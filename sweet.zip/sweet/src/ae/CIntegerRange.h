/* -*-c++-*- */
/* $Id: CIntegerRange.h 5409 2013-06-16 15:04:47Z lkg02 $ */
#ifndef _C_INTEGER_RANGE_H_
#define _C_INTEGER_RANGE_H_

#include "tools/integer_utilities.h"

#include <iostream>
#include <cassert>
#include <stdint.h>

/** \class
   Represents an integer range (interval). Intervals can be extended,
   can decide if it overlaps another interval etc.
   */
class CIntegerRange
{
public:
   /** Construct a new integer range with lower bound l and upper bound u
      \pre l \< u
      */
   CIntegerRange(int64_t l, int64_t u) : _l(l), _u(u) { assert(l <= u); }

   /// Destroys this integer range.
   virtual ~CIntegerRange() { }

   /// Returns the lower bound of the interval
   int64_t L() const { return _l; }

   /// Returns the upper bound of the interval
   int64_t U() const { return _u; }

   /// Returns a pointer to a new integer range that is a duplicate of this integer range.
   CIntegerRange* Copy() const { return new CIntegerRange(_l, _u); }

   /// Checks if this integer range includes a certain point
   /// \param i The integer to be checked
   /// \return True if the point is included in the range.
   bool Includes(int64_t i) const { return i >= _l && i <= _u; }

   /// Checks if this integer range includes another range
   /// \param other The integer range to be checked
   /// \return True if the union between this and the other range is the same as this range, else false
   bool Includes(const CIntegerRange* other) const { return other->L() >= _l && other->U() <= _u; }

   /// Checks if this integer range overlaps antoher integer range
   /// \param other The integer range to be checked
   /// \return True if the intersection between this and the other is not empty, else false
   bool Overlaps(const CIntegerRange* other) const { return !(other->U() < _l || other->L() > _u); }

   /// Merges this integer interval with another
   /// \param other The integer range to merge with
   /// \return A new single integer range that includes this and the other interval ranges
   CIntegerRange* Merge(const CIntegerRange* other) const { return new CIntegerRange(std::min(_l, other->L()),std::max(_u,other->U())); }

   /// Extends this integer interval to include another
   /// \param other The integer range to merge with
   /// \return A new single integer range that includes this and the other interval ranges
   void ExtendWith(const CIntegerRange* other) { _l = std::min(_l, other->L()); _u = std::max(_u,other->U()); }

   ///  \return The number of integers that this integer range represents
   int64_t Cover() const { return _u - _l + 1; }

   /// Prints this integer range as text to the console
   void Print() const {Print(&std::cout);}

   /// Prints this integer range as text to a stream
   void Print(std::ostream * o) const;

   /// Prints this integer range as dot to a stream
   void Draw(std::ostream * o) const;

   /// Prints this integer range as text (in binary format) to the console
   void PrintBinary() const {PrintBinary(&std::cout);};

   /// Prints this integer range as text (in binary format) to a stream
   void PrintBinary(std::ostream * o) const;

private:
  // To hold the upper and lower values
  int64_t _l;
  int64_t _u;
};

// Alternative printing function
std::ostream &operator << (std::ostream &o, const CIntegerRange &r);

#endif
