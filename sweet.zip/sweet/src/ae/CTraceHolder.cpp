
#include "CTraceHolder.h"
#include <stdexcept>
#include <assert.h>

using namespace std;

CTraceHolder::
CTraceHolder(string trace_file_name)
{
  _trace_stream.open(trace_file_name.c_str(), ios::in);
  if (_trace_stream.fail()) {
    throw runtime_error("Trace file " + trace_file_name + " could not be opened");
  }
}

CTraceHolder::
~CTraceHolder()
{
  if(_trace_stream.is_open())
    _trace_stream.close();
}

bool 
CTraceHolder::
HasNoMoreTraces() 
{
  // If the stream is empty
  if(_trace_stream.eof())
    return true;

  // Get the next char without extracting it from trace stream
  char c = _trace_stream.peek();
  // Loop until we have reached end of file
  while(c != '\0' && c != EOF) {
    // Ignore space items and semicolons
    if(c == ' ' || c == '\t' || c == '\n' || c == ';') {
      _trace_stream.get();
      c = _trace_stream.peek();
    }
    else {
      // We have something not being end of file nor a space or semicolon
      return false;
    }
  }
  return true;
}

bool 
CTraceHolder::
IsEndOfTrace() 
{
  // If the stream is empty
  if(_trace_stream.eof())
    return true;

  // Get the next char without extracting it from trace stream
  char c = _trace_stream.peek();
  // Loop until we have reached end of file
  while(c != '\0' && c != EOF) {
    // Ignore space items 
    if(c == ' ' || c == '\t' || c == '\n') {
      _trace_stream.get();
      c = _trace_stream.peek();
      continue;
    }
    // We have something, check if it is a semicolonm
    if(c == ';')
      return true;
    else {
      return false;
    }
  }
  return true;
}

std::string 
CTraceHolder::
GetNextItemFromTrace()
{
  assert(!IsEndOfTrace() && !HasNoMoreTraces());

  // Derive the next item string 
  std::string s;
  char c = _trace_stream.peek();
  while(c != '\0' && c != EOF && c != ' ' && c != '\t' && c != '\n' && c != ';') {
    s += _trace_stream.get();
    c = _trace_stream.peek();
  }
  return s;
}




