/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE: Code implementing an collector which keeps track of the 
//  nodes that never, for any iteration of a certain scope, are executed 
//  together. 
//  The collector should be updated by IterNodeCountRecorders.
//   andreas.ermedahl@mdh.se
//
// ----------------------------------------------------------------------
//
//  $Id: $
//
// ----------------------------------------------------------------------

#ifndef CIterNodePairCollector_H_
#define CIterNodePairCollector_H_

// Standard includes
#include <string>
#include <iostream>
#include <fstream>
#include <map>
#include <set>

// To get the node and scope representation
#include "graphs/ecfg/CECFGNode.h"
#include "graphs/scopes/CScope.h" 
#include "ae/CIterNodeCountRecorder.h"
#include "ae/CCollector.h"
#include "ae/CBitVector.h"

// To avoid writing std:: everywhere
using namespace std;

// Class hierarachy:
//
// CIterNodeCountRecorder 
//   |- CIterMutualExclusiveNodePairCollector
//   |- CIterMustBeTakenTogetherNodePairCollector
//   |- CIterMutualExclusiveAndMustBeTakenTogetherNodePairCollector

// ------------------------------------------------------- 
// CIterNodePairCollector 
// - Class that implements a collector which keeps track of the nodes
// that never, for any iteration of a certain scope, are executed
// together, or if there are nodes that must always be taken together. 
// To inherit from
// At initialization we will first derive which node pairs
// that are interesting to consider in the scope (only those are
// recorded). These are the pair of nodes: <n,m> where the execution
// first may reach n and then later on may reach m. Moreover, if we
// must reach m if n was taken, then we do not want to include the
// pair.  At each new report of a recorder the taken node pairs will
// be updated by the node pairs that have been taken together.
// Finally, those node pairs that where never reported as taken
// together will be used to generate BB1 + BB2 < 2 flow facts for.  If
// we run an analysis with no merging we can also generate flow facts
// which keep track of nodes that must be taken together at each
// iteration of a scope, that is <> : BB1 = BB2 flow facts.  If these
// should be generated are controlled by the
// generate_must_be_taken_together_facts argument.
// -------------------------------------------------------
class CIterNodePairCollector : public CCollector
{
public:
  // To create and delete the collector
  CIterNodePairCollector(CScope * scope, bool record_only_basic_block_start_nodes,
                         bool generate_mutual_exclusive_facts,
                         bool generate_must_be_taken_together_facts);
  virtual ~CIterNodePairCollector();

  // To get updated with a recorder
  void Report(int iter, CIterNodeCountRecorder * rec);
  // Not to be called 
  void Report(CRecorder * rec) {assert(0);};
  // Will call the more specialized function above
  void Report(int iter, CRecorder * rec);

  // To generate flow facts from the exclusion matrix to be inserted
  // in the scope
  int GenerateFlowFacts(void);

  // Take a set of collectors, merge their internals and generate
  // context sensitive valid at entry of flow facts valid over CFG
  // nodes. Returns the number of flow facts created. Adds created ffs
  // to last argument. Collectors should be of CIterNodePairCollector type.
  int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                      std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,
                                                      std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);  

  // To print the collector
  void Print(std::ostream *o=&std::cout);
  virtual void PrintType(std::ostream *o=&std::cout) = 0;

  // To get the number of updates made
  int NrOfReports() { return _nr_of_updates; }

protected:

  // Help class to keep track of how two nodes maye be taken together
  // The state is represented by a three bit bitvector.
  // bv[0] specifies if the two nodes may have a zero sum (1=true, 0=false).
  // bv[1] specifies if the two nodes may have a one sum (1=true, 0=false).
  // bv[2] specifies if the two nodes may have a two sum (1=true, 0=false).
  // Initially all bits are set to zero.
  class CTakenTogetherState : public CBitVector 
  {
  public:
    
    // To create and delete the vector
    CTakenTogetherState() : CBitVector(3) {}
    virtual ~CTakenTogetherState() {}
    
    // Functions to set and get the taken together state 
    bool MayHaveZeroSum() { return ElementExists(0); }
    void SetMayHaveZeroSum() { AddElement(0); }
    bool MayHaveOneSum() { return ElementExists(1); }
    void SetMayHaveOneSum() { AddElement(1); }
    bool MayHaveTwoSum() { return ElementExists(2); }
    void SetMayHaveTwoSum() { AddElement(2); }

    // To merge two states. Will update current state. Is implemented using bitwise or.
    void MergeStates(CTakenTogetherState * other_state) { *this += other_state; }

    // Functions to see if node pair is exclusive or always taken together.
    bool IsMutualExclusive() { return !MayHaveTwoSum(); }
    bool MustBeTakenTogether() { return (!MayHaveOneSum() && MayHaveTwoSum()); } 
  };

  // Help functions to derive which node pairs and start nodes to consider
  void CollectNodePairsToConsider(void);
  void DeriveNodePairsToConsider(CScope * scope, 
                                 std::vector<std::pair<CECFGNode *, CECFGNode *> > * node_pairs_to_consider,
                                 std::set<CECFGNode *> * start_nodes_to_consider);

  // The scope for which the node pairs will be recorded and for which the 
  // flow facts will be created
  CScope * _scope;

  // We represent the excluding matrix as a mapping of pair of nodes
  // to a taken or not taken state
  std::map<std::pair<CECFGNode *, CECFGNode *>, CTakenTogetherState *> _node_pair_to_taken_state_map;

  // To quickly determine if a certain start node are included in any
  // node pair at all
  std::set<CECFGNode *> _start_nodes_to_consider;

  // To remember the number of updates made
  int _nr_of_updates;

  // If only basic block start nodes should be recorded
  bool _record_only_basic_block_start_nodes;

  // If we should generate exclusive node flow facts
  bool _generate_mutual_exclusive_facts;

  // If we should generate must be taken together facts
  bool _generate_must_be_taken_together_facts;

};

// -------------------------------------------------------
// CIterMutualExclusiveNodePairCollector -
// Class inheriting most functionality from CIterNodePairCollector.
// Derives only exclusive node pairs.
// -------------------------------------------------------
class CIterMutualExclusiveNodePairCollector : public CIterNodePairCollector
{
public:
  // To create the collector
  CIterMutualExclusiveNodePairCollector(CScope * scope, bool record_only_basic_block_start_nodes=true);
  
  // To print the type of the collector
  void PrintType(std::ostream *o=&std::cout);
};

// -------------------------------------------------------
// CIterMustBeTakenTogetherNodePairCollector -
// Class inheriting most functionality from CIterNodePairCollector.
// Derives only node pairs that must be taken together (ie either both
// or none of the nodes are taken each iteration. Only to be used
// together with no merging.
// -------------------------------------------------------
class CIterMustBeTakenTogetherNodePairCollector : public CIterNodePairCollector
{
public:
  // To create the collector
  CIterMustBeTakenTogetherNodePairCollector(CScope * scope, bool record_only_basic_block_start_nodes=true);
  
  // To print the type of the collector
  void PrintType(std::ostream *o=&std::cout);
};

// -------------------------------------------------------
// CIterMutualExclusiveAndMustBeTakenTogetherNodePairCollector -
// Class inheriting most functionality from CIterNodePairCollector.
// Derives exclusive node pairs and node pairs that must be taken
// together (ie either both or none of the nodes are taken each
// iteration. Only to be used together with no merging.
// -------------------------------------------------------
class CIterMutualExclusiveAndMustBeTakenTogetherNodePairCollector : public CIterNodePairCollector
{
public:
  // To create the collector
  CIterMutualExclusiveAndMustBeTakenTogetherNodePairCollector(CScope * scope, bool record_only_basic_block_start_nodes=true);
  
  // To print the type of the collector
  void PrintType(std::ostream *o=&std::cout);
};

#endif
