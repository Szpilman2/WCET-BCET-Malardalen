/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CBBCostCalcRecorder.h 1812 2010-02-23 14:49:13Z ael01 $
//
// ----------------------------------------------------------------------

#ifndef CBBCostCalcRecorder_H_
#define CBBCostCalcRecorder_H_

#include <string>
#include <iostream>
#include <fstream>
#include <map>
#include <set>

// To get the scope node representation
#include "graphs/ecfg/CECFGNode.h"
// To get the CRecorder and CRecorderServer base classes
#include "CRecorder.h"


// To handle cout, cin, etc.
using namespace std;

//----------------------------------------------------------------------
// Forward-declare types
//----------------------------------------------------------------------
class CBBCostCalcRecorder;
class CBBCostCalcRecorderServer;
class CBBCostCalcRecorderCOWServer;
class CBBCostCalcRecorderNoReuseServer;
class CScope;
class CBBCostCalcCollector;
class CBBCostLookupTable;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CBBCostCalcRecorder
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CBBCostCalcRecorder : public CRecorder
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------

  // Create a recorder which when executing a node or edge tries to 
  // derive the cost for the node or edge from the bb cost table. 
  // If such costs exists it is added to the recorders min and max costs.
  CBBCostCalcRecorder();
  CBBCostCalcRecorder(const CBBCostLookupTable * bb_costs,
		      int64_t init_min_cost=0, int64_t init_max_cost=0,
		      bool record_min_cost_path=false,
		      bool record_max_cost_path=false);
  virtual ~CBBCostCalcRecorder(void);

  //----------------------------------
  // To update the recorder with a new execution of a edge
  //---------------------------------
  void UpdateWithProgramCounterChange(CECFGNode * pc_before, CECFGNode * pc_after);
  void UpdateWithProgramExit(CECFGNode * pc_before);

  //----------------------------------
  // Report the current min and max timing 
  //---------------------------------
  void ReportToCollector(CBBCostCalcCollector * collector);

  //----------------------------------
  // Reset recorder. Will remove all edge to range mappings.
  //---------------------------------
  void Reset(void);

  //----------------------------------
  // To copy the recorder
  //---------------------------------
  CBBCostCalcRecorder * Copy();

  //----------------------------------
  // To merge two recorders (LUB)
  //---------------------------------
  CBBCostCalcRecorder * Merge(CBBCostCalcRecorder * other_recorder);
  // Will call the more specialized Merge() function...
  CRecorder * Merge(CRecorder * other_recorder);

  // ---------------------------------
  // For printing the recorder
  // ---------------------------------
  void Print() {Print(&std::cout);};
  void Print(std::ostream * o);

  // For getting the min and max cost
  int64_t GetMinCost() { return _min_cost; }
  int64_t GetMaxCost() { return _max_cost; }

protected:

  // Help functions for adding cost for nodes or edges
  void AddCostForNode(CECFGNode * node);
  void AddCostForEdge(CECFGNode * from_node, CECFGNode * to_node);

  // A reference to the cost table
  const CBBCostLookupTable * _bb_costs;

  // The lower and upper timing cost encountered for the recorder so far.
  // Will be reported to the collector.
  int64_t _min_cost;
  int64_t _max_cost;

  // The best and worst case paths
  bool _record_min_cost_path;
  std::vector<CECFGNode *> _min_cost_path;
  bool _record_max_cost_path;
  std::vector<CECFGNode *> _max_cost_path;
};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CBBCostCalcRecorder &a);


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CBBCostCalcRecorderServer
// - Server for generating new edge count recorders
// - To inherit from
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CBBCostCalcRecorderServer : public CRecorderServer
{
public:
  // To create an edge count recorder server. Default behaviour is to
  // only record edges inbetween basic block headers. Alternatively,
  // the behaviour can be controlled by the boolean argument.
  CBBCostCalcRecorderServer(CBBCostLookupTable * bb_costs,
			    bool record_min_cost_path=false,
			    bool record_max_cost_path=false); 
  virtual ~CBBCostCalcRecorderServer() {};

  // For creating a new recorder. Will allocate the recorder and add
  // <recorderptr,1> to the map.
  CBBCostCalcRecorder * CreateRecorder();

  // For deleting a recorder. When deleting a recorder then <recorderptr, i> ->
  // <recorderptr, i-1> If i-1 == 0 then remove recorder for real.
  void DeleteRecorder(CBBCostCalcRecorder * recorder);
    // Will call the more specialized delete function...
  void DeleteRecorder(CRecorder * recorder);

  // To copy the recorder. Returns maybe a new recorder. Ie.
  // the caller should reset its _recorder to the recorder returned.
  virtual CBBCostCalcRecorder * CopyRecorder(CBBCostCalcRecorder * recorder) = 0;
  // Will call the more specialized copy function...
  CRecorder * CopyRecorder(CRecorder * recorder);

  // Functions to be implkemented by subclasses. 
  virtual void UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after) = 0;
  virtual void UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before) = 0;

  // To reset the recorder. Might return a new recorder. Ie.  the
  // caller should reset its _recorder to the recorder returned.
  virtual CBBCostCalcRecorder * ResetRecorder(CBBCostCalcRecorder * recorder) = 0;
  // Will call the more specialized reset function...
  virtual void ResetRecorder(CRecorder ** recorder);

  // To merge two recorders. Return a new recorder.
  virtual CBBCostCalcRecorder * MergeRecorders(CBBCostCalcRecorder * recorder1,
					     CBBCostCalcRecorder * recorder2) = 0;
  // Will call the more specialized merge function...
  CRecorder * MergeRecorders(CRecorder * rec1, CRecorder * rec2);

  // For printing the server
  void Print() {Print(&std::cout);};
  void Print(std::ostream * o);

protected:
  // All recorders are accessible from server by the <recorderptr, refs> map.
  // refs is a counter holding the number of references to the recorder.
  std::map<CBBCostCalcRecorder *, int64_t> _recorder_to_refs;

  // A reference to the bb cost table
  CBBCostLookupTable * _bb_costs;

  // If the best and worst case paths should be rembered 
  bool _record_min_cost_path;
  bool _record_max_cost_path;

};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CBBCostCalcRecorderServer &a);

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CBBCostCalcRecorderCOWServer
// - Recorder server for generating new recorders according to
// copy on write. Most functionality is inherited from CBBCostCalcRecorderServer.
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CBBCostCalcRecorderCOWServer : public CBBCostCalcRecorderServer
{
public: 
  // To create and delete the recorder server. Default behaviour is to
  // only record edges inbetween basic block headers. Alternatively,
  // the behaviour can be controlled by the boolean argument.
  CBBCostCalcRecorderCOWServer(CBBCostLookupTable * bb_costs,
			       bool record_min_cost_path=false,
			       bool record_max_cost_path=false);
  virtual ~CBBCostCalcRecorderCOWServer();

  // For copying the recorder using copy on write. Will not do any copying
  // right away, instead it will just update the map as: <recorderptr, i>
  // -> <recorderptr, i+1>
  CBBCostCalcRecorder * CopyRecorder(CBBCostCalcRecorder * recorder);

  // To increase a count for a edge in the recorder. Might return a
  // new recorder. Ie.  the caller should reset its _recorder to the recorder
  // returned.  If <recorderptr, i> where i > 1 then copy recorder (for real),
  // do the update and return new copied and updated recorder
  // (recorderptr'). We add <recorderptr',1> to map, and update <recorderptr, i>
  // -> <recorderptr, i-1>.  else i == 1, then do the update on recorderptr
  // and return same recorderptr.
  void UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after);
  void UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before);

  // To reset the recorder. Might return a new recorder. Ie.  the
  // caller should reset its _recorder to the recorder returned. If
  // <recorderptr, i> where i > 1 then copy recorder (for real), do
  // the update and return new copied and updated recorder
  // (recorderptr'). We add <recorderptr',1> to map, and update
  // <recorderptr, i> -> <recorderptr, i-1>.  else i == 1, then do the
  // update on recorderptr and return same recorderptr.
  CBBCostCalcRecorder * ResetRecorder(CBBCostCalcRecorder * recorder);

  // To merge two recorders. Return a new recorder. If both recorders
  // are the same we will just return a pointer to the recorder and
  // increase count as <recorderptr, i> -> <recorderptr, i+1>. Otherwise
  // we make the real merge make a new <newrecorderptr, 1> and return
  // the new recorder generated.
  CBBCostCalcRecorder * MergeRecorders(CBBCostCalcRecorder * recorder1,
                                       CBBCostCalcRecorder * recorder2);

};

//------------------------------------------------------------
//--------------------------------------------------
// CBBCostCalcRecorderNoReuseServer
// - Server implementing no reuse.
// - Most functionality is inherited from CBBCostCalcRecorderServer.
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CBBCostCalcRecorderNoReuseServer : public CBBCostCalcRecorderServer
{
public:

  // To create and delete the recorder server. Default behaviour is to
  // only record edges inbetween basic block headers. Alternatively,
  // the behaviour can be controlled by the boolean argument.
  CBBCostCalcRecorderNoReuseServer(CBBCostLookupTable * bb_costs,
				   bool record_min_cost_path=false,
				   bool record_max_cost_path=false);
  virtual ~CBBCostCalcRecorderNoReuseServer();

  // For copying the recorder the ordinary way (ie. diretly when Copy() is called).
  // Creates a new recorder and adds <recorderptr, 1> to the map.
  CBBCostCalcRecorder * CopyRecorder(CBBCostCalcRecorder * recorder);

  // For updating the recorder the ordinary way. Will not update map.
  void UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after);
  void UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before);

  // For reseting the recorder the ordinary way.  Will not update map.
  CBBCostCalcRecorder * ResetRecorder(CBBCostCalcRecorder * recorder);

  // To merge two recorders the ordinary way. Return a new recorder
  // and adds <recorderptr, 1> to the map.
  CBBCostCalcRecorder * MergeRecorders(CBBCostCalcRecorder * recorder1,
				       CBBCostCalcRecorder * recorder2);

};

#endif
