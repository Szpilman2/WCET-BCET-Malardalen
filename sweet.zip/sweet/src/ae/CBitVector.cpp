#include "CBitVector.h"
#include <assert.h>

CBitVector::
CBitVector(unsigned int size_in_bits) 
  : _size_in_bits(size_in_bits)
{
  unsigned nr_of_ints_needed = size_in_bits / NR_OF_INT_BITS;
  if (size_in_bits % NR_OF_INT_BITS)
    nr_of_ints_needed++;
  _bit_vector.resize(nr_of_ints_needed);
}

CBitVector::
~CBitVector(void) 
{
  // Do nothing the vector of ints will be automatically deallocated
}


void 
CBitVector::
AddElement(unsigned key) 
{ 
  _bit_vector[key>>BITS_IN_INT_BITS] |= 1 << (key & MASK_OF_INTBITS); 
}

void 
CBitVector::
RemoveElement(unsigned key) 
{ 
  _bit_vector[key>>BITS_IN_INT_BITS] &= ~(1 << (key & MASK_OF_INTBITS)); 
}

bool 
CBitVector::
ElementExists(unsigned key) const
{ 
  return _bit_vector[key>>BITS_IN_INT_BITS] & (1 << (key & MASK_OF_INTBITS)); 
}

int
CBitVector::
NrOfElements(void)
{
  int n = 0;
  for (unsigned i=0; i<_size_in_bits; i++) {
    if (ElementExists(i)) {
      n++;
    }
  }
  return n;
}

CBitVector *
CBitVector::
operator+(const CBitVector *theother)
{
  assert(SizeInBits() == theother->SizeInBits());
  unsigned nelements = (unsigned)_bit_vector.size();
  for (unsigned i=0; i<nelements; i++) {
    (*this)._bit_vector[i] |= (*theother)._bit_vector[i];
  }
  return this;
}

CBitVector *
CBitVector::
operator-(const CBitVector *theother)
{
  assert(SizeInBits() == theother->SizeInBits());
  // The actual code
  unsigned nelements = (unsigned)_bit_vector.size();
  for (unsigned i=0; i<nelements; i++) {
    (*this)._bit_vector[i] &= ~(*theother)._bit_vector[i];
  }
  return this;
}

CBitVector *
CBitVector::
operator&(const CBitVector *theother)
{
  assert(SizeInBits() == theother->SizeInBits());
  unsigned nelements = (unsigned)_bit_vector.size();
  for (unsigned i=0; i<nelements; i++) {
    (*this)._bit_vector[i] &= (*theother)._bit_vector[i];
  }
  return this;
}

void
CBitVector::
PrintElements(std::ostream *o) const
{
  for (unsigned i=0; i<_size_in_bits; i++) {
    if (ElementExists(i)) {
      *o << i << " ";
    }
  }
}

void
CBitVector::  
PrintBinary(std::ostream *o) const
{
  for (unsigned i=0; i<_size_in_bits; i++) {
    if (ElementExists(i)) 
      *o << 1;
    else
      *o << 0;
  }
}

CBitVector *
CBitVector::
Copy() const
{
  // We create an zeroised  vector and or it with the current vector
  CBitVector * new_vector = new CBitVector(_size_in_bits);
  (*new_vector) += this;
  return new_vector;
}

bool
CBitVector::
IsEqual(const CBitVector * theother) const
{
  if((*this).SizeInBits() != (*theother).SizeInBits())
    return false;
  unsigned nelements = (unsigned)_bit_vector.size();
  for (unsigned i=0; i<nelements; i++) {
    if((*this)._bit_vector[i] != (*theother)._bit_vector[i])
      return false;
  }
  return true;
}


CBitVectorWithBot *
CBitVectorWithBot::
Copy() const 
{
  // We should copy the other vector and its is_bot boolean
  CBitVectorWithBot * new_vector = new CBitVectorWithBot(_size_in_bits, _is_bot);
  (*new_vector) += this;
  return new_vector;
}
