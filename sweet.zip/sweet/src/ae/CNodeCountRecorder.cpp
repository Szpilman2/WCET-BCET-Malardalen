/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CNodeCountRecorder.cpp 7976 2018-11-23 15:35:50Z lkg02 $
//
// ----------------------------------------------------------------------

#include "CNodeCountRecorder.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/ecfg/CECFGNode.h"
#include "ae/CNodeCountCollector.h"
#include "ae/CNodePairCountCollector.h"
#include "macros.h"
using namespace std;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodeCountRecorder
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of recorder
//----------------------------------
CNodeCountRecorder::
CNodeCountRecorder(bool record_only_basic_block_start_nodes)
: _record_only_basic_block_start_nodes(record_only_basic_block_start_nodes)
{

  // Do nothing
}

//----------------------------------
// Deletion of recorder
//----------------------------------
CNodeCountRecorder::
~CNodeCountRecorder()
{
  // Go through the map deleting all the ranges
  t_node_to_range_map::iterator n2r;
  FORALL(n2r, _node_to_range_map)
    delete (*n2r).second;
  ;
}

//----------------------------------
// Remember that we have executed a certain node
//----------------------------------
void
CNodeCountRecorder::
IncreaseCount(CECFGNode * node)
{
  // Check if we should ignore the node
  if(_record_only_basic_block_start_nodes && !(node->IsBeginOfBasicBlock()))
    return;

  // Check if the node exists since before
  if(_node_to_range_map.find(node) == _node_to_range_map.end())
    {
      // Nope, add the range 1..1 to the map
      CIntegerRange* range = new CIntegerRange(1,1);
      _node_to_range_map[node] = range;
    }
  else
    {
      // Yes, add 1..1 to the old range value
      CIntegerRange* old_range =  _node_to_range_map[node];
      int64_t new_l = old_range->L() + 1;
      int64_t new_u = old_range->U() + 1;
      CIntegerRange* new_range = new CIntegerRange(new_l,new_u);
      delete old_range;
      _node_to_range_map[node] = new_range;
    }
}

void
CNodeCountRecorder::
UpdateWithProgramCounterChange(CECFGNode * pc_before, CECFGNode * pc_after)
{
  IncreaseCount(pc_before);
}

void
CNodeCountRecorder::
UpdateWithProgramExit(CECFGNode * pc_before)
{
  IncreaseCount(pc_before);
}

void
CNodeCountRecorder::
SetCount(CECFGNode * node, int count)
{
  // Check if we should ignore the node
  if(_record_only_basic_block_start_nodes && !(node->IsBeginOfBasicBlock()))
    return;

  // Check if the node exists since before
  if(_node_to_range_map.find(node) == _node_to_range_map.end())
    {
      // Nope, set the range
      _node_to_range_map[node] = new CIntegerRange(count, count);
    }
  else
    {
      // Delete the old range
      delete _node_to_range_map[node];
      _node_to_range_map[node] = new CIntegerRange(count, count);
    }
}

void
CNodeCountRecorder::
SetRange(CECFGNode * node, CIntegerRange* range)
{
  // Check if we should ignore the node
  if(_record_only_basic_block_start_nodes && !(node->IsBeginOfBasicBlock()))
    return;

  // Check if the node exists since before
  if(_node_to_range_map.find(node) == _node_to_range_map.end())
    {
      // Nope, set the range
      _node_to_range_map[node] = range;
    }
  else
    {
      // Delete the old range
      delete _node_to_range_map[node];
      _node_to_range_map[node] = range;
    }
}

//----------------------------------
// Report the current ranges to the collector.
//---------------------------------
void
CNodeCountRecorder::
ReportToCollector(CNodeCountCollector * collector)
{
  // Report the current mapping to collector
  collector->Update(&_node_to_range_map);
}

void
CNodeCountRecorder::
ReportToCollector(CNodePairCountCollector * collector)
{
  // Report the current mapping to collector
  collector->Update(&_node_to_range_map);
}

//----------------------------------
// Reset the recorder
//---------------------------------
void
CNodeCountRecorder::
Reset()
{
  // Delete all the ranges
  t_node_to_range_map::iterator n2r;
  FORALL(n2r, _node_to_range_map)
    delete (*n2r).second;

  // Remove all the mappings
  _node_to_range_map.erase(_node_to_range_map.begin(), _node_to_range_map.end());
  assert(_node_to_range_map.size() == 0);
}

//----------------------------------
// Copy the recorder
//---------------------------------
CNodeCountRecorder *
CNodeCountRecorder::
Copy()
{
  // Create a new recorder
  CNodeCountRecorder * new_recorder = new CNodeCountRecorder(_record_only_basic_block_start_nodes);

  // Go through all the node_id to range mappings
  t_node_to_range_map::iterator n2r;
  FORALL(n2r, _node_to_range_map)
    {
      CECFGNode * node = (*n2r).first;
      CIntegerRange* range = (*n2r).second;
      CIntegerRange* new_range = range->Copy();
      new_recorder->_node_to_range_map[node] = new_range;
    }
  // We are done, the range map has been copied to the new recorder
  return new_recorder;
}



//----------------------------------
// Merge two recorders
//---------------------------------
CNodeCountRecorder *
CNodeCountRecorder::
Merge(CNodeCountRecorder * other_recorder)
{
  // Create a new recorder with the same collector
  CNodeCountRecorder * new_recorder = other_recorder->Copy();

  // A set to keep track of processed nodes
  set<CECFGNode *> processed_nodes;

  // Go through all the node_id to range mappings in the current
  // recorder and the argument recorder and remember all the nodes
  // mappings
  t_node_to_range_map::iterator n2r;
  FORALL(n2r, _node_to_range_map)
    {
      CECFGNode * node = (*n2r).first;
      CIntegerRange* range = (*n2r).second;

      // Check if the new recorder has a range for the node
      if(new_recorder->_node_to_range_map.find(node) ==
         new_recorder->_node_to_range_map.end()) {

        // No range, this means that the node has not been
        // taken in the other state

        // Create a [0..0] range
        CIntegerRange* zero_range = new CIntegerRange(0,0);

        // Merge the current range with the zero range
        CIntegerRange* new_range = range->Merge(zero_range);

        // Delete the temporary range
        delete zero_range;

        // Add the new range to the recorder for the node (prev_range
        // will be deleted)
        new_recorder->SetRange(node, new_range);
      }
      else {
        // Merge ranges (prev_range will be deleted)
        CIntegerRange* prev_range = new_recorder->_node_to_range_map[node];
        new_recorder->SetRange(node, range->Merge(prev_range));
      }
      // Add the node to the set of processed nodes
      processed_nodes.insert(node);
    }

  // Go through the second recorder mapping
  FORALL(n2r, other_recorder->_node_to_range_map)
    {
      // Get the node
      CECFGNode * node = (*n2r).first;

      // Check if the node already has been processed
      if(processed_nodes.find(node) != processed_nodes.end())
        continue;

      // We have a node that only exists in the second set.  This
      // means that the node has not been taken in the other state

      // Get the range
      CIntegerRange* range = (*n2r).second;

      // Create a [0..0] range
      CIntegerRange* zero_range = new CIntegerRange(0,0);

      // Merge the current range with the zero range
      CIntegerRange* new_range = range->Merge(zero_range);

      // Delete the temporary range
      delete zero_range;

      // Add the new range to the recorder for the node (prev_range
      // will be deleted)
      new_recorder->SetRange(node, new_range);
    }
  // Return the new recorder
  return new_recorder;
}

//----------------------------------
// Merge two recorders
//---------------------------------
CRecorder *
CNodeCountRecorder::
Merge(CRecorder * other_recorder)
{
  return Merge(dynamic_cast<CNodeCountRecorder *>(other_recorder));
}

//---------------------------------
// For printing the recorder
//---------------------------------
void
CNodeCountRecorder::
Print(ostream * o)
{
  t_node_to_range_map::iterator n2r;
  FORALL(n2r, _node_to_range_map)
    {
      CECFGNode * node = (*n2r).first;
      string bb_name = node->GetFlowGraphNode()->Name();
      CIntegerRange* range = (*n2r).second;
      (*o) << "  " << bb_name << " = " << (*range) << endl;
    }
}


//---------------------------------
// Alternative printing function
//---------------------------------
ostream &operator << (ostream &o, CNodeCountRecorder &a)
{
  a.Print(&o);
  return o;
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodeCountRecorderServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//---------------------------------
// To create the server
//---------------------------------
CNodeCountRecorderServer::
CNodeCountRecorderServer(bool record_only_basic_block_start_nodes)
  : _record_only_basic_block_start_nodes(record_only_basic_block_start_nodes)
{
  // Do nothing
}

//---------------------------------
// To create the recorder
//---------------------------------
CNodeCountRecorder *
CNodeCountRecorderServer::
CreateRecorder()
{
  // Create the recorder
  CNodeCountRecorder * recorder = new CNodeCountRecorder(_record_only_basic_block_start_nodes);

  // Remember that we have one reference to the recorder
  _recorder_to_refs[recorder] = 1;

  // Return the new recorder
  return recorder;
}

// -------------------------------------------------------
// To delete a certain recorder
// -------------------------------------------------------
void
CNodeCountRecorderServer::
DeleteRecorder(CNodeCountRecorder * recorder)
{
  assert(recorder);
  assert(_recorder_to_refs.find(recorder) != _recorder_to_refs.end());
  // Update map
  _recorder_to_refs[recorder] = _recorder_to_refs[recorder]-1;

  // Check if we have any refs left
  if(_recorder_to_refs[recorder] == 0)
    {
      // No, remove the recorder for real
      delete recorder;

      // Remove the mapping
      // _recorder_to_refs.erase(recorder);
    }
}

void
CNodeCountRecorderServer::
DeleteRecorder(CRecorder * recorder)
{
  // Call the more specialized version
  DeleteRecorder(dynamic_cast<CNodeCountRecorder*>(recorder));
}

// -------------------------------------------------------
// Copy the recorder
// -------------------------------------------------------
CRecorder *
CNodeCountRecorderServer::
CopyRecorder(CRecorder * recorder)
{
  assert(recorder);
  // Call the more specialized version
  return CopyRecorder(dynamic_cast<CNodeCountRecorder*>(recorder));
}

// -------------------------------------------------------
// Update the recorder
// -------------------------------------------------------
void
CNodeCountRecorderServer::
UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after)
{
  assert(*recorder);
  CNodeCountRecorder * rec = dynamic_cast<CNodeCountRecorder*>(*recorder);
  assert(rec);
  // Call the more specialized version
  *recorder = IncreaseCountInRecorder(rec, pc_before);
  assert(*recorder);
}

void
CNodeCountRecorderServer::
UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before)
{
  assert(*recorder);
  CNodeCountRecorder * rec = dynamic_cast<CNodeCountRecorder*>(*recorder);
  assert(rec);
  // Call the more specialized version
  *recorder = IncreaseCountInRecorder(rec, pc_before);
  assert(*recorder);
}

// -------------------------------------------------------
// Reset the current recorder
// -------------------------------------------------------
void
CNodeCountRecorderServer::
ResetRecorder(CRecorder ** recorder)
{
  *recorder = ResetRecorder(dynamic_cast<CNodeCountRecorder*>(*recorder));
}

// -------------------------------------------------------
// Merge two recorders
// -------------------------------------------------------
CRecorder *
CNodeCountRecorderServer::
MergeRecorders(CRecorder * rec1, CRecorder * rec2)
{
  assert(rec1 && rec2);
  return MergeRecorders(dynamic_cast<CNodeCountRecorder*>(rec1), dynamic_cast<CNodeCountRecorder*>(rec2));
}

// -------------------------------------------------------
// To print all the mappings in the server
// -------------------------------------------------------
void
CNodeCountRecorderServer::
Print(ostream * o)
{
  // Loop through all maps
  map<CNodeCountRecorder *, int64_t>::iterator tr;
  int i = 1;
  FORALL(tr, (_recorder_to_refs))
    {
      (*o) << i << ": " << (*tr).first << "."
           << (*tr).second << endl;
      i++;
    }
}

// Alternative printing function
ostream &operator << (ostream &o, CNodeCountRecorderServer &a)
{
  a.Print(&o);
  return o;
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodeCountRecorderCOWServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

// -------------------------------------------------------
// To create the recorder server
// -------------------------------------------------------
CNodeCountRecorderCOWServer::
CNodeCountRecorderCOWServer(bool record_only_basic_block_start_nodes)
  : CNodeCountRecorderServer(record_only_basic_block_start_nodes)
{
  // Do nothing
}

// -------------------------------------------------------
// To delete the recorder server
// -------------------------------------------------------
CNodeCountRecorderCOWServer::
~CNodeCountRecorderCOWServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To copy recorder
// -------------------------------------------------------
CNodeCountRecorder *
CNodeCountRecorderCOWServer::
CopyRecorder(CNodeCountRecorder * recorder)
{
  // Do no copying, just add one more reference to the recorder
  assert(_recorder_to_refs.find(recorder) != _recorder_to_refs.end());
  _recorder_to_refs[recorder] = _recorder_to_refs[recorder] + 1;

  // Return the same recorder
  return recorder;
}

// -------------------------------------------------------
// To increase count for a certain node
// -------------------------------------------------------
CNodeCountRecorder *
CNodeCountRecorderCOWServer::
IncreaseCountInRecorder(CNodeCountRecorder * recorder, CECFGNode * node)
{
  // std::cout << "CNodeCountRecorderCOWServer::IncreaseCountInRecorder 1\n";
  assert(_recorder_to_refs.find(recorder) != _recorder_to_refs.end());
  assert(_recorder_to_refs[recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[recorder] == 1)
    {
      // Update current recorder
      recorder->IncreaseCount(node);

      // Return the updated recorder
      return recorder;
    }
  // More than one reference
  else
    {
      // Do the real copying
      CNodeCountRecorder * recorder_copy = recorder->Copy();

      // Update the copied recorder
      recorder_copy->IncreaseCount(node);

      // Update map
      _recorder_to_refs[recorder] = _recorder_to_refs[recorder] - 1;
      _recorder_to_refs[recorder_copy] = 1;

      // Return the copied recorder
      return recorder_copy;
    }
}

// -------------------------------------------------------
// To reset the recorder
// -------------------------------------------------------
CNodeCountRecorder *
CNodeCountRecorderCOWServer::
ResetRecorder(CNodeCountRecorder * recorder)
{
  assert(_recorder_to_refs.find(recorder) != _recorder_to_refs.end());
  assert(_recorder_to_refs[recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[recorder] == 1)
    {
      // Update current recorder
      recorder->Reset();

      // Return the updated recorder
      return recorder;
    }
  // More than one reference
  else
    {
      // Create a new recorder (same as doing a reset)
      CNodeCountRecorder * new_recorder = new CNodeCountRecorder(_record_only_basic_block_start_nodes);

      // Update map
      _recorder_to_refs[recorder] = _recorder_to_refs[recorder] - 1;
      _recorder_to_refs[new_recorder] = 1;

      // Return the new recorder
      return new_recorder;
    }
}

// -------------------------------------------------------
// To merge two recorders
// -------------------------------------------------------
CNodeCountRecorder *
CNodeCountRecorderCOWServer::
MergeRecorders(CNodeCountRecorder * recorder1, CNodeCountRecorder * recorder2)
{
  assert(_recorder_to_refs.find(recorder1) != _recorder_to_refs.end());
  assert(_recorder_to_refs.find(recorder2) != _recorder_to_refs.end());
  // Check if it is the same recorder (i.e. they points to the same address)
  if(recorder1 == recorder2)
    {
      // Update map
      _recorder_to_refs[recorder1] = _recorder_to_refs[recorder1] + 1;

      // Return the same recorder
      return recorder1;
    }
  else
    {
      // Different recorders, do the real merging
      CNodeCountRecorder * new_recorder = recorder1->Merge(recorder2);

      // Update map
      _recorder_to_refs[new_recorder] = 1;

      // Return the new recorder
      return new_recorder;
    }
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodeCountRecorderNoReuseServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

// -------------------------------------------------------
// To create the recorder server
// -------------------------------------------------------
CNodeCountRecorderNoReuseServer::
CNodeCountRecorderNoReuseServer(bool record_only_basic_block_start_nodes)
  : CNodeCountRecorderServer(record_only_basic_block_start_nodes)
{
  // Do nothing
}

// -------------------------------------------------------
// To delete the recorder server
// -------------------------------------------------------
CNodeCountRecorderNoReuseServer::
~CNodeCountRecorderNoReuseServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To copy recorder
// -------------------------------------------------------
CNodeCountRecorder *
CNodeCountRecorderNoReuseServer::
CopyRecorder(CNodeCountRecorder * recorder)
{
  // Do the copying right away
  CNodeCountRecorder * new_recorder = recorder->Copy();

  // Update map
  _recorder_to_refs[new_recorder] = 1;

  // Return the new recorder
  return new_recorder;
}

// -------------------------------------------------------
// To increase count for a certain node
// -------------------------------------------------------
CNodeCountRecorder *
CNodeCountRecorderNoReuseServer::
IncreaseCountInRecorder(CNodeCountRecorder * recorder, CECFGNode * node)
{
  // Update current recorder
  recorder->IncreaseCount(node);

  // Return the updated recorder
  return recorder;
}

// -------------------------------------------------------
// To reset the recorder
// -------------------------------------------------------
CNodeCountRecorder *
CNodeCountRecorderNoReuseServer::
ResetRecorder(CNodeCountRecorder * recorder)
{
  // Reset current recorder
  recorder->Reset();

  // Return the updated recorder
  return recorder;
}

// -------------------------------------------------------
// To merge two recorders
// -------------------------------------------------------
CNodeCountRecorder *
CNodeCountRecorderNoReuseServer::
MergeRecorders(CNodeCountRecorder * recorder1, CNodeCountRecorder * recorder2)
{
  // Do the merging getting a new recorder
  CNodeCountRecorder * new_recorder = recorder1->Merge(recorder2);

  // Update map
  _recorder_to_refs[new_recorder] = 1;

  // Return the new recorder
  return new_recorder;
}



