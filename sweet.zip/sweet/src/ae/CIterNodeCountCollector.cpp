/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CIterNodeCountCollector.cpp 326 2009-05-06 07:59:13Z msl01 $
//
// ----------------------------------------------------------------------

#include "CIterNodeCountCollector.h"
#include "flow_facts/CFlowFact.h"
#include "flow_facts/CIndexRange.h"
#include "graphs/scopes/CScope.h"
#include "flow_facts/CExpression.h"
#include "graphs/ecfg/CECFGNode.h"
#include "graphs/cfg/CFlowGraphNode.h"

using namespace std;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CIterNodeCountCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of collector
//----------------------------------
CIterNodeCountCollector::
CIterNodeCountCollector(CScope * scope)
{
  _scope = scope;
  _collect_only_basic_block_start_nodes = true;
  _nr_of_updates = 0;
}

CIterNodeCountCollector::
CIterNodeCountCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
{
  _scope = scope;
  _collect_only_basic_block_start_nodes = collect_only_basic_block_start_nodes;
  _nr_of_updates = 0;
}

//----------------------------------
// Deletion of collector
//----------------------------------
CIterNodeCountCollector::
~CIterNodeCountCollector()
{
  // Do nothing
}

// ---------------------------------
// Report in recorded result to collector
// ---------------------------------
void
CIterNodeCountCollector::
Report(int iter, CRecorder * rec)
{
  Update(iter, dynamic_cast<CIterNodeCountRecorder *>(rec));
}

//----------------------------------
// Create flow facts 
//---------------------------------
int
CIterNodeCountCollector::
GenerateFlowFacts(void)
{
  return AddFlowFactsToScope();
}


//---------------------------------
// Alternative printing function
//---------------------------------
ostream &operator << (ostream &o, CIterNodeCountCollector &a)
{
  a.Print(&o);
  return o;
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CAllIterNodeCountCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of all iter collector
//----------------------------------
CAllIterNodeCountCollector::
CAllIterNodeCountCollector(CScope * scope)
  : CIterNodeCountCollector(scope)
{
  // Do nothing
}

CAllIterNodeCountCollector::
CAllIterNodeCountCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CIterNodeCountCollector(scope, collect_only_basic_block_start_nodes)
{
  // Do nothing
}

//----------------------------------
// Deletion of all iter collector
//----------------------------------
CAllIterNodeCountCollector::
~CAllIterNodeCountCollector()
{
  // Do nothing, the set will delete itself
}

//----------------------------------
// To update the collector with a new path. The path should be valid
// for a certain iteration and consist of node id:s (as integers).
//---------------------------------
void
CAllIterNodeCountCollector::
Update(int iter, CIterNodeCountRecorder * rec)
{
  _nr_of_updates++;

  // Ignore the iteration argument
  (void) iter;

  // Get the nodes in the recording
  set<CECFGNode *>* nodes = rec->Nodes();

  // Go through the nodes and add them to the internal set
  set<CECFGNode *>::iterator node;
  FORALL(node, (*nodes))
    {
      if(_collect_only_basic_block_start_nodes && !((*node)->IsBeginOfBasicBlock()))
        continue;
      else
        // Insert the node in the set. It does not matter if the node
        // has been inserted before.
        _taken_nodes.insert(*node);
    }
  // We are done, all nodes has been added to the set
  return;
}

//----------------------------------
// Create flow facts from the collector and add to scope
//---------------------------------
int
CAllIterNodeCountCollector::
AddFlowFactsToScope(void)
{
  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;

  // Loop through all the nodes in the scope
  CScope::ecfg_nodes_iterator node;
  for(node=_scope->ECFGNodesBegin(); node!=_scope->ECFGNodesEnd(); node++)
    {
      // Skip count variable for loop header node
      if (_scope->IsHeader(*node)) continue;

      // Check if we should skip the node
      if(_collect_only_basic_block_start_nodes && !((*node)->IsBeginOfBasicBlock()))
        continue;

      // If the node exists in the collected set of taken nodes we should
      // not generate a flow fact for it
      if(_taken_nodes.find(*node) != _taken_nodes.end())
        continue;

      // Else, we should create a flow fact stating that the node
      // never can be taken for any iteration of the scope, ie.
      // something like:  scope : < > : bb_name = 0

      // Create the bb_name = 0 expression
      // string bb_name = (*node)->GetFlowGraphNode()->Name();
      // CExpressionId *id = new CExpressionId(bb_name);
      CExpressionECFGNode *id = new CExpressionECFGNode(*node);
      CExpressionInt *eint = new CExpressionInt(0);
      CConstraint constraint(id, RELOP_EQ, eint);

      // Create the <> collector
      CFFCollector t(FOR_EACH);

      // Create the flow fact
      CFlowFact flow_fact(_scope, CFlowFact::INSA, t, constraint);

      // Add the flow fact to the scope
      _scope->AddFlowFact(flow_fact);

      // Remember that we have added another flow fact
      nr_of_added_flow_facts++;
    }
  // Return the numberof added flow facts
  return nr_of_added_flow_facts;
}

// ---------------------------------
// To generate context sensitive valid at entry of flow facts 
// ---------------------------------
int 
CAllIterNodeCountCollector::
GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  bool collectors_updated = false;
  // Derive taken CFG nodes in all collectors
  std::set<CFlowGraphNode *> taken_cfg_nodes;
  // Go through all collectors (they must be iter node count collectors) and add their taken nodes 
  for(std::set<CCollector *>::iterator c = collectors->begin(); c != collectors->end(); ++c) {
    CAllIterNodeCountCollector * inc_collector = dynamic_cast<CAllIterNodeCountCollector *>(*c);
    assert(inc_collector);
    if(inc_collector->NrOfReports() == 0) continue;
    // Go though the collectors taken nodes
    collectors_updated = true;
    for(std::set<CECFGNode *>::iterator ecfg_node = inc_collector->_taken_nodes.begin();
        ecfg_node != inc_collector->_taken_nodes.end(); ++ecfg_node) {
      taken_cfg_nodes.insert((*ecfg_node)->GetFlowGraphNode());
    }
  }

  int nr_of_flow_facts = 0;

  if(collectors_updated) {
  
    // Create infeasible node flow facts 
    CCollector * c = *(collectors->begin());
    assert(c);
    CAllIterNodeCountCollector * inc_collector = dynamic_cast<CAllIterNodeCountCollector *>(c);
    std::set<CECFGNode *> ecfg_nodes_in_scope;
    inc_collector->Scope()->NodesInScopeExceptHeader(&ecfg_nodes_in_scope);
    for(std::set<CECFGNode *>::iterator ecfg_node = ecfg_nodes_in_scope.begin();
        ecfg_node != ecfg_nodes_in_scope.end(); ++ecfg_node) {
      
      // Check if we should skip the node
      if(inc_collector->_collect_only_basic_block_start_nodes && !((*ecfg_node)->IsBeginOfBasicBlock()))
        continue;
      
      // Check if the corresponding flow graph node exists in take CFG nodes set
      CFlowGraphNode * cfg_node = (*ecfg_node)->GetFlowGraphNode();
      if(taken_cfg_nodes.find(cfg_node) == taken_cfg_nodes.end()) {
        // No, we should create an infeasible CFG node flow fact
        
        // Create the callstring:entry:[]:#bb_name = 0 expression
        // string bb_name = cfg_node->Name();
        // CExpressionId *id = new CExpressionId(bb_name);
        CExpressionFlowGraphNode *id = new CExpressionFlowGraphNode(cfg_node);
        CExpressionInt *eint = new CExpressionInt(0);
        CConstraint *constr = new CConstraint(id, RELOP_EQ, eint);
        CFFCollector * coll = new CFFCollector(FOR_EACH);
        CContextSensitiveValidAtEntryOfFlowFact * ff = 
          new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, coll, constr, CFlowFact::INSA);
        
        // Add the flow fact to the vector 
        ffs->push_back(ff);
        
        // Remember that we have added a flow fact
        nr_of_flow_facts++;
      }
    }
  }

  // Return the number of generate flow facts
  return nr_of_flow_facts;
}


// ---------------------------------
// For printing the collector
// ---------------------------------
void
CAllIterNodeCountCollector::
Print(ostream * o)
{
  (*o) << "scope: " << _scope->Name() << endl;
  (*o) << "  ";
  set<CECFGNode *>::iterator node;
  FORALL(node, _taken_nodes)
    {
      (*o) << (*node) << " ";
    }
  (*o) << endl;
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CEachIterNodeCountCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of each iter collector
//----------------------------------
CEachIterNodeCountCollector::
CEachIterNodeCountCollector(CScope * scope)
  : CIterNodeCountCollector(scope)
{
  // Set that we have not yet remembered any iteration
  _max_iter_stored = 0;
  _nr_of_updates = 0;
}

CEachIterNodeCountCollector::
CEachIterNodeCountCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CIterNodeCountCollector(scope, collect_only_basic_block_start_nodes)
{
  // Set that we have not yet remembered any iteration
  _max_iter_stored = 0;
  _nr_of_updates = 0;
}

//----------------------------------
// Deletion of each iter collector
//----------------------------------
CEachIterNodeCountCollector::
~CEachIterNodeCountCollector()
{
  // Go through all items and delete the corresponding set
  map<int, set<CECFGNode *> *>::iterator i2ns;
  FORALL(i2ns, _iter_to_taken_nodes)
    {
      delete (*i2ns).second;
    }
  // Do nothing more, the map will delete itself
}


//----------------------------------
// To update the collector with a new path. The path should be valid
// for a certain iteration and consist of node id:s (as integers).
//---------------------------------
void
CEachIterNodeCountCollector::
Update(int iter, CIterNodeCountRecorder * rec)
{
  _nr_of_updates++;

  // Update the max_iter_stored
  if(_max_iter_stored < iter) _max_iter_stored = iter;

  // To hold the set of nodes taken for the specific iteration
  set<CECFGNode *> * taken_nodes = NULL;

  // Check if the iteration has been added before
  if(_iter_to_taken_nodes.find(iter) == _iter_to_taken_nodes.end())
    {
      // Nope, create a new set for the path
      taken_nodes = new set<CECFGNode *>;

      // Insert the set in the map
      _iter_to_taken_nodes[iter] = taken_nodes;
    }
  else
    {
      taken_nodes = _iter_to_taken_nodes[iter];
    }

  // Make sure that we got something
  assert(taken_nodes);

  // Get the nodes in the recorder
  set<CECFGNode *>* nodes = rec->Nodes();

  // Go through the nodes and add them to the internal set
  set<CECFGNode *>::iterator node;
  FORALL(node, (*nodes))
    {
      // Check if we should skip the node
      if(_collect_only_basic_block_start_nodes && !((*node)->IsBeginOfBasicBlock()))
        continue;

      // Insert the node in the set. It does not matter if the node
      // has been inserted before.
      taken_nodes->insert(*node);
    }

  // We are done, all node id:s has been added in the set for the iteration.
  return;
}



//----------------------------------
// Create flow facts from the collector and add to scope
//---------------------------------
int
CEachIterNodeCountCollector::
AddFlowFactsToScope(void)
{
  // Skip this if scope never has been entered
  if(_max_iter_stored == 0) return 0;

  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;

  // Get the nr of exit edges to outer scopes. To avoid unneccessary
  // scope : <masxiter> : #BB = 0 flow facts.
  bool nr_exit_edges_to_outer_scopes = _scope->NrOfExitEdgesToSurroundingScopes();

  // Loop through all the nodes in the scope
  CScope::ecfg_nodes_iterator node;
  for(node=_scope->ECFGNodesBegin(); node!=_scope->ECFGNodesEnd(); node++)
    {
      // Skip count variable for header node
      if (_scope->IsHeader(*node)) 
        continue;

      // Check if we should skip the node
      if(_collect_only_basic_block_start_nodes && !((*node)->IsBeginOfBasicBlock()))
        continue;

      // Get the basic block name corresponding to the scope node
      // string bb_name = (*node)->GetFlowGraphNode()->Name();

      // The min range in the <min..max> collector that we should create
      int range_min = 0;

      // Loop through the iterations reported
      int iter = 0;
      for(iter = 1; iter < _max_iter_stored; iter++)
        {
          // Get the set of taken nodes for the current iteration
          set<CECFGNode *> * taken_nodes = _iter_to_taken_nodes[iter];
          assert(taken_nodes);

          // Check if the node does not exists in the collected set
          if(taken_nodes->find(*node) == taken_nodes->end())
            {
              // If we should start a new min..max range
              if(range_min == 0)
                range_min = iter;
            }
          else
            {
              // The node existed in the set, check if the min range
              // != 0, i.e., the node has not been taken in previous
              // iterations
              if(range_min > 0)
                {
                  // Create a scope:<min..iter-1>:#bb=0 flow fact
                  // CExpressionId *id = new CExpressionId(bb_name);
                  CExpressionECFGNode *id = new CExpressionECFGNode(*node);
                  CExpressionInt *eint = new CExpressionInt(0);
                  CConstraint constraint(id, RELOP_EQ, eint);
                  CIndexRange * range = new CIndexRange(range_min, iter-1);
                  CFFCollector t(FOR_EACH, range);
                  CFlowFact flow_fact(_scope, CFlowFact::INSE, t, constraint);

                  // Add the flow fact to the scope
                  _scope->AddFlowFact(flow_fact);

                  // Remember that we have added a flow fact
                  nr_of_added_flow_facts++;

                  // Reset range counter since the node could be taken
                  range_min = 0;
                }
            }
        }

      // Treat last iteration especially
      assert(iter == _max_iter_stored);

      // Get the set of taken nodes for the current iteration
      set<CECFGNode *> * taken_nodes = _iter_to_taken_nodes[iter];
      assert(taken_nodes);

      // Check if the node does not exists in the collected set
      if(taken_nodes->find(*node) == taken_nodes->end())
        {
          // If no iteration includes the current node we should
          // create a new <> range covering all iterations
          if(range_min == 1)
            {
              // Create the scope:<>:#bb=0 flow fact
              // CExpressionId *id = new CExpressionId(bb_name);
              CExpressionECFGNode *id = new CExpressionECFGNode(*node);
              CExpressionInt *eint = new CExpressionInt(0);
              CConstraint constraint(id, RELOP_EQ, eint);
              CFFCollector t(FOR_EACH);
              CFlowFact flow_fact(_scope, CFlowFact::INSE, t, constraint);

              // Add the flow fact to the scope
              _scope->AddFlowFact(flow_fact);

              // Remember that we have added a flow fact
              nr_of_added_flow_facts++;
            }
          else
            {
              // If the range covers just one iteration make min_iter
              // equal to the current iteration
              if(range_min == 0)
                range_min = iter;

              // If the range covers just one iteration and we only
              // have an exit edge to the outer scopes we should not
              // generate any flow fact.
              if((range_min == iter) && (nr_exit_edges_to_outer_scopes == 1)) continue;

              // Else, create a scope:<min..max>:#bb=0 flow fact
              // CExpressionId *id = new CExpressionId(bb_name);
              CExpressionECFGNode *id = new CExpressionECFGNode(*node);
              CExpressionInt *eint = new CExpressionInt(0);
              CConstraint constraint(id, RELOP_EQ, eint);
              CIndexRange * range = new CIndexRange(range_min, iter);
              CFFCollector t(FOR_EACH, range);
              CFlowFact flow_fact(_scope, CFlowFact::INSE, t, constraint);

              // Add the flow fact to the scope
              _scope->AddFlowFact(flow_fact);

              // Remember that we have added a flow fact
              nr_of_added_flow_facts++;
            }
        }
      else
        {
          // The node existed in the set, check if the min range
          // != 0, i.e., the node has not been taken in previous
          // iterations
          if(range_min > 0)
            {
              // Create a scope:<min..iter-1>:#bb=0 flow fact
              // CExpressionId *id = new CExpressionId(bb_name);
              CExpressionECFGNode *id = new CExpressionECFGNode(*node);
              CExpressionInt *eint = new CExpressionInt(0);
              CConstraint constraint(id, RELOP_EQ, eint);
              CIndexRange * range = new CIndexRange(range_min, iter-1);
              CFFCollector t(FOR_EACH, range);
              CFlowFact flow_fact(_scope, CFlowFact::INSE, t, constraint);

              // Add the flow fact to the scope
              _scope->AddFlowFact(flow_fact);

              // Remember that we have added a flow fact
              nr_of_added_flow_facts++;
            }
        }
    } // end for all scope nodes

  // Return the number of flow facts added
  return nr_of_added_flow_facts;
}

// ---------------------------------
// To generate context sensitive valid at entry of flow facts 
// ---------------------------------
int 
CEachIterNodeCountCollector::
GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  // -------------------------------------------------------
  // First, merge all collectors iter to taken ecfg nodes maps to one
  // iter to taken cfg node map
  // -------------------------------------------------------

  // To keep track of the max iteration stored
  int max_iter_stored = 0;

  // A temporary mapping between iterations and taken cfg nodes
  std::map<int,std::set<CFlowGraphNode *> *> iter_to_taken_cfg_nodes_map;
  
   // Go through all collectors (they must be all node count
   // collectors) and add their iter to taken ecfg node maps
  for(std::set<CCollector *>::iterator c = collectors->begin(); c != collectors->end(); ++c) {
    CEachIterNodeCountCollector * anc_collector = dynamic_cast<CEachIterNodeCountCollector *>(*c);
    
    for(std::map<int,std::set<CECFGNode *> *>::iterator i2ens = anc_collector->_iter_to_taken_nodes.begin();
        i2ens != anc_collector->_iter_to_taken_nodes.end(); ++i2ens) {
      int iter = (*i2ens).first;

      // Keep track of the largest iteration stored
      if(iter > max_iter_stored)  max_iter_stored = iter;

      // Get the ecfg nodes taken at during iteration as recorded by collector 
      std::set<CECFGNode *> * taken_ecfg_nodes = (*i2ens).second;
      
      // Get the cfg nodes previously taken for the given iteration
      std::set<CFlowGraphNode *> * taken_cfg_nodes = NULL;
      // Check if the iteration had a cfg node set
      if(iter_to_taken_cfg_nodes_map.find(iter) == iter_to_taken_cfg_nodes_map.end()) {
        // Nope, create a new set for the given iteration
        taken_cfg_nodes = new set<CFlowGraphNode *>;
        iter_to_taken_cfg_nodes_map[iter] = taken_cfg_nodes;
      }
      else {
        // Else, reuse the already existing set
        taken_cfg_nodes = iter_to_taken_cfg_nodes_map[iter];
      }

      // Loop through all taken ecfg nodes and insert their
      // corresponding cfg nodes in the taken set for the iteration
      for(std::set<CECFGNode *>::iterator taken_ecfg_node = taken_ecfg_nodes->begin();
          taken_ecfg_node != taken_ecfg_nodes->end(); ++taken_ecfg_node) {
        taken_cfg_nodes->insert((*taken_ecfg_node)->GetFlowGraphNode());
      } 
    } 
  }  

  // -------------------------------------------------------
  // Second, create the flow facts based on the iter to taken cfg nodes map
  // -------------------------------------------------------

  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;

  // Check if no iteration has been taken
  if(max_iter_stored > 0) {

    // Create infeasible node flow facts 
    CCollector * c = *(collectors->begin());
    assert(c);
    CEachIterNodeCountCollector * inc_collector = dynamic_cast<CEachIterNodeCountCollector *>(c);
    std::set<CECFGNode *> ecfg_nodes_in_scope;
    inc_collector->Scope()->NodesInScopeExceptHeader(&ecfg_nodes_in_scope);
    std::set<CECFGNode *>::iterator ecfg_node; 
    for(ecfg_node = ecfg_nodes_in_scope.begin(); ecfg_node != ecfg_nodes_in_scope.end(); ++ecfg_node) {
      
      // Skip count variable for header node
      if (inc_collector->Scope()->IsHeader(*ecfg_node)) 
        continue;

      // Check if we should skip the node
      if(inc_collector->_collect_only_basic_block_start_nodes && !((*ecfg_node)->IsBeginOfBasicBlock()))
        continue;

      // Get the nr of exit edges to outer scopes. To avoid unneccessary
      // scope : <masxiter> : #BB = 0 flow facts.
      bool nr_exit_edges_to_outer_scopes = inc_collector->Scope()->NrOfExitEdgesToSurroundingScopes();

      // Get the cfg node and its name
      CFlowGraphNode * cfg_node = (*ecfg_node)->GetFlowGraphNode();
      string bb_name = cfg_node->Name();
      
      // The min range in the <min..max> collector that we should create
      int range_min = 0;
      
      // Loop through the iterations reported
      int iter = 0;
      for(iter = 1; iter < max_iter_stored; iter++)
        {
          // Get the set of taken nodes for the current iteration
          set<CFlowGraphNode *> * taken_nodes = iter_to_taken_cfg_nodes_map[iter];
          assert(taken_nodes);
          
          // Check if the node does not exists in the collected set
          if(taken_nodes->find(cfg_node) == taken_nodes->end())
            {
              // If we should start a new min..max range
              if(range_min == 0)
                range_min = iter;
            }
          else
            {
              // The node existed in the set, check if the min range
              // != 0, i.e., the node has not been taken in previous
              // iterations
              if(range_min > 0)
                {
                  // Create a new cstring:entry:<i..j>:#bb=0 flow fact
                  // CExpressionId *id = new CExpressionId(bb_name);
                  CExpressionFlowGraphNode *id = new CExpressionFlowGraphNode(cfg_node);
                  CExpressionInt *eint = new CExpressionInt(0);
                  CConstraint * constr = new CConstraint(id, RELOP_EQ, eint);
                  CIndexRange * range = new CIndexRange(range_min, iter-1);
                  CFFCollector * coll = new CFFCollector(FOR_EACH, range);
                  CContextSensitiveValidAtEntryOfFlowFact * ff = 
                    new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, coll, constr, CFlowFact::INSE);
                  
                  // Add the flow fact to the vector 
                  ffs->push_back(ff);
                  
                  // Remember that we have added a flow fact
                  nr_of_added_flow_facts++;
                  
                  // Reset range counter since the node could be taken
                  range_min = 0;
                }
            }
        }
      
      // Treat last iteration especially
      assert(iter == max_iter_stored);
      
      // Get the set of taken nodes for the current iteration
      set<CFlowGraphNode *> * taken_nodes = iter_to_taken_cfg_nodes_map[iter];
      assert(taken_nodes);

      // Check if the node does not exists in the collected set
      if(taken_nodes->find(cfg_node) == taken_nodes->end()) 
        {
          // If no iteration includes the current node we should
          // create a new <> range covering all iterations
          if(range_min == 1) 
            {
              
              // Create the callstring:entry:<>:#bb=0 flow fact
              CExpressionFlowGraphNode *id = new CExpressionFlowGraphNode(cfg_node);
              CExpressionInt *eint = new CExpressionInt(0);
              CConstraint * constr = new CConstraint(id, RELOP_EQ, eint);
              CFFCollector * coll = new CFFCollector(FOR_EACH);
              CContextSensitiveValidAtEntryOfFlowFact * ff = 
                new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, coll, constr, CFlowFact::INSE);
              
              // Add the flow fact to the vector 
              ffs->push_back(ff);
            
              // Remember that we have added a flow fact
              nr_of_added_flow_facts++;
              
            }
          else
            {
              // If the range covers just one iteration make min_iter
              // equal to the current iteration
              if(range_min == 0)
                range_min = iter;

              // If the range covers just one iteration and we only
              // have an exit edge to the outer scopes we should not
              // generate any flow fact.
              if((range_min == iter) && (nr_exit_edges_to_outer_scopes == 1)) continue;
            
              // Else, create a callstring:entry:<min..max>:#bb=0 flow fact
              // CExpressionId *id = new CExpressionId(bb_name);
              CExpressionFlowGraphNode *id = new CExpressionFlowGraphNode(cfg_node);
              CExpressionInt *eint = new CExpressionInt(0);
              CConstraint * constr = new CConstraint(id, RELOP_EQ, eint);
              CIndexRange * range = new CIndexRange(range_min, iter);
              CFFCollector * coll = new CFFCollector(FOR_EACH, range);
              CContextSensitiveValidAtEntryOfFlowFact * ff = 
                new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, coll, constr, CFlowFact::INSE);
              
              // Add the flow fact to the vector 
              ffs->push_back(ff);
              
              // Remember that we have added a flow fact
              nr_of_added_flow_facts++;
            }
        }
      else
        {
          // The node existed in the set, check if the min range
          // != 0, i.e., the node has not been taken in previous
          // iterations
          if(range_min > 0)
            {
              // Create a callstring:entry:<min..iter-1>:#bb=0 flow fact
              // CExpressionId *id = new CExpressionId(bb_name);
              CExpressionFlowGraphNode *id = new CExpressionFlowGraphNode(cfg_node);
              CExpressionInt *eint = new CExpressionInt(0);
              CConstraint * constr = new CConstraint(id, RELOP_EQ, eint);
              CIndexRange * range = new CIndexRange(range_min, iter-1);
              CFFCollector * coll = new CFFCollector(FOR_EACH, range);
              
              CContextSensitiveValidAtEntryOfFlowFact * ff = 
                new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, coll, constr, CFlowFact::INSE);
              
              // Add the flow fact to the vector 
              ffs->push_back(ff);
              
              // Remember that we have added a flow fact
              nr_of_added_flow_facts++;
            }
        }
    
    } // end for all ecfg nodes
  
  } // end if

  // -------------------------------------------------------
  // Third, delete temporaries 
  // -------------------------------------------------------
  for(std::map<int,std::set<CFlowGraphNode *> *>::iterator i2cfgns = iter_to_taken_cfg_nodes_map.begin();
      i2cfgns != iter_to_taken_cfg_nodes_map.end(); ++i2cfgns) {
    delete (*i2cfgns).second;
  }
  
  // Return the number of flow facts added
  return nr_of_added_flow_facts;
}

// ---------------------------------
// For printing the collector
// ---------------------------------
void
CEachIterNodeCountCollector::
Print(ostream * o)
{
  (*o) << "scope: " << _scope->Name() << endl;

  // Loop through the iterations reported
  int iter = 0;
  for(iter = 1; iter < _max_iter_stored; iter++)
    {
      // Print the current iteration number
      (*o) << "  " << iter << ": ";

      // Get the set of taken nodes for the current iteration
      set<CECFGNode *> * taken_nodes = _iter_to_taken_nodes[iter];
      assert(taken_nodes);

      // Loop through all nodes and print them
      set<CECFGNode *>::iterator node;
      FORALL(node, (*taken_nodes))
        {
          (*o) << (*node) << " ";
        }
      (*o) << endl;
    }
}
