#ifndef AESTRATEGY_H_INCLUDED
#define AESTRATEGY_H_INCLUDED

#include <vector>
#include <list>
#include <map>
#include <memory>
#include <stack>
#include <stdexcept>

class CECFGNode;
class MergePointsHolder;

/** Unordered collection of states */
template <typename MergeableState>
class MergeableStateColl : private std::vector<MergeableState *>
{
private:
   typedef MergeableStateColl<MergeableState> ThisClass;

public:
   typedef typename std::vector<MergeableState *>::size_type SizeType;

   /** Delete all states in the collection */
   ~MergeableStateColl();

   /** @return @p true if the collection is empty, @p false otherwise */
   bool Empty() const {return std::vector<MergeableState *>::empty();}

   /** @return The number of states in this collection */
   SizeType Size() const {return std::vector<MergeableState *>::size();}

   /** Insert the state @a state into the collection */
   void Insert(std::unique_ptr<MergeableState> state);

   /** Insert the states in @a states into this collection. @a states is empty
       after the call */
   void Insert(MergeableStateColl & states);

   /** Remove a random state from the collection and return it */
   std::unique_ptr<MergeableState> RemoveRandom();

   /** Get pointers to the contained states. The states may not be modified or
       deleted, and are still owned by this collection. */
   void GetStates(std::vector<const MergeableState *> & states) const;
};

template <typename MergeableState>
class AEStrategyDebugger
{
public:
   virtual void RecordPerformedMerge(const MergeableState & a, const MergeableState & b,
                                     const MergeableState & merged) = 0;
};

template <typename MergeableState>
class SilentAEStrategyDebugger : public AEStrategyDebugger<MergeableState>
{
public:
   virtual void RecordPerformedMerge(const MergeableState & a, const MergeableState & b,
                                     const MergeableState & merged) {}
};

/** Strategy for choosing which states to execute, which states to merge, etc.\ 
    during abstract execution. Publicly, it appears as a "container" from which
    repeatedly a "next state to execute" is fetched, and then the states resulting
    from executing one or more program statements in the state are inserted back into
    the container. All maintenance of active/waiting states and merging is hidden away
    inside the implementing subclass.
    See, e.g., Gustafsson, Jan and Ermedahl, Andreas. "Merging Techniques for Faster Derivation of
    WCET Flow Information using Abstract Execution". WCET'08, 2008. */
template <typename MergeableState>
class AEStrategy
{
public:
   virtual ~AEStrategy() {}

   /** Set the AE strategy debugger to use */
   virtual void AttachDebugger(AEStrategyDebugger<MergeableState> & debugger) = 0;

   /** @return @p true if there are more states to execute, @p false otherwise
               (which means that the abstract execution can terminate) */
   virtual bool MoreStatesToExecute() const = 0;

   /** Get the next state that should be executed according to the strategy.
       The state is removed from the container. */
   virtual std::unique_ptr<MergeableState> GetNextStateToExecute() = 0;

   /** Insert a set of states (@a states), resulting from executing the statement
       in the ECFG node @a from_node, into the container */
   virtual void InsertStates(const CECFGNode & from_node,
      MergeableStateColl<MergeableState> & states) = 0;

   /** Insert all active states into @a active_states and all states waiting at merge
       points into @a waiting_states. The returned states may not be deleted or modified,
       and are still owned by this AEStrategy. */
   virtual void GetStates(std::vector<const MergeableState *> & active_states,
                          std::vector<const MergeableState *> & waiting_states) const = 0;

   /** Get a pointer to the state identified by @a name, or a null pointer if the strategy
       holds no such state. It is assumed that all states have unique names. 
       @note The returned state may not be modified or deleted, and is still owned by this
             strategy */
   virtual const MergeableState * GetStateByName(const std::string & name) const = 0;

protected:
   AEStrategy();
};

/** AE strategy that makes sure only a single state exists at any time during the abstract execution,
   i.e., that the analyzed program is a single-path program. Throws a MoreThanOneState exception if 
   this condition is violated. */
template <typename MergeableState>
class SinglePathAEStrategy : public AEStrategy<MergeableState>
{
private:
   std::unique_ptr<MergeableState> single_state;

public:
   class MoreThanOneState : public std::runtime_error 
   {
   public:
      MoreThanOneState() : std::runtime_error("") {}
   };

   SinglePathAEStrategy(std::unique_ptr<MergeableState> initial_state)
      : single_state(std::move(initial_state)) {}

   /** Set the AE strategy debugger to use */
   void AttachDebugger(AEStrategyDebugger<MergeableState> & debugger) {}

   /** @return @p true if there are more states to execute, @p false otherwise
               (which means that the abstract execution can terminate) */
   virtual bool MoreStatesToExecute() const {return single_state.get() != 0;}

   /** Get the next state that should be executed according to the strategy.
       The state is removed from the container. */
   virtual std::unique_ptr<MergeableState> GetNextStateToExecute();

   /** Insert a set of states (@a states), resulting from executing the statement
       in the ECFG node @a from_node, into the container */
   virtual void InsertStates(const CECFGNode & from_node,
      MergeableStateColl<MergeableState> & states);

   /** Insert all active states into @a active_states and all states waiting at merge
       points into @a waiting_states. The returned states may not be deleted or modified,
       and are still owned by this AEStrategy. */
   virtual void GetStates(std::vector<const MergeableState *> & active_states,
                          std::vector<const MergeableState *> & waiting_states) const;

   /** Get a pointer to the state identified by @a name, or a null pointer if the strategy
       holds no such state. It is assumed that all states have unique names. 
       @note The returned state may not be modified or deleted, and is still owned by this
             strategy */
   virtual const MergeableState * GetStateByName(const std::string & name) const;
};

/** Superclass for AE strategies which decouple the strategy with which active
    states (states not standing at merge points) are fetched and the strategy 
    with which states are merged. This makes it easy to combine fetch and merge strategies
    arbitrarily. The template argument @a FetchStrategyT should be a class implementing
    the interface FetchStrategy, and the template argument @a AEMergeStrategyT should
    be a class implementing the interface AEMergeStrategy. The combined strategy
    is as follows: as long as there are active states
    (FetchStrategyT::MoreStatesToExecute returns @p true), states are fetched from
    that set, but when there are no more active states, states are merged by a call
    to AEMergeStrategyT::MergeStates, and the merged states then become active
    states. MoreStatesToExecute will return @p false when there are neither active
    states or states standing at merge points left. */
template <typename MergeableState, 
          typename FetchStrategyT,
          typename AEMergeStrategyT>
class DecoupledFetchAndMergeStrategies : public AEStrategy<MergeableState>
{
public:
   /** Set the AE strategy debugger to use */
   void AttachDebugger(AEStrategyDebugger<MergeableState> & debugger);

   /** @return @p true if there are more states to execute, @p false otherwise
               (which means that the abstract execution can terminate) */
   virtual bool MoreStatesToExecute() const;

      /** Get the next state that should be executed according to the strategy */
   virtual std::unique_ptr<MergeableState> GetNextStateToExecute();

   /** Insert a set of states (@a states), resulting from executing the statement
       in the ECFG node @a from_node, into the container */
   virtual void InsertStates(const CECFGNode & from_node, MergeableStateColl<MergeableState> & states);

   /** Insert all active states into @a active_states and all states waiting at merge
       points into @a waiting_states. The returned states may not be deleted or modified,
       and are still owned by this AEStrategy. */
   virtual void GetStates(std::vector<const MergeableState *> & active_states,
                          std::vector<const MergeableState *> & waiting_states) const;

   /** Get a pointer to the state identified by @a name, or a null pointer if the strategy
       holds no such state. It is assumed that all states have unique names. 
       @note The returned state may not be modified or deleted, and is still owned by this
             strategy */
   virtual const MergeableState * GetStateByName(const std::string & name) const;

protected:
   DecoupledFetchAndMergeStrategies(const MergePointsHolder & merge_points_holder,
      FetchStrategyT & fetch_strategy, AEMergeStrategyT & merge_strategy);

   virtual ~DecoupledFetchAndMergeStrategies() {}

private:
   const MergePointsHolder & merge_points_holder;

   /** Reference to the fetch strategy, which is provided by the subclass */
   FetchStrategyT & fetch_strategy;

   /** Reference to the merge strategy, which is provided by the subclass */
   AEMergeStrategyT & merge_strategy;

   /** Get the MergePointsHolder to be able to classify states as standing at
       merge points or not standing at merge points */
   const MergePointsHolder & GetMergePointsHolder() const {return merge_points_holder;}
};

/** Interface for classes implementing strategies for fetching active states
    (states not standing at merge points). Publicly, it appears as a "container" which
    states can be inserted into and fetched from. The actual "strategy" is the
    order in which states are fetched in relation to the order in which they are
    inserted, FIFO (First-In-First-Out) and LIFO (Last-In-First-Out)
    being typical examples. */
template <typename MergeableState>
class FetchStrategy
{
public:
   /** @return @p true if the container holds more than 0 states, @p false otherwise */
   virtual bool MoreStatesToExecute() const = 0;

   /** Fetch the next state to execute. The state is removed from the container. */
   virtual std::unique_ptr<MergeableState> GetNextStateToExecute() = 0;

   /** Insert the state @a state into the container */
   virtual void InsertState(std::unique_ptr<MergeableState> state) = 0;

   /** Insert the states @a states_to_insert into the container. Is a bit more efficient
       than InsertState when a whole set of states are inserted. */
   virtual void InsertStates(MergeableStateColl<MergeableState> & states_to_insert) = 0;

   /** Get pointers to current states. The states may not be deleted or modified, and
       are still owned by this FetchStrategy */
   virtual void GetStates(std::vector<const MergeableState *> & states) const = 0;

   /** Get a pointer to the state identified by @a name, or a null pointer if the strategy
       holds no such state. It is assumed that all states have unique names. 
       @note The returned state may not be modified or deleted, and is still owned by this
             strategy */
   virtual const MergeableState * GetStateByName(const std::string & name) const;

protected:
   FetchStrategy() {}

   virtual ~FetchStrategy() {}
};

/** Interface for classes implementing strategies for merging states during
    abstract execution. Publicly, it appears as a "container" which states can be
    inserted into and removed from. */
template <typename MergeableState>
class AEMergeStrategy
{
public:
   /** Set the AE strategy debugger to use */
   void AttachDebugger(AEStrategyDebugger<MergeableState> & debugger);

   /** @return @p true if the container holds more than 0 states, @p false otherwise */
   virtual bool StatesToMerge() const = 0;

   /** Insert the state @a state into the container */
   virtual void InsertState(std::unique_ptr<MergeableState> state) = 0;

   /** Merge states held by the container and put the resulting states into
       @a merged_states */
   virtual void MergeStates(MergeableStateColl<MergeableState> & merged_states) = 0;

   /** Get pointers to current states. The states may not be deleted or modified, and
       are still owned by this AEMergeStrategy */
   virtual void GetStates(std::vector<const MergeableState *> & states) const = 0;

   /** Get a pointer to the state identified by @a name, or a null pointer if the strategy
       holds no such state. It is assumed that all states have unique names. 
       @note The returned state may not be modified or deleted, and is still owned by this
             strategy */
   virtual const MergeableState * GetStateByName(const std::string & name) const;

protected:
   AEStrategyDebugger<MergeableState> * debugger;

   static SilentAEStrategyDebugger<MergeableState> silent_debugger;

   AEMergeStrategy() : debugger(&silent_debugger) {}

   virtual ~AEMergeStrategy() {}
};

/** LIFO (Last-In-First-Out) strategy for fetching active states */
template <typename MergeableState>
class DepthFirstFetchStrategy : public FetchStrategy<MergeableState>
{
public:
   virtual ~DepthFirstFetchStrategy();

   /** @return @p true if the container holds more than 0 states, @p false otherwise */
   virtual bool MoreStatesToExecute() const {return !states.empty();}

   /** Fetch the next state to execute. The state is removed from the container. */
   virtual std::unique_ptr<MergeableState> GetNextStateToExecute();

   /** Insert the state @a state into the container */
   virtual void InsertState(std::unique_ptr<MergeableState> state) {states.push(state.release());}

   /** Insert the states @a states_to_insert into the container. Is a bit more efficient
       than InsertState when a whole set of states are inserted. */
   virtual void InsertStates(MergeableStateColl<MergeableState> & states_to_insert);

   /** Get pointers to current states. The states may not be deleted or modified, and
       are still owned by this FetchStrategy */
   virtual void GetStates(std::vector<const MergeableState *> & states) const;

private:
   std::stack<MergeableState *> states;
};

/** "Empty" merge strategy, which means that states are not merged at all. A call
    to MergeStates just gives back the states that where given to it without any
    change. */
template <typename MergeableState>
class EmptyMergeStrategy : public AEMergeStrategy<MergeableState>
{
public:
   /** @return @p true if the container holds more than 0 states, @p false otherwise */
   virtual bool StatesToMerge() const {return !states.Empty();}

   /** Insert the state @a state into the container */
   virtual void InsertState(std::unique_ptr<MergeableState> state);

   /** Put the states held by the container into @a merged_states */
   virtual void MergeStates(MergeableStateColl<MergeableState> & merged_states);

   /** Get pointers to current states. The states may not be deleted or modified, and
       are still owned by this AEMergeStrategy */
   virtual void GetStates(std::vector<const MergeableState *> & states) const;

private:
   MergeableStateColl<MergeableState> states;
};

/** AE strategy which combines DepthFirstFetchStrategy and EmptyMergeStrategy */
template <typename MergeableState>
class DepthFirstNoMergeAEStrategy
   : public DecoupledFetchAndMergeStrategies<MergeableState, 
   DepthFirstFetchStrategy<MergeableState>, EmptyMergeStrategy<MergeableState> >
{
public:
   DepthFirstNoMergeAEStrategy(const MergePointsHolder & merge_points_holder,
                               std::unique_ptr<MergeableState> start_state);

private:
   /** Depth-first fetch strategy */
   DepthFirstFetchStrategy<MergeableState> df_fetch_strategy;

   /** Empty merge strategy */
   EmptyMergeStrategy<MergeableState> empty_merge_strategy;
};

/** Superclass for classes implementing "non-empty" merge strategies. Has some
    useful default implementations for organizing states according to the
    merge points they are standing at. */
template <typename MergeableState>
class NonEmptyMergeStrategy : public AEMergeStrategy<MergeableState>
{
public:
   /** @return @p true if the container holds more than 0 states, @p false otherwise */
   virtual bool StatesToMerge() const;

   /** Insert the state @a state into the container */
   virtual void InsertState(std::unique_ptr<MergeableState> state);

   /** Get pointers to current states. The states may not be deleted or modified, and
       are still owned by this NonEmptyMergeStrategy */
   virtual void GetStates(std::vector<const MergeableState *> & states) const;

protected:
   typedef std::list<MergeableState *> OrderedStateColl;
   typedef std::map<CECFGNode *, OrderedStateColl *> MergePointsToStates;

   /** Maps merge points (identified by pointers to ECFG nodes) to collections of
       states standing at those merge points */
   MergePointsToStates merge_points_to_states;

   NonEmptyMergeStrategy() {}

   virtual ~NonEmptyMergeStrategy();
};

/** Unordered merge strategy, which means that all states are merged with the other
    states at the same merge point and are released (become active) in parallel */
template <typename MergeableState>
class UnorderedAEMergeStrategy : public NonEmptyMergeStrategy<MergeableState>
{
public:
   /** All states held by the container are merged with all other states standing
       at the same merge point, and the resulting states are then inserted into
       @a merged_states. The container is empty after the call. */
   void MergeStates(MergeableStateColl<MergeableState> & merged_states);
};

/** AE strategy which combines DepthFirstFetchStrategy and UnorderedAEMergeStrategy */
template <typename MergeableState>
class DepthFirstUnorderedMergeAEStrategy 
   : public DecoupledFetchAndMergeStrategies<MergeableState, 
   DepthFirstFetchStrategy<MergeableState>, UnorderedAEMergeStrategy<MergeableState> >
{
public:
   DepthFirstUnorderedMergeAEStrategy(const MergePointsHolder & merge_points_holder,
                                      std::unique_ptr<MergeableState> start_state);

private:
   /** Depth-first fetch strategy */
   DepthFirstFetchStrategy<MergeableState> dp_fetch_strategy;

   /* Unordered merge strategy */
   UnorderedAEMergeStrategy<MergeableState> unordered_ms;
};

#endif   // #ifndef AESTRATEGY_H_INCLUDED
