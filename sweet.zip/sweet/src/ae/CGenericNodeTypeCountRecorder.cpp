/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: $
//
// ----------------------------------------------------------------------

#include "ae/CGenericNodeTypeCountRecorder.h"
#include "ae/CGenericNodeTypeCountCollector.h"
#include "macros.h" 
#include "program/CGenericStmt.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "program/alf/CAlfTreeFilter.h"

using namespace std;
using namespace alf;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CGenericNodeTypeCountRecorder
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of recorder
//----------------------------------
CGenericNodeTypeCountRecorder::
CGenericNodeTypeCountRecorder(bool record_generic_nodes, bool record_op_types, 
                              bool record_stmts, bool record_stmt_pairs)
  : _record_generic_nodes(record_generic_nodes), _record_op_types(record_op_types), 
    _record_stmts(record_stmts), _record_stmt_pairs(record_stmt_pairs)
{
  // Do nothing
}

//----------------------------------
// Deletion of recorder
//----------------------------------
CGenericNodeTypeCountRecorder::
~CGenericNodeTypeCountRecorder()
{
  {
    // Go through the type to range map deleting all the ranges
    map<CGenericNode::TYPE, CIntegerRange*>::iterator t2r;
    FORALL(t2r, _type_to_range_map) {
      delete (*t2r).second;
    }
  }
  {
    // Go through the op type to range map deleting all the ranges
    map<COpNumExprTuple::OP_TYPE, CIntegerRange*>::iterator ot2r;
    FORALL(ot2r, _op_type_to_range_map) {
      delete (*ot2r).second;
    }
  }

  {
    // Go through the map deleting all the ranges of stmt types
    std::map<CGenericStmt::GS_TYPE, CIntegerRange*>::iterator s2r;
    FORALL(s2r, _stmt_to_range_map)
      delete (*s2r).second;
  } 

  {
    // Go through the map deleting all the ranges of stmt pair types
    std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*>::iterator sp2r;
    FORALL(sp2r, _stmt_pair_to_range_map)
      delete (*sp2r).second;
  } 

}

void
CGenericNodeTypeCountRecorder::
UpdateWithProgramCounterChange(CECFGNode * pc_before, CECFGNode * pc_after)
{
  // Get the statement of the pc_before node
  CGenericStmt * stmt = pc_before->GetFlowGraphNode()->Stmt();

  // Call recursive function which travsere the statement and count
  // occurences of each type
  if(_record_generic_nodes || _record_op_types)
    TraverseRecursivelyAndCountTypeOccurrences(stmt);
  
  // If we should record statements
  if(_record_stmts) {
    IncreaseCount(stmt->Type());
  }  

  // If we should record stmt pairs
  if(_record_stmt_pairs) {
    CGenericStmt * stmt_after = pc_after->GetFlowGraphNode()->Stmt();
    IncreaseCount(make_pair(stmt->Type(), stmt_after->Type()));
  }
}

void
CGenericNodeTypeCountRecorder::
UpdateWithProgramExit(CECFGNode * pc_before)
{
  // Get the statement of the pc_before node
  CGenericStmt * stmt = pc_before->GetFlowGraphNode()->Stmt();

  // Call recursive function which travsere the statement and count
  // occurences of each type
  TraverseRecursivelyAndCountTypeOccurrences(stmt);

  // If we should record statements
  if(_record_stmts) 
    IncreaseCount(stmt->Type());
}
  
// //----------------------------------
// // Report the current ranges to the collector.
// //---------------------------------
// void
// CGenericNodeTypeCountRecorder::
// ReportToCollector(CGenericNodeTypeCountCollector * collector)
// {
//   // Report the current mapping to collector
//   if(_record_generic_nodes) collector->Update(&_type_to_range_map);
//   if(_record_op_types) collector->Update(&_op_type_to_range_map);
//   if(_record_stmts) collector->Update(&_stmt_to_range_map); 
//   if(_record_stmt_pairs) collector->Update(&_stmt_pair_to_range_map); 
// }
 
//----------------------------------
// Reset the recorder
//---------------------------------
void
CGenericNodeTypeCountRecorder::
Reset()
{
  {
    // Delete all the generic node ranges
    map<CGenericNode::TYPE, CIntegerRange*>::iterator t2r;
    FORALL(t2r, _type_to_range_map)
      delete (*t2r).second;
    
    // Remove all the mappings
    _type_to_range_map.erase(_type_to_range_map.begin(), _type_to_range_map.end());
  }

  {
    // Delete all the op type ranges
    map<COpNumExprTuple::OP_TYPE, CIntegerRange*>::iterator ot2r;
    FORALL(ot2r, _op_type_to_range_map)
      delete (*ot2r).second;
    
    // Remove all the mappings
    _op_type_to_range_map.erase(_op_type_to_range_map.begin(), _op_type_to_range_map.end());
  }

  {
    // Delete all the stmt ranges
    std::map<CGenericStmt::GS_TYPE, CIntegerRange*>::iterator s2r;
    FORALL(s2r, _stmt_to_range_map)
      delete (*s2r).second;

    // Remove all the mappings
    _stmt_to_range_map.erase(_stmt_to_range_map.begin(), _stmt_to_range_map.end());

  } 

  {
    // Delete all the stmt pair ranges
    std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*>::iterator sp2r;
    FORALL(sp2r, _stmt_pair_to_range_map)
      delete (*sp2r).second;

    // Remove all the mappings
    _stmt_pair_to_range_map.erase(_stmt_pair_to_range_map.begin(), _stmt_pair_to_range_map.end());
  } 

}

//----------------------------------
// Copy the recorder
//---------------------------------
CGenericNodeTypeCountRecorder *
CGenericNodeTypeCountRecorder::
Copy()
{
  // Create a new recorder
  CGenericNodeTypeCountRecorder * new_recorder = 
    new CGenericNodeTypeCountRecorder(_record_generic_nodes, _record_op_types,
                                      _record_stmts, _record_stmt_pairs);

  {
    // Copy all the type to range mappings 
    map<CGenericNode::TYPE, CIntegerRange*>::iterator t2r;
    FORALL(t2r, _type_to_range_map)
      {
        CGenericNode::TYPE type = (*t2r).first;
        CIntegerRange* range = (*t2r).second;
        CIntegerRange* new_range = range->Copy();
        new_recorder->_type_to_range_map[type] = new_range;
      }
  }

  {
    // Copy all the op_type to range mappings 
    map<COpNumExprTuple::OP_TYPE, CIntegerRange*>::iterator ot2r;
    FORALL(ot2r, _op_type_to_range_map)
      {
        COpNumExprTuple::OP_TYPE op_type = (*ot2r).first;
        CIntegerRange* range = (*ot2r).second;
        CIntegerRange* new_range = range->Copy();
        new_recorder->_op_type_to_range_map[op_type] = new_range;
      }
  }

  {
    // Copy all the stmt to range mappings 
    map<CGenericStmt::GS_TYPE, CIntegerRange*>::iterator s2r;
    FORALL(s2r, _stmt_to_range_map)
      {
        CGenericStmt::GS_TYPE stmt = (*s2r).first;
        CIntegerRange* range = (*s2r).second;
        CIntegerRange* new_range = range->Copy();
        new_recorder->_stmt_to_range_map[stmt] = new_range;
      }
  }

  {
    // Copy all the stmt pair to range mappings 
    std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*>::iterator sp2r;
    FORALL(sp2r, _stmt_pair_to_range_map)
      {
        std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE> stmt_pair = (*sp2r).first;
        CIntegerRange* range = (*sp2r).second;
        CIntegerRange* new_range = range->Copy();
        new_recorder->_stmt_pair_to_range_map[stmt_pair] = new_range;
      }
  }


  // We are done, the range map has been copied to the new recorder
  return new_recorder;
}

//----------------------------------
// Merge two recorders
//---------------------------------
CGenericNodeTypeCountRecorder *
CGenericNodeTypeCountRecorder::
Merge(CGenericNodeTypeCountRecorder * other_recorder)
{
  // Create a new recorder with the same collector
  CGenericNodeTypeCountRecorder * new_recorder = other_recorder->Copy();

  // -------------------------------------------------------
  // Merge type to range mappings
  // -------------------------------------------------------
  if(_record_generic_nodes)
  {
    // A set to keep track of processed types
    set<CGenericNode::TYPE> processed_types;

    // Go through all the to range mappings in the current
    // recorder and the argument recorder and remember all the nodes
    // mappings
    map<CGenericNode::TYPE, CIntegerRange*>::iterator t2r;
    FORALL(t2r, _type_to_range_map)
      {
        CGenericNode::TYPE type = (*t2r).first;
        CIntegerRange* range = (*t2r).second;
        
        // Check if the new recorder has a range for the type
        if(new_recorder->_type_to_range_map.find(type) ==
           new_recorder->_type_to_range_map.end()) {
          
          // No range, this means that the type has not been
          // taken in the other state
          
          // Create a [0..0] range
          CIntegerRange* zero_range = new CIntegerRange(0,0);
          
          // Merge the current range with the zero range
          CIntegerRange* new_range = range->Merge(zero_range);
          
          // Delete the temporary range
          delete zero_range;
          
          // Add the new range to the recorder for the type (prev_range
          // will be deleted)
          new_recorder->SetRange(type, new_range);
        }
        else {
          // Merge ranges (prev_range will be deleted)
          CIntegerRange* prev_range = new_recorder->_type_to_range_map[type];
          new_recorder->SetRange(type, range->Merge(prev_range));
        }
        // Add the type to the set of processed types
        processed_types.insert(type);
      }
    
    // Go through the second recorder mapping
    FORALL(t2r, other_recorder->_type_to_range_map)
      {
        // Get the type
        CGenericNode::TYPE type = (*t2r).first;
        
        // Check if the type already has been processed
        if(processed_types.find(type) != processed_types.end())
          continue;
        
        // We have a type that only exists in the second set.  This
        // means that the type has not been taken in the other state
        
        // Get the range
        CIntegerRange* range = (*t2r).second;
        
        // Create a [0..0] range
        CIntegerRange* zero_range = new CIntegerRange(0,0);
        
        // Merge the current range with the zero range
        CIntegerRange* new_range = range->Merge(zero_range);
        
        // Delete the temporary range
        delete zero_range;
        
        // Add the new range to the recorder for the type (prev_range
        // will be deleted)
        new_recorder->SetRange(type, new_range);
      }
  }

  // -------------------------------------------------------
  // Merge op type to range mappings
  // -------------------------------------------------------
  if(_record_op_types)
  {
    // A set to keep track of processed types
    set<COpNumExprTuple::OP_TYPE> processed_op_types;

    // Go through all the to range mappings in the current
    // recorder and the argument recorder and remember all the nodes
    // mappings
    map<COpNumExprTuple::OP_TYPE, CIntegerRange*>::iterator ot2r;
    FORALL(ot2r, _op_type_to_range_map)
      {
        COpNumExprTuple::OP_TYPE op_type = (*ot2r).first;
        CIntegerRange* range = (*ot2r).second;
        
        // Check if the new recorder has a range for the type
        if(new_recorder->_op_type_to_range_map.find(op_type) ==
           new_recorder->_op_type_to_range_map.end()) {
          
          // No range, this means that the type has not been
          // taken in the other state
          
          // Create a [0..0] range
          CIntegerRange* zero_range = new CIntegerRange(0,0);

          // Merge the current range with the zero range
          CIntegerRange* new_range = range->Merge(zero_range);
          
          // Delete the temporary range
          delete zero_range;
          
          // Add the new range to the recorder for the type (prev_range
          // will be deleted)
          new_recorder->SetRange(op_type, new_range);
        }
        else {
        // Merge ranges (prev_range will be deleted)
          CIntegerRange* prev_range = new_recorder->_op_type_to_range_map[op_type];
          new_recorder->SetRange(op_type, range->Merge(prev_range));
        }
        // Add the type to the set of processed types
      processed_op_types.insert(op_type);
      }
    
    // Go through the second recorder mapping
    FORALL(ot2r, other_recorder->_op_type_to_range_map)
      {
        // Get the type
        COpNumExprTuple::OP_TYPE op_type = (*ot2r).first;
        
        // Check if the type already has been processed
        if(processed_op_types.find(op_type) != processed_op_types.end())
          continue;
        
        // We have a type that only exists in the second set.  This
        // means that the type has not been taken in the other state
        
        // Get the range
        CIntegerRange* range = (*ot2r).second;
        
        // Create a [0..0] range
        CIntegerRange* zero_range = new CIntegerRange(0,0);
        
        // Merge the current range with the zero range
        CIntegerRange* new_range = range->Merge(zero_range);
        
        // Delete the temporary range
        delete zero_range;
        
        // Add the new range to the recorder for the type (prev_range
        // will be deleted)
        new_recorder->SetRange(op_type, new_range);
      }
  }

  // -------------------------------------------------------
  // Merge stmt to range mappings
  // -------------------------------------------------------
  if(_record_stmts)
  {
    // A set to keep track of processed types
    set<CGenericStmt::GS_TYPE> processed_stmts;

    // Go through all the to range mappings in the current
    // recorder and the argument recorder and remember all the nodes
    // mappings
    map<CGenericStmt::GS_TYPE, CIntegerRange*>::iterator ot2r;
    FORALL(ot2r, _stmt_to_range_map)
      {
        CGenericStmt::GS_TYPE stmt = (*ot2r).first;
        CIntegerRange* range = (*ot2r).second;
        
        // Check if the new recorder has a range for the type
        if(new_recorder->_stmt_to_range_map.find(stmt) ==
           new_recorder->_stmt_to_range_map.end()) {
          
          // No range, this means that the type has not been
          // taken in the other state
          
          // Create a [0..0] range
          CIntegerRange* zero_range = new CIntegerRange(0,0);
          
          // Merge the current range with the zero range
          CIntegerRange* new_range = range->Merge(zero_range);
          
          // Delete the temporary range
          delete zero_range;
          
          // Add the new range to the recorder for the type (prev_range
          // will be deleted)
          new_recorder->SetRange(stmt, new_range);
        }
        else {
          // Merge ranges (prev_range will be deleted)
          CIntegerRange* prev_range = new_recorder->_stmt_to_range_map[stmt];
          new_recorder->SetRange(stmt, range->Merge(prev_range));
        }
        // Add the type to the set of processed types
        processed_stmts.insert(stmt);
      }
    
    // Go through the second recorder mapping
    FORALL(ot2r, other_recorder->_stmt_to_range_map)
      {
        // Get the type
        CGenericStmt::GS_TYPE stmt = (*ot2r).first;
        
        // Check if the type already has been processed
        if(processed_stmts.find(stmt) != processed_stmts.end())
          continue;
        
        // We have a type that only exists in the second set.  This
        // means that the type has not been taken in the other state
        
        // Get the range
        CIntegerRange* range = (*ot2r).second;
        
        // Create a [0..0] range
        CIntegerRange* zero_range = new CIntegerRange(0,0);
        
        // Merge the current range with the zero range
        CIntegerRange* new_range = range->Merge(zero_range);
        
        // Delete the temporary range
        delete zero_range;
        
        // Add the new range to the recorder for the type (prev_range
        // will be deleted)
        new_recorder->SetRange(stmt, new_range);
      }
  }

  // -------------------------------------------------------
  // Merge stmt pair to range mappings
  // -------------------------------------------------------
  if(_record_stmt_pairs)
  {
    // A set to keep track of processed types
    std::set<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE> > processed_stmt_pairs;

    // Go through all the to range mappings in the current
    // recorder and the argument recorder and remember all the nodes
    // mappings
    std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*>::iterator sp2r;
    FORALL(sp2r, _stmt_pair_to_range_map)
      {
        std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE> stmt_pair = (*sp2r).first;
        CIntegerRange* range = (*sp2r).second;
        
        // Check if the new recorder has a range for the type
        if(new_recorder->_stmt_pair_to_range_map.find(stmt_pair) ==
           new_recorder->_stmt_pair_to_range_map.end()) {
          
          // No range, this means that the type has not been
          // taken in the other state
          
          // Create a [0..0] range
          CIntegerRange* zero_range = new CIntegerRange(0,0);
          
          // Merge the current range with the zero range
          CIntegerRange* new_range = range->Merge(zero_range);
          
          // Delete the temporary range
          delete zero_range;
          
          // Add the new range to the recorder for the type (prev_range
          // will be deleted)
          new_recorder->SetRange(stmt_pair, new_range);
        }
        else {
          // Merge ranges (prev_range will be deleted)
          CIntegerRange* prev_range = new_recorder->_stmt_pair_to_range_map[stmt_pair];
          new_recorder->SetRange(stmt_pair, range->Merge(prev_range));
        }
        // Add the type to the set of processed types
        processed_stmt_pairs.insert(stmt_pair);
      }
    
    // Go through the second recorder mapping
    FORALL(sp2r, other_recorder->_stmt_pair_to_range_map)
      {
        // Get the type
        std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE> stmt_pair = (*sp2r).first;
        
        // Check if the type already has been processed
        if(processed_stmt_pairs.find(stmt_pair) != processed_stmt_pairs.end())
          continue;
        
        // We have a type that only exists in the second set.  This
        // means that the type has not been taken in the other state
        
        // Get the range
        CIntegerRange* range = (*sp2r).second;
        
        // Create a [0..0] range
        CIntegerRange* zero_range = new CIntegerRange(0,0);
        
        // Merge the current range with the zero range
        CIntegerRange* new_range = range->Merge(zero_range);
        
        // Delete the temporary range
        delete zero_range;
        
        // Add the new range to the recorder for the type (prev_range
        // will be deleted)
        new_recorder->SetRange(stmt_pair, new_range);
      }
  }

  // Return the new recorder
  return new_recorder;
}

//----------------------------------
// Merge two recorders
//---------------------------------
CRecorder *
CGenericNodeTypeCountRecorder::
Merge(CRecorder * other_recorder)
{
  return Merge(dynamic_cast<CGenericNodeTypeCountRecorder *>(other_recorder));
}

//---------------------------------
// For printing the recorder
//---------------------------------
void
CGenericNodeTypeCountRecorder::
Print(ostream * o)
{
  unsigned int index = 1;

  // Print type to range map
  if(_record_generic_nodes) {
    std::map<alf::CGenericNode::TYPE, CIntegerRange*>::iterator t2r;
    FORALL(t2r, _type_to_range_map)
      {
        alf::CGenericNode::TYPE type = (*t2r).first;
        CIntegerRange* range = (*t2r).second;
        string type_as_string = alf::CGenericNode::GetTypeAsString(type);
        if(range->L() == range->U())
          (*o) << "  " << index << " " << type_as_string << " = " << range->U() << endl;
        else
          (*o) << "  " << index << " " << type_as_string << " = " << (*range) << endl;
      }
  }

  // Print op type to range map
  if(_record_op_types) {
    std::map<alf::COpNumExprTuple::OP_TYPE, CIntegerRange*>::iterator ot2r;
    FORALL(ot2r, _op_type_to_range_map)
      {
        alf::COpNumExprTuple::OP_TYPE op_type = (*ot2r).first;
        CIntegerRange* range = (*ot2r).second;
        string op_type_as_string = alf::COpNumExprTuple::GetName(op_type);
        if(range->L() == range->U())
          (*o) << "  " << index << " TYPE_" << op_type_as_string << " = " << range->U() << endl;
        else
          (*o) << "  " << index << " TYPE_" << op_type_as_string << " = " << (*range) << endl;
      }
  }
  
  // Print stmt to range map
  if(_record_stmts) {
    std::map<CGenericStmt::GS_TYPE, CIntegerRange*>::iterator s2r;
    FORALL(s2r, _stmt_to_range_map)
      {
        CGenericStmt::GS_TYPE stmt = (*s2r).first;
        CIntegerRange* range = (*s2r).second;
        string stmt_as_string = CGenericStmt::GetName(stmt);
        if(range->L() == range->U())
          (*o) << "  " << index << " TYPE_" << stmt_as_string << " = " << range->U() << endl;
        else
          (*o) << "  " << index << " TYPE_" << stmt_as_string << " = " << (*range) << endl;
      }
  }

  // Print stmt pairs to range map
  if(_record_stmt_pairs) {
    std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*>::iterator sp2r;
    FORALL(sp2r, _stmt_pair_to_range_map)
      {
        CGenericStmt::GS_TYPE stmt1 = (*sp2r).first.first;
        CGenericStmt::GS_TYPE stmt2 = (*sp2r).first.second;
        CIntegerRange* range = (*sp2r).second;
        string stmt1_as_string = CGenericStmt::GetName(stmt1);
        string stmt2_as_string = CGenericStmt::GetName(stmt2);
        if(range->L() == range->U())
          (*o) << "  " << index << " TYPE_" << stmt1_as_string << "__" << stmt2_as_string 
               << " = " << range->U() << endl;
        else
          (*o) << "  " << index << " TYPE_" << stmt1_as_string << "__" << stmt2_as_string 
               << " = " << (*range) << endl;
      }
  }  
  (*o) << endl;
}

//---------------------------------
// Alternative printing function
//---------------------------------
ostream &operator << (ostream &o, CGenericNodeTypeCountRecorder &a)
{
  a.Print(&o);
  return o;
}

//----------------------------------
// Help function to remember that we have processed a certain node type
//----------------------------------
void
CGenericNodeTypeCountRecorder::
IncreaseCount(CGenericNode::TYPE type)
{
  // Check if the type exists since before
  if(_type_to_range_map.find(type) == _type_to_range_map.end())
    {
      // Nope, add the range 1..1 to the map
      CIntegerRange* range = new CIntegerRange(1,1);
      _type_to_range_map[type] = range;
    }
  else
    {
      // Yes, add 1..1 to the old range value
      CIntegerRange* old_range =  _type_to_range_map[type];
      int64_t new_l = old_range->L() + 1;
      int64_t new_u = old_range->U() + 1;
      CIntegerRange* new_range = new CIntegerRange(new_l,new_u);
      delete old_range;
      _type_to_range_map[type] = new_range;
    }
}

void
CGenericNodeTypeCountRecorder::
SetRange(CGenericNode::TYPE type, CIntegerRange* range)
{
  // Check if the node exists since before
  if(_type_to_range_map.find(type) == _type_to_range_map.end())
    {
      // Nope, set the range
      _type_to_range_map[type] = range;
    }
  else
    {
      // Delete the old range
      delete _type_to_range_map[type];
      _type_to_range_map[type] = range;
    }
}

//----------------------------------
// Help function to remember that we have processed a certain node op type
//----------------------------------
void
CGenericNodeTypeCountRecorder::
IncreaseCount(COpNumExprTuple::OP_TYPE op_type)
{
  // Check if the type exists since before
  if(_op_type_to_range_map.find(op_type) == _op_type_to_range_map.end())
    {
      // Nope, add the range 1..1 to the map
      CIntegerRange* range = new CIntegerRange(1,1);
      _op_type_to_range_map[op_type] = range;
    }
  else
    {
      // Yes, add 1..1 to the old range value
      CIntegerRange* old_range =  _op_type_to_range_map[op_type];
      int64_t new_l = old_range->L() + 1;
      int64_t new_u = old_range->U() + 1;
      CIntegerRange* new_range = new CIntegerRange(new_l,new_u);
      delete old_range;
      _op_type_to_range_map[op_type] = new_range;
    }
}

void
CGenericNodeTypeCountRecorder::
SetRange(COpNumExprTuple::OP_TYPE op_type, CIntegerRange* range)
{
  // Check if the node exists since before
  if(_op_type_to_range_map.find(op_type) == _op_type_to_range_map.end())
    {
      // Nope, set the range
      _op_type_to_range_map[op_type] = range;
    }
  else
    {
      // Delete the old range
      delete _op_type_to_range_map[op_type];
      _op_type_to_range_map[op_type] = range;
    }
}

//----------------------------------
// Help function to remember that we have processed a certain stmt type
//----------------------------------
void
CGenericNodeTypeCountRecorder::
IncreaseCount(CGenericStmt::GS_TYPE stmt)
{ 
  // Check if the type exists since before
  if(_stmt_to_range_map.find(stmt) == _stmt_to_range_map.end())
    {
      // Nope, add the range 1..1 to the map
      CIntegerRange* range = new CIntegerRange(1,1);
      _stmt_to_range_map[stmt] = range;
    }
  else
    {
      // Yes, add 1..1 to the old range value
      CIntegerRange* old_range =  _stmt_to_range_map[stmt];
      int64_t new_l = old_range->L() + 1;
      int64_t new_u = old_range->U() + 1;
      CIntegerRange* new_range = new CIntegerRange(new_l,new_u);
      delete old_range;
      _stmt_to_range_map[stmt] = new_range;
    }
}

void
CGenericNodeTypeCountRecorder::
SetRange(CGenericStmt::GS_TYPE stmt, CIntegerRange* range)
{
  // Check if the node exists since before
  if(_stmt_to_range_map.find(stmt) == _stmt_to_range_map.end())
    {
      // Nope, set the range
      _stmt_to_range_map[stmt] = range;
    }
  else
    {
      // Delete the old range
      delete _stmt_to_range_map[stmt];
      _stmt_to_range_map[stmt] = range;
    }
}


//----------------------------------
// Help function to remember that we have processed a certain stmt type
//----------------------------------
void
CGenericNodeTypeCountRecorder::
IncreaseCount(std::pair<CGenericStmt::GS_TYPE,CGenericStmt::GS_TYPE> stmt_pair)
{ 
  // Check if the type exists since before
  if(_stmt_pair_to_range_map.find(stmt_pair) == _stmt_pair_to_range_map.end())
    {
      // Nope, add the range 1..1 to the map
      CIntegerRange* range = new CIntegerRange(1,1);
      _stmt_pair_to_range_map[stmt_pair] = range;
    }
  else
    {
      // Yes, add 1..1 to the old range value
      CIntegerRange* old_range =  _stmt_pair_to_range_map[stmt_pair];
      int64_t new_l = old_range->L() + 1;
      int64_t new_u = old_range->U() + 1;
      CIntegerRange* new_range = new CIntegerRange(new_l,new_u);
      delete old_range;
      _stmt_pair_to_range_map[stmt_pair] = new_range;
    }
}

void
CGenericNodeTypeCountRecorder::
SetRange(std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE> stmt_pair, CIntegerRange* range)
{
  // Check if the node exists since before
  if(_stmt_pair_to_range_map.find(stmt_pair) == _stmt_pair_to_range_map.end())
    {
      // Nope, set the range
      _stmt_pair_to_range_map[stmt_pair] = range;
    }
  else
    {
      // Delete the old range
      delete _stmt_pair_to_range_map[stmt_pair];
      _stmt_pair_to_range_map[stmt_pair] = range;
    }
}

//----------------------------------
// Help function to traverse a stmt and count of all types encountered
//----------------------------------
void
CGenericNodeTypeCountRecorder::
TraverseRecursivelyAndCountTypeOccurrences(const CGenericStmt *stmt)
{
  // Check if we should record all generic nodes
  if(_record_generic_nodes) {
    // Yes, extract all generic nodes in the statement 
    CAlfTreeFilter filter = CAlfTreeFilter(dynamic_cast<const CGenericNode*>(stmt));
    const CAlfTreeFilter::NodeList gen_nodes = filter.GetAllNodes();
    // Loop through all nodes and extract the operand
    for(CAlfTreeFilter::NodeList::const_iterator gen_node = gen_nodes.begin(); 
        gen_node != gen_nodes.end(); ++gen_node) {
      CGenericNode::TYPE t = (*gen_node)->GetNodeType();
      IncreaseCount(t);
    }
  }

  // Check if we should record operands 
  if(_record_op_types) {
    // Yes, extract all generaic nodes which are of operand types in the statement 
    CAlfTreeFilter filter = CAlfTreeFilter(dynamic_cast<const CGenericNode*>(stmt));
    const CAlfTreeFilter::NodeList gen_nodes = filter.GetNodesOfType(alf::CGenericNode::TYPE_OP_EXPR_TUPLE);
    // Loop through all nodes and extract the operand
    for(CAlfTreeFilter::NodeList::const_iterator gen_node = gen_nodes.begin(); 
        gen_node != gen_nodes.end(); ++gen_node) {
      const alf::COpNumExprTuple * op_num_expr_tuple = dynamic_cast<const alf::COpNumExprTuple *>(*gen_node);
      alf::COpNumExprTuple::OP_TYPE op = op_num_expr_tuple->GetOperator();
      // Increase the count for the operator
      IncreaseCount(op);
    }
  }
}
  

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CGenericNodeTypeCountRecorderServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//---------------------------------
// To create the server
//---------------------------------
CGenericNodeTypeCountRecorderServer::
CGenericNodeTypeCountRecorderServer(bool record_generic_nodes, bool record_op_types, 
                                    bool record_stmts, bool record_stmt_pairs)
  : _record_generic_nodes(record_generic_nodes), _record_op_types(record_op_types), 
    _record_stmts(record_stmts), _record_stmt_pairs(record_stmt_pairs)
{
  // Do nothing
}

//---------------------------------
// To create the recorder
//---------------------------------
CGenericNodeTypeCountRecorder *
CGenericNodeTypeCountRecorderServer::
CreateRecorder()
{
  // Create the recorder
  CGenericNodeTypeCountRecorder * recorder = 
    new CGenericNodeTypeCountRecorder(_record_generic_nodes, _record_op_types,
                                      _record_stmts, _record_stmt_pairs);

  // Remember that we have one reference to the recorder
  _recorder_to_refs[recorder] = 1;

  // Return the new recorder
  return recorder;
}

// -------------------------------------------------------
// To delete a certain recorder
// -------------------------------------------------------
void
CGenericNodeTypeCountRecorderServer::
DeleteRecorder(CGenericNodeTypeCountRecorder * recorder)
{
  assert(recorder);
  assert(_recorder_to_refs.find(recorder) != _recorder_to_refs.end());
  // Update map
  _recorder_to_refs[recorder] = _recorder_to_refs[recorder]-1;

  // Check if we have any refs left
  if(_recorder_to_refs[recorder] == 0)
    {
      // No, remove the recorder for real
      delete recorder;

      // Remove the mapping
      // _recorder_to_refs.erase(recorder);
    }
}

void
CGenericNodeTypeCountRecorderServer::
DeleteRecorder(CRecorder * recorder)
{
  // Call the more specialized version
  DeleteRecorder(dynamic_cast<CGenericNodeTypeCountRecorder*>(recorder));
}

// -------------------------------------------------------
// Copy the recorder
// -------------------------------------------------------
CRecorder *
CGenericNodeTypeCountRecorderServer::
CopyRecorder(CRecorder * recorder)
{
  assert(recorder);
  // Call the more specialized version
  return CopyRecorder(dynamic_cast<CGenericNodeTypeCountRecorder*>(recorder));
}

// -------------------------------------------------------
// Update the recorder
// -------------------------------------------------------
void
CGenericNodeTypeCountRecorderServer::
UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after)
{
  assert(*recorder);
  CGenericNodeTypeCountRecorder * rec = dynamic_cast<CGenericNodeTypeCountRecorder*>(*recorder);
  assert(rec);
  // Call the more specialized version
  *recorder = UpdateRecorderWithProgramCounterChange(rec, pc_before, pc_after);
  assert(*recorder);
}

void
CGenericNodeTypeCountRecorderServer::
UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before)
{
  assert(*recorder);
  CGenericNodeTypeCountRecorder * rec = dynamic_cast<CGenericNodeTypeCountRecorder*>(*recorder);
  assert(rec);
  // Call the more specialized version
  *recorder = UpdateRecorderWithProgramExit(rec, pc_before);
  assert(*recorder);
}

// -------------------------------------------------------
// Reset the current recorder
// -------------------------------------------------------
void
CGenericNodeTypeCountRecorderServer::
ResetRecorder(CRecorder ** recorder)
{
  *recorder = ResetRecorder(dynamic_cast<CGenericNodeTypeCountRecorder*>(*recorder));
}

// -------------------------------------------------------
// Merge two recorders
// -------------------------------------------------------
CRecorder *
CGenericNodeTypeCountRecorderServer::
MergeRecorders(CRecorder * rec1, CRecorder * rec2)
{
  assert(rec1 && rec2);
  return MergeRecorders(dynamic_cast<CGenericNodeTypeCountRecorder*>(rec1), dynamic_cast<CGenericNodeTypeCountRecorder*>(rec2));
}

// -------------------------------------------------------
// To print all the mappings in the server
// -------------------------------------------------------
void
CGenericNodeTypeCountRecorderServer::
Print(ostream * o)
{
  // Loop through all maps
  map<CGenericNodeTypeCountRecorder *, int64_t>::iterator tr;
  int i = 1;
  FORALL(tr, (_recorder_to_refs))
    {
      (*o) << i << ": " << (*tr).first << "."
           << (*tr).second << endl;
      i++;
    }
}

// Alternative printing function
ostream &operator << (ostream &o, CGenericNodeTypeCountRecorderServer &a)
{
  a.Print(&o);
  return o;
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CGenericNodeTypeCountRecorderCOWServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

// -------------------------------------------------------
// To create the recorder server
// -------------------------------------------------------
CGenericNodeTypeCountRecorderCOWServer::
CGenericNodeTypeCountRecorderCOWServer(bool record_generic_nodes, bool record_op_types, 
                                       bool record_stmts, bool record_stmt_pairs)
  : CGenericNodeTypeCountRecorderServer(record_generic_nodes, record_op_types,
                                        record_stmts, record_stmt_pairs)
{
  // Do nothing
}

// -------------------------------------------------------
// To delete the recorder server
// -------------------------------------------------------
CGenericNodeTypeCountRecorderCOWServer::
~CGenericNodeTypeCountRecorderCOWServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To copy recorder
// -------------------------------------------------------
CGenericNodeTypeCountRecorder *
CGenericNodeTypeCountRecorderCOWServer::
CopyRecorder(CGenericNodeTypeCountRecorder * recorder)
{
  // Do no copying, just add one more reference to the recorder
  assert(_recorder_to_refs.find(recorder) != _recorder_to_refs.end());
  _recorder_to_refs[recorder] = _recorder_to_refs[recorder] + 1;

  // Return the same recorder
  return recorder;
}

// -------------------------------------------------------
// To increase count for a certain node
// -------------------------------------------------------
CGenericNodeTypeCountRecorder *
CGenericNodeTypeCountRecorderCOWServer::
UpdateRecorderWithProgramCounterChange(CGenericNodeTypeCountRecorder * recorder, CECFGNode * pc_before, CECFGNode * pc_after)
{
  assert(_recorder_to_refs.find(recorder) != _recorder_to_refs.end());
  assert(_recorder_to_refs[recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[recorder] == 1)
    {
      // Update current recorder
      recorder->UpdateWithProgramCounterChange(pc_before, pc_after);

      // Return the updated recorder
      return recorder;
    }
  // More than one reference
  else
    {
      // Do the real copying
      CGenericNodeTypeCountRecorder * recorder_copy = recorder->Copy();

      // Update the copied recorder
      recorder_copy->UpdateWithProgramCounterChange(pc_before, pc_after);

      // Update map
      _recorder_to_refs[recorder] = _recorder_to_refs[recorder] - 1;
      _recorder_to_refs[recorder_copy] = 1;

      // Return the copied recorder
      return recorder_copy;
    }
}

CGenericNodeTypeCountRecorder *
CGenericNodeTypeCountRecorderCOWServer::
UpdateRecorderWithProgramExit(CGenericNodeTypeCountRecorder * recorder, CECFGNode * pc_before)
{
  assert(_recorder_to_refs.find(recorder) != _recorder_to_refs.end());
  assert(_recorder_to_refs[recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[recorder] == 1)
    {
      // Update current recorder
      recorder->UpdateWithProgramExit(pc_before);

      // Return the updated recorder
      return recorder;
    }
  // More than one reference
  else
    {
      // Do the real copying
      CGenericNodeTypeCountRecorder * recorder_copy = recorder->Copy();

      // Update the copied recorder
      recorder_copy->UpdateWithProgramExit(pc_before);

      // Update map
      _recorder_to_refs[recorder] = _recorder_to_refs[recorder] - 1;
      _recorder_to_refs[recorder_copy] = 1;

      // Return the copied recorder
      return recorder_copy;
    }
}

// -------------------------------------------------------
// To reset the recorder
// -------------------------------------------------------
CGenericNodeTypeCountRecorder *
CGenericNodeTypeCountRecorderCOWServer::
ResetRecorder(CGenericNodeTypeCountRecorder * recorder)
{
  assert(_recorder_to_refs.find(recorder) != _recorder_to_refs.end());
  assert(_recorder_to_refs[recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[recorder] == 1)
    {
      // Update current recorder
      recorder->Reset();

      // Return the updated recorder
      return recorder;
    }
  // More than one reference
  else
    {
      // Create a new recorder (same as doing a reset)
      CGenericNodeTypeCountRecorder * new_recorder = 
        new CGenericNodeTypeCountRecorder(_record_generic_nodes, _record_op_types,
                                          _record_stmts, _record_stmt_pairs);

      // Update map
      _recorder_to_refs[recorder] = _recorder_to_refs[recorder] - 1;
      _recorder_to_refs[new_recorder] = 1;

      // Return the new recorder
      return new_recorder;
    }
}

// -------------------------------------------------------
// To merge two recorders
// -------------------------------------------------------
CGenericNodeTypeCountRecorder *
CGenericNodeTypeCountRecorderCOWServer::
MergeRecorders(CGenericNodeTypeCountRecorder * recorder1, CGenericNodeTypeCountRecorder * recorder2)
{
  assert(_recorder_to_refs.find(recorder1) != _recorder_to_refs.end());
  assert(_recorder_to_refs.find(recorder2) != _recorder_to_refs.end());
  // Check if it is the same recorder (i.e. they points to the same address)
  if(recorder1 == recorder2)
    {
      // Update map
      _recorder_to_refs[recorder1] = _recorder_to_refs[recorder1] + 1;

      // Return the same recorder
      return recorder1;
    }
  else
    {
      // Different recorders, do the real merging
      CGenericNodeTypeCountRecorder * new_recorder = recorder1->Merge(recorder2);

      // Update map
      _recorder_to_refs[new_recorder] = 1;

      // Return the new recorder
      return new_recorder;
    }
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CGenericNodeTypeCountRecorderNoReuseServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

// -------------------------------------------------------
// To create the recorder server
// -------------------------------------------------------
CGenericNodeTypeCountRecorderNoReuseServer::
CGenericNodeTypeCountRecorderNoReuseServer(bool record_generic_nodes, bool record_op_types, 
                                           bool record_stmts, bool record_stmt_pairs)
  : CGenericNodeTypeCountRecorderServer(record_generic_nodes, record_op_types,
                                        record_stmts, record_stmt_pairs)
{
  // Do nothing
}

// -------------------------------------------------------
// To delete the recorder server
// -------------------------------------------------------
CGenericNodeTypeCountRecorderNoReuseServer::
~CGenericNodeTypeCountRecorderNoReuseServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To copy recorder
// -------------------------------------------------------
CGenericNodeTypeCountRecorder *
CGenericNodeTypeCountRecorderNoReuseServer::
CopyRecorder(CGenericNodeTypeCountRecorder * recorder)
{
  // Do the copying right away
  CGenericNodeTypeCountRecorder * new_recorder = recorder->Copy();

  // Update map
  _recorder_to_refs[new_recorder] = 1;

  // Return the new recorder
  return new_recorder;
}

// -------------------------------------------------------
// To increase count for a certain node
// -------------------------------------------------------
CGenericNodeTypeCountRecorder *
CGenericNodeTypeCountRecorderNoReuseServer::
UpdateRecorderWithProgramCounterChange(CGenericNodeTypeCountRecorder * recorder, 
                                       CECFGNode * pc_before, CECFGNode * pc_after)
{
  // Update current recorder
  recorder->UpdateWithProgramCounterChange(pc_before, pc_after);

  // Return the updated recorder
  return recorder;
}

CGenericNodeTypeCountRecorder *
CGenericNodeTypeCountRecorderNoReuseServer::
UpdateRecorderWithProgramExit(CGenericNodeTypeCountRecorder * recorder, 
                              CECFGNode * pc_before)
{
  // Update current recorder
  recorder->UpdateWithProgramExit(pc_before);

  // Return the updated recorder
  return recorder;
}

// -------------------------------------------------------
// To reset the recorder
// -------------------------------------------------------
CGenericNodeTypeCountRecorder *
CGenericNodeTypeCountRecorderNoReuseServer::
ResetRecorder(CGenericNodeTypeCountRecorder * recorder)
{
  // Reset current recorder
  recorder->Reset();

  // Return the updated recorder
  return recorder;
}

// -------------------------------------------------------
// To merge two recorders
// -------------------------------------------------------
CGenericNodeTypeCountRecorder *
CGenericNodeTypeCountRecorderNoReuseServer::
MergeRecorders(CGenericNodeTypeCountRecorder * recorder1, CGenericNodeTypeCountRecorder * recorder2)
{
  // Do the merging getting a new recorder
  CGenericNodeTypeCountRecorder * new_recorder = recorder1->Merge(recorder2);

  // Update map
  _recorder_to_refs[new_recorder] = 1;

  // Return the new recorder
  return new_recorder;
}






