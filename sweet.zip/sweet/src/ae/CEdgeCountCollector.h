/* -*-c++-*- */
  
//----------------------------------------------------------------------
//  
//  THIS FILE:
//
// ----------------------------------------------------------------------
// 
//  $Id: CEdgeCountCollector.h 5409 2013-06-16 15:04:47Z lkg02 $
// 
// ----------------------------------------------------------------------

#ifndef CEdgeCountCollector_H_
#define CEdgeCountCollector_H_

// Standard includes 
#include <string>
#include <iostream>
#include <map>
#include <set>
#include <cassert>

#include "CRecorder.h"
#include "CCollector.h"
#include "CIntegerRange.h"
#include "graphs/ecfg/CECFGNode.h"
#include "flow_facts/CFlowFact.h"
#include "graphs/scopes/CScope.h"
#include "program/CGenericFunction.h"
#include "program/CGenericStmt.h"
#include "flow_facts/CContextSensitiveValidAtEntryOfFlowFact.h"


// -------------------------------------------------------
// Class hierarchy:
// 
//   CEdgeCountCollector
//    |
//    |-- CEdgeCountScopeCollector
//    |     |-- CMinEdgeCountScopeCollector
//    |     |-- CMaxEdgeCountScopeCollector
//    |     |-- CMinMaxEdgeCountScopeCollector
//    |
//    |-- CEdgeCountScopeAndSubCollector
//    |     |-- CMinEdgeCountScopeAndSubCollector
//    |     |-- CMaxEdgeCountScopeAndSubCollector
//    |     |-- CMinMaxEdgeCountScopeAndSubCollector
//    |
//    |-- CEdgeCountScopeAndLoopSubCollector
//    |     |-- CMinEdgeCountScopeAndLoopSubCollector
//    |     |-- CMaxEdgeCountScopeAndLoopSubCollector
//    |     |-- CMinMaxEdgeCountScopeAndLoopSubCollector
//    |
//    |-- CCallEdgeCountScopeCollector
//    |     |-- CMinCallEdgeCountScopeCollector
//    |     |-- CMaxCallEdgeCountScopeCollector
//    |     |-- CMinMaxCallEdgeCountScopeCollector
//    |
//    |-- CCallEdgeCountScopeAndSubCollector
//    |     |-- CMinCallEdgeCountScopeAndSubCollector
//    |     |-- CMaxCallEdgeCountScopeAndSubCollector
//    |     |-- CMinMaxCallEdgeCountScopeAndSubCollector
//    |
//    |-- CCallEdgeCountScopeAndLoopSubCollector
//    |     |-- CMinCallEdgeCountScopeAndLoopSubCollector
//    |     |-- CMaxCallEdgeCountScopeAndLoopSubCollector
//    |     |-- CMinMaxCallEdgeCountScopeAndLoopSubCollector
//    |
//    |-- CLoopBodyBeginEdgeSumCountScopeCollector
//    |     |-- CMinLoopBodyBeginEdgeSumCountScopeCollector
//    |     |-- CMaxLoopBodyBeginEdgeSumCountScopeCollector
//    |     |-- CMinMaxLoopBodyBeginEdgeSumCountScopeCollector
//
// -------------------------------------------------------


//----------------------------------------------------------------------
//----------------------------------------------------------------------
//----------------------------------------------------------------------
// CEdgeCountCollector
// - Class which exports all functionality for updating & storing 
//   information on infeasible edges. Vill be associated with a 
//   scope, asking the scope for information and updating the scope
//   with resulting flow facts.
// - A recorder will update the collector with information upon 
//   the edges taken for an executed scope.  
// - Class to inherit from (is virtual and can not be instansiated).
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//----------------------------------------------------------------------
class CEdgeCountCollector : public CCollector
{
public:

  //----------------------------------
  // Creation and deletion. 
  //----------------------------------

  // Default behaviour is to record only edges inbetween basic blocks. Alternatively,
  // the boolean can be used to control the behaviour.
  CEdgeCountCollector(CScope *, bool collect_only_edges_inbetween_basic_blocks=true, bool sum_edges_in_constraint=false,
                      bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true);
  virtual ~CEdgeCountCollector(void);

  //----------------------------------
  // To update the collector with a new recording. The recording should be 
  // valid for a certain execution (from entry to exit) of a scope. Since
  // we allow states and recording to be merged, the recorder will be a 
  // mapping from edge to ranges or from edges to ranges. Will default 
  // generate an assert, and suitable function call should therefore be 
  // redefined by subclasses.
  //---------------------------------
  void Update(std::map<std::pair<CECFGNode*, CECFGNode*>,CIntegerRange*> * edge_to_range_recording);
  // Will be calling the specialized Update function
  void Report(CRecorder * rec);
  // Should not be called by this collector but need to be implemented
  void Report(int iter, CRecorder * rec) {assert(0);}

  //----------------------------------
  // Create flow facts from the collector and add to scope. Returns
  // the number of flow facts created. Should be defined by subclasses.
  //---------------------------------
  int GenerateFlowFacts(void);

  // ---------------------------------
  // Take a set of collectors, merge their internals and generate
  // context sensitive valid at entry of flow facts valid over CFG
  // nodes. Returns the number of flow facts created. Adds created ffs
  // to last argument. Collectors should be of CEdgeCountCollector type.
  // ---------------------------------
  int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                      std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,
                                                      std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);  
  
  // ---------------------------------
  // For printing the collector
  // ---------------------------------
  void Print(std::ostream *o=&std::cout);

  // The type of the collector, should eb redefined in subclasses
  virtual std::string Type() = 0;

  // To get the edges to consider. Can also be called by a recorder to
  // get the edges to consider. Should not be deallocated by the caller.
  std::set<std::pair<CECFGNode*, CECFGNode*> > * EdgesToConsider(void);

  // To get the saved scope
  CScope * Scope() {return _scope;}

  // To get the number of updates made
  int NrOfReports() { return _nr_of_updates; }

protected:

  // ---------------------------------
  // Functions that should be implemented by subclasses
  // ---------------------------------

  // To get the type of flow fact generated
  virtual CFlowFact::t_flowfacttype GetLowerFlowFactType() = 0;
  virtual CFlowFact::t_flowfacttype GetUpperFlowFactType() = 0;

  // The get the edges to consider. Is called the first time a
  // recorder is reported. Should be provided by subclasses. 
  virtual void SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider) = 0;

  // ---------------------------------
  // Help functions not visible from the outside
  // ---------------------------------

  // Help functions used by different subclasses. Returns the number
  // of flow facts created. Uses the _scope and the _edge_to_range_map.
  int AddMaxEdgeCountFlowFactsToScope(CFlowFact::t_flowfacttype ff_type);
  int AddMinEdgeCountFlowFactsToScope(CFlowFact::t_flowfacttype ff_type);

  // The function should be implemented by subclasses which calls one
  // of the protected Min or MinMax help functions below. Adds created
  // ffs to last argument.
  int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_edge_to_range_map, 
                                                              std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                              std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                              std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);
  
  // Help functions for generating context sensitive flow facts.
  // Returns the number of flow facts created. Adds created ffs to
  // last argument.
  int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_edge_to_range_map, 
                                                         std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                         std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,
                                                         CFlowFact::t_flowfacttype ff_type,
                                                         std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);
  int GenerateContextSensitiveValidAtEntryOfMinFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_edge_to_range_map, 
                                                         std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                         std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of, 
                                                         CFlowFact::t_flowfacttype ff_type,
                                                         std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);
  int GenerateContextSensitiveValidAtEntryOfMaxFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_edge_to_range_map, 
                                                         std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                         std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,
                                                         CFlowFact::t_flowfacttype ff_type,
                                                         std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);

  // To convert the collector's ecfg_edge,range map to a cfg_edge,range map.
  // Result will be stored in argument map.
  void DeriveCFGEdgeToRangeMap(std::map<std::pair<CFlowGraphNode*, CFlowGraphNode*>, CIntegerRange*> * cfg_edge_to_range_map);
    
  // ---------------------------------
  // Internal data 
  // ---------------------------------

  // The scope that the collector is associated with. Will be used 
  // when creating flow facts and when deciding what edges to consider.
  CScope * _scope;

  // If only edges inbetween basic blocks should be collected
  bool _collect_only_edges_inbetween_basic_blocks;

  // If the edges should be summarized in the constraint
  bool _sum_edges_in_constraint;

  // To remember if lower and/or upper bounds should be generated
  bool _generate_lower_bound_ffs;
  bool _generate_upper_bound_ffs;

  // To remember the number of updates made
  int _nr_of_updates;

  // We keep the minimum and maximum count encountered during any
  // scope execution of each edge.
  std::map<std::pair<CECFGNode*, CECFGNode*>,CIntegerRange*> _edge_to_range_map; 

  // To hold the edges to consider. Differently updated by different
  // subclasses.
  std::set<std::pair<CECFGNode*, CECFGNode*> > _edges_to_consider;
  
};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CEdgeCountCollector &a);

//------------------------------------------------------------
//------------------------------------------------------------
// CEdgeCountScopeCollector
// - Collector which just reports both the lowest or largest number of occurrencies
//   of edges for all executions of the scope.
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CEdgeCountScopeCollector : public CEdgeCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CEdgeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                           bool sum_edges_in_constraint=false,
                           bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true);
  virtual ~CEdgeCountScopeCollector() {}

protected:

  // The set the edges to consider. 
  void SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LESS; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UESS; };
};


//--------------------------------------------------
// CMaxEdgeCountScopeCollector
// - Collector which just reports the largest number of occurrencies
//   of edges for all executions of the scope. 
// - Creates  scope : [] : #node->node <= i   flow facts
//-------------------------------------------------
class CMaxEdgeCountScopeCollector : public CEdgeCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxEdgeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMaxEdgeCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxEdgeCountScopeCollector";}
};

//--------------------------------------------------
// CMinEdgeCountScopeCollector
// - Collector which just reports the smallest number of occurrencies
//   of edges for all executions of the scope.
// - Creates  scope : [] : #node->node >= i   flow facts
//-------------------------------------------------
class CMinEdgeCountScopeCollector : public CEdgeCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinEdgeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinEdgeCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinEdgeCountScopeCollector";}
};


//--------------------------------------------------
// CMinMaxEdgeCountScopeCollector
// - Collector which just reports the smallest and largest number of occurrencies
//   of edges for all executions of the scope.
// - Creates  scope : [] : #node->node <= i   and 
//            scope : [] : #node->node >= j   flow facts
//-------------------------------------------------
class CMinMaxEdgeCountScopeCollector : public CEdgeCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxEdgeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinMaxEdgeCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxEdgeCountScopeCollector";}
};



//------------------------------------------------------------
//------------------------------------------------------------
// CEdgeCountScopeAndSubCollector
// - Collector which just reports both the lowest or largest number of occurrencies
//   of edges for all executions of the scope and its subscopes.
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CEdgeCountScopeAndSubCollector : public CEdgeCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                           bool sum_edges_in_constraint=false,
                           bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true);
  virtual ~CEdgeCountScopeAndSubCollector() {}

protected:

  // The set the edges to consider. 
  void SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LESP; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UESP; };
};


//--------------------------------------------------
// CMaxEdgeCountScopeAndSubCollector
// - Collector which just reports the largest number of occurrencies
//   of edges for all executions of the scope and its subscopes. 
// - Creates  scope : [] : #node->node <= i   flow facts
//-------------------------------------------------
class CMaxEdgeCountScopeAndSubCollector : public CEdgeCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMaxEdgeCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxEdgeCountScopeAndSubCollector";}
};

//--------------------------------------------------
// CMinEdgeCountScopeAndSubCollector
// - Collector which just reports the smallest number of occurrencies
//   of edges for all executions of the scope and its subscopes.
// - Creates  scope : [] : #node->node >= i   flow facts
//-------------------------------------------------
class CMinEdgeCountScopeAndSubCollector : public CEdgeCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinEdgeCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinEdgeCountScopeAndSubCollector";}
};


//--------------------------------------------------
// CMinMaxEdgeCountScopeAndSubCollector
// - Collector which just reports the smellest and largest number of occurrencies
//   of edges for all executions of the scope and its subscopes.
// - Creates  scope : [] : #node->node <= i   and 
//            scope : [] : #node->node >= j   flow facts
//-------------------------------------------------
class CMinMaxEdgeCountScopeAndSubCollector : public CEdgeCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinMaxEdgeCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxEdgeCountScopeAndSubCollector";}
};



//------------------------------------------------------------
//------------------------------------------------------------
// CEdgeCountScopeAndLoopSubCollector
// - Collector which just reports both the lowest or largest number of occurrencies
//   of edges for all executions of the scope and its looping subscopes.
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CEdgeCountScopeAndLoopSubCollector : public CEdgeCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                           bool sum_edges_in_constraint=false,
                           bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true);
  virtual ~CEdgeCountScopeAndLoopSubCollector() {}

protected:

  // The set the edges to consider. 
  void SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LESF; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UESF; };
};


//--------------------------------------------------
// CMaxEdgeCountScopeAndLoopSubCollector
// - Collector which just reports the largest number of occurrencies
//   of edges for all executions of the scope and its looping subscopes. 
// - Creates  scope : [] : #node->node <= i   flow facts
//-------------------------------------------------
class CMaxEdgeCountScopeAndLoopSubCollector : public CEdgeCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMaxEdgeCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxEdgeCountScopeAndLoopSubCollector";}
};

//--------------------------------------------------
// CMinEdgeCountScopeAndLoopSubCollector
// - Collector which just reports the smallest number of occurrencies
//   of edges for all executions of the scope and its looping subscopes.
// - Creates  scope : [] : #node->node >= i   flow facts
//-------------------------------------------------
class CMinEdgeCountScopeAndLoopSubCollector : public CEdgeCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinEdgeCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinEdgeCountScopeAndLoopSubCollector";}
};


//--------------------------------------------------
// CMinMaxEdgeCountScopeAndLoopSubCollector
// - Collector which just reports the smellest and largest number of occurrencies
//   of edges for all executions of the scope and its looping subscopes.
// - Creates  scope : [] : #node->node <= i   and 
//            scope : [] : #node->node >= j   flow facts
//-------------------------------------------------
class CMinMaxEdgeCountScopeAndLoopSubCollector : public CEdgeCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinMaxEdgeCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxEdgeCountScopeAndLoopSubCollector";}
};


//------------------------------------------------------------
//------------------------------------------------------------
// CCallEdgeCountScopeAndSubCollector
// - Collector which just reports both the lowest or largest number of occurrencies
//   of call edges for all executions of the scope and its subscopes.
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CCallEdgeCountScopeAndSubCollector : public CEdgeCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CCallEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                           bool sum_edges_in_constraint=false,
                           bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true);
  virtual ~CCallEdgeCountScopeAndSubCollector() {}

protected:

  // The set the edges to consider. 
  void SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LCSP; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UCSP; };
};


//--------------------------------------------------
// CMaxCallEdgeCountScopeAndSubCollector
// - Collector which just reports the largest number of occurrencies
//   of call edges for all executions of the scope and its subscopes. 
// - Creates  scope : [] : #node->node <= i   flow facts
//-------------------------------------------------
class CMaxCallEdgeCountScopeAndSubCollector : public CCallEdgeCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxCallEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMaxCallEdgeCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxCallEdgeCountScopeAndSubCollector";}
};

//--------------------------------------------------
// CMinCallEdgeCountScopeAndSubCollector
// - Collector which just reports the smallest number of occurrencies
//   of call edges for all executions of the scope and its subscopes.
// - Creates  scope : [] : #node->node >= i   flow facts
//-------------------------------------------------
class CMinCallEdgeCountScopeAndSubCollector : public CCallEdgeCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinCallEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinCallEdgeCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinCallEdgeCountScopeAndSubCollector";}
};


//--------------------------------------------------
// CMinMaxCallEdgeCountScopeAndSubCollector
// - Collector which just reports the smellest and largest number of occurrencies
//   of call edges for all executions of the scope and its subscopes.
// - Creates  scope : [] : #node->node <= i   and 
//            scope : [] : #node->node >= j   flow facts
//-------------------------------------------------
class CMinMaxCallEdgeCountScopeAndSubCollector : public CCallEdgeCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxCallEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinMaxCallEdgeCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxCallEdgeCountScopeAndSubCollector";}
};


//------------------------------------------------------------
//------------------------------------------------------------
// CCallEdgeCountScopeAndLoopSubCollector
// - Collector which just reports both the lowest or largest number of occurrencies
//   of call edges for all executions of the scope and its looping subscopes.
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CCallEdgeCountScopeAndLoopSubCollector : public CEdgeCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CCallEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                           bool sum_edges_in_constraint=false,
                           bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true);
  virtual ~CCallEdgeCountScopeAndLoopSubCollector() {}

protected:

  // The set the edges to consider. 
  void SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LCSF; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UCSF; };
};


//--------------------------------------------------
// CMaxCallEdgeCountScopeAndLoopSubCollector
// - Collector which just reports the largest number of occurrencies
//   of call edges for all executions of the scope and its looping subscopes. 
// - Creates  scope : [] : #node->node <= i   flow facts
//-------------------------------------------------
class CMaxCallEdgeCountScopeAndLoopSubCollector : public CCallEdgeCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxCallEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMaxCallEdgeCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxCallEdgeCountScopeAndLoopSubCollector";}
};

//--------------------------------------------------
// CMinCallEdgeCountScopeAndLoopSubCollector
// - Collector which just reports the smallest number of occurrencies
//   of call edges for all executions of the scope and its looping subscopes.
// - Creates  scope : [] : #node->node >= i   flow facts
//-------------------------------------------------
class CMinCallEdgeCountScopeAndLoopSubCollector : public CCallEdgeCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinCallEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinCallEdgeCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinCallEdgeCountScopeAndLoopSubCollector";}
};


//--------------------------------------------------
// CMinMaxCallEdgeCountScopeAndLoopSubCollector
// - Collector which just reports the smellest and largest number of occurrencies
//   of call edges for all executions of the scope and its looping subscopes.
// - Creates  scope : [] : #node->node <= i   and 
//            scope : [] : #node->node >= j   flow facts
//-------------------------------------------------
class CMinMaxCallEdgeCountScopeAndLoopSubCollector : public CCallEdgeCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxCallEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinMaxCallEdgeCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxCallEdgeCountScopeAndLoopSubCollector";}
};


//------------------------------------------------------------
//------------------------------------------------------------
// CLoopBodyBeginEdgeSumCountScopeCollector
// - Collector which just reports both the lowest or largest number of occurrencies
//   of sum of loop body begin edges for all executions of the scope. 
// - Note: will summarize *all* edges in the generated constraints.
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CLoopBodyBeginEdgeSumCountScopeCollector : public CEdgeCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CLoopBodyBeginEdgeSumCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                           bool sum_edges_in_constraint=true,
                                           bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true);
  virtual ~CLoopBodyBeginEdgeSumCountScopeCollector() {}

protected:

  // The set the edges to consider. 
  void SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LBNS; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UBNS; };
};


//--------------------------------------------------
// CMaxLoopBodyBeginEdgeSumCountScopeCollector
// - Collector which just reports the largest number of occurrencies
//   of loop body begin edges for all executions of the scope. 
// - Creates  scope : [] : #node->node + #node->node + ... <= i   flow facts
//-------------------------------------------------
class CMaxLoopBodyBeginEdgeSumCountScopeCollector : public CLoopBodyBeginEdgeSumCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxLoopBodyBeginEdgeSumCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMaxLoopBodyBeginEdgeSumCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxLoopBodyBeginEdgeSumCountScopeCollector";}
};

//--------------------------------------------------
// CMinLoopBodyBeginEdgeSumCountScopeCollector
// - Collector which just reports the smallest number of occurrencies
//   of loop body begin edges for all executions of the scope.
// - Creates  scope : [] : #node->node + #node->node + ...  >= i   flow facts
//-------------------------------------------------
class CMinLoopBodyBeginEdgeSumCountScopeCollector : public CLoopBodyBeginEdgeSumCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinLoopBodyBeginEdgeSumCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinLoopBodyBeginEdgeSumCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinLoopBodyBeginEdgeSumCountScopeCollector";}
};


//--------------------------------------------------
// CMinMaxLoopBodyBeginEdgeSumCountScopeCollector
// - Collector which just reports the smallest and largest number of occurrencies
//   of loop body begin edges for all executions of the scope.
// - Creates  scope : [] : #node->node + #node->node + ...  >= i   and
//            scope : [] : #node->node + #node->node + ...  <= j   flow facts

//-------------------------------------------------
class CMinMaxLoopBodyBeginEdgeSumCountScopeCollector : public CLoopBodyBeginEdgeSumCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxLoopBodyBeginEdgeSumCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinMaxLoopBodyBeginEdgeSumCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxLoopBodyBeginEdgeSumCountScopeCollector";}
};

#endif















