/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: $
//
// ----------------------------------------------------------------------

#include "ae/CGenericNodeTypeCountCollector.h"
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CGenericNodeTypeCountCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of collector
//----------------------------------
CGenericNodeTypeCountCollector::
CGenericNodeTypeCountCollector(bool collect_generic_nodes, bool collect_op_types,
                               bool collect_stmts, bool collect_stmt_pairs,
                               const alf::CAlfCostLookupTable * cost_lookup_table)
  
{
  _nr_of_type_updates = 0;
  _nr_of_op_type_updates = 0;
  _nr_of_stmt_updates = 0;
  _nr_of_stmt_pair_updates = 0;
  _collect_generic_nodes = collect_generic_nodes;
  _collect_op_types = collect_op_types;
  _collect_stmts = collect_stmts;
  _collect_stmt_pairs = collect_stmt_pairs;
  _bcet = 0;
  _wcet = 0;
  _has_bcet_and_wcet = false;
  // We remove the const here, since we want the caller to know that
  // the cost_lookup_table is owned by the caller and that we will not
  // update it. However, since some functions in the cost_lookup_table
  // are using maps to lookup elements, it is not possible to be define
  // the table as a const :(
  _cost_lookup_table = const_cast<alf::CAlfCostLookupTable *>(cost_lookup_table);
}


//----------------------------------
// Deletion of collector
//----------------------------------
CGenericNodeTypeCountCollector::
~CGenericNodeTypeCountCollector()
{
  // Go through the map deleting all the ranges of gen types
  {
    std::map<alf::CGenericNode::TYPE, CIntegerRange*>::iterator t2r;
    FORALL(t2r, _type_to_range_map)
      delete (*t2r).second;
  }

  // Go through the map deleting all the ranges of op types
  {
    std::map<alf::COpNumExprTuple::OP_TYPE, CIntegerRange*>::iterator ot2r;
    FORALL(ot2r, _op_type_to_range_map)
      delete (*ot2r).second;
  }

  // Go through the map deleting all the ranges of stmt types
  {
    std::map<CGenericStmt::GS_TYPE, CIntegerRange*>::iterator s2r;
    FORALL(s2r, _stmt_to_range_map)
      delete (*s2r).second;
  } 

  // Go through the map deleting all the ranges of stmt pair types
  {
    std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*>::iterator sp2r;
    FORALL(sp2r, _stmt_pair_to_range_map)
      delete (*sp2r).second;
  } 

  // The maps will be removed together with the collector
}



// The report function needs to be implemented
void
CGenericNodeTypeCountCollector::
Report(CRecorder * rec)
{
  // Update with different recordings
  CGenericNodeTypeCountRecorder * gntc_rec = dynamic_cast<CGenericNodeTypeCountRecorder *>(rec);
  assert(gntc_rec);
  if(_collect_generic_nodes) Update(gntc_rec->GetTypeToRangeMap());
  if(_collect_op_types) Update(gntc_rec->GetOpTypeToRangeMap());
  if(_collect_stmts) Update(gntc_rec->GetStmtToRangeMap());
  if(_collect_stmt_pairs) Update(gntc_rec->GetStmtPairToRangeMap());

  // If we should keep track on the min and max time derived for the
  // execution based on cost lookup table
  if(_cost_lookup_table) 
    UpdateBCETAndWCETWithRecorder(gntc_rec);
}

void 
CGenericNodeTypeCountCollector::
UpdateBCETAndWCETWithRecorder(CGenericNodeTypeCountRecorder * rec)
{
  // Holders for the bcet and wcet of the recorder
  double rec_bcet = 0;
  double rec_wcet = 0;

  // Derive a new min and max time range for the current recording
  if(_cost_lookup_table->HasProgRunCost()) {
    rec_bcet = _cost_lookup_table->LookUpProgRunCost();
    rec_wcet = rec_bcet;
  }

  // Updated bcet and wcet according to code entities exceuted and
  // their corresponding cost in the cost lookup table
  if(_collect_generic_nodes && _cost_lookup_table->HasGenericNodeCost()) 
    UpdateBCETAndWCET(rec->GetTypeToRangeMap(), rec_bcet, rec_wcet);
  if(_collect_op_types && _cost_lookup_table->HasOperandCost()) 
    UpdateBCETAndWCET(rec->GetOpTypeToRangeMap(), rec_bcet, rec_wcet);
  if(_collect_stmts && _cost_lookup_table->HasStmtCost()) 
    UpdateBCETAndWCET(rec->GetStmtToRangeMap(), rec_bcet, rec_wcet);
  if(_collect_stmt_pairs && _cost_lookup_table->HasStmtPairCost()) 
    UpdateBCETAndWCET(rec->GetStmtPairToRangeMap(), rec_bcet, rec_wcet);

  // Update overall BCET and WCET 
  if(_has_bcet_and_wcet == false) {
    // This is the first time we have derived a bcet and a wcet
    _bcet = rec_bcet;
    _wcet = rec_wcet;
    _has_bcet_and_wcet = true;
  }
  else {    
    // Derive the smallest BCET and the largest WCET
    if(_bcet > rec_bcet) _bcet = rec_bcet;
    if(_wcet < rec_wcet) _wcet = rec_wcet;
  }
}

void
CGenericNodeTypeCountCollector::
UpdateBCETAndWCET(std::map<alf::CGenericNode::TYPE, CIntegerRange*> * type_to_range_map,
                  double & bcet, double & wcet)
{
  std::map<alf::CGenericNode::TYPE, CIntegerRange*>::iterator t2r;
  FORALL(t2r, (*type_to_range_map))
    {
      alf::CGenericNode::TYPE type = (*t2r).first;
      CIntegerRange* range = (*t2r).second;
      double min_count = (double)range->L();
      double max_count = (double)range->U();
      double cost = _cost_lookup_table->LookUpCost(type);
      bcet += min_count * cost;
      wcet += max_count * cost;
    }
}

void
CGenericNodeTypeCountCollector::
UpdateBCETAndWCET(std::map<alf::COpNumExprTuple::OP_TYPE, CIntegerRange*> * op_type_to_range_map,
                  double & bcet, double & wcet)
{
  std::map<alf::COpNumExprTuple::OP_TYPE, CIntegerRange*>::iterator ot2r;
  FORALL(ot2r, (*op_type_to_range_map))
    {
      alf::COpNumExprTuple::OP_TYPE op_type = (*ot2r).first;
      CIntegerRange* range = (*ot2r).second;
      double min_count = (double)range->L();
      double max_count = (double)range->U();
      double cost = _cost_lookup_table->LookUpCost(op_type);
      bcet += min_count * cost;
      wcet += max_count * cost;
    }
}

void
CGenericNodeTypeCountCollector::
UpdateBCETAndWCET(std::map<CGenericStmt::GS_TYPE, CIntegerRange*> * stmt_to_range_map,
                  double & bcet, double & wcet)
{
  std::map<CGenericStmt::GS_TYPE, CIntegerRange*>::iterator s2r;
  FORALL(s2r, (*stmt_to_range_map))
    {
      CGenericStmt::GS_TYPE stmt = (*s2r).first;
      CIntegerRange* range = (*s2r).second;
      double min_count = (double)range->L();
      double max_count = (double)range->U();
      double cost = _cost_lookup_table->LookUpCost(stmt);
      bcet += min_count * cost;
      wcet += max_count * cost;
    }
}

void
CGenericNodeTypeCountCollector::
UpdateBCETAndWCET(std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*> * stmt_pair_to_range_map,
                  double & bcet, double & wcet)
{
  std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*>::iterator sp2r;
  FORALL(sp2r, (*stmt_pair_to_range_map))
    {
      std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE> stmt_pair = (*sp2r).first;
      CIntegerRange* range = (*sp2r).second;
      double min_count = (double)range->L();
      double max_count = (double)range->U();
      double cost = _cost_lookup_table->LookUpCost(stmt_pair);
      bcet += min_count * cost;
      wcet += max_count * cost;
    }
}


//---------------------------------
// For printing the collector
//---------------------------------
void
CGenericNodeTypeCountCollector::
Print(ostream * o)
{
  Print(o, false);
}

#define TC_COMMENT " %% "

void
CGenericNodeTypeCountCollector::
Print(ostream * o, bool simple_count_print)
{
  if(_collect_generic_nodes || _collect_op_types || _collect_stmts || _collect_stmt_pairs)
    PrintCollections(o, simple_count_print);
  if(_cost_lookup_table)
    PrintBCETAndWCET(o);
}

void
CGenericNodeTypeCountCollector::
PrintCollections(ostream * o, bool simple_count_print)
{
  unsigned int index = 0;

  // Print the program run
  if(simple_count_print) 
    (*o) << 1 << " ";
  else {
    (*o) << 1 << TC_COMMENT << "PROG_RUN (" << index << ")" << endl;
    index++;
  }

  // Print type to range map
  if(_collect_generic_nodes) {
    std::map<alf::CGenericNode::TYPE, CIntegerRange*>::iterator t2r;
    FORALL(t2r, _type_to_range_map)
      {
        alf::CGenericNode::TYPE type = (*t2r).first;
        CIntegerRange* range = (*t2r).second;
        string type_as_string = alf::CGenericNode::GetTypeAsString(type);
        if(simple_count_print) 
          (*o) << range->U() << " ";
        else {
          if(range->L() == range->U())
            (*o) << range->U() << TC_COMMENT << type_as_string << " (" << index << ")" << endl;
          else
            (*o) << *range << TC_COMMENT << type_as_string << " (" << index << ")" << endl;
          index++;
        }
      }
  }

  // Print op type to range map
  if(_collect_op_types) {
    std::map<alf::COpNumExprTuple::OP_TYPE, CIntegerRange*>::iterator ot2r;
    FORALL(ot2r, _op_type_to_range_map)
      {
        alf::COpNumExprTuple::OP_TYPE op_type = (*ot2r).first;
        CIntegerRange* range = (*ot2r).second;
        string op_type_as_string = alf::COpNumExprTuple::GetName(op_type);
        if(simple_count_print) 
          (*o) << range->U() << " ";
        else {
          if(range->L() == range->U())
            (*o) << range->U() << TC_COMMENT << op_type_as_string << " (" << index << ")" << endl;
          else
            (*o) << (*range) << TC_COMMENT << op_type_as_string << " (" << index << ")" << endl;
          index++;
        }
      }
  }
  
  // Print stmt to range map
  if(_collect_stmts) {
    std::map<CGenericStmt::GS_TYPE, CIntegerRange*>::iterator s2r;
    FORALL(s2r, _stmt_to_range_map)
      {
        CGenericStmt::GS_TYPE stmt = (*s2r).first;
        CIntegerRange* range = (*s2r).second;
        string stmt_as_string = CGenericStmt::GetName(stmt);
        if(simple_count_print) 
          (*o) << range->U() << " ";
        else {
          if(range->L() == range->U())
            (*o) << range->U() << TC_COMMENT << stmt_as_string << " (" << index << ")" << endl;
          else
            (*o) << (*range) << TC_COMMENT << stmt_as_string << " (" << index << ")" << endl;
          index++;
        }
      }
  }

  // Print stmt pairs to range map
  if(_collect_stmt_pairs) {
    std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*>::iterator sp2r;
    FORALL(sp2r, _stmt_pair_to_range_map)
      {
        CGenericStmt::GS_TYPE stmt1 = (*sp2r).first.first;
        CGenericStmt::GS_TYPE stmt2 = (*sp2r).first.second;
        CIntegerRange* range = (*sp2r).second;
        string stmt1_as_string = CGenericStmt::GetName(stmt1);
        string stmt2_as_string = CGenericStmt::GetName(stmt2);
        std::ostringstream s;
        s << "PAIR_" << stmt1_as_string << "_AND_" << stmt2_as_string; 
        if(simple_count_print) 
          (*o) << range->U() << " ";
        else {
          if(range->L() == range->U())
            (*o) << range->U() << TC_COMMENT << s.str() << " (" << index << ")" << endl;
          else
            (*o) << (*range) << TC_COMMENT << s.str() << " (" << index << ")" << endl;
        }
        index++;
      }
  }  
  (*o) << endl;
}

void
CGenericNodeTypeCountCollector::
PrintBCETAndWCET(ostream * o)
{
  if(_has_bcet_and_wcet) {
    (*o) << "BCET estimate based on ALF AST cost lookup table (old version): " << _bcet << endl;
    (*o) << "WCET estimate based on ALF AST cost lookup table (old version): " << _wcet << endl;
  }
  else {
    (*o) << "No BCET or WCET estimates generated using ALF construct cost lookup table" << endl;
  }
}

//---------------------------------
// Alternative printing function
//---------------------------------
ostream &operator << (ostream &o, CGenericNodeTypeCountCollector &a)
{
  a.Print(&o, false);
  return o;
}

// ---------------------------------
// To check if the collector is empty
// ---------------------------------
bool
CGenericNodeTypeCountCollector::
IsEmpty() 
{
  return (_type_to_range_map.size() == 0) && (_op_type_to_range_map.size() == 0) &&
    (_stmt_to_range_map.size() == 0) && (_stmt_pair_to_range_map.size() == 0);
}

//----------------------------------
// To update the collector with a new recording.
//---------------------------------
void
CGenericNodeTypeCountCollector::
Update(std::map<alf::CGenericNode::TYPE, CIntegerRange*> * type_to_range_recording)
{
  if(!_collect_generic_nodes) return;

  // Increase the nr of updates
  _nr_of_type_updates++;

  // Treat first update especially
  if(_nr_of_type_updates == 1)
    {
      // Go through all types that we should consider 
      unsigned int nr_of_types = alf::CGenericNode::NrOfTYPEs();
      for(unsigned int t = 0; t < nr_of_types; ++t) 
        {
          alf::CGenericNode::TYPE type = (alf::CGenericNode::TYPE)(t);
          // Check if the type existed in the recording
          if(type_to_range_recording->find(type) == type_to_range_recording->end())
            {
              // No, create a new 0..0 range and associated it with type
              _type_to_range_map[type] = new CIntegerRange(0,0);
            }
          else 
            {
              // Yes, copy the recorded range and associate it with type
              CIntegerRange* rec_range = (*type_to_range_recording)[type];
              _type_to_range_map[type] = rec_range->Copy();
            }
        }
    }
  else
    {
      // Go through all types that we should consider 
      unsigned int nr_of_types = alf::CGenericNode::NrOfTYPEs();
      for(unsigned int t = 0; t < nr_of_types; ++t) 
        {
          // Get the type
          alf::CGenericNode::TYPE type = (alf::CGenericNode::TYPE)(t);
          // Get the old range
          CIntegerRange* old_range = _type_to_range_map[type];
          // Check if the type existed in the recording
          if(type_to_range_recording->find(type) == type_to_range_recording->end())
            {
              // No, merge a 0..0 range with the previous range
              CIntegerRange* rec_range = new CIntegerRange(0,0);
              CIntegerRange* new_range = old_range->Merge(rec_range);
              delete rec_range;
              _type_to_range_map[type] = new_range;
            }
          else 
            {
              // Yes, merge the old and the recorded range
              CIntegerRange* rec_range = (*type_to_range_recording)[type];
              CIntegerRange* new_range = old_range->Merge(rec_range);
              _type_to_range_map[type] = new_range;
            }
          // Delete the old range
          delete old_range;
        }
    }
  // We are done, the type to ranges maps have been merged.
  return;
}


//----------------------------------
// To update the collector with a new recording.
//---------------------------------
void
CGenericNodeTypeCountCollector::
Update(std::map<alf::COpNumExprTuple::OP_TYPE, CIntegerRange*> * op_type_to_range_recording)
{
  if(!_collect_op_types) return;
  
  // Increase the nr of updates
  _nr_of_op_type_updates++;

  // Treat first update especially
  if(_nr_of_op_type_updates == 1)
    {
      // Go through all types that we should consider 
      unsigned int nr_of_op_types = alf::COpNumExprTuple::NrOfOPTYPEs();
      for(unsigned int t = 0; t < nr_of_op_types; ++t) 
        {
          alf::COpNumExprTuple::OP_TYPE op_type = (alf::COpNumExprTuple::OP_TYPE)(t);
          // Check if the op_type existed in the recording
          if(op_type_to_range_recording->find(op_type) == op_type_to_range_recording->end())
            {
              // No, create a new 0..0 range and associated it with op_type
              _op_type_to_range_map[op_type] = new CIntegerRange(0,0);
            }
          else 
            {
              // Yes, copy the recorded range and associate it with op_type
              CIntegerRange* rec_range = (*op_type_to_range_recording)[op_type];
              _op_type_to_range_map[op_type] = rec_range->Copy();
            }
        }
    }
  else
    {
      // Go through all op_types that we should consider 
      unsigned int nr_of_op_types = alf::COpNumExprTuple::NrOfOPTYPEs();
      for(unsigned int t = 0; t < nr_of_op_types; ++t) 
        {
          // Get the op_type
          alf::COpNumExprTuple::OP_TYPE op_type = (alf::COpNumExprTuple::OP_TYPE)(t);
          // Get the old range
          CIntegerRange* old_range = _op_type_to_range_map[op_type];
          // Check if the op_type existed in the recording
          if(op_type_to_range_recording->find(op_type) == op_type_to_range_recording->end())
            {
              // No, merge a 0..0 range with the previous range
              CIntegerRange* rec_range = new CIntegerRange(0,0);
              CIntegerRange* new_range = old_range->Merge(rec_range);
              delete rec_range;
              _op_type_to_range_map[op_type] = new_range;
            }
          else 
            {
              // Yes, merge the old and the recorded range
              CIntegerRange* rec_range = (*op_type_to_range_recording)[op_type];
              CIntegerRange* new_range = old_range->Merge(rec_range);
              _op_type_to_range_map[op_type] = new_range;
            }
          // Delete the old range
          delete old_range;
        }
    }
  // We are done, the op_type to ranges maps have been merged.
  return;
}

//----------------------------------
// To update the collector with a new recording.
//---------------------------------
void
CGenericNodeTypeCountCollector::
Update(std::map<CGenericStmt::GS_TYPE, CIntegerRange*> * stmt_to_range_recording)
{
  if(!_collect_stmts) return;

  // Increase the nr of updates
  _nr_of_stmt_updates++;

  // Treat first update especially
  if(_nr_of_stmt_updates == 1)
    {
      // Go through all stmts that we should consider 
      unsigned int nr_of_stmts = CGenericStmt::NrOfGSTYPEs();
      for(unsigned int t = 0; t < nr_of_stmts; ++t) 
        {
          CGenericStmt::GS_TYPE stmt = (CGenericStmt::GS_TYPE)(t);
          // Check if the stmt existed in the recording
          if(stmt_to_range_recording->find(stmt) == stmt_to_range_recording->end())
            {
              // No, create a new 0..0 range and associated it with stmt
              _stmt_to_range_map[stmt] = new CIntegerRange(0,0);
            }
          else 
            {
              // Yes, copy the recorded range and associate it with stmt
              CIntegerRange* rec_range = (*stmt_to_range_recording)[stmt];
              _stmt_to_range_map[stmt] = rec_range->Copy();
            }
        }
    }
  else
    {
      // Go through all stmts that we should consider 
      unsigned int nr_of_stmts = CGenericStmt::NrOfGSTYPEs();
      for(unsigned int t = 0; t < nr_of_stmts; ++t) 
        {
          // Get the stmt
          CGenericStmt::GS_TYPE stmt = (CGenericStmt::GS_TYPE)(t);
          // Get the old range
          CIntegerRange* old_range = _stmt_to_range_map[stmt];
          // Check if the stmt existed in the recording
          if(stmt_to_range_recording->find(stmt) == stmt_to_range_recording->end())
            {
              // No, merge a 0..0 range with the previous range
              CIntegerRange* rec_range = new CIntegerRange(0,0);
              CIntegerRange* new_range = old_range->Merge(rec_range);
              delete rec_range;
              _stmt_to_range_map[stmt] = new_range;
            }
          else 
            {
              // Yes, merge the old and the recorded range
              CIntegerRange* rec_range = (*stmt_to_range_recording)[stmt];
              CIntegerRange* new_range = old_range->Merge(rec_range);
              _stmt_to_range_map[stmt] = new_range;
            }
          // Delete the old range
          delete old_range;
        }
    }
  // We are done, the type to ranges maps have been merged.
  return;
}


//----------------------------------
// To update the collector with a new recording.
//---------------------------------
void
CGenericNodeTypeCountCollector::
Update(std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*> * stmt_pair_to_range_recording)
{
  if(!_collect_stmt_pairs) return;

  // Increase the nr of updates
  _nr_of_stmt_pair_updates++;

  // Treat first update especially
  if(_nr_of_stmt_pair_updates == 1)
    {
      // Go through all stmt pairs that we should consider 
      unsigned int nr_of_stmts = CGenericStmt::NrOfGSTYPEs();
      for(unsigned int i1 = 0; i1 < nr_of_stmts; ++i1) {
        CGenericStmt::GS_TYPE stmt1 = (CGenericStmt::GS_TYPE)(i1);
        for(unsigned int i2 = 0; i2 < nr_of_stmts; ++i2) {
          CGenericStmt::GS_TYPE stmt2 = (CGenericStmt::GS_TYPE)(i2);
          std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE> stmt_pair = 
            std::make_pair(stmt1, stmt2);

            // Check if the stmt existed in the recording
          if(stmt_pair_to_range_recording->find(stmt_pair) == stmt_pair_to_range_recording->end())
            {
              // No, create a new 0..0 range and associated it with stmt
              _stmt_pair_to_range_map[stmt_pair] = new CIntegerRange(0,0);
            }
          else 
            {
              // Yes, copy the recorded range and associate it with stmt
              CIntegerRange* rec_range = (*stmt_pair_to_range_recording)[stmt_pair];
              _stmt_pair_to_range_map[stmt_pair] = rec_range->Copy();
            }
        }
      }
    }
  else
    {
      // Go through all stmt pairs that we should consider 
      unsigned int nr_of_stmts = CGenericStmt::NrOfGSTYPEs();
      for(unsigned int i1 = 0; i1 < nr_of_stmts; ++i1) {
        CGenericStmt::GS_TYPE stmt1 = (CGenericStmt::GS_TYPE)(i1);
        for(unsigned int i2 = 0; i2 < nr_of_stmts; ++i2) {
          CGenericStmt::GS_TYPE stmt2 = (CGenericStmt::GS_TYPE)(i2);
          std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE> stmt_pair = 
            std::make_pair(stmt1, stmt2);
          // Get the old range
          CIntegerRange* old_range = _stmt_pair_to_range_map[stmt_pair];
          // Check if the stmt existed in the recording
          if(stmt_pair_to_range_recording->find(stmt_pair) == stmt_pair_to_range_recording->end())
            {
              // No, merge a 0..0 range with the previous range
              CIntegerRange* rec_range = new CIntegerRange(0,0);
              CIntegerRange* new_range = old_range->Merge(rec_range);
              delete rec_range;
              _stmt_pair_to_range_map[stmt_pair] = new_range;
            }
          else 
            {
              // Yes, merge the old and the recorded range
              CIntegerRange* rec_range = (*stmt_pair_to_range_recording)[stmt_pair];
              CIntegerRange* new_range = old_range->Merge(rec_range);
              _stmt_pair_to_range_map[stmt_pair] = new_range;
            }
          // Delete the old range
          delete old_range;
        }
      }
    }
  // We are done, the type to ranges maps have been merged.
  return;
}
