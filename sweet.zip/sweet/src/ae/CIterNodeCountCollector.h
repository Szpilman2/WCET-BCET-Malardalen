/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CIterNodeCountCollector.h 326 2009-05-06 07:59:13Z msl01 $
//
// ----------------------------------------------------------------------

#ifndef CIterNodeCountCollector_H_
#define CIterNodeCountCollector_H_

#include <string>
#include <iostream>
#include <fstream>
#include <map>
#include <set>

#include "CIterNodeCountRecorder.h"
#include "CCollector.h"
#include "CRecorder.h"
#include "graphs/ecfg/CECFGNode.h"
#include "program/CGenericStmt.h"
#include "program/CGenericFunction.h"

#include "flow_facts/CContextSensitiveValidAtEntryOfFlowFact.h"

// Forward declare the CScope structure
class CScope;

// For getting nice macros
#include "macros.h"

//----------------------------------------------------------------------
// Forward-declare types
//----------------------------------------------------------------------
class CIterNodeCountCollector;
class CAllIterNodeCountCollector;
class CEachIterNodeCountCollector;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CIterNodeCountCollector
// - Class which exports all functionality for updating & storing
//   information on infeasible nodes. Vill be associated with a
//   scope, asking the scope for information and updating the scope
//   with resulting flow facts.
// - A recorder will update the collexctor with information upon
//   the nodes taken for an executed iteration.
// - Class to inherit from.
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CIterNodeCountCollector : public CCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CIterNodeCountCollector(CScope * scope);
  CIterNodeCountCollector(CScope * scope, bool collect_only_basic_block_start_nodes);
  virtual ~CIterNodeCountCollector(void);

  //---------------------------------
  // To update the collector with a new recorder. The recorder should be valid
  // for a certain iteration.
  //---------------------------------
  virtual void Update(int iter, CIterNodeCountRecorder * rec) = 0;
  // Will call the more specialized version
  void Report(int iter, CRecorder * rec);
  // Should not be called
  void Report(CRecorder * rec) {assert(0);};

  //----------------------------------
  // Create flow facts from the collector and add to scope. Returns
  // the number of flow facts created.
  //---------------------------------
  virtual int AddFlowFactsToScope(void) = 0;
  // Will call the more specialized version
  int GenerateFlowFacts(void);

  // ---------------------------------
  // Take a set of collectors, merge their internals and generate
  // context sensitive valid at entry of flow facts valid over CFG
  // nodes. Returns the number of flow facts created. Adds created ffs
  // to last argument. Collectors should be of CIterNodeCountCollector type.
  // ---------------------------------
  virtual int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                      std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,
                                                      std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs) = 0;  

  // ---------------------------------
  // For printing the collector
  // ---------------------------------
  virtual void Print(std::ostream *o=&std::cout) = 0;

  CScope * Scope() {return _scope;};

  // To get the number of updates made
  int NrOfReports() { return _nr_of_updates; }

protected:

  // The scope that the matrix is associated with
  CScope * _scope;

  // If only basic block start nodes should be collected
  bool _collect_only_basic_block_start_nodes;

  int _nr_of_updates;

};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CIterNodeCountCollector &a);

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CAllIterNodeCountCollector
// - Collector which collects all iterations of the same scope
//   together.  Keeping track of the nodes that never can be taken
//   during any iteration of the scope.
// - Creates  scope : <> : #node = 0   flow facts
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CAllIterNodeCountCollector : public CIterNodeCountCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CAllIterNodeCountCollector(CScope * scope);
  CAllIterNodeCountCollector(CScope * scope, bool collect_only_basic_block_start_nodes);
  virtual ~CAllIterNodeCountCollector(void);

  //----------------------------------
  // To update the collector with a new recorder. The recorder should be valid
  // for a certain iteration.
  //---------------------------------
  void Update(int iter, CIterNodeCountRecorder * rec);

  //----------------------------------
  // Create flow facts from the collector and add to scope. Returns
  // the number of flow facts created.
  //---------------------------------
  int AddFlowFactsToScope(void);

  // ---------------------------------
  // Take a set of collectors, merge their internals and generate
  // context sensitive valid at entry of flow facts valid over CFG
  // nodes. Returns the number of flow facts created. Adds created ffs
  // to last argument. Collectors should be of CIterNodeCountCollector type.
  // ---------------------------------
  int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                      std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,
                                                      std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);  

  // ---------------------------------
  // For printing the collector
  // ---------------------------------
  void Print(std::ostream *o=&std::cout);

protected:

  // We have a set keeping track of the nodes that has been taken.
  std::set<CECFGNode *> _taken_nodes;
};


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CEachIterNodeCountCollector
// - Collector which separates the iterations of the same scope.
//   Keeping track of the nodes that can never be taken during each
//   specific iteration of the scope.
// - Creates  scope : <i..j> : #node = 0  or
//            scope : <> : #node = 0  flow facts
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CEachIterNodeCountCollector : public CIterNodeCountCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CEachIterNodeCountCollector(CScope * scope);
  CEachIterNodeCountCollector(CScope * scope, bool collect_only_basic_block_start_nodes);
  virtual ~CEachIterNodeCountCollector(void);

  //----------------------------------
  // To update the collector with a new recorder. The recorder should be valid
  // for a certain iteration.
  //---------------------------------
  void Update(int iter, CIterNodeCountRecorder * rec);

  //----------------------------------
  // Create flow facts from the collector and add to scope. Returns
  // the number of flow facts created.
  //---------------------------------
  int AddFlowFactsToScope(void);

  // ---------------------------------
  // Take a set of collectors, merge their internals and generate
  // context sensitive valid at entry of flow facts valid over CFG
  // nodes. Returns the number of flow facts created. Adds created ffs
  // to last argument. Collectors should be of CIterNodeCountCollector type.
  // ---------------------------------
  int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                      std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,
                                                      std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);  

  // ---------------------------------
  // For printing the collector
  // ---------------------------------
  void Print(std::ostream *o=&std::cout);

protected:

  // We have a map between iterations and sets. Each set keep
  // tracks of nodes (their id:s) that has been taken during
  // the correponding iteration.
  std::map<int, std::set<CECFGNode *>*> _iter_to_taken_nodes;

  // To hold the largest iteration reported;
  int _max_iter_stored;
};

#endif



