/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CNodeCountCollector.cpp 7977 2018-11-23 15:36:56Z lkg02 $
//
// ----------------------------------------------------------------------

#include "ae/CNodeCountCollector.h"
#include "ae/CNodeCountRecorder.h"
#include "flow_facts/CIndexRange.h"
#include "graphs/scopes/CScope.h"
#include "flow_facts/CExpression.h"
#include "graphs/ecfg/CECFGNode.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/cfg/CFlowGraph.h"
#include "graphs/cg/CCallGraphNode.h"
#include "program/alf/AStmt.h"
#include "program/CGenericFunction.h"
#include "program/CGenericStmt.h"

using namespace std;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodeCountCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of collector
//----------------------------------
CNodeCountCollector::
CNodeCountCollector(CScope * scope, bool collect_only_basic_block_start_nodes, 
                    bool generate_lower_bound_ffs, bool generate_upper_bound_ffs)
  : _scope(scope), _collect_only_basic_block_start_nodes(collect_only_basic_block_start_nodes),
    _generate_lower_bound_ffs(generate_lower_bound_ffs), _generate_upper_bound_ffs(generate_upper_bound_ffs)
{
  _nr_of_updates = 0;
}


//----------------------------------
// Deletion of each a collector
//----------------------------------
CNodeCountCollector::
~CNodeCountCollector()
{
  // Go through the map deleting all the ranges
  std::map<CECFGNode *, CIntegerRange *>::iterator n2r;
  FORALL(n2r, _node_to_range_map)
    delete (*n2r).second;

  // The map itself will be removed together with the ocollector
}


//----------------------------------
// To update the collector with a new recording.
//---------------------------------
void
CNodeCountCollector::
Update(std::map<CECFGNode *, CIntegerRange *> * node_to_range_recording)
{
  // Increase the nr of updates
  _nr_of_updates++;

  // Treat first update especially
  if(_nr_of_updates == 1)
    {
      // Set nodes to consider (implemented by subclasses). Only
      // needed to do once.
      if(_nodes_to_consider.size() == 0) {
        // If we should collect all type of nodes
        if(!_collect_only_basic_block_start_nodes) {
          SetNodesToConsider(&_nodes_to_consider);
        }
        // If we should only collect nodes that start basic blocks
        else {
          std::set<CECFGNode *> temp_nodes_to_consider;
          SetNodesToConsider(&temp_nodes_to_consider);
          for(std::set<CECFGNode *>::iterator n = temp_nodes_to_consider.begin();
              n != temp_nodes_to_consider.end(); n++) {
            if((*n)->IsBeginOfBasicBlock()) {
              _nodes_to_consider.insert(*n);
            }
          }
        }
      }

      // Go through all nodes to consider
      set<CECFGNode *>::iterator node;
      FORALL(node, _nodes_to_consider)
        {
          // Check if the node exists in the recording
          if(node_to_range_recording->find(*node) != node_to_range_recording->end())
            {
              // Copy the range
              CIntegerRange* range = (*node_to_range_recording)[*node];
              _node_to_range_map[*node] = range->Copy();
            }
          else
            {
              // Create a new range consisting of only 0..0
              CIntegerRange* range = new CIntegerRange(0,0);
              _node_to_range_map[*node] = range;
            }
        }
    }
  else
    {
      // Remaining updates, the range has already been added in the
      // previous update. Go through all nodes in the graph
      std::map<CECFGNode *, CIntegerRange *>::iterator n2r;
      FORALL(n2r, _node_to_range_map)
        {
          // Get the node and the old range
          CECFGNode * node = (*n2r).first;
          CIntegerRange* old_range = (*n2r).second;

          // Check if the node exists in the recording
          if(node_to_range_recording->find(node) != node_to_range_recording->end())
            {
              // Yes, update the range
              CIntegerRange* rec_range = (*node_to_range_recording)[node];
              CIntegerRange* new_range = old_range->Merge(rec_range);
              _node_to_range_map[node] = new_range;
            }
          else
            {
              // No, merge a 0..0 range with the previous range
              CIntegerRange* rec_range = new CIntegerRange(0,0);
              CIntegerRange* new_range = old_range->Merge(rec_range);
              delete rec_range;
              _node_to_range_map[node] = new_range;
            }
          
          // Delete the old range
          delete old_range;
        }
    }

  // We are done, the ranges has been merged.
  return;
}

// The report function needs to be implemented
void
CNodeCountCollector::
Report(CRecorder * rec)
{
  CNodeCountRecorder * nc_rec = dynamic_cast<CNodeCountRecorder *>(rec);
  nc_rec->ReportToCollector(this);
}

// ---------------------------------
// To generate normal type flow facts
// ---------------------------------
int
CNodeCountCollector::
GenerateFlowFacts(void)
{
  int nr_of_added_flow_facts = 0;
  if(_generate_lower_bound_ffs) {
    CFlowFact::t_flowfacttype ff_type = GetLowerFlowFactType();
    nr_of_added_flow_facts += AddMinNodeCountFlowFactsToScope(ff_type);
  }
  if(_generate_upper_bound_ffs) {
    CFlowFact::t_flowfacttype ff_type = GetUpperFlowFactType();
    nr_of_added_flow_facts += AddMaxNodeCountFlowFactsToScope(ff_type);
  }
  return nr_of_added_flow_facts;
}


// ---------------------------------
// To generate context sensitive valid at entry of flow facts 
// ---------------------------------
int 
CNodeCountCollector::
GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  // To avoid unneccessary work
  if(!_generate_lower_bound_ffs && !_generate_upper_bound_ffs) return 0;

  // Create a mapping inbetween CFG nodes and ranges
  std::map<CFlowGraphNode *, CIntegerRange *> cfg_node_to_range_map;
  // Go through all collectors (they must be node count collectors) and add their included ranges
  bool map_created = false;
  for(std::set<CCollector *>::iterator c = collectors->begin(); c != collectors->end(); ++c) {
    CNodeCountCollector * nc_collector = dynamic_cast<CNodeCountCollector *>(*c);
    assert(nc_collector);

    // If the collector have not been updated so skip it
    if(nc_collector->NrOfReports() == 0) continue;

    // Check if it was the first collector in the set
    if(!map_created) {
      // Derive a CFG node to range map for the given collector
      nc_collector->DeriveCFGNodeToRangeMap(&cfg_node_to_range_map);
      map_created = true;
    }
    else {
      // Derive a temporary map for the given collector
      std::map<CFlowGraphNode *, CIntegerRange *> temp_cfg_node_to_range_map;
      nc_collector->DeriveCFGNodeToRangeMap(&temp_cfg_node_to_range_map);
      // Merge the old and temporary mappings
      for(std::map<CFlowGraphNode *, CIntegerRange *>::iterator tcn2r = temp_cfg_node_to_range_map.begin();
          tcn2r != temp_cfg_node_to_range_map.end(); ++tcn2r) {
        // Merge new and old range for cfg node
        CFlowGraphNode * cfg_node = (*tcn2r).first;
        CIntegerRange * range = (*tcn2r).second;
        assert(range);
        CIntegerRange * old_range = cfg_node_to_range_map[cfg_node];
        assert(old_range);
        CIntegerRange * new_range = range->Merge(old_range);
        cfg_node_to_range_map[cfg_node] = new_range;
        // Delete temporary ranges
        delete range;
        delete old_range;
      }
    }
  }

  int nr_of_flow_facts = 0;
  if(map_created) {
    // Generate the resulting flow facts by calling the right subordinate collector
    CCollector * c = *(collectors->begin());
    assert(c);
    CNodeCountCollector * nc_collector = dynamic_cast<CNodeCountCollector *>(c);
    assert(nc_collector);
    nr_of_flow_facts = nc_collector->GenerateContextSensitiveValidAtEntryOfFlowFacts(&cfg_node_to_range_map, 
                                                                                     call_string, 
                                                                                     valid_at_entry_of, ffs);
  
    // Delete temporary ranges
    for(std::map<CFlowGraphNode *, CIntegerRange *>::iterator cn2r = cfg_node_to_range_map.begin();
        cn2r != cfg_node_to_range_map.end(); ++cn2r) {
      delete (*cn2r).second;
    }
  }

  // Return the number of generate flow facts
  return nr_of_flow_facts;
}

//---------------------------------
// For printing the collector
//---------------------------------
void
CNodeCountCollector::
Print(ostream * o)
{
  (*o) << "type: " << Type() << endl;
  (*o) << "scope: " << _scope->Name() << endl;
  std::map<CECFGNode *, CIntegerRange *>::iterator n2r;
  FORALL(n2r, _node_to_range_map)
    {
      CECFGNode * node = (*n2r).first;
      string bb_name = node->GetFlowGraphNode()->Name();
      CIntegerRange* range = (*n2r).second;
      (*o) << "  " << bb_name << " = " << (*range) << endl;
    }
  (*o) << endl;
}

//---------------------------------
// Alternative printing function
//---------------------------------
ostream &operator << (ostream &o, CNodeCountCollector &a)
{
  a.Print(&o);
  return o;
}

// ---------------------------------
// To get the nodes to consider
// ---------------------------------
set<CECFGNode *> *
CNodeCountCollector::
NodesToConsider(void)
{
  // Set nodes to consider (implemented by subclasses)
  if(_nodes_to_consider.size() == 0)
    SetNodesToConsider(&_nodes_to_consider);
  return &_nodes_to_consider;
}

//----------------------------------
// Create upopert bound flow facts from the collector and add to scope
//---------------------------------
int
CNodeCountCollector::
AddMaxNodeCountFlowFactsToScope(CFlowFact::t_flowfacttype fftype)
{
  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;
  // Loop through all the nodes to consider
  std::map<CECFGNode *, CIntegerRange *>::iterator n2r;
  FORALL(n2r, _node_to_range_map)
    {
      // Get the node and the old range
      CECFGNode * node = (*n2r).first;
      CIntegerRange* range = (*n2r).second;

      // Get the range and min and max values of the node
      int64_t max_count = range->U();
      assert(range->L() <= max_count);

      // Check if the node is the header node of the scope to which
      // the collector belongs
      if(node != _scope->Header())
        {
          // Create a flow fact giving an upper bound on the number
          // of executions of the node: scope : [] : bb_name <= count

          // Create the bb_name =< count expression
          CExpressionECFGNode *max_id = new CExpressionECFGNode(node);
          CExpressionInt *max_eint = new CExpressionInt((int)max_count);
          CConstraint max_constraint(max_id, RELOP_LTEQ, max_eint);
          // Create the [] collector
          CFFCollector max_c(TOTAL);
          // Create the flow fact
          CFlowFact max_flow_fact(_scope, fftype, max_c, max_constraint);
          // Add the flow fact to the scope
          _scope->AddFlowFact(max_flow_fact);

          // Remember that we have added a flow fact
          nr_of_added_flow_facts++;

        } // end if not header

      else

        // The header node. Make a special flow facts
        {
          // Set the iteration count
          SetScopeIterationCount((int)max_count);

          // Remember that we have added a flow fact
          nr_of_added_flow_facts++;

        } // end else header

    } // end loop through all scope nodes

  // Return the number of flow facts added
  return nr_of_added_flow_facts;
}

//----------------------------------
// Create flow facts from the collector and add to scope
//---------------------------------
int
CNodeCountCollector::
AddMinNodeCountFlowFactsToScope(CFlowFact::t_flowfacttype fftype)
{
  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;

  // Loop through all the nodes to consider
  std::map<CECFGNode *, CIntegerRange *>::iterator n2r;
  FORALL(n2r, _node_to_range_map)
    {
      // Get the node and the old range
      CECFGNode * node = (*n2r).first;
      CIntegerRange* range = (*n2r).second;

      // Get the range and min and max values of the node
      int64_t min_count = range->L();

      // Create flow fact scope : [] : bb_name >= min_count

      // Do not create flow facts for 0
      if(min_count == 0) continue;
      
      // Create the bb_name >= count expression
      CExpressionECFGNode *min_id = new CExpressionECFGNode(node);
      CExpressionInt *min_eint = new CExpressionInt((int)min_count);
      CConstraint min_constraint(min_id, RELOP_GTEQ, min_eint);
      // Create the [] collector
      CFFCollector min_c(TOTAL);
      // Create the flow fact
      CFlowFact min_flow_fact(_scope, fftype, min_c, min_constraint);
      // Add the flow fact to the scope
      _scope->AddFlowFact(min_flow_fact);

      // Remember that we have added a flow fact
      nr_of_added_flow_facts++;

    } // end loop through all scope nodes

  // Return the number of flow facts added
  return nr_of_added_flow_facts;
}
 
void
CNodeCountCollector::SetScopeIterationCount(int count)
{
  // If the count has not been set we should set it
  if(!(_scope->HasValidIterationCount()))
    _scope->SetIterationCount(count);
  // If we have count smaller than current we should set it
  else if(count < _scope->IterationCount())
    _scope->SetIterationCount(count);
}

// ---------------------------------
// To generate context sensitive valid at entrty flow facts based on booleans
// ---------------------------------
int 
CNodeCountCollector::
GenerateContextSensitiveValidAtEntryOfFlowFacts(std::map<CFlowGraphNode *, CIntegerRange *> * cfg_node_to_range_map, 
                                                std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  int nr_of_added_flow_facts = 0;
  if(_generate_lower_bound_ffs) {
    CFlowFact::t_flowfacttype ff_type = GetLowerFlowFactType();
    nr_of_added_flow_facts += GenerateContextSensitiveValidAtEntryOfMinFlowFacts(cfg_node_to_range_map, call_string, 
                                                                                 valid_at_entry_of, ff_type, ffs);
  }
  if(_generate_upper_bound_ffs) {
    CFlowFact::t_flowfacttype ff_type = GetUpperFlowFactType();
    nr_of_added_flow_facts += GenerateContextSensitiveValidAtEntryOfMaxFlowFacts(cfg_node_to_range_map, call_string, 
                                                                                 valid_at_entry_of, ff_type, ffs);
  }
  return nr_of_added_flow_facts;
}

// ---------------------------------
// To generate upper bounds context sensitive valid at entry of flow facts
// ---------------------------------
int 
CNodeCountCollector::
GenerateContextSensitiveValidAtEntryOfMaxFlowFacts(std::map<CFlowGraphNode *, CIntegerRange *> * cfg_node_to_range_map, 
                                                   std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                   std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                   CFlowFact::t_flowfacttype ff_type,
                                                   std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;
  // Loop through mappings 
  std::map<CFlowGraphNode *, CIntegerRange *>::iterator n2r;
  FORALL(n2r, (*cfg_node_to_range_map))
    {
      // Get the node and the old range
      CFlowGraphNode * node = (*n2r).first;
      CIntegerRange* range = (*n2r).second;

      // If the node is the header node of the same scope as which the
      // flow fact is valid and the scope is a function scope, and we
      // will make function local or scope local flow facts, then now
      // flow fact should be generated.
      if((valid_at_entry_of.second == NULL && node->FlowGraph()->GetEntry() == node) && 
	 (ff_type == CFlowFact::UNSS || ff_type == CFlowFact::LNSS ||
	  ff_type == CFlowFact::UNSF || ff_type == CFlowFact::LNSF))
        continue;

      // Get the range and min and max values of the node
      int64_t max_count = range->U();
      assert(range->L() <= max_count);

      // Create the bb_name =< count expression
      CExpressionFlowGraphNode *max_id = new CExpressionFlowGraphNode(node);
      CExpressionInt *max_eint = new CExpressionInt((int)max_count);
      CConstraint * max_constraint = new CConstraint(max_id, RELOP_LTEQ, max_eint);
      // Create the [] collector
      CFFCollector * max_c = new CFFCollector(TOTAL);
      // Create the context senstive flow fact
      CContextSensitiveValidAtEntryOfFlowFact * ff = 
        new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, max_c, max_constraint, ff_type);
      // Add the flow fact to the vector 
      ffs->push_back(ff);

      // Remember that we have added a flow fact
      nr_of_added_flow_facts++;

    } // end loop through all scope nodes

  // Return the number of flow facts added
  return nr_of_added_flow_facts;
}

// ---------------------------------
// To generate lower bounds context sensitive valid at entrty flow facts
// ---------------------------------
int 
CNodeCountCollector::
GenerateContextSensitiveValidAtEntryOfMinFlowFacts(std::map<CFlowGraphNode *, CIntegerRange *> * cfg_node_to_range_map, 
                                                   std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                   std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                   CFlowFact::t_flowfacttype ff_type,
                                                   std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;
  // Loop through mappings 
  std::map<CFlowGraphNode *, CIntegerRange *>::iterator n2r;
  FORALL(n2r, (*cfg_node_to_range_map))
    {
      // Get the node and the old range
      CFlowGraphNode * node = (*n2r).first;
      CIntegerRange* range = (*n2r).second;

      // If the node is the header node of the same scope as which the
      // flow fact is valid and the scope is a function scope, then now flow fact
      // should be generated.
      if(valid_at_entry_of.second == NULL && node->FlowGraph()->GetEntry() == node)
        continue;

      // Get the range and min and max values of the node
      int64_t min_count = range->L();
      assert(min_count <= range->U());

      // Create the bb_name >= count expression
      CExpressionFlowGraphNode *min_id = new CExpressionFlowGraphNode(node);
      CExpressionInt *min_eint = new CExpressionInt((int)min_count);
      CConstraint * min_constraint = new CConstraint(min_id, RELOP_GTEQ, min_eint);
      // Create the [] collector
      CFFCollector * min_c = new CFFCollector(TOTAL);
      // Create the context sensitive flow fact
      CContextSensitiveValidAtEntryOfFlowFact * ff = 
        new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, min_c, min_constraint, ff_type);
      // Add the flow fact to the vector 
      ffs->push_back(ff);

      // Remember that we have added a flow fact
      nr_of_added_flow_facts++;

    } // end loop through all scope nodes

  // Return the number of flow facts added
  return nr_of_added_flow_facts;
}


 
// ---------------------------------
// Help function for deriving a cfg node to range mapping for a
// collector.  We need to do this in a separate function since
// several ecfg nodes may correspond to the same cfg node. 
// ---------------------------------
void
CNodeCountCollector::
DeriveCFGNodeToRangeMap(std::map<CFlowGraphNode *, CIntegerRange *> * cfg_node_to_range_map)
{
  for(std::map<CECFGNode *, CIntegerRange *>::iterator en2r = _node_to_range_map.begin();
      en2r != _node_to_range_map.end(); ++en2r) {
     CECFGNode * ecfg_node = (*en2r).first;
     CFlowGraphNode * cfg_node = ecfg_node->GetFlowGraphNode();
     CIntegerRange * range = (*en2r).second;
     // Check if the cfg node already has been added
     if(cfg_node_to_range_map->find(cfg_node) == cfg_node_to_range_map->end()) {
       // No, just copy the range for the ecfg node
       (*cfg_node_to_range_map)[cfg_node] = range->Copy();
     }
     else {
       // Yes, we have the case that the same CFG node correspond to
       // several ECFG nodes. The sum of ecfg node executions is
       // then the executions of the CFG node.
       CIntegerRange * old_range = (*cfg_node_to_range_map)[cfg_node];
       assert(old_range);
       CIntegerRange * new_range = new CIntegerRange(old_range->L() + range->L(), 
                                                     old_range->U() + range->U());
       delete old_range;
       (*cfg_node_to_range_map)[cfg_node] = new_range;
     }
   }
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodeCountScopeCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CNodeCountScopeCollector::
CNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                         bool generate_lower_bound_ffs, bool generate_upper_bound_ffs)
  : CNodeCountCollector(scope, collect_only_basic_block_start_nodes, 
                        generate_lower_bound_ffs, generate_upper_bound_ffs)
{
  // Do nothing
}

//----------------------------------
// To set the nodes to consider
//---------------------------------
void
CNodeCountScopeCollector::
SetNodesToConsider(set<CECFGNode *> * nodes_to_consider)
{
 // Call the wanted function in the scope
  _scope->NodesInScope(nodes_to_consider);
}

//--------------------------------------------------
// CMaxNodeCountScopeCollector
//-------------------------------------------------
CMaxNodeCountScopeCollector::
CMaxNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CNodeCountScopeCollector(scope, collect_only_basic_block_start_nodes, false, true)
{
  // Do nothing
}

//--------------------------------------------------
// CMinNodeCountScopeCollector
//-------------------------------------------------
CMinNodeCountScopeCollector::
CMinNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CNodeCountScopeCollector(scope, collect_only_basic_block_start_nodes, true, false)
{
  // Do nothing
}

//--------------------------------------------------
// CMinMaxNodeCountScopeCollector
//-------------------------------------------------
CMinMaxNodeCountScopeCollector::
CMinMaxNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CNodeCountScopeCollector(scope, collect_only_basic_block_start_nodes, true, true)
{
  // Do nothing
}


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodeCountScopeAndSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CNodeCountScopeAndSubCollector::
CNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                               bool generate_lower_bound_ffs, bool generate_upper_bound_ffs)
  : CNodeCountCollector(scope, collect_only_basic_block_start_nodes, 
                        generate_lower_bound_ffs, generate_upper_bound_ffs)
{
  // Do nothing
}


//----------------------------------
// To set the nodes to consider
//---------------------------------
void
CNodeCountScopeAndSubCollector::
SetNodesToConsider(set<CECFGNode *> * nodes_to_consider)
{
 // Call the wanted function in the scope
  _scope->NodesInScopeAndSubScopes(nodes_to_consider);
}

// ---------------------------------
// CMaxNodeCountScopeAndSubCollector
//----------------------------------
CMaxNodeCountScopeAndSubCollector::
CMaxNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CNodeCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, false, true)
{
  // Do nothing
}

// ---------------------------------
// CMinNodeCountScopeAndSubCollector
//----------------------------------
CMinNodeCountScopeAndSubCollector::
CMinNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CNodeCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, true, false)
{
  // Do nothing
}

// ---------------------------------
// CMinMaxNodeCountScopeAndSubCollector
//----------------------------------
CMinMaxNodeCountScopeAndSubCollector::
CMinMaxNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CNodeCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, true, true)
{
  // Do nothing
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodeCountScopeAndLoopSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CNodeCountScopeAndLoopSubCollector::
CNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                   bool generate_lower_bound_ffs, bool generate_upper_bound_ffs)
  : CNodeCountCollector(scope, collect_only_basic_block_start_nodes, 
                        generate_lower_bound_ffs, generate_upper_bound_ffs)
{
  // Do nothing
}

//----------------------------------
// To set the nodes to consider
//---------------------------------
void
CNodeCountScopeAndLoopSubCollector::
SetNodesToConsider(set<CECFGNode *> * nodes_to_consider)
{
 // Call the wanted function in the scope
  _scope->NodesInScopeAndLoopSubScopes(nodes_to_consider);
}

//----------------------------------
// CMaxNodeCountScopeAndLoopSubCollector
//----------------------------------
CMaxNodeCountScopeAndLoopSubCollector::
CMaxNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CNodeCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, false, true)
{
  // Do nothing
}

//----------------------------------
// CMinNodeCountScopeAndLoopSubCollector
//----------------------------------
CMinNodeCountScopeAndLoopSubCollector::
CMinNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CNodeCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, true, false)
{
  // Do nothing
}

//----------------------------------
// CMinMaxNodeCountScopeAndLoopSubCollector
//----------------------------------
CMinMaxNodeCountScopeAndLoopSubCollector::
CMinMaxNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CNodeCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, true, true)
{
  // Do nothing
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CHeaderNodeCountScopeCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CHeaderNodeCountScopeCollector::
CHeaderNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                               bool generate_lower_bound_ffs, bool generate_upper_bound_ffs)
  : CNodeCountCollector(scope, collect_only_basic_block_start_nodes, 
                        generate_lower_bound_ffs, generate_upper_bound_ffs)
{
  // Do nothing
}

//----------------------------------
// To set the nodes to consider
//---------------------------------
void
CHeaderNodeCountScopeCollector::
SetNodesToConsider(set<CECFGNode *> * nodes_to_consider)
{
 // Call the wanted function in the scope
  _scope->HeaderNodeInScope(nodes_to_consider);
}

//----------------------------------
// CMaxHeaderNodeCountScopeCollector
//----------------------------------
CMaxHeaderNodeCountScopeCollector::
CMaxHeaderNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CHeaderNodeCountScopeCollector(scope, collect_only_basic_block_start_nodes, false, true)
{
  // Do nothing
}

//----------------------------------
// CMinHeaderNodeCountScopeCollector
//----------------------------------
CMinHeaderNodeCountScopeCollector::
CMinHeaderNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CHeaderNodeCountScopeCollector(scope, collect_only_basic_block_start_nodes, true, false)
{
  // Do nothing
}

//----------------------------------
// CMinMaxHeaderNodeCountScopeCollector
//----------------------------------
CMinMaxHeaderNodeCountScopeCollector::
CMinMaxHeaderNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CHeaderNodeCountScopeCollector(scope, collect_only_basic_block_start_nodes, true, true)
{
  // Do nothing
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CHeaderNodeCountScopeAndSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CHeaderNodeCountScopeAndSubCollector::
CHeaderNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                     bool generate_lower_bound_ffs, bool generate_upper_bound_ffs)
  : CNodeCountCollector(scope, collect_only_basic_block_start_nodes, 
                        generate_lower_bound_ffs, generate_upper_bound_ffs)
{
  // Do nothing
}

//----------------------------------
// To set the nodes to consider
//---------------------------------
void
CHeaderNodeCountScopeAndSubCollector::
SetNodesToConsider(set<CECFGNode *> * nodes_to_consider)
{
 // Call the wanted function in the scope
  _scope->HeaderNodesInScopeAndSubScopes(nodes_to_consider);
}

//----------------------------------
// CMaxHeaderNodeCountScopeAndSubCollector
//----------------------------------
CMaxHeaderNodeCountScopeAndSubCollector::
CMaxHeaderNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CHeaderNodeCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, false, true)
{
  // Do nothing
}

//----------------------------------
// CMinHeaderNodeCountScopeAndSubCollector
//----------------------------------
CMinHeaderNodeCountScopeAndSubCollector::
CMinHeaderNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CHeaderNodeCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, true, false)
{
  // Do nothing
}

//----------------------------------
// CMinMaxHeaderNodeCountScopeAndSubCollector
//----------------------------------
CMinMaxHeaderNodeCountScopeAndSubCollector::
CMinMaxHeaderNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CHeaderNodeCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, true, true)
{
  // Do nothing
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CHeaderNodeCountScopeAndLoopSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CHeaderNodeCountScopeAndLoopSubCollector::
CHeaderNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                         bool generate_lower_bound_ffs, bool generate_upper_bound_ffs)
  : CNodeCountCollector(scope, collect_only_basic_block_start_nodes, 
                        generate_lower_bound_ffs, generate_upper_bound_ffs)
{
  // Do nothing
}

//----------------------------------
// To set the nodes to consider
//---------------------------------
void
CHeaderNodeCountScopeAndLoopSubCollector::
SetNodesToConsider(set<CECFGNode *> * nodes_to_consider)
{
 // Call the wanted function in the scope
  _scope->HeaderNodesInScopeAndLoopSubScopes(nodes_to_consider);
}

//----------------------------------
// CMaxHeaderNodeCountScopeAndLoopSubCollector
//----------------------------------
CMaxHeaderNodeCountScopeAndLoopSubCollector::
CMaxHeaderNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CHeaderNodeCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, false, true)
{
  // Do nothing
}

//----------------------------------
// CMinHeaderNodeCountScopeAndLoopSubCollector
//----------------------------------
CMinHeaderNodeCountScopeAndLoopSubCollector::
CMinHeaderNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CHeaderNodeCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, true, false)
{
  // Do nothing
}

//----------------------------------
// CMinMaxHeaderNodeCountScopeAndLoopSubCollector
//----------------------------------
CMinMaxHeaderNodeCountScopeAndLoopSubCollector::
CMinMaxHeaderNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CHeaderNodeCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, true, true)
{
  // Do nothing
}







