/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id:  $
//
// ----------------------------------------------------------------------

#ifndef CRecorderHolder_H_
#define CRecorderHolder_H_

#include "CRecorder.h"
#include "CCollector.h"
#include "../graphs/ecfg/CECFGNode.h"
#include "../graphs/scopes/CScope.h"

// Standard includes
#include <map>
#include <string>
#include <iostream>
#include <fstream>

// ---------------------------------
// CRecorderHolder
//   |- CScopeRecorderHolder
//   |- CIterRecorderHolder
//   |- CLoopNestRecorderHolder
//   |- CFunctionRecorderHolder
//   |- CProgramRecorderHolder
//   |- CScopeIndexRecorderHolder
// ---------------------------------

// -------------------------------------------------------
// CScopeRecorderHolder
// 
// A recorder holder contains (1) one (or more) recorders, (2) one
// recorder_server used to create, delete and update recorders (3) a
// way of mapping recorder(s) to collectors.  
// 
// Different subclasses will create different amount of recorders,
// and reset, update, report recorders to collectors differently. 
// 
// The recorder holders require that: 
// (i) All used recorders inherits from CRecorder and exports the following
// functionality: Update(pc_bef, aft), Merge(r), Copy(), Reset().
// (ii) All used recorder servers inherits from CRecorderServer and exports
// the functions: CreateRecorder(), CopyRecorder(r), MergeRecorders(r1, r2), 
// ResetRecorder(r) and UpdateRecorderWithProgramCounterChange(r, bef, aft)
// (iii) All used collectors inherits from CCollector and exports the
// following functionality: Report(recorder) or Report(iter, recorder).
// -------------------------------------------------------
class CRecorderHolder 
{
public:
  // No create or delete function...
  virtual ~CRecorderHolder() {};

  // Update the recorder holder with a program start 
  virtual void UpdateWithProgramStart(CECFGNode * PC_after) = 0;

  // Update the recorder holder with the change of PC. 
  virtual void UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after) = 0;
     
  // Update the recorder holder with a program exit 
  virtual void UpdateWithProgramExit(CECFGNode * PC_before) = 0;

  // Deep copy of the whole recorder holder.
  virtual CRecorderHolder * Copy() = 0;

  // To merge two record holders
  virtual CRecorderHolder * Merge(CRecorderHolder *) = 0;

  // For printing the recorder holder
  virtual void Print(std::ostream * = &std::cout) = 0;

};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CRecorderHolder &a);

// =======================================================
// =======================================================
// CScopeRecorderHolder -
// A recorder holds for which keeps track of scope local information.
// Basically, to each scope we associate a recorder. When the execution
// cross scope borders the recorders and saved, reset or reported to their
// collectors. 
// =======================================================
// =======================================================
class CScopeRecorderHolder : public CRecorderHolder
{
public:
  
  // To create a new local header recorder holder, we need a way to
  // associate collectors and scopes. We also need a recorder server
  // which will be used to create, delete, and update the recorders.
  // The map is owned by the caller. 
  CScopeRecorderHolder(std::map<CScope *, CCollector *> * scope_to_collector_map, 
                       CRecorderServer * recorder_server);
  virtual ~CScopeRecorderHolder();

  // Update the recorder holder with a program start 
  virtual void UpdateWithProgramStart(CECFGNode * PC_after);

  // Update the recorder holder with the change of PC. 
  virtual void UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after);
     
  // Update the recorder holder with a program exit 
  virtual void UpdateWithProgramExit(CECFGNode * PC_before);

  // Deep copy of the whole recorder holder. 
  virtual CScopeRecorderHolder * Copy();

  // To merge two record holders. 
  virtual CScopeRecorderHolder * Merge(CRecorderHolder *);

  // For printing the recorder holder
  void Print(std::ostream *);

protected:

  // Internal function that calls the correct recorder's update function.
  void UpdateRecorderWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after);
  void UpdateRecorderWithProgramExit(CECFGNode * PC_before);
  
  // Function helps us implement reuse of recorders. Basically, if
  // there already exists a recorder for the scope we will use this one
  // instead of creating a new one. Will use the below map to associate
  // the scope to the created recorder. 
  virtual void CreateRecorderForScopeIfNeeded(CScope * scope);

  // To reset the recorder for a certain scope. Assumes that the map
  // holds a connection between the scope and a certain recorder.
  virtual void ResetRecorderForScope(CScope * scope);

  // To report the recorder for a certain scope to the collector.
  virtual void ReportRecorderForScopeToCollector(CScope * scope);

  // Help function for copying a scope local recorder holder
  void CopySavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders, 
                          std::map<CScope *, CRecorder *> * new_saved_recorders);

  // Help functiopn for merging two scope local recorder holder
  void MergeSavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders1, 
                           std::map<CScope *, CRecorder *> * saved_recorders2,
                           std::map<CScope *, CRecorder *> * new_saved_recorders);

  // A mapping for letting us associate collectors to different
  // scopes. The mapping is not allowed to be updated nor deleted,
  // i.e. it is shared between all recorder holders.
  std::map<CScope *, CCollector *> * _scope_to_collector_map;

  // Server used to generate new recorders. The server is also shared
  // by all the recorders of the same type.
  CRecorderServer * _recorder_server;

  // Holding non-current recorders (index upon scopes). To avoid to
  // much creation and deletion we will only create recorders when
  // actually needed, and instead of deleting them they will be reset.
  std::map<CScope *, CRecorder *> _saved_recorders;
   
};

// =======================================================
// =======================================================
// CIterRecorderHolder -
// A recorder holder which keeps track of iteration local information.
// Similar functionality as the scope local recorder holder, such as
// stacking, resetting and creation of new recorders when entering and
// exiting scopes. Additionally, we also keep track of, for each
// scope, its current iteration number, using _saved_iterations
// map. Will also report in result to the collector and reset the
// recorder whenever a new iterations is made for a scope.
// =======================================================
// =======================================================
class CIterRecorderHolder : public CRecorderHolder
{
public:
  
  // To create a new local header recorder holder, we need a way to associate collectors
  // and scopes. We also need a server which will be used to create, delete, and update the recording.
  // The map will be owned by the recorder.
  CIterRecorderHolder(std::map<CScope *, CCollector *> * scope_to_collector_map, 
                      CRecorderServer * recorder_server);
  virtual ~CIterRecorderHolder();

 // Update the recorder holder with a program start 
  virtual void UpdateWithProgramStart(CECFGNode * PC_after);

  // Update the recorder holder with the change of PC. 
  virtual void UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after);
     
  // Update the recorder holder with a program exit 
  virtual void UpdateWithProgramExit(CECFGNode * PC_before);

  // Deep copy of the whole recorder holder.
  virtual CIterRecorderHolder * Copy();

  // To merge two record holders. 
  virtual CIterRecorderHolder * Merge(CRecorderHolder *);

  // For printing the recorder holder
  void Print(std::ostream *);

protected:

  // Internal function that calls the correct recorder's update function.
  void UpdateRecorderWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after);
  void UpdateRecorderWithProgramExit(CECFGNode * PC_before);

  // Functions used to create and reset recorders and iterations. 
  void CreateRecorderForScopeIfNeeded(CScope * scope);
  void ResetRecorderForScope(CScope * scope);
  void CreateIterationsForScope(CScope * scope);
  void ResetIterationsForScope(CScope * scope);
  void IncreaseIterationsForScope(CScope * scope);
  void ReportIterationsAndRecorderForScopeToCollector(CScope * scope);

  // Help function for copying and merging saved iteration numbers
  void CopySavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders, 
			  std::map<CScope *, CRecorder *> * new_saved_recorders);
  void CopySavedIterations(std::map<CScope *, int> * saved_iterations, 
			   std::map<CScope *, int> * new_saved_iterations);
  void MergeSavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders1, 
			   std::map<CScope *, CRecorder *> * saved_recorders2,
			   std::map<CScope *, CRecorder *> * new_saved_recorders);
  void MergeSavedIterations(std::map<CScope *, int> * saved_iterations1, 
			    std::map<CScope *, int> * saved_iterations2, 
			    std::map<CScope *, int> * new_saved_iterations);

  // A mapping for letting us associate collectors to different
  // scopes. The mapping is not allowed to be updated nor deleted,
  // i.e. it is shared between all recorder holders.
  std::map<CScope *, CCollector *> * _scope_to_collector_map;

  // Server used to generate new recorders. The server is also shared
  // by all the recorders of the same type.
  CRecorderServer * _recorder_server;

  // Holding non-current recorders (index upon scopes). To avoid to
  // much creation and deletion we will only create recorders when
  // actually needed, and instead of deleting them they will be reset.
  std::map<CScope *, CRecorder *> _saved_recorders;

  // Map holding current iteration of each scope. Will be updated in the
  // functions which updates recorders.
  std::map<CScope *, int> _saved_iterations;
};



// =======================================================
// =======================================================
// CFunctionRecorderHolder -
// A recorder holder for which keeps track of function local information.
// Basically, to each function scope we associate a recorder (note that 
// the same function can appear in several scopes). When the execution
// cross function borders the recorders are saved, reset or reported to their
// collectors. 
// =======================================================
// =======================================================
class CFunctionRecorderHolder : public CRecorderHolder
{
public:
  
  // To create a new local header recorder holder, we need a way to
  // associate collectors to function scopes. We also need a recorder
  // server which will be used to create, delete, and update the
  // recorders. The map is owned by the caller. 
  CFunctionRecorderHolder(std::map<CScope *, CCollector *> * func_scope_to_collector_map, 
                          CRecorderServer * recorder_server);
  virtual ~CFunctionRecorderHolder();

  // Update the recorder holder with a program start 
  virtual void UpdateWithProgramStart(CECFGNode * PC_after);

  // Update the recorder holder with the change of PC. 
  virtual void UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after);
     
  // Update the recorder holder with a program exit 
  virtual void UpdateWithProgramExit(CECFGNode * PC_before);

  // Deep copy of the whole recorder holder. 
  virtual CFunctionRecorderHolder * Copy();

  // To merge two record holders. 
  virtual CFunctionRecorderHolder * Merge(CRecorderHolder *);

  // For printing the recorder holder
  void Print(std::ostream *);

protected:

  // Internal function that calls the correct recorder's update function.
  void UpdateRecorderWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after);
  void UpdateRecorderWithProgramExit(CECFGNode * PC_before);
  
  // Function helps us implement reuse of recorders. Basically, if
  // there already exists a recorder for the scope we will use this one
  // instead of creating a new one. Will use the below map to associate
  // the scope to the created recorder. 
  virtual void CreateRecorderForFunctionScopeIfNeeded(CScope * scope);

  // To reset the recorder for a certain scope. Assumes that the map
  // holds a connection between the scope and a certain recorder.
  virtual void ResetRecorderForFunction(CScope * scope);

  // To report the recorder for a certain scope to the collector.
  virtual void ReportRecorderForFunctionToCollector(CScope * scope);

  // Help function for copying a scope local recorder holder
  void CopySavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders, 
			  std::map<CScope *, CRecorder *> * new_saved_recorders);

  // Help functiopn for merging two scope local recorder holder
  void MergeSavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders1, 
			   std::map<CScope *, CRecorder *> * saved_recorders2,
			   std::map<CScope *, CRecorder *> * new_saved_recorders);

  // A mapping for letting us associate collectors to different
  // scopes. The mapping is not allowed to be updated nor deleted,
  // i.e. it is shared between all recorder holders.
  std::map<CScope *, CCollector *> * _func_scope_to_collector_map;

  // Server used to generate new recorders. The server is also shared
  // by all the recorders of the same type.
  CRecorderServer * _recorder_server;

  // Holding non-current recorders (index upon func scopes). To avoid to
  // much creation and deletion we will only create recorders when
  // actually needed, and instead of deleting them they will be reset.
  std::map<CScope *, CRecorder *> _saved_recorders;
 
};

// =======================================================
// =======================================================
// CProgramRecorderHolder -
// A recorder holder which keeps track of global information valid
// from the beginning of the program run until the end of the program
// run. It can for example be used with recorders which keeps track on
// the number of times ECFGNodes are taken at most during a whole
// program run. No stacking of recorders are needed.
// =======================================================
// =======================================================
class CProgramRecorderHolder : public CRecorderHolder
{
public:
  
  // To create a global recorder holder, we need a way to associate
  // collectors and scopes. We also need a server which will be used
  // to create, delete, and update the recorders.
  CProgramRecorderHolder(CCollector * collector, CRecorderServer * recorder_server);
  CProgramRecorderHolder(std::map<CScope *, CCollector *> * root_scope_to_collector_map, CRecorderServer * recorder_server);
  virtual ~CProgramRecorderHolder();

  // Update the recorder holder with a program start 
  virtual void UpdateWithProgramStart(CECFGNode * PC_after);

  // Update the recorder holder with the change of PC. 
  virtual void UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after);
     
  // Update the recorder holder with a program exit 
  virtual void UpdateWithProgramExit(CECFGNode * PC_before);

  // Deep copy of the whole recorder holder. 
  virtual CProgramRecorderHolder * Copy();

  // To merge two record holders. 
  virtual CProgramRecorderHolder * Merge(CRecorderHolder *);

  // For printing the recorder holder
  void Print(std::ostream *);

protected:

  // A mapping for letting us associate collectors to different
  // scopes. The mapping is not allowed to be updated nor deleted,
  // i.e. it is shared between all recorder holders.
  CCollector * _collector;

  // Server used to generate new recorders. The server is also shared
  // by all the recorders of the same type.
  CRecorderServer * _recorder_server;

  // Holding the recorder used
  CRecorder * _recorder;
   
};
  


// =======================================================
// =======================================================
// CLoopNestRecorderHolder -
// A recorder holder for which keeps track of loop nest information.
// Basically, to each loop nest we associate a recorder (note that 
// the same loop nest can appear in several scopes). When the execution
// cross loop nest borders recorders are saved, reset or reported to their
// collectors. 
// =======================================================
// =======================================================
class CLoopNestRecorderHolder : public CRecorderHolder
{
public:

  // To create a new local header recorder holder, we need a way to
  // associate collectors to function scopes. We also need a recorder
  // server which will be used to create, delete, and update the
  // recorders. The map is owned by the caller. 
  CLoopNestRecorderHolder(std::map<CScope *, CCollector *> * loop_nest_root_scope_to_collector_map, 
			  CRecorderServer * recorder_server);
  virtual ~CLoopNestRecorderHolder();

  // Update the recorder holder with a program start 
  virtual void UpdateWithProgramStart(CECFGNode * PC_after);

  // Update the recorder holder with the change of PC. 
  virtual void UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after);
     
  // Update the recorder holder with a program exit 
  virtual void UpdateWithProgramExit(CECFGNode * PC_before);

  // Deep copy of the whole recorder holder. 
  virtual CLoopNestRecorderHolder * Copy();

  // To merge two record holders. 
  virtual CLoopNestRecorderHolder * Merge(CRecorderHolder *);

  // For printing the recorder holder
  void Print(std::ostream *);

protected:

  // Internal function that calls the correct recorder's update function.
  void UpdateRecorderWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after);
  void UpdateRecorderWithProgramExit(CECFGNode * PC_before);
  
  // LoopNest helps us implement reuse of recorders. Basically, if
  // there already exists a recorder for the scope we will use this one
  // instead of creating a new one. Will use the below map to associate
  // the scope to the created recorder. 
  virtual void CreateRecorderForLoopNestRootScopeIfNeeded(CScope * scope);

  // To reset the recorder for a certain scope. Assumes that the map
  // holds a connection between the scope and a certain recorder.
  virtual void ResetRecorderForLoopNest(CScope * scope);

  // To report the recorder for a certain scope to the collector.
  virtual void ReportRecorderForLoopNestToCollector(CScope * scope);

  // Help function for copying a scope local recorder holder
  void CopySavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders, 
			  std::map<CScope *, CRecorder *> * new_saved_recorders);

  // Help functiopn for merging two scope local recorder holder
  void MergeSavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders1, 
			   std::map<CScope *, CRecorder *> * saved_recorders2,
			   std::map<CScope *, CRecorder *> * new_saved_recorders);

  // A mapping for letting us associate collectors to different
  // scopes. The mapping is not allowed to be updated nor deleted,
  // i.e. it is shared between all recorder holders.
  std::map<CScope *, CCollector *> * _loop_nest_root_scope_to_collector_map;

  // Server used to generate new recorders. The server is also shared
  // by all the recorders of the same type.
  CRecorderServer * _recorder_server;

  // Holding non-current recorders (index upon func scopes). To avoid to
  // much creation and deletion we will only create recorders when
  // actually needed, and instead of deleting them they will be reset.
  std::map<CScope *, CRecorder *> _saved_recorders;
 
};

// =======================================================
// =======================================================
// CScopeIndexRecorderHolder -
// A recorder holder which maintain a vector of <scope,iter> pairs.
// Keep track of where we are in our execution.
// Used to determine if two abstract states are allowed to be merged.
// Does not report to a collector.
// =======================================================
// =======================================================
class CScopeIndexRecorderHolder : public CRecorderHolder
{
public:

   // ---------------------------------
   // Public stuff
   // ---------------------------------

   // For creating and deleting a scope index recorder holder
   CScopeIndexRecorderHolder();
   virtual ~CScopeIndexRecorderHolder();

   // For checking if a scope index recorder is equal to another. 
   bool IsEqual(CScopeIndexRecorderHolder * sirh);

   bool IsLessThan(const CScopeIndexRecorderHolder * sirh) const;

   // For checking if the scope index recorder is empty
   bool IsEmpty();

   // For copying a scope index recorder holder
   CScopeIndexRecorderHolder * Copy(void);

   // Update the recorder holder with a program start 
   void UpdateWithProgramStart(CECFGNode * PC_after);

   // Update the recorder holder with the change of PC. 
   void UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after);

   // Update the recorder holder with a program exit 
   void UpdateWithProgramExit(CECFGNode * PC_before);

   // To merge two record holders. Will assert if they are different.
   virtual CScopeIndexRecorderHolder * Merge(CScopeIndexRecorderHolder *);
   // Will call the more specialized version
   virtual CScopeIndexRecorderHolder * Merge(CRecorderHolder *);

   // For printing the scope index recorder holder
   void Print(std::ostream * o);

protected:
   // ---------------------------------
   // Internal classes
   // ---------------------------------
   class CompareScopeIterCountPairs;

   // ---------------------------------
   // Help functions used by update functions
   // ---------------------------------

   // Add a scope and an iteration for the scope.  Will add the scope
   // on the top of the stack and set its iter count to one. The scope
   // should not be on the call stack already.
   void AddScopeIterationPair(CScope * scope);

   // Increment iterations of scope
   void IncrementIterationOfScope(CScope * scope);

   // Remove (s) scope iteration pair(s)
   void RemoveScopeIterationPair(CScope * scope);
   void RemoveAllScopeIterationPairs();

   // ---------------------------------
   // Internal data structures
   // ---------------------------------
   std::vector<std::pair<CScope *, unsigned int> > _siv;
};

#endif
