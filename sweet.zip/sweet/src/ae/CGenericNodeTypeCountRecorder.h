/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE: Holds code for keeping track of the types of statements,
//  operators, etc processed during a states' execution. The types to keep 
//  track of are given by CGenericNode::TYPE. The recorder should be
//  managed by a CGlobalRecorderHolder, i.e. it should only be calling
//  the collector at the end of the execution. 
//
//  Internally, the recorder keeps a map<type,count>, where the count
//  (which is an integer range) for a type is increased by one for
//  each time the type is encountered in a processed statement. The
//  Update() function, which is called by the AE mechanism whenever a
//  state should process a new ECFG node, will extract the stmt from
//  the ECFG node, and the update the map<type,count> by when
//  traversing the abstract syntax tree of the stmt. 
// 
//  Authors: andreas.ermedahl@mdh.se, p.altenbernd@fbi.h-da.de
//
// ----------------------------------------------------------------------
//
//  $Id: $
//
// ----------------------------------------------------------------------

#ifndef CGenericNodeTypeCountRecorder_H_
#define CGenericNodeTypeCountRecorder_H_

#include <map>

// To get the CIntegerRange representation
#include "CIntegerRange.h"
// To get the enum of stmt,operation,... types
#include "program/alf/CGenericNode.h"
// To get the enum of op types
#include "program/alf/COpNumExprTuple.h"
// To get the CECFG node representation
#include "graphs/ecfg/CECFGNode.h"
// To get the statement types used 
#include "program/CGenericStmt.h"
// To get the CRecorder and CRecorderServer base classes
#include "ae/CRecorder.h"

// Predefine class (should be changed to an include)
class CGenericNodeTypeCountCollector;


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CGenericNodeTypeCountRecorder
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CGenericNodeTypeCountRecorder : public CRecorder
{
public:

  // ---------------------------------
  // To create and delete the recorder
  // ---------------------------------
  CGenericNodeTypeCountRecorder(bool record_generic_nodes=true, bool record_op_types=true,
                                bool record_stmts=true, bool record_stmt_pairs=true);
  virtual ~CGenericNodeTypeCountRecorder(void);

  //----------------------------------
  // To update the recorder with a new execution of a the statement held
  // by the pc_before node 
  //---------------------------------

  // The function will extract the statement in the pc_before
  // node. Then it will traverse the content of the statement using
  // the recursive help function TraverseRecursively(). For each
  // CGenericNode type, for each time it is encountered, it will
  // increase its count in the map.
  void UpdateWithProgramCounterChange(CECFGNode * pc_before, CECFGNode * pc_after);
  void UpdateWithProgramExit(CECFGNode * pc_before);

  //----------------------------------
  // Reset recorder. Will remove all CGenericNode type to range mappings.
  //---------------------------------
  void Reset(void);

  // ---------------------------------
  // To report the content of the recorder to the collector
  // ---------------------------------
  // void ReportToCollector(CGenericNodeTypeCountCollector * collector);

  //----------------------------------
  // To copy the recorder
  //---------------------------------
  CGenericNodeTypeCountRecorder * Copy();

  //----------------------------------
  // To merge two recorders (LUB). For each type take the LUB of their ranges. 
  //---------------------------------
  CGenericNodeTypeCountRecorder * Merge(CGenericNodeTypeCountRecorder * other_recorder);
  // Below, will call the more specialized Merge() function...
  CRecorder * Merge(CRecorder * other_recorder);

  // ---------------------------------
  // For printing the recorder
  // ---------------------------------
  void Print() {Print(&std::cout);};
  void Print(std::ostream * o);

  // ---------------------------------
  // To decide what to record
  // ---------------------------------
  bool RecordGenericNodes() { return _record_generic_nodes; }
  bool RecordOpTypes() { return _record_op_types; }
  bool RecordStmts() { return _record_stmts; }
  bool RecordStmtPairs() { return _record_stmt_pairs; }

  //----------------------------------
  // To get the internal map (to be reported to the collector)
  //----------------------------------
  std::map<alf::CGenericNode::TYPE, CIntegerRange*> * GetTypeToRangeMap() { return &_type_to_range_map; };
  std::map<alf::COpNumExprTuple::OP_TYPE, CIntegerRange*> * GetOpTypeToRangeMap() { return &_op_type_to_range_map; };
  std::map<CGenericStmt::GS_TYPE, CIntegerRange*> * GetStmtToRangeMap() { return &_stmt_to_range_map; };
  std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*> * GetStmtPairToRangeMap() { return &_stmt_pair_to_range_map; };

protected:

  // To increase the count of a certain CGenericNode type. 
  void IncreaseCount(alf::CGenericNode::TYPE type); 
  // To set the range of a certain type
  void SetRange(alf::CGenericNode::TYPE type, CIntegerRange* range);

  // To increase the count of a certain operator type. 
  void IncreaseCount(alf::COpNumExprTuple::OP_TYPE op_type); 
  // To set the range of a certain op type
  void SetRange(alf::COpNumExprTuple::OP_TYPE type, CIntegerRange* range);

 // To increase the count of a certain stmt type
  void IncreaseCount(CGenericStmt::GS_TYPE stmt); 
  // To set the range of a certain stmt type
  void SetRange(CGenericStmt::GS_TYPE stmt, CIntegerRange* range);

 // To increase the count of a certain stmt pair
  void IncreaseCount(std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE> stmt_pair); 
  // To set the range of a certain stmt pair
  void SetRange(std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE> stmt_pair, CIntegerRange* range);

  // Recursive help function for reporting in all node types in a
  // stmt.  Will increase the count of the type of the argument node,
  // and then call the function recursively with all its children
  // generic nodes in the ALF syntax tree. 
  void TraverseRecursivelyAndCountTypeOccurrences(const CGenericStmt * stmt);

  // A mapping between node types and ranges. 
  std::map<alf::CGenericNode::TYPE, CIntegerRange*> _type_to_range_map;
  
  // A mapping inbetween operator types and ranges. 
  std::map<alf::COpNumExprTuple::OP_TYPE, CIntegerRange*> _op_type_to_range_map;

  // A mapping between generic statement types and ranges. 
  std::map<CGenericStmt::GS_TYPE, CIntegerRange*> _stmt_to_range_map;

  // A mapping between generic statement types and ranges. 
  std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*> _stmt_pair_to_range_map;

  // Holds the things to record
  bool _record_generic_nodes;
  bool _record_op_types;
  bool _record_stmts;
  bool _record_stmt_pairs;

};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CGenericNodeTypeCountRecorder &a);



//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CGenericNodeTypeCountRecorderServer
// - Server for generating new node count recorders
// - To inherit from
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CGenericNodeTypeCountRecorderServer : public CRecorderServer
{
public:

  // To create a node count recorder server. 
  CGenericNodeTypeCountRecorderServer(bool record_generic_nodes, bool record_op_types, 
                                      bool record_stmts, bool record_stmt_pairs);
  virtual ~CGenericNodeTypeCountRecorderServer() {};

  // For creating a new recorder. Will allocate the recorder and add
  // <recorderptr,1> to the map.
  CGenericNodeTypeCountRecorder * CreateRecorder();

  // For deleting a recorder. When deleting a recorder then <recorderptr, i> ->
  // <recorderptr, i-1> If i-1 == 0 then remove recorder for real.
  void DeleteRecorder(CGenericNodeTypeCountRecorder *  recorder);
  // Will call the more specialized delete function...
  void DeleteRecorder(CRecorder * recorder);

  // To copy the recorder.
  virtual CGenericNodeTypeCountRecorder * CopyRecorder(CGenericNodeTypeCountRecorder * recorder) = 0;
  // Will call the more specialized copy function...
  CRecorder * CopyRecorder(CRecorder * recorder);

  // To count the types found iun the statement held by the node. Might return a 
  // new recorder. Ie. the caller should reset its _recorder to the recorder returned.
  virtual CGenericNodeTypeCountRecorder * UpdateRecorderWithProgramCounterChange(CGenericNodeTypeCountRecorder * rec, 
                                                                                 CECFGNode * pc_before, CECFGNode * pc_after) = 0;
  virtual CGenericNodeTypeCountRecorder * UpdateRecorderWithProgramExit(CGenericNodeTypeCountRecorder * rec, 
                                                                        CECFGNode * pc_before) = 0;
  // Will call the more specialized update function...
  void UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after);
  void UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before);

	using CRecorderServer::UpdateRecorderWithProgramCounterChange;
	
	using CRecorderServer::UpdateRecorderWithProgramExit;
	
  // To reset the recorder. Might return a new recorder. Ie.  the
  // caller should reset its _recorder to the recorder returned.
  virtual CGenericNodeTypeCountRecorder * ResetRecorder(CGenericNodeTypeCountRecorder * recorder) = 0;
  // Will call the more specialized reset function...
  void ResetRecorder(CRecorder ** recorder);

  // To merge two recorders. Return a new recorder.
  virtual CGenericNodeTypeCountRecorder * MergeRecorders(CGenericNodeTypeCountRecorder * recorder1,
                                                         CGenericNodeTypeCountRecorder * recorder2) = 0;
  // Will call the more specialized merge function...
  CRecorder * MergeRecorders(CRecorder * rec1, CRecorder * rec2);

  // For printing the server
  void Print() {Print(&std::cout);};
  void Print(std::ostream * o);

protected:
  // All recorders are accessible from server by the <recorderptr, refs> map.
  // refs is a counter holding the number of references to the recorder.
  std::map<CGenericNodeTypeCountRecorder *, int64_t> _recorder_to_refs;

  // Holds the things to record
  bool _record_generic_nodes;
  bool _record_op_types;
  bool _record_stmts;
  bool _record_stmt_pairs;
};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CGenericNodeTypeCountRecorderServer &a);

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CGenericNodeTypeCountRecorderCOWServer
// - Recorder server for generating new recorders according to
// copy on write. Most functionality is inherited from CGenericNodeTypeCountRecorderServer.
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CGenericNodeTypeCountRecorderCOWServer : public CGenericNodeTypeCountRecorderServer
{
public:

  // To create a COW node count recorder server. 
  CGenericNodeTypeCountRecorderCOWServer(bool record_generic_nodes, bool record_op_types, 
                                         bool record_stmts, bool record_stmt_pairs);
  virtual ~CGenericNodeTypeCountRecorderCOWServer();

  // For copying the recorder using copy on write. Will not do any copying
  // right away, instead it will just update the map as: <recorderptr, i>
  // -> <recorderptr, i+1>
  CGenericNodeTypeCountRecorder * CopyRecorder(CGenericNodeTypeCountRecorder * recorder);

  // To increase a count for a node in the recorder. Might return a
  // new recorder. Ie. the caller should reset its _recorder to the recorder
  // returned.  If <recorderptr, i> where i > 1 then copy recorder (for real),
  // do the update and return new copied and updated recorder
  // (recorderptr'). We add <recorderptr',1> to map, and update <recorderptr, i>
  // -> <recorderptr, i-1>.  else i == 1, then do the update on recorderptr
  // and return same recorderptr.
  CGenericNodeTypeCountRecorder * CountGenericTypesWithRecorder(CGenericNodeTypeCountRecorder * recorder,
                                                                CECFGNode * node);

  // To reset the recorder. Might return a new recorder. Ie.  the
  // caller should reset its _recorder to the recorder returned. If
  // <recorderptr, i> where i > 1 then copy recorder (for real), do
  // the update and return new copied and updated recorder
  // (recorderptr'). We add <recorderptr',1> to map, and update
  // <recorderptr, i> -> <recorderptr, i-1>.  else i == 1, then do the
  // update on recorderptr and return same recorderptr.
  CGenericNodeTypeCountRecorder * UpdateRecorderWithProgramCounterChange(CGenericNodeTypeCountRecorder * recorder,
                                                                         CECFGNode * pc_before, CECFGNode * pc_after);
  CGenericNodeTypeCountRecorder * UpdateRecorderWithProgramExit(CGenericNodeTypeCountRecorder * recorder,
                                                                CECFGNode * pc_before);


  // To reset the recorder. Might return a new recorder. Ie.  the
  // caller should reset its _recorder to the recorder returned. If
  // <recorderptr, i> where i > 1 then copy recorder (for real), do
  // the update and return new copied and updated recorder
  // (recorderptr'). We add <recorderptr',1> to map, and update
  // <recorderptr, i> -> <recorderptr, i-1>.  else i == 1, then do the
  // update on recorderptr and return same recorderptr.
  CGenericNodeTypeCountRecorder * ResetRecorder(CGenericNodeTypeCountRecorder * recorder);

  // To merge two recorders. Return a new recorder. If both recorders
  // are the same we will just return a pointer to the recorder and
  // increase count as <recorderptr, i> -> <recorderptr, i+1>. Otherwise
  // we make the real merge make a new <newrecorderptr, 1> and return
  // the new recorder generated.
  CGenericNodeTypeCountRecorder * MergeRecorders(CGenericNodeTypeCountRecorder * recorder1,
                                                 CGenericNodeTypeCountRecorder * recorder2);

};

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CGenericNodeTypeCountRecorderNoReuseServer
// - Server implementing no reuse.
// - Most functionality is inherited from CGenericNodeTypeCountRecorderServer.
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CGenericNodeTypeCountRecorderNoReuseServer : public CGenericNodeTypeCountRecorderServer
{
public:

  // To create a no reuse node count recorder server. 
  CGenericNodeTypeCountRecorderNoReuseServer(bool record_generic_nodes, bool record_op_types, 
                                         bool record_stmts, bool record_stmt_pairs);
  virtual ~CGenericNodeTypeCountRecorderNoReuseServer();

  // For copying the recorder the ordinary way (ie. diretly when Copy() is called).
  // Creates a new recorder and adds <recorderptr, 1> to the map.
  CGenericNodeTypeCountRecorder * CopyRecorder(CGenericNodeTypeCountRecorder * recorder);

  // For updating the recorder the ordinary way. Will not update map.
  CGenericNodeTypeCountRecorder * UpdateRecorderWithProgramCounterChange(CGenericNodeTypeCountRecorder * recorder,
                                                                         CECFGNode * pc_before, CECFGNode * pc_after);
  CGenericNodeTypeCountRecorder * UpdateRecorderWithProgramExit(CGenericNodeTypeCountRecorder * recorder,
                                                                CECFGNode * pc_before);

  // For reseting the recorder the ordinary way.  Will not update map.
  CGenericNodeTypeCountRecorder * ResetRecorder(CGenericNodeTypeCountRecorder * recorder);

  // To merge two recorders the ordinary way. Return a new recorder
  // and adds <recorderptr, 1> to the map.
  CGenericNodeTypeCountRecorder * MergeRecorders(CGenericNodeTypeCountRecorder * recorder1,
                                                 CGenericNodeTypeCountRecorder * recorder2);

};



#endif

