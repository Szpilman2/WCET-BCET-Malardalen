/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE: File for collecting node count recordings, and generating
//  bb1 + bb2 <= max_count and bb1 + bb2 >= min_count flow facts.
//
//  Author: Andreas Ermedahl, andreas.ermedahl@mdh.se
//
// ----------------------------------------------------------------------
//
//  $Id: CNodePairCountCollector.h 5409 2013-06-16 15:04:47Z lkg02 $
//
// ----------------------------------------------------------------------

#ifndef CNodePairCountCollector_H_
#define CNodePairCountCollector_H_

// Standard includes
#include <string>
#include <iostream>
#include <fstream>
#include <map>
#include <set>


// Forward declare the CScope structure (due to circular dependencies
// we do not want to include the CScope.h file)
class CScope;
class CScopeGraph;
class CIntegerRange;
class CGenericStmt;
class CGenericFunction;
class CECFGNode;

// For getting nice macros
#include "macros.h"

// To get a suitable the range representation
#include "CIntegerRange.h"
// To get the scope node representation
#include "graphs/ecfg/CECFGNode.h"
// To get flow fact types
#include "flow_facts/CFlowFact.h"
#include "flow_facts/CContextSensitiveValidAtEntryOfFlowFact.h"
// To get recorder type
#include "CRecorder.h"
// To get collector type
#include "CCollector.h"


// To handle cout, cin, etc.


// -------------------------------------------------------
// Class hierarchy:
//
//   CNodePairCountCollector
//    |
//    |-- CNodePairCountScopeCollector
//    |    |-- CMinNodePairCountScopeCollector
//    |    |-- CMaxNodePairCountScopeCollector
//    |    |-- CMinMaxNodePairCountScopeCollector
//    |
//    |-- CNodePairCountScopeAndSubCollector
//    |    |-- CMinNodePairCountScopeAndSubCollector
//    |    |-- CMaxNodePairCountScopeAndSubCollector
//    |    |-- CMinMaxNodePairCountScopeAndSubCollector
//    |
//    |-- CNodePairCountScopeAndLoopSubCollector
//    |    |-- CMinNodePairCountScopeAndLoopSubCollector
//    |    |-- CMaxNodePairCountScopeAndLoopSubCollector
//    |    |-- CMinMaxNodePairCountScopeAndLoopSubCollector
//    |
//    |-- CHeaderNodePairCountScopeAndSubCollector
//    |    |-- CMinHeaderNodePairCountScopeAndSubCollector
//    |    |-- CMaxHeaderNodePairCountScopeAndSubCollector
//    |    |-- CMinHeaderMaxNodePairCountScopeAndSubCollector
//    |
//    |-- CHeaderNodePairCountScopeAndSubLoopCollector
//    |    |-- CMinHeaderNodePairCountScopeAndSubLoopCollector
//    |    |-- CMaxHeaderNodePairCountScopeAndSubLoopCollector
//    |    |-- CMinHeaderMaxNodePairCountScopeAndSubLoopCollector
//
// -------------------------------------------------------

// The internal data structure. We will, for each pair of nodes, have
// a min and max count.  This is implemented as a map from the first
// node to a mapping from the second node to a range:
// std::map<node, std::map<node, range>>
typedef std::map<CECFGNode *, CIntegerRange*> t_node_to_range_map;
typedef std::map<CECFGNode *, t_node_to_range_map> t_node_to_node_range_map;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodePairCountCollector
// - Class which exports all functionality for updating & storing
//   information on infeasible nodes. Vill be associated with a
//   scope, asking the scope for information and updating the scope
//   with resulting flow facts.
// - A recorder will update the collector with information upon
//   the nodes taken for an executed scope.
// - Class to inherit from (is virtual and can not be instansiated).
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CNodePairCountCollector : public CCollector 
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------

  // Default behaviour is to record only basic block start nodes. Alternatively,
  // the boolean can be used to control the behaviour. The fifth argument is a filter
  // which gives the set of node pairs that are interestiung to keep track of, i.e. 
  // only node pairs in this set will be reported. Since the set of node pairs is
  // derived on the whole scope graph it might happen that there exists node pairs 
  // in the set which are not in the scope of the collector.
  CNodePairCountCollector(CScope *, bool collect_only_basic_block_start_nodes=true,
                          bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true,
                          std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CNodePairCountCollector(void);

  //----------------------------------
  // To update the collector with a new recording. The recording should be
  // valid for a certain execution (from entry to exit) of a scope. Since
  // we allow states and recording to be merged, the recorder will be a
  // mapping from node to ranges or from edges to ranges. Will default
  // generate an assert, and suitable function call should therefore be
  // redefined by subclasses.
  //---------------------------------
  void Update(t_node_to_range_map * node_to_range_recording);
  // Will be calling the specialized Update function
  void Report(CRecorder * rec);
  // Should not be called by this colector but need to be implemented
  void Report(int iter, CRecorder * rec) {assert(0);}

  //----------------------------------
  // Create flow facts from the collector and add to scope. Returns
  // the number of flow facts created. Should be defined by subclasses.
  //---------------------------------
  int GenerateFlowFacts(void);

  // ---------------------------------
  // Take a set of collectors, merge their internals and generate
  // context sensitive valid at entry of flow facts valid over CFG
  // nodes. Returns the number of flow facts created. Adds created ffs
  // to last argument. Collectors should be of CIterNodeCountCollector type.
  // ---------------------------------
  int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                      std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,
                                                      std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);  
  
  // ---------------------------------
  // For printing the collector
  // ---------------------------------
  void Print(std::ostream *o=&std::cout);

  // The type of the collector, should be redefined in subclasses
  virtual std::string Type() {return "CNodePairCountCollector";}

  // To get the nodes to consider. Can also be called by a recorder to
  // get the nodes to consider. Should not be deallocated by the caller.
  // std::set<CECFGNode *> * NodesToConsider(void);

  inline bool IsEmpty(void) { return _node_pair_to_range_map.size() == 0; }

  // To get the saved scope
  CScope * Scope() {return _scope;}

  // To get the number of updates made
  int NrOfReports() { return _nr_of_updates; }

  // Help function to derive may but not must be taken node pairs
  static void 
  DeriveMayButNotMustBeTakenNodePairs(CScopeGraph * sg, bool collect_only_basic_block_start_nodes,
                                      std::set<std::pair<CECFGNode *, CECFGNode *> > * node_pairs);

  // Help function to derive all nodes that must be taken during any execution of the program
  static void 
  DeriveMustBeTakenNodes(CScopeGraph * sg, bool collect_only_basic_block_start_nodes,
                         std::set<CECFGNode *> * nodes_that_must_be_taken);

protected:

  // ---------------------------------
  // Functions that should be implemented by subclasses
  // ---------------------------------

  // To get the type of flow fact generated
  virtual CFlowFact::t_flowfacttype GetLowerFlowFactType() = 0;
  virtual CFlowFact::t_flowfacttype GetUpperFlowFactType() = 0;

  // The get the nodes to consider. Is called the first time a
  // recorder is reported. Should be provided by subclasses.
  virtual void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider) = 0;

  // ---------------------------------
  // Help functions not visible from the outside
  // ---------------------------------

  // Help function to derive the node pairs to consider
  void GetECFGNodePairsToConsiderBasedOnECFGGraph(std::set<std::pair<CECFGNode *, CECFGNode *> > *node_pairs_to_consider);
  void GetCFGNodePairsToConsider(std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> > *cfg_node_pairs_to_consider);
  void GetECFGNodePairsToConsiderBasedOnCFGNodePairs(std::set<std::pair<CECFGNode *, CECFGNode *> > *ecfg_node_pairs_to_consider);

  // Help functions used by different subclasses. Returns the number
  // of flow facts created. Uses the _scope and the _node_to_range_map.
  int AddMaxNodePairCountFlowFactsToScope(CFlowFact::t_flowfacttype fftype);
  int AddMinNodePairCountFlowFactsToScope(CFlowFact::t_flowfacttype fftype);

  // elp functions used by different subclasses. Returns the number
  // of context sensitive flow facts created. Uses the _scope and the _node_to_range_map.
  int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_node_pair_to_range_map,
                                                              std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                              std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                              std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);
  

  // Help functions to generate context sensitive valid at entry of
  // flow facts. Called by subclasses. Returns the number of flow
  // facts created.
  int GenerateContextSensitiveValidAtEntryOfMaxFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_node_pair_to_range_map,
                                                         std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                         std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                         CFlowFact::t_flowfacttype ff_type,
                                                         std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);
  int GenerateContextSensitiveValidAtEntryOfMinFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_node_pair_to_range_map,
                                                         std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                         std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                         CFlowFact::t_flowfacttype ff_type,
                                                         std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);
    
  // Help function for deriving CFG node pair to range map
  void DeriveCFGNodePairToRangeMap(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_node_pair_to_range_map);

  // To make sure that two nodes always reuslt in the same pair
  // (i.e. that they are stored in the right order)
  static std::pair<CECFGNode *, CECFGNode *> MakeNodePair(CECFGNode * node1, CECFGNode * node2);
  static std::pair<CFlowGraphNode *, CFlowGraphNode *> MakeNodePair(CFlowGraphNode * node1, CFlowGraphNode * node2);

  // ---------------------------------
  // Internal data 
  // ---------------------------------

  // The scope that the collector is associated with. Will be used
  // when creating flow facts and when deciding what nodes to consider.
  CScope * _scope;

  // If only basic block start nodes should be collected
  bool _collect_only_basic_block_start_nodes;

  // To remember if lower and/or upper bounds should be generated
  bool _generate_lower_bound_ffs;
  bool _generate_upper_bound_ffs;

  // To remember the number of updates made
  int _nr_of_updates;

  // To hold the nodes pairs to consider. The first set of ecfg node
  // pairs will be used when deriving context senstive valid at entry
  // of flow facts. The second set is needed in normal .sg flow fact
  // generation. The reason for differenign is that we might remiove
  // some non-interesting node pairs based on the ecfg
  // structure. However, when converting a set of ecfg pairs into one
  // cfg pair, which is done in the ne flow fact generation, we need
  // to include all ecfg pairs which might contribute to the range of
  // a given cfg pair.
  std::set<std::pair<CECFGNode *, CECFGNode *> > _ecfg_node_pairs_to_consider_based_on_cfg_node_pairs;
  std::set<std::pair<CECFGNode *, CECFGNode *> > _ecfg_node_pairs_to_consider_based_on_ecfg_graph;

  // We keep the minimum and maximum count encountered during any
  // scope execution of each node pair. The range hold the min and max
  // sum of the two nodes exec count for all recordings collected.
  std::map<std::pair<CECFGNode *, CECFGNode *>, CIntegerRange * > _node_pair_to_range_map;
  
  // Extra mapping inbetween nodes to consider and their ranges
  std::set<CECFGNode *> _nodes_to_consider;
  std::map<CECFGNode *, CIntegerRange *> _node_to_range_map;

  // To hold the may but not must be taken together node pairs. If != NULL
  // this set will be used to filter away unnessessary node pairs to keep track of.
  std::set<std::pair<CECFGNode *, CECFGNode *> > _may_but_not_must_be_taken_node_pairs;  
  bool _has_may_but_not_must_be_taken_node_pairs;
};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CNodePairCountCollector &a);

//------------------------------------------------------------
//------------------------------------------------------------
// CNodePairCountScopeCollector
// - Collector which just reports both the lowest or largest number 
//   of occurrencies of nodes for all executions of the scope. 
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CNodePairCountScopeCollector : public CNodePairCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CNodePairCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                               bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true,
                               std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CNodePairCountScopeCollector() {}

protected:

  // The get the nodes to consider. 
  void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LNPS; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UNPS; };
};

//--------------------------------------------------
// CMaxNodePairCountScopeCollector
// - Collector which just reports the largest number of occurrencies
//   of node pairs for all executions of the scope. 
// - Creates  scope : [] : #node + #node <= i   flow facts
//-------------------------------------------------
class CMaxNodePairCountScopeCollector : public CNodePairCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxNodePairCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                  std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMaxNodePairCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxNodePairCountScopeCollector";}
};

//--------------------------------------------------
// CMinNodePairCountScopeCollector
// - Collector which just reports the lowest number of occurrencies
//   of node pairs for all executions of the scope. 
// - Creates  scope : [] : #node + #node >= i   flow facts
//-------------------------------------------------
class CMinNodePairCountScopeCollector : public CNodePairCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinNodePairCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                  std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMinNodePairCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinNodePairCountScopeCollector";}
};

//--------------------------------------------------
// CMinMaxNodePairCountScopeCollector
// - Collector which reports both the lowest and largesy number of occurrencies
//   of node pairs for all executions of the scope. 
// - Creates  scope : [] : #node + #node <= i   and   scope : [] : #node + #node >= i flow facts
//-------------------------------------------------
class CMinMaxNodePairCountScopeCollector : public CNodePairCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxNodePairCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                     std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMinMaxNodePairCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxNodePairCountScopeCollector";}
};




//------------------------------------------------------------
//------------------------------------------------------------
// CNodePairCountScopeAndSubCollector
// - Collector which just reports both the lowest or largest number 
//   of occurrencies of nodes for all executions of the scope and its subordinate scopes.
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CNodePairCountScopeAndSubCollector : public CNodePairCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                     bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true,
                                     std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CNodePairCountScopeAndSubCollector() {}

protected:

  // The get the nodes to consider. 
  void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LNPP; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UNPP; };
};

//--------------------------------------------------
// CMaxNodePairCountScopeAndSubCollector
// - Collector which just reports the largest number of occurrencies
//   of node pairs for all executions of the scope and its subordinate scopes.
// - Creates  scope : [] : #node + #node <= i   flow facts
//-------------------------------------------------
class CMaxNodePairCountScopeAndSubCollector : public CNodePairCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                        std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMaxNodePairCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxNodePairCountScopeAndSubCollector";}
};

//--------------------------------------------------
// CMinNodePairCountScopeAndSubCollector
// - Collector which just reports the lowest number of occurrencies
//   of node pairs for all executions of the scope and its subordinate scopes.
// - Creates  scope : [] : #node + #node >= i   flow facts
//-------------------------------------------------
class CMinNodePairCountScopeAndSubCollector : public CNodePairCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                        std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMinNodePairCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinNodePairCountScopeAndSubCollector";}
};

//--------------------------------------------------
// CMinMaxNodePairCountScopeAndSubCollector
// - Collector which reports both the lowest and largesy number of occurrencies
//   of node pairs for all executions of the scope and its subordinate scopes.
// - Creates  scope : [] : #node + #node <= i   and   scope : [] : #node + #node >= i flow facts
//-------------------------------------------------
class CMinMaxNodePairCountScopeAndSubCollector : public CNodePairCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                           std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMinMaxNodePairCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxNodePairCountScopeAndSubCollector";}
};



//------------------------------------------------------------
//------------------------------------------------------------
// CNodePairCountScopeAndLoopSubCollector
// - Collector which just reports both the lowest or largest number 
//   of occurrencies of nodes for all executions of the scope and its looping subscopes.
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CNodePairCountScopeAndLoopSubCollector : public CNodePairCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                         bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true,
                                         std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CNodePairCountScopeAndLoopSubCollector() {}

protected:

  // The get the nodes to consider. 
  void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LNPF; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UNPF; };
};

//--------------------------------------------------
// CMaxNodePairCountScopeAndLoopSubCollector
// - Collector which just reports the largest number of occurrencies
//   of node pairs for all executions of the scope and its looping subscopes.
// - Creates  scope : [] : #node + #node <= i   flow facts
//-------------------------------------------------
class CMaxNodePairCountScopeAndLoopSubCollector : public CNodePairCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                            std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMaxNodePairCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxNodePairCountScopeAndLoopSubCollector";}
};

//--------------------------------------------------
// CMinNodePairCountScopeAndLoopSubCollector
// - Collector which just reports the lowest number of occurrencies
//   of node pairs for all executions of the scope and its looping subscopes.
// - Creates  scope : [] : #node + #node >= i   flow facts
//-------------------------------------------------
class CMinNodePairCountScopeAndLoopSubCollector : public CNodePairCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                            std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMinNodePairCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinNodePairCountScopeAndLoopSubCollector";}
};

//--------------------------------------------------
// CMinMaxNodePairCountScopeAndLoopSubCollector
// - Collector which reports both the lowest and largesy number of occurrencies
//   of node pairs for all executions of the scope and its looping subscopes.
// - Creates  scope : [] : #node + #node <= i   and   scope : [] : #node + #node >= i flow facts
//-------------------------------------------------
class CMinMaxNodePairCountScopeAndLoopSubCollector : public CNodePairCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                               std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMinMaxNodePairCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxNodePairCountScopeAndLoopSubCollector";}
};

//------------------------------------------------------------
//------------------------------------------------------------
// CHeaderNodePairCountScopeAndSubCollector
// - Collector which just reports both the lowest or largest number 
//   of occurrencies of nodes for all executions of the scope and its subordinate scopes.
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CHeaderNodePairCountScopeAndSubCollector : public CNodePairCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CHeaderNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                           bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true,
                                           std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CHeaderNodePairCountScopeAndSubCollector() {}

protected:

  // The get the nodes to consider. 
  void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LHPP; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UHPP; };
};

//--------------------------------------------------
// CMaxHeaderNodePairCountScopeAndSubCollector
// - Collector which just reports the largest number of occurrencies
//   of node pairs for all executions of the scope and its subordinate scopes.
// - Creates  scope : [] : #node + #node <= i   flow facts
//-------------------------------------------------
class CMaxHeaderNodePairCountScopeAndSubCollector : public CHeaderNodePairCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxHeaderNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                              std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMaxHeaderNodePairCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxHeaderNodePairCountScopeAndSubCollector";}
};

//--------------------------------------------------
// CMinHeaderNodePairCountScopeAndSubCollector
// - Collector which just reports the lowest number of occurrencies
//   of node pairs for all executions of the scope and its subordinate scopes.
// - Creates  scope : [] : #node + #node >= i   flow facts
//-------------------------------------------------
class CMinHeaderNodePairCountScopeAndSubCollector : public CHeaderNodePairCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinHeaderNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                              std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMinHeaderNodePairCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinHeaderNodePairCountScopeAndSubCollector";}
};

//--------------------------------------------------
// CMinMaxHeaderNodePairCountScopeAndSubCollector
// - Collector which reports both the lowest and largesy number of occurrencies
//   of node pairs for all executions of the scope and its subordinate scopes.
// - Creates  scope : [] : #node + #node <= i   and   scope : [] : #node + #node >= i flow facts
//-------------------------------------------------
class CMinMaxHeaderNodePairCountScopeAndSubCollector : public CHeaderNodePairCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxHeaderNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                                 std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMinMaxHeaderNodePairCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxHeaderNodePairCountScopeAndSubCollector";}
};



//------------------------------------------------------------
//------------------------------------------------------------
// CHeaderNodePairCountScopeAndLoopSubCollector
// - Collector which just reports both the lowest or largest number 
//   of occurrencies of nodes for all executions of the scope and its looping subscopes.
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CHeaderNodePairCountScopeAndLoopSubCollector : public CNodePairCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CHeaderNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                               bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true,
                                               std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CHeaderNodePairCountScopeAndLoopSubCollector() {}

protected:

  // The get the nodes to consider. 
  void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LHPF; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UHPF; };
};

//--------------------------------------------------
// CMaxHeaderNodePairCountScopeAndLoopSubCollector
// - Collector which just reports the largest number of occurrencies
//   of node pairs for all executions of the scope and its looping subscopes.
// - Creates  scope : [] : #node + #node <= i   flow facts
//-------------------------------------------------
class CMaxHeaderNodePairCountScopeAndLoopSubCollector : public CHeaderNodePairCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxHeaderNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                                  std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMaxHeaderNodePairCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxHeaderNodePairCountScopeAndLoopSubCollector";}
};

//--------------------------------------------------
// CMinHeaderNodePairCountScopeAndLoopSubCollector
// - Collector which just reports the lowest number of occurrencies
//   of node pairs for all executions of the scope and its looping subscopes.
// - Creates  scope : [] : #node + #node >= i   flow facts
//-------------------------------------------------
class CMinHeaderNodePairCountScopeAndLoopSubCollector : public CHeaderNodePairCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinHeaderNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                                  std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMinHeaderNodePairCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinHeaderNodePairCountScopeAndLoopSubCollector";}
};

//--------------------------------------------------
// CMinMaxHeaderNodePairCountScopeAndLoopSubCollector
// - Collector which reports both the lowest and largesy number of occurrencies
//   of node pairs for all executions of the scope and its looping subscopes.
// - Creates  scope : [] : #node + #node <= i   and   scope : [] : #node + #node >= i flow facts
//-------------------------------------------------
class CMinMaxHeaderNodePairCountScopeAndLoopSubCollector : public CHeaderNodePairCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxHeaderNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                                     std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs=NULL);
  virtual ~CMinMaxHeaderNodePairCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxHeaderNodePairCountScopeAndLoopSubCollector";}
};




// //----------------------------------------------------------------------
// //------------------------------------------------------------
// //--------------------------------------------------
// // CMaxNodePairCountScopeAndSubCollector
// // - Collector which just remembers the largest number of occurrencies
// //   of node pairs for all executions of the scope and its subscopes.
// // - Creates  scope : [] : #node + #node <= i   and
// //            scope : [] : #subscope.node + #node <= i
// //            scope : [] : #node + #subscope.node <= i
// //            scope : [] : #subscope.node + #subscope.node <= i   flow facts
// //-------------------------------------------------
// //------------------------------------------------------------
// //----------------------------------------------------------------------
// class CMaxNodePairCountScopeAndSubCollector: public CNodePairCountCollector
// {
// public:

//   //----------------------------------
//   // Creation and deletion.
//   //----------------------------------
//   CMaxNodePairCountScopeAndSubCollector(CScope * scope);
//   CMaxNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes);
//   virtual ~CMaxNodePairCountScopeAndSubCollector(void);

//   //----------------------------------
//   // Create flow facts from the collector and add to scope. Returns
//   // the number of flow facts created.
//   //---------------------------------
//   int AddFlowFactsToScope(void);
//   int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_node_pair_to_range_map,
//                                                       std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
//                                                       std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
//                                                       std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);

//   // The type of the collector
//   std::string Type() {return "CMaxNodePairCountScopeAndSubCollector";}

// protected:

//   // The get the nodes to consider. Is called the first time a
//   // recorder is reported. Should be provided by subclasses.
//   void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);

// };

// //----------------------------------------------------------------------
// //------------------------------------------------------------
// //--------------------------------------------------
// // CMinMaxNodePairCountScopeAndSubCollector
// // - Collector which just remembers the smallest and largest number of
// //   occurrencies of node pairs in the scope and its subscope for all executions
// //   of the scope.
// // - Creates  scope : [] : #node + #node <= i  and
// //            scope : [] : #node + #node >= j  and
// //            scope : [] : #subscope.node + #subscope.node <= i  and
// //            scope : [] : #subscope.node + #subscope.node >= j  flow facts
// //-------------------------------------------------
// //------------------------------------------------------------
// //----------------------------------------------------------------------
// class CMinMaxNodePairCountScopeAndSubCollector : public CNodePairCountCollector
// {
// public:

//   //----------------------------------
//   // Creation and deletion.
//   //----------------------------------
//   CMinMaxNodePairCountScopeAndSubCollector(CScope * scope);
//   CMinMaxNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes);
//   virtual ~CMinMaxNodePairCountScopeAndSubCollector(void);

//   //----------------------------------
//   // Create flow facts from the collector and add to scope. Returns
//   // the number of flow facts created.
//   //---------------------------------
//   int AddFlowFactsToScope(void);
//   int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_node_pair_to_range_map,
//                                                       std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
//                                                       std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
//                                                       std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);

//   // The type of the collector
//   std::string Type() {return "CMinMaxNodePairCountScopeAndSubCollector";}

// protected:

//   // The get the nodes to consider. Is called the first time a
//   // recorder is reported. Should be provided by subclasses.
//   void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);

// };

// //----------------------------------------------------------------------
// //------------------------------------------------------------
// //--------------------------------------------------
// // CMaxNodePairCountScopeAndLoopSubCollector
// // - Collector which just remembers the largest number of occurrencies
// //   of nodes for all executions of the scope and its direct looping
// //   subscopes. The header node of the scope will not be included.
// // - Creates  scope : [] : #node <= i   and
// //            scope : [] : #subscope.node <= i   flow facts
// //-------------------------------------------------
// //------------------------------------------------------------
// //----------------------------------------------------------------------
// class CMaxNodePairCountScopeAndLoopSubCollector: public CNodePairCountCollector
// {
// public:

//   //----------------------------------
//   // Creation and deletion.
//   //----------------------------------
//   CMaxNodePairCountScopeAndLoopSubCollector(CScope * scope);
//   CMaxNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes);
//   virtual ~CMaxNodePairCountScopeAndLoopSubCollector(void);

//   //----------------------------------
//   // Create flow facts from the collector and add to scope. Returns
//   // the number of flow facts created.
//   //---------------------------------
//   int AddFlowFactsToScope(void);
//   int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_node_pair_to_range_map,
//                                                       std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
//                                                       std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
//                                                       std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);

//   // The type of the collector
//   std::string Type() {return "CMaxNodePairCountScopeAndLoopSubCollector";}

// protected:

//   // The get the nodes to consider. Is called the first time a
//   // recorder is reported. Should be provided by subclasses.
//   void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);

// };

// //----------------------------------------------------------------------
// //------------------------------------------------------------
// //--------------------------------------------------
// // CMinMaxNodePairCountScopeAndLoopSubCollector
// // - Collector which just remembers the smallest and largest number of
// //   occurrencies of nodes in the scope and its direct looping subscopes
// //   for all executions of the scope. The header node of the scope will
// //   not be included.
// // - Creates  scope : [] : #node <= i  and
// //            scope : [] : #node >= j  and
// //            scope : [] : #subscope.node <= i  and
// //            scope : [] : #subscope.node >= j  flow facts
// //-------------------------------------------------
// //------------------------------------------------------------
// //----------------------------------------------------------------------
// class CMinMaxNodePairCountScopeAndLoopSubCollector : public CNodePairCountCollector
// {
// public:

//   //----------------------------------
//   // Creation and deletion.
//   //----------------------------------
//   CMinMaxNodePairCountScopeAndLoopSubCollector(CScope * scope);
//   CMinMaxNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes);
//   virtual ~CMinMaxNodePairCountScopeAndLoopSubCollector(void);

//   //----------------------------------
//   // Create flow facts from the collector and add to scope. Returns
//   // the number of flow facts created.
//   //---------------------------------
//   int AddFlowFactsToScope(void);
//   int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_node_pair_to_range_map,
//                                                       std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
//                                                       std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
//                                                       std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);

//   // The type of the collector
//   std::string Type() {return "CMinMaxNodePairCountScopeAndLoopSubCollector";}

// protected:

//   // The get the nodes to consider. Is called the first time a
//   // recorder is reported. Should be provided by subclasses.
//   void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);
// };


// //----------------------------------------------------------------------
// //------------------------------------------------------------
// //--------------------------------------------------
// // CMaxNestedLoopHeaderCountCollector
// // - Collector which just remembers the largest number of occurrencies of
// //   header node pairs of current scope and subscopes for all executions of
// //   the scope.
// // - Creates  scope : [] : #node + #subscope.node <= i
// //            scope : [] : #subscope.node + #subscope.node <= i  flow facts
// //-------------------------------------------------
// //------------------------------------------------------------
// //----------------------------------------------------------------------
// class CMaxNestedLoopHeaderPairCountCollector : public CNodePairCountCollector
// {
// public:
//   //----------------------------------
//   // Creation and deletion.
//   //----------------------------------
//   CMaxNestedLoopHeaderPairCountCollector(CScope * scope);
//   CMaxNestedLoopHeaderPairCountCollector(CScope * scope, bool collect_only_basic_block_start_nodes);
//   virtual ~CMaxNestedLoopHeaderPairCountCollector(void);

//   //----------------------------------
//   // Create maxiter and normal flow facts from the collector and add
//   // to scope. Returns the number of flow facts created.
//   //---------------------------------
//   int AddFlowFactsToScope(void);
//   int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_node_pair_to_range_map,
//                                                       std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
//                                                       std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
//                                                       std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);

//   // The type of the collector
//   std::string Type() {return "CMaxNestedLoopHeaderCountCollector";}

// protected:

//   // The get the nodes to consider. Is called the first time a
//   // recorder is reported. Will only set the header node in the scope.
//   void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);
// };

// //----------------------------------------------------------------------
// //------------------------------------------------------------
// //--------------------------------------------------
// // CMinMaxNestedLoopHeaderPairCountCollector
// // - Collector which just remembers the smallest and largest number of occurrencies of
// //   header node pairs of current scope and subscopes for all executions of
// //   the scope.
// // - Creates  scope : [] : #node + #subscope.node <= i
// //            scope : [] : #subscope.node + #subscope.node <= i
// //            scope : [] : #node + #subscope.node >= j
// //            scope : [] : #subscope.node + #subscope.node >= j flow facts
// //-------------------------------------------------
// //------------------------------------------------------------
// //----------------------------------------------------------------------
// class CMinMaxNestedLoopHeaderPairCountCollector : public CNodePairCountCollector
// {
// public:
//   //----------------------------------
//   // Creation and deletion.
//   //----------------------------------
//   CMinMaxNestedLoopHeaderPairCountCollector(CScope * scope);
//   CMinMaxNestedLoopHeaderPairCountCollector(CScope * scope, bool collect_only_basic_block_start_nodes);
//   virtual ~CMinMaxNestedLoopHeaderPairCountCollector(void);

//   //----------------------------------
//   // Create maxiter and normal flow facts from the collector and add
//   // to scope. Returns the number of flow facts created.
//   //---------------------------------
//   int AddFlowFactsToScope(void);
//   int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_node_pair_to_range_map,
//                                                       std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
//                                                       std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
//                                                       std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);

//   // The type of the collector
//   std::string Type() {return "CMinMaxNestedLoopHeaderPairCountCollector";}

// protected:

//   // The get the nodes to consider. Is called the first time a
//   // recorder is reported. Will only set the header node in the scope.
//   void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);
// };



#endif






























