/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CIterNodeCountRecorder.cpp 326 2009-05-06 07:59:13Z msl01 $
//
// ----------------------------------------------------------------------

#include "CIterNodeCountRecorder.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/scopes/CScope.h"
#include <cassert>

using namespace std;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CIterNodeCountRecorder
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of recorder
//----------------------------------
CIterNodeCountRecorder::
CIterNodeCountRecorder()
  : _record_only_basic_block_start_nodes(true)
{
  // Do nothing
}

CIterNodeCountRecorder::
CIterNodeCountRecorder(bool record_only_basic_block_start_nodes)
  : _record_only_basic_block_start_nodes(record_only_basic_block_start_nodes)
{
  // Do nothing
}

//----------------------------------
// Deletion of recorder
//----------------------------------
CIterNodeCountRecorder::
~CIterNodeCountRecorder()
{
  // Do nothing, the set wil be deleted automatically
}

//----------------------------------
// Remember that we have executed a certain node or edge
//----------------------------------
void
CIterNodeCountRecorder::
IncreaseCount(CECFGNode *node)
{    
  if(_record_only_basic_block_start_nodes && !(node->IsBeginOfBasicBlock()))
    return;
  else
    _nodes.insert(node);
}

void 
CIterNodeCountRecorder::
UpdateWithProgramCounterChange(CECFGNode * pc_before, CECFGNode * pc_after) 
{
  IncreaseCount(pc_before);
}

void 
CIterNodeCountRecorder::
UpdateWithProgramExit(CECFGNode * pc_before) 
{
  IncreaseCount(pc_before);
}

//----------------------------------
// Reset the recorder
//---------------------------------
void
CIterNodeCountRecorder::
Reset()
{
  // Remove all the mappings
  _nodes.erase(_nodes.begin(), _nodes.end());
  assert(_nodes.size() == 0);
}

//----------------------------------
// Copy the recorder
//---------------------------------
CIterNodeCountRecorder *
CIterNodeCountRecorder::
Copy()
{
  // Create a new recorder
  CIterNodeCountRecorder * new_recorder = new CIterNodeCountRecorder(_record_only_basic_block_start_nodes);

  // Go through all nodes in the set and copy them to the new set
  for(std::set<CECFGNode *>::iterator node = _nodes.begin();
      node != _nodes.end(); node++) {
    new_recorder->_nodes.insert(*node);
  }

  // We are done, the range map has been copied to the new recorder
  return new_recorder;
}

//----------------------------------
// Merge two recorders
//---------------------------------
CIterNodeCountRecorder *
CIterNodeCountRecorder::
Merge(CIterNodeCountRecorder * other_recorder)
{
  // Create a new recorder from the argument recorder (will copy its set)
  CIterNodeCountRecorder * new_recorder = other_recorder->Copy();

  // Go through all nodes in the current set and copy them to the new set
  for(std::set<CECFGNode *>::iterator node = _nodes.begin();
      node != _nodes.end(); node++) {
      new_recorder->_nodes.insert(*node);
    }

  // We are done, the range map has been copied to the new recorder
  return new_recorder;
}

CRecorder * 
CIterNodeCountRecorder::
Merge(CRecorder * other_recorder)
{
  return Merge(dynamic_cast<CIterNodeCountRecorder *>(other_recorder));
}

//---------------------------------
// For printing the recorder
//---------------------------------
void
CIterNodeCountRecorder::
Print(ostream * o)
{
  // Go through all nodes in the set and print them
  for(std::set<CECFGNode *>::iterator node = _nodes.begin();
      node != _nodes.end(); node++) { 
    (*node)->Print(*o);
    (*o) << " ";
  }
  (*o) << endl;
}

//---------------------------------
// Alternative printing function
//---------------------------------
ostream &operator << (ostream &o, CIterNodeCountRecorder &a)
{
  a.Print(&o);
  return o;
}

//---------------------------------
// To get the set of nodes held by the recorder
//---------------------------------
std::set<CECFGNode *> * 
CIterNodeCountRecorder::
Nodes() 
{
  return &_nodes;
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CIterNodeCountRecorderServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//---------------------------------
// To create the recorder server
//---------------------------------
CIterNodeCountRecorderServer::
CIterNodeCountRecorderServer()
  : _record_only_basic_block_start_nodes(true)
{
  // Do nothing
}

CIterNodeCountRecorderServer::
CIterNodeCountRecorderServer(bool record_only_basic_block_start_nodes)
  : _record_only_basic_block_start_nodes(record_only_basic_block_start_nodes)
{
  // Do nothing
}

//---------------------------------
// To create the recorder
//---------------------------------
CIterNodeCountRecorder *
CIterNodeCountRecorderServer::
CreateRecorder()
{
  // Create the recorder
  CIterNodeCountRecorder * recorder = new CIterNodeCountRecorder(_record_only_basic_block_start_nodes);

  // Remember that we have one reference to the recorder
  _recorder_to_refs[recorder] = 1;

  // Return the new recorder
  return recorder;
}

// -------------------------------------------------------
// To delete a certain recorder
// -------------------------------------------------------
void
CIterNodeCountRecorderServer::
DeleteRecorder(CIterNodeCountRecorder * recorder)
{
  // Update map
  _recorder_to_refs[recorder] = _recorder_to_refs[recorder]-1;

  // Check if we have any refs left
  if(_recorder_to_refs[recorder] == 0)
    {
      // No, remove the recorder for real
      delete recorder;
    }
}

void
CIterNodeCountRecorderServer::
DeleteRecorder(CRecorder * recorder)
{
  DeleteRecorder(dynamic_cast<CIterNodeCountRecorder *>(recorder));
}

// -------------------------------------------------------
// To copy a recorder
// -------------------------------------------------------
CRecorder *
CIterNodeCountRecorderServer::
CopyRecorder(CRecorder * recorder)
{
  return CopyRecorder(dynamic_cast<CIterNodeCountRecorder *>(recorder));
}

// -------------------------------------------------------
// To update a recorder
// -------------------------------------------------------
void
CIterNodeCountRecorderServer::
UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after)
{
  *recorder = IncreaseCountInRecorder(dynamic_cast<CIterNodeCountRecorder*>(*recorder), pc_before);
}

void
CIterNodeCountRecorderServer::
UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before)
{
  *recorder = IncreaseCountInRecorder(dynamic_cast<CIterNodeCountRecorder*>(*recorder), pc_before);
}

// -------------------------------------------------------
// Reset the current recorder
// -------------------------------------------------------
void
CIterNodeCountRecorderServer::
ResetRecorder(CRecorder ** recorder)
{
  *recorder = ResetRecorder(dynamic_cast<CIterNodeCountRecorder*>(*recorder));
}

// -------------------------------------------------------
// Merge two recorders
// -------------------------------------------------------
CRecorder *
CIterNodeCountRecorderServer::
MergeRecorders(CRecorder * rec1, CRecorder * rec2)
{
  return MergeRecorders(dynamic_cast<CIterNodeCountRecorder*>(rec1), dynamic_cast<CIterNodeCountRecorder*>(rec2)); 
}

// -------------------------------------------------------
// To print all the mappings in the server
// -------------------------------------------------------
void
CIterNodeCountRecorderServer::
Print(ostream * o)
{
  // Loop through all maps
  int i = 1;
  for(map<CIterNodeCountRecorder *, int64_t>::iterator tr = _recorder_to_refs.begin();
      tr != _recorder_to_refs.end(); tr++)
    {
      (*o) << i << ": " << (*tr).first << "."
           << (*tr).second << endl;
      i++;
    }
}

// Alternative printing function
ostream &operator << (ostream &o, CIterNodeCountRecorderServer &a)
{
  a.Print(&o);
  return o;
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CIterNodeCountRecorderCOWServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

// -------------------------------------------------------
// To create the recorder server
// -------------------------------------------------------
CIterNodeCountRecorderCOWServer::
CIterNodeCountRecorderCOWServer()
  : CIterNodeCountRecorderServer()
{
  // Do nothing
}

CIterNodeCountRecorderCOWServer::
CIterNodeCountRecorderCOWServer(bool record_only_basic_block_start_nodes)
  : CIterNodeCountRecorderServer(record_only_basic_block_start_nodes)
{
  // Do nothing
}

// -------------------------------------------------------
// To delete the recorder server
// -------------------------------------------------------
CIterNodeCountRecorderCOWServer::
~CIterNodeCountRecorderCOWServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To copy recorder
// -------------------------------------------------------
CIterNodeCountRecorder *
CIterNodeCountRecorderCOWServer::
CopyRecorder(CIterNodeCountRecorder * recorder)
{
  // Do no copying, just add one more reference to the recorder
  _recorder_to_refs[recorder] = _recorder_to_refs[recorder] + 1;

  // Return the same recorder
  return recorder;
}

// -------------------------------------------------------
// To increase count for a certain node
// -------------------------------------------------------
CIterNodeCountRecorder *
CIterNodeCountRecorderCOWServer::
IncreaseCountInRecorder(CIterNodeCountRecorder * recorder, CECFGNode * node)
{
  assert(_recorder_to_refs[recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[recorder] == 1)
    {
      // Update current recorder
      recorder->IncreaseCount(node);

      // Return the updated recorder
      return recorder;
    }
  // More than one reference
  else
    {
      // Do the real copying
      CIterNodeCountRecorder * recorder_copy = recorder->Copy();

      // Update the copied recorder
      recorder_copy->IncreaseCount(node);

      // Update map
      _recorder_to_refs[recorder] = _recorder_to_refs[recorder] - 1;
      _recorder_to_refs[recorder_copy] = 1;

      // Return the copied recorder
      return recorder_copy;
    }
}

// -------------------------------------------------------
// To reset the recorder
// -------------------------------------------------------
CIterNodeCountRecorder *
CIterNodeCountRecorderCOWServer::
ResetRecorder(CIterNodeCountRecorder * recorder)
{
  assert(_recorder_to_refs[recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[recorder] == 1)
    {
      // Update current recorder
      recorder->Reset();

      // Return the updated recorder
      return recorder;
    }
  // More than one reference
  else
    {
      // Create a new recorder (same as doing a reset)
      CIterNodeCountRecorder * new_recorder = new CIterNodeCountRecorder(_record_only_basic_block_start_nodes);

      // Update map
      _recorder_to_refs[recorder] = _recorder_to_refs[recorder] - 1;
      _recorder_to_refs[new_recorder] = 1;

      // Return the new recorder
      return new_recorder;
    }
}

// -------------------------------------------------------
// To merge two recorders
// -------------------------------------------------------
CIterNodeCountRecorder *
CIterNodeCountRecorderCOWServer::
MergeRecorders(CIterNodeCountRecorder * recorder1, CIterNodeCountRecorder * recorder2)
{
  // Check if it is the same recorder (i.e. they points to the same address)
  if(recorder1 == recorder2)
    {
      // Update map
      _recorder_to_refs[recorder1] = _recorder_to_refs[recorder1] + 1;

      // Return the same recorder
      return recorder1;
    }
  else
    {
      // Different recorders, do the real merging
      CIterNodeCountRecorder * new_recorder = recorder1->Merge(recorder2);

      // Update map
      _recorder_to_refs[new_recorder] = 1;

      // Return the new recorder
      return new_recorder;
    }
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CIterNodeCountRecorderNoReuseServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

// -------------------------------------------------------
// To create the recorder server
// -------------------------------------------------------
CIterNodeCountRecorderNoReuseServer::
CIterNodeCountRecorderNoReuseServer()
  : CIterNodeCountRecorderServer()
{
  // Do nothing
}

CIterNodeCountRecorderNoReuseServer::
CIterNodeCountRecorderNoReuseServer(bool record_only_basic_block_start_nodes)
  : CIterNodeCountRecorderServer(record_only_basic_block_start_nodes)
{
  // Do nothing
}

// -------------------------------------------------------
// To delete the recorder server
// -------------------------------------------------------
CIterNodeCountRecorderNoReuseServer::
~CIterNodeCountRecorderNoReuseServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To copy recorder
// -------------------------------------------------------
CIterNodeCountRecorder *
CIterNodeCountRecorderNoReuseServer::
CopyRecorder(CIterNodeCountRecorder * recorder)
{
  // Do the copying right away
  CIterNodeCountRecorder * new_recorder = recorder->Copy();

  // Update map
  _recorder_to_refs[new_recorder] = 1;

  // Return the new recorder
  return new_recorder;
}

// -------------------------------------------------------
// To increase count for a certain node
// -------------------------------------------------------
CIterNodeCountRecorder *
CIterNodeCountRecorderNoReuseServer::
IncreaseCountInRecorder(CIterNodeCountRecorder * recorder, CECFGNode * node)
{
  // Update current recorder
  recorder->IncreaseCount(node);

  // Return the updated recorder
  return recorder;
}

// -------------------------------------------------------
// To reset the recorder
// -------------------------------------------------------
CIterNodeCountRecorder *
CIterNodeCountRecorderNoReuseServer::
ResetRecorder(CIterNodeCountRecorder * recorder)
{
  // Reset current recorder
  recorder->Reset();

  // Return the updated recorder
  return recorder;
}

// -------------------------------------------------------
// To merge two recorders
// -------------------------------------------------------
CIterNodeCountRecorder *
CIterNodeCountRecorderNoReuseServer::
MergeRecorders(CIterNodeCountRecorder * recorder1, CIterNodeCountRecorder * recorder2)
{
  // Do the merging getting a new recorder
  CIterNodeCountRecorder * new_recorder = recorder1->Merge(recorder2);

  // Update map
  _recorder_to_refs[new_recorder] = 1;

  // Return the new recorder
  return new_recorder;
}



