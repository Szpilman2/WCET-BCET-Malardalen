/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: $
//
// ----------------------------------------------------------------------

#ifndef CAACostCalcRecorder_H_
#define CAACostCalcRecorder_H_

#include <string>
#include <iostream>
#include <fstream>
#include <map>
#include <set>

// To get the scope node representation
#include "graphs/ecfg/CECFGNode.h"
// To get the CRecorder and CRecorderServer base classes
#include "CRecorder.h"
// To get the cost lookup table class
#include "tcalc/CAlfCostLookupTable.h"

// To handle cout, cin, etc.
using namespace std;

//----------------------------------------------------------------------
// Forward-declare types
//----------------------------------------------------------------------
class CAACostCalcRecorder;
class CAACostCalcRecorderServer;
class CAACostCalcRecorderCOWServer;
class CAACostCalcRecorderNoReuseServer;
class CScope;
class CAACostCalcCollector;
class CAACostLookupTable;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CAACostCalcRecorder
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CAACostCalcRecorder : public CRecorder
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------

  // Create a recorder which when executing a node tries to derive the
  // cost for the node from the ALF code construct cost table.  If
  // such costs exists it is added to the recorders min and max costs.
  CAACostCalcRecorder(const alf::CAlfCostLookupTable * cost_lookup_table,
		      bool count_generic_nodes=true, bool count_op_types=true,
		      bool count_stmts=true, bool count_stmt_pairs=true,
		      double init_min_cost=0, double init_max_cost=0,
		      bool record_min_cost_path=false,
		      bool record_max_cost_path=false);
  virtual ~CAACostCalcRecorder(void);

  //----------------------------------
  // To update the recorder with a new execution of a edge
  //---------------------------------
  void UpdateWithProgramCounterChange(CECFGNode * pc_before, CECFGNode * pc_after);
  void UpdateWithProgramExit(CECFGNode * pc_before);

  //----------------------------------
  // Report the current min and max timing 
  //---------------------------------
  void ReportToCollector(CAACostCalcCollector * collector);

  //----------------------------------
  // Reset recorder. Will remove all edge to range mappings.
  //---------------------------------
  void Reset(void);

  //----------------------------------
  // To copy the recorder
  //---------------------------------
  CAACostCalcRecorder * Copy();

  //----------------------------------
  // To merge two recorders (LUB)
  //---------------------------------
  CAACostCalcRecorder * Merge(CAACostCalcRecorder * other_recorder);
  // Will call the more specialized Merge() function...
  CRecorder * Merge(CRecorder * other_recorder);

  // ---------------------------------
  // For printing the recorder
  // ---------------------------------
  void Print() {Print(&std::cout);};
  void Print(std::ostream * o);

  // For getting the min and max cost
  double GetMinCost() { return _min_cost; }
  double GetMaxCost() { return _max_cost; }

  const std::map<CScope*,int64_t> &GetBCProfile() const { return _bc_profile; }
  const std::map<CScope*,int64_t> &GetWCProfile() const { return _wc_profile; }

protected:

  // Help functions for adding cost for nodes or edges
  void AddCostForNode(CECFGNode * node);
  void AddCostForEdge(CECFGNode * from_node, CECFGNode * to_node);

  CScope *GetFunctionScope(CECFGNode *node);

  // A reference to the cost table
  const alf::CAlfCostLookupTable * _cost_lookup_table;

  // Holds the things to record
  bool _count_generic_nodes;
  bool _count_op_types;
  bool _count_stmts;
  bool _count_stmt_pairs;
  
  // The lower and upper timing cost encountered for the recorder so far.
  // Will be reported to the collector.
  double _min_cost;
  double _max_cost;

  std::map<CScope*,int64_t> _bc_profile, _wc_profile;

  // The best and worst case paths
  bool _record_min_cost_path;
  std::vector<CECFGNode *> _min_cost_path;
  bool _record_max_cost_path;
  std::vector<CECFGNode *> _max_cost_path;

};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CAACostCalcRecorder &a);

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CAACostCalcRecorderServer
// - Server for generating new node count recorders
// - To inherit from
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CAACostCalcRecorderServer : public CRecorderServer
{
public:

  // To create a node count recorder server. 
  CAACostCalcRecorderServer(alf::CAlfCostLookupTable * cost_lookup_table,
			    bool count_generic_nodes, bool count_op_types, 
			    bool count_stmts, bool count_stmt_pairs,
			    bool record_min_cost_path=false,
			    bool record_max_cost_path=false);
  virtual ~CAACostCalcRecorderServer() {};

  // For creating a new recorder. Will allocate the recorder and add
  // <recorderptr,1> to the map.
  CAACostCalcRecorder * CreateRecorder();

  // For deleting a recorder. When deleting a recorder then <recorderptr, i> ->
  // <recorderptr, i-1> If i-1 == 0 then remove recorder for real.
  void DeleteRecorder(CAACostCalcRecorder *  recorder);
  // Will call the more specialized delete function...
  void DeleteRecorder(CRecorder * recorder);

  // To copy the recorder.
  virtual CAACostCalcRecorder * CopyRecorder(CAACostCalcRecorder * recorder) = 0;
  // Will call the more specialized copy function...
  CRecorder * CopyRecorder(CRecorder * recorder);

  // To count the types found iun the statement held by the node. Might return a 
  // new recorder. Ie. the caller should reset its _recorder to the recorder returned.
  virtual CAACostCalcRecorder * UpdateRecorderWithProgramCounterChange(CAACostCalcRecorder * rec, 
								       CECFGNode * pc_before, CECFGNode * pc_after) = 0;
  virtual CAACostCalcRecorder * UpdateRecorderWithProgramExit(CAACostCalcRecorder * rec, 
							      CECFGNode * pc_before) = 0;

  // Will call the more specialized update function...
  void UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after);
  void UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before);

	using CRecorderServer::UpdateRecorderWithProgramCounterChange;

	using CRecorderServer::UpdateRecorderWithProgramExit;	
	
  // To reset the recorder. Might return a new recorder. Ie.  the
  // caller should reset its _recorder to the recorder returned.
  virtual CAACostCalcRecorder * ResetRecorder(CAACostCalcRecorder * recorder) = 0;
  // Will call the more specialized reset function...
  void ResetRecorder(CRecorder ** recorder);

  // To merge two recorders. Return a new recorder.
  virtual CAACostCalcRecorder * MergeRecorders(CAACostCalcRecorder * recorder1,
                                                         CAACostCalcRecorder * recorder2) = 0;
  // Will call the more specialized merge function...
  CRecorder * MergeRecorders(CRecorder * rec1, CRecorder * rec2);

  // For printing the server
  void Print() {Print(&std::cout);};
  void Print(std::ostream * o);

protected:
  // All recorders are accessible from server by the <recorderptr, refs> map.
  // refs is a counter holding the number of references to the recorder.
  std::map<CAACostCalcRecorder *, int64_t> _recorder_to_refs;

  // Holds the things to record
  alf::CAlfCostLookupTable * _cost_lookup_table;
  bool _count_generic_nodes;
  bool _count_op_types;
  bool _count_stmts;
  bool _count_stmt_pairs;

  // If the best and worst case paths should be rembered 
  bool _record_min_cost_path;
  bool _record_max_cost_path;
};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CAACostCalcRecorderServer &a);

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CAACostCalcRecorderCOWServer
// - Recorder server for generating new recorders according to
// copy on write. Most functionality is inherited from CAACostCalcRecorderServer.
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CAACostCalcRecorderCOWServer : public CAACostCalcRecorderServer
{
public:

  // To create a COW node count recorder server. 
  CAACostCalcRecorderCOWServer(alf::CAlfCostLookupTable * cost_lookup_table,
			       bool count_generic_nodes, bool count_op_types, 
			       bool count_stmts, bool count_stmt_pairs,
			       bool record_min_cost_path=false,
			       bool record_max_cost_path=false);
  virtual ~CAACostCalcRecorderCOWServer();

  // For copying the recorder using copy on write. Will not do any copying
  // right away, instead it will just update the map as: <recorderptr, i>
  // -> <recorderptr, i+1>
  CAACostCalcRecorder * CopyRecorder(CAACostCalcRecorder * recorder);

  // To increase a count for a node in the recorder. Might return a
  // new recorder. Ie. the caller should reset its _recorder to the recorder
  // returned.  If <recorderptr, i> where i > 1 then copy recorder (for real),
  // do the update and return new copied and updated recorder
  // (recorderptr'). We add <recorderptr',1> to map, and update <recorderptr, i>
  // -> <recorderptr, i-1>.  else i == 1, then do the update on recorderptr
  // and return same recorderptr.
  CAACostCalcRecorder * CountGenericTypesWithRecorder(CAACostCalcRecorder * recorder,
						      CECFGNode * node);

  // To reset the recorder. Might return a new recorder. Ie.  the
  // caller should reset its _recorder to the recorder returned. If
  // <recorderptr, i> where i > 1 then copy recorder (for real), do
  // the update and return new copied and updated recorder
  // (recorderptr'). We add <recorderptr',1> to map, and update
  // <recorderptr, i> -> <recorderptr, i-1>.  else i == 1, then do the
  // update on recorderptr and return same recorderptr.
  CAACostCalcRecorder * UpdateRecorderWithProgramCounterChange(CAACostCalcRecorder * recorder,
							       CECFGNode * pc_before, CECFGNode * pc_after);
  CAACostCalcRecorder * UpdateRecorderWithProgramExit(CAACostCalcRecorder * recorder,
						      CECFGNode * pc_before);


  // To reset the recorder. Might return a new recorder. Ie.  the
  // caller should reset its _recorder to the recorder returned. If
  // <recorderptr, i> where i > 1 then copy recorder (for real), do
  // the update and return new copied and updated recorder
  // (recorderptr'). We add <recorderptr',1> to map, and update
  // <recorderptr, i> -> <recorderptr, i-1>.  else i == 1, then do the
  // update on recorderptr and return same recorderptr.
  CAACostCalcRecorder * ResetRecorder(CAACostCalcRecorder * recorder);

  // To merge two recorders. Return a new recorder. If both recorders
  // are the same we will just return a pointer to the recorder and
  // increase count as <recorderptr, i> -> <recorderptr, i+1>. Otherwise
  // we make the real merge make a new <newrecorderptr, 1> and return
  // the new recorder generated.
  CAACostCalcRecorder * MergeRecorders(CAACostCalcRecorder * recorder1,
				       CAACostCalcRecorder * recorder2);
  
};

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CAACostCalcRecorderNoReuseServer
// - Server implementing no reuse.
// - Most functionality is inherited from CAACostCalcRecorderServer.
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CAACostCalcRecorderNoReuseServer : public CAACostCalcRecorderServer
{
public:

  // To create a no reuse node count recorder server. 
  CAACostCalcRecorderNoReuseServer(alf::CAlfCostLookupTable * cost_lookup_table,
				   bool count_generic_nodes, bool count_op_types, 
				   bool count_stmts, bool count_stmt_pairs,
				   bool record_min_cost_path=false,
				   bool record_max_cost_path=false);
  virtual ~CAACostCalcRecorderNoReuseServer();

  // For copying the recorder the ordinary way (ie. diretly when Copy() is called).
  // Creates a new recorder and adds <recorderptr, 1> to the map.
  CAACostCalcRecorder * CopyRecorder(CAACostCalcRecorder * recorder);

  // For updating the recorder the ordinary way. Will not update map.
  CAACostCalcRecorder * UpdateRecorderWithProgramCounterChange(CAACostCalcRecorder * recorder,
							       CECFGNode * pc_before, CECFGNode * pc_after);
  CAACostCalcRecorder * UpdateRecorderWithProgramExit(CAACostCalcRecorder * recorder,
						      CECFGNode * pc_before);

  // For reseting the recorder the ordinary way.  Will not update map.
  CAACostCalcRecorder * ResetRecorder(CAACostCalcRecorder * recorder);

  // To merge two recorders the ordinary way. Return a new recorder
  // and adds <recorderptr, 1> to the map.
  CAACostCalcRecorder * MergeRecorders(CAACostCalcRecorder * recorder1,
				       CAACostCalcRecorder * recorder2);

};


#endif
