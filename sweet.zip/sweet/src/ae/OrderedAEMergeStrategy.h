#ifndef ORDEREDAEMERGESTRATEGY_H_INCLUDED
#define ORDEREDAEMERGESTRATEGY_H_INCLUDED

#include "AEStrategy.h"
#include <vector>
#include <set>
#include <map>
#include <list>
#include <queue>
#include <functional>

class CECFG;

/** Superclass to classes implementing ordered merge strategies. The ordering is
    given to it as a list of ECFG nodes corresponding to the merge points. */
template <typename MergeableState>
class OrderedAEMergeStrategy : public AEMergeStrategy<MergeableState>
{
public:
   /** @return @p true if the container holds more than 0 states, @p false otherwise */
   virtual bool StatesToMerge() const {return !index_queue.empty();}

   /** Insert the state @a state into the container */
   virtual void InsertState(std::unique_ptr<MergeableState> state);

   /** Merge states held by the container and put the resulting states into
       @a merged_states */
   virtual void MergeStates(MergeableStateColl<MergeableState> & merged_states);

   /** Get pointers to current states. The states may not be deleted or modified, and
       are still owned by this OrderedAEMergeStrategy */
   virtual void GetStates(std::vector<const MergeableState *> & states) const;

   /** Get all ECFG nodes comprising merge points, and in the same order as is
       used in the merge strategy */
   void GetMergePoints(std::vector<CECFGNode*>& merge_points) const;

protected:
   /** Abstract predicate class that should be implemented by subclasses. It is used to choose
       a state to release from a list of states waiting at the same merge point (after
       merging it with the other states in the list that it can be merged with). The
       () operator should perform a less-than comparison. The "largest" state at
       a merge point will always be chosen to release. */
   class StateOrdering
   {
   public:
      virtual bool operator ()(const MergeableState &, const MergeableState &) = 0;
   };

   /** Predicate class that delegates (less-than) comparisons to an internal object of
       type StateOrdering */
   class StateOrderingDelegator
   {
   public:
      StateOrderingDelegator(StateOrdering * state_ordering = 0)
         : state_ordering(state_ordering) {}

      virtual bool operator ()(const MergeableState * a, const MergeableState * b)
      {
         return (*state_ordering)(*a, *b);
      }

   private:
      StateOrdering * state_ordering;
   };

   OrderedAEMergeStrategy() {}

   ~OrderedAEMergeStrategy();

   /** Specify an ordering of merge points. If the ECFG nodes of two merge points A
       and B are present in @a ordered_merge_node_list, and A's node lies before B's,
       A will always be choosen before B when merging and releasing states from merge
       points. The @a state_ordering argument will be used to choose a state from the
       list of states at the merge point to release (after is has been merged with the
       other states at the same merge point that it can be merged with).
       @note The subclass (the caller) is responsible for both arguments */
   void InitializeWithMergePointOrdering(const std::list<CECFGNode *> & ordered_merge_node_list,
                                         StateOrdering * state_ordering);

private:
   typedef std::list<MergeableState *> StateList;
   typedef std::vector<StateList> StatesInMergePoints;
   typedef typename StateList::size_type IndexType;
   typedef std::map<CECFGNode *, IndexType> ECFGNodeToIndex;
   typedef std::priority_queue<IndexType, std::vector<IndexType>, 
      std::greater<IndexType> > IndexQueue;

   /** Maps (pointers to) ECFG nodes (merge points) to indices. The ECFG nodes 
       will be mapped to indices such that a node A will be
       mapped to a lower index than another node B if A lies before B
       in the list of nodes given to InitializeWithMergePointOrdering. */
   ECFGNodeToIndex ecfg_node_to_index;

   /** Predicate class used to find the "largest" state from a list of states that are
       waiting at a merge point. This will be the state to release from
       a merge point (after merging it with the other states at the same merge point
       that it can be merged with) when there are several merge points waiting
       at the same merge point. What defines that a state is "larger" than another
       state is controlled by the @a state_ordering argument to 
       InitializeWithMergePointOrdering(). */
   StateOrderingDelegator state_ordering_delegator;
   
   /** Holds a list for each merge point with the states currently waiting in that
       merge point. The merge points are indexed based on the list of merge-point
       nodes that were given to InitializeWithMergePointOrdering(). */
   StatesInMergePoints states_in_merge_points;
   
   /** Priority queue from which the currently smallest index of a merge point
       (see ecfg_node_to_index) that has states waiting on it can be retrieved. Used
       to choose the next merge point to merge and release states from. */
   IndexQueue index_queue;
};

/** Ordered merge strategy that orders merge points based on the post-dominance 
    relation between their ECFG nodes. If the ECFG nodes A and B of
    two merge points fulfill that B post-dominates A, then A will come before B
    in the ordering. */
template <typename MergeableState>
class PostDominanceOrderedAEMergeStrategy
   : public OrderedAEMergeStrategy<MergeableState>
{
public:
   PostDominanceOrderedAEMergeStrategy(const MergePointsHolder & merge_points_holder, const CECFG & ecfg, 
                                       bool use_bb_start_nodes=true);

private:
   class IndexVecStateOrdering 
      : public OrderedAEMergeStrategy<MergeableState>::StateOrdering
   {
   public:
      virtual bool operator ()(const MergeableState & a, const MergeableState & b);
   };

   /** Map representation of a tree of merge points, which maps (pointers to)
       ECFG nodes to their children */
   typedef std::map<CECFGNode *, std::set<CECFGNode *> > MergePointTree;

   IndexVecStateOrdering index_vec_state_ordering;

   /** Recursive function which traverses the tree @a rev_ipdom and puts the nodes
       post-ordered in the list @a ordered_node_list */
   static void CreateOrderedMergeNodeList(MergePointTree const& rev_ipdom,
      const std::set<CECFGNode *> & nodes, const MergePointsHolder & merge_points_holder,
      std::list<CECFGNode *> & ordered_node_list);
};

/** AE strategy which uses a depth-first strategy for fetching active states and a
    post-dominance-ordered merge strategy */
template <typename MergeableState>
class DepthFirstPostDomOrderedMergeAEStrategy
   : public DecoupledFetchAndMergeStrategies<MergeableState, 
   DepthFirstFetchStrategy<MergeableState>, 
   PostDominanceOrderedAEMergeStrategy<MergeableState> >
{
public:
   DepthFirstPostDomOrderedMergeAEStrategy(
      const MergePointsHolder & merge_points_holder,
      const CECFG & ecfg, std::unique_ptr<MergeableState> start_state);

private:
   /** Depth-first fetch strategy */
   DepthFirstFetchStrategy<MergeableState> df_fetch_strategy;

   /** Post-dominance-ordered merge strategy */
   PostDominanceOrderedAEMergeStrategy<MergeableState> pdo_merge_strategy;
};

#endif   // #ifndef ORDEREDAEMERGESTRATEGY_H_INCLUDED
