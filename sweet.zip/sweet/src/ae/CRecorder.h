/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE: Classes to inherit from. Exports functionality that all
//  recorders and recorder servers must export. No corresponding .cpp file is needed.
//
// ----------------------------------------------------------------------

#ifndef CRecorder_H_
#define CRecorder_H_

// Standard includes
#include <string>
#include <iostream>
#include <fstream>

// Extra includes
#include "graphs/ecfg/CECFGNode.h"
#include "program_state/State.h"
 
//----------------------------------------------------------------------
// -------------------------------------------------------
// CRecorder --
// A class to inherit from. The class is common ancestor for all
// recorders used in the abstract execution. The recorders are
// associated with an abstract state. They are however stored in the
// program recorder/counter.
// -------------------------------------------------------
//----------------------------------------------------------------------
class CRecorder 
{ 
public:

  // ---------------------------------
  // No create function since a lot of virtual functions
  // ---------------------------------
  virtual ~CRecorder() {};

  // The server class to be used to create new recorders. Allow copy on write functionality.
  friend class CRecorderServer;

  // Printing is made by calling the internal print function
  virtual void Print(std::ostream *o = &std::cout) = 0;
  friend std::ostream & operator << (std::ostream &o, CRecorder &r) { r.Print(&o); return o; }

private:

  // ---------------------------------
  // Things that must be implemented by all recorder subclasses
  // ---------------------------------
  virtual void UpdateWithProgramCounterChange(CECFGNode * pc_before, CECFGNode * pc_after) = 0;
  virtual void UpdateWithProgramExit(CECFGNode * pc_before) = 0;
  virtual CRecorder * Merge(CRecorder * other) = 0;
  virtual CRecorder * Copy(void) = 0;
  virtual void Reset(void) = 0;

  // ---------------------------------
  // Functions that may be overloaded by subclasses (but do not have to)
  // ---------------------------------
  virtual void UpdateWithProgramCounterChange(State * abs_state, CECFGNode * pc_before, CECFGNode * pc_after) { UpdateWithProgramCounterChange(pc_before, pc_after); }
  virtual void UpdateWithProgramExit(State * abs_state, CECFGNode * pc_before) { UpdateWithProgramExit(pc_before); }

};

//----------------------------------------------------------------------
// -------------------------------------------------------
// CRecorderServer --
// A class to inherit from. Implements functionality for 
// choisoing inbetween copy on write (COW) and normal handling 
// of recorders. All recorder creation, update, deletion, 
// etc should go through the server...
// -------------------------------------------------------
//----------------------------------------------------------------------
class CRecorderServer
{
public:

  // ---------------------------------
  // Things that must be implemented by all recorder server subclasses
  // ---------------------------------
  virtual ~CRecorderServer() {};
  virtual CRecorder * CreateRecorder() = 0;
  virtual void DeleteRecorder(CRecorder * rec) = 0;
  virtual CRecorder * CopyRecorder(CRecorder * rec) = 0;
  virtual void ResetRecorder(CRecorder ** rec) = 0;
  virtual CRecorder * MergeRecorders(CRecorder * rec1, CRecorder * rec2) = 0;
  virtual void UpdateRecorderWithProgramCounterChange(CRecorder ** rec, CECFGNode * pc_before, CECFGNode * pc_after) = 0;
  virtual void UpdateRecorderWithProgramExit(CRecorder ** rec, CECFGNode * pc_before) = 0;
  virtual void Print(void) {Print(&std::cout);};
  virtual void Print(std::ostream *o) = 0;

  // ---------------------------------
  // Functions that may be overloaded by subclasses (but do not have to)
  // ---------------------------------
  virtual void UpdateRecorderWithProgramCounterChange(CRecorder ** rec, State * abs_state, CECFGNode * pc_before, CECFGNode * pc_after) { UpdateRecorderWithProgramCounterChange(rec, pc_before, pc_after); }
  virtual void UpdateRecorderWithProgramExit(CRecorder ** rec, State * abs_state, CECFGNode * pc_before) { UpdateRecorderWithProgramExit(rec, pc_before); }
};

#endif
