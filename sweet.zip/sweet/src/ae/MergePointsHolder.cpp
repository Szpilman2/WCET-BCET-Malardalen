#include "MergePointsHolder.h"
#include "graphs/ecfg/CECFG.h"
#include "graphs/ecfg/CECFGNode.h"
#include "graphs/scopes/CScope.h"
#include "graphs/cfg/CFlowGraphNode.h"

// Public members of MergePointsHolder - - - - - - - - - - - - - - - - - - - ->

MergePointsHolder::MergePointsHolder(CECFG & ecfg, bool mp_fe, bool mp_fr, 
                                     bool mp_le, bool mp_be, bool mp_je)
{
   to_nodes.reserve(ecfg.NrOfNodes());
   for (CECFG::node_iterator n = ecfg.NodesBegin(); n != ecfg.NodesEnd(); ++n)
   {
      to_nodes.push_back(ToNodeData(**n, mp_fe, mp_fr, mp_le, mp_be, mp_je));
   }
}

bool MergePointsHolder::
IsMergePoint(const CECFGNode & from_node, const CECFGNode & to_node) const
{
   return to_nodes.at(to_node.Id()).IsMergePoint(from_node);
}

bool MergePointsHolder::IsMergePointSometimes(const CECFGNode & to_node) const
{
   return to_nodes.at(to_node.Id()).IsMergePointSometimes();
}

// Private members of MergePointsHolder - - - - - - - - - - - - - - - - - - - ->

// - - Public members of MergePointsHolder::ToNodeData - - - - - - - - - - - - ->

MergePointsHolder::ToNodeData::
ToNodeData(CECFGNode & node, bool mp_fe, bool mp_fr, bool mp_le,
           bool mp_be, bool mp_je)
: always_merge_point(false)
{
   // For each predecessor to the node, evaluate the conditions for the node being
   // a merge point that are given by mp_fe, mp_fr, mp_le, mp_be, and mp_je
   for (CECFGNode::pred_iterator p = node.PredBegin(); p != node.PredEnd(); ++p)
   {
      bool add_p = false;
      if (mp_fe)
      {
         // If the predecessor is a call statement, the current node is a function
         // entry node
         add_p = add_p || (*p)->GetFlowGraphNode()->Stmt()->Type() == CGenericStmt::GS_CALL;
      }
      if (mp_fr)
      {
         // If the predecessor is a return statement, the current node is a function
         // return node
         add_p = add_p || (*p)->GetFlowGraphNode()->Stmt()->Type() == CGenericStmt::GS_RETURN;
      }
      if (mp_le)
      {
         // If the scope has changed, the current scope is an ancestor to the previous, and
         // the previous scope is a loop scope, the current node is a loop exit node
         add_p = add_p || 
            ((*p)->Scope() != node.Scope() && 
            node.Scope()->IsAncestorOf((*p)->Scope()) &&
            (*p)->Scope()->Type() == CScope::LOOP);
      }
      if (mp_be)
      {
         // If we stay in the same scope, the target node is the header of the scope,
         // we must have followed a back-edge
         add_p = add_p ||
            (node.Scope() == (*p)->Scope() &&
            node.Scope()->IsHeader(&node));
      }
      if (mp_je)
      {
         // If the current node is a header node and has more non-back edge predecessors than one, or
         // it is a non-header node and has more than one predecessor, it is a joining-edge node
         add_p = add_p ||
            (node.Scope()->IsHeader(&node) && node.PredSize() - node.Scope()->Backedges()->size() > 1) ||
            (!node.Scope()->IsHeader(&node) && node.PredSize() > 1);
      }

      if (add_p) ingoing_merge_edges.push_back(*p);
   }
   if (ingoing_merge_edges.size() != 0 &&
       ingoing_merge_edges.size() == node.PredSize())
   {
      always_merge_point = true;
      ingoing_merge_edges.clear();
   }
}

bool MergePointsHolder::ToNodeData::
IsMergePoint(const CECFGNode & from_node) const
{
   if (always_merge_point)
      return true;
   if (ingoing_merge_edges.empty())
      return false;
   for (std::vector<CECFGNode *>::const_iterator p = ingoing_merge_edges.begin();
        p != ingoing_merge_edges.end(); ++p)
   {
      if (*p == &from_node)
         return true;
   }
   return false;
}

bool MergePointsHolder::ToNodeData::IsMergePointSometimes() const
{
   return always_merge_point || !ingoing_merge_edges.empty();
}
