/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CEdgeCountRecorder.h 5409 2013-06-16 15:04:47Z lkg02 $
//
// ----------------------------------------------------------------------

#ifndef CEdgeCountRecorder_H_
#define CEdgeCountRecorder_H_

#include <string>
#include <iostream>
#include <fstream>
#include <map>
#include <set>

// Forward declare the CScope structure (due to circular dependencies
// we do not want to include the CScope.h file)
class CScope;

// For getting nice macros
#include "macros.h"


// To get a suitable the range representation
#include "CIntegerRange.h"
// To get the scope node representation
#include "graphs/ecfg/CECFGNode.h"
// To get the collector
#include "CEdgeCountCollector.h"
// To get the CRecorder and CRecorderServer base classes
#include "CRecorder.h"

// To handle cout, cin, etc.


//----------------------------------------------------------------------
// Forward-declare types
//----------------------------------------------------------------------
class CEdgeCountRecorder;
typedef CEdgeCountRecorder * CEdgeCountRecorderPtr;
class CEdgeCountRecorderServer;
typedef CEdgeCountRecorderServer * CEdgeCountRecorderServerPtr;
class CEdgeCountRecorderCOWServer;
typedef CEdgeCountRecorderCOWServer * CEdgeCountRecorderCOWServerPtr;
class CEdgeCountRecorderNoReuseServer;
typedef CEdgeCountRecorderNoReuseServer * CEdgeCountRecorderNoReuseServerPtr;

// A mapping between scope edges and integer ranges
typedef std::map<std::pair<CECFGNode *, CECFGNode *>,CIntegerRange*> t_edge_to_range_map;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CEdgeCountRecorder
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CEdgeCountRecorder : public CRecorder
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------

  // Default behaviour is to only record edges inbeteween basic blocks. I.e. pairs
  // of nodes where the second node is the start node of a basic block.
  // Alternatively, the behaviour can be controlled by the boolean.
  CEdgeCountRecorder();
  CEdgeCountRecorder(bool record_only_edges_inbetween_basic_blocks);
  virtual ~CEdgeCountRecorder(void);

  //----------------------------------
  // To update the recorder with a new execution of a edge
  //---------------------------------
  void IncreaseCount(std::pair<CECFGNode *, CECFGNode *> edge);
  // Will call the more specialized IncreaseCount() function
  void UpdateWithProgramCounterChange(CECFGNode * pc_before, CECFGNode * pc_after);
  void UpdateWithProgramExit(CECFGNode * pc_before);

  //----------------------------------
  // Report the current counts to the edge count collector.
  //---------------------------------
  void ReportToCollector(CEdgeCountCollector * collector);

  // ---------------------------------
  // To get all node pairs which have an upper bound bigger than
  // zero. The second argeument should be set to tru if we instead of
  // giving pair <last_node_in_bb1,first_node_in_bb2> should give
  // <first_node_in_bb1,first_node_in_bb2> where the edge goes inbetween
  // bb1 and bb2.
  // ---------------------------------
  void GetTakenEdges(std::set<std::pair<CECFGNode *, CECFGNode *> > * node_pairs,
                     bool get_start_node_of_basic_block);

  //----------------------------------
  // Reset recorder. Will remove all edge to range mappings.
  //---------------------------------
  void Reset(void);

  //----------------------------------
  // To copy the recorder
  //---------------------------------
  CEdgeCountRecorderPtr Copy();

  //----------------------------------
  // To merge two recorders (LUB)
  //---------------------------------
  CEdgeCountRecorderPtr Merge(CEdgeCountRecorderPtr other_recorder);
  // Will call the more specialized Merge() function...
  CRecorder * Merge(CRecorder * other_recorder);

  // ---------------------------------
  // For printing the recorder
  // ---------------------------------
  void Print() {Print(&std::cout);};
  void Print(std::ostream * o);

protected:

  // To set the count or range of a certain edge
  void SetCount(std::pair<CECFGNode *, CECFGNode *> edge, int count);
  void SetRange(std::pair<CECFGNode *, CECFGNode *> edge, CIntegerRange* range);

  // A mapping between edge ids and ranges. The range can never get more
  // than one value due to a normal IncreaseCount call. Ranges of values
  // only appear due to merge of recorders in state merges.
  t_edge_to_range_map _edge_to_range_map;

  // A boolean keeping track on if all type of edges should be recorded, or just
  // edges going inbetween basic blocks.
  bool _record_only_edges_inbetween_basic_blocks;

};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CEdgeCountRecorder &a);


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CEdgeCountRecorderServer
// - Server for generating new edge count recorders
// - To inherit from
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CEdgeCountRecorderServer : public CRecorderServer
{
public:
  // To create an edge count recorder server. Default behaviour is to
  // only record edges inbetween basic block headers. Alternatively,
  // the behaviour can be controlled by the boolean argument.
  CEdgeCountRecorderServer();
  CEdgeCountRecorderServer(bool record_only_edges_inbetween_basic_blocks);
  virtual ~CEdgeCountRecorderServer() {};

  // For creating a new recorder. Will allocate the recorder and add
  // <recorderptr,1> to the map.
  CEdgeCountRecorderPtr CreateRecorder();

  // For deleting a recorder. When deleting a recorder then <recorderptr, i> ->
  // <recorderptr, i-1> If i-1 == 0 then remove recorder for real.
  void DeleteRecorder(CEdgeCountRecorderPtr recorder);
    // Will call the more specialized delete function...
  void DeleteRecorder(CRecorder * recorder);

  // To copy the recorder. Returns maybe a new recorder. Ie.
  // the caller should reset its _recorder to the recorder returned.
  virtual CEdgeCountRecorderPtr CopyRecorder(CEdgeCountRecorderPtr recorder) = 0;
  // Will call the more specialized copy function...
  CRecorder * CopyRecorder(CRecorder * recorder);

  // To increase the count of the recorder. Might return a new recorder. Ie.
  // the caller should reset its _recorder to the recorder returned.
  virtual CEdgeCountRecorderPtr IncreaseCountInRecorder(CEdgeCountRecorderPtr recorder,
                                                        std::pair<CECFGNode *, CECFGNode *> edge) = 0;
  // Will call the more specialized increase count function...
  virtual void UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after);
  virtual void UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before);

  // To reset the recorder. Might return a new recorder. Ie.  the
  // caller should reset its _recorder to the recorder returned.
  virtual CEdgeCountRecorderPtr ResetRecorder(CEdgeCountRecorderPtr recorder) = 0;
  // Will call the more specialized reset function...
  virtual void ResetRecorder(CRecorder ** recorder);

  // To merge two recorders. Return a new recorder.
  virtual CEdgeCountRecorderPtr MergeRecorders(CEdgeCountRecorderPtr recorder1,
                                               CEdgeCountRecorderPtr recorder2) = 0;
  // Will call the more specialized merge function...
  CRecorder * MergeRecorders(CRecorder * rec1, CRecorder * rec2);

  // For printing the server
  void Print() {Print(&std::cout);};
  void Print(std::ostream * o);

protected:
  // All recorders are accessible from server by the <recorderptr, refs> map.
  // refs is a counter holding the number of references to the recorder.
  std::map<CEdgeCountRecorderPtr, int64_t> _recorder_to_refs;

  // To keep track of if only edges inbetween bbs should be
  // recorded. If not set all edges between ECFG;
  bool _record_only_edges_inbetween_basic_blocks;

};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CEdgeCountRecorderServer &a);

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CEdgeCountRecorderCOWServer
// - Recorder server for generating new recorders according to
// copy on write. Most functionality is inherited from CEdgeCountRecorderServer.
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CEdgeCountRecorderCOWServer : public CEdgeCountRecorderServer
{
public:
  // To create and delete the recorder server. Default behaviour is to
  // only record edges inbetween basic block headers. Alternatively,
  // the behaviour can be controlled by the boolean argument.
  CEdgeCountRecorderCOWServer();
  CEdgeCountRecorderCOWServer(bool record_only_edges_inbetween_basic_blocks);
  virtual ~CEdgeCountRecorderCOWServer();

  // For copying the recorder using copy on write. Will not do any copying
  // right away, instead it will just update the map as: <recorderptr, i>
  // -> <recorderptr, i+1>
  CEdgeCountRecorderPtr CopyRecorder(CEdgeCountRecorderPtr recorder);

  // To increase a count for a edge in the recorder. Might return a
  // new recorder. Ie.  the caller should reset its _recorder to the recorder
  // returned.  If <recorderptr, i> where i > 1 then copy recorder (for real),
  // do the update and return new copied and updated recorder
  // (recorderptr'). We add <recorderptr',1> to map, and update <recorderptr, i>
  // -> <recorderptr, i-1>.  else i == 1, then do the update on recorderptr
  // and return same recorderptr.
  CEdgeCountRecorderPtr IncreaseCountInRecorder(CEdgeCountRecorderPtr recorder,
                                                std::pair<CECFGNode *, CECFGNode *> edge);

  // To reset the recorder. Might return a new recorder. Ie.  the
  // caller should reset its _recorder to the recorder returned. If
  // <recorderptr, i> where i > 1 then copy recorder (for real), do
  // the update and return new copied and updated recorder
  // (recorderptr'). We add <recorderptr',1> to map, and update
  // <recorderptr, i> -> <recorderptr, i-1>.  else i == 1, then do the
  // update on recorderptr and return same recorderptr.
  CEdgeCountRecorderPtr ResetRecorder(CEdgeCountRecorderPtr recorder);

  // To merge two recorders. Return a new recorder. If both recorders
  // are the same we will just return a pointer to the recorder and
  // increase count as <recorderptr, i> -> <recorderptr, i+1>. Otherwise
  // we make the real merge make a new <newrecorderptr, 1> and return
  // the new recorder generated.
  CEdgeCountRecorderPtr MergeRecorders(CEdgeCountRecorderPtr recorder1,
                                       CEdgeCountRecorderPtr recorder2);

};

//------------------------------------------------------------
//--------------------------------------------------
// CEdgeCountRecorderNoReuseServer
// - Server implementing no reuse.
// - Most functionality is inherited from CEdgeCountRecorderServer.
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CEdgeCountRecorderNoReuseServer : public CEdgeCountRecorderServer
{
public:

  // To create and delete the recorder server. Default behaviour is to
  // only record edges inbetween basic block headers. Alternatively,
  // the behaviour can be controlled by the boolean argument.
  CEdgeCountRecorderNoReuseServer();
  CEdgeCountRecorderNoReuseServer(bool record_only_edges_inbetween_basic_blocks);
  virtual ~CEdgeCountRecorderNoReuseServer();

  // For copying the recorder the ordinary way (ie. diretly when Copy() is called).
  // Creates a new recorder and adds <recorderptr, 1> to the map.
  CEdgeCountRecorderPtr CopyRecorder(CEdgeCountRecorderPtr recorder);

  // For updating the recorder the ordinary way. Will not update map.
  CEdgeCountRecorderPtr IncreaseCountInRecorder(CEdgeCountRecorderPtr recorder,
                                                std::pair<CECFGNode *, CECFGNode *> edge);

  // For reseting the recorder the ordinary way.  Will not update map.
  CEdgeCountRecorderPtr ResetRecorder(CEdgeCountRecorderPtr recorder);

  // To merge two recorders the ordinary way. Return a new recorder
  // and adds <recorderptr, 1> to the map.
  CEdgeCountRecorderPtr MergeRecorders(CEdgeCountRecorderPtr recorder1,
                                       CEdgeCountRecorderPtr recorder2);

};

#endif
