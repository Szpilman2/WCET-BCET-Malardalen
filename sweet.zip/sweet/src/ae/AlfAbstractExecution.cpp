#include "ae/AlfAbstractExecution.h"
#include "ae/AEStrategy.h"
#include "ae/OrderedAEMergeStrategy.h"
#include "ae/MergePointsHolder.h"
#include "ae/CNodeCountRecorder.h"
#include "ae/CEdgeCountRecorder.h"
#include "ae/CIterNodePairCollector.h"
#include "ae/CIterNodeCountCollector.h"
#include "ae/CRecorderHolderSet.h"
#include "ae/CGenericNodeTypeCountRecorder.h"
#include "ae/CGenericNodeTypeCountCollector.h"
#include "ae/CNodeCountCollector.h"
#include "ae/CNodePairCountCollector.h"
#include "ae/CCollector.h"
#include "ae/CTraceHolder.h"
#include "absann/CALFAbsAnnot.h"
#include "cmd/CCommandAE.h"
#include "graphs/scopes/CScopeGraph.h"
#include "graphs/ecfg/CECFG.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/ecfg/CECFGNode.h"
#include "globals.h"
#include "program/CGenericFunction.h"
#include "program/CGenericStmt.h"
#include "program/alf/alf.h"
#include "program/alf/CFuncTuple.h"
#include "program_state/AlfVM.h"
#include "program_state/AlfVMTraceDebugger.h"
#include "program_state/AlfVMInterDebugger.h"
#include "program_state/State.h"
#include "program_state/PPEnviron.h"
#include "program_state/value/ValueDomain.h"
#include "program_state/value/IntInterval.h"
#include "program_state/value/FloatIntervalVal.h"
#include "program_state/value/OpPolicies.h"
#include "program_state/value/clp/ClpValue.h"
#include "program_state/value/clp/SymbClpPtrSet.h"
#include "program_state/value/clp/OpPolicies_Clp.h"
#include "program_state/memory/SymbMemory.h"
#include "program_state/memory/Frame.h"
#include "program_state/memory/FrameColl.h"
#include "program_state/program_counter/ProgramCounterECFG_AE.h"
#include "program_state/program_counter/ProgramPointECFG.h"
#include "tools/IndentingOStream.h"
#include "tools/TextTable.h"
#include "tcalc/CBBCostLookupTable.h"
#include "ae/CAACostCalcRecorder.h"
#include "ae/CAACostCalcCollector.h" 
#include "ae/CBBCostCalcRecorder.h"
#include "ae/CBBCostCalcCollector.h" 

#include <list>

#define KEEP_TRACK_OF_BB_START_NODES_ONLY true

using namespace std;
using namespace alf;

AESettings::AESettings()
: debug(NONE)
{
   merge.fe = false;
   merge.fr = false;
   merge.le = false;
   merge.be = false;
   merge.je = false;
}

void
AESettings::
SetFFGMode(cmd::CCommandAE::FFG_KEY ffg_mode, bool value)
{
   switch (ffg_mode) {
   case cmd::CCommandAE::UHSS: ffg.uhss = value; break;
   case cmd::CCommandAE::LHSS: ffg.lhss = value; break;
   case cmd::CCommandAE::UHSF: ffg.uhsf = value; break;
   case cmd::CCommandAE::LHSF: ffg.lhsf = value; break;
   case cmd::CCommandAE::UHSP: ffg.uhsp = value; break;
   case cmd::CCommandAE::LHSP: ffg.lhsp = value; break;
   case cmd::CCommandAE::UNSS: ffg.unss = value; break; 
   case cmd::CCommandAE::LNSS: ffg.lnss = value; break; 
   case cmd::CCommandAE::UNSF: ffg.unsf = value; break; 
   case cmd::CCommandAE::LNSF: ffg.lnsf = value; break; 
   case cmd::CCommandAE::UNSP: ffg.unsp = value; break; 
   case cmd::CCommandAE::LNSP: ffg.lnsp = value; break; 
   case cmd::CCommandAE::INSE: ffg.inse = value; break; 
   case cmd::CCommandAE::INSA: ffg.insa = value; break; 
   case cmd::CCommandAE::UNPS: ffg.unps = value; break; 
   case cmd::CCommandAE::LNPS: ffg.lnps = value; break; 
   case cmd::CCommandAE::UNPF: ffg.unpf = value; break; 
   case cmd::CCommandAE::LNPF: ffg.lnpf = value; break; 
   case cmd::CCommandAE::UNPP: ffg.unpp = value; break; 
   case cmd::CCommandAE::LNPP: ffg.lnpp = value; break; 
   case cmd::CCommandAE::INPA: ffg.inpa = value; break; 
   case cmd::CCommandAE::INNA: ffg.inna = value; break; 
   case cmd::CCommandAE::UHPF: ffg.uhpf = value; break; 
   case cmd::CCommandAE::LHPF: ffg.lhpf = value; break; 
   case cmd::CCommandAE::UHPP: ffg.uhpp = value; break; 
   case cmd::CCommandAE::LHPP: ffg.lhpp = value; break; 
   case cmd::CCommandAE::UESS: ffg.uess = value; break; 
   case cmd::CCommandAE::LESS: ffg.less = value; break; 
   case cmd::CCommandAE::UESF: ffg.uesf = value; break; 
   case cmd::CCommandAE::LESF: ffg.lesf = value; break; 
   case cmd::CCommandAE::UESP: ffg.uesp = value; break; 
   case cmd::CCommandAE::LESP: ffg.lesp = value; break; 
   case cmd::CCommandAE::UCSF: ffg.ucsf = value; break; 
   case cmd::CCommandAE::LCSF: ffg.lcsf = value; break; 
   case cmd::CCommandAE::UCSP: ffg.ucsp = value; break; 
   case cmd::CCommandAE::LCSP: ffg.lcsp = value; break; 
   case cmd::CCommandAE::UBSS: ffg.ubss = value; break; 
   case cmd::CCommandAE::LBSS: ffg.lbss = value; break; 
   case cmd::CCommandAE::UBSF: ffg.ubsf = value; break; 
   case cmd::CCommandAE::LBSF: ffg.lbsf = value; break; 
   case cmd::CCommandAE::UBSP: ffg.ubsp = value; break; 
   case cmd::CCommandAE::LBSP: ffg.lbsp = value; break; 
   case cmd::CCommandAE::UBNS: ffg.ubns = value; break; 
   case cmd::CCommandAE::LBNS: ffg.lbns = value; break; 
   // These are handled before  
   case cmd::CCommandAE::ALL_FFGS: break;
   case cmd::CCommandAE::UB_FFGS: break;
   case cmd::CCommandAE::LB_FFGS: break;
   default: 
     throw logic_error("Internal error. There is no such cmd::CCommandAE enum value!");
   }
}


// Four dimensional space used to specify flow fact generators:
// 1. bounds derived: upper (max), lower & upper (min & max), infeasible (upper = 0) (u,l,i)
// 2. type of entities kept track of: headers, vertices, edges (h,v,e)
// 3. how entity executions are related: single, pair (couple), paths (s,c,p)
// 4. when flow constraint valid: each iteration, all iterations, scope, loop-nest, func scope, global (i,a,s,n,f,g)
typedef enum { UPPER, LOWER_UPPER, INFEASIBLE } t_bounds_derived;   // uli
typedef enum { HEADERS, NODES, EDGES, CALL_EDGES, LOOP_BODY_BEGIN_EDGES } t_entities_kept_track_of;  // hne
typedef enum { SINGLE, PAIRS, PATHS, SUM } t_combination_of_entities;  // spn
typedef enum { EACH_ITERATION, ALL_ITERATIONS, SCOPE, FUNCTION, PROGRAM } t_flow_fact_context; // easlfp

// -------------------------------------------------------
// Help functions for printing t_bounds_derived enum
// -------------------------------------------------------
void PrintBoundsDerived(t_bounds_derived bounds_derived, ostream & o = cout)
{
  switch(bounds_derived)
    {
    case UPPER: o << "UPPER"; break;
    case LOWER_UPPER: o << "LOWER_UPPER"; break;
    case INFEASIBLE: o << "INFEASIBLE"; break;
    }
}
ostream &operator<<(ostream &o, t_bounds_derived &a) { PrintBoundsDerived(a, o); return o; }

// -------------------------------------------------------
// Help function for printing t_entities_kept_track_of enum
// -------------------------------------------------------
void PrintEntitiesKeptTrackOf(t_entities_kept_track_of entities_kept_track_of, ostream & o = cout)
{
  switch(entities_kept_track_of)
    {
    case HEADERS: o << "HEADERS"; break;
    case NODES: o << "NODES"; break;
    case EDGES: o << "EDGES"; break;
    case CALL_EDGES: o << "CALL_EDGES"; break;
    case LOOP_BODY_BEGIN_EDGES: o << "LOOP_BODY_BEGIN_EDGES"; break;
    }
}
ostream &operator<<(ostream &o, t_entities_kept_track_of &a) { PrintEntitiesKeptTrackOf(a, o); return o; }

// -------------------------------------------------------
// Help function for printing t_combination_of_entities enum
// -------------------------------------------------------
void PrintCombinationOfEntities(t_combination_of_entities combination_of_entities, ostream & o = cout)
{
  switch(combination_of_entities)
    {
    case SINGLE: o << "SINGLE"; break;
    case PAIRS: o << "PAIRS"; break;
    case PATHS: o << "PATHS"; break;
    case SUM: o << "PATHS"; break;
    }
}
ostream &operator<<(ostream &o, t_combination_of_entities &a) { PrintCombinationOfEntities(a, o); return o; }

// -------------------------------------------------------
// Help function for printing t_flow_fact_context
// -------------------------------------------------------
void PrintFlowFactContext(t_flow_fact_context flow_fact_context, ostream & o = cout)
{
  switch(flow_fact_context)
    {
    case EACH_ITERATION: o << "EACH_ITERATION"; break;
    case ALL_ITERATIONS: o << "ALL_ITERATIONS"; break;
    case SCOPE: o << "SCOPE"; break;
    // case LOOP_NEST: o << "LOOP_NEST"; break;
    case FUNCTION: o << "FUNCTION"; break;
    case PROGRAM: o << "PROGRAM"; break;
    }
}
ostream &operator<<(ostream &o, t_flow_fact_context &a) { PrintFlowFactContext(a, o); return o; }

// -------------------------------------------------------
// Help function to collect scopes to create collectors for
// -------------------------------------------------------
void GetScopesToCreateCollectorsFor(CScopeGraph * sg, t_flow_fact_context flow_fact_context,
                                    vector<CScope *> * scopes_to_create_collectors_for)
{
  if(flow_fact_context == EACH_ITERATION || flow_fact_context == ALL_ITERATIONS ||
     flow_fact_context == SCOPE) {
    // All scopes should be included
    for(CScopeGraph::node_iterator scope = sg->NodesBegin(); scope != sg->NodesEnd(); scope++) {
      scopes_to_create_collectors_for->push_back(*scope);
    }
  }
  else if(flow_fact_context == FUNCTION) {
    // Only function scopes should be included
    sg->FunctionScopes(scopes_to_create_collectors_for);
  }
  else if(flow_fact_context == PROGRAM) {
    // Only the root scope in the scope graph should be included
    scopes_to_create_collectors_for->push_back(sg->Root());
  }
  // else if(flow_fact_context == LOOP_NEST) {
  //     // Only top scope in loop nests should be included
  //     for(CScopeGraph::node_iterator scope = sg->NodesBegin(); scope != sg->NodesEnd(); scope++) {
  //       if((*scope)->IsLoopScope() && (*scope)->FunctionScope()->IsSucc(*scope))
  //         scopes_to_create_collectors_for->push_back(*scope);
  //     }
  //   }
  else {
    assert(0);
  }
}

// -------------------------------------------------------
// Macros for specifying what collectors and servers to
// create 
// -------------------------------------------------------
#define RECORDER_AND_COLLECTOR_CREATION_CODE(COLLECTOR_TYPE_NAME, RECORDER_SERVER, RECORDER_HOLDER_TYPE_NAME, FLOW_FACT_CONTEXT) \
{ \
   vector<CScope *> scopes_to_create_collectors_for; \
   GetScopesToCreateCollectorsFor(sg, FLOW_FACT_CONTEXT, &scopes_to_create_collectors_for); \
   map<CScope *, CCollector *> * scope_to_collector_map = new map<CScope *, CCollector *>(); \
   for(vector<CScope *>::iterator scope = scopes_to_create_collectors_for.begin(); \
       scope != scopes_to_create_collectors_for.end(); ++scope) { \
     CCollector * collector = new COLLECTOR_TYPE_NAME(*scope, KEEP_TRACK_OF_BB_START_NODES_ONLY);   \
       (*scope_to_collector_map)[*scope] = collector; \
       collectors.push_back(collector); \
  } \
  sc_maps.push_back(scope_to_collector_map); \
  CRecorderHolder * rec_holder = new RECORDER_HOLDER_TYPE_NAME(scope_to_collector_map, RECORDER_SERVER); \
  rhs_server->AddRecorderHolderToRecorderHolderSet(&rhs, rec_holder); \
} \

#define RECORDER_AND_COLLECTOR_CREATION_CODE2(COLLECTOR_TYPE_NAME, RECORDER_SERVER, RECORDER_HOLDER_TYPE_NAME, FLOW_FACT_CONTEXT, EXTRA_THINGS_TO_CONSIDER) \
{ \
   vector<CScope *> scopes_to_create_collectors_for; \
   GetScopesToCreateCollectorsFor(sg, FLOW_FACT_CONTEXT, &scopes_to_create_collectors_for); \
   map<CScope *, CCollector *> * scope_to_collector_map = new map<CScope *, CCollector *>(); \
   for(vector<CScope *>::iterator scope = scopes_to_create_collectors_for.begin(); \
       scope != scopes_to_create_collectors_for.end(); ++scope) { \
     CCollector * collector = new COLLECTOR_TYPE_NAME(*scope, KEEP_TRACK_OF_BB_START_NODES_ONLY, EXTRA_THINGS_TO_CONSIDER);   \
       (*scope_to_collector_map)[*scope] = collector; \
       collectors.push_back(collector); \
  } \
  sc_maps.push_back(scope_to_collector_map); \
  CRecorderHolder * rec_holder = new RECORDER_HOLDER_TYPE_NAME(scope_to_collector_map, RECORDER_SERVER); \
  rhs_server->AddRecorderHolderToRecorderHolderSet(&rhs, rec_holder); \
} \


// Help function to create flow fact generators (i.e. recorders and collectors)
void
SetUpFlowFactGeneration(const AESettings *settings, std::vector<CCollector *> &collectors,
                        std::vector<std::map<CScope *, CCollector *> *> &sc_maps, CScopeGraph * sg,
                        CNodeCountRecorderServer * node_rec_server, 
                        CIterNodeCountRecorderServer * iter_node_rec_server, 
                        CEdgeCountRecorderServer * edge_rec_server, 
                        CRecorderHolderSetServer * rhs_server, CRecorderHolderSet * rhs)
  
{
   // ---------------------------------
   // Headers
   // ---------------------------------

   // -- Scope local headers
   if(settings->ffg.uhss || settings->ffg.lhss) {     
     if(settings->ffg.uhss && settings->ffg.lhss) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinMaxHeaderNodeCountScopeCollector, node_rec_server, CScopeRecorderHolder, SCOPE); }
     else if(settings->ffg.uhss) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMaxHeaderNodeCountScopeCollector, node_rec_server, CScopeRecorderHolder, SCOPE); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinHeaderNodeCountScopeCollector, node_rec_server, CScopeRecorderHolder, SCOPE); }
   } 
   // -- Function local headers
   if(settings->ffg.uhsf || settings->ffg.lhsf) { 
     if(settings->ffg.uhsf && settings->ffg.lhsf) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinMaxHeaderNodeCountScopeAndLoopSubCollector, node_rec_server, CFunctionRecorderHolder, FUNCTION); }
     else if(settings->ffg.uhsf) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMaxHeaderNodeCountScopeAndLoopSubCollector, node_rec_server, CFunctionRecorderHolder, FUNCTION); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinHeaderNodeCountScopeAndLoopSubCollector, node_rec_server, CFunctionRecorderHolder, FUNCTION); }
   }
   // -- Program local headers
   if(settings->ffg.uhsp || settings->ffg.lhsp) { 
     if(settings->ffg.uhsp && settings->ffg.lhsp) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinMaxHeaderNodeCountScopeAndSubCollector, node_rec_server, CProgramRecorderHolder, PROGRAM); }
     else if(settings->ffg.uhsp) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMaxHeaderNodeCountScopeAndSubCollector, node_rec_server, CProgramRecorderHolder, PROGRAM); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinHeaderNodeCountScopeAndSubCollector, node_rec_server, CProgramRecorderHolder, PROGRAM); }
   }

   // ---------------------------------
   // Nodes
   // ---------------------------------

   // -- Scope local nodes
   if(settings->ffg.unss || settings->ffg.lnss) {     
     if(settings->ffg.unss && settings->ffg.lnss) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinMaxNodeCountScopeCollector, node_rec_server, CScopeRecorderHolder, SCOPE); }
     else if(settings->ffg.unss) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMaxNodeCountScopeCollector, node_rec_server, CScopeRecorderHolder, SCOPE); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinNodeCountScopeCollector, node_rec_server, CScopeRecorderHolder, SCOPE); }
   } 
   // -- Function local nodes
   if(settings->ffg.unsf || settings->ffg.lnsf) { 
     if(settings->ffg.unsf && settings->ffg.lnsf) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinMaxNodeCountScopeAndLoopSubCollector, node_rec_server, CFunctionRecorderHolder, FUNCTION); }
     else if(settings->ffg.unsf) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMaxNodeCountScopeAndLoopSubCollector, node_rec_server, CFunctionRecorderHolder, FUNCTION); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinNodeCountScopeAndLoopSubCollector, node_rec_server, CFunctionRecorderHolder, FUNCTION); }
   }
   // -- Program local nodes
   if(settings->ffg.unsp || settings->ffg.lnsp) { 
     if(settings->ffg.unsp && settings->ffg.lnsp) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinMaxNodeCountScopeAndSubCollector, node_rec_server, CProgramRecorderHolder, PROGRAM); }
     else if(settings->ffg.unsp) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMaxNodeCountScopeAndSubCollector, node_rec_server, CProgramRecorderHolder, PROGRAM); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinNodeCountScopeAndSubCollector, node_rec_server, CProgramRecorderHolder, PROGRAM); }
   }
   // -- Infeasible node each individual iteration per scope
   if(settings->ffg.inse) { RECORDER_AND_COLLECTOR_CREATION_CODE(CEachIterNodeCountCollector, iter_node_rec_server, CIterRecorderHolder, EACH_ITERATION); }
   // -- Infeasible node all iterations of scope
   if(settings->ffg.insa) { RECORDER_AND_COLLECTOR_CREATION_CODE(CAllIterNodeCountCollector, iter_node_rec_server, CIterRecorderHolder, ALL_ITERATIONS); }

   // ---------------------------------
   // Node pairs
   // ---------------------------------

   // To avoid making an unneccessary must and may analysis
   if( settings->ffg.unps || settings->ffg.lnps || 
       settings->ffg.unpf || settings->ffg.lnpf ||
       settings->ffg.unpp || settings->ffg.lnpp ) {
     
     // Collect those node pairs that are interestign to keep track of
     std::set<std::pair<CECFGNode *, CECFGNode *> > node_pairs_to_consider;
     CNodePairCountCollector::DeriveMayButNotMustBeTakenNodePairs(sg, true, &node_pairs_to_consider);

     // -- Scope local node pairs
     if(settings->ffg.unps || settings->ffg.lnps) {     
       if(settings->ffg.unps && settings->ffg.lnps) { RECORDER_AND_COLLECTOR_CREATION_CODE2(CMinMaxNodePairCountScopeCollector, node_rec_server, CScopeRecorderHolder, SCOPE, &node_pairs_to_consider); }
       else if(settings->ffg.unps) { RECORDER_AND_COLLECTOR_CREATION_CODE2(CMaxNodePairCountScopeCollector, node_rec_server, CScopeRecorderHolder, SCOPE, &node_pairs_to_consider); }
       else { RECORDER_AND_COLLECTOR_CREATION_CODE2(CMinNodePairCountScopeCollector, node_rec_server, CScopeRecorderHolder, SCOPE, &node_pairs_to_consider); }
     } 
     // -- Function local node pairs
     if(settings->ffg.unpf || settings->ffg.lnpf) { 
       if(settings->ffg.unpf && settings->ffg.lnpf) { RECORDER_AND_COLLECTOR_CREATION_CODE2(CMinMaxNodePairCountScopeAndLoopSubCollector, node_rec_server, CFunctionRecorderHolder, FUNCTION, &node_pairs_to_consider); }
       else if(settings->ffg.unpf) { RECORDER_AND_COLLECTOR_CREATION_CODE2(CMaxNodePairCountScopeAndLoopSubCollector, node_rec_server, CFunctionRecorderHolder, FUNCTION, &node_pairs_to_consider); }
       else { RECORDER_AND_COLLECTOR_CREATION_CODE2(CMinNodePairCountScopeAndLoopSubCollector, node_rec_server, CFunctionRecorderHolder, FUNCTION, &node_pairs_to_consider); }
     } 
     // -- Program local node pairs
     if(settings->ffg.unpp || settings->ffg.lnpp) { 
       if(settings->ffg.unpp && settings->ffg.lnpp) { RECORDER_AND_COLLECTOR_CREATION_CODE2(CMinMaxNodePairCountScopeAndSubCollector, node_rec_server, CProgramRecorderHolder, PROGRAM, &node_pairs_to_consider); }
       else if(settings->ffg.unpp) { RECORDER_AND_COLLECTOR_CREATION_CODE2(CMaxNodePairCountScopeAndSubCollector, node_rec_server, CProgramRecorderHolder, PROGRAM, &node_pairs_to_consider); }
       else { RECORDER_AND_COLLECTOR_CREATION_CODE2(CMinNodePairCountScopeAndSubCollector, node_rec_server, CProgramRecorderHolder, PROGRAM, &node_pairs_to_consider); }
     }
   }

   // -- Infeasible node pairs for all iterations of scope
   if(settings->ffg.inpa) {
     if(settings->DoMerging()) { RECORDER_AND_COLLECTOR_CREATION_CODE(CIterMutualExclusiveNodePairCollector, iter_node_rec_server, CIterRecorderHolder, ALL_ITERATIONS); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE( CIterMutualExclusiveAndMustBeTakenTogetherNodePairCollector, iter_node_rec_server, CIterRecorderHolder, ALL_ITERATIONS); }
   }
   // -- Infeasible node paths for all iterations of scope
   if(settings->ffg.inna) { 
     // *** Removed due to found_header assert *** 
     // RECORDER_AND_COLLECTOR_CREATION_CODE(CIterPathTreeCollector, edge_rec_server, CIterRecorderHolder, ALL_ITERATIONS); 
   }

   // ---------------------------------
   // Node header pairs
   // ---------------------------------

   // -- Function local header pairs'
   if(settings->ffg.uhpf || settings->ffg.lhpf) {     
     if(settings->ffg.uhpf && settings->ffg.lhpf) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinMaxHeaderNodePairCountScopeAndLoopSubCollector, node_rec_server, CFunctionRecorderHolder, FUNCTION); }
     else if(settings->ffg.uhpf) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMaxHeaderNodePairCountScopeAndLoopSubCollector, node_rec_server, CFunctionRecorderHolder, FUNCTION); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinHeaderNodePairCountScopeAndLoopSubCollector, node_rec_server, CFunctionRecorderHolder, FUNCTION); }
   } 
   // -- Program local node pairs
   if(settings->ffg.uhpp || settings->ffg.lhpp) { 
     if(settings->ffg.uhpp && settings->ffg.lhpp) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinMaxHeaderNodePairCountScopeAndSubCollector, node_rec_server, CProgramRecorderHolder, PROGRAM); }
     else if(settings->ffg.uhpp) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMaxHeaderNodePairCountScopeAndSubCollector, node_rec_server, CProgramRecorderHolder, PROGRAM); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinHeaderNodePairCountScopeAndSubCollector, node_rec_server, CProgramRecorderHolder, PROGRAM); }
   }

   // ---------------------------------
   // -- Edges
   // ---------------------------------
   
   // -- Scope local edges
   if(settings->ffg.uess || settings->ffg.less) {     
     if(settings->ffg.uess && settings->ffg.less) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinMaxEdgeCountScopeCollector, edge_rec_server, CScopeRecorderHolder, SCOPE); }
     else if(settings->ffg.uess) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMaxEdgeCountScopeCollector, edge_rec_server, CScopeRecorderHolder, SCOPE); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinEdgeCountScopeCollector, edge_rec_server, CScopeRecorderHolder, SCOPE); }
   } 
   // -- Function local edges
   if(settings->ffg.uesf || settings->ffg.lesf) { 
     if(settings->ffg.uesf && settings->ffg.lesf) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinMaxEdgeCountScopeAndLoopSubCollector, edge_rec_server, CFunctionRecorderHolder, FUNCTION); }
     else if(settings->ffg.uesf) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMaxEdgeCountScopeAndLoopSubCollector, edge_rec_server, CFunctionRecorderHolder, FUNCTION); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinEdgeCountScopeAndLoopSubCollector, edge_rec_server, CFunctionRecorderHolder, FUNCTION); }
   }
   // -- Program local edges
   if(settings->ffg.uesp || settings->ffg.lesp) { 
     if(settings->ffg.uesp && settings->ffg.lesp) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinMaxEdgeCountScopeAndSubCollector, edge_rec_server, CProgramRecorderHolder, PROGRAM); }
     else if(settings->ffg.uesp) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMaxEdgeCountScopeAndSubCollector, edge_rec_server, CProgramRecorderHolder, PROGRAM); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinEdgeCountScopeAndSubCollector, edge_rec_server, CProgramRecorderHolder, PROGRAM); }
   }
   // -- Function local call edgcs
   if(settings->ffg.ucsf || settings->ffg.lcsf) { 
     if(settings->ffg.ucsf && settings->ffg.lcsf) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinMaxCallEdgeCountScopeAndLoopSubCollector, edge_rec_server, CFunctionRecorderHolder, FUNCTION); }
     else if(settings->ffg.ucsf) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMaxCallEdgeCountScopeAndLoopSubCollector, edge_rec_server, CFunctionRecorderHolder, FUNCTION); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinCallEdgeCountScopeAndLoopSubCollector, edge_rec_server, CFunctionRecorderHolder, FUNCTION); }
   }
   // -- Program local call edgcs
   if(settings->ffg.ucsp || settings->ffg.lcsp) { 
     if(settings->ffg.ucsp && settings->ffg.lcsp) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinMaxCallEdgeCountScopeAndSubCollector, edge_rec_server, CProgramRecorderHolder, PROGRAM); }
     else if(settings->ffg.ucsp) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMaxCallEdgeCountScopeAndSubCollector, edge_rec_server, CProgramRecorderHolder, PROGRAM); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinCallEdgeCountScopeAndSubCollector, edge_rec_server, CProgramRecorderHolder, PROGRAM); }
   }
   // -- Scope local sum of loop body begin edges
   if(settings->ffg.ubns || settings->ffg.lbns) {     
     if(settings->ffg.ubns && settings->ffg.lbns) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinMaxLoopBodyBeginEdgeSumCountScopeCollector, edge_rec_server, CScopeRecorderHolder, SCOPE); }
     else if(settings->ffg.ubns) { RECORDER_AND_COLLECTOR_CREATION_CODE(CMaxLoopBodyBeginEdgeSumCountScopeCollector, edge_rec_server, CScopeRecorderHolder, SCOPE); }
     else { RECORDER_AND_COLLECTOR_CREATION_CODE(CMinLoopBodyBeginEdgeSumCountScopeCollector, edge_rec_server, CScopeRecorderHolder, SCOPE); }
   } 
}

void AlfAbstractExecution(const alf::CAlfTuple *ast, std::vector<CCollector *> &collectors,
                          std::vector<std::map<CScope *, CCollector *> *> &sc_maps,
                          CALFAbsAnnotStorage * abs_annots, CALFOutAnnotSpecStorage * out_ann_specs,
                          const CSourceLoader *source_loader, CScopeGraph *sg,
                          const AESettings *settings)
{
   // ---------------------------------
   // Create recorder servers and recorder holder servers
   // ---------------------------------

   // Create needed recorder and recorder holder servers
   CNodeCountRecorderServer * node_rec_server = NULL;
   CIterNodeCountRecorderServer * iter_node_rec_server = NULL;
   CEdgeCountRecorderServer * edge_rec_server = NULL;

   // Create different servers depending on if reuse should be used or not
   if(settings->domain_settings->reuse.recorder) {
     node_rec_server = new CNodeCountRecorderCOWServer();
     iter_node_rec_server = new CIterNodeCountRecorderCOWServer();
     edge_rec_server = new CEdgeCountRecorderCOWServer();
   }
   else {
     node_rec_server = new CNodeCountRecorderNoReuseServer();
     iter_node_rec_server = new CIterNodeCountRecorderNoReuseServer();
     edge_rec_server = new CEdgeCountRecorderNoReuseServer();
   }

   // Create recorder holder set and corresponding server
   CRecorderHolderSetServer * rhs_server = NULL;
   if(settings->domain_settings->reuse.recorder_holder) {
     rhs_server = new CRecorderHolderSetCOWServer();
   }
   else {
     rhs_server = new CRecorderHolderSetNoReuseServer();
   }
   CRecorderHolderSet * rhs = rhs_server->CreateRecorderHolderSet();

   // std::cerr << "AlfAbstractExecution::AlfAbstractExecution 1\n";

   // ---------------------------------
   // Set up normal flow fact generation
   // ---------------------------------
   SetUpFlowFactGeneration(settings, collectors, sc_maps, sg, node_rec_server, iter_node_rec_server, 
                           edge_rec_server, rhs_server, rhs);

   // ---------------------------------
   // Set up BCET/WCET estimate generation using ALF AST cost table
   // ---------------------------------
   CAlfCostLookupTable * aa_costs = NULL;
   CAACostCalcRecorderServer * aa_cost_calc_rec_server = NULL;
   CAACostCalcCollector * aa_cost_calc_collector = NULL;
   bool derive_aac_bcet_path = settings->aacpaths;
   bool derive_aac_wcet_path = settings->aacpaths;
   if(settings->aac) {

      // Read cost lookup table from file 
      aa_costs = new CAlfCostLookupTable(settings->aac_clt_name);

      // Create collector over whole program
      aa_cost_calc_collector = new CAACostCalcScopeAndSubCollector(sg->ECFG()->Root()->Scope(), false,
                                                                   derive_aac_bcet_path, derive_aac_wcet_path);
      collectors.push_back(aa_cost_calc_collector);

      // Create recorder server
      if(settings->domain_settings->reuse.recorder) {
         aa_cost_calc_rec_server = new CAACostCalcRecorderCOWServer(aa_costs, 
            settings->tc_arg.gn, settings->tc_arg.op, 
            settings->tc_arg.st, settings->tc_arg.sp,
            derive_aac_bcet_path, derive_aac_wcet_path);
      }
      else {
         aa_cost_calc_rec_server = new CAACostCalcRecorderNoReuseServer(aa_costs, 
            settings->tc_arg.gn, settings->tc_arg.op, 
            settings->tc_arg.st, settings->tc_arg.sp,
            derive_aac_bcet_path, derive_aac_wcet_path);
      }

      // Associate the collector to the recorder
      CRecorderHolder * rh = new CProgramRecorderHolder(aa_cost_calc_collector, aa_cost_calc_rec_server);
      rhs_server->AddRecorderHolderToRecorderHolderSet(&rhs, rh);
   }

   // ---------------------------------
   // Set up BCET/WCET estimate generation using BB cost table
   // ---------------------------------
   CBBCostLookupTable * bb_costs = NULL;
   CBBCostCalcRecorderServer * bb_cost_calc_rec_server = NULL;
   CBBCostCalcCollector * bb_cost_calc_collector = NULL;
   bool derive_bbc_bcet_path = settings->bbcp;
   bool derive_bbc_wcet_path = settings->bbcp;
   if(settings->bbc) {

     // Read cost lookup table from file 
     bb_costs = new CBBCostLookupTable(settings->bbc_clt_name);

     // Create collector over whole program
     bb_cost_calc_collector = new CBBCostCalcScopeAndSubCollector(sg->ECFG()->Root()->Scope(), false, 
								  derive_bbc_bcet_path, derive_bbc_wcet_path);
     collectors.push_back(bb_cost_calc_collector);

     // Create recorder server
     if(settings->domain_settings->reuse.recorder) {
       bb_cost_calc_rec_server = new CBBCostCalcRecorderCOWServer(bb_costs, derive_bbc_bcet_path, derive_bbc_wcet_path);
     }
     else {
       bb_cost_calc_rec_server = new CBBCostCalcRecorderNoReuseServer(bb_costs, derive_bbc_bcet_path, derive_bbc_wcet_path);
     }

     // Associate the collector to the recorder
     CRecorderHolder * rh = new CProgramRecorderHolder(bb_cost_calc_collector, bb_cost_calc_rec_server);
     rhs_server->AddRecorderHolderToRecorderHolderSet(&rhs, rh);
   }

   // ---------------------------------
   // Set up old version of BCET/WCET estimate generation using ALF AST cost table
   // ---------------------------------
   CGenericNodeTypeCountRecorderServer * type_rec_server = NULL;
   CGenericNodeTypeCountCollector * type_count_collector = NULL;
   alf::CAlfCostLookupTable * clt = NULL;
   if(settings->tc || settings->oaac) {

     // Read cost lookup table from file  
     if(settings->oaac) {
       clt = new alf::CAlfCostLookupTable(settings->oaac_clt_name);
     }

     // Create collector (maybe using a cost lookup table)
     type_count_collector = new CGenericNodeTypeCountCollector(settings->tc_arg.gn, settings->tc_arg.op, 
							       settings->tc_arg.st, settings->tc_arg.sp,
							       clt);
     collectors.push_back(type_count_collector);

     // Create recorder server
     if(settings->domain_settings->reuse.recorder) {
       type_rec_server = new CGenericNodeTypeCountRecorderCOWServer(settings->tc_arg.gn, settings->tc_arg.op, 
                                                                    settings->tc_arg.st, settings->tc_arg.sp);
     }
     else {
       type_rec_server = new CGenericNodeTypeCountRecorderNoReuseServer(settings->tc_arg.gn, settings->tc_arg.op, 
                                                                        settings->tc_arg.st, settings->tc_arg.sp);
     }

     // Associate the collector to the recorder
     CRecorderHolder * rh = new CProgramRecorderHolder(type_count_collector, type_rec_server);
     rhs_server->AddRecorderHolderToRecorderHolderSet(&rhs, rh);
   }

   // ---------------------------------
   // Set up icache and dcache flow fact generation
   // ---------------------------------
   bool run_icache_analysis = false;
   if(run_icache_analysis) {
     // Add something
   }

   // Holder for bb trace
   stringstream gtf_buf;

   // ---------------------------------
   // Run normal AE
   // ---------------------------------
   if(!settings->rtf) {
      // Add abstract annotations if any
      AlfVM vm;
      if (abs_annots != 0)
         vm.SetAbsAnnots(abs_annots);
      if (out_ann_specs != 0)
         vm.SetOutAnnotSpecs(out_ann_specs);
      vm.SetSourceLoader(source_loader);

      // Create first program point and PC and update initial state
      // with global decls and inits. Create a start state and
      // initialize it
      unique_ptr<ProgramPointECFG> entry_pp(new ProgramPointECFG(sg->ECFG()->Root()));
      unique_ptr<ProgramCounterECFG> pc(new ProgramCounterECFG_AE(ast, move(entry_pp), rhs, rhs_server));
      unique_ptr<PPEnviron> pp_environ(new PPEnviron(*ast));
      unique_ptr<State> init_state(new State(move(pc), move(pp_environ)));
      const CFuncTuple * main_func = static_cast<const CFuncTuple *>(sg->ECFG()->Root()->Scope()->Function());
      
      vm.InitializeState(ast, main_func, init_state.get(), settings->iv);

      // Set up merging strategy
      MergePointsHolder merge_points_holder(*sg->ECFG(), settings->merge.fe, settings->merge.fr,
                                            settings->merge.le, settings->merge.be, settings->merge.je);

      unique_ptr<AEStrategy<State> > ae_strategy;
      if (settings->css) ae_strategy.reset(new SinglePathAEStrategy<State>(move(init_state)));
      else
         ae_strategy.reset(new DepthFirstPostDomOrderedMergeAEStrategy<State>(
            merge_points_holder, *sg->ECFG(), move(init_state)));

      // Set up debugging facilities
      unique_ptr<ofstream> debug_out_file;
      unique_ptr<IndentingOStream> iout;
      unique_ptr<AlfVMDebugger> debugger;
      if (settings->debug != AESettings::NONE)
      {
         switch (settings->debug)
         {
         case AESettings::NONE:
            break;
         case AESettings::INTERACTIVE:
            debugger.reset(new AlfVMInterDebugger(*ae_strategy));
            break;
         case AESettings::TRACE:
            debug_out_file.reset(new ofstream("debug_msgs.txt"));
            iout.reset(new IndentingOStream(debug_out_file->rdbuf()));
            debugger.reset(new AlfVMTraceDebugger(iout.get()));
            debugger->ExprEvalEnabled(true);
            break;
         }
         vm.SetDebugger(debugger.get());
         ae_strategy->AttachDebugger(*debugger);
      }

      // Run the AE
      vector<State *> final_states;
      vm.ExecuteTillTermination(move(init_state), final_states, *ae_strategy, settings, gtf_buf);

      // Check that we got at least one final state
      if (final_states.empty())
        cout << "Note: no states reached the final program point." << endl;
      // Clean up temporaries
      for (unsigned i=0; i<final_states.size(); ++i) {
        delete final_states[i];
      }
   }

   // ---------------------------------
   // Runs AE based on traces
   // ---------------------------------
   if(settings->rtf) {
     assert(rhs_server);
     assert(rhs);
     RunAEUsingTraces(sg, rhs, rhs_server, settings->rtf_name);
   }     

   // ---------------------------------
   // Print results from ALF AST cost BCET/WCET calculation
   // ---------------------------------
   if(settings->aac && aa_cost_calc_collector) {
      aa_cost_calc_collector->PrintBCETAndWCET(std::cout);
      if(derive_aac_bcet_path) {
         aa_cost_calc_collector->PrintBCETPath(std::cout);
      }
      if(derive_aac_wcet_path) {
         aa_cost_calc_collector->PrintWCETPath(std::cout);
      }

      if (settings->aacprof) {
         // Print the BC and WC profiles to files
         const std::map<CScope*,int64_t> *profiles[2] = {
            &aa_cost_calc_collector->BCProfile(),
            &aa_cost_calc_collector->WCProfile()
         };
         const char *prof_files[2] = { "_ALFCostCalc_BC.txt", "_ALFCostCalc_WC.txt" };

         typedef vector<pair<CFuncTuple*,CCallStmtTuple*>> CallStringType; // [ (func, call stmt) ]
         typedef pair<CallStringType,int64_t> EntryType; // (call string, cost)
         vector<EntryType> entries;
         for (int p = 0; p < 2; ++p) {
            // create entries for the profile, one for each function scope (in the scope graph)
            entries.clear();
            entries.reserve(profiles[p]->size());
            for (auto i = profiles[p]->begin(), n = profiles[p]->end(); i!=n; ++i) {
               entries.resize(entries.size() + 1);
               CallStringType &callstring = entries.back().first;
               auto j = i->first;
               callstring.push_back( make_pair(dynamic_cast<CFuncTuple*>(j->Function()), (CCallStmtTuple*)nullptr) );
               assert(callstring.back().first);
               CECFGNode *calling_node = j->CallingNode();
               for (j = j->ParentScope(); j != nullptr; j = j->ParentScope()) {
                  if (!j->IsFunctionScope())
                     continue;
                  auto func = dynamic_cast<CFuncTuple*>(j->Function()); assert(func);
                  auto stmt = dynamic_cast<CCallStmtTuple*>(calling_node->GetFlowGraphNode()->Stmt()); assert(stmt);
                  callstring.push_back( make_pair(func,stmt) );
                  calling_node = j->CallingNode();
               }
               reverse(callstring.begin(), callstring.end()); // the call string was built in reverse
               entries.back().second = i->second;
            }

            // sort the entries
            sort(entries.begin(), entries.end(),
               [] (const EntryType &a, const EntryType &b) -> bool {
                  const CallStringType &a_ = a.first;
                  const CallStringType &b_ = b.first;
                  // compare coordinates of the called function
                  int cmp = compare(a_.back().first->GetCoord(), b_.back().first->GetCoord());
                  if (cmp != 0) return cmp < 0;
                  // compare lengths of the call strings
                  cmp = int(a_.size() - b_.size());
                  if (cmp != 0) return cmp < 0;
                  // searching backwards, find the first position where the call sites differ, and compare their coordinates
                  for (auto i = ++a_.rbegin(), j = ++b_.rbegin(), n = a_.rend(); i!=n; ++i, ++j) {
                     cmp = compare(i->second->GetCoord(), j->second->GetCoord());
                     if (cmp != 0) return cmp < 0;
                  }
                  assert(false);
                  return false;
               }
            );

            // print the profile to file
            TextTable table;
            table << "call string"; table.NextColumn();
            table << "cost";        table.NextRow();
            for (auto i = entries.begin(), n = entries.end(); i!=n; ++i) {
               // print the call string
               for (auto k = i->first.begin(), l = i->first.end();;) {
                  table << k->first->Name();
                  if (k->second)
                     table << " (" << k->second->TryGetSourceString() << ')';
                  ++k;
                  if (k != l) table << " -> ";
                  else break;
               }
               table.NextColumn();
               // print the cost
               table << i->second; table.NextRow();
            }
            ofstream out(prof_files[p]);
            out << table;
         }
      }
   }

   // ---------------------------------
   // Print results from old version of ALF AST cost BCET/WCET calculation
   // ---------------------------------
   if(settings->oaac && type_count_collector) {
     type_count_collector->PrintBCETAndWCET(&std::cout);
   }

   // ---------------------------------
   // Print results from BB cost BCET/WCET calculation
   // ---------------------------------
   if(settings->bbc && bb_cost_calc_collector) {
     bb_cost_calc_collector->PrintBCETAndWCET(std::cout);
     if(derive_bbc_bcet_path) {
       bb_cost_calc_collector->PrintBCETPath(std::cout);
     }
     if(derive_bbc_wcet_path) {
       bb_cost_calc_collector->PrintWCETPath(std::cout);
     }
   }

   // ---------------------------------
   // Print collected min and max counts
   // ---------------------------------
   if(settings->tc && !settings->aac && !settings->oaac) { 
     type_count_collector->PrintCollections(&std::cout, settings->simple_count_printout_in_tc);
   }

   // ---------------------------------
   // Print trace to file 
   // ---------------------------------
   if(settings->gtf) {
     ofstream trace_stream;
     trace_stream.open(settings->gtf_name.c_str(), ios::out);
     if (trace_stream.fail()) {
       throw runtime_error("Trace file " + settings->gtf_name + " could not be opened");
     }
     trace_stream << gtf_buf.str() << ";" << endl; 
     trace_stream.close();
   }

   // ---------------------------------
   // Delete temporaries
   // ---------------------------------
   rhs_server->DeleteRecorderHolderSet(rhs);
   if(node_rec_server) delete node_rec_server;
   if(iter_node_rec_server) delete iter_node_rec_server;
   if(edge_rec_server) delete edge_rec_server;
   if(type_rec_server) delete type_rec_server;
   if(rhs_server) delete rhs_server;
   if(clt) delete clt;
   if(aa_costs) delete aa_costs;
   if(aa_cost_calc_rec_server) delete aa_cost_calc_rec_server;
   if(bb_costs) delete bb_costs;
   if(bb_cost_calc_rec_server) delete bb_cost_calc_rec_server;
}

void InitDomain(const CDomainSettings *domain_settings)
{
   domain.reset(new ValueDomain);

   if (domain_settings->type == CDomainSettings::INTERVAL)
   {
      domain->SetIntegerDomain(new IntervalIntDomain);
      domain->SetMemoryDomain(new SymbMemoryDomain);
      domain->SetOpPolicies(new OpPolicies_Interv);
   }
   else // CDomainSettings::CLP
   {
      domain->SetIntegerDomain(new ClpDomain);
      domain->SetMemoryDomain(new SymbClpMemDomain);
      domain->SetOpPolicies(new OpPolicies_Clp);
   }
   if (domain_settings->top_float) {
      domain->SetFloatDomain(new TOPFloatDomain);
   }
   else {
      domain->SetFloatDomain(new IntervalFloatDomain);
   }

   SymbMemory::SetReuse(domain_settings->reuse.memory);
   FrameColl::SetReuse(domain_settings->reuse.memory);
   State::SetReuse_CallStack(domain_settings->reuse.call_stack);
   CallStack::SetReuse(domain_settings->reuse.call_stack);
}


// Help function for running AE based on traces read from file.  
#define DEBUG_PRINT_TRACE 0
void
RunAEUsingTraces(CScopeGraph *sg, CRecorderHolderSet * rhs, 
                 CRecorderHolderSetServer * rhs_server, std::string rtf_name)
{
  assert(sg);
  assert(rhs);
  assert(rhs_server);
  // Create interface class for traces
  CTraceHolder trace_holder(rtf_name);
  int i = 0;
  
  // ---------------------------------
  // Loop until no more traces (also set trace reader to first item of trace) 
  // ---------------------------------
  while(!trace_holder.HasNoMoreTraces()) {

    if(DEBUG_PRINT_TRACE) cout << "trace " << ++i << ": "; 

    // Derive the start node in the sg
    bool first_item = true;
    CECFGNode * ecfg_node = sg->Root()->EntryNode();

    // Copy the recorder holder set, to make sure that we can run the
    // analysis several times (is this really needed?)
    CRecorderHolderSet * copied_rhs = rhs_server->CopyRecorderHolderSet(rhs);
    assert(copied_rhs);
 
    // ---------------------------------
    // Loop until no more items in the current trace
    // ---------------------------------
    while(!trace_holder.IsEndOfTrace()) {

      // Extract the next item from the trace holder
      std::string item = trace_holder.GetNextItemFromTrace();
      if(DEBUG_PRINT_TRACE) cout << item << " \n";

      // Treat first trace item especially, i.e. it should correspond
      // to entry node in the root scope of the scope graph
      if(first_item) {
        if(ecfg_node->GetFlowGraphNode()->Name() != item) {
          cout << "Erroneous trace: expected node: " << ecfg_node->GetFlowGraphNode()->Name() 
               << " as first item in trace\n";
          exit(0);
        }
        rhs_server->UpdateRecorderHolderSetWithProgramStart(&copied_rhs, ecfg_node);
        first_item = false;
      }
      else {
        // Get the successor of the current node with the derived item name
        bool succ_node_found = false; 
        for(CECFGNode::succ_iterator succ_it = ecfg_node->SuccBegin(); 
            succ_it != ecfg_node->SuccEnd(); succ_it++) {
          CECFGNode * succ_node = succ_it->node;
          // Check if the current successor correspond to the trace item
          if(succ_node->GetFlowGraphNode()->Name() == item) {
            // Tell recorderds that we are doing a node tranfser
            rhs_server->UpdateRecorderHolderSetWithProgramCounterChange(&copied_rhs, ecfg_node, succ_node);
            // Reset the ecfg node to the successor node
            ecfg_node = succ_node;
            // Remember that we have found a node
            succ_node_found = true;
            break;
          }
        }
        // Check that we found a successor corresponding to item
        if(!succ_node_found) {
          cout << "Erroneous trace: node: " << ecfg_node->GetFlowGraphNode()->Name() 
               << " does not have successor: " << item << endl;
          exit(0);
        }
        
      } // end while item in trace exists
      
      if(DEBUG_PRINT_TRACE) cout << endl;
      
    } // end while traces exists
    
    // We have reached the end of the current trace. 
    rhs_server->UpdateRecorderHolderSetWithProgramExit(&copied_rhs, ecfg_node);

    // Delete the current recorder holder copy
    rhs_server->DeleteRecorderHolderSet(copied_rhs);
  }
}
