/* -*-c++-*- */
  
//----------------------------------------------------------------------
//  
//  THIS FILE:
//
// ----------------------------------------------------------------------
// 
//  $Id: $
// 
// ----------------------------------------------------------------------

#ifndef CAACostCalcCollector_H_
#define CAACostCalcCollector_H_

// Standard includes 
#include <string>
#include <iostream>
#include <map>
#include <set>
#include <cassert>

#include "CRecorder.h"
#include "CCollector.h"
#include "tcalc/CAlfCostLookupTable.h"
#include "../graphs/ecfg/CECFGNode.h"
#include "flow_facts/CFlowFact.h"
#include "graphs/scopes/CScope.h"
#include "program/CGenericFunction.h"
#include "program/CGenericStmt.h"
#include "flow_facts/CContextSensitiveValidAtEntryOfFlowFact.h"


// -------------------------------------------------------
// Class hierarchy:
// 
//   CAACostCalcCollector
//    |
//    |-- CAACostCalcScopeCollector
//    |-- CAACostCalcScopeAndSubCollector
//    |-- CAACostCalcScopeAndLoopSubCollector
//
// -------------------------------------------------------


//----------------------------------------------------------------------
//----------------------------------------------------------------------
//----------------------------------------------------------------------
// CAACostCalcCollector
// - Class which exports all functionality for calculating BCET and WCET 
//   estimates based on a AA node and AA edge cost lookup table.
// - A recorder will update the collector with information upon 
//   the edges taken for an executed scope.  
// - Class to inherit from (is virtual and can not be instansiated).
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//----------------------------------------------------------------------
class CAACostCalcCollector : public CCollector
{
public:

  //----------------------------------
  // Creation and deletion. 
  //----------------------------------

  // Default behaviour is to record only edges inbetween basic blocks. Alternatively,
  // the boolean can be used to control the behaviour.
  CAACostCalcCollector(CScope *, bool collect_only_edges_inbetween_basic_blocks,
		       bool collect_min_cost_path=false, bool collect_max_cost_path=false);
  virtual ~CAACostCalcCollector(void);

  //----------------------------------
  // To update the collector with a new recording. The recording should be 
  // valid for a certain execution (from entry to exit) of a scope. Since
  // we allow states and recording to be merged, the recorder will be a 
  // mapping from edge to ranges or from edges to ranges. Will default 
  // generate an assert, and suitable function call should therefore be 
  // redefined by subclasses.
  //---------------------------------
  void Update(int64_t min_cost, int64_t max_cost,
              std::map<CScope*,int64_t> * bc_profile, std::map<CScope*,int64_t> * wc_profile,
              std::vector<CECFGNode *> * min_cost_path, std::vector<CECFGNode *> * max_cost_path);
  // Will be calling the recorder's UpdateCollector() function
  void Report(CRecorder * rec);
  // Should not be called by this collector but need to be implemented
  void Report(int iter, CRecorder * rec) {assert(0);}

  //----------------------------------
  // Create flow facts from the collector and add to scope. Returns
  // the number of flow facts created. 
  //---------------------------------
  int GenerateFlowFacts(void) { return 0; }

  // ---------------------------------
  // Take a set of collectors, merge their internals and generate
  // context sensitive valid at entry of flow facts valid over CFG
  // nodes. Returns the number of flow facts created. Adds created ffs
  // to last argument. Collectors should be of CAACostCalcCollector type.
  // ---------------------------------
  int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                      std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,
                                                      std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
  { return 0; }
  
  // ---------------------------------
  // For printing the collector
  // ---------------------------------
  void Print(std::ostream * o = &std::cout);

  // The type of the collector, should be redefined in subclasses
  virtual std::string Type() = 0;

  // To get the edges to consider. Can also be called by a recorder to
  // get the edges to consider. Should not be deallocated by the caller.
  const std::set<std::pair<CECFGNode*, CECFGNode*> > * EdgesToConsider(void);

  // To get the saved scope
  CScope * Scope() {return _scope;}

  // To get the number of updates made
  int NrOfReports() { return _nr_of_updates; }

  // To get the min and max cost collected
  bool HasCosts() { return _nr_of_updates > 0; } 
  int64_t MinCost() { return _min_cost; }
  int64_t MaxCost() { return _max_cost; }  
  const std::map<CScope*,int64_t> &BCProfile() const { return _bc_profile; }
  const std::map<CScope*,int64_t> &WCProfile() const { return _wc_profile; }
  void PrintBCETAndWCET(std::ostream & o = std::cout);
  void PrintBCETPath(std::ostream & o = std::cout);
  void PrintWCETPath(std::ostream & o = std::cout);
  void PrintBCETAndWCETPaths(std::ostream & o = std::cout);

protected:

  // ---------------------------------
  // Help functions
  // ---------------------------------
  void PrintPath(std::ostream * o, std::vector<CECFGNode *> & path);

  // ---------------------------------
  // Functions that should be implemented by subclasses
  // ---------------------------------

  // The set the edges to consider. Is called the first time a
  // recorder is reported. Should be provided by subclasses. 
  virtual void SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider) = 0;

  // ---------------------------------
  // Internal data 
  // ---------------------------------

  // The scope that the collector is associated with. Will be used 
  // when creating flow facts and when deciding what edges to consider.
  CScope * _scope;

  // If only edges inbetween basic blocks should be collected
  bool _collect_only_edges_inbetween_basic_blocks;

  // To remember lower and upper WCET bounds generated for code region
  int64_t _min_cost;
  int64_t _max_cost;

  std::map<CScope*,int64_t> _bc_profile, _wc_profile;

  // The best and worst case paths
  bool _collect_min_cost_path;
  std::vector<CECFGNode *> _min_cost_path;
  bool _collect_max_cost_path;
  std::vector<CECFGNode *> _max_cost_path;

  // To remember the number of updates made
  int _nr_of_updates;

  // To hold the edges to consider. Differently updated by different
  // subclasses.
  std::set<std::pair<CECFGNode*, CECFGNode*> > _edges_to_consider;

};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CAACostCalcCollector &a);

//------------------------------------------------------------
//------------------------------------------------------------
// CAACostCalcScopeCollector
// - Collector which 
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CAACostCalcScopeCollector : public CAACostCalcCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CAACostCalcScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
			    bool collect_min_cost_path=false, bool collect_max_cost_path=false);
  virtual ~CAACostCalcScopeCollector() {}

  // To get the type of the collector
  std::string Type() { return "CAACostCalcScopeCollector"; }

protected:

  // The set the edges to consider. 
  void SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider);
};

//------------------------------------------------------------
//------------------------------------------------------------
// CAACostCalcScopeAndSubCollector
// - Collector which 
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CAACostCalcScopeAndSubCollector : public CAACostCalcCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CAACostCalcScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
				  bool collect_min_cost_path=false, bool collect_max_cost_path=false);
  virtual ~CAACostCalcScopeAndSubCollector() {}

  // To get the type of the collector
  std::string Type() { return "CAACostCalcScopeAndSubCollector"; }

protected:

  // The set the edges to consider. 
  void SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider);
};


//------------------------------------------------------------
//------------------------------------------------------------
// CAACostCalcScopeAndLoopSubCollector
// - Collector which 
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CAACostCalcScopeAndLoopSubCollector : public CAACostCalcCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CAACostCalcScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
				      bool collect_min_cost_path=false, bool collect_max_cost_path=false);
  virtual ~CAACostCalcScopeAndLoopSubCollector() {}

    // To get the type of the collector
  std::string Type() { return "CAACostCalcScopeAndLoopSubCollector"; }

protected:

  // The set the edges to consider. 
  void SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider);
};


#endif















