#ifndef MERGEPOINTSHOLDER_H_INCLUDED
#define MERGEPOINTSHOLDER_H_INCLUDED

#include <vector>

class CECFG;
class CECFGNode;

/** Holds information on which program points (ECFG nodes) are merge points, and
    gives constant-time access to that information */
class MergePointsHolder
{
public:
   /** Create a holder of information about which nodes of @a ecfg are merge
       points */
   MergePointsHolder(CECFG & ecfg, bool mp_fe, bool mp_fr, bool mp_le,
                     bool mp_be, bool mp_je);

   /** @return @p true if the node @a to_node is a merge point when doing a transition
               to it from the node @a from_node, @p false otherwise */
   bool IsMergePoint(const CECFGNode & from_node, const CECFGNode & to_node) const;

   /** @return @p true if the node @a to_node is a merge point in at least one
               situation, i.e.\, if there exist a node from_node such that 
               IsMergePoint(from_node, @a to_node) returns @p true.
               Otherwise, @p false. */
   bool IsMergePointSometimes(const CECFGNode & to_node) const;

private:
   /** Stores information about a "to-node", which is a node that has ingoing
       edges. Each object holds information about which predecessors to the node
       would make the node become a merge point in case a transition is made to it
       from the predecessor. */
   class ToNodeData
   {
   public:
      ToNodeData(CECFGNode & node, bool mp_fe, bool mp_fr, bool mp_le,
                 bool mp_be, bool mp_je);

      /** @return @p true if a transition from @a from_node to the node about which
                  this object holds data causes the latter node to become a merge
                  point, @p false otherwise */
      bool IsMergePoint(const CECFGNode & from_node) const;

      /** @return @p true if a transition from at least one node to the node about which
                  this object holds data causes the latter node to become a merge
                  point, @p false otherwise */
      bool IsMergePointSometimes() const;

   private:
      /** Holds an element for each predecessor to the to-node that would cause
          it to become a merge point if a transition were made to it from the 
          predecessor. If always_merge_point is @p true, no assumptions should be
          made about the contents of this vector, because it shouldn't be used at
          all */
      std::vector<CECFGNode *> ingoing_merge_edges;

      /** If the to-node is a merge point regardless of which edge is followed to
          get to it, this flag is used as an optimization to avoid iterating through
          all the predecessors */
      bool always_merge_point;
   };

   /** Holds information about all the nodes in the ECFG given to the constructor.
       To get information about an ECFG node, the vector is indexed with the number
       retrieved by calling Id on the node. */
   std::vector<ToNodeData> to_nodes;
};

#endif   // #ifndef MERGEPOINTSHOLDER_H_INCLUDED
