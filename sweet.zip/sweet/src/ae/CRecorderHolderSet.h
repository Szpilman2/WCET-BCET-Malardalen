/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id:  $
//
// ----------------------------------------------------------------------

#ifndef CRecorderHolderSet_H_
#define CRecorderHolderSet_H_

// Standard includes
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <stdlib.h>
#include <stdint.h>

// To get the members of the set
#include "CRecorderHolder.h"

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CRecorderHolderSet 
// A set of recorder holders. Associated to a certain AE_PC in a
// certain state. Whenever an update of PC is made all the included
// recorder holders update functions will be called. Similar holds
// when calling Copy(), Merge() etc. A recorder holder keeps track
// of one or more recorders.
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CRecorderHolderSet 
{
public:
  // Creation and deletion  
  CRecorderHolderSet(void);
  ~CRecorderHolderSet();

  friend class CRecorderHolderSetServer; 
  friend class CRecorderHolderSetCOWServer; 
  friend class CRecorderHolderSetNoReuseServer; 

  // To print all the recorders in the recorder set
  void Print(void) {Print(&std::cout);}
  void Print(std::ostream * o); 

  // To get and set the scope index recorder holder
  CScopeIndexRecorderHolder * GetScopeIndexRecorderHolder(void);
  const CScopeIndexRecorderHolder * GetScopeIndexRecorderHolder(void) const;
  void SetScopeIndexRecorderHolder(CScopeIndexRecorderHolder * sirh);

private:

  // Alternative creation function, used by copy and merge
  CRecorderHolderSet(std::vector<CRecorderHolder *> recorder_holders, 
                     CScopeIndexRecorderHolder * scope_index_recorder_holder);
  
  // Add a new recorder holder to the set. The set will own the
  // recorder holder, ie. when deleted all recorder holder will
  // be deleted too. The recorder server used by the recorder
  // holder is however not deleted (the same server will be used
  // by severeal recorders).
  void AddRecorderHolder(CRecorderHolder * rec_holder);

  // Update all recorders with a start of the program
  void UpdateWithProgramStart(CECFGNode * PC_after);

  // Update all of the recorders with the change of PC. 
  void UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after);
     
  // Update all recorders with an exit of program
  void UpdateWithProgramExit(CECFGNode * PC_before);

  // Deep copy of the whole recorder set, including deep copying of
  // all all the included recorders.
  CRecorderHolderSet * Copy();

  // We need to be able to do LUB of recorders when merging two states. 
  // However, Widening, Narrowing, etc. GLB should not be needed! 
  // LUB is only possible for states with equal scopeindexrecorders.
  CRecorderHolderSet * Merge(CRecorderHolderSet * other);

protected:
	
  // The actual set of recorder holders. Should be an ordered list,
  // since when merging two recorder sets we should merge the
  // recorders pairwise.
  std::vector<CRecorderHolder *> _recorder_holders;  
  
  // We always have a scope index recorder holder. 
  CScopeIndexRecorderHolder * _scope_index_recorder_holder;

};
  

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CRecorderHolderSetServer
// - Server for generating new and updating recorder holder set
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CRecorderHolderSetServer 
{
public:
  
  // No create function
  virtual ~CRecorderHolderSetServer() {};

  // For creating a new holder set. Will allocate the recorder holder
  // set and add <rhs*,1> to the map.
  CRecorderHolderSet * CreateRecorderHolderSet();

  // For deleting a recorder holder set.
  void DeleteRecorderHolderSet(CRecorderHolderSet * rhs);

  // To add a recorder holder to the set.
  virtual void AddRecorderHolderToRecorderHolderSet(CRecorderHolderSet ** rhs, CRecorderHolder *rh) = 0;

  // To update the recorder holder set with a pc change.
  virtual void UpdateRecorderHolderSetWithProgramStart(CRecorderHolderSet ** rhs, CECFGNode * PC_after) = 0;
  virtual void UpdateRecorderHolderSetWithProgramCounterChange(CRecorderHolderSet ** rhs, CECFGNode * PC_before, CECFGNode * PC_after) = 0;
  virtual void UpdateRecorderHolderSetWithProgramExit(CRecorderHolderSet ** rhs, CECFGNode * PC_before) = 0;

  // To copy the recorder holder set. 
  virtual CRecorderHolderSet * CopyRecorderHolderSet(CRecorderHolderSet * rhs) = 0;

  // To merge two recorder holder sets. 
  virtual CRecorderHolderSet * MergeRecorderHolderSets(CRecorderHolderSet * rhs1, CRecorderHolderSet * rhs2) = 0;

protected:
  // All recorder holder set are accessible from server by the <rhs*,
  // refs> map.  refs is a counter holding the number of references to
  // the recorder.
  std::map<CRecorderHolderSet *, int64_t> _rhs_to_refs;
};

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CRecorderHolderSetCOWServer
// - Server for generating new recorder holder sets according to
// copy on write. Most functionality is inherited from CRecorderHolderSet
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CRecorderHolderSetCOWServer : public CRecorderHolderSetServer
{
public:
  // To create and delete the recorder server
  CRecorderHolderSetCOWServer();
  virtual ~CRecorderHolderSetCOWServer();

  // To add a recorder holder to the rhs. If there are more than one
  // rhs sharing the same pointer, the actual copying will take place
  // and the rhs pointer will be updated.
  void AddRecorderHolderToRecorderHolderSet(CRecorderHolderSet ** rhs, CRecorderHolder *rh);

  // To update the rhs with a pc change. If there are
  // more than one rhs sharing the same pointer, the actual copying
  // will take place and the rhs pointer wil be updated.
  void UpdateRecorderHolderSetWithProgramStart(CRecorderHolderSet ** rhs, CECFGNode * PC_after);
  void UpdateRecorderHolderSetWithProgramCounterChange(CRecorderHolderSet ** rhs, CECFGNode * PC_before, CECFGNode * PC_after);
  void UpdateRecorderHolderSetWithProgramExit(CRecorderHolderSet ** rhs, CECFGNode * PC_before);

  // For copying the rhs using copy on write. Will not do any copying
  // right away, instead it will just update the map as: <rhs*, i> ->
  // <rhs*, i+1>
  CRecorderHolderSet * CopyRecorderHolderSet(CRecorderHolderSet * rhs);

  // To merge two rhs. Return a new rhs. If both rhs are the same we
  // will just return a pointer to the rhs and increase count as <rhs,
  // i> -> <rhs, i+1>. Otherwise we make the real merge make a new
  // <new_rhs, 1> and return the new rhs generated.
  CRecorderHolderSet * MergeRecorderHolderSets(CRecorderHolderSet * rhs1, CRecorderHolderSet * rhs2);
};

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CRecorderHolderSetNoReuseServer
// - Server for generating new recorder holder sets according to no reuse.
// - Most functionality is inherited from CRecorderHolderSet
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CRecorderHolderSetNoReuseServer : public CRecorderHolderSetServer
{
public:
  // To create and delete the recorder server
  CRecorderHolderSetNoReuseServer();
  virtual ~CRecorderHolderSetNoReuseServer();

  // For adding a recorder holder to the rhs the ordinary way. Will not update map. 
  void AddRecorderHolderToRecorderHolderSet(CRecorderHolderSet ** rhs, CRecorderHolder *rh);

  // For updating a rhs with a pc change the ordinary way. Will not update map. 
  void UpdateRecorderHolderSetWithProgramStart(CRecorderHolderSet ** rhs, CECFGNode * PC_after);
  void UpdateRecorderHolderSetWithProgramCounterChange(CRecorderHolderSet ** rhs, CECFGNode * PC_before, CECFGNode * PC_after);
  void UpdateRecorderHolderSetWithProgramExit(CRecorderHolderSet ** rhs, CECFGNode * PC_before);

  // For copying a rhs with a pc change the ordinary way. Creates a
  // new rhs and adds <new_rhs*, 1> to the map
  CRecorderHolderSet * CopyRecorderHolderSet(CRecorderHolderSet * rhs);

  // To merge two rhs the ordinary way. Returns a new rhs and adds
  // <new_rhs*, 1> to the map.
  CRecorderHolderSet * MergeRecorderHolderSets(CRecorderHolderSet * rhs1, CRecorderHolderSet * rhs2);
};

  

#endif
