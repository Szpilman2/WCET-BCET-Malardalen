#include "ae/DeriveContextSensitiveValidAtEntryOfFlowFacts.h"
#include "graphs/scopes/CScope.h"
#include "ae/CCollector.h"
#include "program/CGenericFunction.h"
#include "program/CGenericStmt.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/ecfg/CECFGNode.h"
#include "ae/CNodeCountCollector.h"
#include "ae/CIterNodeCountCollector.h"
#include "ae/CIterNodePairCollector.h"

#include <list>

// Useful macros to avoid writing to long type names (and make the
// code more readable)
#define t_call_string_as_vector std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > 
#define t_call_string_as_list std::list<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > 

// Help function for creating context senstive valid at entry of
// flow facts from a set of scope,collectors maps. The cs_length
// is how much context sensitivity we want, i.e. 0 - no context senstivity
// 1 - context sensivity of one func call , ... Large enough we get 
// full context sensitivy.
void
DeriveContextSensitiveValidAtEntryOfFlowFacts(const std::vector<std::map<CScope*,CCollector*> *> * sc_maps, 
                                              unsigned int cs_length, 
                                              std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  for(std::vector<std::map<CScope *, CCollector *> *>::const_iterator sc_map = sc_maps->begin();
      sc_map != sc_maps->end(); ++sc_map) {
    DeriveContextSensitiveValidAtEntryOfFlowFacts((*sc_map), cs_length, ffs);
  }
}

// Help function for creating context senstive valid at entry of
// flow facts from a scope,collectors map. The collectors should all
// be of the same type and have an associated scope. The cs_length
// is how much context sensitivity we want, i.e. 0 - no context senstivity
// 1 - context sensivity of one func call , ... Large enough we get 
// full context sensitivy.
void
DeriveContextSensitiveValidAtEntryOfFlowFacts(std::map<CScope*,CCollector*> * scope_to_collector_map, 
                                              unsigned int cs_length, 
                                              std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  // ------------------------------------------------------- 
  // 1. Split the collectors into sets. Each set belongs to a
  // call-string cs of max length cs_length. A collector belongs to
  // cs set if it has a call string that when truncated to max length 
  // cs_length becomes cs.
  // -------------------------------------------------------

  // Mapping from truncated call strings to set of scope,collectors pairs
  std::map<t_call_string_as_vector, std::set<std::pair<CScope *, CCollector *> > > trunced_call_string_to_sc_set_map;

  for(std::map<CScope *, CCollector *>::iterator s2c = scope_to_collector_map->begin();
      s2c != scope_to_collector_map->end(); ++s2c) {

    // Extract the scope and the collector
    CScope * scope = (*s2c).first;
    CCollector * collector = (*s2c).second;
  
    // Create a call string for the scope (valid for CFG nodes)
    t_call_string_as_list call_string;  
    CScope *current = scope;
    while (current->ParentScope()) {
      if (current->IsFunctionScope()) {
        CScope *parent = current->ParentScope();
        CGenericFunction * calling_function = parent->Function();
        CGenericStmt * calling_stmt = current->CallingNode()->GetFlowGraphNode()->Stmt();
        CGenericFunction * called_function = current->Function();
        assert(calling_function != called_function);
        call_string.push_front(std::make_pair(std::make_pair(calling_function, calling_stmt), called_function));
      }
      current = current->ParentScope();
    }
    
    // Extract the cs_length first elements in the call string (list)
    // to a new call string (vector)
    t_call_string_as_vector trunced_call_string;
    for(t_call_string_as_list::iterator c = call_string.begin(); 
        (c != call_string.end()) && (trunced_call_string.size() < cs_length); ++c) {
      trunced_call_string.push_back(*c);
    }

    // Insert the scope,collector pair in the map indexed on the truncated call string
    if(trunced_call_string_to_sc_set_map.find(trunced_call_string) == 
       trunced_call_string_to_sc_set_map.end()) {
      trunced_call_string_to_sc_set_map[trunced_call_string] = std::set<std::pair<CScope *, CCollector *> >();
    }
    trunced_call_string_to_sc_set_map[trunced_call_string].insert(std::make_pair(scope,collector));
  }

  // -------------------------------------------------------
  // 2. Loop through the trucated call_string to set<scope,collector>
  // map. For each set<scope,collector> we should create a number of
  // collector sets where each set is indexed on the CFG node that the
  // collector's scope has as header.
  // -------------------------------------------------------
  for(std::map<t_call_string_as_vector, std::set<std::pair<CScope *, CCollector *> > >::iterator cs2scs = trunced_call_string_to_sc_set_map.begin();
      cs2scs != trunced_call_string_to_sc_set_map.end(); ++cs2scs) {
    // Extract the truncated call string and the set<scope,collector>
    t_call_string_as_vector trunced_call_string = (*cs2scs).first;
    std::set<std::pair<CScope *, CCollector *> > sc_set = (*cs2scs).second;

    // Mapping between flow graph nodes and set of collectors.  
    std::map<std::pair<CGenericFunction *, CGenericStmt *>, std::set<CCollector *> > valid_at_entry_of_to_collectors_map;
    
    // Loop through the set of scope collector pairs and make set of
    // collectors indexed on their valid at entry of func and statements.
    for(std::set<std::pair<CScope *, CCollector *> >::iterator sc = sc_set.begin();
        sc != sc_set.end(); sc++) {
      CScope * scope = (*sc).first;
      CGenericFunction * valid_at_entry_of_func = scope->Function();
      // For valid at entry of that refer to functions we should
      // insert NULL. For loops we should insert a statement.
      CGenericStmt * valid_at_entry_of_stmt = NULL;
      if(scope->IsLoopScope())
        valid_at_entry_of_stmt = scope->Header()->GetFlowGraphNode()->Stmt();
      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of = std::make_pair(valid_at_entry_of_func, valid_at_entry_of_stmt);
      CCollector * collector = (*sc).second;      
      if(valid_at_entry_of_to_collectors_map.find(valid_at_entry_of) == valid_at_entry_of_to_collectors_map.end())
        valid_at_entry_of_to_collectors_map[valid_at_entry_of] = std::set<CCollector *>();
      valid_at_entry_of_to_collectors_map[valid_at_entry_of].insert(collector);
    }

    // Create the context sensitive valid at entry of flow facts. This
    // is made by merging information collected in all the collectors
    // that has the same trunced call string and the same
    // valid_at_entry_of tuple.
    for(std::map<std::pair<CGenericFunction *, CGenericStmt *>, std::set<CCollector *> >::iterator vaeo2cs = valid_at_entry_of_to_collectors_map.begin(); 
        vaeo2cs != valid_at_entry_of_to_collectors_map.end(); ++vaeo2cs) {
      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of = (*vaeo2cs).first;
      std::set<CCollector *> collectors = (*vaeo2cs).second;
      CCollector * collector = *(collectors.begin());
      assert(collector);
      collector->GenerateContextSensitiveValidAtEntryOfFlowFacts(&collectors, trunced_call_string,
                                                                 valid_at_entry_of, ffs);
    }
  }
  // Return, the argument set of ffs has been updated
}
    
