#ifndef ALF_ABSTRACT_EXECUTION_H_
#define ALF_ABSTRACT_EXECUTION_H_

#include <cstring>
#include <vector>
#include <map>
#include <string>
#include "cmd/CCommandAE.h"

class CALFAbsAnnotStorage;
class CALFOutAnnotSpecStorage;
class CSourceLoader;
class CScopeGraph;
class CScope;
class CDomainSettings;
class CCollector;
class CRecorderHolderSet;
class CRecorderHolderSetServer;


namespace alf {class CAlfTuple;}

class FlowFactTypes {
public:
   // Headers
   bool uhss; // UPPER, HEADERS, SINGLE, SCOPE
   bool lhss; // LOWER_UPPER, HEADERS, SINGLE, SCOPE
   bool uhsf; // UPPER, HEADERS, SINGLE, FUNCTION
   bool lhsf; // LOWER_UPPER, HEADERS, SINGLE, FUNCTION
   bool uhsp; // UPPER, HEADERS, SINGLE, PROGRAM
   bool lhsp; // LOWER_UPPER, HEADERS, SINGLE, PROGRAM
   bool uhpf; // UPPER, HEADERS, PAIRS, FUNCTION
   bool lhpf; // LOWER_UPPER, HEADERS, PAIRS, FUNCTION
   bool uhpp; // UPPER, HEADERS, PAIRS, PROGRAM
   bool lhpp; // LOWER_UPPER, HEADERS, PAIRS, PROGRAM

   // Nodes
   bool unss; // UPPER, NODES, SINGLE, SCOPE
   bool lnss; // LOWER_UPPER, NODES, SINGLE, SCOPE
   bool unsf; // UPPER, NODES, SINGLE, FUNCTION
   bool lnsf; // LOWER_UPPER, NODES, SINGLE, FUNCTION
   bool unsp; // UPPER, NODES, SINGLE, PROGRAM
   bool lnsp; // LOWER_UPPER, NODES, SINGLE, PROGRAM
   bool inse; // INFEASIBLE, NODES, SINGLE, EACH_ITERATION
   bool insa; // INFEASIBLE, NODES, SINGLE, ALL_ITERATIONS
   bool unps; // UPPER, NODES, PAIRS, SCOPE
   bool lnps; // LOWER_UPPER, NODES, PAIRS, SCOPE
   bool unpf; // UPPER, NODES, PAIRS, FUNCTION
   bool lnpf; // LOWER_UPPER, NODES, PAIRS, FUNCTION
   bool unpp; // UPPER, NODES, PAIRS, PROGRAM
   bool lnpp; // LOWER_UPPER, NODES, PAIRS, PROGRAM
   bool inpa; // INFEASIBLE, NODES, PAIRS, ALL_ITERATIONS
   bool inna; // INFEASIBLE, EDGES, PATHS, ALL_ITERATIONS

   // Edges
   bool uess; // UPPER, EDGES, SINGLE, SCOPE
   bool less; // LOWER_UPPER, EDGES, SINGLE, SCOPE
   bool uesf; // UPPER, EDGES, SINGLE, FUNCTION
   bool lesf; // LOWER_UPPER, EDGES, SINGLE, FUNCTION
   bool uesp; // UPPER, EDGES, SINGLE, PROGRAM
   bool lesp; // LOWER_UPPER, EDGES, SINGLE, PROGRAM
   bool ucsf; // UPPER, CALL_EDGES, SINGLE, FUNCTION
   bool lcsf; // LOWER_UPPER, CALL_EDGES, SINGLE, FUNCTION
   bool ucsp; // UPPER, CALL_EDGES, SINGLE, PROGRAM
   bool lcsp; // LOWER_UPPER, CALL_EDGES, SINGLE, PROGRAM
   bool ubss; // UPPER, LOOP_BODY_BEGIN_EDGES, SINGLE, SCOPE
   bool lbss; // LOWER_UPPER, LOOP_BODY_BEGIN_EDGES, SINGLE, SCOPE
   bool ubsf; // UPPER, LOOP_BODY_BEGIN_EDGES, SINGLE, FUNCTION
   bool lbsf; // LOWER_UPPER, LOOP_BODY_BEGIN_EDGES, SINGLE, FUNCTION
   bool ubsp; // UPPER, LOOP_BODY_BEGIN_EDGES, SINGLE, PROGRAM
   bool lbsp; // LOWER_UPPER, LOOP_BODY_BEGIN_EDGES, SINGLE, PROGRAM
   bool ubns; // UPPER, LOOP_BODY_BEGIN_EDGES, SUM, SCOPE
   bool lbns; // LOWER_UPPER, LOOP_BODY_BEGIN_EDGES, SUM, SCOPE
};

class AESettings
{
public:
   enum DebugType { NONE, INTERACTIVE, TRACE };

   bool df;    // Run depth-first instead of depth-first in AE when several states are possible to execute
   bool usm;   // Use unordered state merge
   bool op;    // Use optimized singe path xecution.  
   DebugType debug; // Type of debugging activated.
   bool tc;    // Statement type counting
   bool simple_count_printout_in_tc;  // 
   bool css;   // Check single state
   bool ene;   // Extended handling of equal and not equal condition
   bool iv;    // Ignore the "volatile" keyword
   bool tv;    // Set "volatile" to top. Only one of iv and tv can be set at the same time. 
               // tv will not be used since it is the opposite to iv.
   bool pu;    // Process undefined functions and globals
   bool bbt;   // Basic block trace
   bool gtf;   // Generate trace file (from AE)
   std::string gtf_name; // The file name to write trace to 
   bool rtf;   // Read trace file (and run AE accordingly)
   std::string rtf_name; // The file name to read traces from
   bool aac;   // If bcet and wcet should be generated using ALF AST cost lookup table read from file
   std::string aac_clt_name; // The file name holding the ALF AST cost lookup table to be used when genereating bcet and wcet estimates
   bool aacpaths;  // If bcet and wcet paths also should be generated 
   bool aacprof;   // If bcet and wcet profiles should be generated 
   bool bbc;   // If bcet and wcet should be generated using basic block cost lookup table read from file
   std::string bbc_clt_name; // The file name holding the basic block cost lookup table to be used when genereating bcet and wcet estimates
   bool bbcp;  // If bcet and wcet paths also should be generated 
   bool oaac;  // If bcet and wcet should be generated using oled version of ALF AST cost lookup table read from file
   std::string oaac_clt_name; // The file name holding the old version ALF AST cost lookup table to be used when genereating bcet and wcet estimates

   struct {
      bool fe; // FUNCTION ENTRY 
      bool fr; // FUNCTION RETURN 
      bool le; // LOOP EXIT
      bool be; // BACK-EDGE 
      bool je; // JOIN-NODE AFTER IF
   } merge;

   struct {
     bool gn; // GENERIC NODES
     bool op; // OPERANDS
     bool st; // STATEMENTS
     bool sp; // STATEMENT_PAIRS
   } tc_arg;

   bool DoMerging() const { return (merge.fe || merge.fr || merge.le || merge.be || merge.je); }

   AESettings();
   
   // Function for setting a certain ffg_mode to true
   void SetFFGMode(cmd::CCommandAE::FFG_KEY ffg_mode, bool value=true);
    
   // The struct of ffg modes
   FlowFactTypes ffg;

   // How the analysis should be run
   const CDomainSettings *domain_settings;

};

class CDomainSettings
{
public:
   typedef enum DOMAIN_TYPE {
      INTERVAL,
      CLP,
//      MIXED_INT,
//      CONGRUENCE,
//      ,
//      PRODUCT
   } DOMAIN_TYPE;

   DOMAIN_TYPE type;
   bool top_float;

   struct {
      bool memory;
      bool call_stack;
      bool recorder;
      bool recorder_holder;
   } reuse;
};

void AlfAbstractExecution(const alf::CAlfTuple *ast, 
                          std::vector<CCollector *> &collectors,
                          std::vector<std::map<CScope *, CCollector *> *> &sc_maps,
                          CALFAbsAnnotStorage * abs_annots, CALFOutAnnotSpecStorage * out_ann_specs,
                          const CSourceLoader *source_loader, CScopeGraph *scope_graph,
                          const AESettings * settings);
void InitDomain(const CDomainSettings *domain_settings);
void RunAEUsingTraces(CScopeGraph *sg, CRecorderHolderSet * rhs, 
                      CRecorderHolderSetServer * rhs_server, std::string rtf_name);

#endif
