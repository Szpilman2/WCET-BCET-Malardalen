#ifndef DERIVE_CONTEXT_SENSITIVE_VALID_AT_ENTRY_OF_FLOW_FACTS_H_
#define DERIVE_CONTEXT_SENSITIVE_VALID_AT_ENTRY_OF_FLOW_FACTS_H_

#include <vector>
#include <map>
class CCollector;
class CContextSensitiveValidAtEntryOfFlowFact;
class CScope;

// -------------------------------------------------------
// Function for creating context senstive valid at entry of flow facts
// from a set of scope,collectors maps. The cs_length is how much
// context sensitivity we want, i.e. 0 - no context senstivity 1 -
// context sensivity of one func call , ... If cs_length is larger
// than the height of the scope tree, we get full context
// sensitivy. Requires that the underlying scope graph is fully
// context sensitive (i.e. a tree form).
// -------------------------------------------------------
void DeriveContextSensitiveValidAtEntryOfFlowFacts(const std::vector<std::map<CScope*,CCollector*> *> * sc_maps, 
                                                   unsigned int cs_length, 
                                                   std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);
// Help function for just one scope,collector map
void DeriveContextSensitiveValidAtEntryOfFlowFacts(std::map<CScope*,CCollector*> * scope_to_collector_map, 
                                                   unsigned int call_string_length, 
                                                   std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);

#endif
