#include "program_state/State.h"
#include "OrderedAEMergeStrategy.inl"

template class OrderedAEMergeStrategy<State>;
template class PostDominanceOrderedAEMergeStrategy<State>;
template class DecoupledFetchAndMergeStrategies<
   State, 
   DepthFirstFetchStrategy<State>, 
   PostDominanceOrderedAEMergeStrategy<State> >;
template class DepthFirstPostDomOrderedMergeAEStrategy<State>;
