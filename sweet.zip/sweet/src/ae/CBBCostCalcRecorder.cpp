/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CBBCostCalcRecorder.cpp 1871 2010-03-04 10:11:45Z ael01 $
//
// ----------------------------------------------------------------------

#include "tcalc/CBBCostLookupTable.h"
#include "ae/CBBCostCalcRecorder.h"
#include "ae/CBBCostCalcCollector.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/ecfg/CECFGNode.h"

using namespace std;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CBBCostCalcRecorder
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of recorder
//----------------------------------
CBBCostCalcRecorder::
CBBCostCalcRecorder(const CBBCostLookupTable * bb_costs,
		    int64_t init_min_cost, int64_t init_max_cost,
		    bool record_min_cost_path, bool record_max_cost_path)
  : _bb_costs(bb_costs),
    _min_cost(init_min_cost), 
    _max_cost(init_max_cost),
    _record_min_cost_path(record_min_cost_path),
    _record_max_cost_path(record_max_cost_path)
{
  // Do nothing
}


//----------------------------------
// Deletion of recorder
//----------------------------------
CBBCostCalcRecorder::
~CBBCostCalcRecorder()
{
  // Do nothing
}

void
CBBCostCalcRecorder::
UpdateWithProgramCounterChange(CECFGNode * from_node, CECFGNode * to_node)
{  
  // To avoid unneccessary work
  if(_bb_costs->HasBBNodeCosts()) {
    // Add timing for node, if any
    AddCostForNode(from_node);
  }

  // To avoid unneccessary work
  if(_bb_costs->HasBBEdgeCosts()) {
    // Add timing for edge, if any
    AddCostForEdge(from_node, to_node);

    // If the second edge is the beginning of a basic block we should
    // reset the from node. If not, we should not add any cost
    if(to_node->IsBeginOfBasicBlock() && (from_node->GetBeginNodeOfNodesBasicBlock() != from_node)) {
      CECFGNode * bb_start_from_node = from_node->GetBeginNodeOfNodesBasicBlock();
      AddCostForEdge(bb_start_from_node, to_node);
    }
  }

  // Remember the path
  if(_record_min_cost_path)
    _min_cost_path.push_back(from_node);
  if(_record_max_cost_path)
    _max_cost_path.push_back(from_node);
}

void
CBBCostCalcRecorder::
UpdateWithProgramExit(CECFGNode * node)
{
  // Add timing cost for node since it has not been added before 
  if(_bb_costs->HasBBNodeCosts()) {
    AddCostForNode(node);
  }

  // Remember the path
  if(_record_min_cost_path)
    _min_cost_path.push_back(node);
  if(_record_max_cost_path)
    _max_cost_path.push_back(node);
}

void
CBBCostCalcRecorder::
AddCostForNode(CECFGNode * node)
{
  // Get the name of the node 
  std::string node_id = node->GetFlowGraphNode()->Name();
  
  // To avoid unneccessary work
  if(_bb_costs->HasBBNodeCost(node_id)) {

    // Get the cost for the basic block and add its lower and upper
    // value to the accumulated recorder cost
    const CIntegerRange * bb_cost = _bb_costs->LookupBBNodeCost(node_id);
    _min_cost += bb_cost->L();
    _max_cost += bb_cost->U();
  }
}

void
CBBCostCalcRecorder::
AddCostForEdge(CECFGNode * from_node, CECFGNode * to_node)
{
  // Get the name of the nodes 
  std::string from_node_id = from_node->GetFlowGraphNode()->Name();
  std::string to_node_id = to_node->GetFlowGraphNode()->Name();

  // To avoid unneccessary work
  if(_bb_costs->HasBBEdgeCost(from_node_id, to_node_id)) {

    // Get the cost for the edge and add its lower and upper
    // value to the accumulated recorder cost
    const CIntegerRange * edge_cost = _bb_costs->LookupBBEdgeCost(from_node_id, to_node_id);
    _min_cost += edge_cost->L();
    _max_cost += edge_cost->U();  
  }
}

//----------------------------------
// Report the current ranges to the collector.
//---------------------------------
void
CBBCostCalcRecorder::
ReportToCollector(CBBCostCalcCollector * collector)
{
  // Report the current mapping to collector
  collector->Update(_min_cost, _max_cost, &_min_cost_path, &_max_cost_path);
}

//----------------------------------
// Reset the recorder
//---------------------------------
void
CBBCostCalcRecorder::
Reset()
{
  // Reset costs 
  _min_cost = 0;
  _max_cost = 0;
  if(_record_min_cost_path)
    _min_cost_path.erase(_min_cost_path.begin(), _min_cost_path.end());
  if(_record_max_cost_path)
    _max_cost_path.erase(_max_cost_path.begin(), _max_cost_path.end());
}

//----------------------------------
// Copy the recorder
//---------------------------------
CBBCostCalcRecorder *
CBBCostCalcRecorder::
Copy()
{
  // Create a new recorder with the same min and max cost as current recorder
  CBBCostCalcRecorder * new_rec = new CBBCostCalcRecorder(_bb_costs, _min_cost, _max_cost, 
							  _record_min_cost_path, _record_max_cost_path);
  if(_record_min_cost_path)
    new_rec->_min_cost_path = _min_cost_path;
  if(_record_max_cost_path)
    new_rec->_max_cost_path = _max_cost_path;
  return new_rec;
}

//----------------------------------
// Merge two recorders
//---------------------------------
CBBCostCalcRecorder *
CBBCostCalcRecorder::
Merge(CBBCostCalcRecorder * other_rec)
{
  // Take the smallest of the two min costs
  int64_t new_min_cost = other_rec->GetMinCost();
  if(new_min_cost > _min_cost)
    new_min_cost = _min_cost;

  // Take the largest of the two max costs
  int64_t new_max_cost = other_rec->GetMaxCost();
  if(new_max_cost < _max_cost)
    new_max_cost = _max_cost;

  // Create the new recorder
  CBBCostCalcRecorder * new_rec = new CBBCostCalcRecorder(_bb_costs, new_min_cost, new_max_cost,
							  _record_min_cost_path, _record_max_cost_path);

  // Update the new recorder's min path
  if(_record_min_cost_path) {
    // If all costs are equal we take the one with shortest path
    if(new_min_cost == _min_cost && new_min_cost == other_rec->GetMinCost()) {
      if(_min_cost_path.size() <= other_rec->_min_cost_path.size())
	new_rec->_min_cost_path = _min_cost_path;
      else
	new_rec->_min_cost_path = other_rec->_min_cost_path;
    }
    // Else, check if the current was the one with smallest cost
    else if(new_min_cost == _min_cost) {
      new_rec->_min_cost_path = _min_cost_path;
    }
    // Else, it must be the other
    else {
      new_rec->_min_cost_path = other_rec->_min_cost_path;
    }
  }

  // Update the new recorder's max path
  if(_record_max_cost_path) {
    // If all costs are equal we take the one with shortest path
    if(new_max_cost == _max_cost && new_max_cost == other_rec->GetMaxCost()) {
      if(_max_cost_path.size() <= other_rec->_max_cost_path.size())
	new_rec->_max_cost_path = _max_cost_path;
      else
	new_rec->_max_cost_path = other_rec->_max_cost_path;
    }
    // Else, check if the current was the one with smallest cost
    else if(new_max_cost == _max_cost) {
      new_rec->_max_cost_path = _max_cost_path;
    }
    // Else, it must be the other
    else {
      new_rec->_max_cost_path = other_rec->_max_cost_path;
    }
  }

  // Return the created recorder
  return new_rec;
}

CRecorder * 
CBBCostCalcRecorder::
Merge(CRecorder * other_rec)
{
  return Merge(dynamic_cast<CBBCostCalcRecorder *>(other_rec));
}

//---------------------------------
// For printing the recorder
//---------------------------------
void
CBBCostCalcRecorder::
Print(ostream * o)
{
  (*o) << "min_cost: " << _min_cost << " max_cost: " << _max_cost << endl;

  if(_record_min_cost_path) {
    (*o) << "min_cost_path: ";
    for(std::vector<CECFGNode *>::iterator n = _min_cost_path.begin();
	n != _min_cost_path.end(); ++n) {
      (*o) << (*n)->GetFlowGraphNode()->Name() << " ";
    }
  }

  if(_record_max_cost_path) {
    (*o) << "max_cost_path: ";
    for(std::vector<CECFGNode *>::iterator n = _max_cost_path.begin();
	n != _max_cost_path.end(); ++n) {
      (*o) << (*n)->GetFlowGraphNode()->Name() << " ";
    }
  }
}

//---------------------------------
// Alternative printing function
//---------------------------------
ostream &operator << (ostream &o, CBBCostCalcRecorder &a)
{
  a.Print(&o);
  return o;
}


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CBBCostCalcRecorderServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//---------------------------------
// To create the recorder server
//---------------------------------
CBBCostCalcRecorderServer::
CBBCostCalcRecorderServer(CBBCostLookupTable * bb_costs,
			  bool record_min_cost_path, bool record_max_cost_path)
  : _bb_costs(bb_costs),
    _record_min_cost_path(record_min_cost_path),
    _record_max_cost_path(record_max_cost_path)
{
  // Do nothing
}

//---------------------------------
// To create the recorder
//---------------------------------
CBBCostCalcRecorder *
CBBCostCalcRecorderServer::
CreateRecorder()
{
  // Create the recorder
  CBBCostCalcRecorder * recorder = new CBBCostCalcRecorder(_bb_costs, 0, 0, 
							   _record_min_cost_path, _record_max_cost_path);

  // Remember that we have one reference to the recorder
  _recorder_to_refs[recorder] = 1;

  // Return the new recorder
  return recorder;
}

// -------------------------------------------------------
// To delete a certain recorder
// -------------------------------------------------------
void
CBBCostCalcRecorderServer::
DeleteRecorder(CBBCostCalcRecorder * recorder)
{
  // Update map
  _recorder_to_refs[recorder] = _recorder_to_refs[recorder]-1;

  // Check if we have any refs left
  if(_recorder_to_refs[recorder] == 0)
    {
      // No, remove the recorder for real
      delete recorder;

      // Remove the mapping
      // _recorder_to_refs.erase(recorder);
    }
}

void
CBBCostCalcRecorderServer::
DeleteRecorder(CRecorder * recorder)
{
  // Call the more specialized version
  DeleteRecorder(dynamic_cast<CBBCostCalcRecorder*>(recorder));
}

// -------------------------------------------------------
// Copy the recorder
// -------------------------------------------------------
CRecorder *
CBBCostCalcRecorderServer::
CopyRecorder(CRecorder * recorder)
{
  // Call the more specialized version
  return CopyRecorder(dynamic_cast<CBBCostCalcRecorder*>(recorder));
}


// -------------------------------------------------------
// Reset the current recorder
// -------------------------------------------------------
void
CBBCostCalcRecorderServer::
ResetRecorder(CRecorder ** recorder)
{
  *recorder = ResetRecorder(dynamic_cast<CBBCostCalcRecorder*>(*recorder));
}

// -------------------------------------------------------
// Merge two recorders
// -------------------------------------------------------
CRecorder *
CBBCostCalcRecorderServer::
MergeRecorders(CRecorder * rec1, CRecorder * rec2)
{
  return MergeRecorders(dynamic_cast<CBBCostCalcRecorder*>(rec1), dynamic_cast<CBBCostCalcRecorder*>(rec2));
}

// -------------------------------------------------------
// To print all the mappings in the server
// -------------------------------------------------------
void
CBBCostCalcRecorderServer::
Print(ostream * o)
{
  // Loop through all maps
  int i = 1;
  for(map<CBBCostCalcRecorder *, int64_t>::iterator tr = _recorder_to_refs.begin();
      tr != _recorder_to_refs.end(); ++tr)
    {
      (*o) << i << ": " << (*tr).first << "."
           << (*tr).second << endl;
      i++;
    }
}

// Alternative printing function
ostream &operator << (ostream &o, CBBCostCalcRecorderServer &a)
{
  a.Print(&o);
  return o;
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CBBCostCalcRecorderCOWServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

// -------------------------------------------------------
// To create the recorder server
// -------------------------------------------------------
CBBCostCalcRecorderCOWServer::
CBBCostCalcRecorderCOWServer(CBBCostLookupTable * bb_costs, 
			     bool record_min_cost_path, bool record_max_cost_path)
  : CBBCostCalcRecorderServer(bb_costs, record_min_cost_path, record_max_cost_path)
{
  // Do nothing
}

// -------------------------------------------------------
// To delete the recorder server
// -------------------------------------------------------
CBBCostCalcRecorderCOWServer::
~CBBCostCalcRecorderCOWServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To copy recorder
// -------------------------------------------------------
CBBCostCalcRecorder *
CBBCostCalcRecorderCOWServer::
CopyRecorder(CBBCostCalcRecorder * recorder)
{
  // Do no copying, just add one more reference to the recorder
  _recorder_to_refs[recorder] = _recorder_to_refs[recorder] + 1;

  // Return the same recorder
  return recorder;
}

// -------------------------------------------------------
// To updated the recorder with a certain edge
// -------------------------------------------------------
void
CBBCostCalcRecorderCOWServer::
UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after)
{
  CBBCostCalcRecorder * calc_recorder = dynamic_cast<CBBCostCalcRecorder *>(*recorder);

  assert(_recorder_to_refs[calc_recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[calc_recorder] == 1)
    {
      // Update current recorder
      calc_recorder->UpdateWithProgramCounterChange(pc_before, pc_after);
    }
  // More than one reference
  else
    {
      // Do the real copying
      CBBCostCalcRecorder * calc_recorder_copy = calc_recorder->Copy();

      // Update the copied recorder
      calc_recorder_copy->UpdateWithProgramCounterChange(pc_before, pc_after);

      // Update map
      _recorder_to_refs[calc_recorder] = _recorder_to_refs[calc_recorder] - 1;
      _recorder_to_refs[calc_recorder_copy] = 1;

      // Reset pointer 
      *recorder = calc_recorder_copy;
    }
}

// -------------------------------------------------------
// To updated the recorder with a program exit
// -------------------------------------------------------
void
CBBCostCalcRecorderCOWServer::
UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before)
{
  CBBCostCalcRecorder * calc_recorder = dynamic_cast<CBBCostCalcRecorder *>(*recorder);

  assert(_recorder_to_refs[calc_recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[calc_recorder] == 1)
    {
      // Update current recorder
      calc_recorder->UpdateWithProgramExit(pc_before);
    }
  // More than one reference
  else
    {
      // Do the real copying
      CBBCostCalcRecorder * calc_recorder_copy = calc_recorder->Copy();

      // Update the copied recorder
      calc_recorder_copy->UpdateWithProgramExit(pc_before);

      // Update map
      _recorder_to_refs[calc_recorder] = _recorder_to_refs[calc_recorder] - 1;
      _recorder_to_refs[calc_recorder_copy] = 1;

      // Reset pointer 
      *recorder = calc_recorder_copy;
    }
}

// -------------------------------------------------------
// To reset the recorder
// -------------------------------------------------------
CBBCostCalcRecorder *
CBBCostCalcRecorderCOWServer::
ResetRecorder(CBBCostCalcRecorder * recorder)
{
  assert(_recorder_to_refs[recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[recorder] == 1)
    {
      // Update current recorder
      recorder->Reset();

      // Return the updated recorder
      return recorder;
    }
  // More than one reference
  else
    {
      // Create a new recorder 
      CBBCostCalcRecorder * new_recorder = CreateRecorder();

      // Update map
      _recorder_to_refs[recorder] = _recorder_to_refs[recorder] - 1;
      _recorder_to_refs[new_recorder] = 1;

      // Return the new recorder
      return new_recorder;
    }
}

// -------------------------------------------------------
// To merge two recorders
// -------------------------------------------------------
CBBCostCalcRecorder *
CBBCostCalcRecorderCOWServer::
MergeRecorders(CBBCostCalcRecorder * recorder1, CBBCostCalcRecorder * recorder2)
{
  // Check if it is the same recorder (i.e. they points to the same address)
  if(recorder1 == recorder2)
    {
      // Update map
      _recorder_to_refs[recorder1] = _recorder_to_refs[recorder1] + 1;

      // Return the same recorder
      return recorder1;
    }
  else
    {
      // Different recorders, do the real merging
      CBBCostCalcRecorder * new_recorder = recorder1->Merge(recorder2);

      // Update map
      _recorder_to_refs[new_recorder] = 1;

      // Return the new recorder
      return new_recorder;
    }
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CBBCostCalcRecorderNoReuseServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

// -------------------------------------------------------
// To create the recorder server
// -------------------------------------------------------
CBBCostCalcRecorderNoReuseServer::
CBBCostCalcRecorderNoReuseServer(CBBCostLookupTable * bb_costs, 			     
				 bool record_min_cost_path, bool record_max_cost_path)
  : CBBCostCalcRecorderServer(bb_costs, record_min_cost_path, record_max_cost_path)
{
  // Do nothing
}

// -------------------------------------------------------
// To delete the recorder server
// -------------------------------------------------------
CBBCostCalcRecorderNoReuseServer::
~CBBCostCalcRecorderNoReuseServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To copy recorder
// -------------------------------------------------------
CBBCostCalcRecorder *
CBBCostCalcRecorderNoReuseServer::
CopyRecorder(CBBCostCalcRecorder * recorder)
{
  // Do the copying right away
  CBBCostCalcRecorder * new_recorder = recorder->Copy();

  // Update map
  _recorder_to_refs[new_recorder] = 1;

  // Return the new recorder
  return new_recorder;
}

// -------------------------------------------------------
// To update the recorder with a PC change
// -------------------------------------------------------
void
CBBCostCalcRecorderNoReuseServer::
UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after)
{
  // Update the recorder
  CBBCostCalcRecorder * calc_recorder = dynamic_cast<CBBCostCalcRecorder *>(*recorder);
  calc_recorder->UpdateWithProgramCounterChange(pc_before, pc_after);
}

// -------------------------------------------------------
// To update the recorder with a PC exitr
// -------------------------------------------------------
void
CBBCostCalcRecorderNoReuseServer::
UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before)
{
  // Update the recorder
  CBBCostCalcRecorder * calc_recorder = dynamic_cast<CBBCostCalcRecorder *>(*recorder);
  calc_recorder->UpdateWithProgramExit(pc_before);
}

// -------------------------------------------------------
// To reset the recorder
// -------------------------------------------------------
CBBCostCalcRecorder *
CBBCostCalcRecorderNoReuseServer::
ResetRecorder(CBBCostCalcRecorder * recorder)
{
  // Reset current recorder
  recorder->Reset();

  // Return the updated recorder
  return recorder;
}

// -------------------------------------------------------
// To merge two recorders
// -------------------------------------------------------
CBBCostCalcRecorder *
CBBCostCalcRecorderNoReuseServer::
MergeRecorders(CBBCostCalcRecorder * recorder1, CBBCostCalcRecorder * recorder2)
{
  // Do the merging getting a new recorder
  CBBCostCalcRecorder * new_recorder = recorder1->Merge(recorder2);

  // Update map
  _recorder_to_refs[new_recorder] = 1;

  // Return the new recorder
  return new_recorder;
}



