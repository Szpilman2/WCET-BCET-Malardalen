/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CGenericNodeTypeCountCollector.h 542 2009-06-05 14:35:34Z ael01 $
//
// ----------------------------------------------------------------------

#ifndef CGenericNodeTypeCountCollector_H_
#define CGenericNodeTypeCountCollector_H_

// Standard includes
#include <string>
#include <iostream>
#include <fstream>
#include <map>

// Forward declare the CScope structure (due to circular dependencies
// we do not want to include the CScope.h file)
class CScope;
class CIntegerRange;

// For getting nice macros
#include "macros.h"

// To get a suitable the range representation
#include "CIntegerRange.h"
// To get the scope node representation
#include "graphs/ecfg/CECFGNode.h"
// To get the type occurrences collected 
#include "program/alf/CGenericNode.h"
// To get the enum of op types
#include "program/alf/COpNumExprTuple.h"
// To get the enum of stmt types
#include "program/CGenericStmt.h"
// To get recorder type
#include "CRecorder.h"
// To get collector type
#include "CCollector.h"
// To get cost lookup table
#include "tcalc/CAlfCostLookupTable.h"
// To get the recorder
#include "ae/CGenericNodeTypeCountRecorder.h"

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CGenericNodeTypeCountCollector
// - Class which exports all functionality for updating & storing
//   information recorded on CGenericNode types. 
// - A recorder will update the collector with information upon
//   the CGenericNode types taken during an execution
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CGenericNodeTypeCountCollector : public CCollector 
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------

  // Default behaviour is to record only basic block start nodes. Alternatively,
  // the boolean can be used to control the behaviour. Last argument should be
  // instansiated if we should derive a BCET and WCET estimate based on the reported
  // entity counts and the cost for the different entities as specified in the cost 
  // lookup table.
  CGenericNodeTypeCountCollector(bool collect_generic_nodes=true, bool collect_op_types=true,
                                 bool collect_stmts=false, bool collect_stmt_pairs=false,
                                 const alf::CAlfCostLookupTable * cost_lookup_table=NULL);
  virtual ~CGenericNodeTypeCountCollector(void);

  //----------------------------------
  // To update the collector with a new recording. The recording should be
  // valid for a certain execution (from entry to exit) of a program. Since
  // we allow states and recording to be merged, the recorder will be a
  // mapping from CGenericvNode types to ranges. 
  //---------------------------------
  void Report(CRecorder * rec);
  // Should not be called by this colector but must be implemented
  void Report(int iter, CRecorder * rec) { assert(0);}
  int NrOfReports() { return _nr_of_type_updates; }

  //----------------------------------
  // We should not create any flow facts. Instead we should use the 
  // print function for getting the collected result.
  //---------------------------------
  int GenerateFlowFacts(void) { /* do nothing */ return 0; } ;
  int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors,
                                                      std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,
                                                      std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs) { 
    std::cout << " CGenericNodeTypeCountCollector::GenerateContextSensitiveValidAtEntryOfFlowFacts not supported!\n"; return 0; } 

  // ---------------------------------
  // For printing the collector
  // ---------------------------------
  void Print(std::ostream *o=&std::cout);
  void Print(std::ostream *o=&std::cout, bool simple_count_print = false);
  // Help functions for printing
  void PrintCollections(std::ostream * o, bool simple_count_print);
  void PrintBCETAndWCET(std::ostream * o);

  // We can use the counts for code entities and a previously
  // generated cost lookup table (which maps ALF code entities to
  // timing costs) to derive a BECT...WCET interval for the program.
  CIntegerRange * DeriveTimingBounds(alf::CAlfCostLookupTable * clt);

  // The type of the collector, should be redefined in subclasses
  virtual std::string Type() {return "CGenericNodeTypeCountCollector";}

  // To check if we have recorderd anything
  bool IsEmpty(void);

  // ---------------------------------
  // To decide what to collect
  // ---------------------------------
  bool CollectGenericNodes() { return _collect_generic_nodes; }
  bool CollectOpTypes() { return _collect_op_types; }
  bool CollectStmts() { return _collect_stmts; }
  bool CollectStmtPairs() { return _collect_stmt_pairs; }
  
  // ---------------------------------
  // To get BCET and WCET estimates based on cost lookup table
  // ---------------------------------
  bool HasBCETAndWCETEstimate() { return _has_bcet_and_wcet; }
  double BCETEstimate() { assert(_has_bcet_and_wcet); return _bcet; }
  double WCETEstimate() { assert(_has_bcet_and_wcet); return _wcet; }

  // To update the collector with a new map recorded by a
  // recorder. Will make a merge of the new and old range reported for
  // a type. If no range was previously reported for the type, the 
  // collector range will be equal to the recorded range.
  void Update(std::map<alf::CGenericNode::TYPE, CIntegerRange*> * recorded_type_to_range_map);
  void Update(std::map<alf::COpNumExprTuple::OP_TYPE, CIntegerRange*> * recorded_op_type_to_range_map);
  void Update(std::map<CGenericStmt::GS_TYPE, CIntegerRange*> * recorded_stmt_to_range_map);
  void Update(std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*> * recorded_stmt_pair_to_range_map);

protected:

  friend class CGenericNodeTypeCountRecorder;

  // To update BCET and WCET with a recording. 
  void UpdateBCETAndWCETWithRecorder(CGenericNodeTypeCountRecorder * rec);
  void UpdateBCETAndWCET(std::map<alf::CGenericNode::TYPE, CIntegerRange*> * type_to_range_map,
                         double & bcet, double & wcet);
  void UpdateBCETAndWCET(std::map<alf::COpNumExprTuple::OP_TYPE, CIntegerRange*> * op_type_to_range_map,
                         double & bcet, double & wcet);
  void UpdateBCETAndWCET(std::map<CGenericStmt::GS_TYPE, CIntegerRange*> * stmt_to_range_map,
                         double & bcet, double & wcet);
  void UpdateBCETAndWCET(std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*> * stmt_pair_to_range_map,
                         double & bcet, double & wcet);

  // A mapping between generic nodes and ranges. 
  std::map<alf::CGenericNode::TYPE, CIntegerRange*> _type_to_range_map;

  // A mapping between op types and ranges. 
  std::map<alf::COpNumExprTuple::OP_TYPE, CIntegerRange*> _op_type_to_range_map;

  // A mapping between generic statement types and ranges. 
  std::map<CGenericStmt::GS_TYPE, CIntegerRange*> _stmt_to_range_map;

  // A mapping between generic statement types and ranges. 
  std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, CIntegerRange*> _stmt_pair_to_range_map;

  // To remember the number of updates made
  int _nr_of_type_updates;
  int _nr_of_op_type_updates;
  int _nr_of_stmt_updates;
  int _nr_of_stmt_pair_updates;

  // Holds the things to collect
  bool _collect_generic_nodes;
  bool _collect_op_types;
  bool _collect_stmts;
  bool _collect_stmt_pairs;

  // Holds thinsg needed to derive bcet and wcet estimate
  double _bcet;
  double _wcet;
  bool _has_bcet_and_wcet;
  const alf::CAlfCostLookupTable * _cost_lookup_table;
};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CGenericNodeTypeCountCollector &a);

#endif













