#include "program_state/State.h"
#include "AEStrategy.inl"

template class MergeableStateColl<State>;
template class AEStrategyDebugger<State>;
template class SilentAEStrategyDebugger<State>;
template class AEStrategy<State>;
template class SinglePathAEStrategy<State>;
template class FetchStrategy<State>;
template class AEMergeStrategy<State>;
template class DepthFirstFetchStrategy<State>;
template class EmptyMergeStrategy<State>;
template class DecoupledFetchAndMergeStrategies<
   State, 
   DepthFirstFetchStrategy<State>, 
   EmptyMergeStrategy<State> >;
template class DepthFirstNoMergeAEStrategy<State>;
template class NonEmptyMergeStrategy<State>;
template class UnorderedAEMergeStrategy<State>;
template class DecoupledFetchAndMergeStrategies<
   State, 
   DepthFirstFetchStrategy<State>, 
   UnorderedAEMergeStrategy<State> >;
template class DepthFirstUnorderedMergeAEStrategy<State>;
