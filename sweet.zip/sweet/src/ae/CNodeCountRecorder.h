/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CNodeCountRecorder.h 2670 2011-01-07 00:06:19Z ael01 $
//
// ----------------------------------------------------------------------

#ifndef CNodeCountRecorder_H_
#define CNodeCountRecorder_H_

#include <string>
#include <iostream>
#include <fstream>
#include <map>
#include <cstdlib>
#include <stdint.h>
#include "ae/CRecorder.h"

//----------------------------------------------------------------------
// Forward-declare types
//----------------------------------------------------------------------
class CScope;
class CECFGNode;
class CNodeCountCollector;
class CIntegerRange;
class CNodePairCountCollector;
class CMaxHeaderNodeCountScopeCollector;
class CMaxHeaderNodeCountScopeAndLoopSubCollector;

class CNodeCountRecorder;
typedef CNodeCountRecorder * CNodeCountRecorderPtr;
class CNodeCountRecorderServer;
typedef CNodeCountRecorderServer * CNodeCountRecorderServerPtr;
class CNodeCountRecorderCOWServer;
typedef CNodeCountRecorderCOWServer * CNodeCountRecorderCOWServerPtr;
class CNodeCountRecorderNoReuseServer;
typedef CNodeCountRecorderNoReuseServer * CNodeCountRecorderNoReuseServerPtr;

// A mapping between scope nodes and integer ranges
typedef std::map<CECFGNode *,CIntegerRange*> t_node_to_range_map;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodeCountRecorder
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CNodeCountRecorder : public CRecorder
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------

  // Default behaviour is to only record basic block headers. I.e. if
  // not boolean is given only the start nodes will be recorded.
  // Alternatively, the behaviour can be controlled by the boolean.
  CNodeCountRecorder(bool record_only_basic_block_start_nodes=true);
  virtual ~CNodeCountRecorder(void);

  //----------------------------------
  // To update the recorder with a new execution of a node
  //---------------------------------
  void IncreaseCount(CECFGNode * node);
  // Will call the more specialized IncreaseCount() function
  void UpdateWithProgramCounterChange(CECFGNode * pc_before, CECFGNode * pc_after);
  void UpdateWithProgramExit(CECFGNode * pc_before);

  //----------------------------------
  // Report the current counts to the node count collector.
  //---------------------------------
  void ReportToCollector(CNodeCountCollector* collector);
  void ReportToCollector(CNodePairCountCollector* collector);

  //----------------------------------
  // Reset recorder. Will remove all node to range mappings.
  //---------------------------------
  void Reset(void);

  //----------------------------------
  // To copy the recorder
  //---------------------------------
  CNodeCountRecorderPtr Copy();

  //----------------------------------
  // To merge two recorders (LUB)
  //---------------------------------
  CNodeCountRecorderPtr Merge(CNodeCountRecorderPtr other_recorder);
  // Will call the more specialized Merge() function...
  CRecorder * Merge(CRecorder * other_recorder);

  // ---------------------------------
  // For printing the recorder
  // ---------------------------------
  void Print(std::ostream * o = &std::cout);

protected:


  // To set the count or range of a certain node
  void SetCount(CECFGNode * node, int count);
  void SetRange(CECFGNode * node, CIntegerRange* range);

  // A mapping between node ids and ranges. The range can never get more
  // than one value due to a normal IncreaseCount call. Ranges of values
  // only appear due to merge of recorders in state merges.
  t_node_to_range_map _node_to_range_map;

  // To keep track of if only bb start nodes should be recorded. If
  // not set all nodes will be recorded
  bool _record_only_basic_block_start_nodes;
};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CNodeCountRecorder &a);


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodeCountRecorderServer
// - Server for generating new node count recorders
// - To inherit from
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CNodeCountRecorderServer : public CRecorderServer
{
public:

  // To create a node count recorder server. Default behaviour is to
  // only record basic block headers. I.e. if not boolean is given
  // only the start nodes will be recorded. Alternatively, the behaviour
  // can be controlled by the boolean argument.
  CNodeCountRecorderServer(bool record_only_basic_block_start_nodes=true);
  virtual ~CNodeCountRecorderServer() {};

  // For creating a new recorder. Will allocate the recorder and add
  // <recorderptr,1> to the map.
  CNodeCountRecorderPtr CreateRecorder();

  // For deleting a recorder. When deleting a recorder then <recorderptr, i> ->
  // <recorderptr, i-1> If i-1 == 0 then remove recorder for real.
  void DeleteRecorder(CNodeCountRecorderPtr recorder);
  // Will call the more specialized delete function...
  void DeleteRecorder(CRecorder * recorder);

  // To copy the recorder.
  virtual CNodeCountRecorderPtr CopyRecorder(CNodeCountRecorderPtr recorder) = 0;
  // Will call the more specialized copy function...
  CRecorder * CopyRecorder(CRecorder * recorder);

  // To increase the count of the recorder. Might return a new recorder. Ie.
  // the caller should reset its _recorder to the recorder returned.
  virtual CNodeCountRecorderPtr IncreaseCountInRecorder(CNodeCountRecorderPtr recorder,
                                                        CECFGNode * node) = 0;
  // Will call the more specialized increase count function...
  virtual void UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after);
  virtual void UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before);

  // To reset the recorder. Might return a new recorder. Ie.  the
  // caller should reset its _recorder to the recorder returned.
  virtual CNodeCountRecorderPtr ResetRecorder(CNodeCountRecorderPtr recorder) = 0;
  // Will call the more specialized reset function...
  virtual void ResetRecorder(CRecorder ** recorder);

  // To merge two recorders. Return a new recorder.
  virtual CNodeCountRecorderPtr MergeRecorders(CNodeCountRecorderPtr recorder1,
                                               CNodeCountRecorderPtr recorder2) = 0;
  // Will call the more specialized merge function...
  CRecorder * MergeRecorders(CRecorder * rec1, CRecorder * rec2);


  // For printing the server
  void Print() {Print(&std::cout);};
  void Print(std::ostream * o);

protected:
  // All recorders are accessible from server by the <recorderptr, refs> map.
  // refs is a counter holding the number of references to the recorder.
  std::map<CNodeCountRecorderPtr, int64_t> _recorder_to_refs;

  // To keep track of if only bb headers should be recorded. If not set
  // all nodes will be recorded
  bool _record_only_basic_block_start_nodes;
};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CNodeCountRecorderServer &a);

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodeCountRecorderCOWServer
// - Recorder server for generating new recorders according to
// copy on write. Most functionality is inherited from CNodeCountRecorderServer.
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CNodeCountRecorderCOWServer : public CNodeCountRecorderServer
{
public:

  // To create a COW node count recorder server. Default behaviour is to
  // only record basic block headers. I.e. if not boolean is given
  // only the start nodes will be recorded. Alternatively, the behaviour
  // can be controlled by the boolean argument.
  CNodeCountRecorderCOWServer(bool record_only_basic_block_start_nodes=true);
  virtual ~CNodeCountRecorderCOWServer();

  // For copying the recorder using copy on write. Will not do any copying
  // right away, instead it will just update the map as: <recorderptr, i>
  // -> <recorderptr, i+1>
  CNodeCountRecorderPtr CopyRecorder(CNodeCountRecorderPtr recorder);

  // To increase a count for a node in the recorder. Might return a
  // new recorder. Ie.  the caller should reset its _recorder to the recorder
  // returned.  If <recorderptr, i> where i > 1 then copy recorder (for real),
  // do the update and return new copied and updated recorder
  // (recorderptr'). We add <recorderptr',1> to map, and update <recorderptr, i>
  // -> <recorderptr, i-1>.  else i == 1, then do the update on recorderptr
  // and return same recorderptr.
  CNodeCountRecorderPtr IncreaseCountInRecorder(CNodeCountRecorderPtr recorder,
                                                CECFGNode * node);

  // To reset the recorder. Might return a new recorder. Ie.  the
  // caller should reset its _recorder to the recorder returned. If
  // <recorderptr, i> where i > 1 then copy recorder (for real), do
  // the update and return new copied and updated recorder
  // (recorderptr'). We add <recorderptr',1> to map, and update
  // <recorderptr, i> -> <recorderptr, i-1>.  else i == 1, then do the
  // update on recorderptr and return same recorderptr.
  CNodeCountRecorderPtr ResetRecorder(CNodeCountRecorderPtr recorder);

  // To merge two recorders. Return a new recorder. If both recorders
  // are the same we will just return a pointer to the recorder and
  // increase count as <recorderptr, i> -> <recorderptr, i+1>. Otherwise
  // we make the real merge make a new <newrecorderptr, 1> and return
  // the new recorder generated.
  CNodeCountRecorderPtr MergeRecorders(CNodeCountRecorderPtr recorder1,
                                       CNodeCountRecorderPtr recorder2);

};

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodeCountRecorderNoReuseServer
// - Server implementing no reuse.
// - Most functionality is inherited from CNodeCountRecorderServer.
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CNodeCountRecorderNoReuseServer : public CNodeCountRecorderServer
{
public:

  // To create a no reuse node count recorder server. Default behaviour is to
  // only record basic block headers. I.e. if not boolean is given
  // only the start nodes will be recorded. Alternatively, the behaviour
  // can be controlled by the boolean argument.
  CNodeCountRecorderNoReuseServer(bool record_only_basic_block_start_nodes=true);
  virtual ~CNodeCountRecorderNoReuseServer();

  // For copying the recorder the ordinary way (ie. diretly when Copy() is called).
  // Creates a new recorder and adds <recorderptr, 1> to the map.
  CNodeCountRecorderPtr CopyRecorder(CNodeCountRecorderPtr recorder);

  // For updating the recorder the ordinary way. Will not update map.
  CNodeCountRecorderPtr IncreaseCountInRecorder(CNodeCountRecorderPtr recorder,
                                                CECFGNode * node);

  // For reseting the recorder the ordinary way.  Will not update map.
  CNodeCountRecorderPtr ResetRecorder(CNodeCountRecorderPtr recorder);

  // To merge two recorders the ordinary way. Return a new recorder
  // and adds <recorderptr, 1> to the map.
  CNodeCountRecorderPtr MergeRecorders(CNodeCountRecorderPtr recorder1,
                                       CNodeCountRecorderPtr recorder2);

};

#endif
