#ifndef MERGEABLESTATETRAITS_H_INCLUDED
#define MERGEABLESTATETRAITS_H_INCLUDED

/** Template class that should be specialized for each type of MergeableState */
template <typename MergeableState>
class MergeableStateTraits
{
   /*
   // The following members should be defined in a specialization of this class. If they
   // aren't, some static checks in the constructor of AEStrategy prevents the
   // code from even being compiled.

public:
   // Should return the currently visited ECFG in the state @a state.
   static CECFGNode * GetECFGNode(const MergeableState & state);

   // Should return whether @a state1 and @a state2 can be merged
   static bool AreMergeable(const MergeableState & state1, const MergeableState & state2);

   // Should perform a lexicographical comparison of the two states' index vectors and return
   // the result.
   static bool CompareStatesIndexVecs(const MergeableState & a, const MergeableState & b);

   // Should return the state resulting from merging the states @a state1 and @a state2.
   static std::unique_ptr<MergeableState> MergeStates(const MergeableState & state1,
                                                    const MergeableState & state2);
   */
};

#endif   // #ifndef MERGEABLESTATETRAITS_H_INCLUDED
