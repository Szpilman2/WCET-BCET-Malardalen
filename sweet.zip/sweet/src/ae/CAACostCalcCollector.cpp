/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CAACostCalcCollector.cpp 1676 2010-01-22 14:50:10Z ael01 $
//
// ----------------------------------------------------------------------

#include "CAACostCalcCollector.h"
#include "CAACostCalcRecorder.h"
#include "flow_facts/CFlowFact.h"
#include "flow_facts/CFFCollector.h"
#include "graphs/scopes/CScope.h"
#include "graphs/ecfg/CECFGNode.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "flow_facts/CContextSensitiveValidAtEntryOfFlowFact.h"

using namespace std;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CAACostCalcCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of collector
//----------------------------------
CAACostCalcCollector::
CAACostCalcCollector(CScope * scope, bool collect_only_edges_inbetween_basic_blocks,
		     bool collect_min_cost_path, bool collect_max_cost_path)
  : _scope(scope), _collect_only_edges_inbetween_basic_blocks(collect_only_edges_inbetween_basic_blocks),
    _collect_min_cost_path(collect_min_cost_path), _collect_max_cost_path(collect_max_cost_path),
    _nr_of_updates(0)
{
  // Do nothing
}

//----------------------------------
// Deletion of each a collector
//----------------------------------
CAACostCalcCollector::
~CAACostCalcCollector()
{
  // Do nothing
}


//----------------------------------
// To update the collector with a new recording.
//---------------------------------
void
CAACostCalcCollector::
Update(int64_t min_cost, int64_t max_cost,
       std::map<CScope*,int64_t> * bc_profile, std::map<CScope*,int64_t> * wc_profile,
       std::vector<CECFGNode *> * min_cost_path, std::vector<CECFGNode *> * max_cost_path)
{
  // Increase the nr of updates
  _nr_of_updates++;

  // Treat first update especially
  if(_nr_of_updates == 1) {
    _min_cost = min_cost;
    _max_cost = max_cost;
    _bc_profile = *bc_profile;
    _wc_profile = *wc_profile;
  }
  else {
    if(min_cost < _min_cost) {
       _min_cost = min_cost;
       _bc_profile = *bc_profile;
    }
    if(max_cost > _max_cost) {
       _max_cost = max_cost;
       _wc_profile = *wc_profile;
    }
  }

  // Collect min and max cost paths 
  if(_collect_min_cost_path && _min_cost == min_cost) {
    _min_cost_path = (*min_cost_path);
  }
  if(_collect_max_cost_path && _max_cost == max_cost) {
    _max_cost_path = (*max_cost_path);
  }
}

// The report function needs to be implemented
void
CAACostCalcCollector::
Report(CRecorder * rec)
{
  CAACostCalcRecorder * nc_rec = dynamic_cast<CAACostCalcRecorder *>(rec);
  nc_rec->ReportToCollector(this);
}

//---------------------------------
// For printing the collector
//---------------------------------
void
CAACostCalcCollector::
Print(std::ostream * o)
{
  (*o) << "type: " << Type() << endl;
  (*o) << "scope: " << _scope->Name() << endl;
    if(_nr_of_updates > 0) {
    (*o) << "min_cost: " << _min_cost << " max_cost: " << _max_cost << endl;

    if(_collect_min_cost_path) {
      (*o) << "min_cost_path: ";
      PrintPath(o, _min_cost_path);
    }

    if(_collect_max_cost_path) {
      (*o) << "max_cost_path: ";
      PrintPath(o, _max_cost_path);
    }
  }
  else {
    (*o) << "** never executed **" << endl;
  }
}

void
CAACostCalcCollector::
PrintPath(std::ostream * o, std::vector<CECFGNode *> & path)
{
  for(std::vector<CECFGNode *>::iterator n = path.begin();
      n != path.end(); ++n) {
    (*o) << (*n)->GetFlowGraphNode()->Stmt()->TryGetSourceString() << " ";
  } 
}

//---------------------------------
// Alternative printing function
//---------------------------------
ostream &operator << (std::ostream &o, CAACostCalcCollector &a)
{
  a.Print(&o);
  return o;
}

void
CAACostCalcCollector::
PrintBCETAndWCET(std::ostream & o)
{
  if(_nr_of_updates > 0) {
    o << "BCET estimate based on ALF AST cost lookup table: " << _min_cost << endl;
    o << "WCET estimate based on ALF AST cost lookup table: " << _max_cost << endl;
  }
  else {
    o << "No BCET or WCET estimates generated using ALF AST cost lookup table" << endl;
  }
}

void
CAACostCalcCollector::
PrintBCETPath(std::ostream & o)
{
  if(_nr_of_updates > 0 && _collect_min_cost_path) {
    o << "BCET path based on ALF AST cost lookup table: ";
    PrintPath(&o, _min_cost_path);
    o << endl;
  }
  else {
    o << "No BCET path collected" << endl;
  }
}

void
CAACostCalcCollector::
PrintWCETPath(std::ostream & o)
{
  if(_nr_of_updates > 0 && _collect_max_cost_path) {
    o << "WCET path based on ALF AST cost lookup table: ";
    PrintPath(&o, _max_cost_path);
    o << endl;
  }
  else {
    o << "No WCET path collected" << endl;
  }
}

void
CAACostCalcCollector::
PrintBCETAndWCETPaths(std::ostream & o)
{
  PrintBCETPath(o);
  PrintWCETPath(o);
}

// ---------------------------------
// To get the edges to consider
// ---------------------------------
const set<pair<CECFGNode *, CECFGNode *> > *
CAACostCalcCollector::
EdgesToConsider(void)
{
  // Set edges to consider (implemented by subclasses)
  if(_edges_to_consider.size() == 0)
    SetEdgesToConsider(&_edges_to_consider);
  return &_edges_to_consider;
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CAACostCalcScopeCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CAACostCalcScopeCollector::
CAACostCalcScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
			  bool collect_min_cost_path, bool collect_max_cost_path)
  : CAACostCalcCollector(scope, collect_only_basic_block_start_nodes,
			 collect_min_cost_path, collect_max_cost_path)
{
  // Do nothing
}

//----------------------------------
// To set the edges to consider
//---------------------------------
void
CAACostCalcScopeCollector::
SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider)
{
 // Call the wanted function in the scope
  _scope->EdgesInScope(edges_to_consider);
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CAACostCalcScopeAndSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CAACostCalcScopeAndSubCollector::
CAACostCalcScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
				bool collect_min_cost_path, bool collect_max_cost_path)
  : CAACostCalcCollector(scope, collect_only_basic_block_start_nodes,
			 collect_min_cost_path, collect_max_cost_path)
{
  // Do nothing
}

//----------------------------------
// To set the edges to consider
//---------------------------------
void
CAACostCalcScopeAndSubCollector::
SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider)
{
 // Call the wanted function in the scope
  _scope->EdgesInScopeAndSubScopes(edges_to_consider);
}


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CAACostCalcScopeAndLoopSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CAACostCalcScopeAndLoopSubCollector::
CAACostCalcScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
				    	bool collect_min_cost_path, bool collect_max_cost_path)
  : CAACostCalcCollector(scope, collect_only_basic_block_start_nodes,
			 collect_min_cost_path, collect_max_cost_path)
{
  // Do nothing
}

//----------------------------------
// To set the edges to consider
//---------------------------------
void
CAACostCalcScopeAndLoopSubCollector::
SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider)
{
 // Call the wanted function in the scope
  _scope->EdgesInScopeAndLoopSubScopes(edges_to_consider);
}

 
