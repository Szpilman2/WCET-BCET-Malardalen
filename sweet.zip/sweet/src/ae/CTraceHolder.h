#ifndef TRACE_HOLDER_H_
#define TRACE_HOLDER_H_

#include <fstream>
#include <string>

class CTraceHolder  
{
public:

  // To create and delete the trace holder
  CTraceHolder(std::string trace_file_name);
  ~CTraceHolder();

  // Boolean which checks if there are more traces to process
  bool HasNoMoreTraces();
  // Boolen which checks if there are more items in the current trace
  bool IsEndOfTrace();
    
  // To get the next trace item. Will assert if both HasNoMoreTraces() 
  // and IsEndOfTrace() are false. 
  std::string GetNextItemFromTrace();

protected:

  // To hold the stream of trace items
  std::ifstream _trace_stream;
};

#endif
