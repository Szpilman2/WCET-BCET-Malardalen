/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: $
//
// ----------------------------------------------------------------------

#include "tcalc/CAlfCostLookupTable.h"
#include "ae/CAACostCalcRecorder.h"
#include "ae/CAACostCalcCollector.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/ecfg/CECFGNode.h"
#include "program/alf/AStmt.h"
#include "program/alf/CAlfTreeFilter.h"

using namespace std;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CAACostCalcRecorder
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of recorder
//----------------------------------
CAACostCalcRecorder::
CAACostCalcRecorder(const alf::CAlfCostLookupTable * cost_lookup_table,
		    bool count_generic_nodes, bool count_op_types,
		    bool count_stmts, bool count_stmt_pairs,
		    double init_min_cost, double init_max_cost,
		    bool record_min_cost_path, bool record_max_cost_path)
  : _cost_lookup_table(cost_lookup_table),
    _count_generic_nodes(count_generic_nodes), 
    _count_op_types(count_op_types), 
    _count_stmts(count_stmts), 
    _count_stmt_pairs(count_stmt_pairs),
    _min_cost(init_min_cost), 
    _max_cost(init_max_cost),
    _record_min_cost_path(record_min_cost_path),
    _record_max_cost_path(record_max_cost_path)
{
  // Do nothing
}


//----------------------------------
// Deletion of recorder
//----------------------------------
CAACostCalcRecorder::
~CAACostCalcRecorder()
{
  // Do nothing
}

void
CAACostCalcRecorder::
UpdateWithProgramCounterChange(CECFGNode * from_node, CECFGNode * to_node)
{
  AddCostForNode(from_node);
  AddCostForEdge(from_node, to_node);

   // Remember the path
  if(_record_min_cost_path)
    _min_cost_path.push_back(from_node);
  if(_record_max_cost_path)
    _max_cost_path.push_back(from_node);
}

void
CAACostCalcRecorder::
UpdateWithProgramExit(CECFGNode * node)
{
  // Add timing cost for node since it has not been added before 
  AddCostForNode(node);

  // Add cost for program run
  if(_cost_lookup_table->HasProgRunCost()) {
    // Get the cost 
    double cost = _cost_lookup_table->LookUpProgRunCost();
    // Add the cost to the total min and max cost
    _min_cost += cost;
    _max_cost += cost;
    // Add the cost to the profiles
    CScope *func_scope = GetFunctionScope(node);
    _bc_profile[func_scope] += int64_t(cost);
    _wc_profile[func_scope] += int64_t(cost);
  }

  // Remember the path
  if(_record_min_cost_path)
    _min_cost_path.push_back(node);
  if(_record_max_cost_path)
    _max_cost_path.push_back(node);
}

void
CAACostCalcRecorder::
AddCostForNode(CECFGNode * node)
{
  CScope *func_scope = GetFunctionScope(node);
  auto func_min_cost = _bc_profile.insert( make_pair(func_scope,int64_t(0)) ).first;
  auto func_max_cost = _wc_profile.insert( make_pair(func_scope,int64_t(0)) ).first;

  // To avoid unneccessary work
  if((!_cost_lookup_table->HasGenericNodeCost() || !_count_generic_nodes) &&  
     (!_cost_lookup_table->HasOperandCost() || !_count_op_types) &&
     (!_cost_lookup_table->HasStmtCost() || !_count_stmts))
    return;

  // Check if node is first node in CFG
  // if(node->GetFlowGraphNode()->FlowGraph()->IsEntry(node->GetFlowGraphNode())) {
  // Yes add the cost for func args and declarations
  //  ******
  // }

  // Get the node statement
  CGenericStmt * stmt = node->GetFlowGraphNode()->Stmt();
  alf::AStmt * astmt = dynamic_cast<alf::AStmt *>(stmt);
  
  // Check if we should record all generic nodes
  if(_count_generic_nodes && _cost_lookup_table->HasGenericNodeCost()) {
    // Yes, extract all generic nodes in the statement 
    alf::CAlfTreeFilter filter(astmt);
    const alf::CAlfTreeFilter::NodeList gen_nodes = filter.GetAllNodes();
    // Loop through all nodes and extract the type
    for(alf::CAlfTreeFilter::NodeList::const_iterator gen_node = gen_nodes.begin(); 
        gen_node != gen_nodes.end(); ++gen_node) {
      // Extractg the gen node type
      alf::CGenericNode::TYPE node_type = (*gen_node)->GetNodeType();
      // Get the cost if any
      double cost = _cost_lookup_table->LookUpCost(node_type);
      // Add the cost to the total min and max cost
      _min_cost += cost;
      _max_cost += cost;
      func_min_cost->second += int64_t(cost);
      func_max_cost->second += int64_t(cost);
    }
  }
  
  // Check if we should record operands
  if(_count_op_types && _cost_lookup_table->HasOperandCost()) {
    // Yes, extract all generic nodes in the statement 
    alf::CAlfTreeFilter filter(astmt);
    const alf::CAlfTreeFilter::NodeList gen_nodes = filter.GetNodesOfType(alf::CGenericNode::TYPE_OP_EXPR_TUPLE);
    // Loop through all nodes and extract the operand
    for(alf::CAlfTreeFilter::NodeList::const_iterator gen_node = gen_nodes.begin(); 
        gen_node != gen_nodes.end(); ++gen_node) {
      // Extract the op type
      const alf::COpNumExprTuple * op_num_expr_tuple = dynamic_cast<const alf::COpNumExprTuple *>(*gen_node);
      alf::COpNumExprTuple::OP_TYPE op_type = op_num_expr_tuple->GetOperator();
      // Get the cost if any
      double cost = _cost_lookup_table->LookUpCost(op_type);
      // Add the cost to the total min and max cost
      _min_cost += cost;
      _max_cost += cost;
      func_min_cost->second += int64_t(cost);
      func_max_cost->second += int64_t(cost);
    }
  }

  // Check if we should record statement types
  if(_count_stmts && _cost_lookup_table->HasStmtCost()) {
    // Yes, extract the statement type and add its cost 
    CGenericStmt::GS_TYPE stmt_type = astmt->Type();
    // Get the cost if any
    double cost = _cost_lookup_table->LookUpCost(stmt_type);
    // Add the cost to the total min and max cost
    _min_cost += cost;
    _max_cost += cost;
    func_min_cost->second += int64_t(cost);
    func_max_cost->second += int64_t(cost);
  }
}

void
CAACostCalcRecorder::
AddCostForEdge(CECFGNode * from_node, CECFGNode * to_node)
{
  CScope *func_scope = GetFunctionScope(from_node);
  auto func_min_cost = _bc_profile.insert( make_pair(func_scope,int64_t(0)) ).first;
  auto func_max_cost = _wc_profile.insert( make_pair(func_scope,int64_t(0)) ).first;

  // To avoid unneccessary work
  if(!_cost_lookup_table->HasStmtPairCost() || !_count_stmt_pairs)
    return;

  // Get the stmt types of the two nodes
  CGenericStmt * from_stmt = from_node->GetFlowGraphNode()->Stmt();
  alf::AStmt * from_astmt = dynamic_cast<alf::AStmt *>(from_stmt);
  CGenericStmt::GS_TYPE from_stmt_type = from_astmt->Type();
  CGenericStmt * to_stmt = to_node->GetFlowGraphNode()->Stmt();
  alf::AStmt * to_astmt = dynamic_cast<alf::AStmt *>(to_stmt);
  CGenericStmt::GS_TYPE to_stmt_type = to_astmt->Type();

  // Get the cost if any and add its lower and upper
  // value to the accumulated recorder cost
  double cost = _cost_lookup_table->LookUpCost(std::make_pair(from_stmt_type, to_stmt_type));
  
  // Add the cost to the total min and max cost
  _min_cost += cost;
  _max_cost += cost;
  func_min_cost->second += int64_t(cost);
  func_max_cost->second += int64_t(cost);
}

CScope *
CAACostCalcRecorder::
GetFunctionScope(CECFGNode *node)
{
   CScope *scope = node->Scope();
   while (!scope->IsFunctionScope())
      scope = scope->ParentScope();
   return scope;
}

//----------------------------------
// Report the current ranges to the collector.
//---------------------------------
void
CAACostCalcRecorder::
ReportToCollector(CAACostCalcCollector * collector)
{
  // Report the current mapping to collector
  collector->Update((int64_t)_min_cost, (int64_t)_max_cost, &_bc_profile, &_wc_profile, &_min_cost_path, &_max_cost_path);
}

//----------------------------------
// Reset the recorder
//---------------------------------
void
CAACostCalcRecorder::
Reset()
{
  // Reset costs 
  _min_cost = 0;
  _max_cost = 0;

  // Reset profiles
  _bc_profile.clear();
  _wc_profile.clear();

  // Reset paths
  if(_record_min_cost_path)
    _min_cost_path.erase(_min_cost_path.begin(), _min_cost_path.end());
  if(_record_max_cost_path)
    _max_cost_path.erase(_max_cost_path.begin(), _max_cost_path.end());
}

//----------------------------------
// Copy the recorder
//---------------------------------
CAACostCalcRecorder *
CAACostCalcRecorder::
Copy()
{
  // Create a new recorder with the same mina amx max cost as current recorder
  CAACostCalcRecorder * new_rec = 
    new CAACostCalcRecorder(_cost_lookup_table, _count_generic_nodes, _count_op_types, 
			    _count_stmts, _count_stmt_pairs, _min_cost, _max_cost,
			    _record_min_cost_path, _record_max_cost_path);

  // Copy profiles
  new_rec->_bc_profile = _bc_profile;
  new_rec->_wc_profile = _wc_profile;

  // Copy the internal paths
  if(_record_min_cost_path)
    new_rec->_min_cost_path = _min_cost_path;
  if(_record_max_cost_path)
    new_rec->_max_cost_path = _max_cost_path;

  // Return the created recorder
  return new_rec;
}


//----------------------------------
// Merge two recorders
//---------------------------------
CAACostCalcRecorder *
CAACostCalcRecorder::
Merge(CAACostCalcRecorder * other_rec)
{
   // Take the smallest of the two min costs
   double new_min_cost = other_rec->GetMinCost();
   if(new_min_cost > _min_cost)
      new_min_cost = _min_cost;

   // Take the largest of the two max costs
   double new_max_cost = other_rec->GetMaxCost();
   if(new_max_cost < _max_cost)
      new_max_cost = _max_cost;
  
   // Craete the new recorder
   CAACostCalcRecorder * new_rec = 
      new CAACostCalcRecorder(_cost_lookup_table, _count_generic_nodes, _count_op_types, 
                              _count_stmts, _count_stmt_pairs, new_min_cost, new_max_cost,
                              _record_min_cost_path, _record_max_cost_path);

   // When both recorders have the same min/max cost, the values are taken from the one with the shortest path
   bool use_this_min = ((_min_cost < other_rec->GetMinCost()) ||
                        (_min_cost == other_rec->GetMinCost() &&
                         _min_cost_path.size() <= other_rec->_min_cost_path.size()));
   bool use_this_max = ((_max_cost > other_rec->GetMaxCost()) ||
                        (_max_cost == other_rec->GetMaxCost() &&
                         _max_cost_path.size() <= other_rec->_max_cost_path.size()));

   // Update the new recorder's BC and WC profiles
   new_rec->_bc_profile = use_this_min? _bc_profile : other_rec->_bc_profile;
   new_rec->_wc_profile = use_this_max? _wc_profile : other_rec->_wc_profile;

   // Update the new recorder's min and max paths
   if (_record_min_cost_path)
      new_rec->_min_cost_path = use_this_min? _min_cost_path : other_rec->_min_cost_path;
   if (_record_max_cost_path)
      new_rec->_max_cost_path = use_this_max? _max_cost_path : other_rec->_max_cost_path;

   // Return the created recorder
   return new_rec;
}

CRecorder * 
CAACostCalcRecorder::
Merge(CRecorder * other_rec)
{
  return Merge(dynamic_cast<CAACostCalcRecorder *>(other_rec));
}

//---------------------------------
// For printing the recorder
//---------------------------------
void
CAACostCalcRecorder::
Print(ostream * o)
{
  (*o) << "min_cost: " << _min_cost << " max_cost: " << _max_cost << endl;
}

//---------------------------------
// Alternative printing function
//---------------------------------
ostream &operator << (ostream &o, CAACostCalcRecorder &a)
{
  a.Print(&o);
  return o;
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CAACostCalcRecorderServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//---------------------------------
// To create the server
//---------------------------------
CAACostCalcRecorderServer::
CAACostCalcRecorderServer(alf::CAlfCostLookupTable * cost_lookup_table,
			  bool count_generic_nodes, bool count_op_types, 
			  bool count_stmts, bool count_stmt_pairs,
			  bool record_min_cost_path, bool record_max_cost_path)
  : _cost_lookup_table(cost_lookup_table), 
    _count_generic_nodes(count_generic_nodes), _count_op_types(count_op_types), 
    _count_stmts(count_stmts), _count_stmt_pairs(count_stmt_pairs),
    _record_min_cost_path(record_min_cost_path),
    _record_max_cost_path(record_max_cost_path)
{
  // Do nothing
}

//---------------------------------
// To create the recorder
//---------------------------------
CAACostCalcRecorder *
CAACostCalcRecorderServer::
CreateRecorder()
{
  // Create the recorder
  CAACostCalcRecorder * recorder = 
    new CAACostCalcRecorder(_cost_lookup_table,
			    _count_generic_nodes, _count_op_types,
			    _count_stmts, _count_stmt_pairs, 0, 0,
			    _record_min_cost_path, _record_max_cost_path);
  
  // Remember that we have one reference to the recorder
  _recorder_to_refs[recorder] = 1;

  // Return the new recorder
  return recorder;
}

// -------------------------------------------------------
// To delete a certain recorder
// -------------------------------------------------------
void
CAACostCalcRecorderServer::
DeleteRecorder(CAACostCalcRecorder * recorder)
{
  assert(recorder);
  assert(_recorder_to_refs.find(recorder) != _recorder_to_refs.end());
  // Update map
  _recorder_to_refs[recorder] = _recorder_to_refs[recorder]-1;

  // Check if we have any refs left
  if(_recorder_to_refs[recorder] == 0)
    {
      // No, remove the recorder for real
      delete recorder;

      // Remove the mapping
      // _recorder_to_refs.erase(recorder);
    }
}

void
CAACostCalcRecorderServer::
DeleteRecorder(CRecorder * recorder)
{
  // Call the more specialized version
  DeleteRecorder(dynamic_cast<CAACostCalcRecorder*>(recorder));
}

// -------------------------------------------------------
// Copy the recorder
// -------------------------------------------------------
CRecorder *
CAACostCalcRecorderServer::
CopyRecorder(CRecorder * recorder)
{
  assert(recorder);
  // Call the more specialized version
  return CopyRecorder(dynamic_cast<CAACostCalcRecorder*>(recorder));
}

// -------------------------------------------------------
// Update the recorder
// -------------------------------------------------------
void
CAACostCalcRecorderServer::
UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after)
{
  assert(*recorder);
  CAACostCalcRecorder * rec = dynamic_cast<CAACostCalcRecorder*>(*recorder);
  assert(rec);
  // Call the more specialized version
  *recorder = UpdateRecorderWithProgramCounterChange(rec, pc_before, pc_after);
  assert(*recorder);
}

void
CAACostCalcRecorderServer::
UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before)
{
  assert(*recorder);
  CAACostCalcRecorder * rec = dynamic_cast<CAACostCalcRecorder*>(*recorder);
  assert(rec);
  // Call the more specialized version
  *recorder = UpdateRecorderWithProgramExit(rec, pc_before);
  assert(*recorder);
}

// -------------------------------------------------------
// Reset the current recorder
// -------------------------------------------------------
void
CAACostCalcRecorderServer::
ResetRecorder(CRecorder ** recorder)
{
  *recorder = ResetRecorder(dynamic_cast<CAACostCalcRecorder*>(*recorder));
}

// -------------------------------------------------------
// Merge two recorders
// -------------------------------------------------------
CRecorder *
CAACostCalcRecorderServer::
MergeRecorders(CRecorder * rec1, CRecorder * rec2)
{
  assert(rec1 && rec2);
  return MergeRecorders(dynamic_cast<CAACostCalcRecorder*>(rec1), dynamic_cast<CAACostCalcRecorder*>(rec2));
}

// -------------------------------------------------------
// To print all the mappings in the server
// -------------------------------------------------------
void
CAACostCalcRecorderServer::
Print(ostream * o)
{
  // Loop through all maps
  map<CAACostCalcRecorder *, int64_t>::iterator tr;
  int i = 1;
  for(map<CAACostCalcRecorder *, int64_t>::iterator tr = _recorder_to_refs.begin();
      tr != _recorder_to_refs.end(); ++tr) {
    (*o) << i << ": " << (*tr).first << "."
	 << (*tr).second << endl;
    i++;
  }
}

// Alternative printing function
ostream &operator << (ostream &o, CAACostCalcRecorderServer &a)
{
  a.Print(&o);
  return o;
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CAACostCalcRecorderCOWServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

// -------------------------------------------------------
// To create the recorder server
// -------------------------------------------------------
CAACostCalcRecorderCOWServer::
CAACostCalcRecorderCOWServer(alf::CAlfCostLookupTable * cost_lookup_table,
			     bool count_generic_nodes, bool count_op_types, 
			     bool count_stmts, bool count_stmt_pairs,
			     bool record_min_cost_path, bool record_max_cost_path)
  : CAACostCalcRecorderServer(cost_lookup_table,
			      count_generic_nodes, count_op_types,
			      count_stmts, count_stmt_pairs,
			      record_min_cost_path, record_max_cost_path)
{
  // Do nothing
}

// -------------------------------------------------------
// To delete the recorder server
// -------------------------------------------------------
CAACostCalcRecorderCOWServer::
~CAACostCalcRecorderCOWServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To copy recorder
// -------------------------------------------------------
CAACostCalcRecorder *
CAACostCalcRecorderCOWServer::
CopyRecorder(CAACostCalcRecorder * recorder)
{
  // Do no copying, just add one more reference to the recorder
  assert(_recorder_to_refs.find(recorder) != _recorder_to_refs.end());
  _recorder_to_refs[recorder] = _recorder_to_refs[recorder] + 1;

  // Return the same recorder
  return recorder;
}

// -------------------------------------------------------
// To increase count for a certain node
// -------------------------------------------------------
CAACostCalcRecorder *
CAACostCalcRecorderCOWServer::
UpdateRecorderWithProgramCounterChange(CAACostCalcRecorder * recorder, CECFGNode * pc_before, CECFGNode * pc_after)
{
  // std::cout << "CAACostCalcRecorderCOWServer::CountGenericTypesWithRecorder 1\n";
  assert(_recorder_to_refs.find(recorder) != _recorder_to_refs.end());
  assert(_recorder_to_refs[recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[recorder] == 1)
    {
      // Update current recorder
      recorder->UpdateWithProgramCounterChange(pc_before, pc_after);

      // Return the updated recorder
      return recorder;
    }
  // More than one reference
  else
    {
      // Do the real copying
      CAACostCalcRecorder * recorder_copy = recorder->Copy();

      // Update the copied recorder
      recorder_copy->UpdateWithProgramCounterChange(pc_before, pc_after);

      // Update map
      _recorder_to_refs[recorder] = _recorder_to_refs[recorder] - 1;
      _recorder_to_refs[recorder_copy] = 1;

      // Return the copied recorder
      return recorder_copy;
    }
}

CAACostCalcRecorder *
CAACostCalcRecorderCOWServer::
UpdateRecorderWithProgramExit(CAACostCalcRecorder * recorder, CECFGNode * pc_before)
{
  assert(_recorder_to_refs.find(recorder) != _recorder_to_refs.end());
  assert(_recorder_to_refs[recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[recorder] == 1)
    {
      // Update current recorder
      recorder->UpdateWithProgramExit(pc_before);

      // Return the updated recorder
      return recorder;
    }
  // More than one reference
  else
    {
      // Do the real copying
      CAACostCalcRecorder * recorder_copy = recorder->Copy();

      // Update the copied recorder
      recorder_copy->UpdateWithProgramExit(pc_before);

      // Update map
      _recorder_to_refs[recorder] = _recorder_to_refs[recorder] - 1;
      _recorder_to_refs[recorder_copy] = 1;

      // Return the copied recorder
      return recorder_copy;
    }
}

// -------------------------------------------------------
// To reset the recorder
// -------------------------------------------------------
CAACostCalcRecorder *
CAACostCalcRecorderCOWServer::
ResetRecorder(CAACostCalcRecorder * recorder)
{
  assert(_recorder_to_refs.find(recorder) != _recorder_to_refs.end());
  assert(_recorder_to_refs[recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[recorder] == 1)
    {
      // Update current recorder
      recorder->Reset();

      // Return the updated recorder
      return recorder;
    }
  // More than one reference
  else
    {
      // Create a new recorder (same as doing a reset)
      CAACostCalcRecorder * new_recorder = 
        new CAACostCalcRecorder(_cost_lookup_table, 
				_count_generic_nodes, _count_op_types,
				_count_stmts, _count_stmt_pairs, 0, 0,
				_record_min_cost_path, _record_max_cost_path);

      // Update map
      _recorder_to_refs[recorder] = _recorder_to_refs[recorder] - 1;
      _recorder_to_refs[new_recorder] = 1;

      // Return the new recorder
      return new_recorder;
    }
}

// -------------------------------------------------------
// To merge two recorders
// -------------------------------------------------------
CAACostCalcRecorder *
CAACostCalcRecorderCOWServer::
MergeRecorders(CAACostCalcRecorder * recorder1, CAACostCalcRecorder * recorder2)
{
  assert(_recorder_to_refs.find(recorder1) != _recorder_to_refs.end());
  assert(_recorder_to_refs.find(recorder2) != _recorder_to_refs.end());
  // Check if it is the same recorder (i.e. they points to the same address)
  if(recorder1 == recorder2)
    {
      // Update map
      _recorder_to_refs[recorder1] = _recorder_to_refs[recorder1] + 1;

      // Return the same recorder
      return recorder1;
    }
  else
    {
      // Different recorders, do the real merging
      CAACostCalcRecorder * new_recorder = recorder1->Merge(recorder2);

      // Update map
      _recorder_to_refs[new_recorder] = 1;

      // Return the new recorder
      return new_recorder;
    }
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CAACostCalcRecorderNoReuseServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

// -------------------------------------------------------
// To create the recorder server
// -------------------------------------------------------
CAACostCalcRecorderNoReuseServer::
CAACostCalcRecorderNoReuseServer(alf::CAlfCostLookupTable * cost_lookup_table,
				 bool count_generic_nodes, bool count_op_types, 
				 bool count_stmts, bool count_stmt_pairs,
				 bool record_min_cost_path, bool record_max_cost_path)
  : CAACostCalcRecorderServer(cost_lookup_table,
			      count_generic_nodes, count_op_types,
			      count_stmts, count_stmt_pairs,
			      record_min_cost_path, record_max_cost_path)
{
  // Do nothing
}

// -------------------------------------------------------
// To delete the recorder server
// -------------------------------------------------------
CAACostCalcRecorderNoReuseServer::
~CAACostCalcRecorderNoReuseServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To copy recorder
// -------------------------------------------------------
CAACostCalcRecorder *
CAACostCalcRecorderNoReuseServer::
CopyRecorder(CAACostCalcRecorder * recorder)
{
  // Do the copying right away
  CAACostCalcRecorder * new_recorder = recorder->Copy();

  // Update map
  _recorder_to_refs[new_recorder] = 1;

  // Return the new recorder
  return new_recorder;
}

// -------------------------------------------------------
// To increase count for a certain node
// -------------------------------------------------------
CAACostCalcRecorder *
CAACostCalcRecorderNoReuseServer::
UpdateRecorderWithProgramCounterChange(CAACostCalcRecorder * recorder, 
                                       CECFGNode * pc_before, CECFGNode * pc_after)
{
  // Update current recorder
  recorder->UpdateWithProgramCounterChange(pc_before, pc_after);

  // Return the updated recorder
  return recorder;
}

CAACostCalcRecorder *
CAACostCalcRecorderNoReuseServer::
UpdateRecorderWithProgramExit(CAACostCalcRecorder * recorder, 
                              CECFGNode * pc_before)
{
  // Update current recorder
  recorder->UpdateWithProgramExit(pc_before);

  // Return the updated recorder
  return recorder;
}

// -------------------------------------------------------
// To reset the recorder
// -------------------------------------------------------
CAACostCalcRecorder *
CAACostCalcRecorderNoReuseServer::
ResetRecorder(CAACostCalcRecorder * recorder)
{
  // Reset current recorder
  recorder->Reset();

  // Return the updated recorder
  return recorder;
}

// -------------------------------------------------------
// To merge two recorders
// -------------------------------------------------------
CAACostCalcRecorder *
CAACostCalcRecorderNoReuseServer::
MergeRecorders(CAACostCalcRecorder * recorder1, CAACostCalcRecorder * recorder2)
{
  // Do the merging getting a new recorder
  CAACostCalcRecorder * new_recorder = recorder1->Merge(recorder2);

  // Update map
  _recorder_to_refs[new_recorder] = 1;

  // Return the new recorder
  return new_recorder;
}










