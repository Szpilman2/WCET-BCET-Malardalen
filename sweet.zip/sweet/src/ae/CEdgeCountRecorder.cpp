/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CEdgeCountRecorder.cpp 7975 2018-11-23 15:24:04Z lkg02 $
//
// ----------------------------------------------------------------------

#include "CEdgeCountRecorder.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/ecfg/CECFGNode.h"

using namespace std;

// Part of the memory debuger



//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CEdgeCountRecorder
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of recorder
//----------------------------------
CEdgeCountRecorder::
CEdgeCountRecorder()
: _record_only_edges_inbetween_basic_blocks(true)
{

  // Do nothing
}

CEdgeCountRecorder::
CEdgeCountRecorder(bool record_only_edges_inbetween_basic_blocks)
  : _record_only_edges_inbetween_basic_blocks(record_only_edges_inbetween_basic_blocks)
{

  // Do nothing
}


//----------------------------------
// Deletion of recorder
//----------------------------------
CEdgeCountRecorder::
~CEdgeCountRecorder()
{
  // Go through the map deleting all the ranges
  t_edge_to_range_map::iterator e2r;
  FORALL(e2r, _edge_to_range_map)
    delete (*e2r).second;
  ;
}

//----------------------------------
// Remember that we have executed a certain edge
//----------------------------------
void
CEdgeCountRecorder::
IncreaseCount(pair<CECFGNode *, CECFGNode *> edge)
{
  // Check if we should ignore the edge
  if(_record_only_edges_inbetween_basic_blocks && !(edge.second->IsBeginOfBasicBlock()))
    return;

  // Check if the edge exists since before
  if(_edge_to_range_map.find(edge) == _edge_to_range_map.end())
    {
      // Nope, add the range 1..1 to the map
      CIntegerRange* range = new CIntegerRange(1,1);
      _edge_to_range_map[edge] = range;
    }
  else
    {
      // Yes, add 1..1 to the old range value
      CIntegerRange* old_range =  _edge_to_range_map[edge];
      int64_t new_l = old_range->L() + 1;
      int64_t new_u = old_range->U() + 1;
      CIntegerRange* new_range = new CIntegerRange(new_l,new_u);
      delete old_range;
      _edge_to_range_map[edge] = new_range;
    }
}

void
CEdgeCountRecorder::
UpdateWithProgramCounterChange(CECFGNode * pc_before, CECFGNode * pc_after)
{
  IncreaseCount(make_pair(pc_before,pc_after));
}

void
CEdgeCountRecorder::
UpdateWithProgramExit(CECFGNode * pc_before)
{
  // Do nothing, we do not keep track on individual nodes
}

// ---------------------------------
// To get all node pairs which have an upper bound bigger than zero
// ---------------------------------
void 
CEdgeCountRecorder::
GetTakenEdges(std::set<std::pair<CECFGNode *, CECFGNode *> > * node_pairs, 
              bool get_start_node_of_basic_block)
{
  t_edge_to_range_map::iterator e2r;
  FORALL(e2r, _edge_to_range_map) {
    std::pair<CECFGNode *, CECFGNode *> edge = (*e2r).first;
    CIntegerRange* range = (*e2r).second;
    if(range->U() > 0) {
      // Get the first ecfg node. If we should only keep track of basic block
      // start nodes, we derive this node from the first node.
      CECFGNode * first_ecfg_node = NULL; 
      if(get_start_node_of_basic_block) {
        first_ecfg_node = edge.first->GetBeginNodeOfNodesBasicBlock();
      }
      else {
        first_ecfg_node = edge.first;
      }
      // Get the second ecfg node. For call edges we should instead get the 
      // edge that goes to the result node from the call node.
      CECFGNode * second_ecfg_node = NULL;
      if(edge.first->HasFalseEdgeSuccessor()) {
        second_ecfg_node = edge.first->GetFalseEdgeSuccessor();
      }
      else {
        second_ecfg_node = edge.second;
      }

      // Create the resulting edge and instert in set
      node_pairs->insert(make_pair(first_ecfg_node, second_ecfg_node));
    }
  }
}

void
CEdgeCountRecorder::
SetCount(pair<CECFGNode *, CECFGNode *> edge, int count)
{
  // Check if we should ignore the edge
  if(_record_only_edges_inbetween_basic_blocks && !(edge.second->IsBeginOfBasicBlock()))
    return;

  // Check if the edge exists since before
  if(_edge_to_range_map.find(edge) == _edge_to_range_map.end())
    {
      // Nope, set the range
      _edge_to_range_map[edge] = new CIntegerRange(count, count);
    }
  else
    {
      // Delete the old range
      delete _edge_to_range_map[edge];
      _edge_to_range_map[edge] = new CIntegerRange(count, count);
    }
}

void
CEdgeCountRecorder::
SetRange(pair<CECFGNode *, CECFGNode *> edge, CIntegerRange* range)
{
  // Check if we should ignore the edge
  if(_record_only_edges_inbetween_basic_blocks && !(edge.second->IsBeginOfBasicBlock()))
    return;

  // Check if the edge exists since before
  if(_edge_to_range_map.find(edge) == _edge_to_range_map.end())
    {
      // Nope, set the range
      _edge_to_range_map[edge] = range;
    }
  else
    {
      // Delete the old range
      delete _edge_to_range_map[edge];
      _edge_to_range_map[edge] = range;
    }
}

//----------------------------------
// Report the current ranges to the collector.
//---------------------------------
void
CEdgeCountRecorder::
ReportToCollector(CEdgeCountCollector * collector)
{
  // Report the current mapping to collector
  collector->Update(&_edge_to_range_map);
}

//----------------------------------
// Reset the recorder
//---------------------------------
void
CEdgeCountRecorder::
Reset()
{
  // Delete all the ranges
  t_edge_to_range_map::iterator e2r;
  FORALL(e2r, _edge_to_range_map)
    delete (*e2r).second;

  // Remove all the mappings
  _edge_to_range_map.erase(_edge_to_range_map.begin(), _edge_to_range_map.end());
  assert(_edge_to_range_map.size() == 0);
}

//----------------------------------
// Copy the recorder
//---------------------------------
CEdgeCountRecorderPtr
CEdgeCountRecorder::
Copy()
{
  // Create a new recorder
  CEdgeCountRecorder * new_recorder = new CEdgeCountRecorder(_record_only_edges_inbetween_basic_blocks);

  // Go through all the edge_id to range mappings
  t_edge_to_range_map::iterator e2r;
  FORALL(e2r, _edge_to_range_map)
    {
      pair<CECFGNode *, CECFGNode *> edge = (*e2r).first;
      CIntegerRange* range = (*e2r).second;
      CIntegerRange* new_range = range->Copy();
      new_recorder->_edge_to_range_map[edge] = new_range;
    }
  // We are done, the range map has been copied to the new recorder
  return new_recorder;
}

//----------------------------------
// Merge two recorders
//---------------------------------
CEdgeCountRecorderPtr
CEdgeCountRecorder::
Merge(CEdgeCountRecorderPtr other_recorder)
{
  // Create a new recorder with the same collector
  CEdgeCountRecorderPtr new_recorder = other_recorder->Copy();

  // A set to keep track of processed edges
  set<pair<CECFGNode *, CECFGNode *> > processed_edges;

  // Go through all the edge_id to range mappings in the current
  // recorder and the argument recorder and remember all the edges
  // mappings
  t_edge_to_range_map::iterator e2r;
  FORALL(e2r, _edge_to_range_map)
    {
      pair<CECFGNode *, CECFGNode *> edge = (*e2r).first;
      CIntegerRange* range = (*e2r).second;

      // Check if the new recorder has a range for the edge
      if(new_recorder->_edge_to_range_map.find(edge) ==
         new_recorder->_edge_to_range_map.end()) {

        // No range, this means that the edge has not been
        // taken in the other state

        // Create a [0..0] range
        CIntegerRange* zero_range = new CIntegerRange(0,0);

        // Merge the current range with the zero range
        CIntegerRange* new_range = range->Merge(zero_range);

        // Delete the temporary range
        delete zero_range;

        // Add the new range to the recorder for the node (prev_range
        // will be deleted)
        new_recorder->SetRange(edge, new_range);
      }
      else {
        // Merge ranges (prev_range will be deleted)
        CIntegerRange* prev_range = new_recorder->_edge_to_range_map[edge];
        new_recorder->SetRange(edge, range->Merge(prev_range));
      }

      // Add the edge to the set of processed edges
      processed_edges.insert(edge);
    }

  // Go through the second recorder mapping
  FORALL(e2r, other_recorder->_edge_to_range_map)
    {
      // Get the edge
      pair<CECFGNode *, CECFGNode *> edge = (*e2r).first;

      // Check if the edge already has been processed
      if(processed_edges.find(edge) != processed_edges.end())
        continue;

      // We have a edge that only exists in the second set.  This
      // means that the edge has not been taken in the other state

      // Get the range
      CIntegerRange* range = (*e2r).second;

      // Create a [0..0] range
      CIntegerRange* zero_range = new CIntegerRange(0,0);

      // Merge the current range with the zero range
      CIntegerRange* new_range = range->Merge(zero_range);

      // Delete the temporary range
      delete zero_range;

      // Add the new range to the recorder for the node (prev_range
      // will be deleted)
      new_recorder->SetRange(edge, new_range);
    }

  // Return the new recorder
  return new_recorder;
}

//----------------------------------
// Merge two recorders
//---------------------------------
CRecorder *
CEdgeCountRecorder::
Merge(CRecorder * other_recorder)
{
  return Merge(dynamic_cast<CEdgeCountRecorder *>(other_recorder));
}

//---------------------------------
// For printing the recorder
//---------------------------------
void
CEdgeCountRecorder::
Print(ostream * o)
{
  t_edge_to_range_map::iterator e2r;
  FORALL(e2r, _edge_to_range_map)
    {
      pair<CECFGNode *, CECFGNode *> edge = (*e2r).first;
      string edge_name =  edge.first->GetFlowGraphNode()->Name() + "->"
        + edge.second->GetFlowGraphNode()->Name();
      CIntegerRange* range = (*e2r).second;
      (*o) << "  " << edge_name << " = " << (*range) << endl;
    }
  (*o) << endl;
  (*o) << endl;
}




//---------------------------------
// Alternative printing function
//---------------------------------
ostream &operator << (ostream &o, CEdgeCountRecorder &a)
{
  a.Print(&o);
  return o;
}


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CEdgeCountRecorderServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//---------------------------------
// To create the recorder server
//---------------------------------
CEdgeCountRecorderServer::
CEdgeCountRecorderServer()
  : _record_only_edges_inbetween_basic_blocks(true)
{
  // Do nothing
}

CEdgeCountRecorderServer::
CEdgeCountRecorderServer(bool record_only_edges_inbetween_basic_blocks)
  : _record_only_edges_inbetween_basic_blocks(record_only_edges_inbetween_basic_blocks)
{
  // Do nothing
}

//---------------------------------
// To create the recorder
//---------------------------------
CEdgeCountRecorderPtr
CEdgeCountRecorderServer::
CreateRecorder()
{
  // Create the recorder
  CEdgeCountRecorderPtr recorder = new CEdgeCountRecorder(_record_only_edges_inbetween_basic_blocks);

  // Remember that we have one reference to the recorder
  _recorder_to_refs[recorder] = 1;

  // Return the new recorder
  return recorder;
}

// -------------------------------------------------------
// To delete a certain recorder
// -------------------------------------------------------
void
CEdgeCountRecorderServer::
DeleteRecorder(CEdgeCountRecorderPtr recorder)
{
  // Update map
  _recorder_to_refs[recorder] = _recorder_to_refs[recorder]-1;

  // Check if we have any refs left
  if(_recorder_to_refs[recorder] == 0)
    {
      // No, remove the recorder for real
      delete recorder;

      // Remove the mapping
      // _recorder_to_refs.erase(recorder);
    }
}

void
CEdgeCountRecorderServer::
DeleteRecorder(CRecorder * recorder)
{
  // Call the more specialized version
  DeleteRecorder(dynamic_cast<CEdgeCountRecorder*>(recorder));
}

// -------------------------------------------------------
// Copy the recorder
// -------------------------------------------------------
CRecorder *
CEdgeCountRecorderServer::
CopyRecorder(CRecorder * recorder)
{
  // Call the more specialized version
  return CopyRecorder(dynamic_cast<CEdgeCountRecorder*>(recorder));
}

// -------------------------------------------------------
// Update the recorder
// -------------------------------------------------------
void
CEdgeCountRecorderServer::
UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after)
{
  *recorder = IncreaseCountInRecorder(dynamic_cast<CEdgeCountRecorder*>(*recorder),
				      make_pair(pc_before,pc_after));
}

void
CEdgeCountRecorderServer::
UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before)
{
  // We ignore edges
  return;
}

// -------------------------------------------------------
// Reset the current recorder
// -------------------------------------------------------
void
CEdgeCountRecorderServer::
ResetRecorder(CRecorder ** recorder)
{
  *recorder = ResetRecorder(dynamic_cast<CEdgeCountRecorder*>(*recorder));
}

// -------------------------------------------------------
// Merge two recorders
// -------------------------------------------------------
CRecorder *
CEdgeCountRecorderServer::
MergeRecorders(CRecorder * rec1, CRecorder * rec2)
{
  return MergeRecorders(dynamic_cast<CEdgeCountRecorder*>(rec1), dynamic_cast<CEdgeCountRecorder*>(rec2));
}

// -------------------------------------------------------
// To print all the mappings in the server
// -------------------------------------------------------
void
CEdgeCountRecorderServer::
Print(ostream * o)
{
  // Loop through all maps
  map<CEdgeCountRecorderPtr, int64_t>::iterator tr;
  int i = 1;
  FORALL(tr, (_recorder_to_refs))
    {
      (*o) << i << ": " << (*tr).first << "."
           << (*tr).second << endl;
      i++;
    }
}

// Alternative printing function
ostream &operator << (ostream &o, CEdgeCountRecorderServer &a)
{
  a.Print(&o);
  return o;
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CEdgeCountRecorderCOWServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

// -------------------------------------------------------
// To create the recorder server
// -------------------------------------------------------
CEdgeCountRecorderCOWServer::
CEdgeCountRecorderCOWServer()
  : CEdgeCountRecorderServer()
{
  // Do nothing
}

CEdgeCountRecorderCOWServer::
CEdgeCountRecorderCOWServer(bool record_only_edges_inbetween_basic_blocks)
  : CEdgeCountRecorderServer(record_only_edges_inbetween_basic_blocks)
{
  // Do nothing
}

// -------------------------------------------------------
// To delete the recorder server
// -------------------------------------------------------
CEdgeCountRecorderCOWServer::
~CEdgeCountRecorderCOWServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To copy recorder
// -------------------------------------------------------
CEdgeCountRecorderPtr
CEdgeCountRecorderCOWServer::
CopyRecorder(CEdgeCountRecorderPtr recorder)
{
  // Do no copying, just add one more reference to the recorder
  _recorder_to_refs[recorder] = _recorder_to_refs[recorder] + 1;

  // Return the same recorder
  return recorder;
}

// -------------------------------------------------------
// To increase count for a certain edge
// -------------------------------------------------------
CEdgeCountRecorderPtr
CEdgeCountRecorderCOWServer::
IncreaseCountInRecorder(CEdgeCountRecorderPtr recorder, pair<CECFGNode *, CECFGNode *> edge)
{
  assert(_recorder_to_refs[recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[recorder] == 1)
    {
      // Update current recorder
      recorder->IncreaseCount(edge);

      // Return the updated recorder
      return recorder;
    }
  // More than one reference
  else
    {
      // Do the real copying
      CEdgeCountRecorderPtr recorder_copy = recorder->Copy();

      // Update the copied recorder
      recorder_copy->IncreaseCount(edge);

      // Update map
      _recorder_to_refs[recorder] = _recorder_to_refs[recorder] - 1;
      _recorder_to_refs[recorder_copy] = 1;

      // Return the copied recorder
      return recorder_copy;
    }
}

// -------------------------------------------------------
// To reset the recorder
// -------------------------------------------------------
CEdgeCountRecorderPtr
CEdgeCountRecorderCOWServer::
ResetRecorder(CEdgeCountRecorderPtr recorder)
{
  assert(_recorder_to_refs[recorder] >= 1);

  // Check if we have only one reference to recorder
  if(_recorder_to_refs[recorder] == 1)
    {
      // Update current recorder
      recorder->Reset();

      // Return the updated recorder
      return recorder;
    }
  // More than one reference
  else
    {
      // Create a new recorder (same as doing a reset)
      CEdgeCountRecorderPtr new_recorder = new CEdgeCountRecorder();

      // Update map
      _recorder_to_refs[recorder] = _recorder_to_refs[recorder] - 1;
      _recorder_to_refs[new_recorder] = 1;

      // Return the new recorder
      return new_recorder;
    }
}

// -------------------------------------------------------
// To merge two recorders
// -------------------------------------------------------
CEdgeCountRecorderPtr
CEdgeCountRecorderCOWServer::
MergeRecorders(CEdgeCountRecorderPtr recorder1, CEdgeCountRecorderPtr recorder2)
{
  // Check if it is the same recorder (i.e. they points to the same address)
  if(recorder1 == recorder2)
    {
      // Update map
      _recorder_to_refs[recorder1] = _recorder_to_refs[recorder1] + 1;

      // Return the same recorder
      return recorder1;
    }
  else
    {
      // Different recorders, do the real merging
      CEdgeCountRecorderPtr new_recorder = recorder1->Merge(recorder2);

      // Update map
      _recorder_to_refs[new_recorder] = 1;

      // Return the new recorder
      return new_recorder;
    }
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CEdgeCountRecorderNoReuseServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

// -------------------------------------------------------
// To create the recorder server
// -------------------------------------------------------
CEdgeCountRecorderNoReuseServer::
CEdgeCountRecorderNoReuseServer()
  : CEdgeCountRecorderServer()
{
  // Do nothing
}

CEdgeCountRecorderNoReuseServer::
CEdgeCountRecorderNoReuseServer(bool record_only_edges_inbetween_basic_blocks)
  : CEdgeCountRecorderServer(record_only_edges_inbetween_basic_blocks)
{
  // Do nothing
}

// -------------------------------------------------------
// To delete the recorder server
// -------------------------------------------------------
CEdgeCountRecorderNoReuseServer::
~CEdgeCountRecorderNoReuseServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To copy recorder
// -------------------------------------------------------
CEdgeCountRecorderPtr
CEdgeCountRecorderNoReuseServer::
CopyRecorder(CEdgeCountRecorderPtr recorder)
{
  // Do the copying right away
  CEdgeCountRecorderPtr new_recorder = recorder->Copy();

  // Update map
  _recorder_to_refs[new_recorder] = 1;

  // Return the new recorder
  return new_recorder;
}

// -------------------------------------------------------
// To increase count for a certain edge
// -------------------------------------------------------
CEdgeCountRecorderPtr
CEdgeCountRecorderNoReuseServer::
IncreaseCountInRecorder(CEdgeCountRecorderPtr recorder, pair<CECFGNode *, CECFGNode *> edge)
{
  // Update current recorder
  recorder->IncreaseCount(edge);

  // Return the updated recorder
  return recorder;
}

// -------------------------------------------------------
// To reset the recorder
// -------------------------------------------------------
CEdgeCountRecorderPtr
CEdgeCountRecorderNoReuseServer::
ResetRecorder(CEdgeCountRecorderPtr recorder)
{
  // Reset current recorder
  recorder->Reset();

  // Return the updated recorder
  return recorder;
}

// -------------------------------------------------------
// To merge two recorders
// -------------------------------------------------------
CEdgeCountRecorderPtr
CEdgeCountRecorderNoReuseServer::
MergeRecorders(CEdgeCountRecorderPtr recorder1, CEdgeCountRecorderPtr recorder2)
{
  // Do the merging getting a new recorder
  CEdgeCountRecorderPtr new_recorder = recorder1->Merge(recorder2);

  // Update map
  _recorder_to_refs[new_recorder] = 1;

  // Return the new recorder
  return new_recorder;
}



