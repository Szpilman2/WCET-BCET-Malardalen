#include "CIntegerRange.h"

using namespace std;

void
CIntegerRange::
Print(ostream * o) const
{
   *o << "[" << _l << "," << _u << "]";
}

void
CIntegerRange::
Draw(ostream * o) const
{
   *o << _l << ".." << _u;
}

ostream &operator << (ostream &o, const CIntegerRange &a)
{
  a.Print(&o);
  return o;
}

