/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CNodePairCountCollector.cpp 7974 2018-11-23 13:53:26Z lkg02 $
//
// ----------------------------------------------------------------------

#include "CNodePairCountCollector.h"
#include "CNodeCountRecorder.h"
#include "flow_facts/CIndexRange.h"
#include "graphs/scopes/CScope.h"
#include "flow_facts/CExpression.h"
#include "graphs/ecfg/CECFGNode.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "dfa/DataFlowAnalysis.h"
#include "dfa/DataFlowAnalysis.inl"
#include "dfa/TakenBeforeDataFlowAnalysis.h"
#include "dfa/TakenBeforeDataFlowAnalysis.inl"

using namespace std;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodePairCountCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of collector
//----------------------------------
CNodePairCountCollector::
CNodePairCountCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                        bool generate_lower_bound_ffs, bool generate_upper_bound_ffs,
                        std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : _scope(scope), _collect_only_basic_block_start_nodes(collect_only_basic_block_start_nodes),
    _generate_lower_bound_ffs(generate_lower_bound_ffs), _generate_upper_bound_ffs(generate_upper_bound_ffs)
{
  if(may_but_not_must_be_taken_node_pairs != NULL) {
    _has_may_but_not_must_be_taken_node_pairs=true;
    for(std::set<std::pair<CECFGNode *, CECFGNode *> >::iterator nn = may_but_not_must_be_taken_node_pairs->begin();
        nn != may_but_not_must_be_taken_node_pairs->end(); ++nn) {
      _may_but_not_must_be_taken_node_pairs.insert(MakeNodePair((*nn).first, (*nn).second));
    }
  }
  else { 
    _has_may_but_not_must_be_taken_node_pairs=false;
  }
  
  _nr_of_updates = 0;
}

//----------------------------------
// Deletion of a collector
//----------------------------------
CNodePairCountCollector::
~CNodePairCountCollector()
{
  // Go through the first map, and then the second map, and delete all the ranges
  for (auto &np2r : _node_pair_to_range_map) delete np2r.second;
  for (auto &n2r : _node_to_range_map) delete n2r.second;
}

void
CNodePairCountCollector::
GetECFGNodePairsToConsiderBasedOnECFGGraph(std::set<std::pair<CECFGNode *, CECFGNode *> > *node_pairs_to_consider)
{
  // Loop through all the nodes
  set<CECFGNode *>::iterator node1;
  FORALL(node1, _nodes_to_consider) {
    // Maybe skip the node if it is not a basic block being node
    if(_collect_only_basic_block_start_nodes && !(*node1)->IsBeginOfBasicBlock()) continue;
    // Get the following node in the set
    set<CECFGNode *>::iterator node2 = node1;
    for(node2++; node2 != _nodes_to_consider.end(); node2++) {
      // Maybe skip the node if it is not a basic block being node
      if(_collect_only_basic_block_start_nodes && !(*node2)->IsBeginOfBasicBlock()) continue;
      // Check if the node exists among the node pairs that should
      // be considered. If not, skip keeping track of this node pair.
      if((_has_may_but_not_must_be_taken_node_pairs == true) &&
         _may_but_not_must_be_taken_node_pairs.find(MakeNodePair(*node1, *node2)) ==
         _may_but_not_must_be_taken_node_pairs.end()) 
	continue;
      // Else, insert the node pairs in the node_pairs_to_consider set 
      node_pairs_to_consider->insert(MakeNodePair(*node1,*node2));
    }
  }
}

void
CNodePairCountCollector::
GetCFGNodePairsToConsider(std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> > *cfg_node_pairs_to_consider)
{
  // Loop through all the nodes
  set<CECFGNode *>::iterator node1;
  FORALL(node1, _nodes_to_consider) {
    // Maybe skip the node if it is not a basic block being node
    if(_collect_only_basic_block_start_nodes && !(*node1)->IsBeginOfBasicBlock()) continue;
    // Get the following node in the set
    set<CECFGNode *>::iterator node2 = node1;
    for(node2++; node2 != _nodes_to_consider.end(); node2++) {
      // Maybe skip the node if it is not a basic block being node
      if(_collect_only_basic_block_start_nodes && !(*node2)->IsBeginOfBasicBlock()) continue;
      // Check if the node exists among the node pairs that should
      // be considered. If not, skip keeping track of this node pair.
      if((_has_may_but_not_must_be_taken_node_pairs == true) &&
         _may_but_not_must_be_taken_node_pairs.find(MakeNodePair(*node1, *node2)) ==
         _may_but_not_must_be_taken_node_pairs.end()) 
	continue;
      // Skip making pairs including the same cfg node twice 
      if((*node1)->GetFlowGraphNode() == (*node2)->GetFlowGraphNode()) 
	continue;
      // Else, insert the node pairs in the node_pairs_to_consider set 
      cfg_node_pairs_to_consider->insert(MakeNodePair((*node1)->GetFlowGraphNode(),(*node2)->GetFlowGraphNode()));
    }
  }
}

void
CNodePairCountCollector::
GetECFGNodePairsToConsiderBasedOnCFGNodePairs(std::set<std::pair<CECFGNode *, CECFGNode *> > *ecfg_node_pairs_to_consider)
{
  // Get the CFG nodes to consider
  std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> > cfg_node_pairs_to_consider;
  GetCFGNodePairsToConsider(&cfg_node_pairs_to_consider);

  // Loop through all the ecfg nodes
  set<CECFGNode *>::iterator node1;
  FORALL(node1, _nodes_to_consider) {
    // Get the following node in the set
    set<CECFGNode *>::iterator node2 = node1;
    for(node2++; node2 != _nodes_to_consider.end(); node2++) {
      // Skip making pairs including the same cfg node twice 
      if((*node1)->GetFlowGraphNode() == (*node2)->GetFlowGraphNode()) 
	continue;
      // If the corresponding CFG node pair exists in cfg node pairs
      // to conider we should consider the corresponding ecfg node pair
      if(cfg_node_pairs_to_consider.find(MakeNodePair((*node1)->GetFlowGraphNode(), (*node2)->GetFlowGraphNode())) !=
	 cfg_node_pairs_to_consider.end()) {
	ecfg_node_pairs_to_consider->insert(MakeNodePair(*node1, *node2));
      }
    }
  }
}

//----------------------------------
// To update the collector with a new recording.
//---------------------------------
void
CNodePairCountCollector::
Update(t_node_to_range_map * node_to_range_recording)
{
  // Increase the nr of updates
  _nr_of_updates++;

  // Make sure that we have a node pair to consider
  if(_nr_of_updates == 1) {
    // Set nodes to consider only once
    SetNodesToConsider(&_nodes_to_consider);
    // Get the ECFG node pairs to consider based on CFG node pairs 
    GetECFGNodePairsToConsiderBasedOnCFGNodePairs(&_ecfg_node_pairs_to_consider_based_on_cfg_node_pairs);
  }

  // Go through all node pairs to consider
  std::set<std::pair<CECFGNode *, CECFGNode *> >::iterator np;
  FORALL(np, _ecfg_node_pairs_to_consider_based_on_cfg_node_pairs) {

    // Get the first node in the pair
    CECFGNode * node1 = (*np).first;
    // To hold the min and max value for node1
    int64_t L1 = 0;
    int64_t U1 = 0;
    // Check if the node exists in the recording
    if(node_to_range_recording->find(node1) != node_to_range_recording->end()) {
      // Replace the values
      CIntegerRange* range1 = (*node_to_range_recording)[node1];
      L1 = range1->L();
      U1 = range1->U();
    }

    // Get the second node in the pair
    CECFGNode * node2 = (*np).second;
    // To hold the min and max value for node2
    int64_t L2 = 0;
    int64_t U2 = 0;
    // Check if the node exists in the recording
    if(node_to_range_recording->find(node2) != node_to_range_recording->end()) {
      // Replace the values
      CIntegerRange* range2 = (*node_to_range_recording)[node2];
      L2 = range2->L();
      U2 = range2->U();
    }
    
    // Create a new range consisting of only L1+L2..U1+U2
    CIntegerRange* range = new CIntegerRange(L1+L2,U1+U2);
    
    // Create a node pair
    std::pair<CECFGNode *, CECFGNode *> node_pair = MakeNodePair(node1, node2);
    
    // Check if there already existed a range for the given node pair
    if(_node_pair_to_range_map.find(node_pair) == _node_pair_to_range_map.end()) {
      // Nope, associate the range with the given node pair
      _node_pair_to_range_map[node_pair] = range;
    }
    else {
      // Yes, create a new range by merging old range and recorded range
      CIntegerRange * old_range = _node_pair_to_range_map[node_pair];
      CIntegerRange * new_range = range->Merge(old_range);
      delete range;
      delete old_range;
      _node_pair_to_range_map[node_pair] = new_range;
    }
  }

  { 
     // Update node to range mapping
     std::set<CECFGNode *>::iterator node;
     FORALL(node, _nodes_to_consider) {
        // To hold the min and max value for node
        int64_t L = 0;
        int64_t U = 0;
        // Check if the node exists in the recording
        if(node_to_range_recording->find(*node) != node_to_range_recording->end()) {
           // Replace the values
           CIntegerRange* rec_range = (*node_to_range_recording)[*node];
           L = rec_range->L();
           U = rec_range->U();
        }
        // Create a new range consisting of only L..U
        CIntegerRange* range = new CIntegerRange(L,U);
        // Check if there already existed a range for the given node 
        if(_node_to_range_map.find(*node) == _node_to_range_map.end()) {
           // Nope, associate the range with the given node 
           _node_to_range_map[*node] = range;
        }
        else {
           // Yes, create a new range by merging old range and recorded range
           CIntegerRange * old_range = _node_to_range_map[*node];
           CIntegerRange * new_range = range->Merge(old_range);
           delete range;
           delete old_range;
           _node_to_range_map[*node] = new_range;
        }
     }
  }
}

// -------------------------------------------------------
// Help function for always making node pairs the same way
// -------------------------------------------------------
std::pair<CECFGNode *, CECFGNode *>
CNodePairCountCollector::
MakeNodePair(CECFGNode * node1, CECFGNode * node2)
{
  assert(node1 != node2);
  if(node1 < node2) 
    return std::make_pair(node1, node2);
  else
    return std::make_pair(node2, node1);
}

// -------------------------------------------------------
// Help function for always making node pairs the same way
// -------------------------------------------------------
std::pair<CFlowGraphNode *, CFlowGraphNode *>
CNodePairCountCollector::
MakeNodePair(CFlowGraphNode * node1, CFlowGraphNode * node2)
{
  assert(node1 != node2);
  if(node1 < node2) 
    return std::make_pair(node1, node2);
  else
    return std::make_pair(node2, node1);
}

// -------------------------------------------------------
// The report function needs to be implemented
// -------------------------------------------------------
void
CNodePairCountCollector::
Report(CRecorder * rec)
{
  CNodeCountRecorder * nc_rec = dynamic_cast<CNodeCountRecorder *>(rec);
  nc_rec->ReportToCollector(this);
}

// ---------------------------------
// To generate flow facts
// ---------------------------------
int
CNodePairCountCollector::
GenerateFlowFacts(void)
{
  // We only want to generate flow facts for the pairs on nodes in the ecfg 
  if(_generate_lower_bound_ffs || _generate_upper_bound_ffs) {
     GetECFGNodePairsToConsiderBasedOnECFGGraph(&_ecfg_node_pairs_to_consider_based_on_ecfg_graph);
  }

  int nr_of_added_flow_facts = 0;
  if(_generate_lower_bound_ffs) {
    CFlowFact::t_flowfacttype ff_type = GetLowerFlowFactType();
    nr_of_added_flow_facts += AddMinNodePairCountFlowFactsToScope(ff_type);
  }
  if(_generate_upper_bound_ffs) {
    CFlowFact::t_flowfacttype ff_type = GetUpperFlowFactType();
    nr_of_added_flow_facts += AddMaxNodePairCountFlowFactsToScope(ff_type);
  }
  return nr_of_added_flow_facts;
}


// ---------------------------------
// To generate context sensitive valid at entry of flow facts 
// ---------------------------------
int 
CNodePairCountCollector::
GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
 // To avoid unneccessary work
  if(!_generate_lower_bound_ffs && !_generate_upper_bound_ffs) return 0;

  // Create a mapping inbetween CFG nodes and ranges
  std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange * > * cfg_node_pair_to_range_map
    = new std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange * >; 

  // Go through all collectors and derive the cfg node pairs that has
  // to be considered by all of them, i.e. their intersection. This
  // may differ between the collectors if the belong to different
  // scopes but the same CFG, since one of the CFGs may be contained
  // in a loop, but not the other one. If one has this pair but the
  // other does not we cannot generate a ff for it, and thus the node
  // pair should no be included in the map.

  // Go through all collectors (they must be node pair count collectors) 
  bool map_created = false;
  for(std::set<CCollector *>::iterator c = collectors->begin(); c != collectors->end(); ++c) {
    CNodePairCountCollector * npc_collector = dynamic_cast<CNodePairCountCollector *>(*c);
    assert(npc_collector);
    if(npc_collector->NrOfReports() == 0) continue;

    // Check if it was the first collector in the set
    if(!map_created) {
      // Derive a CFG node pair to range map for the given collector
      npc_collector->DeriveCFGNodePairToRangeMap(cfg_node_pair_to_range_map);
      map_created = true;
    }
    else {
      // Derive a temporary map for the given collector
      std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange * > * temp_cfg_node_pair_to_range_map
        = new std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange * >;
      npc_collector->DeriveCFGNodePairToRangeMap(temp_cfg_node_pair_to_range_map);
      // Merge the old and temporary mappings
      std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange * > * new_cfg_node_pair_to_range_map
        = new std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange * >;
      for(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange * >::iterator np2r = cfg_node_pair_to_range_map->begin();
          np2r != cfg_node_pair_to_range_map->end(); ++np2r) {
        // Get the node pair and the range 
        std::pair<CFlowGraphNode *, CFlowGraphNode *> cfg_node_pair = (*np2r).first;
        CIntegerRange * range = (*np2r).second;
        // Check if the new collector has the same node pair
        std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange * >::iterator temp_np2r;
        temp_np2r = temp_cfg_node_pair_to_range_map->find(cfg_node_pair);
        if(temp_np2r != temp_cfg_node_pair_to_range_map->end()) {
          // The pair and the range existed in the temp map
          CIntegerRange * temp_range = (*temp_np2r).second;
          CIntegerRange * new_range = temp_range->Merge(range);
          (*new_cfg_node_pair_to_range_map)[cfg_node_pair] = new_range;
        }
      }
      // Delete temporary ranges
      for(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange * >::iterator cnp2r = cfg_node_pair_to_range_map->begin();
          cnp2r != cfg_node_pair_to_range_map->end(); ++cnp2r) {
        delete (*cnp2r).second;
      }
      delete cfg_node_pair_to_range_map;

      for(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange * >::iterator cnp2r = temp_cfg_node_pair_to_range_map->begin();
          cnp2r != temp_cfg_node_pair_to_range_map->end(); ++cnp2r) {
        delete (*cnp2r).second;
      }
      delete temp_cfg_node_pair_to_range_map;

      // Reassign the node pair to range map
      cfg_node_pair_to_range_map = new_cfg_node_pair_to_range_map;
    }    
  }

  // Generate the resulting flow facts by calling the right subordinate collector
  int nr_of_flow_facts = 0;

  if(map_created) {
    CCollector * c = *(collectors->begin());
    assert(c);
    CNodePairCountCollector * npc_collector = dynamic_cast<CNodePairCountCollector *>(c);
    assert(npc_collector);
    nr_of_flow_facts = npc_collector->GenerateContextSensitiveValidAtEntryOfFlowFacts(cfg_node_pair_to_range_map, call_string, 
                                                                                      valid_at_entry_of, ffs);
    
    // Delete temporary ranges
    for(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange * >::iterator cnp2r = cfg_node_pair_to_range_map->begin();
        cnp2r != cfg_node_pair_to_range_map->end(); ++cnp2r) {
      delete (*cnp2r).second;
    }
    delete cfg_node_pair_to_range_map;
  }

  // Return the number of generate flow facts
  return nr_of_flow_facts;
}

// ---------------------------------
// To generate context sensitive valid at entrty flow facts based on booleans
// ---------------------------------
int 
CNodePairCountCollector::
GenerateContextSensitiveValidAtEntryOfFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_node_pair_to_range_map,
                                                std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  int nr_of_added_flow_facts = 0;
  if(_generate_lower_bound_ffs) {
    CFlowFact::t_flowfacttype ff_type = GetLowerFlowFactType();
    nr_of_added_flow_facts += GenerateContextSensitiveValidAtEntryOfMinFlowFacts(cfg_node_pair_to_range_map, call_string, 
                                                                                 valid_at_entry_of, ff_type, ffs);
  }
  if(_generate_upper_bound_ffs) {
    CFlowFact::t_flowfacttype ff_type = GetUpperFlowFactType();
    nr_of_added_flow_facts += GenerateContextSensitiveValidAtEntryOfMaxFlowFacts(cfg_node_pair_to_range_map, call_string, 
                                                                                 valid_at_entry_of, ff_type, ffs);
  }
  return nr_of_added_flow_facts;
}


// ---------------------------------
// Help function used to generate upper bounds context sensitive 
// valid at entry flow facts. Called by sub classes.
// ---------------------------------
int
CNodePairCountCollector::
GenerateContextSensitiveValidAtEntryOfMaxFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_node_pair_to_range_map,
                                                   std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                   std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                   CFlowFact::t_flowfacttype ff_type,
                                                   std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;

  // Loop through node pair to range mappings 
  std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *>::iterator np2r;
  FORALL(np2r, (*cfg_node_pair_to_range_map))
    {
      // Get the node pair and the range
      CFlowGraphNode * node1 = (*np2r).first.first;
      CFlowGraphNode * node2 = (*np2r).first.second;
      CIntegerRange* range = (*np2r).second;

      // Get the range and min and max values of the node
      int64_t max_count = range->U();
      assert(range->L() <= max_count);

      // Create the bb_name1 + bb_name2 =< count expression
      CExpressionFlowGraphNode *expr_node1 = new CExpressionFlowGraphNode(node1);
      CExpressionFlowGraphNode *expr_node2 = new CExpressionFlowGraphNode(node2);
      CExpressionBin *expr_plus = new CExpressionBin(expr_node1, BINOP_ADD, expr_node2);
      CExpressionInt *max_eint = new CExpressionInt((int)max_count);
      CConstraint *constr = new CConstraint(expr_plus, RELOP_LTEQ, max_eint);
      // Create the [] collector
      CFFCollector * coll = new CFFCollector(TOTAL);
      // Create the context senstive flow fact
      CContextSensitiveValidAtEntryOfFlowFact * ff = 
        new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, coll, constr, ff_type);

      // Add the flow fact to the vector 
      ffs->push_back(ff);

      // Remember that we have added a flow fact
      nr_of_added_flow_facts++;

    } // end loop through all mappings

  // Return the number of flow facts added
  return nr_of_added_flow_facts;
}

// ---------------------------------
// Help function used to generate upper bounds context sensitive 
// valid at entry flow facts. Called by sub classes.
// ---------------------------------
int 
CNodePairCountCollector::
GenerateContextSensitiveValidAtEntryOfMinFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_node_pair_to_range_map,
                                                   std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                   std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                   CFlowFact::t_flowfacttype ff_type,
                                                   std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;

  // Loop through node pair to range mappings 
  std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *>::iterator np2r;
  FORALL(np2r, (*cfg_node_pair_to_range_map))
    {
      // Get the node pair and the range
      CFlowGraphNode * node1 = (*np2r).first.first;
      CFlowGraphNode * node2 = (*np2r).first.second;
      CIntegerRange* range = (*np2r).second;

      // Get the range and min and max values of the node
      int64_t min_count = range->L();
      assert(min_count <= range->U());

      // Create the bb_name1 + bb_name2 >= count expression
      CExpressionFlowGraphNode *expr_node1 = new CExpressionFlowGraphNode(node1);
      CExpressionFlowGraphNode *expr_node2 = new CExpressionFlowGraphNode(node2);
      CExpressionBin *expr_plus = new CExpressionBin(expr_node1, BINOP_ADD, expr_node2);
      CExpressionInt *min_eint = new CExpressionInt((int)min_count);
      CConstraint * constr = new CConstraint(expr_plus, RELOP_GTEQ, min_eint);
      // Create the [] collector
      CFFCollector * coll = new CFFCollector(TOTAL);
      // Create the context senstive flow fact
      CContextSensitiveValidAtEntryOfFlowFact * ff = 
        new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, coll, constr, ff_type);

      // Add the flow fact to the vector 
      ffs->push_back(ff);

      // Remember that we have added a flow fact
      nr_of_added_flow_facts++;

    } // end loop through all mappings

  // Return the number of flow facts added
  return nr_of_added_flow_facts;
}
  

// ---------------------------------
// Help function for deriving a cfg node pair to range mapping for a
// collector.  We need to do this in a separate function since
// several ecfg nodes maye correspond to the same cfg node. 
// ---------------------------------
void
CNodePairCountCollector::
DeriveCFGNodePairToRangeMap(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_node_pair_to_range_map)
{
  {
    // Derive an initial CFGNode,CFGNode -> Range mapping

    // Go through all node pairs to consider
    std::set<std::pair<CECFGNode *, CECFGNode *> >::iterator np;
    FORALL(np, _ecfg_node_pairs_to_consider_based_on_cfg_node_pairs) {
      
      // Get the first and second node in the pair
      CECFGNode * ecfg_node1 = (*np).first;
      CECFGNode * ecfg_node2 = (*np).second;
      
      // Get the corresponding cfg nodes
      CFlowGraphNode * cfg_node1 = ecfg_node1->GetFlowGraphNode();
      CFlowGraphNode * cfg_node2 = ecfg_node2->GetFlowGraphNode();
      
      // Skip ecfg node pairs that both refer to the same node
      if(cfg_node1 == cfg_node2) continue;
      
      // Get the range associated with the ecfg node pair
      CIntegerRange * range = _node_pair_to_range_map[MakeNodePair(ecfg_node1, ecfg_node2)];
      assert(range);
            
      // Create a node pair for the cfg nodes
      std::pair<CFlowGraphNode *, CFlowGraphNode *> cfg_node_pair = MakeNodePair(cfg_node1, cfg_node2);
      // Check if the cfg node pair already have got a range assigned
      // to it. Might happen if several ecfg nodes have same cfg node.
      if(cfg_node_pair_to_range_map->find(cfg_node_pair) == cfg_node_pair_to_range_map->end()) {
          // Nope, just copy the old range
        (*cfg_node_pair_to_range_map)[cfg_node_pair] = range->Copy();
        }
        else {
            // Yes, make new range as [max(L1,L2)..U1+U2]
          CIntegerRange * old_range = (*cfg_node_pair_to_range_map)[cfg_node_pair];
            // The new L is max of the two L's
          int64_t new_L = old_range->L();
          if(range->L() > old_range->L())
            new_L = range->L();
            // The new U is the sum of the two U's
          int64_t new_U = old_range->U() + range->U();
            // Create the new range, set it, and the delete the old one
          CIntegerRange * new_range = new CIntegerRange(new_L, new_U);
          (*cfg_node_pair_to_range_map)[cfg_node_pair] = new_range;
          delete old_range;
        }
      }  
    }

  std::map<CFlowGraphNode *, CIntegerRange *> cfg_node_to_range;
  {
    // Calculate the sum of occurrences of each cfg node and store
    // result in cfg to range mapping
    std::set<CECFGNode *> processed_ecfg_nodes;

    std::set<std::pair<CECFGNode *, CECFGNode *> >::iterator np;
    FORALL(np, _ecfg_node_pairs_to_consider_based_on_cfg_node_pairs) {
      
      // Get the first and second node in the pair
      CECFGNode * ecfg_node1 = (*np).first;
      CECFGNode * ecfg_node2 = (*np).second;
      
      // Check if the range of the ecfg_node1 already has been added
      if(processed_ecfg_nodes.find(ecfg_node1) == processed_ecfg_nodes.end()) {
	// Nope, We should add the nodes range to the cfg node range
	CFlowGraphNode * cfg_node1 = ecfg_node1->GetFlowGraphNode(); 
	CIntegerRange * range1 = _node_to_range_map[ecfg_node1];
	if(range1) {
	  // Check if the cfg node already has a range
	  if(cfg_node_to_range.find(cfg_node1) == cfg_node_to_range.end()) {
	    // Nope, just copy the range
	    cfg_node_to_range[cfg_node1] = range1->Copy();	    
	  }
	  else {
	    // Yes, summarize the old and new range, and update mapping.
	    CIntegerRange * old_range1 = cfg_node_to_range[cfg_node1];
	    CIntegerRange * new_range1 = new CIntegerRange(old_range1->L() + range1->L(), 
							   old_range1->U() + range1->U());
	    cfg_node_to_range[cfg_node1] = new_range1;
	    delete old_range1;
	  }
	}
	// Remember that we have added the range for the ecfg node
	processed_ecfg_nodes.insert(ecfg_node1);
      }

      // Check if the range of the ecfg_node2 already has been added
      if(processed_ecfg_nodes.find(ecfg_node2) == processed_ecfg_nodes.end()) {
	// Nope, We should add the nodes range to the cfg node range
	CFlowGraphNode * cfg_node2 = ecfg_node2->GetFlowGraphNode(); 
	CIntegerRange * range2 = _node_to_range_map[ecfg_node2];
	if(range2) {
	  // Check if the cfg node already has a range
	  if(cfg_node_to_range.find(cfg_node2) == cfg_node_to_range.end()) {
	    // Nope, just copy the range
	    cfg_node_to_range[cfg_node2] = range2->Copy();	    
	  }
	  else {
	    // Yes, summarize the old and new range, and update mapping.
	    CIntegerRange * old_range2 = cfg_node_to_range[cfg_node2];
	    CIntegerRange * new_range2 = new CIntegerRange(old_range2->L() + range2->L(), 
							   old_range2->U() + range2->U());
	    cfg_node_to_range[cfg_node2] = new_range2;
	    delete old_range2;
	  }
	}
	// Remember that we have added the range for the ecfg node
	processed_ecfg_nodes.insert(ecfg_node2);
      }
    }
  }


  { // Extra tightening. We use cfg_node_to_range to in some cases
    // derive smaller ranges for air of cfg nodes
    std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *>::iterator np2r;
    FORALL(np2r, (*cfg_node_pair_to_range_map)) {

      // Get the node pair and the range deroived for the pair
      CFlowGraphNode * node1 = (*np2r).first.first;
      CFlowGraphNode * node2 = (*np2r).first.second;
      CIntegerRange * np_range = (*np2r).second;

      // Get the ranges derived for the individual nodes
      CIntegerRange * range1 = cfg_node_to_range[node1];
      CIntegerRange * range2 = cfg_node_to_range[node2];
      assert(range1);
      assert(range2);

      // Derive the intersection range of range1+range2 and np_range
      bool tigther_range = false;
      int64_t new_L = np_range->L();
      if(np_range->L() < range1->L() + range2->L()) {
        new_L = range1->L() + range2->L();
        tigther_range = true;
      }
      int64_t new_U = np_range->U();
      if(np_range->U() > range1->U() + range2->U()) {
        new_U = range1->U() + range2->U();
        tigther_range = true;
      }
      // Check if we should change the range fo the pair
      if(tigther_range) {
        (*np2r).second = new CIntegerRange(new_L, new_U);
        delete np_range;
      }
    }
  }

  {
    // Delete temporary ranges created for the cfg node to range map
    std::map<CFlowGraphNode *, CIntegerRange * >::iterator n2r; 
    FORALL(n2r, cfg_node_to_range) {
      // Delete the range
      CIntegerRange* range = (*n2r).second;
      if(range) delete range;
    }
  }

  // Return the cfg_node_pair_to_range mapping
}

//---------------------------------
// For printing the collector
//---------------------------------
void
CNodePairCountCollector::
Print(ostream * o)
{
  (*o) << "type: " << Type() << endl;
  (*o) << "scope: " << _scope->Name() << endl;

  // Go through all node pairs to consider
  std::map<std::pair<CECFGNode *, CECFGNode *>, CIntegerRange * >::iterator np2r;
  FORALL(np2r, _node_pair_to_range_map) {
    
    CECFGNode * node1 = (*np2r).first.first;
    CECFGNode * node2 = (*np2r).first.second;
    CIntegerRange* range = (*np2r).second;

    // Print the node pair
    (*o) << "  " << (*node1) << "," << (*node2) << " ";
    // Print the range
    (*o) << (*range) << endl;
  }
  (*o) << endl;
}

//---------------------------------
// Alternative printing function
//---------------------------------
ostream &operator << (ostream &o, CNodePairCountCollector &a)
{
  a.Print(&o);
  return o;
}

// // ---------------------------------
// // To get the nodes to consider
// // ---------------------------------
// set<CECFGNode *> *
// CNodePairCountCollector::
// NodesToConsider(void)
// {
//   // Set nodes to consider (implemented by subclasses)
//   if(_nodes_to_consider.size() == 0)
//     SetNodesToConsider(&_nodes_to_consider);
//   return &_nodes_to_consider;
// }


//----------------------------------
// Create flow facts from the collector and add to scope
//---------------------------------
int
CNodePairCountCollector::
AddMaxNodePairCountFlowFactsToScope(CFlowFact::t_flowfacttype fftype)
{
  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;

  // Go through all node pairs to consider
  std::set<std::pair<CECFGNode *, CECFGNode *> >::iterator np;
  FORALL(np, _ecfg_node_pairs_to_consider_based_on_ecfg_graph) {

    // Get the nodes 
    CECFGNode * node1 = (*np).first;
    CECFGNode * node2 = (*np).second;

    // Get the range
    CIntegerRange* range = _node_pair_to_range_map[*np];
    if(!range) continue;

    int64_t max_count = range->U();
          
    // Create the bb_name + bb_name =< count expression
    CExpressionECFGNode *expr_node1 = new CExpressionECFGNode(node1);
    CExpressionECFGNode *expr_node2 = new CExpressionECFGNode(node2);
    CExpressionBin *expr_plus = new CExpressionBin(expr_node1, BINOP_ADD, expr_node2);
    CExpressionInt *max_eint = new CExpressionInt((int)max_count);
    CConstraint lteq_constraint(expr_plus, RELOP_LTEQ, max_eint);
    // Create the [] collector
    CFFCollector max_c(TOTAL);
    // Create the flow fact
    CFlowFact max_flow_fact(_scope, fftype, max_c, lteq_constraint);
    // Add the flow fact to the scope
    _scope->AddFlowFact(max_flow_fact);
    // Remember that we have added a flow fact
    nr_of_added_flow_facts++;
    
  } // end loop through all node pairs 

  // Return the number of flow facts added
  return nr_of_added_flow_facts;
}

//----------------------------------
// Create flow facts from the collector and add to scope
//---------------------------------
int
CNodePairCountCollector::
AddMinNodePairCountFlowFactsToScope(CFlowFact::t_flowfacttype fftype)
{
  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;

  // Go through all node pairs to consider
  std::set<std::pair<CECFGNode *, CECFGNode *> >::iterator np;
  FORALL(np, _ecfg_node_pairs_to_consider_based_on_ecfg_graph) {

    // Get the nodes 
    CECFGNode * node1 = (*np).first;
    CECFGNode * node2 = (*np).second;

    // Get the range
    CIntegerRange* range = _node_pair_to_range_map[*np];
    if(!range) continue;

    int64_t min_count = range->L();
    
    // Create the bb_name + bb_name =< count expression
    CExpressionECFGNode *expr_node1 = new CExpressionECFGNode(node1);
    CExpressionECFGNode *expr_node2 = new CExpressionECFGNode(node2);
    CExpressionBin *expr_plus = new CExpressionBin(expr_node1, BINOP_ADD, expr_node2);
    CExpressionInt *min_eint = new CExpressionInt((int)min_count);
    CConstraint gteq_constraint(expr_plus, RELOP_GTEQ, min_eint);
    // Create the [] collector
    CFFCollector max_c(TOTAL);
    // Create the flow fact
    CFlowFact max_flow_fact(_scope, fftype, max_c, gteq_constraint);
    // Add the flow fact to the scope
    _scope->AddFlowFact(max_flow_fact);
    // Remember that we have added a flow fact
    nr_of_added_flow_facts++;
    
  } // end loop through all node pairs 
  
  // Return the number of flow facts added
  return nr_of_added_flow_facts;
}

// -------------------------------------------------------
// To derive what node pairs that we should keep track of (for the whole scope graph)
// -------------------------------------------------------

// Will create and run may and must be taken before data flow analysis.
// The number of node pairs that fulfil the requirments are returned
// in the argument set.
void 
CNodePairCountCollector::
DeriveMayButNotMustBeTakenNodePairs(CScopeGraph * sg, bool collect_only_basic_block_start_nodes,
                                    std::set<std::pair<CECFGNode *, CECFGNode *> > * node_pairs_to_consider)
{
  // To hold all nodes that should be considered 
  std::set<CECFGNode*> nodes;

  // To hold all basic block begin nodes and their successor node
  // basic block begin nodes
  std::set<std::pair<CECFGNode *, CECFGNode *> > node_to_succs;
      
  { // Derive the nodes and the node to succ nodes

    // Check if only basic block start nodes should be considered
    if(collect_only_basic_block_start_nodes) {
      
      // Derive the nodes that start basic blocks
      sg->ECFGNodesThatBeginBasicBlocks(&nodes);
      
      // Create pairs from bb begin nodes to successor bb begin nodes
      for(std::set<CECFGNode*>::iterator bb_begin_node = nodes.begin();
          bb_begin_node != nodes.end(); ++bb_begin_node) {
        // Get the end node of the basic block
        CECFGNode * bb_end_node = (*bb_begin_node)->GetEndNodeOfNodesBasicBlock();
        // Get the successor of the end node
        for(CECFGNode::succ_iterator succ_it = bb_end_node->SuccBegin();
            succ_it != bb_end_node->SuccEnd(); ++succ_it) {
          CECFGNode * succ_node = (*succ_it).node;
          assert(succ_node->IsBeginOfBasicBlock());
          node_to_succs.insert(std::make_pair(*bb_begin_node, succ_node));
        }
      }
    }
    else {
        
      // Derive all the nodes in the scope graph
      sg->ECFGNodes(&nodes);
      
      // Create pairs from nodes to successor nodes
      for(std::set<CECFGNode*>::iterator node = nodes.begin();
          node != nodes.end(); ++node) {
        // Get the successor of the node
        for(CECFGNode::succ_iterator succ_it = (*node)->SuccBegin();
            succ_it != (*node)->SuccEnd(); ++succ_it) {
          CECFGNode * succ_node = (*succ_it).node;
          node_to_succs.insert(std::make_pair(*node, succ_node));
        }
      }
    }
  }

  CECFGNode * start_node = sg->RootScope()->Header();

  // To hold connection between nodes and their states
  std::set<std::pair<CECFGNode *, CBitVectorWithBot *> > node_to_may_input_state;
  std::set<std::pair<CECFGNode *, CBitVectorWithBot *> > node_to_may_output_state;
  std::set<std::pair<CECFGNode *, CBitVectorWithBot *> > node_to_must_input_state;
  std::set<std::pair<CECFGNode *, CBitVectorWithBot *> > node_to_must_output_state;
  std::map<CECFGNode *, unsigned int> node_to_index;
  int nr_of_elements = (int)nodes.size();

  { // Create input and output states for all the nodes    
    unsigned int i = 0;
    for(std::set<CECFGNode *>::iterator node = nodes.begin();
        node != nodes.end(); i++, ++node) {
      if(*node == start_node) {
        node_to_must_input_state.insert(std::make_pair(*node, new CBitVectorWithBot(nr_of_elements, false)));
        node_to_may_input_state.insert(std::make_pair(*node, new CBitVectorWithBot(nr_of_elements, false)));
      }
      else {
        node_to_must_input_state.insert(std::make_pair(*node, new CBitVectorWithBot(nr_of_elements, true)));
        node_to_may_input_state.insert(std::make_pair(*node, new CBitVectorWithBot(nr_of_elements, true)));
      }
      node_to_must_output_state.insert(std::make_pair(*node, new CBitVectorWithBot(nr_of_elements, true)));
      node_to_may_output_state.insert(std::make_pair(*node, new CBitVectorWithBot(nr_of_elements, true)));
      node_to_index[*node] = i;
    }
  }

  // Create the two data flow analysis objects
  MayBeTakenBeforeDataFlowAnalysis<CECFGNode> 
    may_be_taken_before(&node_to_may_input_state, &node_to_may_output_state, &node_to_succs, &node_to_index);
  MustBeTakenBeforeDataFlowAnalysis<CECFGNode> 
    must_be_taken_before(&node_to_must_input_state, &node_to_must_output_state, &node_to_succs, &node_to_index);
  
  { // Run the two data flow analyses
    std::list<TakenBeforeDataFlowAnalysis<CECFGNode>::FIXPOINT_PASS> run_list;
    run_list.push_back(TakenBeforeDataFlowAnalysis<CECFGNode>::NORMAL);
    std::set<CECFGNode *> start_nodes;
    start_nodes.insert(start_node);

    // We are using worklist and not optimal node ordering since it seems as if we are 
    // losing time by creating the optimal node ordering
    may_be_taken_before.RunUsingWorkList(&run_list, TakenBeforeDataFlowAnalysis<CECFGNode>::FORWARD, &start_nodes);
    must_be_taken_before.RunUsingWorkList(&run_list, TakenBeforeDataFlowAnalysis<CECFGNode>::FORWARD, &start_nodes);
  }

  // To hold the indexes of the nodes that must be taken during any
  // execution of the graph
  CBitVector nodes_that_must_be_taken(nr_of_elements);

  { // Derive the nodes that must be taken during each execution of
    // the graph
    bool first_update = true;
    for(std::set<CECFGNode*>::iterator node = nodes.begin();
        node != nodes.end(); ++node) {
      // Only use the nodes with no successors
      if(collect_only_basic_block_start_nodes) {
        if((*node)->GetEndNodeOfNodesBasicBlock()->SuccSize() > 0) 
          continue;
      }
      else { 
        if((*node)->SuccSize() > 0) 
          continue;
      }
      // Get the must vector of the node
      const CBitVector * must_vector = must_be_taken_before.GetOutputState(*node);
      // Treat first update especially
      if(first_update) {
        nodes_that_must_be_taken += must_vector;
        first_update = false;
      }
      else {
        nodes_that_must_be_taken &= must_vector;
      }      
    }
  }

  { // Derive the node pairs to consider. 

    // Loop through all nodes twice to see if the node pair should be
    // added or not
    for(std::set<CECFGNode*>::iterator first_node = nodes.begin();
        first_node != nodes.end(); ++first_node) {

      // If the node must be taken during all executions it should not be included
      // in any pair
      unsigned int first_index = node_to_index[*first_node];
      if(nodes_that_must_be_taken.ElementExists(first_index)) continue;
      
      // Loop through all the nodes again
      for(std::set<CECFGNode*>::iterator second_node = nodes.begin();
          second_node != nodes.end(); ++second_node) {  
        
        // The same node cannot occur twice in a pair
        if(first_node == second_node) continue;
        
        // If the node must be taken during all executions it should not be included
        // in any pair
        unsigned int second_index = node_to_index[*second_node];
        if(nodes_that_must_be_taken.ElementExists(second_index)) continue;
        
        // If Y not in MUST(X) and Y in MAY(X) then we should record pair X,Y 
        if(!(must_be_taken_before.GetInputState(*first_node)->ElementExists(second_index)) &&
           may_be_taken_before.GetInputState(*first_node)->ElementExists(second_index)) {
          node_pairs_to_consider->insert(MakeNodePair(*first_node, *second_node));
        }
      }
    }
  }

  { // Print the result
    bool print_result=false;
    if(print_result) {

      // Print nodes that are always taken
      cout << "NODES THAT MUST ALWAYS BE TAKEN (FOR ALL EXECUTIONS)\n";
      for(std::set<CECFGNode*>::iterator n = nodes.begin(); n != nodes.end(); ++n) {
        unsigned int index = node_to_index[*n];
        if(nodes_that_must_be_taken.ElementExists(index))
          cout << "  node: " << **n << endl;
      }
      nodes_that_must_be_taken.PrintBinary(&std::cout);
      cout << endl;
      
      // For each node print its may be taken before nodes
      for(std::set<CECFGNode*>::iterator node = nodes.begin();
          node != nodes.end(); ++node) {
        cout << "NODE: " << **node << " HAS THE FOLLOWING MAY BE TAKEN BEFORE NODES: { ";
        const CBitVectorWithBot * bit_vector = may_be_taken_before.GetInputState(*node);
        for(std::set<CECFGNode*>::iterator n = nodes.begin(); n != nodes.end(); ++n) {
          unsigned int index = node_to_index[*n];
          if(bit_vector->ElementExists(index))
            cout << **n << " ";
        }
        cout << "}\n";
      }
      
      // For each node print its must be taken before nodes
      for(std::set<CECFGNode*>::iterator node = nodes.begin();
          node != nodes.end(); ++node) {
        cout << "NODE: " << **node << " HAS THE FOLLOWING MUST BE TAKEN BEFORE NODES: { ";
        const CBitVectorWithBot * bit_vector = must_be_taken_before.GetInputState(*node);
        for(std::set<CECFGNode*>::iterator n = nodes.begin(); n != nodes.end(); ++n) {
          unsigned int index = node_to_index[*n];
          if(bit_vector->ElementExists(index))
            cout << **n << " ";
        }
        cout << "}\n";
      }

      // Print the resulting pair to keep track of
      for(std::set<std::pair<CECFGNode *, CECFGNode *> >::iterator nn = node_pairs_to_consider->begin();
          nn != node_pairs_to_consider->end(); ++nn) {      
        cout << "NODE PAIR TO CONSIDER: " << *(*nn).first << ", " << *(*nn).second << endl;
      }
    } // end if print result
  }

  // Return, the node_pairs_to_consider has been updated
  return;
}



// -------------------------------------------------------
// To derive what nodes that must be taken eacxh program run (for the whole scope graph)
// -------------------------------------------------------

void 
CNodePairCountCollector::
DeriveMustBeTakenNodes(CScopeGraph * sg, bool collect_only_basic_block_start_nodes,
                       std::set<CECFGNode *> * arg_nodes_that_must_be_taken)
{
  // To hold all nodes that should be considered 
  std::set<CECFGNode*> nodes;

  // To hold all basic block begin nodes and their successor node
  // basic block begin nodes
  std::set<std::pair<CECFGNode *, CECFGNode *> > node_to_succs;
      
  { // Derive the nodes and the node to succ nodes

    // Check if only basic block start nodes should be considered
    if(collect_only_basic_block_start_nodes) {
      
      // Derive the nodes that start basic blocks
      sg->ECFGNodesThatBeginBasicBlocks(&nodes);
      
      // Create pairs from bb begin nodes to successor bb begin nodes
      for(std::set<CECFGNode*>::iterator bb_begin_node = nodes.begin();
          bb_begin_node != nodes.end(); ++bb_begin_node) {
        // Get the end node of the basic block
        CECFGNode * bb_end_node = (*bb_begin_node)->GetEndNodeOfNodesBasicBlock();
        // Get the successor of the end node
        for(CECFGNode::succ_iterator succ_it = bb_end_node->SuccBegin();
            succ_it != bb_end_node->SuccEnd(); ++succ_it) {
          CECFGNode * succ_node = (*succ_it).node;
          assert(succ_node->IsBeginOfBasicBlock());
          node_to_succs.insert(std::make_pair(*bb_begin_node, succ_node));
        }
      }
    }
    else {
        
      // Derive all the nodes in the scope graph
      sg->ECFGNodes(&nodes);
      
      // Create pairs from nodes to successor nodes
      for(std::set<CECFGNode*>::iterator node = nodes.begin();
          node != nodes.end(); ++node) {
        // Get the successor of the node
        for(CECFGNode::succ_iterator succ_it = (*node)->SuccBegin();
            succ_it != (*node)->SuccEnd(); ++succ_it) {
          CECFGNode * succ_node = (*succ_it).node;
          node_to_succs.insert(std::make_pair(*node, succ_node));
        }
      }
    }
  }

  CECFGNode * start_node = sg->RootScope()->Header();

  // To hold connection between nodes and their states
  std::set<std::pair<CECFGNode *, CBitVectorWithBot *> > node_to_must_input_state;
  std::set<std::pair<CECFGNode *, CBitVectorWithBot *> > node_to_must_output_state;
  std::map<CECFGNode *, unsigned int> node_to_index;
  int nr_of_elements = (int)nodes.size();

  { // Create input and output states for all the nodes    
    unsigned int i = 0;
    for(std::set<CECFGNode *>::iterator node = nodes.begin();
        node != nodes.end(); i++, ++node) {
      if(*node == start_node) {
        node_to_must_input_state.insert(std::make_pair(*node, new CBitVectorWithBot(nr_of_elements, false)));
      }
      else {
        node_to_must_input_state.insert(std::make_pair(*node, new CBitVectorWithBot(nr_of_elements, true)));
      }
      node_to_must_output_state.insert(std::make_pair(*node, new CBitVectorWithBot(nr_of_elements, true)));
      node_to_index[*node] = i;
    }
  }

  // Create the data flow analysis objects
  MustBeTakenBeforeDataFlowAnalysis<CECFGNode> 
    must_be_taken_before(&node_to_must_input_state, &node_to_must_output_state, &node_to_succs, &node_to_index);
  
  { // Run the data flow analysis
    std::list<TakenBeforeDataFlowAnalysis<CECFGNode>::FIXPOINT_PASS> run_list;
    run_list.push_back(TakenBeforeDataFlowAnalysis<CECFGNode>::NORMAL);
    std::set<CECFGNode *> start_nodes;
    start_nodes.insert(start_node);

    // We are using worklist and not optimal node ordering since it seems as if we are 
    // loosing time by creating the optimal node ordering
    must_be_taken_before.RunUsingWorkList(&run_list, TakenBeforeDataFlowAnalysis<CECFGNode>::FORWARD, &start_nodes);
  }

  // To hold the indexes of the nodes that must be taken during any
  // execution of the graph
  CBitVector nodes_that_must_be_taken(nr_of_elements);

  { // Derive the nodes that must be taken during each execution of
    // the graph
    bool first_update = true;
    for(std::set<CECFGNode*>::iterator node = nodes.begin();
        node != nodes.end(); ++node) {
      // Only use the nodes with no successors
      if(collect_only_basic_block_start_nodes) {
        if((*node)->GetEndNodeOfNodesBasicBlock()->SuccSize() > 0) 
          continue;
      }
      else { 
        if((*node)->SuccSize() > 0) 
          continue;
      }
      // Get the must vector of the node
      const CBitVector * must_vector = must_be_taken_before.GetOutputState(*node);
      // Treat first update especially
      if(first_update) {
        nodes_that_must_be_taken += must_vector;
        first_update = false;
      }
      else {
        nodes_that_must_be_taken &= must_vector;
      }      
    }
  }

  {
    // Derive the node set that mus be taken from the bit vector
    for(std::set<CECFGNode*>::iterator node = nodes.begin();
        node != nodes.end(); ++node) {
      
      // Get the node from the index
      unsigned int index = node_to_index[*node];
      if(nodes_that_must_be_taken.ElementExists(index)) {
        
        // Update the argument set
        arg_nodes_that_must_be_taken->insert(*node);
      }
    }
  }

  // Return, the nodes_that_must_be_taken has been updated
  return;
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodePairCountScopeCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CNodePairCountScopeCollector::
CNodePairCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                             bool generate_lower_bound_ffs, bool generate_upper_bound_ffs,
                             std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CNodePairCountCollector(scope, collect_only_basic_block_start_nodes, 
                            generate_lower_bound_ffs, generate_upper_bound_ffs,
                            may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

//----------------------------------
// To get the nodes to consider
//---------------------------------
void
CNodePairCountScopeCollector::
SetNodesToConsider(set<CECFGNode *> * nodes_to_consider)
{
  _scope->NodesInScopeExceptHeader(nodes_to_consider);
}

//--------------------------------------------------
// CMaxNodePairCountScopeCollector
//-------------------------------------------------
CMaxNodePairCountScopeCollector::
CMaxNodePairCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CNodePairCountScopeCollector(scope, collect_only_basic_block_start_nodes, false, true, may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

//--------------------------------------------------
// CMinNodePairCountScopeCollector
//-------------------------------------------------
CMinNodePairCountScopeCollector::
CMinNodePairCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CNodePairCountScopeCollector(scope, collect_only_basic_block_start_nodes, true, false, may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

//--------------------------------------------------
// CMinMaxNodePairCountScopeCollector
//-------------------------------------------------
CMinMaxNodePairCountScopeCollector::
CMinMaxNodePairCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                   std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CNodePairCountScopeCollector(scope, collect_only_basic_block_start_nodes, true, true, may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodePairCountScopeAndSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CNodePairCountScopeAndSubCollector::
CNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                   bool generate_lower_bound_ffs, bool generate_upper_bound_ffs,
                                   std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CNodePairCountCollector(scope, collect_only_basic_block_start_nodes, 
                            generate_lower_bound_ffs, generate_upper_bound_ffs, may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}


//----------------------------------
// To set the nodes to consider
//---------------------------------
void
CNodePairCountScopeAndSubCollector::
SetNodesToConsider(set<CECFGNode *> * nodes_to_consider)
{
 // Call the wanted function in the scope
  _scope->NodesInScopeExceptHeaderAndSubScopes(nodes_to_consider);
}

// ---------------------------------
// CMaxNodePairCountScopeAndSubCollector
//----------------------------------
CMaxNodePairCountScopeAndSubCollector::
CMaxNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes, 
                                      std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CNodePairCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, false, true, 
                                       may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

// ---------------------------------
// CMinNodePairCountScopeAndSubCollector
//----------------------------------
CMinNodePairCountScopeAndSubCollector::
CMinNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes, 
                                      std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CNodePairCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, true, false, 
                                       may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

// ---------------------------------
// CMinMaxNodePairCountScopeAndSubCollector
//----------------------------------
CMinMaxNodePairCountScopeAndSubCollector::
CMinMaxNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes, 
                                         std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CNodePairCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, true, true, 
                                       may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CNodePairCountScopeAndLoopSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CNodePairCountScopeAndLoopSubCollector::
CNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                       bool generate_lower_bound_ffs, bool generate_upper_bound_ffs, 
                                       std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CNodePairCountCollector(scope, collect_only_basic_block_start_nodes, 
                            generate_lower_bound_ffs, generate_upper_bound_ffs, may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

//----------------------------------
// To set the nodes to consider
//---------------------------------
void
CNodePairCountScopeAndLoopSubCollector::
SetNodesToConsider(set<CECFGNode *> * nodes_to_consider)
{
 // Call the wanted function in the scope
  _scope->NodesInScopeExceptHeaderAndLoopSubScopes(nodes_to_consider);
}

//----------------------------------
// CMaxNodePairCountScopeAndLoopSubCollector
//----------------------------------
CMaxNodePairCountScopeAndLoopSubCollector::
CMaxNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes, 
                                          std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CNodePairCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, false, true, may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

//----------------------------------
// CMinNodePairCountScopeAndLoopSubCollector
//----------------------------------
CMinNodePairCountScopeAndLoopSubCollector::
CMinNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes, 
                                          std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CNodePairCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, true, false, may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

//----------------------------------
// CMinMaxNodePairCountScopeAndLoopSubCollector
//----------------------------------
CMinMaxNodePairCountScopeAndLoopSubCollector::
CMinMaxNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                             std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CNodePairCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, true, true, may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CHeaderNodePairCountScopeAndSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CHeaderNodePairCountScopeAndSubCollector::
CHeaderNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                         bool generate_lower_bound_ffs, bool generate_upper_bound_ffs, 
                                         std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CNodePairCountCollector(scope, collect_only_basic_block_start_nodes, 
                            generate_lower_bound_ffs, generate_upper_bound_ffs, may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}


//----------------------------------
// To set the nodes to consider
//---------------------------------
void
CHeaderNodePairCountScopeAndSubCollector::
SetNodesToConsider(set<CECFGNode *> * nodes_to_consider)
{
 // Call the wanted function in the scope
  _scope->HeaderNodesInScopeAndSubScopes(nodes_to_consider);
}

// ---------------------------------
// CMaxHeaderNodePairCountScopeAndSubCollector
//----------------------------------
CMaxHeaderNodePairCountScopeAndSubCollector::
CMaxHeaderNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes, 
                                            std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CHeaderNodePairCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, false, true,
                                             may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

// ---------------------------------
// CMinHeaderNodePairCountScopeAndSubCollector
//----------------------------------
CMinHeaderNodePairCountScopeAndSubCollector::
CMinHeaderNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                            std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CHeaderNodePairCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, true, false,
                                             may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

// ---------------------------------
// CMinMaxHeaderNodePairCountScopeAndSubCollector
//----------------------------------
CMinMaxHeaderNodePairCountScopeAndSubCollector::
CMinMaxHeaderNodePairCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                               std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CHeaderNodePairCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, true, true,
                                             may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CHeaderNodePairCountScopeAndLoopSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CHeaderNodePairCountScopeAndLoopSubCollector::
CHeaderNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                             bool generate_lower_bound_ffs, bool generate_upper_bound_ffs,
                                             std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CNodePairCountCollector(scope, collect_only_basic_block_start_nodes, 
                            generate_lower_bound_ffs, generate_upper_bound_ffs,
                            may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

//----------------------------------
// To set the nodes to consider
//---------------------------------
void
CHeaderNodePairCountScopeAndLoopSubCollector::
SetNodesToConsider(set<CECFGNode *> * nodes_to_consider)
{
 // Call the wanted function in the scope
  _scope->HeaderNodesInScopeAndLoopSubScopes(nodes_to_consider);
}

//----------------------------------
// CMaxHeaderNodePairCountScopeAndLoopSubCollector
//----------------------------------
CMaxHeaderNodePairCountScopeAndLoopSubCollector::
CMaxHeaderNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                                std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CHeaderNodePairCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, false, true,
                                                 may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

//----------------------------------
// CMinHeaderNodePairCountScopeAndLoopSubCollector
//----------------------------------
CMinHeaderNodePairCountScopeAndLoopSubCollector::
CMinHeaderNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                                std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CHeaderNodePairCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, true, false,
                                                 may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}

//----------------------------------
// CMinMaxHeaderNodePairCountScopeAndLoopSubCollector
//----------------------------------
CMinMaxHeaderNodePairCountScopeAndLoopSubCollector::
CMinMaxHeaderNodePairCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes, 
                                                   std::set<std::pair<CECFGNode *, CECFGNode *> > * may_but_not_must_be_taken_node_pairs)
  : CHeaderNodePairCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, true, true,
                                                 may_but_not_must_be_taken_node_pairs)
{
  // Do nothing
}








