/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CNodeCountCollector.h 5409 2013-06-16 15:04:47Z lkg02 $
//
// ----------------------------------------------------------------------

#ifndef CNodeCountCollector_H_
#define CNodeCountCollector_H_

// Standard includes
#include <string>
#include <iostream>
#include <fstream>
#include <map>
#include <vector>

// Forward declare the CScope structure (due to circular dependencies
// we do not want to include the CScope.h file)
class CScope;
class CIntegerRange;
class CGenericStmt;
class CGenericFunction;

// For getting nice macros
#include "macros.h"

// To get a suitable the range representation
#include "CIntegerRange.h"
// To get the scope node representation
#include "graphs/ecfg/CECFGNode.h"
// To get flow fact types
#include "flow_facts/CFlowFact.h"
#include "flow_facts/CContextSensitiveValidAtEntryOfFlowFact.h"
// To get recorder type
#include "CRecorder.h"
// To get collector type
#include "CCollector.h"

// -------------------------------------------------------
// Class hierarchy:
//
//   CNodeCountCollector
//    |
//    |-- CNodeCountScopeCollector
//    |     |-- CMinNodeCountScopeCollector
//    |     |-- CMaxNodeCountScopeCollector
//    |     |-- CMinMaxNodeCountScopeCollector
//    |
//    |-- CNodeCountScopeAndSubCollector
//    |     |-- CMinNodeCountScopeAndSubCollector
//    |     |-- CMaxNodeCountScopeAndSubCollector
//    |     |-- CMinMaxNodeCountScopeAndSubCollector
//    |
//    |-- CNodeCountScopeAndLoopSubCollector
//    |     |-- CMinNodeCountScopeAndLoopSubCollector
//    |     |-- CMaxNodeCountScopeAndLoopSubCollector
//    |     |-- CMinMaxNodeCountScopeAndLoopSubCollector
//    |
//    |-- CHeaderNodeCountScopeCollector
//    |     |-- CMinHeaderNodeCountScopeCollector
//    |     |-- CMaxHeaderNodeCountScopeCollector
//    |     |-- CMinMaxHeaderNodeCountScopeCollector
//    |
//    |-- CHeaderNodeCountScopeAndSubCollector
//    |     |-- CMinHeaderNodeCountScopeAndSubCollector
//    |     |-- CMaxHeaderNodeCountScopeAndSubCollector
//    |     |-- CMinMaxHeaderNodeCountScopeAndSubCollector
//    |
//    |-- CHeaderNodeCountScopeAndLoopSubCollector
//    |     |-- CMinHeaderNodeCountScopeAndLoopSubCollector
//    |     |-- CMaxHeaderNodeCountScopeAndLoopSubCollector
//    |     |-- CMinMaxHeaderNodeCountScopeAndLoopSubCollector
//
// -------------------------------------------------------


//----------------------------------------------------------------------
//----------------------------------------------------------------------
//----------------------------------------------------------------------
// CNodeCountCollector
// - Class which exports all functionality for updating & storing
//   information on number of times nodes are taken in a certain context. 
//   Vill be associated with a scope, asking the scope for information
//   and updating the scope with resulting flow facts.
// - A recorder will update the collector with information upon
//   the nodes taken for an executed scope.
// - Class to inherit from (is virtual and can not be instansiated).
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//----------------------------------------------------------------------
class CNodeCountCollector : public CCollector 
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------

  // Default behaviour is to record only basic block start nodes. Alternatively,
  // the boolean can be used to control the behaviour.
  CNodeCountCollector(CScope *, bool collect_only_basic_block_start_nodes=true, 
                      bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true);
  virtual ~CNodeCountCollector(void);

  //----------------------------------
  // To update the collector with a new recording. The recording should be
  // valid for a certain execution (from entry to exit) of a scope. Since
  // we allow states and recording to be merged, the recorder will be a
  // mapping from node to ranges or from edges to ranges. Will default
  // generate an assert, and suitable function call should therefore be
  // redefined by subclasses.
  //---------------------------------
  void Update(std::map<CECFGNode *, CIntegerRange *> * node_to_range_recording);
  // Will be calling the specialized Update function
  void Report(CRecorder * rec);
  // Should not be called by this colector but need to be implemented
  void Report(int iter, CRecorder * rec) {assert(0);}

  //----------------------------------
  // Create flow facts from the collector and add to scope. Returns
  // the number of flow facts created. Will be calling the specialized
  // AddNodeCountFlowFactsToScope functions.
  //---------------------------------
  int GenerateFlowFacts(void);
  
  // ---------------------------------
  // Take a set of collectors, merge their internals and generate
  // context sensitive valid at entry of flow facts valid over CFG
  // nodes. Returns the number of flow facts created. Adds created ffs
  // to last argument. Collectors should be of CNodeCountScopeCollector type.
  // ---------------------------------
  int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                      std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,
                                                      std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);  

  // ---------------------------------
  // For printing the collector
  // ---------------------------------
  void Print(std::ostream *o=&std::cout);

  // The type of the collector, should be redefined in subclasses
  virtual std::string Type() = 0;

  // To get the nodes to consider. Can also be called by a recorder to
  // get the nodes to consider. Should not be deallocated by the caller.
  std::set<CECFGNode *> * NodesToConsider(void);

  inline bool IsEmpty(void) { return _node_to_range_map.size() == 0; }

  // To get the saved scope
  CScope * Scope() {return _scope;}

  // To get the number of updates made
  int NrOfReports() { return _nr_of_updates; }

protected:

  // ---------------------------------
  // Functions that should be implemented by subclasses
  // ---------------------------------

  // To get the type of flow fact generated
  virtual CFlowFact::t_flowfacttype GetLowerFlowFactType() = 0;
  virtual CFlowFact::t_flowfacttype GetUpperFlowFactType() = 0;

  // The get the nodes to consider. Is called the first time a
  // recorder is reported. Should be provided by subclasses.
  virtual void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider) = 0;

  // To set the node iteration count. May be redefined by subclasses.
  virtual void SetScopeIterationCount(int count);
  
  // ---------------------------------
  // Help functions not visible from the outside
  // ---------------------------------

  // Help functions used to create and add flow facts to the scope
  // graph. Returns the number of flow facts created. Uses the _scope.
  int AddMinNodeCountFlowFactsToScope(CFlowFact::t_flowfacttype ff_type);
  int AddMaxNodeCountFlowFactsToScope(CFlowFact::t_flowfacttype ff_type);

  // Help functions for generating context sensitive flow facts.
  // Returns the number of flow facts created. Adds created ffs to
  // last argument.
  int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::map<CFlowGraphNode *, CIntegerRange *> * cfg_node_to_range_map, 
                                                      std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                      std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);
  int GenerateContextSensitiveValidAtEntryOfMinFlowFacts(std::map<CFlowGraphNode *, CIntegerRange *> * cfg_node_to_range_map, 
                                                         std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                         std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,
                                                         CFlowFact::t_flowfacttype ff_type,
                                                         std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);
  int GenerateContextSensitiveValidAtEntryOfMaxFlowFacts(std::map<CFlowGraphNode *, CIntegerRange *> * cfg_node_to_range_map, 
                                                         std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                         std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of, 
                                                         CFlowFact::t_flowfacttype ff_type,
                                                         std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs);
    
  // Help function for deriving CFG node to range map
  void DeriveCFGNodeToRangeMap(std::map<CFlowGraphNode *, CIntegerRange *> * cfg_node_to_range_map);

  // ---------------------------------
  // Internal data 
  // ---------------------------------

  // The scope that the collector is associated with. Will be used
  // when creating flow facts and when deciding what nodes to consider.
  CScope * _scope;

  // If only basic block start nodes should be collected
  bool _collect_only_basic_block_start_nodes;

  // To remember if lower and/or upper bounds should be generated
  bool _generate_lower_bound_ffs;
  bool _generate_upper_bound_ffs;

  // To remember the number of updates made
  int _nr_of_updates;

  // To hold the nodes to consider. Differently updated by different
  // subclasses.
  std::set<CECFGNode *> _nodes_to_consider;

  // We keep the minimum and maximum count encountered during any
  // scope execution of each node.
  std::map<CECFGNode *, CIntegerRange *> _node_to_range_map;

};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CNodeCountCollector &a);

//------------------------------------------------------------
//------------------------------------------------------------
// CNodeCountScopeCollector
// - Collector which just reports both the lowest or largest number of occurrencies
//   of nodes for all executions of the scope. The header node of the
//   scope will not be included.
// - Virtual, i.e. can not be instansiated.
//------------------------------------------------------------
//------------------------------------------------------------
class CNodeCountScopeCollector : public CNodeCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                           bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true);
  virtual ~CNodeCountScopeCollector() {}

protected:

  // The get the nodes to consider. 
  void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LNSS; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UNSS; };
};


//--------------------------------------------------
// CMaxNodeCountScopeCollector
// - Collector which just reports the largest number of occurrencies
//   of nodes for all executions of the scope. The header node of the
//   scope will not be included.
// - Creates  scope : [] : #node <= i   flow facts
//-------------------------------------------------
class CMaxNodeCountScopeCollector : public CNodeCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMaxNodeCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxNodeCountScopeCollector";}
};

//--------------------------------------------------
// CMinNodeCountScopeCollector
// - Collector which just reports the lowest number of occurrencies
//   of nodes for all executions of the scope. The header node of the
//   scope will be included.
// - Creates  scope : [] : #node >= i   flow facts
//-------------------------------------------------
class CMinNodeCountScopeCollector : public CNodeCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinNodeCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinNodeCountScopeCollector";}
};

//--------------------------------------------------
// CMinMaxNodeCountScopeCollector
// - Collector which reports both the lowest and largesy number of occurrencies
//   of nodes for all executions of the scope. The header node of the
//   scope will be included.
// - Creates  scope : [] : #node <= i   and   scope : [] : #node >= i flow facts
//-------------------------------------------------
class CMinMaxNodeCountScopeCollector : public CNodeCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinMaxNodeCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxNodeCountScopeCollector";}
};


//------------------------------------------------------------
//------------------------------------------------------------
// CNodeCountScopeAndSubCollector
// - Collector which just remembers the lowset and largest number of occurrencies
//   of nodes for all executions of the scope and its subscopes. The header
//   node of the scope will not be included.
// - Virtual, i.e. cannot be created 
//------------------------------------------------------------
//------------------------------------------------------------
class CNodeCountScopeAndSubCollector : public CNodeCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                 bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true);
  virtual ~CNodeCountScopeAndSubCollector() {}


protected:

  // The set the nodes to consider. 
  void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LNSP; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UNSP; };

};

//--------------------------------------------------
// CMinNodeCountScopeAndSubCollector
// - Collector which just remembers the smallest number of occurrencies
//   of nodes for all executions of the scope and its subscopes. 
// - Creates  scope : [] : #node >= i   and
//            scope : [] : #subscope.node >= i   flow facts
//-------------------------------------------------
class CMinNodeCountScopeAndSubCollector : public CNodeCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinNodeCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinNodeCountScopeAndSubCollector";}

};


//--------------------------------------------------
// CMaxNodeCountScopeAndSubCollector
// - Collector which just remembers the largest number of occurrencies
//   of nodes for all executions of the scope and its subscopes. 
// - Creates  scope : [] : #node <= i   and
//            scope : [] : #subscope.node <= i   flow facts
//-------------------------------------------------
class CMaxNodeCountScopeAndSubCollector : public CNodeCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMaxNodeCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxNodeCountScopeAndSubCollector";}

};


//--------------------------------------------------
// CMinMaxNodeCountScopeAndSubCollector
// - Collector which just remembers the largest number of occurrencies
//   of nodes for all executions of the scope and its subscopes. 
// - Creates  scope : [] : #node <= i  and
//            scope : [] : #node >= j  and
//            scope : [] : #subscope.node <= i  and
//            scope : [] : #subscope.node >= j  flow facts
//-------------------------------------------------
class CMinMaxNodeCountScopeAndSubCollector : public CNodeCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinMaxNodeCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxNodeCountScopeAndSubCollector";}

};

//------------------------------------------------------------
//------------------------------------------------------------
// CNodeCountScopeAndLoopSubCollector
// - Collector which just remembers the largest number of occurrencies
//   of nodes for all executions of the scope and its direct looping
//   subscopes. The header node of the scope will not be included.
// - Virtual, i.e cannot be created 
//------------------------------------------------------------
//------------------------------------------------------------
class CNodeCountScopeAndLoopSubCollector: public CNodeCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                           bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true);
  virtual ~CNodeCountScopeAndLoopSubCollector() {}

protected:

  // The get the nodes to consider. 
  void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LNSF; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UNSF; };
};

//--------------------------------------------------
// CMinNodeCountScopeAndLoopSubCollector
// - Collector which just remembers the smallest number of
//   occurrencies of nodes in the scope and its direct looping subscopes
//   for all executions of the scope. 
// - Creates  scope : [] : #node >= j  and
//            scope : [] : #subscope.node >= j  flow facts
//-------------------------------------------------
class CMinNodeCountScopeAndLoopSubCollector : public CNodeCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinNodeCountScopeAndLoopSubCollector(void) {}

  // The type of the collector, must be given by subclasses
  std::string Type() {return "CMinNodeCountScopeAndLoopSubCollector";}
};

//--------------------------------------------------
// CMaxNodeCountScopeAndLoopSubCollector
// - Collector which just remembers the largest number of occurrencies
//   of nodes for all executions of the scope and its direct looping
//   subscopes. The header node of the scope will not be included.
// - Creates  scope : [] : #node <= i   and
//            scope : [] : #subscope.node <= i   flow facts
//-------------------------------------------------
class CMaxNodeCountScopeAndLoopSubCollector : public CNodeCountScopeAndLoopSubCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMaxNodeCountScopeAndLoopSubCollector(void) {}

  // The type of the collector, must be given by subclasses
  std::string Type() {return "CMaxNodeCountScopeAndLoopSubCollector";}
};


//--------------------------------------------------
// CMinMaxNodeCountScopeAndLoopSubCollector
// - Collector which just remembers the largest number of occurrencies
//   of nodes for all executions of the scope and its direct looping
//   subscopes. The header node of the scope will not be included.
// - Creates  scope : [] : #node <= i   and
//            scope : [] : #subscope.node <= i   flow facts
//-------------------------------------------------
class CMinMaxNodeCountScopeAndLoopSubCollector : public CNodeCountScopeAndLoopSubCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinMaxNodeCountScopeAndLoopSubCollector(void) {}

  // The type of the collector, must be given by subclasses
  std::string Type() {return "CMinMaxNodeCountScopeAndLoopSubCollector";}
};


//------------------------------------------------------------
//------------------------------------------------------------
// CHeaderNodeCountScopeCollector
// - Collector which just remembers the largest number of occurrencies of
//   the header node for all executions of the scope.
// - Virtual, i.e. cannot be created
//------------------------------------------------------------
//------------------------------------------------------------
class CHeaderNodeCountScopeCollector : public CNodeCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CHeaderNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                           bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true);
  virtual ~CHeaderNodeCountScopeCollector() {}

protected:

  // The get the nodes to consider. Is called the first time a
  // recorder is reported. Will only set the header node in the scope.
  void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LHSS; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UHSS; };
};

//--------------------------------------------------
// CMaxHeaderNodeCountScopeCollector
// - Collector which reports the largest number of occurrencies
//   of the header node of the scope. The header node of the
//   scope will not be included.
// - Creates  scope : [] : #node <= i   flow facts
//-------------------------------------------------
class CMaxHeaderNodeCountScopeCollector : public CHeaderNodeCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxHeaderNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMaxHeaderNodeCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxHeaderCountScopeCollector";}
};

//--------------------------------------------------
// CMinHeaderNodeCountScopeCollector
// - Collector which reports the smallest number of occurrencies
//   of the header node of the scope. The header node of the
//   scope will not be included.
// - Creates  scope : [] : #node >= i   flow facts
//-------------------------------------------------
class CMinHeaderNodeCountScopeCollector : public CHeaderNodeCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinHeaderNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinHeaderNodeCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinHeaderCountScopeCollector";}
};

//--------------------------------------------------
// CMinMaxHeaderNodeCountScopeCollector
// - Collector which reports the smallest number of occurrencies
//   of the header node of the scope. The header node of the
//   scope will not be included.
// - Creates  scope : [] : #node <= i and scope : [] : #node >= i  flow facts
//-------------------------------------------------
class CMinMaxHeaderNodeCountScopeCollector : public CHeaderNodeCountScopeCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxHeaderNodeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinMaxHeaderNodeCountScopeCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxHeaderCountScopeCollector";}
};

//------------------------------------------------------------
//------------------------------------------------------------
// CHeaderNodeCountScopeAndSubCollector
// - Collector which just remembers the smallest and largest number of 
//   occurrencies of the header nodes of the scope and its subscopes. 
// - Virtual, i.e. cannot be created
//------------------------------------------------------------
//------------------------------------------------------------
class CHeaderNodeCountScopeAndSubCollector : public CNodeCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CHeaderNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                           bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true);
  virtual ~CHeaderNodeCountScopeAndSubCollector() {}

protected:

  // The get the nodes to consider. Is called the first time a
  // recorder is reported. Will only set the header node in the scope.
  void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LHSP; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UHSP; };
};


//--------------------------------------------------
// CMaxHeaderNodeCountScopeAndSubCollector
// - Collector which just remembers the largest number of occurrencies of
//   the header node for all executions of the scope. It also remembers
//   the max count for all direct (one or more steps) looping subscopes.
// - Creates  maxiter : #node                   and
//            scope : [] : #subscope.node <= i  flow facts
//-------------------------------------------------
class CMaxHeaderNodeCountScopeAndSubCollector : public CHeaderNodeCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxHeaderNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMaxHeaderNodeCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxHeaderNodeCountScopeAndSubCollector";}
};

//--------------------------------------------------
// CMinHeaderNodeCountScopeAndSubCollector
// - Collector which just remembers the largest number of occurrencies of
//   the header node for all executions of the scope. It also remembers
//   the max count for all direct (one or more steps) looping subscopes.
// - Creates  maxiter : #node                   and
//            scope : [] : #subscope.node <= i  flow facts
//-------------------------------------------------
class CMinHeaderNodeCountScopeAndSubCollector : public CHeaderNodeCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinHeaderNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinHeaderNodeCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinHeaderNodeCountScopeAndSubCollector";}
};

//--------------------------------------------------
// CMinMaxHeaderNodeCountScopeAndSubCollector
// - Collector which just remembers the smallest and largest number of
//   occurrencies of the header node for all executions of the scope.
//   It also remembers the min and max count for all direct (one or
//   more steps) looping subscopes.
// - Creates  maxiter : #node                   and
//            scope : [] : #node >= j           and
//            scope : [] : #subscope.node <= i  and
//            scope : [] : #subscope.node >= j  flow facts
//-------------------------------------------------
class CMinMaxHeaderNodeCountScopeAndSubCollector : public CHeaderNodeCountScopeAndSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxHeaderNodeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinMaxHeaderNodeCountScopeAndSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxHeaderNodeCountScopeAndSubCollector";}
};



//------------------------------------------------------------
//------------------------------------------------------------
// CHeaderNodeCountScopeAndLoopSubCollector
// - Collector which just remembers the largest number of occurrencies
//   of nodes for all executions of the scope and its subscopes. The header
//   node of the scope will not be included.
// - Virtual, i.e. cannot be created
//------------------------------------------------------------
//------------------------------------------------------------
class CHeaderNodeCountScopeAndLoopSubCollector : public CNodeCountCollector
{
public:
  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CHeaderNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true,
                                           bool generate_lower_bound_ffs=true, bool generate_upper_bound_ffs=true);
  virtual ~CHeaderNodeCountScopeAndLoopSubCollector() {}

protected:

  // The get the nodes to consider. Is called the first time a
  // recorder is reported. Will only set the header node in the scope.
  void SetNodesToConsider(std::set<CECFGNode *> * nodes_to_consider);

  // To get the type of flow facts
  CFlowFact::t_flowfacttype GetLowerFlowFactType() { return CFlowFact::LHSF; };
  CFlowFact::t_flowfacttype GetUpperFlowFactType() { return CFlowFact::UHSF; };
};


//--------------------------------------------------
// CMaxHeaderNodeCountScopeAndLoopSubCollector
// - Collector which just remembers the largest number of occurrencies
//   of nodes for all executions of the scope and its subscopes. 
// - Creates  scope : [] : #node <= i   and
//            scope : [] : #subscope.node <= i   flow facts
//-------------------------------------------------
class CMaxHeaderNodeCountScopeAndLoopSubCollector : public CHeaderNodeCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMaxHeaderNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMaxHeaderNodeCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMaxHeaderNodeCountScopeAndLoopSubCollector";}
};

//--------------------------------------------------
// CMinHeaderNodeCountScopeAndLoopSubCollector
// - Collector which just remembers the largest number of occurrencies
//   of nodes for all executions of the scope and its subscopes. 
// - Creates  scope : [] : #node >= i   and
//            scope : [] : #subscope.node >= i   flow facts
//-------------------------------------------------
class CMinHeaderNodeCountScopeAndLoopSubCollector : public CHeaderNodeCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinHeaderNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinHeaderNodeCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinHeaderNodeCountScopeAndLoopSubCollector";}
};

//--------------------------------------------------
// CMinMaxHeaderNodeCountScopeAndLoopSubCollector
// - Collector which just remembers the smellest and largest number of occurrencies
//   of nodes for all executions of the scope and its subscopes. 
// - Creates  scope : [] : #node <= i   and
//            scope : [] : #node >= j   and
//            scope : [] : #subscope.node <= i  and
//            scope : [] : #subscope.node >= j  flow facts
//-------------------------------------------------
class CMinMaxHeaderNodeCountScopeAndLoopSubCollector : public CHeaderNodeCountScopeAndLoopSubCollector
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------
  CMinMaxHeaderNodeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes=true);
  virtual ~CMinMaxHeaderNodeCountScopeAndLoopSubCollector(void) {}

  // The type of the collector
  std::string Type() {return "CMinMaxHeaderNodeCountScopeAndLoopSubCollector";}
};


#endif















