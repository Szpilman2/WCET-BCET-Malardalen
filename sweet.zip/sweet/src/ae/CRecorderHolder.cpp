#include "CRecorderHolder.h"
#include <stack>
#include <algorithm>

using namespace std;

std::ostream &operator << (std::ostream &o, CRecorderHolder &a)
{
  a.Print(&o);
  return o;
}

// =======================================================
// =======================================================
// =======================================================
// CScopeRecorderHolder
// =======================================================
// =======================================================
// =======================================================

// To create a new scope local recorder holder, we need a way to
// associate collectors and scopes. We also need a server which will
// be used to create, delete, and update the recording.
CScopeRecorderHolder:: 
CScopeRecorderHolder(std::map<CScope *, CCollector *> * scope_to_collector_map, 
                     CRecorderServer * recorder_server) 
{
  // Set needed data structures
  _scope_to_collector_map = scope_to_collector_map;
  _recorder_server = recorder_server;
}

CScopeRecorderHolder:: 
~CScopeRecorderHolder()
{
  // At deletion, we should delete all recorders that we do not need
  // any longer.

  // Delete all stacked recorders
  for(std::map<CScope *, CRecorder *>::iterator c2r = _saved_recorders.begin();
      c2r != _saved_recorders.end(); c2r++) {
    // Get the recorder and delete it
    CRecorder * rec = (*c2r).second;
    assert(rec);
    _recorder_server->DeleteRecorder(rec);
  }
  // delete _scope_to_collector_map;
}

// When we start the execution we should also create a scope local recorder
void
CScopeRecorderHolder:: 
UpdateWithProgramStart(CECFGNode * PC_after)
{
   // Make sure that the stack is empty
   assert(_saved_recorders.size() == 0);

   // Create new recorders for the scope and its ancestors
   for (CScope * s = PC_after->Scope(); s != 0; s = s->ParentScope())
      CreateRecorderForScopeIfNeeded(s);  
}

// When we end the execution we should also create a scope local recorder
void
CScopeRecorderHolder:: 
UpdateWithProgramExit(CECFGNode * PC_before)
{
  // std::cout << "CScopeRecorderHolder::UpdateWithProgramExit PC_before: ";
  // PC_before->Print();
  // std::cout << endl;

  // Remember that we have taken the last node
  UpdateRecorderWithProgramExit(PC_before); 

  // Get the current scope
  CScope * scope = PC_before->Scope();

  // We should report and reset all recorders which are associated to
  // scopes at current scope and higher up in the scope graph...
  while(scope != NULL) {
    ReportRecorderForScopeToCollector(scope);
    ResetRecorderForScope(scope);
    // Get the parent scope
    scope = scope->ParentScope();
  }
}

// Update scope recorder holder with the node transfer. The below code
// also holds the functionality for handling the case that the
// execution goes from one scope to another.
//
// Example of scope hierarchy used to illustrate the different cases 
// of scope change. The scopes forms a tree.
//
//       A
//      / |
//     B  D
//    /   | 
//   C    E 
// 
void CScopeRecorderHolder::
UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after) 
{
  // Update recorder with the change of program counter value
  UpdateRecorderWithProgramCounterChange(PC_before, PC_after); 

  // Check if the scope has changed. If so, new recorders may be
  // created, recorders may be stacked and recorders results may be
  // reported to their collectors. 
  CScope * scope_before = PC_before->Scope();
  CScope * scope_after = PC_after->Scope();
  if(scope_before != scope_after) {

    // Check if we have left the scope to a subordinate scope,
    // e.g. A->D or A->E
    if(scope_before->IsAncestorOf(scope_after)) {

      // Loop upwards from scope_after until we reach the before scope
      CScope * parent_to_scope_after = scope_after->ParentScope();
      assert(parent_to_scope_after);
      // Create recorders for intermediate scopes if needed,
      // e.g. scope D in case A->E
      while(parent_to_scope_after != scope_before) {
        CreateRecorderForScopeIfNeeded(parent_to_scope_after);
        parent_to_scope_after = parent_to_scope_after->ParentScope();
      }

      // Finally, create the recorder for the after scope
      CreateRecorderForScopeIfNeeded(scope_after);
    }    

    // Else, we have left the scope to an ancestor scope, e.g. E->A or
    // D-A or to a scope which is a sibling to a common ancestor
    // scope, e.g D->B or E->C
    else {

      // Report the before scope's recorder to its collector, and then
      // reset it
      ReportRecorderForScopeToCollector(scope_before);
      ResetRecorderForScope(scope_before);
      // Loop upwards until we reach the after scope, e.g. in E->A we
      // loop from E to D, or until we reach a common ancestoral
      // scope, e.g. in E->C we have that A is common ancestral scope
      // and we go from E to D.
      CScope * parent_to_scope_before = scope_before->ParentScope();
      while((parent_to_scope_before != scope_after) && 
            !(parent_to_scope_before->IsAncestorOf(scope_after))) {
        // Report intermediate recorder to its collector, and then
        // reset it
        ReportRecorderForScopeToCollector(parent_to_scope_before);
        ResetRecorderForScope(parent_to_scope_before);
        // Iterate upwards
        parent_to_scope_before = parent_to_scope_before->ParentScope();
      }

      // Check if we have should go down to a subordinate scope of
      // parent_to_scope_before, i.e. if we go from E->C we do not 
      // need to create for A, but maybe for B and C.
      if(scope_after != parent_to_scope_before) {
        // Loop upwards until we reach the common ancestor scope
        CScope * common_ancestor_scope = scope_after->ParentScope();
        assert(common_ancestor_scope);
        // Create recorders for these intermediate scopes
        while(common_ancestor_scope != parent_to_scope_before) {
          CreateRecorderForScopeIfNeeded(common_ancestor_scope);
          common_ancestor_scope = common_ancestor_scope->ParentScope();
        }
        // Finally, create the recorder for the after scope
        CreateRecorderForScopeIfNeeded(scope_after);
      }
      else {
        // We do not need to do anything, i.e. the recorder for the 
        // after scope should already have been created, e.g. for E->A
        // or D->A a recorder for A should already have been created. 
      }
    }
  }

}


// This function helps us implement reuse of recorders. Basically, if
// there already exists a recorder for the scope we will use this one
// instead of creating a new.
void
CScopeRecorderHolder:: 
CreateRecorderForScopeIfNeeded(CScope * scope)
{
  if(_saved_recorders.find(scope) == _saved_recorders.end()) {
    CRecorder * rec = _recorder_server->CreateRecorder();
    _saved_recorders[scope] = rec;
  }
}
  
void
CScopeRecorderHolder:: 
ResetRecorderForScope(CScope * scope)
{
  CRecorder * recorder = _saved_recorders[scope];
  _recorder_server->ResetRecorder(&recorder);
  _saved_recorders[scope] = recorder;
}

void
CScopeRecorderHolder:: 
ReportRecorderForScopeToCollector(CScope * scope)
{
  assert(scope);
  CRecorder * recorder = _saved_recorders[scope];
  CCollector * collector = (*_scope_to_collector_map)[scope];
  assert(recorder);
  assert(collector);
  collector->Report(recorder);
}

// For copying the scope local header node count recorder holder
CScopeRecorderHolder *
CScopeRecorderHolder::
Copy(void)
{
  // First, create a new recorder holder object
  CScopeRecorderHolder * new_rec_holder =
    new CScopeRecorderHolder(_scope_to_collector_map, _recorder_server);

  // Secondly, copy the saved node count recorders
  CopySavedRecorders(&(_saved_recorders), &(new_rec_holder->_saved_recorders));
  
  // Return the created object
  return new_rec_holder;
}


// Help function for copying saved recorders
void
CScopeRecorderHolder::
CopySavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders, 
                   std::map<CScope *, CRecorder *> * new_saved_recorders)
{
  // Copy each of the recorders and insert them into the map 
  for(std::map<CScope *, CRecorder *>::iterator s2r = saved_recorders->begin();
      s2r != saved_recorders->end(); s2r++) {
    CScope * s = (*s2r).first;
    CRecorder * r = (*s2r).second;
    assert(r);
    CRecorder * new_r = _recorder_server->CopyRecorder(r);
    (*new_saved_recorders)[s] = new_r;
  }
}

// For merging the scope local header node count recorder holder
CScopeRecorderHolder *
CScopeRecorderHolder::
Merge(CRecorderHolder * other_rec_holder)
{
  // Create a new recorder holder object
  CScopeRecorderHolder * new_rec_holder =
    new CScopeRecorderHolder(_scope_to_collector_map, _recorder_server);

  // Merge the internal map of saved record holders and store in 
  MergeSavedRecorders(&(_saved_recorders), 
                      &((dynamic_cast<CScopeRecorderHolder *>(other_rec_holder))->_saved_recorders), 
                      &(new_rec_holder->_saved_recorders));
		      
  // Return the created object
  return new_rec_holder;
}

// Help function for merging saved recorders
void
CScopeRecorderHolder::
MergeSavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders1, 
                    std::map<CScope *, CRecorder *> * saved_recorders2,
                    std::map<CScope *, CRecorder *> * new_saved_recorders)
{
  // Merge each of the saved recorders.
  for(std::map<CScope *, CRecorder *>::iterator s2r = saved_recorders1->begin();
      s2r != saved_recorders1->end(); s2r++) {
    CScope * s = (*s2r).first;
    CRecorder * r1 = (*s2r).second;
    assert(r1 != 0);
    map<CScope *, CRecorder *>::iterator r2it = saved_recorders2->find(s);
    // If saved_recorders2 does not have the recorder, we assume it is a
    // garbage recorder that is only kept around for caching purposes, so skip it
    if (r2it != saved_recorders2->end())
    {
       CRecorder * r2 = r2it->second;
       CRecorder * new_r = _recorder_server->MergeRecorders(r1, r2);
       (*new_saved_recorders)[s] = new_r;
    }
  }
}

void 
CScopeRecorderHolder:: 
Print(std::ostream *o)
{
  // Loop through and print all saved recorders
  for(std::map<CScope *, CRecorder *>::iterator c2r = _saved_recorders.begin();
      c2r != _saved_recorders.end(); c2r++) {
    // Get the scope and the recorder 
    CScope * scope = (*c2r).first;
    CRecorder * rec  =(*c2r).second;
    assert(rec);
    *o << "Scope: " << scope->Name() << std::endl;
    *o << "  Recorder: ";
    assert(rec);
    rec->Print(o);
  }
}

// Update recorder with program counter change
void
CScopeRecorderHolder:: 
UpdateRecorderWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after)
{ 
  assert(_saved_recorders.find(PC_before->Scope()) != _saved_recorders.end());
  CRecorder * recorder = _saved_recorders[PC_before->Scope()];
  // Increase count of node for current recorder 
  _recorder_server->UpdateRecorderWithProgramCounterChange(&recorder, PC_before, PC_after); 
  // Save maybe updated recorder back to scope 
  _saved_recorders[PC_before->Scope()] = recorder;
}

// Update recorder with program exit
void
CScopeRecorderHolder:: 
UpdateRecorderWithProgramExit(CECFGNode * PC_before)
{ 
  assert(_saved_recorders.find(PC_before->Scope()) != _saved_recorders.end());
  CRecorder * recorder = _saved_recorders[PC_before->Scope()];
  // Increase count of node for current recorder 
  _recorder_server->UpdateRecorderWithProgramExit(&recorder, PC_before); 
  // Save maybe updated recorder back to scope 
  _saved_recorders[PC_before->Scope()] = recorder;
}

// =======================================================
// =======================================================
// =======================================================
// CIterRecorderHolder
// =======================================================
// =======================================================
// =======================================================

// To create a new scope local recorder holder, we need a way to
// associate collectors and scopes. We also need a server which will
// be used to create, delete, and update the recording.
CIterRecorderHolder:: 
CIterRecorderHolder(std::map<CScope *, CCollector *> * scope_to_collector_map, 
                    CRecorderServer * recorder_server) 
{
  // Set needed data structures
  _scope_to_collector_map = scope_to_collector_map;
  _recorder_server = recorder_server;
}

CIterRecorderHolder:: 
~CIterRecorderHolder()
{
  // At deletion, we should delete all recorders that we do not need
  // any longer.

  // Delete all stacked recorders
  for(std::map<CScope *, CRecorder *>::iterator c2r = _saved_recorders.begin();
      c2r != _saved_recorders.end(); c2r++) {
    // Get the recorder and delete it
    CRecorder * rec = (*c2r).second;
    _recorder_server->DeleteRecorder(rec);
  }
  // delete _scope_to_collector_map;
  // We do not need to delete stacked iterations
}

// When we start the execution we should also create a scope local recorder
void
CIterRecorderHolder:: 
UpdateWithProgramStart(CECFGNode * PC_after)
{
   // Make sure that the stack is empty
   assert(_saved_recorders.size() == 0);
   // Create new recorders for the scope and its ancestors
   for (CScope * s = PC_after->Scope(); s != 0; s = s->ParentScope())
   {
      CreateRecorderForScopeIfNeeded(s);  
      CreateIterationsForScope(s);  
   }
}

// When we end the execution we should also create a scope local recorder
void
CIterRecorderHolder:: 
UpdateWithProgramExit(CECFGNode * PC_before)
{
  // Get the current scope
  CScope * scope = PC_before->Scope();

  // Remember that we have taken the last node
  UpdateRecorderWithProgramExit(PC_before); 

  // We should report and reset all recorders which are associated to
  // scopes at current scope and higher up in the scope graph...
  while(scope != NULL) {
    ReportIterationsAndRecorderForScopeToCollector(scope);
    ResetRecorderForScope(scope);
    ResetIterationsForScope(scope);
    // Get the parent scope
    scope = scope->ParentScope();
  }
}

// Example of scope hierarchy used to illustrate the different cases 
// of scope change. The scopes forms a tree.
//
//       A
//      / |
//     B  D
//    /   | 
//   C    E 
// 
// Update recorder with the node transfer
void CIterRecorderHolder::
UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after) 
{
  // Update recorder with the change of program counter value
  UpdateRecorderWithProgramCounterChange(PC_before, PC_after); 

  // Check if the scope has changed. If so, new recorders may be
  // created, recorders may be stacked and recorders results may be
  // reported to their collectors. 
  CScope * scope_before = PC_before->Scope();
  CScope * scope_after = PC_after->Scope();
  if(scope_before != scope_after) {
    
    // Check if we have left the scope to a subordinate scope,
    // e.g. A->D or A->E
    if(scope_before->IsAncestorOf(scope_after)) {
      // Loop upwards from scope_after until we reach the old scope
      CScope * parent_to_scope_after = scope_after->ParentScope();
      assert(parent_to_scope_after);
      // Create recorders for these intermediate scopes if needed,
      // e.g. scope D in case A->E
      while(parent_to_scope_after != scope_before) {
        CreateRecorderForScopeIfNeeded(parent_to_scope_after);
        CreateIterationsForScope(parent_to_scope_after);
        parent_to_scope_after = parent_to_scope_after->ParentScope();
      }
      // Create the recorder and start iterations for the after scope
      CreateRecorderForScopeIfNeeded(scope_after);
      CreateIterationsForScope(scope_after);
    }
    // Else, we have left the scope to an ancestor scope, e.g. E->A or
    // D-A or to a scope which is a sibling to a common ancestor
    // scope, e.g D->B or E->C
    else {
      // Report the recorder to its collector, and then reset it
      ReportIterationsAndRecorderForScopeToCollector(scope_before);
      ResetRecorderForScope(scope_before);
      // Loop upwards until we reach the after scope, e.g. in E->A we
      // loop from E to D, or until we reach a common ancestoral
      // scope, e.g. in E->C we have that A is common ancestral scope
      // and we go from E to D.
      CScope * parent_to_scope_before = scope_before->ParentScope();
      while((parent_to_scope_before != scope_after) && 
            (!(parent_to_scope_before->IsAncestorOf(scope_after)))) {
        // Report the recorder to its collector, and then reset it
        ReportIterationsAndRecorderForScopeToCollector(parent_to_scope_before);
        ResetRecorderForScope(parent_to_scope_before);
        ResetIterationsForScope(parent_to_scope_before);
        // Iterate upwards
        parent_to_scope_before = parent_to_scope_before->ParentScope();
      }
      // Check if we have should go down to a subordinate scope of
      // parent_to_scope_before, i.e. if we go from E->C we do not 
      // need to create for A, but maybe for B and C.
      if(scope_after != parent_to_scope_before) {
        // Loop upwards until we reach the common ancestor scope
        CScope * common_ancestor_scope = scope_after->ParentScope();
        assert(common_ancestor_scope);
        // Create recorders for these intermediate scopes
        while(common_ancestor_scope != parent_to_scope_before) {
          CreateRecorderForScopeIfNeeded(common_ancestor_scope);
          CreateIterationsForScope(common_ancestor_scope);
          common_ancestor_scope = common_ancestor_scope->ParentScope();
        }
        // Finally, create the recorder and iterations for the after scope
        CreateRecorderForScopeIfNeeded(scope_after);
        CreateIterationsForScope(scope_after);
      }
      else {
        // We do not need to do anything, i.e. the recorder for the 
        // after scope should already have been created, e.g. for E->A
        // or D->A a recorder for A should already have been created. 
      }
    }
  }
  
  // If we should update the iteration count for the after scope.
  if(scope_after->IsHeader(PC_after)) {
    // For new entries of scope, the CreateRecorderForScopeIfNeeded
    // has set the scope iteration count to 1. However, if the scope
    // already is on the scope call stack, i.e. the edge goes to the
    // before scope or to an ancestor of the before scope, then we
    // should increase the iteration count by one.
    if(scope_before == scope_after || scope_after->IsAncestorOf(scope_before)) {
      // We should report the recording for the scope to the collecor
      ReportIterationsAndRecorderForScopeToCollector(scope_after);
      // After that we can reset the recorder
      ResetRecorderForScope(scope_after);
      // Finally, we should also increase the number of iterations for
      // the target scope
      IncreaseIterationsForScope(scope_after);
    }
  }
}

// This function helps us implement reuse of recorders. Basically, if
// there already exists a recorder for the scope we will use this one
// instead of creating a new.
void
CIterRecorderHolder:: 
CreateRecorderForScopeIfNeeded(CScope * scope)
{
  if(_saved_recorders.find(scope) == _saved_recorders.end()) {
    CRecorder * rec = _recorder_server->CreateRecorder();
    _saved_recorders[scope] = rec;
  }
}
  
void
CIterRecorderHolder:: 
ResetRecorderForScope(CScope * scope)
{
  CRecorder * recorder = _saved_recorders[scope];
  assert(recorder);
  _recorder_server->ResetRecorder(&recorder);
  _saved_recorders[scope] = recorder;
}

// Function called when entering a scope not in the current scope string
void 
CIterRecorderHolder:: 
CreateIterationsForScope(CScope * scope)
{
  // Set iterations for scope
  _saved_iterations[scope] = 1;
}

void
CIterRecorderHolder:: 
ResetIterationsForScope(CScope * scope)
{
  _saved_iterations[scope] = -1;
}

void
CIterRecorderHolder:: 
IncreaseIterationsForScope(CScope * scope)
{
  assert(_saved_iterations[scope] != -1);
  _saved_iterations[scope] = _saved_iterations[scope] + 1;
}

void
CIterRecorderHolder:: 
ReportIterationsAndRecorderForScopeToCollector(CScope * scope)
{
  CRecorder * recorder = _saved_recorders[scope];
  CCollector * collector = (*_scope_to_collector_map)[scope];
  int iter = _saved_iterations[scope];
  assert(recorder);
  assert(collector);
  assert(iter != -1);
  collector->Report(iter, recorder);
}

// For copying the scope local header node count recorder holder
CIterRecorderHolder *
CIterRecorderHolder::
Copy(void)
{
  // First, create a new recorder holder object
  CIterRecorderHolder * new_rec_holder =
    new CIterRecorderHolder(_scope_to_collector_map, _recorder_server);

  // Secondly, copy the saved node count recorders
  CopySavedRecorders(&(_saved_recorders), &(new_rec_holder->_saved_recorders));

  // Third, copy the saved iterations
  CopySavedIterations(&(_saved_iterations), &(new_rec_holder->_saved_iterations));
  
  // Return the created object
  return new_rec_holder;
}

// Help function for copying saved recorders
void
CIterRecorderHolder::
CopySavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders, 
                   std::map<CScope *, CRecorder *> * new_saved_recorders)
{
  // Copy each of the recorders and insert them into the map 
  for(std::map<CScope *, CRecorder *>::iterator s2r = saved_recorders->begin();
      s2r != saved_recorders->end(); s2r++) {
    CScope * s = (*s2r).first;
    CRecorder * r = (*s2r).second;
    assert(r);
    CRecorder * new_r = _recorder_server->CopyRecorder(r);
    (*new_saved_recorders)[s] = new_r;
  }
}

// Help function for copying saved iterations
void
CIterRecorderHolder::
CopySavedIterations(std::map<CScope *, int> * saved_iterations, 
                    std::map<CScope *, int> * new_saved_iterations)
{
  // Copy saved iterations is made by copying the whole map
  *new_saved_iterations = *saved_iterations;
}

// For merging the scope local header node count recorder holder
CIterRecorderHolder *
CIterRecorderHolder::
Merge(CRecorderHolder * other_rec_holder)
{
  // Create a new recorder holder object
  CIterRecorderHolder * new_rec_holder =
    new CIterRecorderHolder(_scope_to_collector_map, _recorder_server);

  // Merge the internal map of saved record holders and store in 
  MergeSavedRecorders(&(_saved_recorders), 
                      &((dynamic_cast<CIterRecorderHolder *>(other_rec_holder))->_saved_recorders), 
                      &(new_rec_holder->_saved_recorders));
  MergeSavedIterations(&(_saved_iterations), 
                       &((dynamic_cast<CIterRecorderHolder *>(other_rec_holder))->_saved_iterations), 
                       &(new_rec_holder->_saved_iterations));

  // Return the created object
  return new_rec_holder;
}

// Help function for merging saved recorders
void
CIterRecorderHolder::
MergeSavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders1, 
                    std::map<CScope *, CRecorder *> * saved_recorders2,
                    std::map<CScope *, CRecorder *> * new_saved_recorders)
{
  // Merge each of the saved recorders.
  for(std::map<CScope *, CRecorder *>::iterator s2r = saved_recorders1->begin();
      s2r != saved_recorders1->end(); s2r++) {
    CScope * s = (*s2r).first;
    CRecorder * r1 = (*s2r).second;
    assert(r1 != 0);
    map<CScope *, CRecorder *>::iterator r2it = saved_recorders2->find(s);
    // If saved_recorders2 does not have the recorder, we assume it is a
    // garbage recorder that is only kept around for caching purposes, so skip it
    if (r2it != saved_recorders2->end())
    {
       CRecorder * r2 = r2it->second;
       CRecorder * new_r = _recorder_server->MergeRecorders(r1, r2);
       (*new_saved_recorders)[s] = new_r;
    }
  }
}

// Help function for merging saved iterations
void
CIterRecorderHolder::
MergeSavedIterations(std::map<CScope *, int> * saved_iterations1,
                     std::map<CScope *, int> * saved_iterations2,
                     std::map<CScope *, int> * new_saved_iterations)
{
  // Merge saved iterations. Maybe we should check that both maps
  // have the same content?
  *new_saved_iterations = *saved_iterations1;
}

void 
CIterRecorderHolder:: 
Print(std::ostream *o)
{
  // Loop through and print all saved recorders
  for(std::map<CScope *, CRecorder *>::iterator c2r = _saved_recorders.begin();
      c2r != _saved_recorders.end(); c2r++) {
    // Get the scope and the recorder 
    CScope * scope = (*c2r).first;
    CRecorder * rec  =(*c2r).second;
    assert(rec);
    int iter = _saved_iterations[scope];
    *o << "Scope: " << scope->Name() << " iterations: " << iter << std::endl;
    *o << "  Recorder: ";
    rec->Print(o);
    *o << std::endl;
  }
}


// Update recorder with program counter change
void
CIterRecorderHolder:: 
UpdateRecorderWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after)
{ 
  CRecorder * recorder = _saved_recorders[PC_before->Scope()];
  // Increase count of node for current recorder 
  _recorder_server->UpdateRecorderWithProgramCounterChange(&recorder, PC_before, PC_after); 
  // Associate the scope with the new recorder
  _saved_recorders[PC_before->Scope()] = recorder;
}
 
// Update recorder with program exit
void
CIterRecorderHolder:: 
UpdateRecorderWithProgramExit(CECFGNode * PC_before)
{ 
  assert(_saved_recorders.find(PC_before->Scope()) != _saved_recorders.end());
  CRecorder * recorder = _saved_recorders[PC_before->Scope()];
  // Increase count of node for current recorder 
  _recorder_server->UpdateRecorderWithProgramExit(&recorder, PC_before); 
  // Save maybe updated recorder back to scope 
  _saved_recorders[PC_before->Scope()] = recorder;
}


// =======================================================
// =======================================================
// =======================================================
// CFunctionRecorderHolder
// =======================================================
// =======================================================
// =======================================================

// To create a new scope local recorder holder, we need a way to
// associate collectors and scopes. We also need a server which will
// be used to create, delete, and update the recording.
CFunctionRecorderHolder:: 
CFunctionRecorderHolder(std::map<CScope *, CCollector *> * func_scope_to_collector_map, 
                        CRecorderServer * recorder_server) 
{
  // Set needed data structures
  _func_scope_to_collector_map = func_scope_to_collector_map;
  _recorder_server = recorder_server;
}

CFunctionRecorderHolder:: 
~CFunctionRecorderHolder()
{
  // At deletion, we should delete all recorders that we do not need
  // any longer.

  // Delete all stacked recorders
  for(std::map<CScope *, CRecorder *>::iterator c2r = _saved_recorders.begin();
      c2r != _saved_recorders.end(); c2r++) {
    // Get the recorder and delete it
    CRecorder * rec = (*c2r).second;
    _recorder_server->DeleteRecorder(rec);
  }
  // delete _func_scope_to_collector_map;
}

// When we start the execution we should also create a scope local recorder
void
CFunctionRecorderHolder:: 
UpdateWithProgramStart(CECFGNode * PC_after)
{
   // Make sure that the stack is empty
   assert(_saved_recorders.size() == 0);
   // Create new recorders for the scope and its ancestors
   for (CScope * s = PC_after->Scope(); s != 0; s = s->ParentScope())
      CreateRecorderForFunctionScopeIfNeeded(s);  
}

// When we end the execution we should also create a scope local recorder
void
CFunctionRecorderHolder:: 
UpdateWithProgramExit(CECFGNode * PC_before)
{
  // Remember that we have taken the last node
  UpdateRecorderWithProgramExit(PC_before); 

  // Get the current scope
  CScope * scope = PC_before->Scope();

  // We should report and reset all recorders which are associated to
  // scopes at current scope and higher up in the scope graph...
  while(scope != NULL) {
    if(scope->IsFunctionScope()) {
      ReportRecorderForFunctionToCollector(scope);
      ResetRecorderForFunction(scope);
    }
    // Get the parent scope
    scope = scope->ParentScope();
  }
}

// Update recorder with the node transfer
void CFunctionRecorderHolder::
UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after) 
{
  // Update recorder with the change of program counter value
  UpdateRecorderWithProgramCounterChange(PC_before, PC_after); 

  // Check if the function scope has changed. If so, new recorders may be
  // created, recorders may be stacked and recorders results may be
  // reported to their collectors. 
  CScope * scope_before = PC_before->Scope();
  CScope * scope_after = PC_after->Scope();
  CScope * func_scope_before = scope_before->FunctionScope();
  CScope * func_scope_after = scope_after->FunctionScope();
  if(func_scope_before != func_scope_after) {
    // Check if we have left the scope to a subordinate function scope. 
    if(scope_before->IsAncestorOf(scope_after)) {
      // Loop upwards from scope_after until we reach the scope_before
      CScope * parent_to_scope_after = scope_after->ParentScope();
      assert(parent_to_scope_after);
      // Create recorders for the intermediate function
      // scopes if needed
      while(parent_to_scope_after != scope_before) {
        if(parent_to_scope_after->IsFunctionScope()) {
          CreateRecorderForFunctionScopeIfNeeded(parent_to_scope_after);
        }
        parent_to_scope_after = parent_to_scope_after->ParentScope();
      }
      // Finally, create the recorder for the after scope
      if(scope_after->IsFunctionScope()) {
        CreateRecorderForFunctionScopeIfNeeded(scope_after);
      }
    }
    
    // Else, we have left the scope to an ancestor scope or to a scope
    // which is a sibling to a common ancestor scope
    else {
      // Report the recorder to its collector, and then reset it
      ReportRecorderForFunctionToCollector(scope_before);
      ResetRecorderForFunction(scope_before);
      // Loop upwards until we reach the new scope or until we reach a
      // common ancestoral scope
      CScope * parent_to_scope_before = scope_before->ParentScope();
      while((parent_to_scope_before != scope_after) && 
            (!(parent_to_scope_before->IsAncestorOf(scope_after)))) {
        // Report the recorder to its collector, and then reset it
        if(parent_to_scope_before->IsFunctionScope()) {
          ReportRecorderForFunctionToCollector(parent_to_scope_before);
          ResetRecorderForFunction(parent_to_scope_before);
        }
        // Iterate upwards
        parent_to_scope_before = parent_to_scope_before->ParentScope();
      }
      // Check if we have should go down to a subordinate scope of parent_to_scope_before
      if(scope_after != parent_to_scope_before) {
        // Loop upwards until we reach the common ancestor scope
        CScope * common_ancestor_scope = scope_after->ParentScope();
        assert(common_ancestor_scope);
        // Create recorders for the intermediate function scopes
        while(common_ancestor_scope != parent_to_scope_before) {
          if(common_ancestor_scope->IsFunctionScope()) {
            CreateRecorderForFunctionScopeIfNeeded(common_ancestor_scope);
          }
          common_ancestor_scope = common_ancestor_scope->ParentScope();
        }
        // Finally, create the recorder for the after scope
        if(scope_after->IsFunctionScope()) {
          CreateRecorderForFunctionScopeIfNeeded(scope_after);
        }
      }
    }
  }
}


// This function helps us implement reuse of recorders. Basically, if
// there already exists a recorder for the scope we will use this one
// instead of creating a new.
void
CFunctionRecorderHolder:: 
CreateRecorderForFunctionScopeIfNeeded(CScope * scope)
{
  if(_saved_recorders.find(scope) == _saved_recorders.end()) {
    CRecorder * rec = _recorder_server->CreateRecorder();
    _saved_recorders[scope] = rec;
  }
}
  
void
CFunctionRecorderHolder:: 
ResetRecorderForFunction(CScope * scope)
{
  CRecorder * recorder = _saved_recorders[scope];
  assert(recorder);
  _recorder_server->ResetRecorder(&recorder);
  _saved_recorders[scope] = recorder;
}

void
CFunctionRecorderHolder:: 
ReportRecorderForFunctionToCollector(CScope * scope)
{
  CRecorder * recorder = _saved_recorders[scope];
  CCollector * collector = (*_func_scope_to_collector_map)[scope];
  assert(recorder);
  assert(collector);
  collector->Report(recorder);
}

// For copying the scope local header node count recorder holder
CFunctionRecorderHolder *
CFunctionRecorderHolder::
Copy(void)
{
  // First, create a new recorder holder object
  CFunctionRecorderHolder * new_rec_holder =
    new CFunctionRecorderHolder(_func_scope_to_collector_map, _recorder_server);

  // Secondly, copy the saved node count recorders
  CopySavedRecorders(&(_saved_recorders), &(new_rec_holder->_saved_recorders));
  
  // Return the created object
  return new_rec_holder;
}


// Help function for copying saved recorders
void
CFunctionRecorderHolder::
CopySavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders, 
                   std::map<CScope *, CRecorder *> * new_saved_recorders)
{
  // Copy each of the recorders and insert them into the map 
  for(std::map<CScope *, CRecorder *>::iterator s2r = saved_recorders->begin();
      s2r != saved_recorders->end(); s2r++) {
    CScope * s = (*s2r).first;
    CRecorder * r = (*s2r).second;
    assert(r);
    CRecorder * new_r = _recorder_server->CopyRecorder(r);
    (*new_saved_recorders)[s] = new_r;
  }
}

// For merging the scope local header node count recorder holder
CFunctionRecorderHolder *
CFunctionRecorderHolder::
Merge(CRecorderHolder * other_rec_holder)
{
  // Create a new recorder holder object
  CFunctionRecorderHolder * new_rec_holder =
    new CFunctionRecorderHolder(_func_scope_to_collector_map, _recorder_server);

  // Merge the internal map of saved record holders and store in 
  MergeSavedRecorders(&(_saved_recorders), 
                      &((dynamic_cast<CFunctionRecorderHolder *>(other_rec_holder))->_saved_recorders), 
                      &(new_rec_holder->_saved_recorders));
		      
  // Return the created object
  return new_rec_holder;
}

// Help function for merging saved recorders
void
CFunctionRecorderHolder::
MergeSavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders1, 
                    std::map<CScope *, CRecorder *> * saved_recorders2,
                    std::map<CScope *, CRecorder *> * new_saved_recorders)
{
  // Merge each of the saved recorders.
  for(std::map<CScope *, CRecorder *>::iterator s2r = saved_recorders1->begin();
      s2r != saved_recorders1->end(); s2r++) {
    CScope * s = (*s2r).first;
    CRecorder * r1 = (*s2r).second;
    assert(r1 != 0);
    map<CScope *, CRecorder *>::iterator r2it = saved_recorders2->find(s);
    // If saved_recorders2 does not have the recorder, we assume it is a
    // garbage recorder that is only kept around for caching purposes, so skip it
    if (r2it != saved_recorders2->end())
    {
       CRecorder * r2 = r2it->second;
       CRecorder * new_r = _recorder_server->MergeRecorders(r1, r2);
       (*new_saved_recorders)[s] = new_r;
    }
  }
}

void 
CFunctionRecorderHolder:: 
Print(std::ostream *o)
{
  // Loop through and print all saved recorders
  for(std::map<CScope *, CRecorder *>::iterator c2r = _saved_recorders.begin();
      c2r != _saved_recorders.end(); c2r++) {
    // Get the scope and the recorder 
    CScope * scope = (*c2r).first;
    CRecorder * rec  =(*c2r).second;
    assert(rec);
    *o << "Function scope: " << scope->Name() << std::endl;
    *o << "  Recorder: ";
    rec->Print(o);
    *o << std::endl;
  }
}

// Update recorder with program counter change
void
CFunctionRecorderHolder:: 
UpdateRecorderWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after)
{ 
  CRecorder * recorder = _saved_recorders[PC_before->Scope()->FunctionScope()];
  // Increase count of node for current recorder 
  _recorder_server->UpdateRecorderWithProgramCounterChange(&recorder, PC_before, PC_after); 
  // Associate the scope with the new recorder
  _saved_recorders[PC_before->Scope()->FunctionScope()] = recorder;
}

// Update recorder with program exit
void
CFunctionRecorderHolder:: 
UpdateRecorderWithProgramExit(CECFGNode * PC_before)
{ 
  CRecorder * recorder = _saved_recorders[PC_before->Scope()->FunctionScope()];
  // Increase count of node for current recorder 
  _recorder_server->UpdateRecorderWithProgramExit(&recorder, PC_before); 
  // Save maybe updated recorder back to scope 
  _saved_recorders[PC_before->Scope()->FunctionScope()] = recorder;
}


// =======================================================
// =======================================================
// =======================================================
// CProgramRecorderHolder 
// =======================================================
// =======================================================
// =======================================================

// To create a new scope local recorder holder, we need a way to
// associate collectors and scopes. We also need a server which will
// be used to create, delete, and update the recorders.
CProgramRecorderHolder:: 
CProgramRecorderHolder(CCollector * collector, CRecorderServer * recorder_server) 
{
  // Set needed data structures
  _collector = collector;
  _recorder_server = recorder_server;
  // Create recorder
  _recorder = _recorder_server->CreateRecorder();
}

CProgramRecorderHolder:: 
CProgramRecorderHolder(std::map<CScope *, CCollector *> * root_scope_to_collector_map, 
                      CRecorderServer * recorder_server) 
{
  // Set needed data structures
  assert(root_scope_to_collector_map->size() == 1);
  _collector = root_scope_to_collector_map->begin()->second;
  _recorder_server = recorder_server;
  // Create recorder
  _recorder = _recorder_server->CreateRecorder();
}

CProgramRecorderHolder:: 
~CProgramRecorderHolder()
{
  // Delete recorder (it should have been reported in during the
  // UpdateWithProgramExit()
  if(_recorder) _recorder_server->DeleteRecorder(_recorder);
}

void
CProgramRecorderHolder:: 
UpdateWithProgramStart(CECFGNode * PC_after)
{
  // Do nothing, the recorder has already been created
}

// When we end the execution we should also create a scope local recorder
void
CProgramRecorderHolder:: 
UpdateWithProgramExit(CECFGNode * PC_before)
{
  // We only report at the end of the program
  _recorder_server->UpdateRecorderWithProgramExit(&_recorder, PC_before);
  _collector->Report(_recorder);  
}

// Update recorder with the node transfer
void CProgramRecorderHolder::
UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after) 
{
  // Update recorder with the change of program counter value
  _recorder_server->UpdateRecorderWithProgramCounterChange(&_recorder, PC_before, PC_after); 
}

// For copying the scope local header node count recorder holder
CProgramRecorderHolder *
CProgramRecorderHolder::
Copy(void)
{
  // First, create a new recorder holder object
  CProgramRecorderHolder * new_rec_holder = new CProgramRecorderHolder(_collector, _recorder_server);

  // Secondly, copy and set the recorder
  new_rec_holder->_recorder = _recorder_server->CopyRecorder(_recorder);
  
  // Return the created object
  return new_rec_holder;
}

// For merging the scope local header node count recorder holder
CProgramRecorderHolder *
CProgramRecorderHolder::
Merge(CRecorderHolder * other_rec_holder)
{
  // First, create a new recorder holder object
  CProgramRecorderHolder * new_rec_holder = new CProgramRecorderHolder(_collector, _recorder_server);

  // Secondly, merge the two recorders and store as the new recorder
  // in the resulting recorder holder
  new_rec_holder->_recorder = 
    _recorder_server->MergeRecorders(_recorder, 
                                     (dynamic_cast<CProgramRecorderHolder *>(other_rec_holder))->_recorder);

  // Return the created object
  return new_rec_holder;
}
  
void 
CProgramRecorderHolder:: 
Print(std::ostream *o)
{
  // Print the recorder 
  *o << "Global recorder: ";
  assert(_recorder);
  _recorder->Print(o);
  *o << std::endl;
}

// =======================================================
// =======================================================
// =======================================================
// CLoopNestRecorderHolder
// =======================================================
// =======================================================
// =======================================================

// To create a new scope local recorder holder, we need a way to
// associate collectors and scopes. We also need a server which will
// be used to create, delete, and update the recording.
CLoopNestRecorderHolder:: 
CLoopNestRecorderHolder(std::map<CScope *, CCollector *> * loop_nest_root_scope_to_collector_map, 
                        CRecorderServer * recorder_server) 
{
  // Set needed data structures
  _loop_nest_root_scope_to_collector_map = loop_nest_root_scope_to_collector_map;
  _recorder_server = recorder_server;
}

CLoopNestRecorderHolder:: 
~CLoopNestRecorderHolder()
{
  // At deletion, we should delete all recorders that we do not need
  // any longer.

  // Delete all stacked recorders
  for(std::map<CScope *, CRecorder *>::iterator c2r = _saved_recorders.begin();
      c2r != _saved_recorders.end(); c2r++) {
    // Get the recorder and delete it
    CRecorder * rec = (*c2r).second;
    _recorder_server->DeleteRecorder(rec);
  }
  // delete _loop_nest_root_scope_to_collector_map;
}

// When we start the execution we should also create a scope local recorder
void
CLoopNestRecorderHolder:: 
UpdateWithProgramStart(CECFGNode * PC_after)
{
   // Make sure that the stack is empty
   assert(_saved_recorders.size() == 0);
   // Create new recorders for the scope and its ancestors
   for (CScope * s = PC_after->Scope(); s != 0; s = s->ParentScope())
      CreateRecorderForLoopNestRootScopeIfNeeded(s);  
}

// When we end the execution we should also create a scope local recorder
void
CLoopNestRecorderHolder:: 
UpdateWithProgramExit(CECFGNode * PC_before)
{
  // Get the current scope
  CScope * scope = PC_before->Scope();

  // We should report and reset all recorders which are associated to
  // scopes at current scope and higher up in the scope graph...
  while(scope != NULL) {
    if(scope->IsLoopScope() && scope->LoopNestRootScope() == scope) {
      ReportRecorderForLoopNestToCollector(scope);
      ResetRecorderForLoopNest(scope);
    }
    // Get the parent scope
    scope = scope->ParentScope();
  }
}

// Update recorder with the node transfer
void CLoopNestRecorderHolder::
UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after) 
{
  // Update recorder with the change of program counter value
  UpdateRecorderWithProgramCounterChange(PC_before, PC_after); 

  // Check if the loop nest scope has changed, ie. we have jumped in
  // our out of a new loop scope nest. If so, new recorders may be
  // created, recorders may be stacked and recorders results may be
  // reported to their collectors.
  CScope * scope_before = PC_before->Scope();
  CScope * scope_after = PC_after->Scope();
  // Get the loop nest the scopes belong to (if any).
  CScope * loop_nest_root_scope_before = scope_before->LoopNestRootScope();
  CScope * loop_nest_root_scope_after = scope_after->LoopNestRootScope();
  if((scope_before != scope_after) && 
     (loop_nest_root_scope_before != loop_nest_root_scope_after)) {
    // Check if we have left the scope to a subordinate scope. 
    if(scope_before->IsAncestorOf(scope_after)) {
      // Loop upwards from scope_after until we reach the scope_before
      CScope * parent_to_scope_after = scope_after->ParentScope();
      assert(parent_to_scope_after);
      // Create recorders for the intermediate root loop nest function
      // scopes if needed
      while(parent_to_scope_after != scope_before) {
        if(parent_to_scope_after->IsLoopNestRootScope()) {
          CreateRecorderForLoopNestRootScopeIfNeeded(parent_to_scope_after);
        }
        parent_to_scope_after = parent_to_scope_after->ParentScope();
      }
      // Create recorders for the after scope if needed
      if(scope_after->IsLoopNestRootScope()) {
        CreateRecorderForLoopNestRootScopeIfNeeded(scope_after);
      }
    }
    
    // Else, we have left the scope to an ancestor scope or to a scope
    // which is a sibling to a common ancestor scope
    else {
      if(scope_before->IsLoopNestRootScope()) {
        // Report the recorder to its collector, and then reset it
        ReportRecorderForLoopNestToCollector(scope_before);
        ResetRecorderForLoopNest(scope_before);
      }
      // Loop upwards until we reach the new scope or until we reach a
      // common ancestoral scope
      CScope * parent_to_scope_before = scope_before->ParentScope();
      while((parent_to_scope_before != scope_after) && 
            (!(parent_to_scope_before->IsAncestorOf(scope_after)))) {
        // Report the recorder to its collector, and then reset it
        if(parent_to_scope_before->IsLoopNestRootScope()) {
          ReportRecorderForLoopNestToCollector(parent_to_scope_before);
          ResetRecorderForLoopNest(parent_to_scope_before);
        }
        // Iterate upwards
        parent_to_scope_before = parent_to_scope_before->ParentScope();
      }
      // Check if we have should go down to a subordinate scope of parent_to_scope_before
      if(scope_after != parent_to_scope_before) {
        // Loop upwards until we reach the common ancestor scope
        CScope * common_ancestor_scope = scope_after->ParentScope();
        assert(common_ancestor_scope);
        // Create recorders for the intermediate function scopes
        while(common_ancestor_scope != parent_to_scope_before) {
          if(common_ancestor_scope->IsLoopNestRootScope()) {
            CreateRecorderForLoopNestRootScopeIfNeeded(common_ancestor_scope);
          }
          common_ancestor_scope = common_ancestor_scope->ParentScope();
        }
        // Finally, create the recorder for the after scope if needed
        if(scope_after->IsLoopNestRootScope()) {
          CreateRecorderForLoopNestRootScopeIfNeeded(scope_after);
        }
      }
      else {
        // We do not need to do anything, i.e. the recorder for the 
        // after scope should already have been created, e.g. for E->A
        // or D->A a recorder for A should already have been created. 
      }
    }
  }
}


// This function helps us implement reuse of recorders. Basically, if
// there already exists a recorder for the scope we will use this one
// instead of creating a new.
void
CLoopNestRecorderHolder:: 
CreateRecorderForLoopNestRootScopeIfNeeded(CScope * scope)
{
  if(_saved_recorders.find(scope) == _saved_recorders.end()) {
    CRecorder * rec = _recorder_server->CreateRecorder();
    _saved_recorders[scope] = rec;
  }
}
  
void
CLoopNestRecorderHolder:: 
ResetRecorderForLoopNest(CScope * scope)
{
  CRecorder * recorder = _saved_recorders[scope];
  assert(recorder);
  _recorder_server->ResetRecorder(&recorder);
  _saved_recorders[scope] = recorder;
}

void
CLoopNestRecorderHolder:: 
ReportRecorderForLoopNestToCollector(CScope * scope)
{
  CRecorder * recorder = _saved_recorders[scope];
  CCollector * collector = (*_loop_nest_root_scope_to_collector_map)[scope];
  assert(recorder);
  assert(collector);
  collector->Report(recorder);
}

// For copying the scope local header node count recorder holder
CLoopNestRecorderHolder *
CLoopNestRecorderHolder::
Copy(void)
{
  // First, create a new recorder holder object
  CLoopNestRecorderHolder * new_rec_holder =
    new CLoopNestRecorderHolder(_loop_nest_root_scope_to_collector_map, _recorder_server);

  // Secondly, copy the saved node count recorders
  CopySavedRecorders(&(_saved_recorders), &(new_rec_holder->_saved_recorders));
  
  // Return the created object
  return new_rec_holder;
}


// Help function for copying saved recorders
void
CLoopNestRecorderHolder::
CopySavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders, 
                   std::map<CScope *, CRecorder *> * new_saved_recorders)
{
  // Copy each of the recorders and insert them into the map 
  for(std::map<CScope *, CRecorder *>::iterator s2r = saved_recorders->begin();
      s2r != saved_recorders->end(); s2r++) {
    CScope * s = (*s2r).first;
    CRecorder * r = (*s2r).second;
    assert(r);
    CRecorder * new_r = _recorder_server->CopyRecorder(r);
    (*new_saved_recorders)[s] = new_r;
  }
}

// For merging the scope local header node count recorder holder
CLoopNestRecorderHolder *
CLoopNestRecorderHolder::
Merge(CRecorderHolder * other_rec_holder)
{
  // Create a new recorder holder object
  CLoopNestRecorderHolder * new_rec_holder =
    new CLoopNestRecorderHolder(_loop_nest_root_scope_to_collector_map, _recorder_server);

  // Merge the internal map of saved record holders and store in 
  MergeSavedRecorders(&(_saved_recorders), 
                      &((dynamic_cast<CLoopNestRecorderHolder *>(other_rec_holder))->_saved_recorders), 
                      &(new_rec_holder->_saved_recorders));
		      
  // Return the created object
  return new_rec_holder;
}

// Help function for merging saved recorders
void
CLoopNestRecorderHolder::
MergeSavedRecorders(std::map<CScope *, CRecorder *> * saved_recorders1, 
                    std::map<CScope *, CRecorder *> * saved_recorders2,
                    std::map<CScope *, CRecorder *> * new_saved_recorders)
{
  // Merge each of the saved recorders.
  for(std::map<CScope *, CRecorder *>::iterator s2r = saved_recorders1->begin();
      s2r != saved_recorders1->end(); s2r++) {
    CScope * s = (*s2r).first;
    CRecorder * r1 = (*s2r).second;
    assert(r1 != 0);
    map<CScope *, CRecorder *>::iterator r2it = saved_recorders2->find(s);
    // If saved_recorders2 does not have the recorder, we assume it is a
    // garbage recorder that is only kept around for caching purposes, so skip it
    if (r2it != saved_recorders2->end())
    {
       CRecorder * r2 = r2it->second;
       CRecorder * new_r = _recorder_server->MergeRecorders(r1, r2);
       (*new_saved_recorders)[s] = new_r;
    }
  }
}

void 
CLoopNestRecorderHolder:: 
Print(std::ostream *o)
{
  // Loop through and print all saved recorders
  for(std::map<CScope *, CRecorder *>::iterator c2r = _saved_recorders.begin();
      c2r != _saved_recorders.end(); c2r++) {
    // Get the scope and the recorder 
    CScope * scope = (*c2r).first;
    CRecorder * rec  =(*c2r).second;
    assert(rec);
    *o << "Loo nest root scope: " << scope->Name() << std::endl;
    *o << "  Recorder: ";
    rec->Print(o);
    *o << std::endl;
  }
}


// Update recorder with program counter change
void
CLoopNestRecorderHolder:: 
UpdateRecorderWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after)
{ 
  // We must must be within a loop scope
  if(!(PC_before->Scope()->IsLoopScope())) {
    return;
  }
  else {
    // Derive the scope which is the root of the loop nest
    CScope * loop_nest_root_scope = PC_before->Scope()->LoopNestRootScope();
    // Get its corresponding recorder
    CRecorder * recorder = _saved_recorders[loop_nest_root_scope];
    // Increase count of node for current recorder 
    _recorder_server->UpdateRecorderWithProgramCounterChange(&recorder, PC_before, PC_after); 
     // Associate the scope with the new recorder
    _saved_recorders[loop_nest_root_scope] = recorder;
  }
}

// =======================================================
// =======================================================
// =======================================================
// CScopeIndexRecorderHolder
// =======================================================
// =======================================================
// =======================================================

class CScopeIndexRecorderHolder::CompareScopeIterCountPairs
{
public:
   bool operator()(const std::pair<CScope *, unsigned int> & a,
                   const std::pair<CScope *, unsigned int> & b)
   {
      assert(a.first == b.first);
      return a.second < b.second;
   }
};

CScopeIndexRecorderHolder::
CScopeIndexRecorderHolder(void)
{
  // Do nothing
}

CScopeIndexRecorderHolder::
~CScopeIndexRecorderHolder(void)
{
  // Do nothing, the vector wil be automatically deleted
}

// For checking if a scope index recorder is equal to another. 
bool 
CScopeIndexRecorderHolder::
IsEqual(CScopeIndexRecorderHolder * sirh)
{
  // If the vectors are equal and they are at the same PC, then they are eqaul
  return (_siv == sirh->_siv);
}

bool 
CScopeIndexRecorderHolder::IsLessThan(const CScopeIndexRecorderHolder * sirh) const
{
   return lexicographical_compare(this->_siv.begin(), this->_siv.end(),
                                  sirh->_siv.begin(), sirh->_siv.end(), 
                                  CompareScopeIterCountPairs());
}

// For checking if the scope index recorder is empty
bool 
CScopeIndexRecorderHolder::
IsEmpty()
{
  return _siv.empty();
}

// For copying a scope index record holder 
CScopeIndexRecorderHolder * 
CScopeIndexRecorderHolder::
Copy(void)
{
  CScopeIndexRecorderHolder * sirh = new CScopeIndexRecorderHolder();
  sirh->_siv = _siv;
  return sirh;
}

// To start a program execution
void 
CScopeIndexRecorderHolder::
UpdateWithProgramStart(CECFGNode * PC_after)
{
   // Loop upwards from the start scope through all its ancestors,
   // and push the nodes on a stack so that they appear in the top-down
   // order, then run through this stack from top to bottom
   // and create recorders for the scopes
   stack<CScope *> ancestors;
   for (CScope * s = PC_after->Scope(); s != 0; s = s->ParentScope())
      ancestors.push(s);
   while (!ancestors.empty())
   {
      AddScopeIterationPair(ancestors.top());
      ancestors.pop();
   }
}

// To exit a program execution
void
CScopeIndexRecorderHolder::
UpdateWithProgramExit(CECFGNode * PC_before)
{
  // Reset the vector
  _siv.erase(_siv.begin(), _siv.end());
}

// Example of scope hierarchy used to illustrate the different cases 
// of scope change. The scopes forms a tree.
//
//       A
//      / |
//     B  D
//    /   | 
//   C    E 
// 
// To update recorder holder with a PC change 
void 
CScopeIndexRecorderHolder::
UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after)
{
   // Check if the scope has changed. If so, new recorders may be
   // created, recorders may be stacked and recorders results may be
   // reported to their collectors. 
   CScope * scope_before = PC_before->Scope();
   CScope * scope_after = PC_after->Scope();
   if(scope_before != scope_after) {

      // Check if we have left the scope to a subordinate scope,
      // e.g. A->D or A->E
      if(scope_before->IsAncestorOf(scope_after)) {
         // Loop upwards from the after scope until the before scope is reached,
         // and push the nodes on a stack so that they appear in the before-scope-to-
         // after-scope order, then run through this stack from top to bottom
         // and create recorders for these intermediate scopes if needed, 
         // e.g. scope D in case A->E
         stack<CScope *> ancestors;
         for (CScope * s = scope_after; s != scope_before; s = s->ParentScope())
            ancestors.push(s);
         while (!ancestors.empty())
         {
            AddScopeIterationPair(ancestors.top());
            ancestors.pop();
         }
      }
      // Else, we have left the scope to an ancestor scope, e.g. E->A or
      // D-A or to a scope which is a sibling to a common ancestor
      // scope, e.g D->B or E->C
      else {
         // Reset the counter for the before scope 
         RemoveScopeIterationPair(scope_before);
         // Loop upwards until we reach the after scope, e.g. in E->A we
         // loop from E to D, or until we reach a common ancestoral
         // scope, e.g. in E->C we have that A is common ancestral scope
         // and we go from E to D.
         CScope * parent_to_scope_before = scope_before->ParentScope();
         while((parent_to_scope_before != scope_after) && 
               !(parent_to_scope_before->IsAncestorOf(scope_after))) {
               // Reset the counter for the scope 
               RemoveScopeIterationPair(parent_to_scope_before);
               // Iterate upwards
               parent_to_scope_before = parent_to_scope_before->ParentScope();
         }
         // Check if we have should go down to a subordinate scope of
         // parent_to_scope_before, i.e. if we go from E->C we do not 
         // need to create for A, but maybe for B and C.
         if(scope_after != parent_to_scope_before) {
            // Loop upwards from the after scope until the before scope is reached,
            // and push the nodes on a stack so that they appear in the before-scope-to-
            // after-scope order, then run through this stack from top to bottom
            // and create recorders for these intermediate scopes if needed
            stack<CScope *> ancestors;
            for (CScope * s = scope_after; s != parent_to_scope_before; s = s->ParentScope())
               ancestors.push(s);
            while (!ancestors.empty())
            {
               AddScopeIterationPair(ancestors.top());
               ancestors.pop();
            }
         }
         else {
            // We do not need to do anything, i.e. the recorder for the 
            // after scope should already have been created, e.g. for E->A
            // or D->A a recorder for A should already have been created. 
         }
      }
   }

   // If we should update the iteration count for the after scope.
   if(scope_after->IsHeader(PC_after)) {
      // For new entries of scope, the CreateRecorderForScopeIfNeeded
      // has set the scope iteration count to 1. However, if the scope
      // already is on the scope call stack, i.e. the edge goes to the
      // before scope or to an ancestor of the before scope, then we
      // should increase the iteration count by one.
      if(scope_before == scope_after || scope_after->IsAncestorOf(scope_before)) {
         // Increase the number of iterations for the target scope
         IncrementIterationOfScope(scope_after);
      }
   }
}

// To merge two record holders. 
CScopeIndexRecorderHolder * 
CScopeIndexRecorderHolder::
Merge(CRecorderHolder * rh)
{
  // Downcast and call the real merge function
  return Merge(dynamic_cast<CScopeIndexRecorderHolder *>(rh));
}

CScopeIndexRecorderHolder * 
CScopeIndexRecorderHolder::
Merge(CScopeIndexRecorderHolder * sirh)
{
  // Make sure that they are equal, and then return a copy of one
  assert(IsEqual(sirh));
  return Copy();
}

void
CScopeIndexRecorderHolder::
Print(std::ostream * o)
{
  for(std::vector<std::pair<CScope *, unsigned int> >::iterator s2i = _siv.begin();
      s2i != _siv.end(); s2i++) {
    // Get the content of the pair
    CScope * scope = (*s2i).first;
    unsigned int iter = (*s2i).second;
    // Print the current pair
    (*o) << "<" << scope->Name() << "," << iter << "> ";
  }
  (*o) << std::endl;
}


void 
CScopeIndexRecorderHolder::
AddScopeIterationPair(CScope * scope)
{
  // Add a new pair last in the vector
  _siv.push_back(std::make_pair(scope, (unsigned int) 1));
}  

void 
CScopeIndexRecorderHolder::
IncrementIterationOfScope(CScope * scope)
{
  // The scope should be the last poair in the vector
  unsigned int size = (unsigned)_siv.size();
  assert(size > 0);
  // Make sure that it holds the scope
  assert(_siv[size-1].first == scope);
  // Increase the iteration count with one
  (_siv[size-1].second)++;
}

void 
CScopeIndexRecorderHolder::
RemoveAllScopeIterationPairs(void)
{
  // Delete all items in the vector
  _siv.erase(_siv.begin(), _siv.end());
}

void 
CScopeIndexRecorderHolder::
RemoveScopeIterationPair(CScope * scope)
{
  // It should be the last scope pair on the stack
  assert(_siv.rbegin()->first == scope);
  _siv.pop_back();
}


