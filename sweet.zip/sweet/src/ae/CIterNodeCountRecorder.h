/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CIterNodeCountRecorder.h 326 2009-05-06 07:59:13Z msl01 $
//
// ----------------------------------------------------------------------

#ifndef CIterNodeCountRecorder_H_
#define CIterNodeCountRecorder_H_

#include <string>
#include <iostream>
#include <fstream>
#include <map>
#include <set>
#include <stdint.h>

// For getting the ecfg node
#include "../graphs/ecfg/CECFGNode.h"
#include "CRecorder.h"

//----------------------------------------------------------------------
// Forward-declare types
//----------------------------------------------------------------------
class CIterNodeCountRecorder;
class CIterNodeCountRecorderServer;
class CIterNodeCountRecorderCOWServer;
class CIterNodeCountRecorderNoReuseServer;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CIterNodeCountRecorder
// - Implemented as a set of node 
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CIterNodeCountRecorder : public CRecorder
{
public:

  //----------------------------------
  // To create and delete the recorder
  //----------------------------------
  CIterNodeCountRecorder();
  CIterNodeCountRecorder(bool record_only_basic_block_start_nodes);
  virtual ~CIterNodeCountRecorder();

  //----------------------------------
  // To update the recorder with a new execution of a node or edge
  //---------------------------------
  void IncreaseCount(CECFGNode * node);
  // Will call the more specialized IncreaseCount() function
  void UpdateWithProgramCounterChange(CECFGNode * pc_before, CECFGNode * pc_after);
  void UpdateWithProgramExit(CECFGNode * pc_before);

  //----------------------------------
  // Reset recorder. Will empty the set
  //---------------------------------
  void Reset();

  //----------------------------------
  // To copy the recorder
  //---------------------------------
  CIterNodeCountRecorder * Copy();

  //----------------------------------
  // To merge two recorders (LUB)
  //---------------------------------
  CIterNodeCountRecorder * Merge(CIterNodeCountRecorder * other_recorder);
  // Will call the more specialized Merge() function...
  CRecorder * Merge(CRecorder * other_recorder);

  // ---------------------------------
  // For printing the recorder
  // ---------------------------------
  void Print() {Print(&std::cout);};
  void Print(std::ostream * o);

  // ---------------------------------
  // To get the id set (should only be used by collector)
  // ---------------------------------
  std::set<CECFGNode *> * Nodes();

  // ---------------------------------
  // To get if only basic blocks should be recorded
  // ---------------------------------
  bool RecordOnlyBasicBlockStartNodes() {return _record_only_basic_block_start_nodes;}

protected:

  // A set of cecfg nodes
  std::set<CECFGNode *> _nodes;

  // To keep track of if only bb start nodes should be recorded. If
  // not set all nodes will be recorded
  bool _record_only_basic_block_start_nodes;

};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CIterNodeCountRecorder &a);

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CIterNodeCountRecorderServer
// - Server for generating new iter count recorders
// - To inherit from
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CIterNodeCountRecorderServer : public CRecorderServer
{
public:
  // To create a iter node count recorder server. Default behaviour is to
  // only record basic block headers. I.e. if not boolean is given
  // only the headers will be recorded. Alternatively, the behaviour
  // can be controlled by the boolean argument.
  CIterNodeCountRecorderServer();
  CIterNodeCountRecorderServer(bool record_only_basic_block_start_nodes);
  virtual ~CIterNodeCountRecorderServer() {};

  // For creating a new recorder. Will allocate the recorder and add
  // <recorderptr,1> to the map.
  CIterNodeCountRecorder * CreateRecorder();

  // For deleting a recorder. When deleting a recorder then <recorderptr, i> ->
  // <recorderptr, i-1> If i-1 == 0 then remove recorder for real.
  void DeleteRecorder(CIterNodeCountRecorder * recorder);
  // Will call the more specialized delete function...
  void DeleteRecorder(CRecorder * recorder);

  // To copy the recorder. Returns maybe a new recorder. Ie.
  // the caller should reset its _recorder to the recorder returned.
  virtual CIterNodeCountRecorder * CopyRecorder(CIterNodeCountRecorder * recorder) = 0;
  // Will call the more specialized copy function...
  CRecorder * CopyRecorder(CRecorder * recorder);

  // To increase the count of the recorder. Might return a new recorder. Ie.
  // the caller should reset its _recorder to the recorder returned.
  virtual CIterNodeCountRecorder * IncreaseCountInRecorder(CIterNodeCountRecorder * recorder,
							   CECFGNode * node) = 0;
  // Will call the more specialized increase count function...
  virtual void UpdateRecorderWithProgramCounterChange(CRecorder ** recorder, CECFGNode * pc_before, CECFGNode * pc_after);  
  virtual void UpdateRecorderWithProgramExit(CRecorder ** recorder, CECFGNode * pc_before);  
  
  // To reset the recorder. Might return a new recorder. Ie.  the
  // caller should reset its _recorder to the recorder returned.
  virtual CIterNodeCountRecorder * ResetRecorder(CIterNodeCountRecorder * recorder) = 0;
  // Will call the more specialized reset function...
  virtual void ResetRecorder(CRecorder ** recorder);
  
  // To merge two recorders. Return a new recorder.
  virtual CIterNodeCountRecorder * MergeRecorders(CIterNodeCountRecorder * recorder1,
						  CIterNodeCountRecorder * recorder2) = 0;
  // Will call the more specialized merge function...
  CRecorder * MergeRecorders(CRecorder * rec1, CRecorder * rec2);

  // For printing the server
  void Print() {Print(&std::cout);};
  void Print(std::ostream * o);

protected:
  // All recorders are accessible from server by the <recorderptr, refs> map.
  // refs is a counter holding the number of references to the recorder.
  std::map<CIterNodeCountRecorder *, int64_t> _recorder_to_refs;

  // To keep track of if only bb start nodes should be recorded. If
  // not set all nodes will be recorded
  bool _record_only_basic_block_start_nodes;

};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CIterNodeCountRecorderServer &a);


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CIterNodeCountRecorderCOWServer
// - Recorder server for generating new recorders according to
// copy on write. Most functionality is inherited from CIterNodeCountRecorderServer.
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CIterNodeCountRecorderCOWServer : public CIterNodeCountRecorderServer
{
public:
  // To create and delete the recorder server. Default behaviour is to
  // only record basic block headers. I.e. if not boolean is given
  // only the headers will be recorded. Alternatively, the behaviour
  // can be controlled by the boolean argument.
  CIterNodeCountRecorderCOWServer();
  CIterNodeCountRecorderCOWServer(bool record_only_basic_block_start_nodes);
  virtual ~CIterNodeCountRecorderCOWServer();

  // For copying the recorder using copy on write. Will not do any copying
  // right away, instead it will just update the map as: <recorderptr, i>
  // -> <recorderptr, i+1>
  CIterNodeCountRecorder * CopyRecorder(CIterNodeCountRecorder * recorder);

  // To increase a count for a node in the recorder. Might return a
  // new recorder. Ie.  the caller should reset its _recorder to the recorder
  // returned.  If <recorderptr, i> where i > 1 then copy recorder (for real),
  // do the update and return new copied and updated recorder
  // (recorderptr'). We add <recorderptr',1> to map, and update <recorderptr, i>
  // -> <recorderptr, i-1>.  else i == 1, then do the update on recorderptr
  // and return same recorderptr.
  CIterNodeCountRecorder * IncreaseCountInRecorder(CIterNodeCountRecorder * recorder, CECFGNode * node);

  // To reset the recorder. Might return a new recorder. Ie.  the
  // caller should reset its _recorder to the recorder returned. If
  // <recorderptr, i> where i > 1 then copy recorder (for real), do
  // the update and return new copied and updated recorder
  // (recorderptr'). We add <recorderptr',1> to map, and update
  // <recorderptr, i> -> <recorderptr, i-1>.  else i == 1, then do the
  // update on recorderptr and return same recorderptr.
  CIterNodeCountRecorder * ResetRecorder(CIterNodeCountRecorder * recorder);

  // To merge two recorders. Return a new recorder. If both recorders
  // are the same we will just return a pointer to the recorder and
  // increase count as <recorderptr, i> -> <recorderptr, i+1>. Otherwise
  // we make the real merge make a new <newrecorderptr, 1> and return
  // the new recorder generated.
  CIterNodeCountRecorder * MergeRecorders(CIterNodeCountRecorder * recorder1,
                                       CIterNodeCountRecorder * recorder2);

};

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CIterNodeCountRecorderNoReuseServer
// - Server implementing no reuse.
// - Most functionality is inherited from CIterNodeCountRecorderServer.
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CIterNodeCountRecorderNoReuseServer : public CIterNodeCountRecorderServer
{
public:

  // To create and delete the recorder server.  Default behaviour is to
  // only record basic block headers. I.e. if not boolean is given
  // only the headers will be recorded. Alternatively, the behaviour
  // can be controlled by the boolean argument.
  CIterNodeCountRecorderNoReuseServer();
  CIterNodeCountRecorderNoReuseServer(bool record_only_basic_block_start_nodes);
  virtual ~CIterNodeCountRecorderNoReuseServer();

  // For copying the recorder the ordinary way (ie. diretly when Copy() is called).
  // Creates a new recorder and adds <recorderptr, 1> to the map.
  CIterNodeCountRecorder * CopyRecorder(CIterNodeCountRecorder * recorder);

  // For updating the recorder the ordinary way. Will not update map.
  CIterNodeCountRecorder * IncreaseCountInRecorder(CIterNodeCountRecorder * recorder, CECFGNode * node);

  // For reseting the recorder the ordinary way.  Will not update map.
  CIterNodeCountRecorder * ResetRecorder(CIterNodeCountRecorder * recorder);

  // To merge two recorders the ordinary way. Return a new recorder
  // and adds <recorderptr, 1> to the map.
  CIterNodeCountRecorder * MergeRecorders(CIterNodeCountRecorder * recorder1,
					  CIterNodeCountRecorder * recorder2);

};

#endif
