/* -*-c++-*- */

#include "ae/CIterNodePairCollector.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "ae/CBitVector.h"
#include "flow_facts/CExpression.h"
#include "flow_facts/CFlowFact.h"
#include "flow_facts/CContextSensitiveValidAtEntryOfFlowFact.h"

#define FORALL(i,L) for ((i) = (L).begin(); (i) != (L).end(); (i)++)

// ---------------------------------
// To create the collector
// ---------------------------------
CIterNodePairCollector::
CIterNodePairCollector(CScope * scope, bool record_only_basic_block_start_nodes,
                       bool generate_mutual_exclusive_facts, 
                       bool generate_must_be_taken_together_facts)
{
  // Set the scope
  _scope = scope;
  _record_only_basic_block_start_nodes = record_only_basic_block_start_nodes;
  _generate_mutual_exclusive_facts = generate_mutual_exclusive_facts;
  _generate_must_be_taken_together_facts = generate_must_be_taken_together_facts;
  _nr_of_updates = 0;

  // Call function for initializing _start_nodes_to_consider and _node_pairs_to_taken_state
  CollectNodePairsToConsider();
}

void
CIterNodePairCollector::
CollectNodePairsToConsider(void)
{
  if(_record_only_basic_block_start_nodes) 
    {
      // Derive the node pairs to consider into temporary data structures.
      std::vector<std::pair<CECFGNode *, CECFGNode *> > temp_node_pairs_to_consider;
      std::set<CECFGNode *> temp_start_nodes_to_consider;
      DeriveNodePairsToConsider(_scope, &temp_node_pairs_to_consider, &temp_start_nodes_to_consider);

      // Reduce the number of start nodes to consider to only include bb start nodes
      for(std::set<CECFGNode *>::iterator n = temp_start_nodes_to_consider.begin();
          n != temp_start_nodes_to_consider.end(); n++) {
        if((*n)->IsBeginOfBasicBlock()) {
          _start_nodes_to_consider.insert(*n);
        }
      }
      // Reduce the number of node pairs to consider to only include bb start nodes
      for(std::vector<std::pair<CECFGNode *, CECFGNode *> >::iterator np = temp_node_pairs_to_consider.begin();
          np != temp_node_pairs_to_consider.end(); np++) {
        if((*np).first->IsBeginOfBasicBlock() && (*np).second->IsBeginOfBasicBlock()) {
          _node_pair_to_taken_state_map[make_pair((*np).first, (*np).second)] = new CTakenTogetherState();
        }
      }
    }
  else
    {
      // We should record all type of node pairs
      std::vector<std::pair<CECFGNode *, CECFGNode *> > temp_node_pairs_to_consider;
      DeriveNodePairsToConsider(_scope, &temp_node_pairs_to_consider, &_start_nodes_to_consider);
      for(std::vector<std::pair<CECFGNode *, CECFGNode *> >::iterator np = temp_node_pairs_to_consider.begin();
          np != temp_node_pairs_to_consider.end(); np++) {
        _node_pair_to_taken_state_map[make_pair((*np).first, (*np).second)] = new CTakenTogetherState();
      }
    }
}

// ---------------------------------    
// To delete the collector
// ---------------------------------
CIterNodePairCollector::
~CIterNodePairCollector(void)
{
  // Delete all the taken together states
  for(std::map<std::pair<CECFGNode *, CECFGNode *>, CTakenTogetherState *>::iterator n2s = _node_pair_to_taken_state_map.begin();
      n2s != _node_pair_to_taken_state_map.end(); ++n2s) {
    delete (*n2s).second;
  }
}

// -------------------------------------------------------
// We only want to keep track of certain node pairs in the scope, i.e.
// those pair of nodes: <n,m> where the execution first may reach n
// and then later on may reach m. Moreover, if we must reach m if n
// was taken, then we do not want to include the pair. Finally, if a
// node must during each execution of a scope, it should nopt be part
// of any node pair to consider (these infeasibel nodes are detected
// by the infeasible nodes analysis). This algorithm derives the nodes
// pairs that filfull the above requirements and stores them in the
// _node_pairs_to_taken_state set.
//
// We derive this by a top down search of all the nodes in the scope,
// basically a node is only processed when all of its predecessors has
// been processed. We stop the analysis when we come to a back-edge.
// Each node is assigned two bit vectors, a MAY and a MUST vector,
// where n.MAY holds the nodes that we may have visited before n and
// n.MUST holds the nodes that must have been visited before n. A node
// pair <n,m> should be recorded if n not in m.MUST and n in m.MAY.  A
// join between to MAY vectors is implemented as a bit-wise OR. A join
// between to MUST vectors is implemented as a bit-wise AND. We treat
// successor nodes in subscopes especially, since the MUST and MAY
// information can process through the subscopes.
//
// Finally, we derive which nodes that must be taken during an execution
// of the scope. This is made by identifying all nodes being a from node 
// to a back-edge. We then take the intersection of all these nodes MUST
// sets. The nodes that remain are all nodes that must be taken during 
// any execution of the scope. All pairs including such a node is removed 
// from the set of node pairs to consider. 
//
// The CBitVector class is used implement the bitvector. We also use
// this bitvector to keep track of nodes in the scope that we have
// been processed.
// -------------------------------------------------------
void
CIterNodePairCollector::
DeriveNodePairsToConsider(CScope * scope, 
                          std::vector<std::pair<CECFGNode *, CECFGNode *> > * node_pairs_to_consider,
                          std::set<CECFGNode *> * start_nodes_to_consider)
{
  // Hold the number of nodes encountered
  unsigned int index = 0;

  // Give an index to each ecfg node in the set
  map<CECFGNode *, unsigned  int> node_to_index_map;
  for(CScope::ecfg_nodes_iterator node = scope->ECFGNodesBegin();
      node != scope->ECFGNodesEnd(); node++, index++) {
    node_to_index_map[*node] = index;
  }

  // Additionally, add target header nodes of all the child scopes.
  // Needed since we may need to propagate information over scope
  // borders. These nodes should however not be included in the MUST
  // and MAY sets.
  std::set<CScope *> child_scopes;
  scope->ChildScopes(&child_scopes);
  for(std::set<CScope *>::iterator c = child_scopes.begin();
      c != child_scopes.end(); c++) {
    CECFGNode * header_node = (*c)->Header();
    node_to_index_map[header_node] = index;
  }
  
  // JG
  // Above: index is not incremented...?

  // Create mapping between nodes and their predecessors
  map<CECFGNode *, set<CECFGNode *> * > node_to_preds;
  map<CECFGNode *, set<CECFGNode *> * > node_to_succs;

  // Loop through all ecfg nodes in the set and initialize their predecessor and 
  // sucessor node sets
  for(map<CECFGNode *, unsigned int>::iterator n2i = node_to_index_map.begin();
     n2i != node_to_index_map.end(); n2i++)
    {
      CECFGNode * node = (*n2i).first;
      node_to_preds[node] = new set<CECFGNode *>;
      node_to_succs[node] = new set<CECFGNode *>;
    }

  // Loop through all ecfg nodes in the set to derive 
  for(map<CECFGNode *, unsigned int>::iterator n2i = node_to_index_map.begin();
      n2i != node_to_index_map.end(); n2i++)
    {
      // Get the node
      CECFGNode * node = (*n2i).first;

      // If the node has no predecessor or if the node is the header
      // in the current scope
      if(node->PredSize() == 0 || _scope->IsHeader(node)) {
        continue;
      }
      // If the node is located in the current scope
      else if(node->Scope() == scope) {

        // Loop through all predecessor nodes
        for(CECFGNode::pred_iterator pred_node = node->PredBegin();
            pred_node != node->PredEnd(); pred_node++) {

          // The node to use as the predecessor
          CECFGNode * pred_node_to_use = NULL;
          // If the predecessor node comes from the current scope
          if((*pred_node)->Scope() == scope) {
            pred_node_to_use = (*pred_node);
          }
          // If the predecessor node comes from a subordinate scope of current scope
          else if(scope->IsAncestorOf((*pred_node)->Scope())) {

            // Get its ancestor scope which is a direct child of the current scope
            CScope * walker_scope = (*pred_node)->Scope();
            while(!scope->IsParentOf(walker_scope))
              walker_scope = walker_scope->ParentScope();
            // Use the header of the child scope
            pred_node_to_use = walker_scope->Header();	    
          }
          // If the predecessor node comes from a scope not being the
          // current scope or a subordinate scope of current scope
          else {
            // Do nothing
          }
	  
          // Check if we got a valid predecessor node
          if(pred_node_to_use != NULL) {
            node_to_preds[node]->insert(pred_node_to_use);
            node_to_succs[pred_node_to_use]->insert(node);
          }
        }
      }

      // If the node is located in a subscope. We should only consider all 
      // predecessor nodes coming from the current scope or from other subscopes
      // of current scope which do not have the target node as parent.
      else if(scope->IsParentOf(node->Scope())) {
        // Loop through all predecessor nodes
        for(CECFGNode::pred_iterator pred_node = node->PredBegin();
            pred_node != node->PredEnd(); pred_node++) {
          // The node to use as the predecessor
          CECFGNode * pred_node_to_use = NULL;
          // If the predecessor node comes from the current scope 
          if((*pred_node)->Scope() == scope) {
            pred_node_to_use = (*pred_node);
          }
          // If the predecessor node comes from a scope which is the
          // node's scope or a scope which is subordinate of node's
          // scope, then the edge should be ignored
          else if(((*pred_node)->Scope() == node->Scope()) ||
                  (node->Scope()->IsAncestorOf((*pred_node)->Scope()))) {
            // Do nothing
          }

          // If the predecessor node comes from a scope not
          // subordinate of the current scope
          else if(!(scope->IsAncestorOf((*pred_node)->Scope()))) {
            // Do nothing
          }
          // The predecessor node must come from a scope subordinate
          // of the current scope not having the node's scope as
          // ancestor.
          else {
            CScope * walker_scope = (*pred_node)->Scope();
            while(!scope->IsParentOf(walker_scope))
              walker_scope = walker_scope->ParentScope();
            pred_node_to_use = walker_scope->Header();
          }

          // Check if we got a valid predecessor node
          if(pred_node_to_use != NULL) {
            node_to_preds[node]->insert(pred_node_to_use);
            node_to_succs[pred_node_to_use]->insert(node);
          }
        }
      }
    }

  // Create mappings between nodes and MUST and MAY bitvectors 
  map<CECFGNode *, CBitVector * > node_to_may_taken_nodes_map;
  map<CECFGNode *, CBitVector * > node_to_must_taken_nodes_map;
  
  unsigned int nr_of_indexes = (unsigned)node_to_index_map.size();
  for(map<CECFGNode *, unsigned int>::iterator n2i = node_to_index_map.begin();
      n2i != node_to_index_map.end(); n2i++) {  
    CECFGNode * node = (*n2i).first;
    node_to_may_taken_nodes_map[node] = new CBitVector(nr_of_indexes);
    node_to_must_taken_nodes_map[node] = new CBitVector(nr_of_indexes);
  }  

  // A bitvector holding the nodes that have been processed
  CBitVector processed_nodes(nr_of_indexes);

  // A list holding next ecfg nodes to process
  list<CECFGNode *> nodes_to_process;
  nodes_to_process.push_back(scope->Header());
  
  // Run until we have not more nodes to process
  while(!nodes_to_process.empty()) {

    // Pop a node from the set
    CECFGNode * node = nodes_to_process.front();
    nodes_to_process.pop_front();
    assert(node);

    // Get the vectors belonging to the node
    CBitVector * may_vector = node_to_may_taken_nodes_map[node];
    CBitVector * must_vector = node_to_must_taken_nodes_map[node];

    // Get the index of the node to process
    unsigned int index = node_to_index_map[node];

    // Update with all the vectors of all the predecessors  
    set<CECFGNode *> * preds = node_to_preds[node];
    // To treat first update especially
    bool first_update = true;
    for(set<CECFGNode *>::iterator pred = (*preds).begin();
        pred != (*preds).end(); pred++) {
      // Get the MAY and MUST vector of the predecessor
      CBitVector * pred_may_vector = node_to_may_taken_nodes_map[*pred];
      CBitVector * pred_must_vector = node_to_must_taken_nodes_map[*pred];
      if(first_update) {
        // Do first update especially, do bitwise OR on both vectors
        (*may_vector) += pred_may_vector;
        (*must_vector) += pred_must_vector;
        first_update = false;
      } 
      else {
        // Normal case, MAY is bitwise OR, MUST is bitwise AND
        (*may_vector) += pred_may_vector;
        (*must_vector) &= pred_must_vector;
      }
    }

    // Add the node itself to its MAY and MUST vectors
    may_vector->AddElement(index); 
    must_vector->AddElement(index); 

    // Remember that we have processed the node
    processed_nodes.AddElement(index);

    // Get all the successors to node. Only those successors that have had
    // all their predecessor nodes processed should be added to the list
    set<CECFGNode *> * succs = node_to_succs[node];
    for(set<CECFGNode *>::iterator succ = (*succs).begin(); succ != (*succs).end(); succ++) {
      bool should_be_added = true;
      set<CECFGNode *> * preds_to_succ = node_to_preds[*succ];
      for(set<CECFGNode *>::iterator pred_to_succ = (*preds_to_succ).begin();
          pred_to_succ != (*preds_to_succ).end(); pred_to_succ++) {
        int index = node_to_index_map[*pred_to_succ];
        if(!(processed_nodes.ElementExists(index))) {
          should_be_added = false;
          break;
        }
      }
      if(should_be_added == true) {
        nodes_to_process.push_back(*succ);
      }
    }
  }

  
  // Derive the nodes that must be taken during an execution of the
  // scope. This is made by identifying all nodes being a from node to
  // a back-edge. We then take the intersection of all these nodes
  // MUST sets. The nodes that remain are all nodes that must be taken
  // during any execution of the scope.   
  
  // To hold the nodes that must be processed through all executions
  // of the scope.
  CBitVector nodes_that_must_be_taken(nr_of_indexes);
  
  // Loop through all node to succ pairs
  bool first_update = true;
  for(map<CECFGNode *, set<CECFGNode *> * >::iterator n2s = node_to_succs.begin();
      n2s != node_to_succs.end(); ++n2s) {
    // Extract the elements in the pair
    CECFGNode * node = (*n2s).first;
    set<CECFGNode *> * succs = (*n2s).second;
    // Only use the nodes with no successors
    if(succs->size() > 0) 
      continue;
    // Get the must vector of the node
    CBitVector * must_vector = node_to_must_taken_nodes_map[node];
    // Treat first update especially
    if(first_update) {
      nodes_that_must_be_taken += must_vector;
      first_update = false;
    }
    else {
      nodes_that_must_be_taken &= must_vector;
    }      
  }
    
  // Derive the node pairs to consider. 

  // Loop through all nodes in the scope twice to see if the node pair
  // should be added or not
  for(CScope::ecfg_nodes_iterator first_node = scope->ECFGNodesBegin();
      first_node != scope->ECFGNodesEnd(); first_node++) {
    // If the node must be taken during all executions it should not be included
    // in any pair

    unsigned int first_index = node_to_index_map[*first_node];
    if(nodes_that_must_be_taken.ElementExists(first_index)) continue;

    // Loop through all the nodes again
    for(CScope::ecfg_nodes_iterator second_node = scope->ECFGNodesBegin();
        second_node != scope->ECFGNodesEnd(); second_node++) {  

      // The same node cannot occur twice in a pair
      if(first_node == second_node) continue;

      // If the node must be taken during all executions it should not be included
      // in any pair
      unsigned int second_index = node_to_index_map[*second_node];
      if(nodes_that_must_be_taken.ElementExists(second_index)) continue;

      // If Y not in MUST(X) and Y in MAY(X) then we should record pair X,Y 
      if(!(node_to_must_taken_nodes_map[*first_node]->ElementExists(second_index)) &&
         node_to_may_taken_nodes_map[*first_node]->ElementExists(second_index)) {
        node_pairs_to_consider->push_back(make_pair(*second_node, *first_node));
        start_nodes_to_consider->insert(*second_node);
      }
    }
  }
  
  // Delete temporary predecessor sets
  for(map<CECFGNode *, set<CECFGNode *> *>::iterator n2p = node_to_preds.begin();
      n2p != node_to_preds.end(); n2p++) 
    delete (*n2p).second;
  // Delete temporary successor sets
  for(map<CECFGNode *, set<CECFGNode *> *>::iterator n2s = node_to_succs.begin();
      n2s != node_to_succs.end(); n2s++) 
    delete (*n2s).second;

  // Delete temporary may bit vectors
  for(map<CECFGNode *, CBitVector *>::iterator n2v = node_to_may_taken_nodes_map.begin();
      n2v != node_to_may_taken_nodes_map.end(); n2v++)
    delete (*n2v).second;
  // Delete temporary must bit vectors
  for(map<CECFGNode *, CBitVector *>::iterator n2v = node_to_must_taken_nodes_map.begin();
      n2v != node_to_must_taken_nodes_map.end(); n2v++)
    delete (*n2v).second;

  // Return, since we use unique_ptr the newly allocated things
  // automatically beceomes deallocated. The result is stored in the 
  // node_pairs_to_consider and start_nodes_to_consider.
  
  return;
}


// ---------------------------------
// To update an exclusion matrix with a recording
// ---------------------------------
void
CIterNodePairCollector::
Report(int iter, CRecorder * rec)
{
  Report(iter, dynamic_cast<CIterNodeCountRecorder *>(rec));
}

void
CIterNodePairCollector:: 
Report(int iter, CIterNodeCountRecorder * rec)
{
  _nr_of_updates++;

  // The iter node count recorder should have a list of nodes processed in the scope
  set<CECFGNode *> * taken_nodes = rec->Nodes();

  // The updates has to be done somewhat different depending on if what type of flow facts
  // that should be generated. 

  // ---------------------------------
  // Do update suitable both for must_be_taken_together node pairs and
  // mutually exclusive node pairs
  // ---------------------------------
  // if(_generate_must_be_taken_together_facts) 
  {
    // Loop through all the node pairs that we should keep track of
    for(map<pair<CECFGNode *, CECFGNode *>, CTakenTogetherState * >::iterator np2s = _node_pair_to_taken_state_map.begin();
        np2s != _node_pair_to_taken_state_map.end(); np2s++) {    

      // Get the nodes
      CECFGNode * first_node = (*np2s).first.first;
      CECFGNode * second_node = (*np2s).first.second;

      // Check if they are taken or not
      bool first_node_taken = (taken_nodes->find(first_node) != taken_nodes->end());
      bool second_node_taken = (taken_nodes->find(second_node) != taken_nodes->end());

      // Get the state
      CTakenTogetherState * s = (*np2s).second;
      assert(s);

      // Update the status of the pair
      if(first_node_taken && second_node_taken) {
        s->SetMayHaveTwoSum();
      }
      else if(!first_node_taken && !second_node_taken) {
        s->SetMayHaveZeroSum();
      }
      else {
        s->SetMayHaveOneSum();
      }
    }
  }
}

// ---------------------------------
// Generate flow facts for the nodes that never has been taken together
// for any iteration of the scope.
// ---------------------------------
int 
CIterNodePairCollector:: 
GenerateFlowFacts(void)
{
  int nr_of_flow_facts = 0;

  // Loop through all the nodes that we should keep track of
  for(map<pair<CECFGNode *, CECFGNode *>, CTakenTogetherState * >::iterator np2s = _node_pair_to_taken_state_map.begin();
      np2s != _node_pair_to_taken_state_map.end(); np2s++) {

    // Check if the node pairs never have been taken together
    if(_generate_mutual_exclusive_facts && (*np2s).second->IsMutualExclusive()) {

      // Yes, we should create a scope : <> : BB1 + BB2 < 2 flow fact

      // Get the nodes
      CECFGNode * first_node = (*np2s).first.first;
      CECFGNode * second_node = (*np2s).first.second;
      // Generate expressions for the nodes
      CExpressionECFGNode *id1 = new CExpressionECFGNode(first_node);
      CExpressionECFGNode *id2 = new CExpressionECFGNode(second_node);
      CExpressionBin *expr = new CExpressionBin(id1, BINOP_ADD, id2);
      // Create the flow fact
      CFFCollector t(FOR_EACH);
      CExpressionInt *eint = new CExpressionInt(2);
      CConstraint constraint(expr, RELOP_LT, eint);
      CFlowFact flow_fact(_scope, CFlowFact::INPA, t, constraint);
      // Add the flow fact to the scope
      _scope->AddFlowFact(flow_fact);
      // Remember that we have craeted another flow fact
      nr_of_flow_facts++;
    }

    // Check if we should generate must be taken together facts as well
    if(_generate_must_be_taken_together_facts && (*np2s).second->MustBeTakenTogether()) {
      
      // Yes, we should create a scope : <> : BB1 == BB2 flow fact

      // Get the nodes
      CECFGNode * first_node = (*np2s).first.first;
      CECFGNode * second_node = (*np2s).first.second;
      // Get their names
      string first_name = first_node->GetFlowGraphNode()->Name();
      string second_name = second_node->GetFlowGraphNode()->Name();
      // Generate expressions for the nodes
      CExpressionECFGNode *id1 = new CExpressionECFGNode(first_node);
      CExpressionECFGNode *id2 = new CExpressionECFGNode(second_node);
      // Create the flow fact
      CFFCollector t(FOR_EACH);
      CConstraint constraint(id1, RELOP_EQ, id2);
      CFlowFact flow_fact(_scope, CFlowFact::INPA2, t, constraint);
      // Add the flow fact to the scope
      _scope->AddFlowFact(flow_fact);
      // Remember that we have created another flow fact
      nr_of_flow_facts++;
    }

  }
  return nr_of_flow_facts;
}

// ---------------------------------
// Take a set of collectors, merge their internals and generate
// context sensitive valid at entry of flow facts valid over CFG
// nodes. Returns the number of flow facts created. Adds created ffs
// to last argument. Collectors should be of CIterNodePairCollector type.
// ---------------------------------
int 
CIterNodePairCollector:: 
GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,
                                                std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  // Map holding all cfg node pairs that can be taken together
  std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CTakenTogetherState *> cfg_node_pair_to_taken_state_map;

  // -------------------------------------------------------
  // Create an initial map where all cfg_node pairs are mapped to not taken state
  // -------------------------------------------------------
  {
    std::set<CCollector *>::iterator c = collectors->begin();
    CIterNodePairCollector * inpc = dynamic_cast<CIterNodePairCollector *>(*c);
    for(std::map<std::pair<CECFGNode *, CECFGNode *>, CTakenTogetherState *>::iterator np2t = inpc->_node_pair_to_taken_state_map.begin();
        np2t != inpc->_node_pair_to_taken_state_map.end(); ++np2t) {
      // Create the cfg node pair from the ecfg node pair
      std::pair<CFlowGraphNode *, CFlowGraphNode *> cfg_node_pair = 
        std::make_pair((*np2t).first.first->GetFlowGraphNode(), (*np2t).first.second->GetFlowGraphNode());
      // Set initially all cfg node pairs to not taken
      cfg_node_pair_to_taken_state_map[cfg_node_pair] = new CTakenTogetherState();
    }
  }

  // -------------------------------------------------------
  // Do the merging of the collector's matrixes
  // -------------------------------------------------------
  bool collectors_updated = false;
  {
    for(std::set<CCollector *>::iterator c = collectors->begin(); c != collectors->end(); ++c) {
      CIterNodePairCollector * inpc = dynamic_cast<CIterNodePairCollector *>(*c);
      assert(inpc);
      if(inpc->NrOfReports() == 0) continue;
      collectors_updated = true;
      for(std::map<std::pair<CECFGNode *, CECFGNode *>, CTakenTogetherState *>::iterator np2t = inpc->_node_pair_to_taken_state_map.begin();
          np2t != inpc->_node_pair_to_taken_state_map.end(); ++np2t) {
        // Create the cfg node pair from the ecfg node pair
        std::pair<CFlowGraphNode *, CFlowGraphNode *> cfg_node_pair = 
          std::make_pair((*np2t).first.first->GetFlowGraphNode(), (*np2t).first.second->GetFlowGraphNode());
        // Do a bitwise or on the two taken states 
        CTakenTogetherState * taken_state = (*np2t).second;
        cfg_node_pair_to_taken_state_map[cfg_node_pair]->MergeStates(taken_state);
      }
    }
  }

  // -------------------------------------------------------
  // Create context sensitive flow facts
  // -------------------------------------------------------

  // Count on the number of flow facts created
  int nr_of_flow_facts_added = 0;

  if(collectors_updated) {
    // Loop through all the nodes that we should keep track of
    for(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CTakenTogetherState *>::iterator np2t = cfg_node_pair_to_taken_state_map.begin();
        np2t != cfg_node_pair_to_taken_state_map.end(); np2t++) {
      
      // Check if the node pairs never have been taken together
      if(_generate_mutual_exclusive_facts && (*np2t).second->IsMutualExclusive()) {
        
        // Yes, we should create a callstring: entry : <> : BB1 + BB2 < 2 flow fact
        
        // Get the cfg node names
        CFlowGraphNode * first_node = (*np2t).first.first;
        CFlowGraphNode * second_node = (*np2t).first.second;
        // Generate expressions for the nodes
        CExpressionFlowGraphNode *id1 = new CExpressionFlowGraphNode(first_node);
        CExpressionFlowGraphNode *id2 = new CExpressionFlowGraphNode(second_node);
        CExpressionBin *expr = new CExpressionBin(id1, BINOP_ADD, id2);
        // Create the flow fact
        CFFCollector * coll = new CFFCollector(FOR_EACH);
        CExpressionInt *eint = new CExpressionInt(2);
        CConstraint * constr = new CConstraint(expr, RELOP_LT, eint);
        CContextSensitiveValidAtEntryOfFlowFact * ff = 
          new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, coll, constr, CFlowFact::INPA); 

        // Add the ff to the set
        ffs->push_back(ff);
        
        // Remember that we created another flow fact
        nr_of_flow_facts_added++;
      }

      // Check if we should generate must be taken together facts as well
      if(_generate_must_be_taken_together_facts && (*np2t).second->MustBeTakenTogether()) {

        // Yes, we should create a callstring: entry : <> : BB1 == BB2 flow fact

        // Get the cfg node names
        CFlowGraphNode * first_node = (*np2t).first.first;
        CFlowGraphNode * second_node = (*np2t).first.second;
        // Generate expressions for the nodes
        CExpressionFlowGraphNode *id1 = new CExpressionFlowGraphNode(first_node);
        CExpressionFlowGraphNode *id2 = new CExpressionFlowGraphNode(second_node);
        // Create the flow fact
        CFFCollector * coll = new CFFCollector(FOR_EACH);
        CConstraint * constr = new CConstraint(id1, RELOP_EQ, id2);
        CContextSensitiveValidAtEntryOfFlowFact * ff = 
          new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, coll, constr, CFlowFact::INPA2); 

        // Add the ff to the set
        ffs->push_back(ff);
        
        // Remember that we created another flow fact
        nr_of_flow_facts_added++;
      }
    }
  }

  return nr_of_flow_facts_added;
}
    
      
// ---------------------------------
// Help functiopn for checking if a certain node pair should be recorded
// --------------------------------- 
// bool 
// CIterNodePairCollector:: 
// HasNodePairInMap(CECFGNode * first_node, CECFGNode * second_node)
// {
//   if(first_node < second_node)
//     return (_node_pair_to_taken_state_map.find(make_pair(first_node,second_node)) !=
// 	    _node_pair_to_taken_state_map.end());
//   else
//     return (_node_pair_to_taken_state_map.find(make_pair(second_node,first_node)) !=
// 	    _node_pair_to_taken_state_map.end());
// }

// // ---------------------------------
// // Help function for setting state of node pair
// // ---------------------------------
// void
// CIterNodePairCollector::
// SetNodePairInMapToMayHaveZeroSum(CECFGNode * first_node, CECFGNode * second_node)
// {
//   if(first_node < second_node)
//     _node_pair_to_taken_state_map[make_pair(first_node,second_node)]->SetMayHaveZeroSum();
//   else
//     _node_pair_to_taken_state_map[make_pair(second_node,first_node)]->SetMayHaveZeroSum();
// }

// // ---------------------------------
// // Help function for setting state of node pair
// // ---------------------------------
// void
// CIterNodePairCollector::
// SetNodePairInMapToMayHaveOneSum(CECFGNode * first_node, CECFGNode * second_node)
// {
//   if(first_node < second_node)
//     _node_pair_to_taken_state_map[make_pair(first_node,second_node)]->SetMayHaveOneSum();
//   else
//     _node_pair_to_taken_state_map[make_pair(second_node,first_node)]->SetMayHaveOneSum();
// }

// // ---------------------------------
// // Help function for setting state of node pair
// // ---------------------------------
// void
// CIterNodePairCollector::
// SetNodePairInMapToMayHaveTwoSum(CECFGNode * first_node, CECFGNode * second_node)
// {
//   if(first_node < second_node)
//     _node_pair_to_taken_state_map[make_pair(first_node,second_node)]->SetMayHaveTwoSum();
//   else
//     _node_pair_to_taken_state_map[make_pair(second_node,first_node)]->SetMayHaveTwoSum();
// }

// ---------------------------------
// Help function for printing the collector
// ---------------------------------
void
CIterNodePairCollector::
Print(ostream *o)
{
  // Print some general info
  PrintType(o);
  (*o) << "Scope: " << _scope->Name() << endl;
  // Loop through all items in the map and print them 
  for(map< pair<CECFGNode *, CECFGNode *>, CTakenTogetherState *>::iterator np2s = _node_pair_to_taken_state_map.begin();
      np2s != _node_pair_to_taken_state_map.end(); np2s++) {
    // Get the nodes
    CECFGNode * first_node = (*np2s).first.first;
    CECFGNode * second_node = (*np2s).first.second;
    // Get their names
    string first_name = first_node->GetFlowGraphNode()->Name();
    string second_name = second_node->GetFlowGraphNode()->Name();    
    // Get the take or not taken status
    CTakenTogetherState * s = (*np2s).second;
    // Print the pair and the state
    (*o) << "  <" << first_name << "," << second_name << "> : ";
    s->PrintBinary(o);
    (*o) << endl;
  } 
}


// -------------------------------------------------------
// CIterMutualExclusiveNodePairCollector
// -------------------------------------------------------

// To create the class
CIterMutualExclusiveNodePairCollector::
CIterMutualExclusiveNodePairCollector(CScope * scope, bool record_only_basic_block_start_nodes)
  : CIterNodePairCollector(scope, record_only_basic_block_start_nodes, true, false)
{
  // Do nothing
}

// To print the type
void
CIterMutualExclusiveNodePairCollector::
PrintType(std::ostream *o)
{
  *o << "CIterMutualExclusiveNodePairCollector";
}

// -------------------------------------------------------
// CIterMustBeTakenTogetherNodePairCollector
// -------------------------------------------------------

// To create the class
CIterMustBeTakenTogetherNodePairCollector::
CIterMustBeTakenTogetherNodePairCollector(CScope * scope, bool record_only_basic_block_start_nodes)
  : CIterNodePairCollector(scope, record_only_basic_block_start_nodes, false, true)
{
  // Do nothing
}

// To print the type
void
CIterMustBeTakenTogetherNodePairCollector::
PrintType(std::ostream *o)
{
  *o << "CIterMustBeTakenTogetherNodePairCollector";
}

// -------------------------------------------------------
// CIterMutualExclusiveAndMustBeTakenTogetherNodePairCollector
// -------------------------------------------------------

// To create the class
CIterMutualExclusiveAndMustBeTakenTogetherNodePairCollector::
CIterMutualExclusiveAndMustBeTakenTogetherNodePairCollector(CScope * scope, bool record_only_basic_block_start_nodes)
  : CIterNodePairCollector(scope, record_only_basic_block_start_nodes, true, true)
{
  // Do nothing
}

// To print the type
void
CIterMutualExclusiveAndMustBeTakenTogetherNodePairCollector::
PrintType(std::ostream *o)
{
  *o << "CIterMutualExclusiveAndMustBeTakenTogetherNodePairCollector";
}
