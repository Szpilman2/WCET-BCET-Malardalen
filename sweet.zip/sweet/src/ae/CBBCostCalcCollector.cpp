/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CBBCostCalcCollector.cpp 1676 2010-01-22 14:50:10Z ael01 $
//
// ----------------------------------------------------------------------

#include "CBBCostCalcCollector.h"
#include "CBBCostCalcRecorder.h"
#include "flow_facts/CFlowFact.h"
#include "flow_facts/CFFCollector.h"
#include "graphs/scopes/CScope.h"
#include "graphs/ecfg/CECFGNode.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "flow_facts/CContextSensitiveValidAtEntryOfFlowFact.h"

using namespace std;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CBBCostCalcCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of collector
//----------------------------------
CBBCostCalcCollector::
CBBCostCalcCollector(CScope * scope, bool collect_only_edges_inbetween_basic_blocks,
		     bool collect_min_cost_path, bool collect_max_cost_path)
  : _scope(scope), _collect_only_edges_inbetween_basic_blocks(collect_only_edges_inbetween_basic_blocks),
    _collect_min_cost_path(collect_min_cost_path), _collect_max_cost_path(collect_max_cost_path),
    _nr_of_updates(0)
{
  // Do nothing
}

//----------------------------------
// Deletion of each a collector
//----------------------------------
CBBCostCalcCollector::
~CBBCostCalcCollector()
{
  // Do nothing
}


//----------------------------------
// To update the collector with a new recording.
//---------------------------------
void
CBBCostCalcCollector::
Update(int64_t min_cost, int64_t max_cost, 
       std::vector<CECFGNode *> * min_cost_path, std::vector<CECFGNode *> * max_cost_path)
{
  // Increase the nr of updates
  _nr_of_updates++;

  // Treat first update especially
  if(_nr_of_updates == 1) {
    _min_cost = min_cost;
    _max_cost = max_cost;
  }
  else {
    if(min_cost < _min_cost) _min_cost = min_cost;
    if(max_cost > _max_cost) _max_cost = max_cost;
  }

  // Collect min and max cost paths 
  if(_collect_min_cost_path && _min_cost == min_cost) {
    _min_cost_path = (*min_cost_path);
  }
  if(_collect_max_cost_path && _max_cost == max_cost) {
    _max_cost_path = (*max_cost_path);
  }
}

// The report function needs to be implemented
void
CBBCostCalcCollector::
Report(CRecorder * rec)
{
  CBBCostCalcRecorder * nc_rec = dynamic_cast<CBBCostCalcRecorder *>(rec);
  nc_rec->ReportToCollector(this);
}

//---------------------------------
// For printing the collector
//---------------------------------
void
CBBCostCalcCollector::
Print(std::ostream * o)
{
  (*o) << "type: " << Type() << endl;
  (*o) << "scope: " << _scope->Name() << endl;
  if(_nr_of_updates > 0) {
    (*o) << "min_cost: " << _min_cost << " max_cost: " << _max_cost << endl;

    if(_collect_min_cost_path) {
      (*o) << "min_cost_path: ";
      PrintPath(o, _min_cost_path);
    }

    if(_collect_max_cost_path) {
      (*o) << "max_cost_path: ";
      PrintPath(o, _max_cost_path);
    }
  }
  else {
    (*o) << "** never executed **" << endl;
  }
}

void
CBBCostCalcCollector::
PrintPath(std::ostream * o, std::vector<CECFGNode *> & path)
{
  for(std::vector<CECFGNode *>::iterator n = path.begin();
      n != path.end(); ++n) {
    (*o) << (*n)->GetFlowGraphNode()->Name() << " ";
  } 
}

//---------------------------------
// Alternative printing function
//---------------------------------
ostream &operator << (std::ostream &o, CBBCostCalcCollector &a)
{
  a.Print(&o);
  return o;
}



void
CBBCostCalcCollector::
PrintBCETAndWCET(std::ostream & o)
{
  if(_nr_of_updates > 0) {
    o << "BCET estimate based on BB cost lookup table: " << _min_cost << endl;
    o << "WCET estimate based on BB cost lookup table: " << _max_cost << endl;
  }
  else {
    o << "No BCET or WCET estimates generated using BB cost lookup table" << endl;
  }
}

void
CBBCostCalcCollector::
PrintBCETPath(std::ostream & o)
{
  if(_nr_of_updates > 0 && _collect_min_cost_path) {
    o << "BCET path based on BB cost lookup table: ";
    PrintPath(&o, _min_cost_path);
    o << endl;
  }
  else {
    o << "No BCET path collected" << endl;
  }
}

void
CBBCostCalcCollector::
PrintWCETPath(std::ostream & o)
{
  if(_nr_of_updates > 0 && _collect_max_cost_path) {
    o << "WCET path based on BB cost lookup table: ";
    PrintPath(&o, _max_cost_path);
    o << endl;
  }
  else {
    o << "No WCET path collected" << endl;
  }
}

void
CBBCostCalcCollector::
PrintBCETAndWCETPaths(std::ostream & o)
{
  PrintBCETPath(o);
  PrintWCETPath(o);
}

// ---------------------------------
// To get the edges to consider
// ---------------------------------
const set<pair<CECFGNode *, CECFGNode *> > *
CBBCostCalcCollector::
EdgesToConsider(void)
{
  // Set edges to consider (implemented by subclasses)
  if(_edges_to_consider.size() == 0)
    SetEdgesToConsider(&_edges_to_consider);
  return &_edges_to_consider;
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CBBCostCalcScopeCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CBBCostCalcScopeCollector::
CBBCostCalcScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
			  bool collect_min_cost_path, bool collect_max_cost_path)
  : CBBCostCalcCollector(scope, collect_only_basic_block_start_nodes,
			 collect_min_cost_path, collect_max_cost_path)
{
  // Do nothing
}

//----------------------------------
// To set the edges to consider
//---------------------------------
void
CBBCostCalcScopeCollector::
SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider)
{
 // Call the wanted function in the scope
  _scope->EdgesInScope(edges_to_consider);
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CBBCostCalcScopeAndSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CBBCostCalcScopeAndSubCollector::
CBBCostCalcScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
				bool collect_min_cost_path, bool collect_max_cost_path)
  : CBBCostCalcCollector(scope, collect_only_basic_block_start_nodes,
			 collect_min_cost_path, collect_max_cost_path)
{
  // Do nothing
}

//----------------------------------
// To set the edges to consider
//---------------------------------
void
CBBCostCalcScopeAndSubCollector::
SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider)
{
 // Call the wanted function in the scope
  _scope->EdgesInScopeAndSubScopes(edges_to_consider);
}


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CBBCostCalcScopeAndLoopSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CBBCostCalcScopeAndLoopSubCollector::
CBBCostCalcScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
				    bool collect_min_cost_path, bool collect_max_cost_path)
  : CBBCostCalcCollector(scope, collect_only_basic_block_start_nodes,
			 collect_min_cost_path, collect_max_cost_path)
{
  // Do nothing
}

//----------------------------------
// To set the edges to consider
//---------------------------------
void
CBBCostCalcScopeAndLoopSubCollector::
SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider)
{
 // Call the wanted function in the scope
  _scope->EdgesInScopeAndLoopSubScopes(edges_to_consider);
}

 
