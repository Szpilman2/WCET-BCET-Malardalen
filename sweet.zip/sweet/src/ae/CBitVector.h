/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE: File holding code for a bit-vector implementation.
//  Created by christer.sandberg@mdh.se and later modified by andreas.ewmedahl@mdh.se
//
// ----------------------------------------------------------------------
//
//  $Id: $
//
// ----------------------------------------------------------------------

#ifndef CBITVECTOR_H_
#define CBITVECTOR_H_

#include <iostream>
#include <vector>

/* These are constant definitions based on the assumption that an int has the size 32. Unfortunately there are
   no ANSI macros defining these sizes. To benefit wider ints the values has to be mofified. To compile with
   smaller sizes it is required to change sizes. */
#define NR_OF_INT_BITS 32
#define BITS_IN_INT_BITS 5
#define MASK_OF_INTBITS 0x1f


//----------------------------------------------------------------------
// CBitVector
// -- Implements a bit_vector. Allow each element in a larger set to be represented
//    by a bit in a vector of integer elements. If the bit is set then
//    this means that the element with corresponding key is contined
//    within the set. Allow for efficient implementation of
//    many program analysis algorithms.
//----------------------------------------------------------------------
class CBitVector 
{
public:
  // For creation and deletion of the bit vector. size_in_bits holds
  // the number of elements that should be possible to store in the
  // index vector
  CBitVector(unsigned size_in_bits); 
  virtual ~CBitVector(void);

  // Adds the element with the key `key' to this set
  void AddElement(unsigned key);

  // Adds the element with the key `key' to this set
  void RemoveElement(unsigned key);
  
  // Returns true if the element with the key `key' is present in this set, else false
  bool ElementExists(unsigned key) const;

  // Returns the number of elements in the set.
  int NrOfElements(void);

  /* This is the union operator (i.e. bit-wise OR). The elements in theother will be
     included in this after the operation. A pointer to this will be returned. */
  CBitVector *operator+(const CBitVector *theother);
  inline void operator+=(const CBitVector *theother) { *this + theother; }

  /* This is the complement operator. Only elements that are not present
     in the other will be left in this after the operation. A pointer to this will be returned. */
  CBitVector *operator-(const CBitVector *theother);
  inline void operator-=(const CBitVector *theother) { *this - theother; }

   /* This is the intersection & operator (i.e. bit-wise AND). Only elements that are present
      in both the other and in this will be left after the operation. A pointer to this will be returned. */
  CBitVector *operator&(const CBitVector *theother);
  inline void operator&=(const CBitVector *theother) { *this & theother; }

  /* For printing the vector */
  void PrintElements(std::ostream *o) const;
  void PrintBinary(std::ostream *o) const;

  /* To get a copy of the vector */
  virtual CBitVector * Copy() const;

  /* To get if two vetcors are equal */
  bool IsEqual(const CBitVector *theother) const;

  // To get the size of the bitvector in bits
  unsigned int SizeInBits() const { return _size_in_bits; }

    virtual std::ostream& Print(std::ostream& o) const { return o; }
   
	virtual bool IsBottom() const {return false;}


protected:

  // The vector of integers that holds all the bits
  std::vector<unsigned> _bit_vector;
  unsigned int _size_in_bits;

};

// -------------------------------------------------------
// CBitVectorWithBotWithBot 
// - Help class used in dfa analysis. In MUST analysis we must have the possibility 
// to have an invalid bit vector. Then we can avoid including those in a join.  
// -------------------------------------------------------
class CBitVectorWithBot : public CBitVector
{
public:
  CBitVectorWithBot(int size_in_bits, bool is_bot=false) : CBitVector(size_in_bits), _is_bot(is_bot) { };
  ~CBitVectorWithBot() {}
  CBitVectorWithBot * Copy() const;
  bool IsBot() const { return _is_bot; }

protected:
  bool _is_bot;
};

#endif
