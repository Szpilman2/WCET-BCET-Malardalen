/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE: A class to inherit from. Exports functionality that all
//  collectors must export. 
//
// ----------------------------------------------------------------------
//
//  $Id: $
//
// ----------------------------------------------------------------------

#ifndef CCollector_H_
#define CCollector_H_

// Standard includes
#include <string>
#include <map>
#include <vector>
#include <set>
#include <iostream>
#include <fstream>

class CRecorder;
class CGenericFunction;
class CGenericStmt;
class CContextSensitiveValidAtEntryOfFlowFact;

class CCollector
{
public:
   virtual ~CCollector() {};
   // At least one of the Update functions should be supported
   virtual void Report(CRecorder * rec) = 0; // Report recorded data to the collector
   virtual void Report(int iter, CRecorder * rec) = 0; // As above, but with iteration number included
   virtual int NrOfReports() = 0; // To get the number of reports that have been made to collector
   virtual int GenerateFlowFacts(void) = 0; // Returns the number fo flow facts generated
   // Take a set of collectors, merge their internals and generate
   // context sensitive valid at entry of flow facts valid over CFG
   // nodes. Returns the number of flow facts created. Adds created ffs
   // to last argument. All collectors should be of the same type as the called collector.
   virtual int GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                               std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                               std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,
                                                               std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs) = 0;
   virtual void Print(std::ostream *o=&std::cout) = 0;  
  friend std::ostream & operator << (std::ostream &o, CCollector &c) { c.Print(&o); return o; }
};

#endif
