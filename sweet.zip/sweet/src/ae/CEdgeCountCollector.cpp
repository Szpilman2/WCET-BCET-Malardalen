/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CEdgeCountCollector.cpp 7975 2018-11-23 15:24:04Z lkg02 $
//
// ----------------------------------------------------------------------

#include "CEdgeCountCollector.h"
#include "CEdgeCountRecorder.h"
#include "flow_facts/CFlowFact.h"
#include "flow_facts/CFFCollector.h"
#include "flow_facts/CIndexRange.h"
#include "graphs/scopes/CScope.h"
#include "flow_facts/CExpression.h"
#include "graphs/ecfg/CECFGNode.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "program/CGenericFunction.h"
#include "program/CGenericStmt.h"
#include "flow_facts/CContextSensitiveValidAtEntryOfFlowFact.h"

using namespace std;

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CEdgeCountCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------
// Creation of collector
//----------------------------------
CEdgeCountCollector::
CEdgeCountCollector(CScope * scope, bool collect_only_edges_inbetween_basic_blocks,
                    bool sum_edges_in_constraint, bool generate_lower_bound_ffs, bool generate_upper_bound_ffs)
  : _scope(scope), _collect_only_edges_inbetween_basic_blocks(collect_only_edges_inbetween_basic_blocks),
    _sum_edges_in_constraint(sum_edges_in_constraint),
    _generate_lower_bound_ffs(generate_lower_bound_ffs),
    _generate_upper_bound_ffs(generate_upper_bound_ffs)
{
  _nr_of_updates = 0;
}

//----------------------------------
// Deletion of each a collector
//----------------------------------
CEdgeCountCollector::
~CEdgeCountCollector()
{
  // Go through the map deleting all the ranges
  std::map<std::pair<CECFGNode*, CECFGNode*>,CIntegerRange*>::iterator n2r;
  FORALL(n2r, _edge_to_range_map)
    delete (*n2r).second;

  // The map itself will be removed together with the ocollector
}


//----------------------------------
// To update the collector with a new recording.
//---------------------------------
void
CEdgeCountCollector::
Update(std::map<std::pair<CECFGNode*, CECFGNode*>,CIntegerRange*> * edge_to_range_recording)
{
  //   std::map<std::pair<CECFGNode*, CECFGNode*>,CIntegerRange*>::iterator e2m;
  //   FORALL(e2m, (*edge_to_range_recording)) {
  //     cout << (*e2m).first.first->GetFlowGraphNode()->Name() << "->"
  //          << (*e2m).first.second->GetFlowGraphNode()->Name() << " range: " 
  //          << *((*e2m).second) << endl;
  //   }
  //   cout << "CEdgeCountCollector::Update _edges_to_consider: \n";
  //   std::set<std::pair<CECFGNode*, CECFGNode*> >::iterator e;
  //   FORALL(e, _edges_to_consider) {
  //     cout << (*e).first->GetFlowGraphNode()->Name() << "->"
  //          << (*e).second->GetFlowGraphNode()->Name() << endl;
  //   }
  //   cout << endl;

  // Increase the nr of updates
  _nr_of_updates++;

  // Treat first update especially
  if(_nr_of_updates == 1)
    {
      // Set edges to consider (implemented by subclasses)
      if(_edges_to_consider.size() == 0) {
        // If all type of edges should be collected
        if(!_collect_only_edges_inbetween_basic_blocks) {
          SetEdgesToConsider(&_edges_to_consider);
        }
        else {
          // if only edges going inbetween basic blocks should be collected
          std::set<std::pair<CECFGNode*, CECFGNode*> > temp_edges_to_consider;
          SetEdgesToConsider(&temp_edges_to_consider);
          for(std::set<std::pair<CECFGNode*, CECFGNode*> >::iterator e = temp_edges_to_consider.begin();
              e != temp_edges_to_consider.end(); e++) {
            if((*e).second->IsBeginOfBasicBlock()) {
              _edges_to_consider.insert(*e);
            }
          }
        }
      }

      // Go through all edges to consider
      set<pair<CECFGNode *, CECFGNode *> >::iterator edge;
      FORALL(edge, _edges_to_consider)
        {
          // Check if the edge exists in the recording
          if(edge_to_range_recording->find(*edge) != edge_to_range_recording->end())
            {
              // Copy the range
              CIntegerRange* range = (*edge_to_range_recording)[*edge];
              _edge_to_range_map[*edge] = range->Copy();
            }
          else
            {
              // Create a new range consisting of only 0..0
              CIntegerRange* range = new CIntegerRange(0,0);
              _edge_to_range_map[*edge] = range;
            }
        }
    }
  else
    {
      // Remaining updates, the range has already been added in the
      // previous update. Go through all edges in the graph
      std::map<std::pair<CECFGNode*, CECFGNode*>,CIntegerRange*>::iterator n2r;
      FORALL(n2r, _edge_to_range_map)
        {
          // Get the edge and the old range
          pair<CECFGNode *, CECFGNode *> edge = (*n2r).first;
          CIntegerRange* old_range = (*n2r).second;

          // Check if the edge exists in the recording
          if(edge_to_range_recording->find(edge) != edge_to_range_recording->end())
            {
              // Yes, update the range
              CIntegerRange* rec_range = (*edge_to_range_recording)[edge];
              CIntegerRange* new_range = old_range->Merge(rec_range);
              _edge_to_range_map[edge] = new_range;
            }
          else
            {
              // No, merge a 0..0 range with the previous range
              CIntegerRange* rec_range = new CIntegerRange(0,0);
              CIntegerRange* new_range = old_range->Merge(rec_range);
              delete rec_range;
              _edge_to_range_map[edge] = new_range;
            }

          // Delete the old range
          delete old_range;
        }
    }

  // We are done, the ranges has been merged.
  return;
}

// The report function needs to be implemented
void
CEdgeCountCollector::
Report(CRecorder * rec)
{
  CEdgeCountRecorder * nc_rec = dynamic_cast<CEdgeCountRecorder *>(rec);
  nc_rec->ReportToCollector(this);
}

// ---------------------------------
// To generate flow facts
// ---------------------------------
int
CEdgeCountCollector::
GenerateFlowFacts(void)
{
  int nr_of_added_flow_facts = 0;
  if(_generate_lower_bound_ffs) {
    CFlowFact::t_flowfacttype ff_type = GetLowerFlowFactType();
    nr_of_added_flow_facts += AddMinEdgeCountFlowFactsToScope(ff_type);
  }
  if(_generate_upper_bound_ffs) {
    CFlowFact::t_flowfacttype ff_type = GetUpperFlowFactType();
    nr_of_added_flow_facts += AddMaxEdgeCountFlowFactsToScope(ff_type);
  }
  return nr_of_added_flow_facts;
}


// ---------------------------------
// To generate context sensitive valid at entry of flow facts 
// ---------------------------------
int 
CEdgeCountCollector::
GenerateContextSensitiveValidAtEntryOfFlowFacts(std::set<CCollector *> * collectors, 
                                                std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  // Create a mapping inbetween CFG edges and ranges
  std::map<std::pair<CFlowGraphNode*, CFlowGraphNode*>,CIntegerRange*> cfg_edge_to_range_map;
  // Go through all collectors (they must be edge count collectors) and add their included ranges
  bool map_created = false;
  for(std::set<CCollector *>::iterator c = collectors->begin(); c != collectors->end(); ++c) {
    CEdgeCountCollector * ec_collector = dynamic_cast<CEdgeCountCollector *>(*c);
    assert(ec_collector);

    // If the collector have not been updated so skip it
    if(ec_collector->NrOfReports() == 0) continue;

    // Check if it was the first collector in the set
    if(!map_created) {
      // Derive a CFG node to range map for the given collector
      ec_collector->DeriveCFGEdgeToRangeMap(&cfg_edge_to_range_map);
      map_created = true;
    }
    else {
      // Derive a temporary map for the given collector
      std::map<std::pair<CFlowGraphNode*, CFlowGraphNode*>,CIntegerRange*> temp_cfg_edge_to_range_map;
      ec_collector->DeriveCFGEdgeToRangeMap(&temp_cfg_edge_to_range_map);
      // Merge the old and temporary mappings
      for(std::map<std::pair<CFlowGraphNode*, CFlowGraphNode*>,CIntegerRange*>::iterator tce2r = temp_cfg_edge_to_range_map.begin();
          tce2r != temp_cfg_edge_to_range_map.end(); ++tce2r) {
        // Merge new and old range for cfg node
        std::pair<CFlowGraphNode*, CFlowGraphNode*> cfg_edge = (*tce2r).first;
        CIntegerRange * range = (*tce2r).second;
        CIntegerRange * old_range = NULL;
        if(cfg_edge_to_range_map.find(cfg_edge) == cfg_edge_to_range_map.end()) {
          // We had that the old map did not include this particular edge
          old_range = new CIntegerRange(0,0);
        } else {
          old_range = cfg_edge_to_range_map[cfg_edge];
        }
        CIntegerRange * new_range = range->Merge(old_range);
        cfg_edge_to_range_map[cfg_edge] = new_range;
        // Delete temporary ranges
        delete old_range;
      }
      // Extra merge test needed to make sure to capture all edges which only occur in one of the maps
      for(std::map<std::pair<CFlowGraphNode*, CFlowGraphNode*>,CIntegerRange*>::iterator ce2r = cfg_edge_to_range_map.begin();
          ce2r != cfg_edge_to_range_map.end(); ++ce2r) {
        std::pair<CFlowGraphNode*, CFlowGraphNode*> cfg_edge = (*ce2r).first;
        CIntegerRange * temp_range = temp_cfg_edge_to_range_map[cfg_edge];
        if(!temp_range) {
          // we had that the temp map did not include this particular edge
          CIntegerRange * range = (*ce2r).second;
          CIntegerRange * t_range = new CIntegerRange(0,0);
          CIntegerRange * new_range = range->Merge(t_range);
          cfg_edge_to_range_map[cfg_edge] = new_range;
          delete t_range;
        }
        delete temp_range;
      }
    }
  }

  // Generate the resulting flow facts by calling the right subordinate collector
  int nr_of_flow_facts = 0;

  if(map_created) {
    CCollector * c = *(collectors->begin());
    assert(c);
    CEdgeCountCollector * ec_collector = dynamic_cast<CEdgeCountCollector *>(c);
    assert(ec_collector);
    nr_of_flow_facts = ec_collector->GenerateContextSensitiveValidAtEntryOfFlowFacts(&cfg_edge_to_range_map, 
                                                                                     call_string, 
                                                                                     valid_at_entry_of, ffs);
    
    // Delete temporary ranges
    for(std::map<std::pair<CFlowGraphNode*, CFlowGraphNode*>,CIntegerRange*>::iterator ce2r = cfg_edge_to_range_map.begin();
        ce2r != cfg_edge_to_range_map.end(); ++ce2r) {
      delete (*ce2r).second;
    }
  }

  // Return the number of generate flow facts
  return nr_of_flow_facts;
}




//---------------------------------
// For printing the collector
//---------------------------------
void
CEdgeCountCollector::
Print(ostream * o)
{
  (*o) << "type: " << Type() << endl;
  (*o) << "scope: " << _scope->Name() << endl;
  std::map<std::pair<CECFGNode*, CECFGNode*>,CIntegerRange*>::iterator n2r;
  FORALL(n2r, _edge_to_range_map)
    {
      pair<CECFGNode *, CECFGNode *> edge = (*n2r).first;
      string edge_name =  edge.first->GetFlowGraphNode()->Name() + "->"
        + edge.second->GetFlowGraphNode()->Name();
      CIntegerRange* range = (*n2r).second;
      (*o) << "  " << edge_name << " = " << (*range) << endl;
    }
  (*o) << endl;
}

//---------------------------------
// Alternative printing function
//---------------------------------
ostream &operator << (ostream &o, CEdgeCountCollector &a)
{
  a.Print(&o);
  return o;
}

// ---------------------------------
// To get the edges to consider
// ---------------------------------
set<pair<CECFGNode *, CECFGNode *> > *
CEdgeCountCollector::
EdgesToConsider(void)
{
  // Set edges to consider (implemented by subclasses)
  if(_edges_to_consider.size() == 0)
    SetEdgesToConsider(&_edges_to_consider);
  return &_edges_to_consider;
}


//----------------------------------
// Create flow facts from the collector and add to scope
//---------------------------------
int
CEdgeCountCollector::
AddMaxEdgeCountFlowFactsToScope(CFlowFact::t_flowfacttype ff_type)
{
  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;

  if(!_sum_edges_in_constraint) {

    // ---------------------------------
    // We should create one or more flow fact for each edge
    // ---------------------------------
    
    // Loop through all the edges to consider
    std::map<std::pair<CECFGNode*, CECFGNode*>,CIntegerRange*>::iterator e2r;
    FORALL(e2r, _edge_to_range_map)
      {
        // Get the edge and the range
        pair<CECFGNode *, CECFGNode *> edge = (*e2r).first;
        CIntegerRange* range = (*e2r).second;
        
        // Get the range and min and max values of the edge
        int64_t min_count = range->L();
        int64_t max_count = range->U();
        
        // Check if the min and max values are equal
        if(min_count == max_count)
          {
            // Yes, create a flow fact as:
            // - scope : [] : edge_name = count
            // CExpressionId *id = new CExpressionId(edge_name);
            CExpressionECFGEdge *id = new CExpressionECFGEdge(edge.first, edge.second);
            CExpressionInt *eint = new CExpressionInt((int)min_count);
            CConstraint constraint(id, RELOP_EQ, eint);
            // Create the [] collector
            CFFCollector c(TOTAL);
            // Create the flow fact
            CFlowFact flow_fact(_scope, ff_type, c, constraint);
            // Add the flow fact to the scope
            _scope->AddFlowFact(flow_fact);
            // Remember that we have added a flow fact
            nr_of_added_flow_facts++;
          }
        else
          {
            // Create a flow fact giving an upper bound on the number
            // of executions of the edge: scope : [] : edge_name <= count
            
            // CExpressionId *max_id = new CExpressionId(edge_name);
            CExpressionECFGEdge *max_id = new CExpressionECFGEdge(edge.first, edge.second);
            CExpressionInt *max_eint = new CExpressionInt((int)max_count);
            CConstraint max_constraint(max_id, RELOP_LTEQ, max_eint);
            // Create the [] collector
            CFFCollector max_c(TOTAL);
            // Create the flow fact
            CFlowFact max_flow_fact(_scope, ff_type, max_c, max_constraint);
            // Add the flow fact to the scope
            _scope->AddFlowFact(max_flow_fact);
            // Remember that we have added a flow fact
            nr_of_added_flow_facts++;
          }
        } // end loop through all scope edges
    
    } // end do not sum edges in constraint     
  
  else if(_edge_to_range_map.size() > 0) {
    
    // ---------------------------------
    // We should sum all the edges in a min and max constraint
    // ---------------------------------

    // Create min sum and max sum expressions
    int64_t min_sum = 0;
    int64_t max_sum = 0;
    CExpression * min_sum_expr = (CExpression *) NULL;
    CExpression * max_sum_expr = (CExpression *) NULL;
    std::map<std::pair<CECFGNode*, CECFGNode*>,CIntegerRange*>::iterator e2r;
    FORALL(e2r, _edge_to_range_map)
      {
        if(e2r == _edge_to_range_map.begin()) {
          min_sum_expr = new CExpressionECFGEdge((*e2r).first.first, (*e2r).first.second);
          max_sum_expr = new CExpressionECFGEdge((*e2r).first.first, (*e2r).first.second);
        }
        else {
          CExpressionECFGEdge * min_edge_expr = new CExpressionECFGEdge((*e2r).first.first, (*e2r).first.second);
          CExpressionECFGEdge * max_edge_expr = new CExpressionECFGEdge((*e2r).first.first, (*e2r).first.second);
          min_sum_expr = new CExpressionBin(min_sum_expr, BINOP_ADD, min_edge_expr);
          max_sum_expr = new CExpressionBin(max_sum_expr, BINOP_ADD, max_edge_expr);
        }
        min_sum += (*e2r).second->L();
        max_sum += (*e2r).second->U();
      }

    if(min_sum == max_sum) {
      // Create the edge1 + edge2 + ... edgeN == max_sum constraint
      CExpressionInt *max_eint = new CExpressionInt((int)max_sum);
      CConstraint max_constraint(max_sum_expr, RELOP_EQ, max_eint);
      CFFCollector max_c(TOTAL);
      CFlowFact max_flow_fact(_scope, ff_type, max_c, max_constraint);
      // Add the flow fact to the scope
      _scope->AddFlowFact(max_flow_fact);
      // Remember that we have added a flow fact
      nr_of_added_flow_facts++;
    }
    else {
      // Create the edge1 + edge2 + ... edgeN <= max_sum constraint
      CExpressionInt *max_eint = new CExpressionInt((int)max_sum);
      CConstraint max_constraint(max_sum_expr, RELOP_LTEQ, max_eint);
      CFFCollector max_c(TOTAL);
      CFlowFact max_flow_fact(_scope, ff_type, max_c, max_constraint);
      // Add the flow fact to the scope
      _scope->AddFlowFact(max_flow_fact);
      // Remember that we have added a flow fact
      nr_of_added_flow_facts++;
    }
  }

  // Return the number of flow facts added
  return nr_of_added_flow_facts;
}

//----------------------------------
// Create flow facts from the collector and add to scope
//---------------------------------
int
CEdgeCountCollector::
AddMinEdgeCountFlowFactsToScope(CFlowFact::t_flowfacttype ff_type)
{
  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;

  if(!_sum_edges_in_constraint) {

    // ---------------------------------
    // We should create one or more flow fact for each edge
    // ---------------------------------

    // Loop through all the edges to consider
    std::map<std::pair<CECFGNode*, CECFGNode*>,CIntegerRange*>::iterator n2r;
    FORALL(n2r, _edge_to_range_map)
      {
        // Get the edge and the old range
        pair<CECFGNode *, CECFGNode *> edge = (*n2r).first;
        CIntegerRange* range = (*n2r).second;
        
        // Get the range and min and max values of the edge
        int64_t min_count = range->L();
                
        // Do not create flow facts for 0
        if(min_count == 0) continue;
        
        // Create a flow fact giving an lower bound on the number
        // of executions of the edge: scope : [] : edge_name >= count

        // Create the edge_name >= count expression
        // CExpressionId *min_id = new CExpressionId(edge_name);
        CExpressionECFGEdge *min_id = new CExpressionECFGEdge(edge.first, edge.second);
        CExpressionInt *min_eint = new CExpressionInt((int)min_count);
        CConstraint min_constraint(min_id, RELOP_GTEQ, min_eint);
        // Create the [] collector
        CFFCollector min_c(TOTAL);
        // Create the flow fact
        CFlowFact min_flow_fact(_scope, CFlowFact::LESS, min_c, min_constraint);
        // Add the flow fact to the scope
        _scope->AddFlowFact(min_flow_fact);
        // Remember that we have added a flow fact
        nr_of_added_flow_facts++;
      }
  } // end loop through all scope edges

  else if(_edge_to_range_map.size() > 0) {
    
    // ---------------------------------
    // We should sum all the edges in a min and max constraint
    // ---------------------------------
    
    // Create min sum and max sum expressions
    int64_t min_sum = 0;
    CExpression * min_sum_expr = (CExpression *) NULL;
    std::map<std::pair<CECFGNode*, CECFGNode*>,CIntegerRange*>::iterator e2r;
    FORALL(e2r, _edge_to_range_map)
      {
        if(e2r == _edge_to_range_map.begin()) {
          min_sum_expr = new CExpressionECFGEdge((*e2r).first.first, (*e2r).first.second);
        }
        else {
          CExpressionECFGEdge * min_edge_expr = new CExpressionECFGEdge((*e2r).first.first, (*e2r).first.second);
          min_sum_expr = new CExpressionBin(min_sum_expr, BINOP_ADD, min_edge_expr);
        }
        min_sum += (*e2r).second->L();
      }

    // Create the edge1 + edge2 + ... edgeN >= min_sum constraint
    CExpressionInt *min_eint = new CExpressionInt((int)min_sum);
    CConstraint min_constraint(min_sum_expr, RELOP_GTEQ, min_eint);
    CFFCollector min_c(TOTAL);
    CFlowFact min_flow_fact(_scope, ff_type, min_c, min_constraint);
    // Add the flow fact to the scope
    _scope->AddFlowFact(min_flow_fact);
    // Remember that we have added a flow fact
    nr_of_added_flow_facts++;
  }
  
  // Return the number of flow facts added
  return nr_of_added_flow_facts;
}

// Help function for generating context senstive valid at enetry of flow facts
int 
CEdgeCountCollector::
GenerateContextSensitiveValidAtEntryOfFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_edge_to_range_map, 
                                                std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  int nr_of_added_flow_facts = 0;
  if(_generate_lower_bound_ffs) {
    CFlowFact::t_flowfacttype ff_type = GetLowerFlowFactType();
    nr_of_added_flow_facts += GenerateContextSensitiveValidAtEntryOfMinFlowFacts(cfg_edge_to_range_map, call_string, 
                                                                                 valid_at_entry_of, ff_type, ffs);
  }
  if(_generate_upper_bound_ffs) {
    CFlowFact::t_flowfacttype ff_type = GetUpperFlowFactType();
    nr_of_added_flow_facts += GenerateContextSensitiveValidAtEntryOfMaxFlowFacts(cfg_edge_to_range_map, call_string, 
                                                                                 valid_at_entry_of, ff_type, ffs);
  }
  return nr_of_added_flow_facts;
}


// Help function for generating upper bound context senstive val�id at enetry of flow facts
int 
CEdgeCountCollector::
GenerateContextSensitiveValidAtEntryOfMaxFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_edge_to_range_map, 
                                                   std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                   std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                   CFlowFact::t_flowfacttype ff_type,
                                                   std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;

  if(!_sum_edges_in_constraint) {

    // ---------------------------------
    // We should create one or more flow fact for each edge
    // ---------------------------------

    // Loop through mappings 
    std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *>::iterator e2r;
    FORALL(e2r, (*cfg_edge_to_range_map))
      {
        // Get the node and the old range
        std::pair<CFlowGraphNode *, CFlowGraphNode *> edge = (*e2r).first;
        CFlowGraphNode * from_node = edge.first;
        CFlowGraphNode * to_node = edge.second;
        CIntegerRange* range = (*e2r).second;
        
        // Get the range and min and max values of the node
        int64_t max_count = range->U();
        assert(range->L() <= max_count);

        // Create the bb_name =< count expression
        // CExpressionId *max_id = new CExpressionId(edge_name);
        CExpressionFlowGraphEdge *max_id = new CExpressionFlowGraphEdge(from_node, to_node);
        CExpressionInt *max_eint = new CExpressionInt((int)max_count);
        CConstraint * max_constraint = new CConstraint(max_id, RELOP_LTEQ, max_eint);
        // Create the [] collector
        CFFCollector * max_c = new CFFCollector(TOTAL);
        // Create the context senstive flow fact
        CContextSensitiveValidAtEntryOfFlowFact * ff = 
          new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, max_c, max_constraint, ff_type);
        // Add the flow fact to the vector 
        ffs->push_back(ff);
        
        // Remember that we have added a flow fact
        nr_of_added_flow_facts++;
        
      } // end loop through all scope nodes
  }
    
  // ---------------------------------
  // We should sum all the edges in a max constraint
  // ---------------------------------

  else if(cfg_edge_to_range_map->size() > 0) {
    
    // Create max sum expressions
    int64_t max_sum = 0;
    CExpression * max_sum_expr = (CExpression *) NULL;
    std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *>::iterator e2r;
    FORALL(e2r, (*cfg_edge_to_range_map))
      {
        if(e2r == cfg_edge_to_range_map->begin()) {
          max_sum_expr = new CExpressionFlowGraphEdge((*e2r).first.first, (*e2r).first.second);
        }
        else {
          CExpressionFlowGraphEdge * max_edge_expr = new CExpressionFlowGraphEdge((*e2r).first.first, (*e2r).first.second);
          max_sum_expr = new CExpressionBin(max_sum_expr, BINOP_ADD, max_edge_expr);
        }
        max_sum += (*e2r).second->U();
      }
    
    // Create the edge1 + .. + edgeN  <= count expression
    CExpressionInt *max_eint = new CExpressionInt((int)max_sum);
    CConstraint * max_constraint = new CConstraint(max_sum_expr, RELOP_LTEQ, max_eint);
    // Create the [] collector
    CFFCollector * max_c = new CFFCollector(TOTAL);
    // Create the context senstive flow fact
    CContextSensitiveValidAtEntryOfFlowFact * ff = 
      new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, max_c, max_constraint, ff_type);
    // Add the flow fact to the vector 
    ffs->push_back(ff);

    // Remember that we have added a flow fact
    nr_of_added_flow_facts++;

  } 
  
  // Return the number of flow facts added
  return nr_of_added_flow_facts;
}

// Help function for generating lower bound context senstive val�id at enetry of flow facts
int 
CEdgeCountCollector::
GenerateContextSensitiveValidAtEntryOfMinFlowFacts(std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *> * cfg_edge_to_range_map, 
                                                   std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                                   std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of,  
                                                   CFlowFact::t_flowfacttype ff_type,
                                                   std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
  // To keep track of the number of flow facts created
  int nr_of_added_flow_facts = 0;

  if(!_sum_edges_in_constraint) {

    // ---------------------------------
    // We should create one or more flow fact for each edge
    // ---------------------------------

    // Loop through mappings 
    std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *>::iterator e2r;
    FORALL(e2r, (*cfg_edge_to_range_map))
    {
      // Get the node and the old range
      std::pair<CFlowGraphNode *, CFlowGraphNode *> edge = (*e2r).first;
      CFlowGraphNode * from_node = edge.first;
      CFlowGraphNode * to_node = edge.second;
      CIntegerRange* range = (*e2r).second;
      
      // Get the range and min and max values of the node
      int64_t min_count = range->L();
      assert(min_count <= range->U());

      // Get the name of the cfg node
      // std::string from_name = from_node->Name();
      // std::string to_name = to_node->Name();
      // string edge_name = from_name + "->" + to_name;
      
      // Create the bb_name >= count expression
      // CExpressionId *min_id = new CExpressionId(edge_name;)
      CExpressionFlowGraphEdge *min_id = new CExpressionFlowGraphEdge(from_node, to_node);
      CExpressionInt *min_eint = new CExpressionInt((int)min_count);
      CConstraint * min_constraint = new CConstraint(min_id, RELOP_GTEQ, min_eint);
      // Create the [] collector
      CFFCollector * min_c = new CFFCollector(TOTAL);
      // Create the context senstive flow fact
      CContextSensitiveValidAtEntryOfFlowFact * ff = 
        new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, min_c, min_constraint, ff_type);
      // Add the flow fact to the vector 
      ffs->push_back(ff);

      // Remember that we have added a flow fact
      nr_of_added_flow_facts++;

    } // end loop through all scope nodes

  } 

  else if(cfg_edge_to_range_map->size() > 0) {

    // ---------------------------------
    // We should sum all the edges in a min constraint
    // ---------------------------------

    // Create min sum expressions
    int64_t min_sum = 0;
    CExpression * min_sum_expr = (CExpression *) NULL;
    std::map<std::pair<CFlowGraphNode *, CFlowGraphNode *>, CIntegerRange *>::iterator e2r;
    FORALL(e2r, (*cfg_edge_to_range_map))
      {
        if(e2r == cfg_edge_to_range_map->begin()) {
          min_sum_expr = new CExpressionFlowGraphEdge((*e2r).first.first, (*e2r).first.second);
        }
        else {
          CExpressionFlowGraphEdge * min_edge_expr = new CExpressionFlowGraphEdge((*e2r).first.first, (*e2r).first.second);
          min_sum_expr = new CExpressionBin(min_sum_expr, BINOP_ADD, min_edge_expr);
        }
        min_sum += (*e2r).second->L();
      }

    // Create the edge1 + .. + edgeN  >= count expression
    CExpressionInt *min_eint = new CExpressionInt((int)min_sum);
    CConstraint * min_constraint = new CConstraint(min_sum_expr, RELOP_GTEQ, min_eint);
    // Create the [] collector
    CFFCollector * min_c = new CFFCollector(TOTAL);
    // Create the context senstive flow fact
    CContextSensitiveValidAtEntryOfFlowFact * ff = 
      new CContextSensitiveValidAtEntryOfFlowFact(call_string, valid_at_entry_of, min_c, min_constraint, ff_type);
    // Add the flow fact to the vector 
    ffs->push_back(ff);

    // Remember that we have added a flow fact
    nr_of_added_flow_facts++;

  } 

  // Return the number of flow facts added
  return nr_of_added_flow_facts;
}



// The same CFG edge may correspond to several ECFG edges
void
CEdgeCountCollector::
DeriveCFGEdgeToRangeMap(std::map<std::pair<CFlowGraphNode*, CFlowGraphNode*>,CIntegerRange*> * cfg_edge_to_range_map)
{
  // Loop through ecfg to range map
   for(std::map<std::pair<CECFGNode*, CECFGNode*>,CIntegerRange*>::iterator e2r = _edge_to_range_map.begin();
      e2r != _edge_to_range_map.end(); ++e2r) {
     // Create a cfg edge from the ecfg edge
     std::pair<CECFGNode *, CECFGNode *> ecfg_edge = (*e2r).first;
     std::pair<CFlowGraphNode *, CFlowGraphNode *> cfg_edge = 
       std::make_pair(ecfg_edge.first->GetFlowGraphNode(), ecfg_edge.second->GetFlowGraphNode());
     CIntegerRange * range = (*e2r).second;
     // Check if the cfg edge already has been added
     if(cfg_edge_to_range_map->find(cfg_edge) == cfg_edge_to_range_map->end()) {
       // No, just copy the range for the ecfg edge
       (*cfg_edge_to_range_map)[cfg_edge] = range->Copy();
     }
     else {
       // Yes, we have the case that the same CFG edge correspond to
       // several ECFG edges. The sum of ecfg edge executions is
       // then the executions of the CFG edge.
       CIntegerRange * old_range = (*cfg_edge_to_range_map)[cfg_edge];
       assert(old_range);
       CIntegerRange * new_range = new CIntegerRange(old_range->L() + range->L(), 
                                                     old_range->U() + range->U());
       delete old_range;
       (*cfg_edge_to_range_map)[cfg_edge] = new_range;
     }
   }
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CEdgeCountScopeCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CEdgeCountScopeCollector::
CEdgeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                         bool sum_edges_in_constraint, bool generate_lower_bound_ffs, bool generate_upper_bound_ffs)
  : CEdgeCountCollector(scope, collect_only_basic_block_start_nodes, sum_edges_in_constraint, 
                        generate_lower_bound_ffs, generate_upper_bound_ffs)
{
  // Do nothing
}

//----------------------------------
// To set the edges to consider
//---------------------------------
void
CEdgeCountScopeCollector::
SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider)
{
 // Call the wanted function in the scope
  _scope->EdgesInScope(edges_to_consider);
}

//--------------------------------------------------
// CMaxEdgeCountScopeCollector
//-------------------------------------------------
CMaxEdgeCountScopeCollector::
CMaxEdgeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CEdgeCountScopeCollector(scope, collect_only_basic_block_start_nodes, false, false, true)
{
  // Do nothing
}

//--------------------------------------------------
// CMinEdgeCountScopeCollector
//-------------------------------------------------
CMinEdgeCountScopeCollector::
CMinEdgeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CEdgeCountScopeCollector(scope, collect_only_basic_block_start_nodes, false, true, false)
{
  // Do nothing
}

//--------------------------------------------------
// CMinMaxEdgeCountScopeCollector
//-------------------------------------------------
CMinMaxEdgeCountScopeCollector::
CMinMaxEdgeCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CEdgeCountScopeCollector(scope, collect_only_basic_block_start_nodes, false, true, true)
{
  // Do nothing
}


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CEdgeCountScopeAndSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CEdgeCountScopeAndSubCollector::
CEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                               bool sum_edges_in_constraint, bool generate_lower_bound_ffs, bool generate_upper_bound_ffs)
  : CEdgeCountCollector(scope, collect_only_basic_block_start_nodes, sum_edges_in_constraint, 
                        generate_lower_bound_ffs, generate_upper_bound_ffs)
{
  // Do nothing
}

//----------------------------------
// To set the edges to consider
//---------------------------------
void
CEdgeCountScopeAndSubCollector::
SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider)
{
 // Call the wanted function in the scope
  _scope->EdgesInScopeAndSubScopes(edges_to_consider);
}

//--------------------------------------------------
// CMaxEdgeCountScopeAndSubCollector
//-------------------------------------------------
CMaxEdgeCountScopeAndSubCollector::
CMaxEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CEdgeCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, false, false, true)
{
  // Do nothing
}

//--------------------------------------------------
// CMinEdgeCountScopeAndSubCollector
//-------------------------------------------------
CMinEdgeCountScopeAndSubCollector::
CMinEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CEdgeCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, false, true, false)
{
  // Do nothing
}

//--------------------------------------------------
// CMinMaxEdgeCountScopeAndSubCollector
//-------------------------------------------------
CMinMaxEdgeCountScopeAndSubCollector::
CMinMaxEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CEdgeCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, false, true, true)
{
  // Do nothing
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CEdgeCountScopeAndLoopSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CEdgeCountScopeAndLoopSubCollector::
CEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                   bool sum_edges_in_constraint, bool generate_lower_bound_ffs, bool generate_upper_bound_ffs)
  : CEdgeCountCollector(scope, collect_only_basic_block_start_nodes, sum_edges_in_constraint, 
                        generate_lower_bound_ffs, generate_upper_bound_ffs)
{
  // Do nothing
}

//----------------------------------
// To set the edges to consider
//---------------------------------
void
CEdgeCountScopeAndLoopSubCollector::
SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider)
{
 // Call the wanted function in the scope
  _scope->EdgesInScopeAndLoopSubScopes(edges_to_consider);
}

//--------------------------------------------------
// CMaxEdgeCountScopeAndLoopSubCollector
//-------------------------------------------------
CMaxEdgeCountScopeAndLoopSubCollector::
CMaxEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CEdgeCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, false, false, true)
{
  // Do nothing
}

//--------------------------------------------------
// CMinEdgeCountScopeAndLoopSubCollector
//-------------------------------------------------
CMinEdgeCountScopeAndLoopSubCollector::
CMinEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CEdgeCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, false, true, false)
{
  // Do nothing
}

//--------------------------------------------------
// CMinMaxEdgeCountScopeAndLoopSubCollector
//-------------------------------------------------
CMinMaxEdgeCountScopeAndLoopSubCollector::
CMinMaxEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CEdgeCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, false, true, true)
{
  // Do nothing
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CCallEdgeCountScopeAndSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CCallEdgeCountScopeAndSubCollector::
CCallEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                               bool sum_edges_in_constraint, bool generate_lower_bound_ffs, bool generate_upper_bound_ffs)
  : CEdgeCountCollector(scope, collect_only_basic_block_start_nodes, sum_edges_in_constraint, 
                        generate_lower_bound_ffs, generate_upper_bound_ffs)
{
  // Do nothing
}

//----------------------------------
// To set the edges to consider
//---------------------------------
void
CCallEdgeCountScopeAndSubCollector::
SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider)
{
 // Call the wanted function in the scope
  _scope->CallEdgesInScopeAndSubScopes(edges_to_consider);
}

//--------------------------------------------------
// CMaxCallEdgeCountScopeAndSubCollector
//-------------------------------------------------
CMaxCallEdgeCountScopeAndSubCollector::
CMaxCallEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CCallEdgeCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, false, false, true)
{
  // Do nothing
}

//--------------------------------------------------
// CMinCallEdgeCountScopeAndSubCollector
//-------------------------------------------------
CMinCallEdgeCountScopeAndSubCollector::
CMinCallEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CCallEdgeCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, false, true, false)
{
  // Do nothing
}

//--------------------------------------------------
// CMinMaxCallEdgeCountScopeAndSubCollector
//-------------------------------------------------
CMinMaxCallEdgeCountScopeAndSubCollector::
CMinMaxCallEdgeCountScopeAndSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CCallEdgeCountScopeAndSubCollector(scope, collect_only_basic_block_start_nodes, false, true, true)
{
  // Do nothing
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CCallEdgeCountScopeAndLoopSubCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CCallEdgeCountScopeAndLoopSubCollector::
CCallEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                                   bool sum_edges_in_constraint, bool generate_lower_bound_ffs, bool generate_upper_bound_ffs)
  : CEdgeCountCollector(scope, collect_only_basic_block_start_nodes, sum_edges_in_constraint, 
                        generate_lower_bound_ffs, generate_upper_bound_ffs)
{
  // Do nothing
}

//----------------------------------
// To set the edges to consider
//---------------------------------
void
CCallEdgeCountScopeAndLoopSubCollector::
SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider)
{
 // Call the wanted function in the scope
  _scope->CallEdgesInScopeAndLoopSubScopes(edges_to_consider);
}

//--------------------------------------------------
// CMaxCallEdgeCountScopeAndLoopSubCollector
//-------------------------------------------------
CMaxCallEdgeCountScopeAndLoopSubCollector::
CMaxCallEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CCallEdgeCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, false, false, true)
{
  // Do nothing
}

//--------------------------------------------------
// CMinCallEdgeCountScopeAndLoopSubCollector
//-------------------------------------------------
CMinCallEdgeCountScopeAndLoopSubCollector::
CMinCallEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CCallEdgeCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, false, true, false)
{
  // Do nothing
}

//--------------------------------------------------
// CMinMaxCallEdgeCountScopeAndLoopSubCollector
//-------------------------------------------------
CMinMaxCallEdgeCountScopeAndLoopSubCollector::
CMinMaxCallEdgeCountScopeAndLoopSubCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CCallEdgeCountScopeAndLoopSubCollector(scope, collect_only_basic_block_start_nodes, false, true, true)
{
  // Do nothing
}


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CLoopBodyBeginEdgeSumCountScopeCollector
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
CLoopBodyBeginEdgeSumCountScopeCollector::
CLoopBodyBeginEdgeSumCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes,
                         bool sum_edges_in_constraint, bool generate_lower_bound_ffs, bool generate_upper_bound_ffs)
  : CEdgeCountCollector(scope, collect_only_basic_block_start_nodes, sum_edges_in_constraint, 
                        generate_lower_bound_ffs, generate_upper_bound_ffs)
{
  // Do nothing
}

//----------------------------------
// To set the edges to consider
//---------------------------------
void
CLoopBodyBeginEdgeSumCountScopeCollector::
SetEdgesToConsider(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider)
{
 // Call the wanted function in the scope
  _scope->LoopBodyBeginEdgesInScope(edges_to_consider);
}

//--------------------------------------------------
// CMaxLoopBodyBeginEdgeSumCountScopeCollector
//-------------------------------------------------
CMaxLoopBodyBeginEdgeSumCountScopeCollector::
CMaxLoopBodyBeginEdgeSumCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CLoopBodyBeginEdgeSumCountScopeCollector(scope, collect_only_basic_block_start_nodes, true, false, true)
{
  // Do nothing
}

//--------------------------------------------------
// CMinLoopBodyBeginEdgeSumCountScopeCollector
//-------------------------------------------------
CMinLoopBodyBeginEdgeSumCountScopeCollector::
CMinLoopBodyBeginEdgeSumCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CLoopBodyBeginEdgeSumCountScopeCollector(scope, collect_only_basic_block_start_nodes, true, true, false)
{
  // Do nothing
}

//--------------------------------------------------
// CMinMaxLoopBodyBeginEdgeSumCountScopeCollector
//-------------------------------------------------
CMinMaxLoopBodyBeginEdgeSumCountScopeCollector::
CMinMaxLoopBodyBeginEdgeSumCountScopeCollector(CScope * scope, bool collect_only_basic_block_start_nodes)
  : CLoopBodyBeginEdgeSumCountScopeCollector(scope, collect_only_basic_block_start_nodes, true, true, true)
{
  // Do nothing
}
