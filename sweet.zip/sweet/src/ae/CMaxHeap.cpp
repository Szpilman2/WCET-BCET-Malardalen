/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CMaxHeap.cpp 7976 2018-11-23 15:35:50Z lkg02 $
//
// ----------------------------------------------------------------------

#include "CMaxHeap.h"
#include <cassert>
#include <ciso646>

using namespace std;

// Creation
CMaxHeap::
CMaxHeap(void)
{
  _max_nr_of_values_held = 0;
  _allow_duplicate_keys = true;
}

// Creation
CMaxHeap::
CMaxHeap(bool allow_duplicate_keys)
{
  _max_nr_of_values_held = 0;
  _allow_duplicate_keys = allow_duplicate_keys;
}

// Deletion
CMaxHeap::
~CMaxHeap(void)
{
  // Do nothing
}

// Insert the new key in the heap
void
CMaxHeap::
Insert(int key)
{
  // Only insert duplicate keys if allowed
  if(!_allow_duplicate_keys) {
    if(_keys_in_heap.find(key) != _keys_in_heap.end())
      return;
    else
      _keys_in_heap.insert(key);
  }

  // Insert the new element at the last position in _a
  _a.push_back(key);
  int i = (int)_a.size() - 1;
  // Move the new elements upward in the heap
  while(i > 0 and _a[parent(i)] < key)
    {
      _a[i] = _a[parent(i)];
      i = parent(i);
      _a[i] = key;
    }
  // Check if we should update the _max_nr_of_values_held
  if(_a.size() > _max_nr_of_values_held)
    _max_nr_of_values_held = (unsigned)_a.size();
}

// Extract the largest element from the heap
int
CMaxHeap::
PopMax(void)
{
  assert(!IsEmpty());

  // Extract the max key
  int max = _a[0];

  // Reorganize the heap
  int size = (int)_a.size();
  _a[0] = _a[size - 1];
  _a.pop_back();
  heapify(0);

  // To avoid duplicate keys
  if(!_allow_duplicate_keys)
    _keys_in_heap.erase(max);

  // Return the largest key
  return max;
}

// To check if the heap is empty
bool
CMaxHeap::
IsEmpty(void)
{
  return (_a.size() == 0);
} 

// To get statistics on the max number of elements held
int
CMaxHeap::
NrOfValuesHeld(void)
{
  return (int)_a.size();
}


// To get statistics on the max number of elements held
int
CMaxHeap::
MaxNrOfValuesHeld(void)
{
  return _max_nr_of_values_held;
}

// Help function for placing element with index i at the right place
// of the heap
void
CMaxHeap::
heapify(int i)
{
  int l, r, size, largest;
  l = left(i);
  r = right(i);
  size = (int)_a.size();
  // Get the largest element of _a[l] and _a[i]
  if(l < size && _a[l] > _a[i])
    largest = l;
  else
    largest = i;
  // Get the largest element of _a[r] and _a[largest]
  if(r < size && _a[r] > _a[largest])
    largest = r;
  // Check if i is not the largest element. If not we should swap
  // i one step down in the heap and call algorithm recursively.
  if(largest != i) {
    exchange(i, largest);
    heapify(largest);
  }
}

// Help function for change value of two array elements.
void
CMaxHeap::
exchange(int i, int j)
{
  int temp = _a[i];
  _a[i] = _a[j];
  _a[j] = temp;
}

void
CMaxHeap::
Print(ostream * o)
{
  int max_index = (int)_a.size() - 1;
  int i = 0;
  for(i = 0; i <= max_index; i++)
    (*o) << "_a[" << i << "] = " << _a[i] << endl;
}

// Alternative printing function
ostream &operator << (ostream &o, CMaxHeap &a)
{
  a.Print(&o);
  return o;
}
