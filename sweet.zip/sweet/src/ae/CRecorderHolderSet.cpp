/* -*- Mode: C++; tab-width: 4; indent-tabs-mode: nil -*- */ 

#include "CRecorderHolderSet.h"

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CRecorderHolderSet
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

CRecorderHolderSet::
CRecorderHolderSet(void)
{
  // Create a scope index recorder holder 
  _scope_index_recorder_holder = new CScopeIndexRecorderHolder();
}

CRecorderHolderSet::
~CRecorderHolderSet(void)
{
  // Delete all recorder holders, by calling their delete function
  for(std::vector<CRecorderHolder *>::iterator rec_holder = _recorder_holders.begin();
      rec_holder != _recorder_holders.end(); rec_holder++) {
    delete *rec_holder;
  }
  
  // Delete the scope index record holder
  delete _scope_index_recorder_holder;
}

void  
CRecorderHolderSet::
AddRecorderHolder(CRecorderHolder * rec_holder)
{
  _recorder_holders.push_back(rec_holder);
}

void
CRecorderHolderSet::
UpdateWithProgramStart(CECFGNode * PC_after) 
{
  // std::cout << "CRecorderHolderSet::UpdateWithProgramStart \n";
  // Go through all recorder holders and call their corresponding function.
  for(std::vector<CRecorderHolder *>::iterator rec_holder = _recorder_holders.begin();
      rec_holder != _recorder_holders.end(); rec_holder++) {
    (*rec_holder)->UpdateWithProgramStart(PC_after);
  }

  // Also update the scope index recorder holder
  _scope_index_recorder_holder->UpdateWithProgramStart(PC_after);

  // std::cout << "CRecorderHolderSet::UpdateWithProgramStart end\n";
}

void
CRecorderHolderSet::
UpdateWithProgramCounterChange(CECFGNode * PC_before, CECFGNode * PC_after) 
{
  // std::cout << "CRecorderHolderSet::UpdateWithProgramCounterChange \n";

  // Go through all recorder holders and call their corresponding Update function.
  for(std::vector<CRecorderHolder *>::iterator rec_holder = _recorder_holders.begin();
      rec_holder != _recorder_holders.end(); rec_holder++) {
    (*rec_holder)->UpdateWithProgramCounterChange(PC_before, PC_after);
  }
    
  // Also update the scope index recorder holder
  _scope_index_recorder_holder->UpdateWithProgramCounterChange(PC_before, PC_after);
  // std::cout << "CRecorderHolderSet::UpdateWithProgramCounterChange end\n";
}

void
CRecorderHolderSet::
UpdateWithProgramExit(CECFGNode * PC_before) 
{
  // std::cout << "CRecorderHolderSet::UpdateWithProgramExit\n";

  // Go through all recorder holders and call their corresponding function.
  for(std::vector<CRecorderHolder *>::iterator rec_holder = _recorder_holders.begin();
      rec_holder != _recorder_holders.end(); rec_holder++) {
    (*rec_holder)->UpdateWithProgramExit(PC_before);
  }

  // Also update the scope index recorder holder
  _scope_index_recorder_holder->UpdateWithProgramExit(PC_before);

  // std::cout << "CRecorderHolderSet::UpdateWithProgramExit end\n";
}

CRecorderHolderSet *
CRecorderHolderSet::
Copy(void)
{
  // Create a new recorder holder set
  CRecorderHolderSet * new_rec_holder_set = new CRecorderHolderSet();
  
  // Go through all recorder holders and generate a copy for the new rec holder 
  for(std::vector<CRecorderHolder *>::iterator rec_holder = _recorder_holders.begin();
      rec_holder != _recorder_holders.end(); rec_holder++) {
    CRecorderHolder * new_rec_holder = (*rec_holder)->Copy();
    new_rec_holder_set->_recorder_holders.push_back(new_rec_holder);
  }

  // Set the scope index recorder holder to a copy of current scope index recorder holder
  new_rec_holder_set->SetScopeIndexRecorderHolder(_scope_index_recorder_holder->Copy());
 
  // Return the new set
  return new_rec_holder_set;
}


CRecorderHolderSet *
CRecorderHolderSet::
Merge(CRecorderHolderSet * other)
{
  // Create a new recorder holder set
  CRecorderHolderSet * new_rec_holder_set = new CRecorderHolderSet();

  // Go through all recorder holders and make a merge version of each of them 
  std::vector<CRecorderHolder *>::iterator rec_holder;
  std::vector<CRecorderHolder *>::iterator other_rec_holder;
  for(rec_holder = _recorder_holders.begin(), other_rec_holder = (other->_recorder_holders).begin();
      rec_holder != _recorder_holders.end() && other_rec_holder != other->_recorder_holders.end(); 
      rec_holder++, other_rec_holder++) {
    CRecorderHolder * new_rec_holder = (*rec_holder)->Merge(*other_rec_holder);
    new_rec_holder_set->_recorder_holders.push_back(new_rec_holder);
  }

  // Set the scope index recorder holder to a merged one...
  CScopeIndexRecorderHolder * new_scope_index_rec_holder = 
    _scope_index_recorder_holder->Merge(other->GetScopeIndexRecorderHolder());
  new_rec_holder_set->SetScopeIndexRecorderHolder(new_scope_index_rec_holder);
 
  // Return the new set holding the merged recorder holders
  return new_rec_holder_set;
}

void
CRecorderHolderSet::
Print(std::ostream * o){
   // Go through all recorder holders and print each
  for(std::vector<CRecorderHolder *>::iterator rec_holder = _recorder_holders.begin();
      rec_holder != _recorder_holders.end(); rec_holder++) {
    (*rec_holder)->Print(o);
  }
}

CScopeIndexRecorderHolder * 
CRecorderHolderSet::
GetScopeIndexRecorderHolder(void)
{
  return _scope_index_recorder_holder;
}

const CScopeIndexRecorderHolder * 
CRecorderHolderSet::GetScopeIndexRecorderHolder(void) const
{return _scope_index_recorder_holder;}

void
CRecorderHolderSet::
SetScopeIndexRecorderHolder(CScopeIndexRecorderHolder * sirh)
{
  if(_scope_index_recorder_holder) delete _scope_index_recorder_holder;
  _scope_index_recorder_holder = sirh;
}


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CRecorderHolderSetServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

//---------------------------------
// To create a recorder holder set
//---------------------------------
CRecorderHolderSet *
CRecorderHolderSetServer::
CreateRecorderHolderSet()
{
  // Create the recorder
  CRecorderHolderSet * rhs = new CRecorderHolderSet();

  // Remember that we have one reference to the rhs
  _rhs_to_refs[rhs] = 1;

  // Return the new rhs
  return rhs;
}

// -------------------------------------------------------
// To delete a certain rhs
// -------------------------------------------------------
void
CRecorderHolderSetServer::
DeleteRecorderHolderSet(CRecorderHolderSet * rhs)
{
  // Update map
  _rhs_to_refs[rhs] = _rhs_to_refs[rhs]-1;

  // Check if we have any refs left
  if(_rhs_to_refs[rhs] == 0) {
    // No, remove the rhs for real
    delete rhs;
  }
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CRecorderHolderSetCOWServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

// -------------------------------------------------------
// To create the server
// -------------------------------------------------------
CRecorderHolderSetCOWServer::
CRecorderHolderSetCOWServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To delete the server
// -------------------------------------------------------
CRecorderHolderSetCOWServer::
~CRecorderHolderSetCOWServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To add a recorder holder to a set
// -------------------------------------------------------
void
CRecorderHolderSetCOWServer::
AddRecorderHolderToRecorderHolderSet(CRecorderHolderSet ** rhs, CRecorderHolder *rh)
{

  // Check if we have only one reference to rhs
  if(_rhs_to_refs[*rhs] == 1)
    {
      // Add to rhs 
      (*rhs)->AddRecorderHolder(rh);

      // Do not update rhs
    }
  // More than one reference
  else
    {
      // Do the real copying
      CRecorderHolderSet * rhs_copy = (*rhs)->Copy();

      // Update the copied rhs
      rhs_copy->AddRecorderHolder(rh);

      // Update refs map
      _rhs_to_refs[*rhs] = _rhs_to_refs[*rhs] - 1;
      _rhs_to_refs[rhs_copy] = 1;

      // Update rhs
      (*rhs) = rhs_copy;
    }
}

// -------------------------------------------------------
// To update all recorders in a given set with program start
// -------------------------------------------------------
void
CRecorderHolderSetCOWServer::
UpdateRecorderHolderSetWithProgramStart(CRecorderHolderSet ** rhs, CECFGNode * PC_after)
{
  // Check if we have only one reference to rhs
  if(_rhs_to_refs[*rhs] == 1)
    {
      // Add to rhs 
      (*rhs)->UpdateWithProgramStart(PC_after);

      // Do not update rhs
    }
  // More than one reference
  else
    {
      // Do the real copying
      CRecorderHolderSet * rhs_copy = (*rhs)->Copy();

      // Update the copied rhs
      rhs_copy->UpdateWithProgramStart(PC_after);

      // Update refs map
      _rhs_to_refs[*rhs] = _rhs_to_refs[*rhs] - 1;
      _rhs_to_refs[rhs_copy] = 1;

      // Update rhs
      (*rhs) = rhs_copy;
    }
}

// -------------------------------------------------------
// To update all recorders in a given set with program transfer
// -------------------------------------------------------
void
CRecorderHolderSetCOWServer::
UpdateRecorderHolderSetWithProgramCounterChange(CRecorderHolderSet ** rhs, CECFGNode * PC_before, CECFGNode * PC_after)
{
  // Check if we have only one reference to rhs
  if(_rhs_to_refs[*rhs] == 1)
    {
      // Add to rhs 
      (*rhs)->UpdateWithProgramCounterChange(PC_before, PC_after);

      // Do not update rhs
    }
  // More than one reference
  else
    {
      // Do the real copying
      CRecorderHolderSet * rhs_copy = (*rhs)->Copy();

      // Update the copied rhs
      rhs_copy->UpdateWithProgramCounterChange(PC_before, PC_after);

      // Update refs map
      _rhs_to_refs[*rhs] = _rhs_to_refs[*rhs] - 1;
      _rhs_to_refs[rhs_copy] = 1;

      // Update rhs
      (*rhs) = rhs_copy;
    }
}

// -------------------------------------------------------
// To update all recorders in a given set with program exit
// -------------------------------------------------------
void
CRecorderHolderSetCOWServer::
UpdateRecorderHolderSetWithProgramExit(CRecorderHolderSet ** rhs, CECFGNode * PC_before)
{

  // Check if we have only one reference to rhs
  if(_rhs_to_refs[*rhs] == 1)
    {
      // Add to rhs 
      (*rhs)->UpdateWithProgramExit(PC_before);

      // Do not update rhs
    }
  // More than one reference
  else
    {
      // Do the real copying
      CRecorderHolderSet * rhs_copy = (*rhs)->Copy();

      // Update the copied rhs
      rhs_copy->UpdateWithProgramExit(PC_before);

      // Update refs map
      _rhs_to_refs[*rhs] = _rhs_to_refs[*rhs] - 1;
      _rhs_to_refs[rhs_copy] = 1;

      // Update rhs
      (*rhs) = rhs_copy;
    }
}

// -------------------------------------------------------
// To copy a recorder holder set
// -------------------------------------------------------
CRecorderHolderSet * 
CRecorderHolderSetCOWServer::
CopyRecorderHolderSet(CRecorderHolderSet * rhs)
{
  // Do no copying, just add one more reference to the rhs
  _rhs_to_refs[rhs] = _rhs_to_refs[rhs] + 1;

  // Return the same rhs
  return rhs;
}

// -------------------------------------------------------
// To merge two rhs
// -------------------------------------------------------
CRecorderHolderSet *
CRecorderHolderSetCOWServer::
MergeRecorderHolderSets(CRecorderHolderSet * rhs1, CRecorderHolderSet * rhs2)
{
  // Check if it is the same rhs (i.e. they points to the same address)
  if(rhs1 == rhs2)
    {
      // Update map
      _rhs_to_refs[rhs1] = _rhs_to_refs[rhs1] + 1;

      // Return the same rhs
      return rhs1;
    }
  else
    {
      // Different rhss, do the real merging
      CRecorderHolderSet * new_rhs = rhs1->Merge(rhs2);

      // Update map
      _rhs_to_refs[new_rhs] = 1;

      // Return the new rhs
      return new_rhs;
    }
}

//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CRecorderHolderSetNoReuseServer
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------

// -------------------------------------------------------
// To create the server
// -------------------------------------------------------
CRecorderHolderSetNoReuseServer::
CRecorderHolderSetNoReuseServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To delete the server
// -------------------------------------------------------
CRecorderHolderSetNoReuseServer::
~CRecorderHolderSetNoReuseServer()
{
  // Do nothing
}

// -------------------------------------------------------
// To add a recorder holder to a set
// -------------------------------------------------------
void
CRecorderHolderSetNoReuseServer::
AddRecorderHolderToRecorderHolderSet(CRecorderHolderSet ** rhs, CRecorderHolder *rh)
{
  // Add to rhs 
  (*rhs)->AddRecorderHolder(rh);
}

// -------------------------------------------------------
// To update all recorders in a given set with program start
// -------------------------------------------------------
void
CRecorderHolderSetNoReuseServer::
UpdateRecorderHolderSetWithProgramStart(CRecorderHolderSet ** rhs, CECFGNode * PC_after)
{
  (*rhs)->UpdateWithProgramStart(PC_after);
}

// -------------------------------------------------------
// To update all recorders in a given set with program transfer
// -------------------------------------------------------
void
CRecorderHolderSetNoReuseServer::
UpdateRecorderHolderSetWithProgramCounterChange(CRecorderHolderSet ** rhs, CECFGNode * PC_before, CECFGNode * PC_after)
{
  (*rhs)->UpdateWithProgramCounterChange(PC_before, PC_after);
}

// -------------------------------------------------------
// To update all recorders in a given set with program exit
// -------------------------------------------------------
void
CRecorderHolderSetNoReuseServer::
UpdateRecorderHolderSetWithProgramExit(CRecorderHolderSet ** rhs, CECFGNode * PC_before)
{
  (*rhs)->UpdateWithProgramExit(PC_before);
}

// -------------------------------------------------------
// To copy recorder
// -------------------------------------------------------
CRecorderHolderSet *
CRecorderHolderSetNoReuseServer::
CopyRecorderHolderSet(CRecorderHolderSet * rhs)
{
  // Do the copying right away
  CRecorderHolderSet * new_rhs = rhs->Copy();

  // Update map
  _rhs_to_refs[new_rhs] = 1;

  // Return the new rhs
  return new_rhs;
}

// -------------------------------------------------------
// To merge two rhss
// -------------------------------------------------------
CRecorderHolderSet *
CRecorderHolderSetNoReuseServer::
MergeRecorderHolderSets(CRecorderHolderSet * rhs1, CRecorderHolderSet * rhs2)
{
  // Do the merging getting a new rhs
  CRecorderHolderSet * new_rhs = rhs1->Merge(rhs2);

  // Update map
  _rhs_to_refs[new_rhs] = 1;

  // Return the new rhs
  return new_rhs;
}

