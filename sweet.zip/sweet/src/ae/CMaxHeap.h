/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: CMaxHeap.h 1627 2010-01-08 11:04:12Z ael01 $
//
// ----------------------------------------------------------------------

#ifndef CMaxHeap_H_
#define CMaxHeap_H_

// Standard includes
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <set>

// To handle cout, cin, etc.


//----------------------------------------------------------------------
//------------------------------------------------------------
//--------------------------------------------------
// CMaxHeap
//-------------------------------------------------
//------------------------------------------------------------
//----------------------------------------------------------------------
class CMaxHeap
{
public:

  //----------------------------------
  // Creation and deletion. If duplicate keys should not be allowed 
  // insertion of key already in heap will be ignored. Note that checking
  // for multiple keys will include some extra lookup cost at insertion.
  //---------------------------------
  CMaxHeap(void); // Will allow duplicate keays
  CMaxHeap(bool allow_duplicate_keys);
  virtual ~CMaxHeap(void);

  //---------------------------------
  // To insert an index in the heap. 
  //----------------------------------
  void Insert(int index);

  //---------------------------------
  // To get the largest element in the heap
  //---------------------------------
  int PopMax(void);

  //---------------------------------
  // To check if there are no elements in the heap
  //---------------------------------
  bool IsEmpty(void);

  //---------------------------------
  // To get statistics on the current and max number of values held
  //---------------------------------
  int NrOfValuesHeld(void);
  int MaxNrOfValuesHeld(void);

  //---------------------------------
  // To print the current heap
  //---------------------------------
  void Print() {Print(&std::cout);}
  void Print(std::ostream * s);

private:

  // Help functions
  void heapify(int i);
  inline void exchange(int i, int j);
  inline int parent(int i) {return i >> 1;}
  inline int left(int i) {return i << 1;}
  inline int right(int i) {return (i << 1) + 1;}

  // We implement the max heap using an integer vector
  std::vector<int> _a;
  unsigned int _max_nr_of_values_held;

  // To avoid duplicate elements. Wilkl not be updated when multiple
  // keys are allowed.
  bool _allow_duplicate_keys;
  std::set<int> _keys_in_heap;
};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CMaxHeap &mh);


#endif
