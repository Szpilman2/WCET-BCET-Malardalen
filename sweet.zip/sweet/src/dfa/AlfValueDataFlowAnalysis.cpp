#include "dfa/AlfValueDataFlowAnalysis.h"
#include "program/CGenericProgram.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CFuncTuple.h"
#include "program_state/PPEnviron.h"
#include "program_state/AlfVM.h"
#include "program_state/program_counter/ProgramCounterECFG_VA.h"
#include "dfa/DataFlowAnalysis.inl"
#include "cmd/CCommandVA.h"
#include "graphs/ecfg/CECFG.h"
#include "globals.h"

extern int g_nr_of_abs_states;

AlfValueDataFlowAnalysis::
AlfValueDataFlowAnalysis(const std::set<std::pair<CECFGNode *, State *> > * node_to_input_state, 
                         const std::set<std::pair<std::pair<CECFGNode *, CECFGNode *>, State *> > *node_and_succ_node_to_output_state, 
                         AlfVM * vm, WideningPlacement widening_placement,
                         const std::set<CECFGNode *> *wid_nar_nodes)
  : DataFlowAnalysis<CECFGNode, State>(node_to_input_state, node_and_succ_node_to_output_state, wid_nar_nodes), 
    _vm(vm), _widening_placement(widening_placement)
{
  // Do nothing
}

AlfValueDataFlowAnalysis::
~AlfValueDataFlowAnalysis()
{
  // Do nothing
}

// To perform the out_state[n] = transfer(in_state[n]). Note that the
// state does not need to have the current node as its pp. This is
// because we might have done step stmt in widening or narrowing call.
void 
AlfValueDataFlowAnalysis::
Transfer(const State * in_state, CECFGNode * node, 
         std::map<CECFGNode *, State *> *succ_node_to_out_state_map)
{ 
  // Check if the input state is bottom. If so the resulting output
  // states will also become bottom.
  if(in_state->IsBottom()) {
    // Loop through all successors of node 
    std::set<CECFGNode *> * succ_nodes = _node_to_succ_nodes[node];
    assert(succ_nodes);
    for(std::set<CECFGNode *>::iterator succ_node = succ_nodes->begin();
        succ_node != succ_nodes->end(); ++succ_node) {
      // Get the previous state assigned to the succ node (to get the pc)
      State * prev_succ_node_state = _node_and_succ_node_pair_to_out_state[std::make_pair(node, *succ_node)];
      assert(prev_succ_node_state);
      std::unique_ptr<ProgramCounterECFG> pc(prev_succ_node_state->GetProgramCounterECFG()->Copy());
      // Create a bottom state
      State * new_succ_node_state = State::CreateBottomState(move(pc));
      // Associate the new state to the succ node. The old state will
      // be deleted by the parent class.
      (*succ_node_to_out_state_map)[*succ_node] = new_succ_node_state;
    }      
  }
  else {
    // Input state is not bottom state. Do the transfer function,
    // basically step through all statements in the basic block until
    // end statement has been processed.
    std::vector<State *> next_states;
    next_states.push_back(in_state->Copy());
    bool is_end_of_bb;
    do {
      unique_ptr<State> state(next_states.front());
      next_states.clear();
      is_end_of_bb = state->GetProgramCounter()->GetProgramPoint()->IsEndOfBasicBlock();
      _vm->StepStmt(move(state), next_states);
    }
    while(!is_end_of_bb);

    std::set<CECFGNode *> * succ_nodes = _node_to_succ_nodes[node];
    assert(succ_nodes);
    
    // Check if we have any successor nodes
    if(succ_nodes->size() > 0) { 
      // Associate output states to node's successor nodes. This is made
      // by looping through all already derived successor nodes and see
      // if it has got a state. If not the successor should be given a
      // bottom state.
      for(std::set<CECFGNode *>::iterator succ_node = succ_nodes->begin();
          succ_node != succ_nodes->end(); ++succ_node) {
        // Derive the new state associated to succ node (if any)
        State * new_succ_node_state = NULL;
        for(std::vector<State *>::iterator next_state = next_states.begin(); 
            next_state != next_states.end(); ++next_state) {
             State * next_abs_state = dynamic_cast<State *>(*next_state);
             CECFGNode * next_abs_state_node = const_cast<CECFGNode *>(next_abs_state->GetProgramCounterECFG()->GetProgramPointECFG()->GetECFGNode());
             if(next_abs_state_node == (*succ_node)) {
               new_succ_node_state = next_abs_state;
               break;
          }
        }
        // If we did not find any state, we should create a new bottom state
        if(new_succ_node_state == NULL) {
          // Get the previous state assigned to the succ node (to get the pc)
          State * prev_succ_node_state = 
	          _node_and_succ_node_pair_to_out_state[std::make_pair(node, *succ_node)];
          assert(prev_succ_node_state);
          std::unique_ptr<ProgramCounterECFG> pc(prev_succ_node_state->GetProgramCounterECFG()->Copy());
          // Create a bottom state
          new_succ_node_state = State::CreateBottomState(move(pc));
	}      
        // Associate the new state to the succ node
        (*succ_node_to_out_state_map)[*succ_node] = new_succ_node_state;
      }
    }
    else {
      // A node with no successors, we should delete all resulting output states 
      assert(next_states.size() <= 1);
      for(std::vector<State *>::iterator next_state = next_states.begin(); 
          next_state != next_states.end(); ++next_state) {
        delete *next_state;
      }
    }
  }
}

// To perform in_state[n] = join_{p in predecessor(n)}(out_state[p]).
State *
AlfValueDataFlowAnalysis::
Join(const std::set<State *> * out_states)
{
  assert(out_states->size() > 0);

  // We should iterate through all output states
  std::set<State *>::const_iterator s = out_states->begin();

  // If we only have one output state
  if(out_states->size() == 1) {
    return (*s)->Copy();
  }

  // We have more than one state
  State * work_s = (*s);

  State * del_s = NULL;

  // Loop through the remaining output states
  for(s++; s != out_states->end(); s++) {
	 // (*s)->Print(cout); cout << std::endl;
    // Join two states creating a new state
    work_s = work_s->LUB(*s);
    // Delete the old state
    if(del_s) delete del_s;
    // Set the delete pointer to point at the new state
    del_s = work_s;
  }

  // Return the state which is the join of all output states
  return work_s;
}

// To perform widening between two states
State * 
AlfValueDataFlowAnalysis::
Widen(const State *state_prev_iter, const State *state_current_iter)
{
	if(_widening_placement == WID_BACKEDGE) return state_current_iter->Copy();

  // If we should do widening at the first node in bb
  if(_widening_placement == WID_STANDARD /*|| _widening_placement == WID_BACKEDGE*/) {
    State * res_state = state_prev_iter->Widening(state_current_iter);
    return res_state;
  }
  // Process the statements before the last statement of the basic
  // block. Note that we do the test before the loop is taken (in
  // comparison to when also the last stmt in bb should be processed).
  else if (_widening_placement == WID_STD_BEFORE_LAST_STMT_IN_BB) {
    vector<State *> next_states;
    bool is_end_of_bb = state_current_iter->GetProgramCounterECFG()->GetProgramPointECFG()->IsEndOfBasicBlock();
    next_states.push_back(state_current_iter->Copy());

    while(!is_end_of_bb) {
      assert(next_states.size() == 1);
      unique_ptr<State> state_to_process(next_states.front());
      next_states.clear();
      _vm->StepStmt(move(state_to_process), next_states);
      assert(next_states.size() == 1);
      State * abs_state_to_process = dynamic_cast<State *>(next_states.front());
      assert(abs_state_to_process);
	  
      is_end_of_bb = abs_state_to_process->GetProgramCounterECFG()->GetProgramPointECFG()->IsEndOfBasicBlock();
    }
    assert(next_states.size() == 1);
    unique_ptr<State> state_to_widen(dynamic_cast<State *>(next_states.front()));

    State * res_state = state_prev_iter->Widening(state_to_widen.get());
    return res_state;
  }
  else return state_current_iter->Copy();
}

// To perform widening between two states
State * 
AlfValueDataFlowAnalysis::
WidenOrNarrowEdge(std::pair<CECFGNode*,CECFGNode*> edge,const State *state_prev_iter, const State *state_current_iter,FIXPOINT_PASS fp_pass)
{

  // Cancel widening if not an edge-widening	
  if(_widening_placement != WID_BACKEDGE) {

     return state_current_iter->Copy(); // Do not change current iteration
  }
  else
  {
	  cout << "Widening at edge" << std::endl;
	state_prev_iter->GetProgramCounter()->GetProgramPoint()->Print(cout);
	State * res_state;
	 
		/* This bb has been marked as a widening point. We do widening as long as we stay in the scope, 
		   which means stay in the same loop. If we leave the scope, widening is not necessary */

	  if(edge.first->Scope() == edge.second->Scope())
	  {		

		// Choose function according to iteration type
		if(fp_pass == WIDENING) 
		{
			cout << "performing widening: " << std::endl;
			res_state = state_prev_iter->Widening(state_current_iter);
		}
		else if(fp_pass == NARROWING)
		{
			res_state = state_prev_iter->Narrowing(state_current_iter);
		}
		else
		{
			cout << "no widening" << std::endl;
			res_state = state_current_iter->Copy(); // If not widening/narrowing
		}
	  }
	  else
	  {
		  cout << "leaves scope" << std::endl;
		  res_state = state_current_iter->Copy(); // If not back edge
	  }

	return res_state;
  }
}


// To perform narrowing between two states
State * 
AlfValueDataFlowAnalysis::
Narrow(const State *state_prev_iter, const State *state_current_iter)
{
  // If we should do widening at the first node in bb
  if(_widening_placement == WID_STANDARD || WID_BACKEDGE) {
    State * res_state = state_prev_iter->Narrowing(state_current_iter);
    return res_state;
  }
  // Process the statements before the last statement of the basic
  // block. Note that we do the test before the loop is taken (in
  // comparison to when also the last stmt in bb should be processed).
  else {
    vector<State *> next_states;
    bool is_end_of_bb = state_current_iter->GetProgramCounterECFG()->GetProgramPointECFG()->IsEndOfBasicBlock();
    next_states.push_back(state_current_iter->Copy());
    while(!is_end_of_bb) {
      assert(next_states.size() == 1);
      unique_ptr<State> state_to_process(next_states.front());
      next_states.clear();
      _vm->StepStmt(move(state_to_process), next_states);
      assert(next_states.size() == 1);
      State * abs_state_to_process = dynamic_cast<State *>(next_states.front());
      is_end_of_bb = abs_state_to_process->GetProgramCounterECFG()->GetProgramPointECFG()->IsEndOfBasicBlock();
    }
    assert(next_states.size() == 1);
    unique_ptr<State> state_to_narrow(dynamic_cast<State *>(next_states.front()));
    State * res_state = state_prev_iter->Narrowing(state_to_narrow.get());
    return res_state;
  }
}

bool
AlfValueDataFlowAnalysis::
AreEqual(const State *state1, const State *state2)
{
  return state1->IsEqual(state2);
}
    
void
AlfValueDataFlowAnalysis::
Delete(State *state)
{
  delete state;
}


// Insert widening nodes at basic blocks corresponding to loop merges
std::set<CECFGNode*> WideningNodesAtLoopMerge(CScopeGraph * sg)
{
   std::set<CECFGNode *> wid_nar_nodes;
   
      // We have the widening and narrowing nodes are the header nodes
      // in all loop scopes
   std::vector<CScope*> loop_scopes;
   sg->LoopScopes(&loop_scopes);
   for(std::vector<CScope*>::iterator loop_scope = loop_scopes.begin();
       loop_scope != loop_scopes.end(); ++loop_scope) {
		CECFGNode * header = (*loop_scope)->Header();
		assert(header->IsBeginOfBasicBlock());
		wid_nar_nodes.insert(header);
   }
   
   return wid_nar_nodes;
}


// Insert widening nodes at basic blocks with out going back edges
std::set<CECFGNode*> WideningNodesAtBackEdges(const std::set<CECFGNode*>& nodes)
{
	std::set<CECFGNode *> wid_nar_nodes;

	for(std::set<CECFGNode*>::const_iterator bb_begin_node = nodes.begin() ; bb_begin_node != nodes.end() ; ++bb_begin_node) 
	{

		CECFGNode* bb_end_node = (*bb_begin_node)->GetEndNodeOfNodesBasicBlock();
	
		// For each outgoing node for this BB, check if it is a backedge
		for(CECFGNode::succ_iterator out_edge = bb_end_node->SuccBegin(); out_edge != bb_end_node->SuccEnd(); ++out_edge)
		{
			// Check consistency
			assert(out_edge->node);
			assert(bb_end_node->EdgeTo(out_edge->node));
		
			CECFGEdgeAnnot* edge_data = out_edge->node->EdgedataOfPred(bb_end_node);

			if(edge_data && edge_data->IsBackEdge())
			{
				// This basic block has an outgoing back edge
				// We insert the header of this basic block as a widening point
				wid_nar_nodes.insert(*bb_begin_node);
			}
		}
	}
	return wid_nar_nodes;
}

AlfValueDataFlowAnalysis *
ScopeGraphToAlfValueDataFlowAnalysis(CScopeGraph * sg, AlfVM *vm, const alf::CAlfTuple * ast, 
                                     bool ignore_volatile, bool use_wid_nar, 
                                     WideningPlacement widening_placement)
{
  assert(ast && sg && vm);
 
  // Make sure that we do not have a recursive scope graph
  assert(!sg->HasRecursiveScopes());

  // Get all the ecfg nodes that begin basic blocks in the scope graph
  std::set<CECFGNode*> nodes;
  sg->ECFGNodesThatBeginBasicBlocks(&nodes);

  // To hold all basic block begin nodes and their successor node
  // basic block begin nodes
  std::set<std::pair<CECFGNode *, CECFGNode *> > node_to_succs;

  { // Create pairs from bb begin nodes to successor bb begin nodes
    for(std::set<CECFGNode*>::iterator bb_begin_node = nodes.begin();
        bb_begin_node != nodes.end(); ++bb_begin_node) {
      // Get the end node of the basic block
      CECFGNode * bb_end_node = (*bb_begin_node)->GetEndNodeOfNodesBasicBlock();
      // Get the successor of the end node
      for(CECFGNode::succ_iterator succ_it = bb_end_node->SuccBegin();
          succ_it != bb_end_node->SuccEnd(); ++succ_it) {
        CECFGNode * succ_node = (*succ_it).node;
        assert(succ_node->IsBeginOfBasicBlock());
        node_to_succs.insert(std::make_pair(*bb_begin_node, succ_node));
      }
    }
  }

  // To hold connection between nodes and their input state
  std::set<std::pair<CECFGNode *, State *> > node_to_input_state;

  // Get the start node for the analysis
  CECFGNode * start_node = sg->RootScope()->Header();
  assert(start_node->IsBeginOfBasicBlock());

  { // Create first program point and PC and update initial state with
    // global decls and inits. Create a start state and initialize it
    unique_ptr<ProgramPointECFG> entry_pp(new ProgramPointECFG(sg->ECFG()->Root()));
    unique_ptr<ProgramCounterECFG> pc(new ProgramCounterECFG_VA(ast, move(entry_pp)));
    unique_ptr<PPEnviron> pp_environ(new PPEnviron(*ast));
    State * init_state = new State(move(pc), move(pp_environ));
    const alf::CFuncTuple * root_func = static_cast<const alf::CFuncTuple *>(sg->ECFG()->Root()->Scope()->Function());
    vm->InitializeState(ast, root_func, init_state, ignore_volatile);

    // Associate the input state for the first node in the scope graph
    // to the init state
    node_to_input_state.insert(std::make_pair(start_node, init_state));
  }

  { // Create input bottom state for all other nodes
    for(std::set<CECFGNode*>::iterator bb_begin_node = nodes.begin();
        bb_begin_node != nodes.end(); ++bb_begin_node) {
      CECFGNode * node = (*bb_begin_node);
      if(node == start_node) continue;
      unique_ptr<ProgramPointECFG> pp(new ProgramPointECFG(node));
      unique_ptr<ProgramCounterECFG> pc(new ProgramCounterECFG_VA(ast, move(pp)));
      State * bottom_state = State::CreateBottomState(move(pc));
      node_to_input_state.insert(std::make_pair(node, bottom_state));
    }
  }
  
  // To hold connection between nodes and succ node pairs and output state
  std::set<std::pair<std::pair<CECFGNode *, CECFGNode *>, State *> > node_and_succ_node_to_output_state;

  { // Create output bottom state for all node_to_succ pairs. The pp
    // should hold the ecfg node of the successor.
    for(std::set<std::pair<CECFGNode *, CECFGNode *> >::iterator ns = node_to_succs.begin();
        ns != node_to_succs.end(); ++ns) {
      CECFGNode * node = (*ns).first;
      CECFGNode * succ_node = (*ns).second;
      unique_ptr<ProgramPointECFG> pp(new ProgramPointECFG(succ_node));
      unique_ptr<ProgramCounterECFG> pc(new ProgramCounterECFG_VA(ast, move(pp)));
      State * bottom_state = State::CreateBottomState(move(pc)); 
      node_and_succ_node_to_output_state.insert(std::make_pair(std::make_pair(node, succ_node), bottom_state));
    }
  }

  // Set widening and narrowing nodes
  std::set<CECFGNode *> wid_nar_nodes;
  if(use_wid_nar) 
  {
	  // Select stragegy
	  //if(widening_placement == WID_STANDARD || widening_placement == WID_STD_BEFORE_LAST_STMT_IN_BB)
		wid_nar_nodes = WideningNodesAtLoopMerge(sg);
	//  else if(widening_placement == WID_BACKEDGE)
//		wid_nar_nodes = WideningNodesAtBackEdges(nodes);
	  //else
	//	assert(0 && "ScopeGraphToAlfValueDataFlowAnalysis: Unknown widening placement");
  }
  
  // Create the data flow analysis object
  AlfValueDataFlowAnalysis * dfa = 
    new AlfValueDataFlowAnalysis(&node_to_input_state, &node_and_succ_node_to_output_state, vm, 
                                 widening_placement, &wid_nar_nodes);

  // Return the created and initialized data flow analysis object
  return dfa;
}

AlfValueDataFlowAnalysis *
DoValueDataFlowAnalysis(CScopeGraph * sg, const alf::CAlfTuple * ast, CALFAbsAnnotStorage * abs_annots, 
                        const CSourceLoader *source_loader, const cmd::VASettings * va_settings)
{
   // Create virtual machine and add abstract annotations if any
  AlfVM vm;
  if (abs_annots != NULL) {
    vm.SetAbsAnnots(abs_annots);
  }
  vm.SetSourceLoader(source_loader);

  // Create value data flow analysis algorithm object
  AlfValueDataFlowAnalysis * dfa =
    ScopeGraphToAlfValueDataFlowAnalysis(sg, &vm, ast, true, va_settings->UseWidNar(),
                                         va_settings->GetWideningPlacement());

  // Do the value data flow analysis
  switch(va_settings->GetAnalysisType()) {
    case AlfValueDataFlowAnalysis::CHAOTIC: {
      dfa->RunUsingChaotic(va_settings->GetFixpointPasses(), AlfValueDataFlowAnalysis::FORWARD, 
			   va_settings->_print_analysis_specification, "", 
			   va_settings->_draw_analysis_specification, "");
      break;
    }
    case AlfValueDataFlowAnalysis::WORK_LIST: {
      std::set<CECFGNode *> start_nodes;
      start_nodes.insert(sg->RootScope()->Header());
      dfa->RunUsingWorkList(va_settings->GetFixpointPasses(), AlfValueDataFlowAnalysis::FORWARD, &start_nodes,
			    va_settings->_print_analysis_specification, "", 
			    va_settings->_draw_analysis_specification, "");
      break;
    }
    case AlfValueDataFlowAnalysis::NODE_ORDERING: {
      std::set<CECFGNode *> start_nodes;
      start_nodes.insert(sg->RootScope()->Header());
      dfa->RunUsingNodeOrdering(va_settings->GetFixpointPasses(), AlfValueDataFlowAnalysis::FORWARD, &start_nodes,
				va_settings->_print_analysis_specification, "", 
				va_settings->_draw_analysis_specification, "");
      break;
    }
  }

  // Return the analysis object
  return dfa;
}
