#ifndef ALFVALUEDATAFLOWANALYSIS_H_
#define ALFVALUEDATAFLOWANALYSIS_H_

#include "dfa/DataFlowAnalysis.h"
#include "graphs/scopes/CScopeGraph.h"
#include "graphs/ecfg/CECFGNode.h"
#include "program_state/State.h"
#include "ae/CRecorderHolderSet.h"
#include "absann/CALFAbsAnnot.h"


namespace cmd {
class VASettings;
}

#include <set>
#include <vector>
#include <iostream>

enum WideningPlacement 
{
	WID_STANDARD,					// Do widening/narrowing at loop merge BB at the beginning of the basic block 
	WID_STD_BEFORE_LAST_STMT_IN_BB, // Do widening/narrowing at loop merge BB at before the last stmt 
	WID_BACKEDGE					// Do widening/narrowing at the backedges of the CFG
};

class AlfVM;
class CSourceLoader;

class AlfValueDataFlowAnalysis : public DataFlowAnalysis <CECFGNode, State>
{
public:
  // ---------------------------------
  // To create and delete a value data flow analysis
  // ---------------------------------

  // All arguments are owned by the caller.
  AlfValueDataFlowAnalysis(const std::set<std::pair<CECFGNode *, State *> > * node_to_input_state, 
                           const std::set<std::pair<std::pair<CECFGNode *, CECFGNode *>, State *> > *node_and_succ_node_to_output_state, 
                           AlfVM * vm, WideningPlacement widening_placement=WID_STANDARD,
                           const std::set<CECFGNode *> *wid_nar_nodes=NULL);
  virtual ~AlfValueDataFlowAnalysis();

protected:

  // ---------------------------------
  // Help functions for which code bodies must be provided 
  // ---------------------------------

  // To perform out_state[n] = transfer(in_state[n]). Each successor
  // can get a different out state (for path-sensitive data-flow
  // analyses).
  void Transfer(const State * in_state, CECFGNode * node, 
                std::map<CECFGNode *, State *> *succ_node_to_out_state_map);
  
  // To perform in_state[n] = join_{p in predecessor(n)}(out_state[p]).
  // Will merge several out states into an in_state.
  State * Join(const std::set<State *> * out_states);
  
  // Functions used to perform widening and narrowing. Will generate
  // the input state to the transfer function.
  State * Widen(const State *state_prev_iter, const State *state_current_iter);
  State * Narrow(const State *state_prev_iter, const State *state_current_iter);
  State * WidenOrNarrowEdge(std::pair<CECFGNode*,CECFGNode*> edge,
                            const State *state_prev_iter, 
                            const State *state_current_iter,
                            FIXPOINT_PASS fp_pass);

  // Help function to decide if two states are equal
  bool AreEqual(const State *state1, const State *state2);

  // Help function to delete a state
  void Delete(State *state);

  // Help functions to print a state and a node.
  void PrintState(const State *state, std::ostream & s = std::cout) const { state->Print(s); }
  void PrintNode(const CECFGNode *node, std::ostream & s = std::cout) const { node->Print(s); }

  // Virtual functions to draw a state and a node. 
  void DrawState(const State *state, std::ostream & s = std::cout) const { state->Draw(s); }
  void DrawNode(const CECFGNode *node, std::ostream & s = std::cout) const { node->Print(s); }

  // Help functions to print a name for the analysis 
  std::string AnalysisName() const { return "AlfValueAnalysis"; }

  // ---------------------------------
  // Functions not to be used from the outside
  // ---------------------------------
private:

   State * Transfer(const State * in_state, CECFGNode * node) { return NULL; };


protected:
   // ---------------------------------
   // Internal data
   // ---------------------------------
   AlfVM * _vm;
   WideningPlacement _widening_placement;
  
};

// Help function to create a alf data value analysis. Will use vm to
// create analysis states and to do the transfer function.
AlfValueDataFlowAnalysis * 
ScopeGraphToValueDataFlowAnalysis(CScopeGraph * sg, AlfVM *vm, const alf::CAlfTuple * ast, 
                                  bool ignore_volatile, bool use_wid_nar, WideningPlacement widening_placement);

// Help function to create (using above function) and run value data flow analysis according to
// arguments provided. 
AlfValueDataFlowAnalysis * 
DoValueDataFlowAnalysis(CScopeGraph * sg, const alf::CAlfTuple * ast, CALFAbsAnnotStorage * abs_annots, 
                        const CSourceLoader *source_loader, const cmd::VASettings * va_settings);

#endif
