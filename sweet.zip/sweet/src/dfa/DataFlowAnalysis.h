#ifndef DATA_FLOW_ANALYSIS_H
#define DATA_FLOW_ANALYSIS_H

// Standard includes
#include <map>
#include <vector>
#include <list>
#include <set>
#include <cassert>
#include "graphs/tools/CNode.inl"
#include "graphs/tools/CGraph.inl"
#include "ae/CMaxHeap.h"
#include "ae/AlfAbstractExecution.h"
#include "graphs/tools/Dominance.h"

// -------------------------------------------------------
// DataFlowAnalysis -
// General template class for setting up and perform data flow analysis. 
//
// A data flow analysis derives specific data-flow information (held by a state) 
// for each program point (represented by a node) in a program (represented by a 
// control-flow graph). The data-flow information is propagated through the graph 
// using the following basic algorithm:
//   UNTIL fixpoint has been reached DO
//      FOR EACH node n IN program graph DO
//         out_state[n] = transfer(in_state[n])
//         in_state[n] = join_{p in predecessor(n)}(out_state[p])
//      END FOR
//   END UNTIL
// There are however variants of this basic algorithm, including run using a
// worklist, selecting next node to process using an order to minimize amount of
// nodes to processm, using widening and narrowing, etc. 
//
// The template class is used as follows: 
// (1) Instatiate the template with the type of nodes and analysis states
// that should be used in the program analysis, and create a new class which 
// inherits from this instatiated template. E.g.
// class VAAlgorithm : public DataFlowAnalysis<CECFGNode,CALFAbsState> { ... }
// (2) Add function declarations in the new class' .h file for all the help 
// functions that are virtually declared in DataFlowAnalysis. Also add corresponding
// code bodies for these functions in some .cpp file. E.g.  
// CALFAbsState * VAAlgorithm::Join(std::set<CALFAbsState *> * out_states) { ... }
// (3) Create an object of the new class with the list of nodes, successor nodes, 
// input aand outputs states set up.
// E.g. VAAlgorithm * va = new VAAlgorithm(...);
// (5) Do the specific program analysis using some data-flow analysis algorithm. E.g. 
// std::list<VAAlgorithm::ANALYSIS_TYPE> l;
// l.push_back(VAAlgorithm::WIDENING);
// l.push_back(VAAlgorithm::NARROWING);
// va->RunUsingWorkList(&l,...);
// ------------------------------------------------------- 

template <typename DFANode, typename DFAState>
class DataFlowAnalysis 
{
public:

  // ---------------------------------
  // To create and delete the class
  // ---------------------------------

  // The template class contains a lot of virtual functions and can
  // therefore not be created. 

  // For creating a data flow analysis where each node as an initial
  // input state and one single output state. The first two arguments
  // must be of the same size. The third argument gives the node to
  // successor relation. The fourth argument wid_nar_nodes, hold
  // nodes to be used as widening or narrowing nodes. The nodes are 
  // owned by the caller while the state are owned by the dfa analysis.
  DataFlowAnalysis(const std::set<std::pair<DFANode *, DFAState *> > * node_to_input_state, 
                   const std::set<std::pair<DFANode *, DFAState *> > * node_to_output_state,
                   const std::set<std::pair<DFANode *, DFANode *> > *node_to_succ_node, 
                   const std::set<DFANode *> *wid_nar_nodes = NULL);

  // For creating a data flow analysis where each successor to a node
  // gets an individual output state. Each node also has an input
  // state. The third arguments hold nodes to be used as widening or
  // narrowing nodes, if any.
  DataFlowAnalysis(const std::set<std::pair<DFANode *, DFAState *> > * node_to_input_state, 
                   const std::set<std::pair<std::pair<DFANode *, DFANode *>, DFAState *> > *node_and_succ_node_to_output_state, 
                   const std::set<DFANode *> *wid_nar_nodes = NULL);

  // Deletion will delete all analysis states, but no nodes.
  virtual ~DataFlowAnalysis();

  // ---------------------------------
  // Data structures for running the data flow analysis
  // ---------------------------------

  // To define what type of program analysis to perform. 
  enum ANALYSIS_TYPE { CHAOTIC, WORK_LIST, NODE_ORDERING };

  // To define what type of program analysis to perform. The analyses
  // will be perform according to the order of the list of analysis
  // types. Each analysis runs will be run until fixpoint.
  enum FIXPOINT_PASS { NORMAL, WIDENING, NARROWING };
  
  // To define the analysis direction. In forward analysis the
  // out_states of the predecessors of a node will be joined to form
  // the node's in_state. In backward analysis the out_states of the
  // successors of a node is used instead.
  enum ANALYSIS_DIRECTION { FORWARD, BACKWARD };

  // To define what type of print and draw that should be perfomed
  enum PRINT_DRAW_SPECIFICATION { NONE, ITERATION, FIX_POINT_PASS, RESULT };
    
  // ---------------------------------
  // Functions for running the data flow analysis
  // ---------------------------------

  // To do data flow analysis. Returns the number of node runs. If
  // using chaotic iteration no startnodes can be given.
  int Run(ANALYSIS_TYPE analysis, const std::list<FIXPOINT_PASS> * run_list, ANALYSIS_DIRECTION dir=FORWARD,
          std::set<DFANode *> * start_nodes=NULL, 
	  PRINT_DRAW_SPECIFICATION print_spec=NONE, std::string print_file_name="",
	  PRINT_DRAW_SPECIFICATION draw_spec=NONE, std::string draw_file_name="");

  // To do data flow analysis using chaotic iteration. That is, each
  // run all nodes will be processed. Returns the number of node runs.
  int RunUsingChaotic(const std::list<FIXPOINT_PASS> * run_list, ANALYSIS_DIRECTION dir=FORWARD,
		      PRINT_DRAW_SPECIFICATION print_spec=NONE, std::string print_file_name="",
		      PRINT_DRAW_SPECIFICATION draw_spec=NONE, std::string draw_file_name="");

  // To do data flow analysis using a worklist. That is, only nodes
  // who has got a predecessor node output state updated should be run
  // next run. If start nodes are given the first fixpoint pass are
  // started with a worklist initialized with a specific set of
  // nodes. Remaining fixpoint passes will be initialized with a
  // worklist holding all the nodes.
  int RunUsingWorkList(const std::list<FIXPOINT_PASS> * run_list, ANALYSIS_DIRECTION dir=FORWARD, 
                       std::set<DFANode *> * start_nodes=NULL,
		       PRINT_DRAW_SPECIFICATION print_spec=NONE, std::string print_file_name="",
		       PRINT_DRAW_SPECIFICATION draw_spec=NONE, std::string draw_file_name="");

  // To do data flow analysis using an optimal ordering of the nodes
  // in the graph, to minimize the number of node processings, and a
  // worklist. Basically, when having several nodes to process, the
  // next node to process will always be selected based on the derived
  // node ordering. It should be noted that the ordering can in itself
  // be somewhat costly to derive (is is derived by a reverse
  // immidiate post-dominance analysis and a topological sort of all
  // the nodes in the graph). If start nodes are given the first
  // fixpoint pass are stared with a worklist initialized with a
  // specific set of nodes. Remaining fixpoint passes will be
  // initialized with a worklist holding all the nodes.
  int RunUsingNodeOrdering(const std::list<FIXPOINT_PASS> * run_list, ANALYSIS_DIRECTION dir=FORWARD,
                           std::set<DFANode *> * start_nodes=NULL,
			   PRINT_DRAW_SPECIFICATION print_spec=NONE, std::string print_file_name="",
			   PRINT_DRAW_SPECIFICATION draw_spec=NONE, std::string draw_file_name="");

  // To print and draw the dfa. Might be redefined by subclasses. Calls 
  // PrintNode, PrintState, DrawNode and DrawState functions below.
  virtual void Print(std::ostream &o = std::cout) const;
  virtual void Draw(std::ostream &o = std::cout) const;

  // To get if a run has been made. Returns true if at least one run
  // has been made, false otherwise.
  bool HasMadeRun();

protected:

  // ---------------------------------
  // Help functions for which code bodies must be provided 
  // ---------------------------------

  // To perform out_state[n] = transfer(in_state[n]). The first
  // transfer function is used when all succ nodes are using the same
  // out_state. The second function is used when each successor can
  // get a different out state (for path-sensitive data-flow
  // analyses). Which one that will be called in the analysis is
  // controlled by the use_single_state_for_all_successors_of_node
  // boolean to the class creator function.
  virtual DFAState * Transfer(const DFAState * in_state, DFANode * node) = 0;
  virtual void Transfer(const DFAState * in_state, DFANode * node, 
                        std::map<DFANode *, DFAState *> *succ_node_to_out_state_map) = 0;
  
  // To perform in_state[n] = join_{p in predecessor(n)}(out_state[p]).
  // Will merge several out states into an in_state.
  virtual DFAState * Join(const std::set<DFAState *> * out_states) = 0;

  // Virtual function used to perform widening and narrowing. If no
  // widening and narrowing is used the functions can given be left as
  // is. Otherwise they should be overwritten.
  virtual DFAState * Widen(const DFAState *state_prev_iter, 
                           const DFAState *state_current_iter) { assert(0); return NULL; }
  virtual DFAState * Narrow(const DFAState *state_prev_iter, 
                            const DFAState *state_current_iter) { assert(0); return NULL; }
  virtual DFAState* WidenOrNarrowEdge(std::pair<DFANode*,DFANode*> edge,
									  const DFAState* state_prev_iter, 
								      const DFAState* state_current_iter,
									  FIXPOINT_PASS fp_pass) {return state_current_iter->Copy();}

  // Help function to decide if two states are equal
  virtual bool AreEqual(const DFAState *state1, const DFAState *state2) = 0;

  // Help function to delete a state
  virtual void Delete(DFAState *state) = 0;

  // Help functions to print a state and a node. 
  virtual void PrintState(const DFAState *state, std::ostream & s = std::cout) const = 0;
  virtual void PrintNode(const DFANode *node, std::ostream & s = std::cout) const = 0;

  // Help functions to draw a state and a node. 
  virtual void DrawState(const DFAState *state, std::ostream & s = std::cout) const = 0;
  virtual void DrawNode(const DFANode *node, std::ostream & s = std::cout) const = 0;

  // Virtual function to get the type of the analysis
  virtual std::string AnalysisName(void) const = 0;

protected:

  // ---------------------------------
  // Help functions called by the other functions for which code exists
  // ---------------------------------

  // To remove all input and output states. The states will
  // automatically be removed at class deletion.
  void RemoveAllInputStates();
  void RemoveAllOutputStates();
  void RemoveAllStates();

  // To specify if a node should be a node to perform widening and
  // narrowing at. The node must exists among the nodes set.
  void SetAsWidNarNode(DFANode * node);
  bool IsWidNarNode(DFANode *node) const;

  // Run chaotic analysis with a certain analysis type until
  // fixpoint. Returns the number of runs made.
  int RunUsingChaoticUntilFixpoint(FIXPOINT_PASS fp_type, ANALYSIS_DIRECTION dir);

  // Run worklist analysis with a certain analysis type until 
  // fixpoint. Returns the number of runs made.
  int RunUsingWorkListUntilFixpoint(FIXPOINT_PASS fp_type, ANALYSIS_DIRECTION dir, std::set<DFANode *> *start_list);
  
  // Run worklist analysis with a certain analysis type until 
  // fixpoint. Returns the number of runs made.
  int RunUsingNodeOrderingUntilFixpoint(FIXPOINT_PASS fp_type, ANALYSIS_DIRECTION dir, CMaxHeap * max_heap, 
                                        std::map<DFANode *, int> * node_to_index_map,
                                        std::map<int, DFANode *> * index_to_node_map);
  
  // Run a certain node once (i.e. perform join and transfer). Returns true
  // if the node has reached a fixpoint.
  bool RunNodeOnce(DFANode * node, FIXPOINT_PASS fp_type, ANALYSIS_DIRECTION dir, bool first_run_in_fixpoint_pass);

  // Call all nodes for post processing
  // Always called after reaching the final fix point
  void postProcess();
  virtual void postProcessState(DFAState* state) {}

  // To print or draw the analysis graph during a certain fixpoint
  // pass and iteration. Numbers which are -1 will not be included in
  // the generated file name.
  void PrintToFile(std::string print_file_name, int fix_point_pass=-1, int iteration=-1) const;
  void DrawToFile(std::string print_file_name, int fix_point_pass=-1, int iteration=-1) const;

  // ---------------------------------
  // Internal data structures used 
  // ---------------------------------

  // To remember if we have called the RUN once
  bool _has_made_run;

  // To get fast access of all the nodes in the graph 
  std::set<DFANode *> _nodes;

  // To keep track of nodes successors and predecessors
  std::map<DFANode *, std::set<DFANode *> *> _node_to_succ_nodes;
  std::map<DFANode *, std::set<DFANode *> *> _node_to_pred_nodes;

  // To keep track of the latest input state to a node
  std::map<DFANode *, DFAState *> _node_to_in_state;
  inline DFAState * InState(DFANode * node) { return _node_to_in_state[node]; }

  // To keep track of if we should have a common out state for all succ
  // nodes to a node or if each succ node can get an individual out state
  bool _use_single_state_for_all_successors_of_node;

  // To keep track of the latest out state to a node. The second map
  // will be used when we have that each succ node to a node may have a
  // different out state.
  std::map<DFANode *, DFAState *> _node_to_out_state;
  std::map<std::pair<DFANode *, DFANode *>, DFAState *> _node_and_succ_node_pair_to_out_state;
  inline DFAState * OutState(DFANode * node) { return _node_to_out_state[node]; }
  inline DFAState * OutState(DFANode * node, DFANode * succ) { return _node_and_succ_node_pair_to_out_state[make_pair(node,succ)]; }

  // To keep track what nodes that should be used in widening and narrowing.
  std::set<DFANode *> _wid_nar_nodes;  

protected: 

  // Help template class used to encapsulate a DFANode. 
  class DFANodeContainer : public CNode<DFANodeContainer,Empty>
  {
  public:
    DFANodeContainer() { _has_encapsulated_node = false; _node = NULL; }
    DFANodeContainer(DFANode * node) { _has_encapsulated_node = true; _node = node; }
    virtual ~DFANodeContainer();
    DFANode * EncapsulatedNode() { assert(_has_encapsulated_node); return _node; }
    bool HasEncapsulatedNode() { return _has_encapsulated_node; }
  protected:
    DFANode * _node;
    bool _has_encapsulated_node;
  };

  // class DFANodeContainer : public CNode<CNodeContainer> {};

  // Help function for RunUsingNodeOrdering() to derive an order
  // between nodes based on reverse immediate dominator.
  // typedef CNode<CNodeContainer> DFANodeContainer; 
  void CreateOrderedNodeList(std::map<DFANodeContainer *, std::set<DFANodeContainer *> > * rev_ipdom, 
                             const std::set<DFANodeContainer *> & nodes, std::list<DFANode *> * ordered_node_list); 

  // To keep track of the current fix point pass number and current
  // iteration number
  int _fix_point_pass_nr;
  int _iteration_nr;
 
  // To hold if we should print or draw on an iteration, fixpoint or
  // whole analysis basis. Parameters are used by the PrintToFile()
  // and DrawToFile() functions.
  PRINT_DRAW_SPECIFICATION _print_spec;
  std::string _print_file_name;
  PRINT_DRAW_SPECIFICATION _draw_spec;
  std::string _draw_file_name;
};

// Alternative printing function
template <typename DFANode, typename DFAState>
std::ostream &operator << (std::ostream &o, DataFlowAnalysis<DFANode, DFAState> &a);

 //  // Create functions. First argument, nodes, is the set of nodes that
//   // should be be processed. Second argument specifies if analysis
//   // should derive separate out states for successors of nodes (used
//   // in path-sensitive data-flow analyses) or not. The third argument,
//   // node_to_succ_nodes set up what nodes that are successor to other
//   // nodes in the analysis. These could alternatively be set using the
//   // SetSuccessor() func (note that multi-graphs are not allowed). The
//   // fourth argument, wid_nar_nodes, hold nodes to be used as widening
//   // or narrowing nodes. Alternatively, these nodes can be set using
//   // the SetAsWidNarNode() function. All of the lists are owned by
//   // the caller.
//   DataFlowAnalysis(const std::set<DFANode *> *nodes, bool use_single_state_for_all_successors_of_node,
//                    const std::set<std::pair<DFANode *, DFANode *> > *node_to_succ_nodes = NULL, 
//                    const std::set<DFANode *> *wid_nar_nodes = NULL);



//   // To specify a node to succ node relation. Both nodes must exists
//   // among the nodes set.
//   void SetNodeSuccessor(DFANode * node, DFANode * succ_node);

//   // To specify if a node should be a node to perform widening and
//   // narrowing at. The node must exists among the nodes set.
//   void SetAsWidNarNode(DFANode * node);
//   bool IsWidNarNode(const DFANode *node) const;

//   // ---------------------------------
//   // Function needed to set up data flow analysis
//   // ---------------------------------

//   // To set initial input state for a node. The state is owned by the 
//   void SetInputState(DFANode *node, DFAState *in_state);
//   // To set initial output state(s) for a node. The second version
//   // should be used when we can get different output states for
//   // different successor nodes to a node.
//   void SetOutputState(DFANode *node, DFAState *out_state);
//   void SetOutputState(DFANode *node, DFANode *succ_node, DFAState *out_state);


#endif
