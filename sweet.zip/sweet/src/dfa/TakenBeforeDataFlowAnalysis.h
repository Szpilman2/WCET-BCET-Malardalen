#ifndef TAKENTOGETHERDATAFLOWANALYSIS_H_
#define TAKENTOGETHERDATAFLOWANALYSIS_H_

#include "dfa/DataFlowAnalysis.h"
#include "graphs/scopes/CScopeGraph.h"
#include "graphs/ecfg/CECFGNode.h"
#include "ae/CBitVector.h"

#include <set>
#include <iostream>

class CBitVectorWithBot;

// -------------------------------------------------------
// TakenBeforeDataFlowAnalysis 
// - Help template class for deriving which nodes that must and may be taken 
// before a given node. Virtual, i.e can not be instansiated.
// -------------------------------------------------------
template <typename DFANode>
class TakenBeforeDataFlowAnalysis : public DataFlowAnalysis <DFANode, CBitVectorWithBot>
{
public:

  // The arguments are owned by the caller. Each bit vector should be
  // of the same size as the number of nodes, and zeroized.  Each node
  // should be given an index. The mapping of nodes to indexes should
  // start from 0 to nr_of_nodes-1.
  TakenBeforeDataFlowAnalysis(const std::set<std::pair<DFANode *, CBitVectorWithBot *> > * node_to_input_state, 
                              const std::set<std::pair<DFANode *, CBitVectorWithBot *> > * node_to_output_state,
                              const std::set<std::pair<DFANode *, DFANode *> > * node_to_succ_node,
                              const std::map<DFANode *, unsigned int> * node_to_index);
  virtual ~TakenBeforeDataFlowAnalysis();
  
  // To get the input state vector with the indexes of the nodes that
  // may/must have been taken before the node was taken.
  const CBitVectorWithBot * GetInputState(DFANode * node);

  // To get the input state vector with the indexes of the nodes that
  // may/must have been taken before the node was taken. This will be the
  // same vector as the input with the addition of the current node's
  // index.
  const CBitVectorWithBot * GetOutputState(DFANode * node);

protected:

  // ---------------------------------
  // Help functions for which code bodies must be provided 
  // ---------------------------------

  // To perform out_state[n] = transfer(in_state[n]). Each successor
  // can get a different out state (for path-sensitive data-flow
  // analyses).
  virtual CBitVectorWithBot * Transfer(const CBitVectorWithBot * in_state, DFANode * node);
  
  // To perform in_state[n] = join_{p in predecessor(n)}(out_state[p]).
  // Will merge several out states into an in_state.
  virtual CBitVectorWithBot * Join(const std::set<CBitVectorWithBot *> * out_states) = 0;
  
  // Help function to decide if two states are equal
  bool AreEqual(const CBitVectorWithBot *state1, const CBitVectorWithBot *state2);

  // Help function to delete a state
  void Delete(CBitVectorWithBot *state);

  // Overload help functions to print and draw a state 
  void PrintState(const CBitVectorWithBot *state, std::ostream & s = std::cout) const;
  void DrawState(const CBitVectorWithBot *state, std::ostream & s = std::cout) const;

  // These functions might be redefined in case the nodes in case the
  // nodes do not supprt the print function
  virtual void DrawNode(const CECFGNode *node, std::ostream & s = std::cout) const { node->Print(s); }
  virtual void PrintNode(const DFANode *node, std::ostream & s = std::cout) const { node->Print(s); }

private:

  // Functions that must be provided, but are not used.
  void Transfer(const CBitVectorWithBot * in_state, DFANode * node, 
                std::map<DFANode *, CBitVectorWithBot *> *succ_node_to_out_state_map) { };
  CBitVectorWithBot * Widen(const CBitVectorWithBot *state_prev_iter, const CBitVectorWithBot *state_current_iter) {return NULL;};
  CBitVectorWithBot * Narrow(const CBitVectorWithBot *state_prev_iter, const CBitVectorWithBot *state_current_iter) {return NULL;};

protected:

  // Each node has an index in the bitvector. Needed for the transfer function.
  std::map<DFANode *, unsigned int> _node_to_index;

};

// -------------------------------------------------------
// MustBeTakenBeforeDataFlowAnalysis
// - Help template class for deriving which nodes that must be taken before a given node.
// - Inherits most functionality from TakenBeforeDataFlowAnalysis.
// - The size of each bit vector must be he size of the number of nodes in the graph.
// -------------------------------------------------------
template <typename DFANode>
class MustBeTakenBeforeDataFlowAnalysis : public TakenBeforeDataFlowAnalysis<DFANode>
{
public:
  // ---------------------------------
  // To create and delete a value data flow analysis
  // ---------------------------------

  // First three arguments are owned by the caller. Each bit vector
  // should be of the same size as the number of nodes, and zeroized.
  // Each node should be givcen an index. The mapping of nodes to 
  // indexes should start from 0 to nr_of_nodes-1.
  MustBeTakenBeforeDataFlowAnalysis(const std::set<std::pair<DFANode *, CBitVectorWithBot *> > * node_to_input_state, 
                                    const std::set<std::pair<DFANode *, CBitVectorWithBot *> > * node_to_output_state,
                                    const std::set<std::pair<DFANode *, DFANode *> > * node_to_succ_node,
                                    const std::map<DFANode *, unsigned int> * node_to_index);
  virtual ~MustBeTakenBeforeDataFlowAnalysis();

protected:

  // To perform in_state[n] = join_{p in predecessor(n)}(out_state[p]).
  // Will merge several out states into an in_state.
  CBitVectorWithBot * Join(const std::set<CBitVectorWithBot *> * out_states);

  // Help functions to print a name for the analysis 
  std::string AnalysisName() const { return "MustBeTakenBeforeDataFlowAnalysis"; }

  // To keep track of the nodes that have been processed
  std::set<CECFGNode *> _transfered_nodes;
};

// -------------------------------------------------------
// MayBeTakenBeforeDataFlowAnalysis
// - Help temnplate class for deriving which nodes that may be taken before a given node.
// - Inherits most functionality from TakenBeforeDataFlowAnalysis.
// - The size of each bit vector must be he size of the number of nodes in the graph.
// -------------------------------------------------------
template <typename DFANode>
class MayBeTakenBeforeDataFlowAnalysis : public TakenBeforeDataFlowAnalysis<DFANode>
{
public:
  // ---------------------------------
  // To create and delete a value data flow analysis
  // ---------------------------------

  // First three arguments are owned by the caller. Each bit vector
  // should be of the same size as the number of nodes, and zeroized.
  // Each node should be given an index. The mapping of nodes to 
  // indexes should start from 0 to nr_of_nodes-1.
  MayBeTakenBeforeDataFlowAnalysis(const std::set<std::pair<DFANode *, CBitVectorWithBot *> > * node_to_input_state, 
                                   const std::set<std::pair<DFANode *, CBitVectorWithBot *> > * node_to_output_state,
                                   const std::set<std::pair<DFANode *, DFANode *> > * node_to_succ_node,
                                   const std::map<DFANode *, unsigned int> * node_to_index);
  virtual ~MayBeTakenBeforeDataFlowAnalysis();

protected:

  // Help functions to print a name for the analysis 
  std::string AnalysisName() const { return "MayBeTakenBeforeDataFlowAnalysis"; }

  // To perform in_state[n] = join_{p in predecessor(n)}(out_state[p]).
  // Will merge several out states into an in_state.
  CBitVectorWithBot * Join(const std::set<CBitVectorWithBot *> * out_states);
};

#endif
