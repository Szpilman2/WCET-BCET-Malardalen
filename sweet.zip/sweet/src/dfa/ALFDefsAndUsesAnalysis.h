#ifndef ALFDEFSANDUSESANALYSIS_H_
#define ALFDEFSANDUSESANALYSIS_H_

#include "absann/CALFAbsAnnot.h"
#include "program/alf/AStmt.h"
#include "program/alf/AExpr.h"
#include "program/alf/CInitTuple.h"
#include "program/alf/CInitList.h"
#include "program/alf/CAllocTuple.h"
#include "program/alf/CStoreStmtTuple.h"
#include "program/alf/CCallStmtTuple.h"
#include "program/alf/CJumpStmtTuple.h"
#include "program/alf/CSwitchStmtTuple.h"
#include "program/alf/CStoreStmtTuple.h"
#include "program/alf/CCallStmtTuple.h"
#include "program/alf/CReturnStmtTuple.h"
#include "program/alf/CAddrTuple.h"
#include "graphs/cg/CCallGraph.h"
#include "alf_slicing/ALFExtendedProgramGraphNode.h"

#include <set>

// -------------------------------------------------------
// ALFDefsAndUsesAnalysis 
// - Analysis class for deriving the defs and uses of statements, inits, etc.
// - USES returns the variables potentially used (read) in a statement. This may 
//   be both the variables used on the right hand side as well as the variables 
//   used to calculate the address where to store the result. E.g. 
//   USES(if(x < y)) = {x,y} and USES(x=y+z) = {y,z} and USES(x=42) = { }
//   and if p = &a the USES(*p=x) = {p,a,x}  
//   Note that USES(p=&x) = { } since the value held by the variable is not used
//   only the address where the variable is stored.
// - DEFS returns the set of loications where the result of an assignment may be 
//   stored. E.g. DEFS(x = y) = {x} and if p = {&a,&b} then DEFS(*p = 17} = {a,b}
// - Take a pointer analysis as input to be able to handle when variables are 
//   read and written through pointers. We use a flow- and context-insensitive
//   pointer analysis. 
// - Variables are referred to by unsigned integers. A symbol table can be used
//   to get from unsigned ints to the actual variable and its symbolic name.
// -------------------------------------------------------
class ALFDefsAndUsesAnalysis 
{
public:
  // To create and delete the analysis. The call graph is needed to get uses of parameters 
  // at function call and returns. 
  ALFDefsAndUsesAnalysis(CSteensgaardPA * pa, CSymTabBase * symtab, 
			 CALFAbsAnnotStorage * annots=NULL, alf::CInitList * inits=NULL);
  ~ALFDefsAndUsesAnalysis();

  // To get the defs and uses of a certain ALFExtendedProgramGraphNode 
  void GetDefsOfEPGNode(const ALFExtendedProgramGraphNode * node, std::set<unsigned int> *defs);	
  void GetUsesOfEPGNode(const ALFExtendedProgramGraphNode * node, std::set<unsigned int> *uses);
  void GetDefsAndUsesOfEPGNode(const ALFExtendedProgramGraphNode * node, std::set<unsigned int> *defs, std::set<unsigned int> *uses);	
  void GetGenAndKillDefsOfEPGNode(const ALFExtendedProgramGraphNode * node, std::set<unsigned int> *gen_defs, std::set<unsigned int> *kill_defs);	
  void GetGenAndKillDefsAndUsesOfEPGNode(const ALFExtendedProgramGraphNode * node, std::set<unsigned int> *gen_defs, std::set<unsigned int> *kill_defs, std::set<unsigned int> *uses);	

  // To get the defs and uses of a certain statement
  void GetDefsOfStmt(const alf::AStmt * stmt, std::set<unsigned int> *defs);
  void GetUsesOfStmt(const alf::AStmt * stmt, std::set<unsigned int> *uses);	
  void GetDefsAndUsesOfStmt(const alf::AStmt * stmt, std::set<unsigned int> *defs, std::set<unsigned int> *uses);	
  
  // To get the defs and uses of a local or global initialization 
  void GetDefsOfInit(const alf::CInitTuple * init, std::set<unsigned int> *defs);
  void GetUsesOfInit(const alf::CInitTuple * init, std::set<unsigned int> *uses);
  void GetDefsAndUsesOfInit(const alf::CInitTuple * init, std::set<unsigned int> *defs, std::set<unsigned int> *uses);	
  
  // To get the defs and uses of an abstract ALF annotation 
  void GetDefsOfAnnot(const CALFAbsAnnot * annot, std::set<unsigned int> *defs);
  void GetUsesOfAnnot(const CALFAbsAnnot * annot, std::set<unsigned int> *uses);
  void GetDefsAndUsesOfAnnot(const CALFAbsAnnot * annot, std::set<unsigned int> *defs, std::set<unsigned int> *uses);

  // To get the defs and uses of an allocation
  void GetDefsOfAlloc(const alf::CAllocTuple * decl, std::set<unsigned int> *defs);
  void GetUsesOfAlloc(const alf::CAllocTuple * decl, std::set<unsigned int> *uses);
  void GetDefsAndUsesOfAlloc(const alf::CAllocTuple * decl, std::set<unsigned int> *defs, std::set<unsigned int> *uses);

protected:
  
  // Help functions for partitioning defs in gens and kills
  void GetGenAndKillDefsOfStoreStmt(const alf::CStoreStmtTuple * stmt, std::set<unsigned int> *gen_defs, std::set<unsigned int> *kill_defs);	
  void GetGenAndKillDefsOfAnnot(CALFAbsAnnot * annot, std::set<unsigned int> *gen_defs, std::set<unsigned int> *kill_defs);	
  void GetGenAndKillDefsOfReturnResultAssign(alf::AExpr * return_expr, alf::AExpr * result_expr, 
					     std::set<unsigned int> *gen_defs, std::set<unsigned int> *kill_defs);
  
  // Help function for getting the defs of a statement. 
  void GetDefsOfStoreStmt(const alf::CStoreStmtTuple * stmt, std::set<unsigned int> *defs);
  // The call statemen t defs should not be used on EPG nodes since these have partitioned
  // their defs in calls in ASSIGN nodes.
  void GetDefsOfCallStmt(const alf::CCallStmtTuple * stmt, std::set<unsigned int> *defs);

  // Help function for getting the uses of a statement
  void GetUsesOfJumpStmt(const alf::CJumpStmtTuple * stmt, std::set<unsigned int> *uses);
  void GetUsesOfSwitchStmt(const alf::CSwitchStmtTuple * stmt, std::set<unsigned int> *uses);
  void GetUsesOfStoreStmt(const alf::CStoreStmtTuple * stmt, std::set<unsigned int> *uses);
  void GetUsesOfCallStmt(const alf::CCallStmtTuple * stmt, std::set<unsigned int> *uses);
  void GetUsesOfReturnStmt(const alf::CReturnStmtTuple * stmt, std::set<unsigned int> *uses);
  bool HasLoadOfVar(const alf::AExpr * expr);
  
  // Help function for getting defs and uses of an expression
  void GetDefsOfExpr(const alf::AExpr *expr, std::set<unsigned int> *defs);
  void GetUsesOfExpr(const alf::AExpr * expr, std::set<unsigned int> *uses);
  
  // To extract the variables occurriding in volatiles from a set of annotations and initializations
  void ExtractVolatileVarsFromAnnots(CALFAbsAnnotStorage * annots);
  void ExtractVolatileVarsFromInits(alf::CInitList * inits);

  // Help functions to get the variables possibly updated in expr. The
  // expr can be a lhs expr of a store or assign.
  void GetUpdatedVarsOfLhsAddrExpr(alf::AExpr *expr, std::set<unsigned int> *updated_vars);
  void GetUpdatedVarsOfExpr(const alf::AExpr *expr, std::set<unsigned int> *updated_vars);

  // To get the size of frames and value expressions
  Size GetSizeOfFrameByKey(unsigned int key, CSymTabBase * symtab);
  Size GetSizeOfValueExpr(const alf::AExpr * expr);  

  // Internal pointers 
  CSteensgaardPA * _pa;
  CSymTabBase * _symtab;
  std::set<unsigned int> _volatile_vars;
};

#endif

