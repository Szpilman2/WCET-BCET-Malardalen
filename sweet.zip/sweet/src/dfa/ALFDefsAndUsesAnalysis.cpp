#include "dfa/ALFDefsAndUsesAnalysis.h"
#include "program/alf/CAlfTreeFilter.h"
#include "program/alf/CGenericNode.h"
#include "program/alf/CExprList.h"
#include "program/alf/CFRefTuple.h"
#include "program/alf/CRefTuple.h"
#include "program/alf/CCompAddrTuple.h"
#include "program/alf/CCompLabelTuple.h"
#include "program/alf/CLoadExprTuple.h"
#include "program/alf/COpNumExprTuple.h"
#include "program/alf/CTargetList.h"
#include "program/alf/ATarget.h"
#include "ptranal/CSteensgaardPA.h"
#include "symtab/CSymTabBase.h"
#include "symtab/CSymTabEntry.h"

using namespace alf;

// -------------------------------------------------------
// To create and delete the analysis 
// -------------------------------------------------------
ALFDefsAndUsesAnalysis::
ALFDefsAndUsesAnalysis(CSteensgaardPA * pa, CSymTabBase * symtab,
		       CALFAbsAnnotStorage * annots, CInitList * global_inits)
  : _pa(pa), _symtab(symtab)
{
  // If annots and inits has been given add volatile vars to internal
  // volatile vars set
  if(annots != NULL) ExtractVolatileVarsFromAnnots(annots);
  if(global_inits != NULL) ExtractVolatileVarsFromInits(global_inits);  
}

ALFDefsAndUsesAnalysis::
~ALFDefsAndUsesAnalysis()
{
  // Do nothing
}

// -------------------------------------------------------
// To get the variables potentially defined and uses by an epg node 
// -------------------------------------------------------

void 
ALFDefsAndUsesAnalysis::
GetDefsOfEPGNode(const ALFExtendedProgramGraphNode * node, std::set<unsigned int> *defs)
{
  GetGenAndKillDefsOfEPGNode(node, defs, defs);
}

void 
ALFDefsAndUsesAnalysis::
GetUsesOfEPGNode(const ALFExtendedProgramGraphNode * node, std::set<unsigned int> *uses)
{
  // Get the type of the node
  switch(node->GetBaseType()) {
  case ALFExtendedProgramGraphNode::VIRTUAL: {
    // Virtual node have no defines or uses
    break;
  }
  case ALFExtendedProgramGraphNode::STMT: {
    // We need to treat call and return statements especially, since we should not include 
    // those uses that have been moved to ASSIGN nodes. However, uses in func to call calculation
    // in call statements should be included.
    const ALFExtendedProgramGraphNodeStmt * stmt_node = dynamic_cast<const ALFExtendedProgramGraphNodeStmt *>(node);
    alf::AStmt * stmt = stmt_node->GetStmt();
    // Return and result statements (which holds call statements) are
    // handled in ASSIGN nodes. 
    if(node->GetType() == ALFExtendedProgramGraphNode::RETURN_STMT ||
       node->GetType() == ALFExtendedProgramGraphNode::RESULT_STMT) {
      // Do nothing
    }
    else if(node->GetType() == ALFExtendedProgramGraphNode::CALL_STMT) {
      // Add all variables in expression used to calculated the
      // address of the called function. Calling args and resulting
      // args are handled in assign statement.
      alf::CCallStmtTuple * call_stmt = dynamic_cast<CCallStmtTuple *>(stmt);
      const alf::AExpr* called_func_label_expr = call_stmt->GetLabelExpr();
      GetUsesOfExpr(called_func_label_expr, uses);
    }
    else {
      // Remaining statements are treated as normal
      GetUsesOfStmt(stmt, uses);
    }
    break;
  }
  case ALFExtendedProgramGraphNode::ALLOC: {
    // Get the alloc and gets its uses
    const ALFExtendedProgramGraphNodeAlloc * alloc_node = dynamic_cast<const ALFExtendedProgramGraphNodeAlloc *>(node);
    GetUsesOfAlloc(alloc_node->GetAlloc(), uses);
    break;
  }
  case ALFExtendedProgramGraphNode::ANNOT: { 
    // Get the annot and get its uses
    const ALFExtendedProgramGraphNodeAnnot * annot_node = dynamic_cast<const ALFExtendedProgramGraphNodeAnnot *>(node);
    GetUsesOfAnnot(annot_node->GetAnnot(), uses);
    break;
  }
  case ALFExtendedProgramGraphNode::INIT: {
    // Get the init and its uses
    const ALFExtendedProgramGraphNodeGlobalInit * init_node = dynamic_cast<const ALFExtendedProgramGraphNodeGlobalInit *>(node);
    GetUsesOfInit(init_node->GetInit(), uses);
    break;
  }
  case ALFExtendedProgramGraphNode::ASSIGN: {
    if(node->GetType() == ALFExtendedProgramGraphNode::CALL_ENTER_ASSIGN) {
          // Get the uses of the call expression and the alloc
      const ALFExtendedProgramGraphNodeCallEnterAssign * call_enter_assign_node = 
        dynamic_cast<const ALFExtendedProgramGraphNodeCallEnterAssign *>(node);

      GetUsesOfExpr(call_enter_assign_node->GetCallExpr(), uses);
      GetUsesOfAlloc(call_enter_assign_node->GetEnterAlloc(), uses);
    }
    else if(node->GetType() == ALFExtendedProgramGraphNode::RETURN_RESULT_ASSIGN) {

        // Get the uses of the return and result expressions
      const ALFExtendedProgramGraphNodeReturnResultAssign * return_result_assign_node = 
        dynamic_cast<const ALFExtendedProgramGraphNodeReturnResultAssign *>(node);
      GetUsesOfExpr(return_result_assign_node->GetReturnExpr(), uses);
      GetUsesOfExpr(return_result_assign_node->GetResultExpr(), uses);
    }
    else if(node->GetType() == ALFExtendedProgramGraphNode::ROOT_FUNC_ENTER_ASSIGN) {
      const ALFExtendedProgramGraphNodeRootFuncEnterAssign * root_func_enter_assign_node = 
      dynamic_cast<const ALFExtendedProgramGraphNodeRootFuncEnterAssign *>(node);
      GetUsesOfAlloc(root_func_enter_assign_node->GetEnterAlloc(), uses);
    }
    else if(node->GetType() == ALFExtendedProgramGraphNode::ROOT_FUNC_RETURN_ASSIGN) {
      const ALFExtendedProgramGraphNodeRootFuncReturnAssign * root_func_return_assign_node = 
        dynamic_cast<const ALFExtendedProgramGraphNodeRootFuncReturnAssign *>(node);
      GetUsesOfExpr(root_func_return_assign_node->GetReturnExpr(), uses);
    }
    else {
      assert(0);
    }
    break;
  }
  }
}

void 
ALFDefsAndUsesAnalysis::
GetDefsAndUsesOfEPGNode(const ALFExtendedProgramGraphNode * node, 
			std::set<unsigned int> *defs, std::set<unsigned int> *uses)
{
  GetGenAndKillDefsOfEPGNode(node, defs, defs);
  GetUsesOfEPGNode(node, uses);
}

void 
ALFDefsAndUsesAnalysis::
GetGenAndKillDefsOfEPGNode(const ALFExtendedProgramGraphNode * node, 
			   std::set<unsigned int> *gen_defs, std::set<unsigned int> *kill_defs)
{
  // Get the type of the node
  switch(node->GetBaseType()) {
  case ALFExtendedProgramGraphNode::VIRTUAL: {
    // Virtual node have no defines or uses
    break;
  }
  case ALFExtendedProgramGraphNode::STMT: {
    // Get the statement and get its defs and uses
    const ALFExtendedProgramGraphNodeStmt * stmt_node = dynamic_cast<const ALFExtendedProgramGraphNodeStmt *>(node);
    // Call and return statements are handled in ASSIGN nodes. No other
    // stmt are defining.
    if(node->GetType() == ALFExtendedProgramGraphNode::STORE_STMT) {
      alf::CStoreStmtTuple * store_stmt = dynamic_cast<CStoreStmtTuple *>(stmt_node->GetStmt());
      GetGenAndKillDefsOfStoreStmt(store_stmt, gen_defs, kill_defs);
    }
    break;
  }
  case ALFExtendedProgramGraphNode::ALLOC: {
    // All allocs are killing defs
    const ALFExtendedProgramGraphNodeAlloc * alloc_node = dynamic_cast<const ALFExtendedProgramGraphNodeAlloc *>(node);
    GetDefsOfAlloc(alloc_node->GetAlloc(), kill_defs);
    break;
  }
  case ALFExtendedProgramGraphNode::ANNOT: { 
    // Get the annot and get its defs and uses
    const ALFExtendedProgramGraphNodeAnnot * annot_node = dynamic_cast<const ALFExtendedProgramGraphNodeAnnot *>(node);
    GetGenAndKillDefsOfAnnot(annot_node->GetAnnot(), gen_defs, kill_defs);
    break;
  }
  case ALFExtendedProgramGraphNode::INIT: {
    // All inits are defining since we do not know if the whole frame is overwritten
    const ALFExtendedProgramGraphNodeGlobalInit * init_node = dynamic_cast<const ALFExtendedProgramGraphNodeGlobalInit *>(node);
    GetDefsOfInit(init_node->GetInit(), gen_defs);
    break;
  }
  case ALFExtendedProgramGraphNode::ASSIGN: {
    if(node->GetType() == ALFExtendedProgramGraphNode::CALL_ENTER_ASSIGN) {
      // We can assume that all func parameters and aallocated frames are of teh same size.
      // Thus, the alloc must be a killing def.
      const ALFExtendedProgramGraphNodeCallEnterAssign * assign_node = 
	dynamic_cast<const ALFExtendedProgramGraphNodeCallEnterAssign *>(node);
      GetDefsOfAlloc(assign_node->GetEnterAlloc(), kill_defs);
    }
    else if(node->GetType() == ALFExtendedProgramGraphNode::RETURN_RESULT_ASSIGN) {
      // Depending on what values that may be written and how large the written values are 
      // a return to result assignment can be either a kill or a (set of) gen.
      const ALFExtendedProgramGraphNodeReturnResultAssign * assign_node = 
	dynamic_cast<const ALFExtendedProgramGraphNodeReturnResultAssign *>(node);
      GetGenAndKillDefsOfReturnResultAssign(assign_node->GetReturnExpr(), assign_node->GetResultExpr(), 
					    gen_defs, kill_defs);
    }
    else if(node->GetType() == ALFExtendedProgramGraphNode::ROOT_FUNC_ENTER_ASSIGN) {
      const ALFExtendedProgramGraphNodeRootFuncEnterAssign * root_func_enter_assign_node = 
	dynamic_cast<const ALFExtendedProgramGraphNodeRootFuncEnterAssign *>(node);
      GetDefsOfAlloc(root_func_enter_assign_node->GetEnterAlloc(), kill_defs);
    }
    else if(node->GetType() == ALFExtendedProgramGraphNode::ROOT_FUNC_RETURN_ASSIGN) {
      // No defs, since we do not assign any variables 
    }
    
    break;
  }
  }
}

// -------------------------------------------------------
// To get the variables potentially defined by a statement
// -------------------------------------------------------
void
ALFDefsAndUsesAnalysis::
GetDefsAndUsesOfStmt(const alf::AStmt * stmt, std::set<unsigned int> *defs, std::set<unsigned int> *uses)
{
  // Call the two more specialized functions
  GetDefsOfStmt(stmt, defs);
  GetUsesOfStmt(stmt, uses);
}

// Check what type of statement we have and call the corresponding
// calculated defs function
void
ALFDefsAndUsesAnalysis::
GetDefsOfStmt(const alf::AStmt * stmt, std::set<unsigned int> *defs)
{
  switch(stmt->GetNodeType()) {
    // Null, jump and switch statements do not generate any defines
    case CGenericNode::TYPE_NULL_STMT_TUPLE:
    case CGenericNode::TYPE_JUMP_STMT_TUPLE:
    case CGenericNode::TYPE_SWITCH_STMT_TUPLE:
    case CGenericNode::TYPE_RETURN_STMT_TUPLE:
      {
	// No defs in the statement
	break;
      }
    case CGenericNode::TYPE_STORE_STMT_TUPLE:
      {
	 // Store statement can make many defines  
         const CStoreStmtTuple *store_stmt = dynamic_cast<const CStoreStmtTuple *>(stmt);
         GetDefsOfStoreStmt(store_stmt, defs);
         break;
      }
    case CGenericNode::TYPE_CALL_STMT_TUPLE:
      {
	// Call statements can make many defines  
	const CCallStmtTuple *call_stmt = dynamic_cast<const CCallStmtTuple *>(stmt);
	GetDefsOfCallStmt(call_stmt, defs);
	break;
      }
    // Free and other type of statements are not supported yet 
    case CGenericNode::TYPE_FREE_STMT_TUPLE:
    default: {
      assert("ALFDefsAndUsesAnalysis::GetDefsOfStmt - unsupported statement" == 0);
      break;
    }
  } // end switch
}

void
ALFDefsAndUsesAnalysis::
GetGenAndKillDefsOfStoreStmt(const alf::CStoreStmtTuple * stmt, std::set<unsigned int> *gen_defs,
			     std::set<unsigned int> *kill_defs)
{
  // Get the list of addresses where the values should be stored
  const CExprList* store_addr_exprs = stmt->GetAddrExprs();

  // Get the list of expressions generating values to be stored 
  const CExprList* value_exprs = stmt->GetExprs();

  // Sets to keep track of variables for which it should be created
  // generating and killing RD units. A variable first classified as
  // generating can later be classified as killing if there exist at
  // least assignment which surely defines this variable.
  std::set<unsigned int> generating;
  std::set<unsigned int> killing;

  // Loop through the expressions of store addresses and values 
  alf::CExprList::const_list_iterator store_addr_expr = store_addr_exprs->ConstIterator();
  alf::CExprList::const_list_iterator value_expr = value_exprs->ConstIterator();
  for( ; store_addr_expr != store_addr_exprs->InvalidIterator() && value_expr != value_exprs->InvalidIterator();
       ++store_addr_expr, ++value_expr) { 
    // Get the variables potentially updated on the lhs of this particular parallel store
    std::set<unsigned int> updated_vars;
    GetUpdatedVarsOfLhsAddrExpr(*store_addr_expr, &updated_vars);
    assert(updated_vars.size() >= 1);
    
    // If more than one variable may be updated then it can not be a killing define 
    if(updated_vars.size() == 1) {
      
      // Get the key of the updated variable
      unsigned int lhs_key = *(updated_vars.begin());
      
      // If the variable already has been set as a killing 
      if(killing.find(lhs_key) != killing.end()) {
	continue;
      }
      
      // If the variable is present in the volatile_vars set it can
      // not be a kill
      if(_volatile_vars.find(lhs_key) != _volatile_vars.end()) {
	generating.insert(lhs_key);
	continue;
      }
      
      // Get the size of the frame the key refers to
      Size lhs_size = GetSizeOfFrameByKey(lhs_key, _symtab);
      // Get the size of the value stored
      Size rhs_size = GetSizeOfValueExpr(*value_expr);
      
      // Check if the sizes are equal. Since we are not allowed to
      // write outside frames, we assume if the sizes are equal, that
      // the whole frame will be overwritten.
      if(lhs_size == rhs_size) { 
	killing.insert(lhs_key);
	// Remove previous generating assignment of var if any 
	std::set<unsigned int>::iterator gen = generating.find(lhs_key);
	if(gen != generating.end()) {
	  generating.erase(gen);
	}
      }
      else {
	// We have a generating assignment
	generating.insert(lhs_key);
      }
    }
    else {
      // More than one variable means that no variable is killing.
      // All variables should therefore be added to the generating set.
      for(std::set<unsigned int>::iterator v = updated_vars.begin();
	  v != updated_vars.end(); ++v) {
	// If the variable already is present in the killing set we
	// should not add it to the generating set.
	if(killing.find(*v) == killing.end()) {
	  generating.insert(*v);
	}
      }
    }
  }

  // Make sure that we generate some rd units for the statement
  assert(killing.size() + generating.size() > 0);

  // Loop through the generating vars to create corresponding RD units 
  for(std::set<unsigned int>::iterator key = generating.begin(); key != generating.end(); ++key) {
    gen_defs->insert(*key);
  }

  // Loop through the killing vars to create corresponding RD units 
  for(std::set<unsigned int>::iterator key = killing.begin(); key != killing.end(); ++key) {
    kill_defs->insert(*key);
  }
}

void
ALFDefsAndUsesAnalysis::
GetGenAndKillDefsOfAnnot(CALFAbsAnnot * annot, std::set<unsigned int> *gen_defs,
			 std::set<unsigned int> *kill_defs)
{
  // Get all the var := values assignments made in the abstract assignment 
  const list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > * var_vals_list = annot->VarValsList();

  // Sets to keep track of if assignmenst are generating and maybe also killing a 
  // previous variable definition variables. If the whole frame is overwritten 
  // the abstract value, then the assignment is killing, otherwise not. 
  std::set<unsigned int> generating;
  std::set<unsigned int> killing;
  
  // If the same variable is updated in several assignments in the
  // same annot we might have the case that the assignments together
  // overwrites the whole variable and the absann is therefore a kill
  // of this particular variable. If however, there exists a part of
  // the var which is not covered by the assignment, then the absann
  // is a gen but not a kill of this particular variable.

  // To keep track of the variable assignments made. We summarize all
  // the sizes covered. If the sum is equal to the size of the frame
  // then the whole frame is covered (a kill) otherwise not (a gen).
  std::map<unsigned int, Size> var_key_to_bits_covered;

  // Loop through the parallel assignments in the abstract annotation updating map 
  for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::const_iterator var_vals = var_vals_list->begin();
      var_vals != var_vals_list->end(); ++var_vals)
    {
      CALFAbsAnnotVar * var = (*var_vals).first;
      // Get the key of the updated variable
      const CSymTabEntry * var_entry = _symtab->Lookup(var->FRefId());
      unsigned int var_key = var_entry->GetIdentifier()->GetKey(); 

      // If the update is a GLB or LUB the assignment can not be killing
      if(annot->IsType(CALFAbsAnnot::GLB) || 
	 annot->IsType(CALFAbsAnnot::LUB)) {
	generating.insert(var_key);
      }
      else {
	// It is an ASSIGN update, it can be killing!

	// If the var assignment does not has a size then it writes over the whole frame
	// and is therefore a kill
	if(!var->HasSize()) {	  
	  killing.insert(var_key);
	}
	// If the var assignment has a infinite size then the whole frame is updated
	else if(var->SizeInBits().IsInfinity()) {
	  killing.insert(var_key);
	}
	else {
	  // We have one or more assignments of the given variable.
	  // Calculate the size of the parts of the frame covered.
	  if(var_key_to_bits_covered.find(var_key) == var_key_to_bits_covered.end()) {
	    var_key_to_bits_covered[var_key] = Size(0);
	  }
	  var_key_to_bits_covered[var_key] += var->SizeInBits() * Size(var->Repeat());
	}
      }
    }

  // Go through all list of size of var assignments and categorize the
  // assignment as a kill or a define
  for(std::map<unsigned int, Size>::iterator vk2bc = var_key_to_bits_covered.begin();
      vk2bc != var_key_to_bits_covered.end(); ++vk2bc) {
    // Get the variable defined and the size of bits covered in teh corresponding frame
    unsigned int var_key = (*vk2bc).first;
    Size bits_covered = (*vk2bc).second;
    // Get the size of the frame that the var_key corresponds to 
    Size frame_size = GetSizeOfFrameByKey(var_key, _symtab);
    // If they are equal it is a kill, otherwise not
    if(bits_covered == frame_size) {
      killing.insert(var_key);
    }
    else {
      generating.insert(var_key);
    }
  }

  // Loop through the generating vars to create corresponding RD units 
  for(std::set<unsigned int>::iterator key = generating.begin(); key != generating.end(); ++key) {
    gen_defs->insert(*key);
  }
  
  // Loop through the killing vars to create corresponding RD units 
  for(std::set<unsigned int>::iterator key = killing.begin(); key != killing.end(); ++key) {
    kill_defs->insert(*key);
  }
}

void
ALFDefsAndUsesAnalysis::
GetGenAndKillDefsOfReturnResultAssign(alf::AExpr * return_expr, alf::AExpr * result_expr, 
				      std::set<unsigned int> *gen_defs, std::set<unsigned int> *kill_defs)
{
  assert(return_expr);
  assert(result_expr);

  // Sets to keep track of variables for which it should be created
  // generating and killing RD units. A variable first classified as
  // generating can later be classified as killing if there exist at
  // least assignment which surely defines this variable.
  std::set<unsigned int> generating;
  std::set<unsigned int> killing;

  // Get the variables potentially updated by the result expr
  std::set<unsigned int> updated_vars;
  GetUpdatedVarsOfLhsAddrExpr(result_expr, &updated_vars);
  assert(updated_vars.size() >= 1);
    
  // If more than one variable may be updated then it can not be a killing define 
  if(updated_vars.size() == 1) {
      
    // Get the key of the updated variable
    unsigned int lhs_key = *(updated_vars.begin());
      
    // If the variable is present in the volatile_vars set it can
    // not be a kill
    if(_volatile_vars.find(lhs_key) != _volatile_vars.end()) {
      generating.insert(lhs_key);
    }
    else {
      
      // Get the size of the frame the key refers to
      Size lhs_size = GetSizeOfFrameByKey(lhs_key, _symtab);
      // Get the size of the value stored
      Size rhs_size = GetSizeOfValueExpr(return_expr);
      
      // Check if the sizes are equal. Since we are not allowed to
      // write outside frames, we assume if the sizes are equal, that
      // the whole frame will be overwritten.
      if(lhs_size == rhs_size) { 
	killing.insert(lhs_key);
      }
      else {
	// We have a generating assignment
	generating.insert(lhs_key);
      }
    }
  }
  else {
    // More than one variable means that no variable is killing.
    // All variables should therefore be added to the generating set.
    for(std::set<unsigned int>::iterator v = updated_vars.begin();
	v != updated_vars.end(); ++v) {
      generating.insert(*v);
    }
  }

  // Make sure that we generate some vars 
  assert(killing.size() + generating.size() > 0);

  // Loop through the generating vars to create corresponding RD units 
  for(std::set<unsigned int>::iterator key = generating.begin(); key != generating.end(); ++key) {
    gen_defs->insert(*key);
  }

  // Loop through the killing vars to create corresponding RD units 
  for(std::set<unsigned int>::iterator key = killing.begin(); key != killing.end(); ++key) {
    kill_defs->insert(*key);
  }
}


void
ALFDefsAndUsesAnalysis::
GetDefsOfStoreStmt(const alf::CStoreStmtTuple * stmt, std::set<unsigned int> *defs)
{
  // Get the list of addresses where the values should be stored
  const CExprList* store_addr_exprs = stmt->GetAddrExprs();

  // Loop through the store expressions
  for(alf::CExprList::const_list_iterator store_addr_expr = store_addr_exprs->ConstIterator();
      store_addr_expr != store_addr_exprs->InvalidIterator(); ++store_addr_expr) { 	  	
    
    // Get the variables potentially updated on the lhs of this particular parallel store.
    // All defs will be added to the set to be returned
    GetDefsOfExpr(*store_addr_expr, defs);
  }
}

void
ALFDefsAndUsesAnalysis::
GetDefsOfCallStmt(const alf::CCallStmtTuple * stmt, std::set<unsigned int> *defs)
{
  // We do not need to create any defines for the actual call. This is
  // because we are only overwriting the parameter passing area. To be
  // able to overwrite something using these parameters we must pass
  // pointers to the function. Assignment using dereferenced pointers
  // are handled in normal store statements by the pointer analysis.  	

  // The result parameters must however be treated as assignments
  // since they may overwrite local (and global) variables to the
  // calling function.
  const alf::CExprList * result_addr_exprs = stmt->GetAddrExprs();
  for(alf::CExprList::const_list_iterator result_addr_expr = result_addr_exprs->ConstIterator();
     result_addr_expr != result_addr_exprs->InvalidIterator(); ++result_addr_expr) {
    
    // Get the variables potentially updated on the lhs of this result 
    GetDefsOfExpr(*result_addr_expr, defs);
  }
}

// -------------------------------------------------------
// GetDefsOfExpr -
// Function that given a lhs ADDR_EXPR in a store statement returns the
// variables possibly updated. We say possibly since the analysis rely 
// on the pointer analysis, and the pointer analysis is over approximative.
//
// The following are the valid BNF rules for lhs ADDR_EXPR in store statements.
// May be called recursively.
//
// STMT -> 
// | { store ADDR_EXPR+ with EXPR+ }
//
// ADDR_EXPR -> 
// | { addr SIZE_IN_BITS FREF NUM_EXPR }              // CAddrTuple TYPE_ADDR_EXPR_TUPLE 
// | { addr SIZE_IN_BITS FREF_EXPR NUM_EXPR }         // CCompAddrTuple TYPE_COMPADDR_EXPR_TUPLE 
// | { load SIZE_IN_BITS ADDR_EXPR }                  // CLoadExprTuple TYPE_LOAD_EXPR_TUPLE
// | { add SIZE_IN_BITS ADDR_EXPR NUM_EXPR NUM_EXPR } // COpNumExprTuple TYPE_OP_EXPR_TUPLE && GetOperator()==OP_TYPE_ADD   
// | { add SIZE_IN_BITS NUM_EXPR ADDR_EXPR NUM_EXPR } // COpNumExprTuple TYPE_OP_EXPR_TUPLE && GetOperator()==OP_TYPE_ADD 
// | { sub SIZE_IN_BITS ADDR_EXPR NUM_EXPR NUM_EXPR } // COpNumExprTuple TYPE_OP_EXPR_TUPLE && GetOperator()==OP_TYPE_SUB
// | { undefined SIZE_IN_BITS }                       // CUndefinedExprTuple TYPE_UNDEFINED_EXPR_TUPLE
//
// -------------------------------------------------------
void 
ALFDefsAndUsesAnalysis::
GetDefsOfExpr(const AExpr *expr, std::set<unsigned int> *defs)
{
  // Check the type of the expression and act accordingly
  switch(expr->GetNodeType()) {
  case CGenericNode::TYPE_ADDR_EXPR_TUPLE:
    {
      // Get the fref and insert its key into the set
      const alf::CAddrTuple *cast_expr = dynamic_cast<const alf::CAddrTuple *>(expr);
      const alf::CFRefTuple *fref = cast_expr->GetFref();
      unsigned int key = fref->GetKey();
      defs->insert(key);
      break;
    }
  case CGenericNode::TYPE_COMPADDR_EXPR_TUPLE:
    {
      // Get the expression that should evaluate to a fref and call
      // the function recursively
      const alf::CCompAddrTuple *cast_expr = dynamic_cast<const alf::CCompAddrTuple *>(expr);
      const alf::AExpr * fref_expr = cast_expr->GetFRefExpr();
      GetDefsOfExpr(fref_expr, defs);
      break;
    }
   case CGenericNode::TYPE_LOAD_EXPR_TUPLE: 
     {
       // Here we do not return the variables of the subexpression,
       // but rather the points-to-set of these. Note that we need not
       // bother which variables are pointers, non-pointers will
       // result zero sized points-to-set.
       const alf::CLoadExprTuple *cast_expr = dynamic_cast<const alf::CLoadExprTuple *>(expr);
       const AExpr * addr_expr = cast_expr->GetAddrExpr();
       std::set<unsigned int> vars_to_deref;
       GetDefsOfExpr(addr_expr, &vars_to_deref);
       for(std::set<unsigned int>::const_iterator v = vars_to_deref.begin();
	   v != vars_to_deref.end(); ++v) {
	 if(_pa->HasPointsToVars(*v)) {
	   // Add the dereferenced variables to the argument set
	   _pa->GetPointsToVars(*v, defs);
	 }
       }
       break;
     }
  case CGenericNode::TYPE_OP_EXPR_TUPLE:
    {
      // Here we just have to collect all updated variables in the sub-expressions.
      // This is made by callign the funbction recursively.
      const alf::COpNumExprTuple *cast_expr = dynamic_cast<const alf::COpNumExprTuple *>(expr);
      const alf::CExprList* exprs = cast_expr->GetNumExprs();
      for(CExprList::const_list_iterator e = exprs->ConstIterator();
	  e != exprs->InvalidIterator(); ++e) {
	GetDefsOfExpr(*e, defs);
      }
      break;
    }
  case CGenericNode::TYPE_FREF_TUPLE:
    {
      // Get the key of the fref tuple and insert it into the set
      const alf::CFRefTuple *cast_expr = dynamic_cast<const alf::CFRefTuple *>(expr);
      unsigned int key = cast_expr->GetKey();
      defs->insert(key);
      break;
    }
  case CGenericNode::TYPE_INTVAL_TUPLE:
  case CGenericNode::TYPE_FLOATVAL_TUPLE:
  case CGenericNode::TYPE_LREF_TUPLE:
  case CGenericNode::TYPE_LABEL_TUPLE:
  case CGenericNode::TYPE_COMPLABEL_EXPR_TUPLE:
  case CGenericNode::TYPE_DYNALLOC_EXPR_TUPLE:
    {
      // No variables here, just return
      break;
    }
  case CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE:
    {
      // This is problematic. We do not know what variables that will be updated.
      assert("undefined value can't be handled in RD analysis" == 0);
      break;
    } 
  default:
    {
      assert("This type of expression should not occur on lhs side of store" == 0);
      break;
    }
  } // end switch
}

// -------------------------------------------------------
// To get the variables potentially used by a statement
// -------------------------------------------------------
void
ALFDefsAndUsesAnalysis::
GetUsesOfStmt(const alf::AStmt * stmt, std::set<unsigned int> *uses)
{
  // Check what type of statement we have and call the corresponding
  // create RD units function
  switch(stmt->GetNodeType()) {
    // Null statements do not generate any defines
    case CGenericNode::TYPE_NULL_STMT_TUPLE:
      {
	// No uses 
	break;
      }
    case CGenericNode::TYPE_JUMP_STMT_TUPLE:
      {
        // A jump statement can have uses in label expression  
        const CJumpStmtTuple *jump_stmt = static_cast<const CJumpStmtTuple *>(stmt);
        GetUsesOfJumpStmt(jump_stmt, uses);
        break;
      }
    case CGenericNode::TYPE_SWITCH_STMT_TUPLE:
      {
	// A switch statement can have uses both in the num expression and in the target expressions 
        const CSwitchStmtTuple *switch_stmt = static_cast<const CSwitchStmtTuple *>(stmt);
        GetUsesOfSwitchStmt(switch_stmt, uses);
        break;
      }
    case CGenericNode::TYPE_STORE_STMT_TUPLE:
      {
	// Store statement can use variables 
	const CStoreStmtTuple *store_stmt = static_cast<const CStoreStmtTuple *>(stmt);
	GetUsesOfStoreStmt(store_stmt, uses);
	break;
      }
    case CGenericNode::TYPE_CALL_STMT_TUPLE:
      {
	// Call statements can use variables   
	const CCallStmtTuple *call_stmt = static_cast<const CCallStmtTuple *>(stmt);
	GetUsesOfCallStmt(call_stmt, uses);
	break;
      }
    case CGenericNode::TYPE_RETURN_STMT_TUPLE:
      {
	// Return statements can't make defines   
	const CReturnStmtTuple *return_stmt = static_cast<const CReturnStmtTuple *>(stmt);
	GetUsesOfReturnStmt(return_stmt, uses);
	break;
      }
    // Free and other type of statements are not supported yet 
    case CGenericNode::TYPE_FREE_STMT_TUPLE:
    default: {
      assert("ALFDefsAndUsesAnalysis::GetUsesOfStmt - unsupported statement" == 0);
      break;
    }
  } // end switch
}  

void
ALFDefsAndUsesAnalysis::  
GetUsesOfJumpStmt(const alf::CJumpStmtTuple * stmt, std::set<unsigned int> *uses)
{
  // Get label the expression of the statement	
  const AExpr* expr = stmt->GetLabelExpr();

  // Get the variables potentially updated on the lhs of this result 
  GetUsesOfExpr(expr, uses);
}

void
ALFDefsAndUsesAnalysis::  
GetUsesOfSwitchStmt(const alf::CSwitchStmtTuple * stmt, std::set<unsigned int> *uses)
{
  // Add the uses of all the target expressions 
  const alf::CTargetList* targets = stmt->GetTargets();
  for(alf::CTargetList::const_list_iterator target = targets->ConstIterator();
      target != targets->InvalidIterator(); ++target) {
    // Extract the expression for the label and add its uses
    const AExpr * label_expr = (*target)->GetLabelExpr();
    GetUsesOfExpr(label_expr, uses);
  }  

  // Add the uses of the numerical expression
  const alf::AExpr* num_expr = stmt->GetNumExpr();
  GetUsesOfExpr(num_expr, uses);
}


//  // Borde kunna hanteras genom att vi skapar en rd unit i callet som
//   // definierar (lokala) y.  �r kill om bara *en* funk kan ansropas i
//   // anropet och det v�rde som laddas av expr har samma storlek som
//   // framen som motsvarande alloc skapar... Annars gen.
  
//   // Om vi skriver pekare in s� inget problem. Bara y's address som
//   //
  
//   // Borde inneb�ra att anropet till CreateRDUnitsForFuncArgs skall
//   // tas bort, annars s� risk att parameter v�rdena skrivs �ver

//   // Skall dessa noder ligga f�re eller efter den call node som skapas 
//   // f�r anropet? 

//   // Handle functional arguments

//   //  int foo(int x) {
//     //     int k=5;
//     //  }
//     //
//     //  int main() {
//     //     foo(y);
//     //  }
//     //
//     //  int bar() {
//     //     foo(z)  or baz(z) (due to function pointers)
//     //  }   
//     // 
//     //  int baz(t) {...}
//     //
//     //     [main]                   [bar]
//     //       |                --------|-------|
//     //       |                |               |
//     //     [call]           [call]          [call]   
//     //       |                |               |
//     //     [x = y]         [x = z]          [t = z}
//     //       |                |               |
//     //       |----------|-----|             [baz]
//     //                  |
//     //                [foo]
//     //                  |
//     //                [k = 5]   
    
//     // If there are more than one function which may be called all defines
//     // should be non-killing
//     bool non_killing_def_args = false;
//     if(called_cfgs.size() > 1) 
//       non_killing_args = true;

    

//   // Check if we should generate any gen or killing units for the
//   // call. Not neccessary if the function takes no arguments.
//   const alf::CExprList * call_value_exprs = call_stmt->GetAddrExprs();
//   if(call_value_exprs.size() > 0) {


          
//  int foo(int y)   // called_func->GetArgs() = { y address }
//  {
//     y++;          
//     return;
//  }
  



// -------------------------------------------------------
// To get all the uses of a store statement. Each parallel store
// can be on x = e or *e = e' form. The following rules apply:
// USES(PTS, x = e) = USES(PTS, e)
// USES(PTS, *e = e') = USES(PTS, e) U USES(PTS, e')
// -------------------------------------------------------
void
ALFDefsAndUsesAnalysis::  
GetUsesOfStoreStmt(const alf::CStoreStmtTuple * stmt, std::set<unsigned int> *uses)
{
  // Get the list of addresses where the values should be stored
  const CExprList* store_addr_exprs = stmt->GetAddrExprs();
  // Add uses for all the store expressions
  for(alf::CExprList::const_list_iterator store_addr_expr = store_addr_exprs->ConstIterator();
      store_addr_expr != store_addr_exprs->InvalidIterator(); ++store_addr_expr) {
    // Check if we do a *e in the lhs side
    if(HasLoadOfVar(*store_addr_expr)) {
      GetUsesOfExpr(*store_addr_expr, uses);
    }
  }

  // Get the list of expressions generating values to be stored 
  const CExprList* value_exprs = stmt->GetExprs();
  // Add uses for all the values to be stored expressions
  for(alf::CExprList::const_list_iterator value_expr = value_exprs->ConstIterator();
      value_expr != value_exprs->InvalidIterator(); ++value_expr) {
    GetUsesOfExpr(*value_expr, uses);
  }
}
  
void
ALFDefsAndUsesAnalysis::  
GetUsesOfCallStmt(const alf::CCallStmtTuple * stmt, std::set<unsigned int> *uses)
{
  // The call statement use the variables of all the arguments, as
  // well as possible variables used to compute the address of the
  // called function.  Also, all variables in expressions used to
  // calculate where to store values should be added to the uses.

  // Add all variables in expression used to calculated the address
  // of the called function.
  const alf::AExpr* called_func_label_expr = stmt->GetLabelExpr();
  GetUsesOfExpr(called_func_label_expr, uses);

  // Add all variables in expressions used to calculate expressions to
  // put in the calling param area
  const alf::CExprList * arg_exprs = stmt->GetExprs();
  for(alf::CExprList::const_list_iterator arg_expr = arg_exprs->ConstIterator();
      arg_expr != arg_exprs->InvalidIterator(); ++arg_expr) {
    GetUsesOfExpr(*arg_expr, uses);
  }

  // Add all variables in expressions used to calculate addresses
  // where the return values should be stored at. 
  const alf::CExprList * ret_addr_exprs = stmt->GetAddrExprs();
  for(alf::CExprList::const_list_iterator ret_addr_expr = ret_addr_exprs->ConstIterator();
      ret_addr_expr != ret_addr_exprs->InvalidIterator(); ++ret_addr_expr) {
    if(HasLoadOfVar(*ret_addr_expr)) {
      GetUsesOfExpr(*ret_addr_expr, uses);
    }
  }
}

void
ALFDefsAndUsesAnalysis::  
GetUsesOfReturnStmt(const alf::CReturnStmtTuple * stmt, std::set<unsigned int> *uses)
{
  // Add all variables in the expressions specifying the return values
  // from the function of this statement.
  const alf::CExprList * ret_val_exprs = stmt->GetExprs();
  for(alf::CExprList::const_list_iterator ret_val_expr = ret_val_exprs->ConstIterator();
      ret_val_expr != ret_val_exprs->InvalidIterator(); ++ret_val_expr) {
    GetUsesOfExpr(*ret_val_expr, uses);
  }
}

// EXPR ->  LREF
//        | LABEL
//        | { load SIZE EXPR }
//        | { undefined SIZE }
//        | FREF
//        | { dyn_alloc SIZE FREF EXPR }
//        | { addr SIZE EXPR EXPR}
//        | NUM_VAL
//        | { OP SIZE* EXPR* }


// From the LCTES2006 paper
// -------------------------
// USES(PTS, c) = { } 
// USES(PTS, x) = {x} 
// USES(PTS, &x) = { } 
// USES(PTS, *e) = refs(PTS, e) U USES(PTS, e)
// USES(PTS, f(e1, ..., en)) = USES(PTS, e1) U ... U USES(PTS, en)

void
ALFDefsAndUsesAnalysis::
GetUsesOfExpr(const alf::AExpr * expr, std::set<unsigned int> *uses)
{
  // Check the type of the expression and act accordingly
  switch(expr->GetNodeType()) {
  case CGenericNode::TYPE_ADDR_EXPR_TUPLE:
    {
      // EXPR -> { addr SIZE FREF NUM_EXPR } 
      // Check if we have a node in the parse tree above it which is a
      // load. We then have a use of the variable.
      if(expr->GetParent(CGenericNode::TYPE_LOAD_EXPR_TUPLE)) {
	// Get the fref and insert its key into the set
	const alf::CAddrTuple *cast_expr = dynamic_cast<const alf::CAddrTuple *>(expr);
	const alf::CFRefTuple *fref = cast_expr->GetFref();
	unsigned int key = fref->GetKey();
	uses->insert(key);
      }
      else {
	// Else, it is an address taken subexpression. This is not a
	// use of the variable.
      }
      break;
    }
  case CGenericNode::TYPE_COMPADDR_EXPR_TUPLE:
    {
      // EXPR -> { addr SIZE FREF_EXPR NUM_EXPR }
      // Get the expression that should evaluate to a fref and call
      // the function recursively
      const alf::CCompAddrTuple *cast_expr = dynamic_cast<const alf::CCompAddrTuple *>(expr);
      const alf::AExpr * fref_expr = cast_expr->GetFRefExpr();
      GetUsesOfExpr(fref_expr, uses);
      break;
    }
   case CGenericNode::TYPE_LOAD_EXPR_TUPLE: 
     {
       // EXPR -> { load SIZE EXPR }
       // Here we return the variables of the subexpression as well as
       // their points-to-sets. i.e. USES(PTS, *e) = refs(PTS, e) U USES(PTS, e)
       const alf::CLoadExprTuple *cast_expr = dynamic_cast<const alf::CLoadExprTuple *>(expr);
       const AExpr * addr_expr = cast_expr->GetAddrExpr();
       std::set<unsigned int> vars_to_deref;
       GetUsesOfExpr(addr_expr, &vars_to_deref);
       for(std::set<unsigned int>::const_iterator v = vars_to_deref.begin();
	   v != vars_to_deref.end(); ++v) {
	 // Check if the variable can point to something
	 if(_pa->HasPointsToVars(*v)) {
	   // Yes, add its dereferenced variables to the uses
	   _pa->GetPointsToVars(*v, uses);
	 }
	 // Add the variable itself to the uses
	 uses->insert(*v);
       }
       break;
     }
  case CGenericNode::TYPE_OP_EXPR_TUPLE:
    {
      // EXPR -> { OP SIZE* EXPR* }
      // Here we just have to collect all updated variables in the sub-expressions.
      // This is made by callign the function recursively.
      const alf::COpNumExprTuple *cast_expr = dynamic_cast<const alf::COpNumExprTuple *>(expr);
      const alf::CExprList* exprs = cast_expr->GetNumExprs();
      for(CExprList::const_list_iterator e = exprs->ConstIterator();
	  e != exprs->InvalidIterator(); ++e) {
	GetUsesOfExpr(*e, uses);
      }
      break;
    }
  case CGenericNode::TYPE_FREF_TUPLE:
    {
      // EXPR -> FREF
      // Get the key of the fref tuple and insert it into the set
      const alf::CFRefTuple *cast_expr = dynamic_cast<const alf::CFRefTuple *>(expr);
      unsigned int key = cast_expr->GetKey();
      uses->insert(key);
      break;
    }
  case CGenericNode::TYPE_COMPLABEL_EXPR_TUPLE:
    {
      // EXPR -> ?
      const alf::CCompLabelTuple *cast_expr = dynamic_cast<const alf::CCompLabelTuple *>(expr);
      // Add variables used in the expression that is used to
      // determine the origin of the label
      const AExpr* lref_expr = cast_expr->GetLRefExpr();
      GetUsesOfExpr(lref_expr, uses);
      // Add variables used in the expression to calculate a numeric value
      const AExpr* num_expr = cast_expr->GetNumExpr();
      GetUsesOfExpr(num_expr, uses);
      break;
    }
  case CGenericNode::TYPE_LREF_TUPLE:
  case CGenericNode::TYPE_INTVAL_TUPLE:
  case CGenericNode::TYPE_FLOATVAL_TUPLE:
  case CGenericNode::TYPE_LABEL_TUPLE:
    {
      // Constant used variable here, just return
      break;
    }
  case CGenericNode::TYPE_DYNALLOC_EXPR_TUPLE:
    {
      // EXPR -> { dyn_alloc SIZE FREF EXPR }
      // Not yet supported
      assert(0);
      break;
    }
  case CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE:
    {
      // EXPR -> { undefined SIZE }
      // This is problematic. We do not know what variables that will be used.
      assert("undefined value can't be handled in RD analysis" == 0);
      break;
    } 
  default:
    {
      assert("This type of expression should not occur on rhs side of store" == 0);
      break;
    }
  } // end switch
}

// Function which checks if an expression loads a variable
bool
ALFDefsAndUsesAnalysis::
HasLoadOfVar(const alf::AExpr * expr)
{
  switch(expr->GetNodeType()) {
  case CGenericNode::TYPE_LOAD_EXPR_TUPLE: 
    {
      return true;
      break;
    }
  case CGenericNode::TYPE_OP_EXPR_TUPLE:
    {
      const alf::COpNumExprTuple *cast_expr = dynamic_cast<const alf::COpNumExprTuple *>(expr);
      const alf::CExprList* exprs = cast_expr->GetNumExprs();
      for(CExprList::const_list_iterator e = exprs->ConstIterator();
	  e != exprs->InvalidIterator(); ++e) {
	if(HasLoadOfVar(*e)) {
	  return true;
	}
      }
      return false;
      break;
    }
  default:
    {
      return false;
      break;
    }
  }
}

// -------------------------------------------------------
// To get the variables defined and used by an initialization
// -------------------------------------------------------
void
ALFDefsAndUsesAnalysis::
GetDefsAndUsesOfInit(const alf::CInitTuple * init, std::set<unsigned int> *defs, std::set<unsigned int> *uses)
{
  GetDefsOfInit(init, defs);
  GetUsesOfInit(init, uses);
}

void
ALFDefsAndUsesAnalysis::
GetDefsOfInit(const alf::CInitTuple * init, std::set<unsigned int> *defs)
{
  // Get the data area reference
  const CRefTuple * ref = init->GetRef();
  // The CRefTuple is a sym tab identifier which has a unique key
  assert(ref->HasKey());
  unsigned int key = ref->GetKey();
  // Add the identifier to the set of defs
  defs->insert(key);
}

void
ALFDefsAndUsesAnalysis::
GetUsesOfInit(const alf::CInitTuple * init, std::set<unsigned int> *uses)
{
  // We can not load any value in an init, and therefore we can not do
  // any uses
  return;
}

// -------------------------------------------------------
// To get the variables defined and used by an annotation 
// -------------------------------------------------------
void
ALFDefsAndUsesAnalysis::
GetDefsAndUsesOfAnnot(const CALFAbsAnnot * annot, std::set<unsigned int> *defs, std::set<unsigned int> *uses)
{
  GetDefsOfAnnot(annot, defs);
  GetUsesOfAnnot(annot, uses);
}

void
ALFDefsAndUsesAnalysis::
GetDefsOfAnnot(const CALFAbsAnnot * annot, std::set<unsigned int> *defs)
{
  // Get all the var := values assignments made in the abstract assignment 
  const list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > * var_vals_list = annot->VarValsList();

  // Loop through the parallel assignments in the abstract annotation 
  for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::const_iterator var_vals = var_vals_list->begin();
      var_vals != var_vals_list->end(); ++var_vals) {

    // Get the key of the updated variable
    CALFAbsAnnotVar * var = (*var_vals).first;
    assert(var->HasKey());
    unsigned int var_key = var->GetKey();
    // Add it to the defs set
    defs->insert(var_key);
  }
}

void
ALFDefsAndUsesAnalysis::
GetUsesOfAnnot(const CALFAbsAnnot * annot, std::set<unsigned int> *uses)
{
  // We can not use a variable value in an annot, only variables addresses. Thus 
  // no uses can be made. 
  return;
}

// -------------------------------------------------------
// To get the variables defined and used by a declaration
// -------------------------------------------------------
void
ALFDefsAndUsesAnalysis::
GetDefsAndUsesOfAlloc(const alf::CAllocTuple * decl, std::set<unsigned int> *defs, std::set<unsigned int> *uses)
{
  GetDefsOfAlloc(decl, defs);
  GetUsesOfAlloc(decl, uses);
}

void
ALFDefsAndUsesAnalysis::
GetDefsOfAlloc(const alf::CAllocTuple * decl, std::set<unsigned int> *defs)
{
  // The alloc is a symtab identifier, so we just add its key
  defs->insert(decl->GetKey());
}


void
ALFDefsAndUsesAnalysis::
GetUsesOfAlloc(const alf::CAllocTuple * alloc, std::set<unsigned int> *uses)
{
  // No uses in an alloc
}

// ---------------------------------------
// Help function for extracting the variables occurriding in volatile
// vars from a set of annotations
// -------------------------------------------------------
void
ALFDefsAndUsesAnalysis::
ExtractVolatileVarsFromAnnots(CALFAbsAnnotStorage * annots)
{
  if(!annots || !annots->HasVolatileAbsAnnots()) {
    // Skip processing if no volatle annots are present
    return;
  }
  else {
    // Get all the variables defined in all the volatile abs annots
    std::list<CALFAbsAnnot *> * vol_abs_annot_list = annots->GetVolatileAbsAnnots();
    for(std::list<CALFAbsAnnot *>::iterator vol_abs_annot = vol_abs_annot_list->begin();
	vol_abs_annot != vol_abs_annot_list->end(); ++vol_abs_annot) {
      // Since we can not convert a set of signed ints to a set of unsigned ints
      std::set<int> defs;
      (*vol_abs_annot)->GetDefs(&defs);
      for(std::set<int>::iterator def = defs.begin(); def != defs.end(); ++def) {
	_volatile_vars.insert(*def);
      }
    }
  }
}

// -------------------------------------------------------
// Help function for extracting the variables occurriding in volatile
// vars from a set of initializations
// -------------------------------------------------------
void
ALFDefsAndUsesAnalysis::
ExtractVolatileVarsFromInits(CInitList * inits)
{
  if(!inits || inits->ElementCount() == 0) {
    // Skip processing if no volatle annots are present
    return;
  }
  else {
    // Get all the variables defined in all the volatile inits
    for(CInitList::list_iterator init = inits->Iterator(); init != inits->InvalidIterator(); ++init) {
      // Check if it is a volatile initialization
      if((*init)->GetInitOption() == CInitTuple::VOLATILE) {
	// Get the key of the frame written to
	unsigned int lhs_key = (*init)->GetRef()->GetKey();
	// Add the key to the volatile vars set. 
	_volatile_vars.insert(lhs_key);
      }
    }
  }
}


// -------------------------------------------------------
// GetUpdatedVarsOfLhsAddrExpr -
// Function that given a lhs ADDR_EXPR in a store statement returns the
// variables possibly updated. We say possibly since the analysis rely 
// on the pointer analysis, and the pointer analysis is over approximative.
//
// The following are the valid BNF rules for lhs ADDR_EXPR in store statements.
//
// STMT -> 
// | { store ADDR_EXPR+ with EXPR+ }
//
// ADDR_EXPR -> 
// | { addr SIZE_IN_BITS FREF NUM_EXPR }              // CAddrTuple TYPE_ADDR_EXPR_TUPLE 
// | { addr SIZE_IN_BITS FREF_EXPR NUM_EXPR }         // CCompAddrTuple TYPE_COMPADDR_EXPR_TUPLE 
// | { load SIZE_IN_BITS ADDR_EXPR }                  // CLoadExprTuple TYPE_LOAD_EXPR_TUPLE
// | { add SIZE_IN_BITS ADDR_EXPR NUM_EXPR NUM_EXPR } // COpNumExprTuple TYPE_OP_EXPR_TUPLE && GetOperator()==OP_TYPE_ADD   
// | { add SIZE_IN_BITS NUM_EXPR ADDR_EXPR NUM_EXPR } // COpNumExprTuple TYPE_OP_EXPR_TUPLE && GetOperator()==OP_TYPE_ADD 
// | { sub SIZE_IN_BITS ADDR_EXPR NUM_EXPR NUM_EXPR } // COpNumExprTuple TYPE_OP_EXPR_TUPLE && GetOperator()==OP_TYPE_SUB
// | { undefined SIZE_IN_BITS }                       // CUndefinedExprTuple TYPE_UNDEFINED_EXPR_TUPLE
//
// -------------------------------------------------------
void 
ALFDefsAndUsesAnalysis::
GetUpdatedVarsOfLhsAddrExpr(alf::AExpr *expr, std::set<unsigned int> *updated_vars)
{
  assert(expr);

  // Check that we have got a valid lhs address expression
  bool valid_lhs_expr = false;
  if(expr->IsType(alf::CGenericNode::TYPE_ADDR_EXPR_TUPLE) || 
     expr->IsType(alf::CGenericNode::TYPE_COMPADDR_EXPR_TUPLE) ||
     expr->IsType(alf::CGenericNode::TYPE_LOAD_EXPR_TUPLE) || 
     expr->IsType(alf::CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE))
    valid_lhs_expr = true;
  else if(expr->IsType(alf::CGenericNode::TYPE_OP_EXPR_TUPLE)) {
    COpNumExprTuple * op_num_expr = dynamic_cast<alf::COpNumExprTuple *>(expr);
    if(((op_num_expr->GetOperator() == alf::COpNumExprTuple::OP_TYPE_ADD) ||
	(op_num_expr->GetOperator() == alf::COpNumExprTuple::OP_TYPE_SUB)) && 
       op_num_expr->GetNumExprs()->ElementCount() == 3) {
      valid_lhs_expr = true;
    }
  }
  
  // Make sure that we have got a valid lhs expression
  assert(valid_lhs_expr);
  
  // Call the real function which derives the updated variables
  GetUpdatedVarsOfExpr(expr, updated_vars);
}

// Help function for deriving which variables that may be updated in a
// lhs ADDR_EXPR. Extracted so that it can be called recursively.
void 
ALFDefsAndUsesAnalysis::
GetUpdatedVarsOfExpr(const AExpr *expr, std::set<unsigned int> *updated_vars)
{
  // Check the type of the expression and act accordingly
  switch(expr->GetNodeType()) {
  case CGenericNode::TYPE_ADDR_EXPR_TUPLE:
    {
      // Get the fref and insert its key into the set
      const alf::CAddrTuple *cast_expr = dynamic_cast<const alf::CAddrTuple *>(expr);
      const alf::CFRefTuple *fref = cast_expr->GetFref();
      unsigned int key = fref->GetKey();
      updated_vars->insert(key);
      break;
    }
  case CGenericNode::TYPE_COMPADDR_EXPR_TUPLE:
    {
      // Get the expression that should evaluate to a fref and call
      // the function recursively
      const alf::CCompAddrTuple *cast_expr = dynamic_cast<const alf::CCompAddrTuple *>(expr);
      const alf::AExpr * fref_expr = cast_expr->GetFRefExpr();
      GetUpdatedVarsOfExpr(fref_expr, updated_vars);
      break;
    }
   case CGenericNode::TYPE_LOAD_EXPR_TUPLE: 
     {
       // Here we do not return the variables of the subexpression,
       // but rather the points-to-set of these. Note that we need not
       // bother which variables are pointers, non-pointers will
       // result zero sized points-to-set.
       const alf::CLoadExprTuple *cast_expr = dynamic_cast<const alf::CLoadExprTuple *>(expr);
       const AExpr * addr_expr = cast_expr->GetAddrExpr();
       std::set<unsigned int> vars_to_deref;
       GetUpdatedVarsOfExpr(addr_expr, &vars_to_deref);
       for(std::set<unsigned int>::const_iterator v = vars_to_deref.begin();
	   v != vars_to_deref.end(); ++v) {
	 if(_pa->HasPointsToVars(*v)) {
	   // Add the dereferenced variables to the argument set
	   _pa->GetPointsToVars(*v, updated_vars);
	 }
       }
       break;
     }
  case CGenericNode::TYPE_OP_EXPR_TUPLE:
    {
      // Here we just have to collect all updated variables in the sub-expressions.
      // This is made by callign the funbction recursively.
      const alf::COpNumExprTuple *cast_expr = dynamic_cast<const alf::COpNumExprTuple *>(expr);
      const alf::CExprList* exprs = cast_expr->GetNumExprs();
      for(CExprList::const_list_iterator e = exprs->ConstIterator();
	  e != exprs->InvalidIterator(); ++e) {
	GetUpdatedVarsOfExpr(*e, updated_vars);
      }
      break;
    }
  case CGenericNode::TYPE_FREF_TUPLE:
    {
      // Get the key of the fref tuple and insert it into the set
      const alf::CFRefTuple *cast_expr = dynamic_cast<const alf::CFRefTuple *>(expr);
      unsigned int key = cast_expr->GetKey();
      updated_vars->insert(key);
      break;
    }
  case CGenericNode::TYPE_INTVAL_TUPLE:
  case CGenericNode::TYPE_FLOATVAL_TUPLE:
  case CGenericNode::TYPE_LREF_TUPLE:
  case CGenericNode::TYPE_LABEL_TUPLE:
  case CGenericNode::TYPE_COMPLABEL_EXPR_TUPLE:
  case CGenericNode::TYPE_DYNALLOC_EXPR_TUPLE:
    {
      // No variables here, just return
      break;
    }
  case CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE:
    {
      // This is problematic. We do not know what variables that will be updated.
      assert("undefined value can't be handled in RD analysis" == 0);
      break;
    } 
  default:
    {
      assert("This type of expression should not occur on lhs side of store" == 0);
      break;
    }
  } // end switch
}

// Use the symbol table to get the size in bits of a frame referred to
Size 
ALFDefsAndUsesAnalysis::
GetSizeOfFrameByKey(unsigned int key, CSymTabBase * symtab) 
{
  // Get the symbol table entry and identifier corresponding to the key
  const CSymTabEntry * entry = symtab->Lookup(key); 
  const CSymTabIdentifier * id = entry->GetIdentifier(); 

  // Check if the identifier is an alloc tuple 
  const CAllocTuple * alloc = dynamic_cast<const CAllocTuple *>(id); 
  if(alloc != NULL) {
    return alloc->GetFrameSize()->GetSizeInBits();
  }
  
  // Check if the identrier is a fref tuple
  const CFRefTuple * fref = dynamic_cast<const CFRefTuple *>(id);
  if(fref != NULL) {
    return fref->GetSize()->GetSizeInBits();
  }

  // Check if the identrier is a lref tuple
  // const CLRefTuple * lref = dynamic_cast<const CLRefTuple *>(id);
  //   if(lref != NULL) {
  //     return lref->GetSize()->GetSizeInBits();
  //   }

  // Check if the identrier is a ref 
  // const CRefTuple * ref = dynamic_cast<const CRefTuple *>(id);
  //   if(ref != NULL) {
  //     return ...
  //   }

  // ADD MORE!!!! 

  assert("Not possible to get the size of the sym tab identifier with given key" == 0);
  return 0;
}


// To get the size of an expression evaluating to a value
Size 
ALFDefsAndUsesAnalysis::
GetSizeOfValueExpr(const AExpr * expr) 
{
  // We use the functionality provided by AExpr
  return expr->GetSizeOfEvaluatedExpr();
}
  


