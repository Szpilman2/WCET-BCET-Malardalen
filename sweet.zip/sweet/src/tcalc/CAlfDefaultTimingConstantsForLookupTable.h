// $Id $

#ifndef ALF_DEFAULT_TIMING_CONSTANTS_FOR_LOOKUP_TABLE_H_
#define ALF_DEFAULT_TIMING_CONSTANTS_FOR_LOOKUP_TABLE_H_

// ---------------------------------
// Program run
// ---------------------------------

const double defaultTimingConstant_PROG_RUN = 0;

// ---------------------------------
// Generic nodes
// ---------------------------------

// Top-level and general
const double defaultTimingConstant_TYPE_LIST_NODE 		= 0;
const double defaultTimingConstant_TYPE_ALF_TUPLE 		= 0;
const double defaultTimingConstant_TYPE_DECL_LIST 		= 0;
const double defaultTimingConstant_TYPE_LAU_TUPLE 		= 0;
const double defaultTimingConstant_TYPE_EXPORTS_TUPLE 		= 0;
const double defaultTimingConstant_TYPE_IMPORTS_TUPLE 		= 0;
const double defaultTimingConstant_TYPE_SCOPE_TUPLE 		= 0;
const double defaultTimingConstant_TYPE_DEFAULT_TUPLE 	= 0;

// References
const double defaultTimingConstant_TYPE_REF_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_FREF_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_FREF_LIST 	= 0;
const double defaultTimingConstant_TYPE_LREF_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_LREF_LIST 	= 0;

// Expressions
const double defaultTimingConstant_TYPE_EXPR 				= 0;
const double defaultTimingConstant_TYPE_ADDR_EXPR_TUPLE 		= 0;
const double defaultTimingConstant_TYPE_OP_EXPR_TUPLE		= 0; // own level of abstraction - see below
const double defaultTimingConstant_TYPE_COMPADDR_EXPR_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_UNDEFINED_EXPR_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_LOAD_EXPR_TUPLE 		= 0;
const double defaultTimingConstant_TYPE_DYNALLOC_EXPR_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_UNKNOWN_EXPR 		= 0;

const double defaultTimingConstant_TYPE_ALLOC_TUPLE 			= 0; 

// Values
const double defaultTimingConstant_TYPE_VAL 			= 0;
const double defaultTimingConstant_TYPE_NUM_VAL 		= 0;
const double defaultTimingConstant_TYPE_FLOATVAL_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_INTVAL_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_CHARSTRING_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_FLOAT_LIST 	= 0;
const double defaultTimingConstant_TYPE_INT_LIST 		= 0;
const double defaultTimingConstant_TYPE_STRING 		= 0; 
const double defaultTimingConstant_TYPE_UNKNOWN_VAL 	= 0;

const double defaultTimingConstant_TYPE_SIZE 	= 0;
const double defaultTimingConstant_TYPE_SIZE_LIST = 0;

// Constants
const double defaultTimingConstant_TYPE_CONST = 0;
const double defaultTimingConstant_TYPE_CONSTREPEAT_TUPLE = 0;
const double defaultTimingConstant_TYPE_CONST_LIST = 0;
const double defaultTimingConstant_TYPE_UNKNOWN_CONST = 0;

// Inits
const double defaultTimingConstant_TYPE_INIT_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_INIT_LIST 	= 0;

// Functions
const double defaultTimingConstant_TYPE_FUNC_TUPLE 		= 0;
const double defaultTimingConstant_TYPE_FUNC_LIST 		= 0;
const double defaultTimingConstant_TYPE_ARGDECL_LIST 	= 0;

// Statements
const double defaultTimingConstant_TYPE_FREE_STMT_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_NULL_STMT_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_STORE_STMT_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_JUMP_STMT_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_RETURN_STMT_TUPLE = 0;
const double defaultTimingConstant_TYPE_CALL_STMT_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_SWITCH_STMT_TUPLE = 0;
const double defaultTimingConstant_TYPE_STMT 			= 0;
const double defaultTimingConstant_TYPE_STMT_LIST 	= 0;
const double defaultTimingConstant_TYPE_UNKNOWN_STMT 	= 0;

// Target
const double defaultTimingConstant_TYPE_TARGET 		= 0;
const double defaultTimingConstant_TYPE_TARGET_TUPLE 	= 0;

// Labels
const double defaultTimingConstant_TYPE_COMPLABEL_EXPR_TUPLE 	= 0;
const double defaultTimingConstant_TYPE_LABEL_TUPLE 	= 0;

// Macros
const double defaultTimingConstant_TYPE_MACRO_CALL_TUPLE 		= 0;
const double defaultTimingConstant_TYPE_MACRO_FORMAL_ARG 		= 0;
const double defaultTimingConstant_TYPE_MACRO_FORMAL_ARG_LIST 	= 0;
const double defaultTimingConstant_TYPE_MACRO_DEF_TUPLE 		= 0;
const double defaultTimingConstant_TYPE_MACRO_DEF_LIST 		= 0;

// ---------------------------------
// Expressions
// ---------------------------------
const double defaultTimingConstant_OP_TYPE_NEG = 0;
const double defaultTimingConstant_OP_TYPE_ADD = 0;
const double defaultTimingConstant_OP_TYPE_C_ADD = 0;
const double defaultTimingConstant_OP_TYPE_SUB = 0;
const double defaultTimingConstant_OP_TYPE_C_SUB = 0;
const double defaultTimingConstant_OP_TYPE_U_MUL = 0;
const double defaultTimingConstant_OP_TYPE_S_MUL = 0;
const double defaultTimingConstant_OP_TYPE_U_DIV = 0;
const double defaultTimingConstant_OP_TYPE_S_DIV = 0;
const double defaultTimingConstant_OP_TYPE_U_MOD = 0;
const double defaultTimingConstant_OP_TYPE_S_MOD = 0;
const double defaultTimingConstant_OP_TYPE_L_SHIFT = 0;
const double defaultTimingConstant_OP_TYPE_R_SHIFT = 0;
const double defaultTimingConstant_OP_TYPE_R_SHIFT_A = 0;
const double defaultTimingConstant_OP_TYPE_S_EXT = 0;
const double defaultTimingConstant_OP_TYPE_NOT = 0;
const double defaultTimingConstant_OP_TYPE_AND = 0;
const double defaultTimingConstant_OP_TYPE_OR = 0;
const double defaultTimingConstant_OP_TYPE_XOR = 0;
const double defaultTimingConstant_OP_TYPE_F_NEG = 0;
const double defaultTimingConstant_OP_TYPE_F_ADD = 0;
const double defaultTimingConstant_OP_TYPE_F_SUB = 0;
const double defaultTimingConstant_OP_TYPE_F_MUL = 0;
const double defaultTimingConstant_OP_TYPE_F_DIV = 0;
const double defaultTimingConstant_OP_TYPE_F_TO_F = 0;
const double defaultTimingConstant_OP_TYPE_F_TO_U = 0;
const double defaultTimingConstant_OP_TYPE_F_TO_S = 0;
const double defaultTimingConstant_OP_TYPE_U_TO_F = 0;
const double defaultTimingConstant_OP_TYPE_S_TO_F = 0;
const double defaultTimingConstant_OP_TYPE_EQ = 0;
const double defaultTimingConstant_OP_TYPE_NEQ = 0;
const double defaultTimingConstant_OP_TYPE_U_LT = 0;
const double defaultTimingConstant_OP_TYPE_U_GE = 0;
const double defaultTimingConstant_OP_TYPE_U_GT = 0;
const double defaultTimingConstant_OP_TYPE_U_LE = 0;
const double defaultTimingConstant_OP_TYPE_S_LT = 0;
const double defaultTimingConstant_OP_TYPE_S_GE = 0;
const double defaultTimingConstant_OP_TYPE_S_GT = 0;
const double defaultTimingConstant_OP_TYPE_S_LE = 0;
const double defaultTimingConstant_OP_TYPE_F_EQ = 0;
const double defaultTimingConstant_OP_TYPE_F_NE = 0;
const double defaultTimingConstant_OP_TYPE_F_LT = 0;
const double defaultTimingConstant_OP_TYPE_F_GE = 0;
const double defaultTimingConstant_OP_TYPE_F_GT = 0;
const double defaultTimingConstant_OP_TYPE_F_LE = 0;
const double defaultTimingConstant_OP_TYPE_IF = 0;
const double defaultTimingConstant_OP_TYPE_B2N = 0;
const double defaultTimingConstant_OP_TYPE_EXP2 = 0;
const double defaultTimingConstant_OP_TYPE_SELECT = 0;
const double defaultTimingConstant_OP_TYPE_CONC = 0;
const double defaultTimingConstant_OP_TYPE_REPEAT = 0;

// ---------------------------------
// Statements
// ---------------------------------
const double defaultTimingConstant_GS_SKIP = 0;
const double defaultTimingConstant_GS_STORE = 0;
const double defaultTimingConstant_GS_COND = 0;
const double defaultTimingConstant_GS_JUMP = 0;
const double defaultTimingConstant_GS_CALL = 0;
const double defaultTimingConstant_GS_ENTER = 0;
const double defaultTimingConstant_GS_RETURN = 0;
const double defaultTimingConstant_GS_RESULT = 0;
const double defaultTimingConstant_GS_FREE = 0;
const double defaultTimingConstant_GS_SCOPE = 0;
const double defaultTimingConstant_GS_UNKNOWN = 0;
const double defaultTimingConstant_GS_OTHER = 0;
const double defaultTimingConstant_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_GS_ABS_STORE_POINTER = 0;

// ---------------------------------
// Statements pairs
// ---------------------------------
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_SKIP_AND_GS_ABS_STORE_POINTER = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_STORE_AND_GS_ABS_STORE_POINTER = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_COND_AND_GS_ABS_STORE_POINTER = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_JUMP_AND_GS_ABS_STORE_POINTER = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_CALL_AND_GS_ABS_STORE_POINTER = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_ENTER_AND_GS_ABS_STORE_POINTER = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_RETURN_AND_GS_ABS_STORE_POINTER = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_RESULT_AND_GS_ABS_STORE_POINTER = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_FREE_AND_GS_ABS_STORE_POINTER = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_SCOPE_AND_GS_ABS_STORE_POINTER = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_UNKNOWN_AND_GS_ABS_STORE_POINTER = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_OTHER_AND_GS_ABS_STORE_POINTER = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_INT_AND_GS_ABS_STORE_POINTER = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_FLOAT_AND_GS_ABS_STORE_POINTER = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_SKIP = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_STORE = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_COND = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_JUMP = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_CALL = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_ENTER = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_RETURN = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_RESULT = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_FREE = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_SCOPE = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_UNKNOWN = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_OTHER = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_ABS_STORE_INT = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_ABS_STORE_FLOAT = 0;
const double defaultTimingConstant_PAIR_GS_ABS_STORE_POINTER_AND_GS_ABS_STORE_POINTER = 0;

#endif
