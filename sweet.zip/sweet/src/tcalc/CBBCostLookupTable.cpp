// $Id $

#include "tcalc/CBBCostLookupTable.h"
#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include <cstdlib>

#include <stdio.h>
#include <stdlib.h>

using namespace std;

// ---------------------------------
// To create a new lookup table by reading timing values for 
// Basic block identifiers
// ---------------------------------
CBBCostLookupTable::
CBBCostLookupTable(const std::string & filename) 
{
  // Read timing consta%nts from the file and update maps
  ReadCostInfoFromFile(filename);
  // Create zero range
  _zero_range = new CIntegerRange(0,0);
}

// ---------------------------------
// To delete a table
// ---------------------------------
CBBCostLookupTable::
~CBBCostLookupTable()
{
  // Delete all integer ranges in the node to integer range map
  for(std::map<std::string, CIntegerRange *>::iterator bb2c = _bb_node_to_cost.begin();
      bb2c != _bb_node_to_cost.end(); ++bb2c) {
    delete (*bb2c).second;
  }
  // Delete all integer ranges in the edge to integer range map
  for(std::map<std::pair<std::string, std::string>, CIntegerRange *>::iterator e2c = _bb_edge_to_cost.begin();
      e2c != _bb_edge_to_cost.end(); ++e2c) {
    delete (*e2c).second;
  }
  // Delete the zero range
  delete _zero_range;
}

// ---------------------------------
// Help function for reading a cost table from file
// ---------------------------------
void
CBBCostLookupTable::
ReadCostInfoFromFile(const std::string & filename)
{
  // To hold the currenty read basic blocks and currently read values
  std::vector<std::string> bbs;
  std::vector<int> costs;
  
  // Open the file for reading
  std::ifstream fs;                  
  fs.open(filename.c_str(), ios::in); 
  
  // Check that we where able to open the file
  if (!fs) { 
    cerr << "Basic block cost table input file '"  << filename << "' cannot be opened!\n";
    assert(0);
  }
  
  // To hold what type of item we last read
  bool bb_last_read = false;

  // Read until no more items
  while(!fs.eof()) {

    // Read the next item
    string s;
    fs >> s;

    // Check if the first char was an integer inbetween 0 or 9 or a minus
    if(((s.c_str())[0] >= '0' && (s.c_str())[0] <= '9') || (s.c_str())[0] == '-') {
      // Yes, convert the item to an integer
      char *p;
      int cost = strtol(s.c_str(), &p, 0);

      // Do some checking that ok
      if(bb_last_read == true || (bb_last_read == false && costs.size() == 1)) {
	costs.push_back(cost);
	bb_last_read = false;
      }
      else {
	cerr << "Erroneous token string at cost "  << cost << "\n";
	assert(0);
      }
    }
    // Check if it was a string
    else if(s != "\n" && s != "\0") {
      // Check if was the first item read, or if we have already read a BB
      // and should read the next one.
      if((bb_last_read == false && bbs.size() == 0 && costs.size() == 0) ||
	 (bb_last_read == true && bbs.size() == 1)) {
	// Interpret item as a basic block id
	bbs.push_back(s);
	bb_last_read = true;
      }
      // Check if we should create a new pair
      else if(bb_last_read == false && costs.size() > 0) {
	// We should store the already read stuff
	StoreCostInfoAndResetVectors(bbs, costs);
	// Store the new item as a basic block id
	bbs.push_back(s);
	bb_last_read = true;
      }
      else {
	cerr << "Erroneous token string at bb " << s << "\n";
	assert(0);
      } 
    }
    // Check if we have reached the end of file
    else if(fs.eof()) { 
      continue;
    }
    // Else, something is wrong
    else {
      cerr << "Erroneous token string at bb " << s << "\n";
      assert(0);
    } 
  }

  // Check if we have some items to store
  if(bb_last_read == false && costs.size() > 0) {
    // We should store the already read stuff
    StoreCostInfoAndResetVectors(bbs, costs);
  }
}

// To check if we have BB node costs
bool 
CBBCostLookupTable::
HasBBNodeCosts() const 
{ 
  return (_bb_node_to_cost.size() > 0); 
}

// To check if we have BB edge costs
bool 
CBBCostLookupTable::
HasBBEdgeCosts() const 
{ 
  return (_bb_edge_to_cost.size() > 0); 
} 

// To check if we have a BB node cost
bool 
CBBCostLookupTable::
HasBBNodeCost(std::string bb_id) const
{
  return (_bb_node_to_cost.find(bb_id) != _bb_node_to_cost.end());
}

// To check if we have a BB edge cost
bool 
CBBCostLookupTable::
HasBBEdgeCost(std::string from_bb_id, std::string to_bb_id) const
{
  return (_bb_edge_to_cost.find(std::make_pair(from_bb_id, to_bb_id)) != _bb_edge_to_cost.end());
}

// To get a BB node costs
const CIntegerRange * 
CBBCostLookupTable::
LookupBBNodeCost(std::string bb_id) const
{
  std::map<std::string, CIntegerRange *>::const_iterator it = _bb_node_to_cost.find(bb_id);
  if(it != _bb_node_to_cost.end())
    return (*it).second;
  else
    return _zero_range;
}

// To get a BB edge costs
const CIntegerRange * 
CBBCostLookupTable::
LookupBBEdgeCost(std::string from_bb_id, std::string to_bb_id) const
{
  std::map<std::pair<std::string, std::string>, CIntegerRange *>::const_iterator it = 
    _bb_edge_to_cost.find(std::make_pair(from_bb_id, to_bb_id));
  if(it != _bb_edge_to_cost.end())
    return (*it).second;
  else
    return _zero_range;
}

// Help function for updating maps when info has been read
void
CBBCostLookupTable::
StoreCostInfoAndResetVectors(std::vector<std::string> & bbs, std::vector<int> & costs)
{
  // We have a single basic block 
  if(bbs.size() == 1) {
    std::string bb = *(bbs.begin());
    if(costs.size() == 1) {
      int cost = *(costs.begin());
      _bb_node_to_cost[bb] = new CIntegerRange(cost, cost);
    }
    if(costs.size() == 2) {
      int cost1 = *(costs.begin());
      int cost2 = *(costs.rbegin());
      assert(cost1 <= cost2);
      _bb_node_to_cost[bb] = new CIntegerRange(cost1, cost2);
    }
  }
  // We have a basic block edge
  else if(bbs.size() == 2) {
    std::string from_bb = *(bbs.begin());
    std::string to_bb = *(bbs.rbegin());
    if(costs.size() == 1) {
      int cost = *(costs.begin());
      _bb_edge_to_cost[std::make_pair(from_bb, to_bb)] = new CIntegerRange(cost, cost);
    }
    if(costs.size() == 2) {
      int cost1 = *(costs.begin());
      int cost2 = *(costs.rbegin());
      assert(cost1 <= cost2);
      _bb_edge_to_cost[std::make_pair(from_bb, to_bb)] = new CIntegerRange(cost1, cost2);
    }
  }
  // Remove all temporaries
  bbs.erase(bbs.begin(), bbs.end());
  costs.erase(costs.begin(), costs.end());  
}

// ---------------------------------
// To print a cost lookup table template to file
// ---------------------------------
void 
CBBCostLookupTable::
PrintToFile(std::string file_name) const
{
  // Open a file for reading
  ofstream file_stream(file_name.c_str());
  if (!file_stream) { 
    cerr << "Output file_stream  '" << file_name << "' cannot be opened!\n";
    exit(-2);
  }
  Print(file_stream);

  // Close the file
  file_stream.close();
}

void 
CBBCostLookupTable::
Print(std::ostream &o) const
{
  // Print all node to cost mappings
  for(std::map<std::string, CIntegerRange *>::const_iterator bb2c = _bb_node_to_cost.begin();
      bb2c != _bb_node_to_cost.end(); ++bb2c) {
    o << (*bb2c).first << " ";
    o << (*bb2c).second->L() << " "; 
    if((*bb2c).second->L() != (*bb2c).second->U()) {
      o << (*bb2c).second->U();
    }
    o << std::endl;
  }

  // Print all edge to cost mappings
  for(std::map<std::pair<std::string, std::string>, CIntegerRange *>::const_iterator e2c = _bb_edge_to_cost.begin();
      e2c != _bb_edge_to_cost.end(); ++e2c) {
    o << (*e2c).first.first << " ";
    o << (*e2c).first.second << " ";
    o << (*e2c).second->L() << " "; 
    if((*e2c).second->L() != (*e2c).second->U()) {
      o << (*e2c).second->U();
    }
    o << std::endl;
  }
}


//---------------------------------
// Alternative printing function
//---------------------------------
ostream &operator << (ostream &o, const CBBCostLookupTable &a)
{
  a.Print(o);
  return o;
}
