// $Id $

#ifndef BB_COSTLOOKUPTABLE_H
#define BB_COSTLOOKUPTABLE_H

#include <map>
#include <string>
#include <vector>
#include <iostream>

// To get the needed types
#include "ae/CIntegerRange.h"

// -------------------------------------------------------
// CBBCostLookupTable -
// Reads timing costs for BB nodes and edges from a file. Either the 
// BB has a single cost associated to it, alternatively 
// it has a lower and an upper bound. Each row in the file
// should look like: 
// <BBID> <COST>                  // A node with a single cost  
// <BBID> <COST1> <COST2>         // A node with a lower and upper cost 
// <BBID> <BBID> <COST>           // An edge with a single cost
// <BBID> <BBID> <COST1> <COST2>  // An edge with a single cost
// where <BBID> is a string not starting with a number or a - 
// and <COST> is a integer starting with a number or a -.
// In the cases to costs are given COST1 must be <= COST 2
//
// Example:
// BB1 47
// BB2 10 12
// BB3 -1 1
// BB1 BB2 -1
// BB2 BB3 -3 -4
// 
// The resulting data structure will be used by AE time cost recorder
// and collector to derive a BCET and WCET estimate already in the AE.
//  
// Author: andreas.ermedalh@mdh.se 20110505
// -------------------------------------------------------
class CBBCostLookupTable 
{
public:
    
  // To create and delete the object. Without any input argument
  // a default table is created. With an argument the table is read 
  // from a file. 
  CBBCostLookupTable(const std::string & filename);
  ~CBBCostLookupTable();
  
  // To check what types of costs we have
  bool HasBBNodeCosts() const;
  bool HasBBEdgeCosts() const;

  // To check if a certain cost is held by the lookup table
  bool HasBBNodeCost(std::string bb_id) const;
  bool HasBBEdgeCost(std::string from_bb_id, std::string to_bb_id) const;

  // To get the cost of a a basic block or an edge inbetween basic
  // blocks. Will return a 0..0 range if no such consts exists.
  const CIntegerRange * LookupBBNodeCost(std::string bb_id) const;
  const CIntegerRange * LookupBBEdgeCost(std::string from_bb_id, std::string to_bb_id) const;
  
  // To print the cost lookup table
  void PrintToFile(std::string file_name) const;
  void Print(std::ostream &o = std::cout) const;

protected:
  
  // Function which do the actual reading of bbids and costs. 
  void ReadCostInfoFromFile(const std::string & filename);

  // Help function for updating the below maps when info has been read
  void StoreCostInfoAndResetVectors(std::vector<std::string> & bbs, std::vector<int> & costs);

  // Maps holding the costs of basic blocks and edges inbetween basic blocks
  std::map<std::string, CIntegerRange *> _bb_node_to_cost;
  std::map<std::pair<std::string, std::string>, CIntegerRange *> _bb_edge_to_cost;
  // A integer range consting of two zeros
  CIntegerRange * _zero_range;
};

// Alternative printing function
std::ostream &operator << (std::ostream &o, const CBBCostLookupTable &a);

#endif
