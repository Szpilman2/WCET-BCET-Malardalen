// $Id $

#include "CAlfCostLookupTable.h"
#include "CAlfDefaultTimingConstantsForLookupTable.h"
#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include <cstdlib>

using namespace std;

namespace alf
{

// ---------------------------------
// To create a new lookup table. Uses simpleWCETconst.h to assign 
// default timing values to ALf code constructs.
// ---------------------------------
CAlfCostLookupTable::
CAlfCostLookupTable() 
{
  SetAllTimingConstants(0);
}

// ---------------------------------
// To create a new lookup table by reading timing values for 
// ALf code constructs from a file.
// ---------------------------------
CAlfCostLookupTable::
CAlfCostLookupTable(const string & filename) 
{
  // Set all values to 0 as default
  SetAllTimingConstants(0);

  // Read timing constants from the file
  ReadTimingConstantsFromFile(filename);
}

// ---------------------------------
// To delete a table
// ---------------------------------
CAlfCostLookupTable::
~CAlfCostLookupTable()
{
  // Do nothing, the maps and their content will be deleted
}

// ---------------------------------
// Help function for reading a cost table from file
// ---------------------------------
void
CAlfCostLookupTable::
ReadTimingConstantsFromFile(const std::string & filename)
{
  // Open the file for reading
  ifstream source;                         
  source.open(filename.c_str(), ios::in); 
  
  // Check that we where able to open the file
  if (!source) { 
		cerr << "Cost table input file '"  << filename << "' cannot be opened!\n";
		exit(-2);
	}
  
  // Read until end of file
  while(!source.eof()) {

    // Get a ALF code construct identifier
    string identifier;
    source >> identifier;

    if(source.eof()) continue; // ignore string without any value

    // Get the value that should be associated to the identifier
    double value;
    source >> value;

    // The following do block is executed at most once; it's used to
    // be able to used the break keyword to keep the code following it
    // from being executed
    do
    {
       // Program run
       if(identifier == "PROG_RUN") {_prog_run_cost = value; break; } 

       // Stmt types
       if (identifier == "TYPE_LIST_NODE") {_node_to_cost[CGenericNode::TYPE_LIST_NODE] = value; break;} 
       if (identifier == "TYPE_ALF_TUPLE") {_node_to_cost[CGenericNode::TYPE_ALF_TUPLE] = value; break;} 
       if (identifier == "TYPE_DECL_LIST") {_node_to_cost[CGenericNode::TYPE_DECL_LIST] = value; break;} 
       if (identifier == "TYPE_LAU_TUPLE") {_node_to_cost[CGenericNode::TYPE_LAU_TUPLE] = value; break;} 
       if (identifier == "TYPE_EXPORTS_TUPLE") {_node_to_cost[CGenericNode::TYPE_EXPORTS_TUPLE] = value; break;} 
       if (identifier == "TYPE_IMPORTS_TUPLE") {_node_to_cost[CGenericNode::TYPE_IMPORTS_TUPLE] = value; break;} 
       if (identifier == "TYPE_FREF_LIST") {_node_to_cost[CGenericNode::TYPE_FREF_LIST] = value; break;} 
       if (identifier == "TYPE_LREF_LIST") {_node_to_cost[CGenericNode::TYPE_LREF_LIST] = value; break;} 
       if (identifier == "TYPE_EXPR") {_node_to_cost[CGenericNode::TYPE_EXPR] = value; break;} 
       if (identifier == "TYPE_VAL") {_node_to_cost[CGenericNode::TYPE_VAL] = value; break;} 
       if (identifier == "TYPE_CONST") {_node_to_cost[CGenericNode::TYPE_CONST] = value; break;} 
       if (identifier == "TYPE_FREF_TUPLE") {_node_to_cost[CGenericNode::TYPE_FREF_TUPLE] = value; break;} 
       if (identifier == "TYPE_LREF_TUPLE") {_node_to_cost[CGenericNode::TYPE_LREF_TUPLE] = value; break;} 
       if (identifier == "TYPE_INIT_LIST") {_node_to_cost[CGenericNode::TYPE_INIT_LIST] = value; break;} 
       if (identifier == "TYPE_FUNC_LIST") {_node_to_cost[CGenericNode::TYPE_FUNC_LIST] = value; break;} 
       if (identifier == "TYPE_INIT_TUPLE") {_node_to_cost[CGenericNode::TYPE_INIT_TUPLE] = value; break;} 
       if (identifier == "TYPE_FUNC_TUPLE") {_node_to_cost[CGenericNode::TYPE_FUNC_TUPLE] = value; break;} 
       if (identifier == "TYPE_STMT") {_node_to_cost[CGenericNode::TYPE_STMT] = value; break;} 
       if (identifier == "TYPE_SCOPE_TUPLE") {_node_to_cost[CGenericNode::TYPE_SCOPE_TUPLE] = value; break;} 
       if (identifier == "TYPE_REF_TUPLE") {_node_to_cost[CGenericNode::TYPE_REF_TUPLE] = value; break;} 
       if (identifier == "TYPE_ALLOC_TUPLE") {_node_to_cost[CGenericNode::TYPE_ALLOC_TUPLE] = value; break;}  
       if (identifier == "TYPE_ARGDECL_LIST") {_node_to_cost[CGenericNode::TYPE_ARGDECL_LIST] = value; break;}
       if (identifier == "TYPE_STMT_LIST") {_node_to_cost[CGenericNode::TYPE_STMT_LIST] = value; break;} 
       if (identifier == "TYPE_FREE_STMT_TUPLE") {_node_to_cost[CGenericNode::TYPE_FREE_STMT_TUPLE] = value; break;} 
       if (identifier == "TYPE_NULL_STMT_TUPLE") {_node_to_cost[CGenericNode::TYPE_NULL_STMT_TUPLE] = value; break;} 
       if (identifier == "TYPE_STORE_STMT_TUPLE") {_node_to_cost[CGenericNode::TYPE_STORE_STMT_TUPLE] = value; break;} 
       if (identifier == "TYPE_JUMP_STMT_TUPLE") {_node_to_cost[CGenericNode::TYPE_JUMP_STMT_TUPLE] = value; break;} 
       if (identifier == "TYPE_RETURN_STMT_TUPLE") {_node_to_cost[CGenericNode::TYPE_RETURN_STMT_TUPLE] = value; break;} 
       if (identifier == "TYPE_CALL_STMT_TUPLE") {_node_to_cost[CGenericNode::TYPE_CALL_STMT_TUPLE] = value; break;} 
       if (identifier == "TYPE_SWITCH_STMT_TUPLE") {_node_to_cost[CGenericNode::TYPE_SWITCH_STMT_TUPLE] = value; break;} 
       if (identifier == "TYPE_TARGET") {_node_to_cost[CGenericNode::TYPE_TARGET] = value; break;} 
       if (identifier == "TYPE_TARGET_TUPLE") {_node_to_cost[CGenericNode::TYPE_TARGET_TUPLE] = value; break;} 
       if (identifier == "TYPE_DEFAULT_TUPLE") {_node_to_cost[CGenericNode::TYPE_DEFAULT_TUPLE] = value; break;} 
       if (identifier == "TYPE_DYNALLOC_EXPR_TUPLE") {_node_to_cost[CGenericNode::TYPE_DYNALLOC_EXPR_TUPLE] = value; break;} 
       if (identifier == "TYPE_UNDEFINED_EXPR_TUPLE") {_node_to_cost[CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE] = value; break;} 
       if (identifier == "TYPE_LOAD_EXPR_TUPLE") {_node_to_cost[CGenericNode::TYPE_LOAD_EXPR_TUPLE] = value; break;} 
       if (identifier == "TYPE_COMPLABEL_EXPR_TUPLE") {_node_to_cost[CGenericNode::TYPE_COMPLABEL_EXPR_TUPLE] = value; break;} 
       if (identifier == "TYPE_LABEL_TUPLE") {_node_to_cost[CGenericNode::TYPE_LABEL_TUPLE] = value; break;} 
       if (identifier == "TYPE_COMPADDR_EXPR_TUPLE") {_node_to_cost[CGenericNode::TYPE_COMPADDR_EXPR_TUPLE] = value; break;} 
       if (identifier == "TYPE_ADDR_EXPR_TUPLE") {_node_to_cost[CGenericNode::TYPE_ADDR_EXPR_TUPLE] = value; break;} 
       if (identifier == "TYPE_OP_EXPR_TUPLE") {_node_to_cost[CGenericNode::TYPE_OP_EXPR_TUPLE] = value; break;} 
       if (identifier == "TYPE_NUM_VAL") {_node_to_cost[CGenericNode::TYPE_NUM_VAL] = value; break;} 
       if (identifier == "TYPE_FLOATVAL_TUPLE") {_node_to_cost[CGenericNode::TYPE_FLOATVAL_TUPLE] = value; break;} 
       if (identifier == "TYPE_INTVAL_TUPLE") {_node_to_cost[CGenericNode::TYPE_INTVAL_TUPLE] = value; break;} 
       if (identifier == "TYPE_CHARSTRING_TUPLE") {_node_to_cost[CGenericNode::TYPE_CHARSTRING_TUPLE] = value; break;} 
       if (identifier == "TYPE_CONSTREPEAT_TUPLE") {_node_to_cost[CGenericNode::TYPE_CONSTREPEAT_TUPLE] = value; break;} 
       if (identifier == "TYPE_FLOAT_LIST") {_node_to_cost[CGenericNode::TYPE_FLOAT_LIST] = value; break;} 
       if (identifier == "TYPE_INT_LIST") {_node_to_cost[CGenericNode::TYPE_INT_LIST] = value; break;} 
       if (identifier == "TYPE_CONST_LIST") {_node_to_cost[CGenericNode::TYPE_CONST_LIST] = value; break;} 
       if (identifier == "TYPE_SIZE") {_node_to_cost[CGenericNode::TYPE_SIZE] = value; break;} 
       if (identifier == "TYPE_SIZE_LIST") {_node_to_cost[CGenericNode::TYPE_SIZE_LIST] = value; break;} 
       if (identifier == "TYPE_MACRO_CALL_TUPLE") {_node_to_cost[CGenericNode::TYPE_MACRO_CALL_TUPLE] = value; break;} 
       if (identifier == "TYPE_MACRO_FORMAL_ARG") {_node_to_cost[CGenericNode::TYPE_MACRO_FORMAL_ARG] = value; break;} 
       if (identifier == "TYPE_MACRO_FORMAL_ARG_LIST") {_node_to_cost[CGenericNode::TYPE_MACRO_FORMAL_ARG_LIST] = value; break;} 
       if (identifier == "TYPE_MACRO_DEF_TUPLE") {_node_to_cost[CGenericNode::TYPE_MACRO_DEF_TUPLE] = value; break;} 
       if (identifier == "TYPE_MACRO_DEF_LIST") {_node_to_cost[CGenericNode::TYPE_MACRO_DEF_LIST] = value; break;} 
       if (identifier == "TYPE_STRING") {_node_to_cost[CGenericNode::TYPE_STRING] = value; break;} 
       if (identifier == "TYPE_UNKNOWN_VAL") {_node_to_cost[CGenericNode::TYPE_UNKNOWN_VAL] = value; break;} 
       if (identifier == "TYPE_UNKNOWN_STMT") {_node_to_cost[CGenericNode::TYPE_UNKNOWN_STMT] = value; break;} 
       if (identifier == "TYPE_UNKNOWN_CONST") {_node_to_cost[CGenericNode::TYPE_UNKNOWN_CONST] = value; break;} 
       if (identifier == "TYPE_UNKNOWN_EXPR") {_node_to_cost[CGenericNode::TYPE_UNKNOWN_EXPR] = value; break;} 

       // Operands
       if (identifier == "OP_TYPE_NEG") {_optype_to_cost[COpNumExprTuple::OP_TYPE_NEG] = value; break;} 
       if (identifier == "OP_TYPE_ADD") {_optype_to_cost[COpNumExprTuple::OP_TYPE_ADD] = value; break;} 
       if (identifier == "OP_TYPE_C_ADD") {_optype_to_cost[COpNumExprTuple::OP_TYPE_C_ADD] = value; break;} 
       if (identifier == "OP_TYPE_SUB") {_optype_to_cost[COpNumExprTuple::OP_TYPE_SUB] = value; break;} 
       if (identifier == "OP_TYPE_C_SUB") {_optype_to_cost[COpNumExprTuple::OP_TYPE_C_SUB] = value; break;} 
       if (identifier == "OP_TYPE_U_MUL") {_optype_to_cost[COpNumExprTuple::OP_TYPE_U_MUL] = value; break;} 
       if (identifier == "OP_TYPE_S_MUL") {_optype_to_cost[COpNumExprTuple::OP_TYPE_S_MUL] = value; break;} 
       if (identifier == "OP_TYPE_U_DIV") {_optype_to_cost[COpNumExprTuple::OP_TYPE_U_DIV] = value; break;} 
       if (identifier == "OP_TYPE_S_DIV") {_optype_to_cost[COpNumExprTuple::OP_TYPE_S_DIV] = value; break;} 
       if (identifier == "OP_TYPE_U_MOD") {_optype_to_cost[COpNumExprTuple::OP_TYPE_U_MOD] = value; break;} 
       if (identifier == "OP_TYPE_S_MOD") {_optype_to_cost[COpNumExprTuple::OP_TYPE_S_MOD] = value; break;} 
       if (identifier == "OP_TYPE_L_SHIFT") {_optype_to_cost[COpNumExprTuple::OP_TYPE_L_SHIFT] = value; break;} 
       if (identifier == "OP_TYPE_R_SHIFT") {_optype_to_cost[COpNumExprTuple::OP_TYPE_R_SHIFT] = value; break;} 
       if (identifier == "OP_TYPE_R_SHIFT_A") {_optype_to_cost[COpNumExprTuple::OP_TYPE_R_SHIFT_A] = value; break;} 
       if (identifier == "OP_TYPE_S_EXT") {_optype_to_cost[COpNumExprTuple::OP_TYPE_S_EXT] = value; break;} 
       if (identifier == "OP_TYPE_NOT") {_optype_to_cost[COpNumExprTuple::OP_TYPE_NOT] = value; break;} 
       if (identifier == "OP_TYPE_AND") {_optype_to_cost[COpNumExprTuple::OP_TYPE_AND] = value; break;} 
       if (identifier == "OP_TYPE_OR") {_optype_to_cost[COpNumExprTuple::OP_TYPE_OR] = value; break;} 
       if (identifier == "OP_TYPE_XOR") {_optype_to_cost[COpNumExprTuple::OP_TYPE_XOR] = value; break;} 
       if (identifier == "OP_TYPE_F_NEG") {_optype_to_cost[COpNumExprTuple::OP_TYPE_F_NEG] = value; break;} 
       if (identifier == "OP_TYPE_F_ADD") {_optype_to_cost[COpNumExprTuple::OP_TYPE_F_ADD] = value; break;} 
       if (identifier == "OP_TYPE_F_SUB") {_optype_to_cost[COpNumExprTuple::OP_TYPE_F_SUB] = value; break;} 
       if (identifier == "OP_TYPE_F_MUL") {_optype_to_cost[COpNumExprTuple::OP_TYPE_F_MUL] = value; break;} 
       if (identifier == "OP_TYPE_F_DIV") {_optype_to_cost[COpNumExprTuple::OP_TYPE_F_DIV] = value; break;} 
       if (identifier == "OP_TYPE_F_TO_F") {_optype_to_cost[COpNumExprTuple::OP_TYPE_F_TO_F] = value; break;} 
       if (identifier == "OP_TYPE_F_TO_U") {_optype_to_cost[COpNumExprTuple::OP_TYPE_F_TO_U] = value; break;} 
       if (identifier == "OP_TYPE_F_TO_S") {_optype_to_cost[COpNumExprTuple::OP_TYPE_F_TO_S] = value; break;} 
       if (identifier == "OP_TYPE_U_TO_F") {_optype_to_cost[COpNumExprTuple::OP_TYPE_U_TO_F] = value; break;} 
       if (identifier == "OP_TYPE_S_TO_F") {_optype_to_cost[COpNumExprTuple::OP_TYPE_S_TO_F] = value; break;} 
       if (identifier == "OP_TYPE_EQ") {_optype_to_cost[COpNumExprTuple::OP_TYPE_EQ] = value; break;} 
       if (identifier == "OP_TYPE_NEQ") {_optype_to_cost[COpNumExprTuple::OP_TYPE_NEQ] = value; break;} 
       if (identifier == "OP_TYPE_U_LT") {_optype_to_cost[COpNumExprTuple::OP_TYPE_U_LT] = value; break;} 
       if (identifier == "OP_TYPE_U_GE") {_optype_to_cost[COpNumExprTuple::OP_TYPE_U_GE] = value; break;} 
       if (identifier == "OP_TYPE_U_GT") {_optype_to_cost[COpNumExprTuple::OP_TYPE_U_GT] = value; break;} 
       if (identifier == "OP_TYPE_U_LE") {_optype_to_cost[COpNumExprTuple::OP_TYPE_U_LE] = value; break;} 
       if (identifier == "OP_TYPE_S_LT") {_optype_to_cost[COpNumExprTuple::OP_TYPE_S_LT] = value; break;} 
       if (identifier == "OP_TYPE_S_GE") {_optype_to_cost[COpNumExprTuple::OP_TYPE_S_GE] = value; break;} 
       if (identifier == "OP_TYPE_S_GT") {_optype_to_cost[COpNumExprTuple::OP_TYPE_S_GT] = value; break;} 
       if (identifier == "OP_TYPE_S_LE") {_optype_to_cost[COpNumExprTuple::OP_TYPE_S_LE] = value; break;} 
       if (identifier == "OP_TYPE_F_EQ") {_optype_to_cost[COpNumExprTuple::OP_TYPE_F_EQ] = value; break;} 
       if (identifier == "OP_TYPE_F_NE") {_optype_to_cost[COpNumExprTuple::OP_TYPE_F_NE] = value; break;} 
       if (identifier == "OP_TYPE_F_LT") {_optype_to_cost[COpNumExprTuple::OP_TYPE_F_LT] = value; break;} 
       if (identifier == "OP_TYPE_F_GE") {_optype_to_cost[COpNumExprTuple::OP_TYPE_F_GE] = value; break;} 
       if (identifier == "OP_TYPE_F_GT") {_optype_to_cost[COpNumExprTuple::OP_TYPE_F_GT] = value; break;} 
       if (identifier == "OP_TYPE_F_LE") {_optype_to_cost[COpNumExprTuple::OP_TYPE_F_LE] = value; break;} 
       if (identifier == "OP_TYPE_IF") {_optype_to_cost[COpNumExprTuple::OP_TYPE_IF] = value; break;} 
       if (identifier == "OP_TYPE_B2N") {_optype_to_cost[COpNumExprTuple::OP_TYPE_B2N] = value; break;} 
       if (identifier == "OP_TYPE_EXP2") {_optype_to_cost[COpNumExprTuple::OP_TYPE_EXP2] = value; break;} 
       if (identifier == "OP_TYPE_SELECT") {_optype_to_cost[COpNumExprTuple::OP_TYPE_SELECT] = value; break;} 
       if (identifier == "OP_TYPE_CONC") {_optype_to_cost[COpNumExprTuple::OP_TYPE_CONC] = value; break;} 
       if (identifier == "OP_TYPE_REPEAT") {_optype_to_cost[COpNumExprTuple::OP_TYPE_REPEAT] = value; break;} 

       // Stmts
       if (identifier == "GS_SKIP") {_stmt_to_cost[CGenericStmt::GS_SKIP] = value; break;}
       if (identifier == "GS_STORE") {_stmt_to_cost[CGenericStmt::GS_STORE] = value; break;}
       if (identifier == "GS_COND") {_stmt_to_cost[CGenericStmt::GS_COND] = value; break;}
       if (identifier == "GS_JUMP") {_stmt_to_cost[CGenericStmt::GS_JUMP] = value; break;}
       if (identifier == "GS_CALL") {_stmt_to_cost[CGenericStmt::GS_CALL] = value; break;}
       if (identifier == "GS_ENTER") {_stmt_to_cost[CGenericStmt::GS_ENTER] = value; break;}
       if (identifier == "GS_RETURN") {_stmt_to_cost[CGenericStmt::GS_RETURN] = value; break;}
       if (identifier == "GS_RESULT") {_stmt_to_cost[CGenericStmt::GS_RESULT] = value; break;}
       if (identifier == "GS_FREE") {_stmt_to_cost[CGenericStmt::GS_FREE] = value; break;}
       if (identifier == "GS_SCOPE") {_stmt_to_cost[CGenericStmt::GS_SCOPE] = value; break;}
       if (identifier == "GS_UNKNOWN") {_stmt_to_cost[CGenericStmt::GS_UNKNOWN] = value; break;}
       if (identifier == "GS_OTHER") {_stmt_to_cost[CGenericStmt::GS_OTHER] = value; break;}
       if (identifier == "GS_ABS_STORE_INT") {_stmt_to_cost[CGenericStmt::GS_ABS_STORE_INT] = value; break;}
       if (identifier == "GS_ABS_STORE_FLOAT") {_stmt_to_cost[CGenericStmt::GS_ABS_STORE_FLOAT] = value; break;}
       if (identifier == "GS_ABS_STORE_POINTER") {_stmt_to_cost[CGenericStmt::GS_ABS_STORE_POINTER] = value; break;}

       // Stmt pairs
       if (identifier == "PAIR_GS_SKIP_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_SKIP_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_SKIP_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_SKIP_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_SKIP_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_SKIP_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_SKIP_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_SKIP_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_SKIP_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_SKIP_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_SKIP_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_SKIP_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_SKIP_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_SKIP_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_SKIP_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SKIP, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_STORE_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_STORE, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_COND_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_COND, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_JUMP_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_JUMP, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_CALL_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_CALL, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_ENTER_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ENTER, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_RETURN_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RETURN, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_RESULT_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_RESULT, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_FREE_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_FREE, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_SCOPE_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_SCOPE, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_UNKNOWN_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_UNKNOWN, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_OTHER_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_OTHER, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_INT_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_INT, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_FLOAT_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_FLOAT, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_SKIP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_SKIP)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_STORE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_STORE)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_COND") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_COND)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_JUMP") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_JUMP)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_CALL") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_CALL)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_ENTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_ENTER)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_RETURN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_RETURN)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_RESULT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_RESULT)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_FREE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_FREE)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_SCOPE") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_SCOPE)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_UNKNOWN") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_UNKNOWN)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_OTHER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_OTHER)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_ABS_STORE_INT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_ABS_STORE_INT)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_ABS_STORE_FLOAT") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_ABS_STORE_FLOAT)] = value; break;}
       if (identifier == "PAIR_GS_ABS_STORE_POINTER_AND_GS_ABS_STORE_POINTER") {_stmt_pair_to_cost[std::make_pair(CGenericStmt::GS_ABS_STORE_POINTER, CGenericStmt::GS_ABS_STORE_POINTER)] = value; break;}

       // nothing matches (default)
       cerr << "ERROR: " << filename << ": unknown identifier '" << identifier << "'\n";
       exit(-2);
    }
    while (false);
  }
  // _node_to_cost[CGenericNode::TYPE_GENERIC_NODE] 	= 0; // ignored
}


// // ---------------------------------
// // Help function for parsing identifiers and values from input file
// // ---------------------------------
// string 
// CAlfCostLookupTable::
// GetToken(std::ifstream & source, const char separator)
// {
//   string token, help;
  
//   token = "";
  
//   do {
//     source >> help;

//     cout << "help : " << help << endl;
    
//     if (help == "//") {
//       // comment found, ie. ignore rest of line
//       getline(source, token);
//       return help;
//     }
    
//     if (help[help.size()-1] == separator) {
//       token = token + help;
//       token.erase(token.size()-1); // delete separator
//       break;
//     }
    
//     if (source.peek() == '\n') {
//       token = token + help;
//       getline(source, help); // goto next line		
//       break;
//     }
    
//     if (source.eof()) {
//       token = token + help;			
//       break;
//     }
    
//     token = token + help + " ";
//   } while ( true );
  
//   return token;
// }

bool 
CAlfCostLookupTable::
HasGenericNodeCost() const
{
  return _node_to_cost.size() > 0;
}

bool 
CAlfCostLookupTable::
HasOperandCost() const
{
  return _optype_to_cost.size() > 0;
}

bool 
CAlfCostLookupTable::
HasStmtCost() const
{
  return _stmt_to_cost.size() > 0;
}

bool 
CAlfCostLookupTable::
HasStmtPairCost() const
{
  return _stmt_pair_to_cost.size() > 0;
}

// To get the cost of a certain node type  
double 
CAlfCostLookupTable::
LookUpCost(CGenericNode::TYPE node_type) const {
  std::map<CGenericNode::TYPE, double>::const_iterator nc = _node_to_cost.find(node_type);
  if(nc != _node_to_cost.end())
    return (*nc).second;
  else
    return 0;
}
  
// To get the cost of a certain operand type  
double 
CAlfCostLookupTable::
LookUpCost(COpNumExprTuple::OP_TYPE op_type) const  {
  std::map<COpNumExprTuple::OP_TYPE, double>::const_iterator oc = _optype_to_cost.find(op_type);
  if(oc != _optype_to_cost.end())
    return (*oc).second;
  else
    return 0;
}

// To get the cost of a certain stmt
double 
CAlfCostLookupTable::
LookUpCost(CGenericStmt::GS_TYPE stmt) const  {
  std::map<CGenericStmt::GS_TYPE, double>::const_iterator sc = _stmt_to_cost.find(stmt);
  if(sc != _stmt_to_cost.end())
    return (*sc).second;
  else
    return 0;
}

// To get the cost of a certain stmt pair
double 
CAlfCostLookupTable::
LookUpCost(std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE> stmt_pair) const {
  std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, double>::const_iterator spc = _stmt_pair_to_cost.find(stmt_pair);
  if(spc != _stmt_pair_to_cost.end())
    return (*spc).second;
  else
    return 0;
}

// ---------------------------------
// To print a cost lookup table template to file
// ---------------------------------
void 
CAlfCostLookupTable::
PrintAsTemplate(std::string file_name, bool print_prog_run,
		bool print_gen_nodes, bool print_ops, 
		bool print_stmts, bool print_stmt_pairs) {
  // Open a file for reading
  ofstream file_stream(file_name.c_str());
  if (!file_stream) { 
    cerr << "Output file_stream  '" << file_name << "' cannot be opened!\n";
    exit(-2);
  }
  ofstream * o = &file_stream;

  // if we should print the program run
  if(print_prog_run) {
    (*o) << "PROG_RUN 0" << endl;
  }

  // If we should print generic nodes
  if(print_gen_nodes) {
    unsigned int nr_of_types = alf::CGenericNode::NrOfTYPEs();
    for(unsigned int t = 0; t < nr_of_types; ++t) {
      alf::CGenericNode::TYPE type = (alf::CGenericNode::TYPE)(t);
      string type_as_string = alf::CGenericNode::GetTypeAsString(type);
      (*o) << type_as_string << " 0" << endl;
    }
  }

  // If we should print op types
  if(print_ops) {
    unsigned int nr_of_op_types = alf::COpNumExprTuple::NrOfOPTYPEs();
    for(unsigned int t = 0; t < nr_of_op_types; ++t) {
      alf::COpNumExprTuple::OP_TYPE op_type = (alf::COpNumExprTuple::OP_TYPE)(t);
      string op_type_as_string = alf::COpNumExprTuple::GetName(op_type);
      (*o) << op_type_as_string << " 0" << endl;
    }
  }
  
  // If we should print stmts
  if(print_stmts) {
    unsigned int nr_of_stmts = CGenericStmt::NrOfGSTYPEs();
    for(unsigned int t = 0; t < nr_of_stmts; ++t) {
      CGenericStmt::GS_TYPE stmt_type = (CGenericStmt::GS_TYPE)(t);
      string stmt_type_as_string = CGenericStmt::GetName(stmt_type);
      (*o) << stmt_type_as_string << " 0" << endl;
    }
  }

  // If we should print stmt pairs
  if(print_stmt_pairs) {
    unsigned int nr_of_stmts = CGenericStmt::NrOfGSTYPEs();
    for(unsigned int i1 = 0; i1 < nr_of_stmts; ++i1) {
      CGenericStmt::GS_TYPE stmt1 = (CGenericStmt::GS_TYPE)(i1);
      string stmt1_as_string = CGenericStmt::GetName(stmt1);
      for(unsigned int i2 = 0; i2 < nr_of_stmts; ++i2) {
        CGenericStmt::GS_TYPE stmt2 = (CGenericStmt::GS_TYPE)(i2);
        string stmt2_as_string = CGenericStmt::GetName(stmt2);
         std::ostringstream s;
         s << "PAIR_" << stmt1_as_string << "_AND_" << stmt2_as_string;
         (*o) << s.str() << " 0" << endl;
      }
    }
  }

  // Close the file
  file_stream.close();
}

// // ---------------------------------
// // Help function for reading default timing constants from 
// // simpleWCETconst.h"
// // ---------------------------------
// void
// CAlfCostLookupTable::SetDefaultTimingConstants() 
// {
//   // Program run
//   _prog_run_cost = defaultTimingConstant_PROG_RUN;  

//   cout << "CAlfCostLookupTable::SetDefaultTimingConstants _prog_run_cost: " << _prog_run_cost << endl;

//   // Generic nodes
//   _node_to_cost[CGenericNode::TYPE_GENERIC_NODE] 	= 0; // ignored
//   _node_to_cost[CGenericNode::TYPE_LIST_NODE] 	= defaultTimingConstant_TYPE_LIST_NODE;
//   _node_to_cost[CGenericNode::TYPE_ALF_TUPLE] 	= defaultTimingConstant_TYPE_ALF_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_DECL_LIST] 	= defaultTimingConstant_TYPE_DECL_LIST;
//   _node_to_cost[CGenericNode::TYPE_LAU_TUPLE] 	= defaultTimingConstant_TYPE_LAU_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_EXPORTS_TUPLE] = defaultTimingConstant_TYPE_EXPORTS_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_IMPORTS_TUPLE] = defaultTimingConstant_TYPE_IMPORTS_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_FREF_LIST] 	= defaultTimingConstant_TYPE_FREF_LIST;
//   _node_to_cost[CGenericNode::TYPE_LREF_LIST] 	= defaultTimingConstant_TYPE_LREF_LIST;
//   _node_to_cost[CGenericNode::TYPE_EXPR] 		= defaultTimingConstant_TYPE_EXPR;
//   _node_to_cost[CGenericNode::TYPE_VAL] 		= defaultTimingConstant_TYPE_VAL;
//   _node_to_cost[CGenericNode::TYPE_CONST] 	= defaultTimingConstant_TYPE_CONST;
//   _node_to_cost[CGenericNode::TYPE_FREF_TUPLE] 	= defaultTimingConstant_TYPE_FREF_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_LREF_TUPLE] 	= defaultTimingConstant_TYPE_LREF_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_INIT_LIST] 	= defaultTimingConstant_TYPE_INIT_LIST;
//   _node_to_cost[CGenericNode::TYPE_FUNC_LIST] 	= defaultTimingConstant_TYPE_FUNC_LIST;
//   _node_to_cost[CGenericNode::TYPE_INIT_TUPLE] 	= defaultTimingConstant_TYPE_INIT_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_FUNC_TUPLE] 	= defaultTimingConstant_TYPE_FUNC_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_STMT] 		= defaultTimingConstant_TYPE_STMT;
//   _node_to_cost[CGenericNode::TYPE_SCOPE_TUPLE] 	= defaultTimingConstant_TYPE_SCOPE_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_REF_TUPLE] 	= defaultTimingConstant_TYPE_REF_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_ALLOC_TUPLE] 	= defaultTimingConstant_TYPE_ALLOC_TUPLE; 
//   _node_to_cost[CGenericNode::TYPE_ARGDECL_LIST]	= defaultTimingConstant_TYPE_ARGDECL_LIST;
//   _node_to_cost[CGenericNode::TYPE_STMT_LIST]	= defaultTimingConstant_TYPE_STMT_LIST;
//   _node_to_cost[CGenericNode::TYPE_FREE_STMT_TUPLE]	= defaultTimingConstant_TYPE_FREE_STMT_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_NULL_STMT_TUPLE]	= defaultTimingConstant_TYPE_NULL_STMT_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_STORE_STMT_TUPLE]	= defaultTimingConstant_TYPE_STORE_STMT_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_JUMP_STMT_TUPLE]	= defaultTimingConstant_TYPE_JUMP_STMT_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_RETURN_STMT_TUPLE]	= defaultTimingConstant_TYPE_RETURN_STMT_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_CALL_STMT_TUPLE]	= defaultTimingConstant_TYPE_CALL_STMT_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_SWITCH_STMT_TUPLE]	= defaultTimingConstant_TYPE_SWITCH_STMT_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_TARGET]		= defaultTimingConstant_TYPE_TARGET;
//   _node_to_cost[CGenericNode::TYPE_TARGET_TUPLE]		= defaultTimingConstant_TYPE_TARGET_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_DEFAULT_TUPLE]		= defaultTimingConstant_TYPE_DEFAULT_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_DYNALLOC_EXPR_TUPLE]	= defaultTimingConstant_TYPE_DYNALLOC_EXPR_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE]	= defaultTimingConstant_TYPE_UNDEFINED_EXPR_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_LOAD_EXPR_TUPLE]	= defaultTimingConstant_TYPE_LOAD_EXPR_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_COMPLABEL_EXPR_TUPLE]	= defaultTimingConstant_TYPE_COMPLABEL_EXPR_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_LABEL_TUPLE]		= defaultTimingConstant_TYPE_LABEL_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_COMPADDR_EXPR_TUPLE]	= defaultTimingConstant_TYPE_COMPADDR_EXPR_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_ADDR_EXPR_TUPLE]	= defaultTimingConstant_TYPE_ADDR_EXPR_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_OP_EXPR_TUPLE]		= defaultTimingConstant_TYPE_OP_EXPR_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_NUM_VAL]		= defaultTimingConstant_TYPE_NUM_VAL;
//   _node_to_cost[CGenericNode::TYPE_FLOATVAL_TUPLE]	= defaultTimingConstant_TYPE_FLOATVAL_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_INTVAL_TUPLE]		= defaultTimingConstant_TYPE_INTVAL_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_CHARSTRING_TUPLE]	= defaultTimingConstant_TYPE_CHARSTRING_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_CONSTREPEAT_TUPLE]	= defaultTimingConstant_TYPE_CONSTREPEAT_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_FLOAT_LIST]		= defaultTimingConstant_TYPE_FLOAT_LIST;
//   _node_to_cost[CGenericNode::TYPE_INT_LIST]		= defaultTimingConstant_TYPE_INT_LIST;
//   _node_to_cost[CGenericNode::TYPE_CONST_LIST]		= defaultTimingConstant_TYPE_CONST_LIST;    
//   _node_to_cost[CGenericNode::TYPE_SIZE]			= defaultTimingConstant_TYPE_SIZE;
//   _node_to_cost[CGenericNode::TYPE_SIZE_LIST]		= defaultTimingConstant_TYPE_SIZE_LIST;
//   _node_to_cost[CGenericNode::TYPE_MACRO_CALL_TUPLE]	= defaultTimingConstant_TYPE_MACRO_CALL_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_MACRO_FORMAL_ARG]	= defaultTimingConstant_TYPE_MACRO_FORMAL_ARG;
//   _node_to_cost[CGenericNode::TYPE_MACRO_FORMAL_ARG_LIST]	= defaultTimingConstant_TYPE_MACRO_FORMAL_ARG_LIST;
//   _node_to_cost[CGenericNode::TYPE_MACRO_DEF_TUPLE]	= defaultTimingConstant_TYPE_MACRO_DEF_TUPLE;
//   _node_to_cost[CGenericNode::TYPE_MACRO_DEF_LIST]	= defaultTimingConstant_TYPE_MACRO_DEF_LIST;
//   _node_to_cost[CGenericNode::TYPE_STRING]		= defaultTimingConstant_TYPE_STRING; 
//   _node_to_cost[CGenericNode::TYPE_UNKNOWN_VAL]		= defaultTimingConstant_TYPE_UNKNOWN_VAL;
//   _node_to_cost[CGenericNode::TYPE_UNKNOWN_STMT]		= defaultTimingConstant_TYPE_UNKNOWN_STMT;
//   _node_to_cost[CGenericNode::TYPE_UNKNOWN_CONST]		= defaultTimingConstant_TYPE_UNKNOWN_CONST;
//   _node_to_cost[CGenericNode::TYPE_UNKNOWN_EXPR]		= defaultTimingConstant_TYPE_UNKNOWN_EXPR;

//   // Operands
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_NEG] = defaultTimingConstant_OP_TYPE_NEG;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_ADD] = defaultTimingConstant_OP_TYPE_ADD;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_C_ADD] = defaultTimingConstant_OP_TYPE_C_ADD;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_SUB] = defaultTimingConstant_OP_TYPE_SUB;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_C_SUB] = defaultTimingConstant_OP_TYPE_C_SUB;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_U_MUL] = defaultTimingConstant_OP_TYPE_U_MUL;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_S_MUL] = defaultTimingConstant_OP_TYPE_S_MUL;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_U_DIV] = defaultTimingConstant_OP_TYPE_U_DIV;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_S_DIV] = defaultTimingConstant_OP_TYPE_S_DIV;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_U_MOD] = defaultTimingConstant_OP_TYPE_U_MOD;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_S_MOD] = defaultTimingConstant_OP_TYPE_S_MOD;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_L_SHIFT] = defaultTimingConstant_OP_TYPE_L_SHIFT;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_R_SHIFT] = defaultTimingConstant_OP_TYPE_R_SHIFT;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_R_SHIFT_A] = defaultTimingConstant_OP_TYPE_R_SHIFT_A;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_S_EXT] = defaultTimingConstant_OP_TYPE_S_EXT;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_NOT] = defaultTimingConstant_OP_TYPE_NOT;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_AND] = defaultTimingConstant_OP_TYPE_AND;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_OR] = defaultTimingConstant_OP_TYPE_OR;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_XOR] = defaultTimingConstant_OP_TYPE_XOR;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_F_NEG] = defaultTimingConstant_OP_TYPE_F_NEG;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_F_ADD] = defaultTimingConstant_OP_TYPE_F_ADD;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_F_SUB] = defaultTimingConstant_OP_TYPE_F_SUB;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_F_MUL] = defaultTimingConstant_OP_TYPE_F_MUL;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_F_DIV] = defaultTimingConstant_OP_TYPE_F_DIV;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_F_TO_F] = defaultTimingConstant_OP_TYPE_F_TO_F;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_F_TO_U] = defaultTimingConstant_OP_TYPE_F_TO_U;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_F_TO_S] = defaultTimingConstant_OP_TYPE_F_TO_S;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_U_TO_F] = defaultTimingConstant_OP_TYPE_U_TO_F;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_S_TO_F] = defaultTimingConstant_OP_TYPE_S_TO_F;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_EQ] = defaultTimingConstant_OP_TYPE_EQ;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_NEQ] = defaultTimingConstant_OP_TYPE_NEQ;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_U_LT] = defaultTimingConstant_OP_TYPE_U_LT;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_U_GE] = defaultTimingConstant_OP_TYPE_U_GE;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_U_GT] = defaultTimingConstant_OP_TYPE_U_GT;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_U_LE] = defaultTimingConstant_OP_TYPE_U_LE;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_S_LT] = defaultTimingConstant_OP_TYPE_S_LT;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_S_GE] = defaultTimingConstant_OP_TYPE_S_GE;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_S_GT] = defaultTimingConstant_OP_TYPE_S_GT;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_S_LE] = defaultTimingConstant_OP_TYPE_S_LE;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_F_EQ] = defaultTimingConstant_OP_TYPE_F_EQ;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_F_NE] = defaultTimingConstant_OP_TYPE_F_NE;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_F_LT] = defaultTimingConstant_OP_TYPE_F_LT;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_F_GE] = defaultTimingConstant_OP_TYPE_F_GE;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_F_GT] = defaultTimingConstant_OP_TYPE_F_GT;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_F_LE] = defaultTimingConstant_OP_TYPE_F_LE;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_IF] = defaultTimingConstant_OP_TYPE_IF;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_B2N] = defaultTimingConstant_OP_TYPE_B2N;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_EXP2] = defaultTimingConstant_OP_TYPE_EXP2;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_SELECT] = defaultTimingConstant_OP_TYPE_SELECT;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_CONC] = defaultTimingConstant_OP_TYPE_CONC;
//   _optype_to_cost[COpNumExprTuple::OP_TYPE_REPEAT] = defaultTimingConstant_OP_TYPE_REPEAT;

//   // Statements
//   _stmt_to_cost[CGenericStmt::GS_SKIP] = defaultTimingConstant_GS_SKIP;
//   _stmt_to_cost[CGenericStmt::GS_STORE] = defaultTimingConstant_GS_STORE;
//   _stmt_to_cost[CGenericStmt::GS_COND] = defaultTimingConstant_GS_COND;
//   _stmt_to_cost[CGenericStmt::GS_JUMP] = defaultTimingConstant_GS_JUMP;
//   _stmt_to_cost[CGenericStmt::GS_CALL] = defaultTimingConstant_GS_CALL;
//   _stmt_to_cost[CGenericStmt::GS_ENTER] = defaultTimingConstant_GS_ENTER;
//   _stmt_to_cost[CGenericStmt::GS_RETURN] = defaultTimingConstant_GS_RETURN;
//   _stmt_to_cost[CGenericStmt::GS_RESULT] = defaultTimingConstant_GS_RESULT;
//   _stmt_to_cost[CGenericStmt::GS_FREE] = defaultTimingConstant_GS_FREE;
//   _stmt_to_cost[CGenericStmt::GS_SCOPE] = defaultTimingConstant_GS_SCOPE;
//   _stmt_to_cost[CGenericStmt::GS_UNKNOWN] = defaultTimingConstant_GS_UNKNOWN;
//   _stmt_to_cost[CGenericStmt::GS_OTHER] = defaultTimingConstant_GS_OTHER;
//   _stmt_to_cost[CGenericStmt::GS_ABS_STORE_INT] = defaultTimingConstant_GS_ABS_STORE_INT;
//   _stmt_to_cost[CGenericStmt::GS_ABS_STORE_FLOAT] = defaultTimingConstant_GS_ABS_STORE_FLOAT;
//   _stmt_to_cost[CGenericStmt::GS_ABS_STORE_POINTER] = defaultTimingConstant_GS_ABS_STORE_POINTER;


// }

// ---------------------------------
// Help function for reading default timing constants from 
// simpleWCETconst.h"
// ---------------------------------
void
CAlfCostLookupTable::SetAllTimingConstants(double value) 
{
  // Program run
  _prog_run_cost = value; 

  // Generic nodes
  _node_to_cost[CGenericNode::TYPE_GENERIC_NODE] = value; 
  _node_to_cost[CGenericNode::TYPE_LIST_NODE] = value; 
  _node_to_cost[CGenericNode::TYPE_ALF_TUPLE] = value; 
  _node_to_cost[CGenericNode::TYPE_DECL_LIST] = value; 
  _node_to_cost[CGenericNode::TYPE_LAU_TUPLE] = value; 
  _node_to_cost[CGenericNode::TYPE_EXPORTS_TUPLE] = value; 
  _node_to_cost[CGenericNode::TYPE_IMPORTS_TUPLE] = value; 
  _node_to_cost[CGenericNode::TYPE_FREF_LIST] = value; 
  _node_to_cost[CGenericNode::TYPE_LREF_LIST] = value; 
  _node_to_cost[CGenericNode::TYPE_EXPR] = value;
  _node_to_cost[CGenericNode::TYPE_VAL] = value;
  _node_to_cost[CGenericNode::TYPE_CONST] = value; 
  _node_to_cost[CGenericNode::TYPE_FREF_TUPLE] = value; 
  _node_to_cost[CGenericNode::TYPE_LREF_TUPLE] = value; 
  _node_to_cost[CGenericNode::TYPE_INIT_LIST] = value; 
  _node_to_cost[CGenericNode::TYPE_FUNC_LIST] = value; 
  _node_to_cost[CGenericNode::TYPE_INIT_TUPLE] = value; 
  _node_to_cost[CGenericNode::TYPE_FUNC_TUPLE] = value; 
  _node_to_cost[CGenericNode::TYPE_STMT] = value;
  _node_to_cost[CGenericNode::TYPE_SCOPE_TUPLE] = value; 
  _node_to_cost[CGenericNode::TYPE_REF_TUPLE] = value; 
  _node_to_cost[CGenericNode::TYPE_ALLOC_TUPLE] = value; 
  _node_to_cost[CGenericNode::TYPE_ARGDECL_LIST] = value;
  _node_to_cost[CGenericNode::TYPE_STMT_LIST] = value;
  _node_to_cost[CGenericNode::TYPE_FREE_STMT_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_NULL_STMT_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_STORE_STMT_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_JUMP_STMT_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_RETURN_STMT_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_CALL_STMT_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_SWITCH_STMT_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_TARGET] = value;
  _node_to_cost[CGenericNode::TYPE_TARGET_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_DEFAULT_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_DYNALLOC_EXPR_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_LOAD_EXPR_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_COMPLABEL_EXPR_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_LABEL_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_COMPADDR_EXPR_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_ADDR_EXPR_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_OP_EXPR_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_NUM_VAL] = value;
  _node_to_cost[CGenericNode::TYPE_FLOATVAL_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_INTVAL_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_CHARSTRING_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_CONSTREPEAT_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_FLOAT_LIST] = value;
  _node_to_cost[CGenericNode::TYPE_INT_LIST] = value;
  _node_to_cost[CGenericNode::TYPE_CONST_LIST] = value;
  _node_to_cost[CGenericNode::TYPE_SIZE] = value;
  _node_to_cost[CGenericNode::TYPE_SIZE_LIST] = value;
  _node_to_cost[CGenericNode::TYPE_MACRO_CALL_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_MACRO_FORMAL_ARG] = value;
  _node_to_cost[CGenericNode::TYPE_MACRO_FORMAL_ARG_LIST] = value;
  _node_to_cost[CGenericNode::TYPE_MACRO_DEF_TUPLE] = value;
  _node_to_cost[CGenericNode::TYPE_MACRO_DEF_LIST] = value;
  _node_to_cost[CGenericNode::TYPE_STRING] = value;
  _node_to_cost[CGenericNode::TYPE_UNKNOWN_VAL] = value;
  _node_to_cost[CGenericNode::TYPE_UNKNOWN_STMT] = value;
  _node_to_cost[CGenericNode::TYPE_UNKNOWN_CONST] = value;
  _node_to_cost[CGenericNode::TYPE_UNKNOWN_EXPR] = value;

  // Operands= value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_NEG] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_ADD] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_C_ADD] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_SUB] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_C_SUB] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_U_MUL] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_S_MUL] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_U_DIV] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_S_DIV] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_U_MOD] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_S_MOD] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_L_SHIFT] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_R_SHIFT] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_R_SHIFT_A] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_S_EXT] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_NOT] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_AND] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_OR] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_XOR] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_F_NEG] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_F_ADD] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_F_SUB] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_F_MUL] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_F_DIV] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_F_TO_F] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_F_TO_U] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_F_TO_S] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_U_TO_F] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_S_TO_F] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_EQ] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_NEQ] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_U_LT] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_U_GE] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_U_GT] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_U_LE] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_S_LT] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_S_GE] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_S_GT] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_S_LE] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_F_EQ] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_F_NE] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_F_LT] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_F_GE] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_F_GT] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_F_LE] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_IF] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_B2N] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_EXP2] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_SELECT] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_CONC] = value;
  _optype_to_cost[COpNumExprTuple::OP_TYPE_REPEAT] = value;

  // Statements
  _stmt_to_cost[CGenericStmt::GS_SKIP] = value;
  _stmt_to_cost[CGenericStmt::GS_STORE] = value;
  _stmt_to_cost[CGenericStmt::GS_COND] = value;
  _stmt_to_cost[CGenericStmt::GS_JUMP] = value;
  _stmt_to_cost[CGenericStmt::GS_CALL] = value;
  _stmt_to_cost[CGenericStmt::GS_ENTER] = value;
  _stmt_to_cost[CGenericStmt::GS_RETURN] = value;
  _stmt_to_cost[CGenericStmt::GS_RESULT] = value;
  _stmt_to_cost[CGenericStmt::GS_FREE] = value;
  _stmt_to_cost[CGenericStmt::GS_SCOPE] = value;
  _stmt_to_cost[CGenericStmt::GS_UNKNOWN] = value;
  _stmt_to_cost[CGenericStmt::GS_OTHER] = value;
  _stmt_to_cost[CGenericStmt::GS_ABS_STORE_INT] = value;
  _stmt_to_cost[CGenericStmt::GS_ABS_STORE_FLOAT] = value;
  _stmt_to_cost[CGenericStmt::GS_ABS_STORE_POINTER] = value;

}



} // end namespace alf
