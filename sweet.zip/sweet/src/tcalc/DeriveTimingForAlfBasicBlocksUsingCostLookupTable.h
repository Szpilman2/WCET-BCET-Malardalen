#ifndef DERIVE_TIMING_FOR_ALF_BASIC_BLOCKS_USING_COST_LOOKUP_TABLE_H_
#define DERIVE_TIMING_FOR_ALF_BASIC_BLOCKS_USING_COST_LOOKUP_TABLE_H_

#include <vector>
#include "graphs/cfg/CFlowGraph.h"

// -------------------------------------------------------
// Functions for deriving timing for ALF basic blocks based on
// a table holding timing costs for different ALF code constructs. 
// -------------------------------------------------------

// Read cost lookup table from second argument file and write result to third argument file
void DeriveTimingForAlfBasicBlocksUsingCostLookupTable(const std::vector<CFlowGraph*> * flow_graphs, 
                                                       std::string clt_filename, std::string tdb_filename);
// Read cost lookup table from second argument file and write result to stdout
void DeriveTimingForAlfBasicBlocksUsingCostLookupTable(const std::vector<CFlowGraph*> * flow_graphs, 
                                                       std::string clt_filename);
// Run using default cost values instead of reading from file. Write result to tdb_filename.
void DeriveTimingForAlfBasicBlocksUsingDefaultCostLookupTable(const std::vector<CFlowGraph*> * flow_graphs, 
                                                              std::string tdb_filename);
// Run using default cost values instead of reading from file. Write result to stdout
void DeriveTimingForAlfBasicBlocksUsingDefaultCostLookupTable(const std::vector<CFlowGraph*> * flow_graphs); 


#endif




