// $Id $

#include "CAlfCostCalculator.h"
#include "program/alf/AStmt.h"

namespace alf
{

CAlfCostCalculator::CAlfCostCalculator(CAlfCostLookupTable * table)
  : _table(table),
    _traversor(new CAlfTreeTraversor)
{
  _traversor->RegisterNodeVisitor(this);
}
  
CAlfCostCalculator::~CAlfCostCalculator()
{
  delete _table;
  delete _traversor;
}

int
CAlfCostCalculator::
CalculateCost(const AStmt * stmt)
{
  _cost = 0; 
  _traversor->BeginTraverse((const CGenericNode*)stmt);
  return _cost;
}

bool 
CAlfCostCalculator::
onBeginVisit(const CGenericNode* node) {
  // std::cout << "onBeginVisit(CGenericNode::" << node->GetNodeTypeAsString() << ")" << std::endl;
  
  // Get the type of node 
  const CGenericNode::TYPE node_type = node->GetNodeType();
  
  // Add the cost for generic node if lookup table has costs for such
  if(_table->HasGenericNodeCost()) {
    // Add cost for the generic node
    _cost = _cost + (int)_table->LookUpCost(node_type);
  }
	  
  // Check if it is an operand expression and lookup table has costs for such
  if(_table->HasOperandCost() && CGenericNode::TYPE_OP_EXPR_TUPLE == node_type) {
    // Downcast the node to an expression node
    const COpNumExprTuple * expr = dynamic_cast<const COpNumExprTuple*>(node);
    // Get the operand
    COpNumExprTuple::OP_TYPE op_type = expr->GetOperator();
    // Add the cost for the operand (if any)
    _cost = _cost + (int)_table->LookUpCost(op_type);
  }

  // Check if it is a statement and lookup table has costs for such
  if(_table->HasStmtCost() && node->IsType(CGenericNode::TYPE_STMT)) {
    // Downcast to a generic statement
    const alf::AStmt * astmt = dynamic_cast<const alf::AStmt *>(node);
    // Get the statement type
    CGenericStmt::GS_TYPE gs_type = astmt->Type();
    // Get the cost for the statement type
    _cost = _cost + (int)_table->LookUpCost(gs_type);
  }
    
  return true;
}
  
void
CAlfCostCalculator::
onEndVisit(const CGenericNode* node)
{
  return;
}
  
}
