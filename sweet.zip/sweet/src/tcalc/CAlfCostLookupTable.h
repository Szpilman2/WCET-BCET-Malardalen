// $Id $

#ifndef ALF_COSTLOOKUPTABLE_H
#define ALF_COSTLOOKUPTABLE_H

#include <map>
#include <string>

// To get the needed types
#include "program/alf/CGenericNode.h"
#include "program/CGenericStmt.h"
#include "program/alf/COpNumExprTuple.h"

// -------------------------------------------------------
// CAlfCostLookupTable -
// Reads timing constants for ALF code constructs from a file 
// or from a simple predefined mapping table. After table has 
// been created the LookUpCost() function can be used to get 
// the timing constants for a certain ALF node type.
// -------------------------------------------------------
namespace alf 
{

class CAlfCostLookupTable {
 
public:
    
  // To create and delete the object. Without any input argument
  // a default table is created. With an argument the table is read 
  // from a file. 
  CAlfCostLookupTable();
  CAlfCostLookupTable(const std::string & filename);
  ~CAlfCostLookupTable();
  
  // To get if a certain cost type is held by the lookup table
  bool HasProgRunCost() const { return _prog_run_cost != 0; }
  bool HasGenericNodeCost() const;
  bool HasOperandCost() const;
  bool HasStmtCost() const;
  bool HasStmtPairCost() const;

  // To get the cost of a certain alf construct 
  double LookUpProgRunCost() const {return _prog_run_cost; }
  double LookUpCost(CGenericNode::TYPE node_type) const;
  double LookUpCost(COpNumExprTuple::OP_TYPE op_type) const;
  double LookUpCost(CGenericStmt::GS_TYPE stmt_type) const;
  double LookUpCost(std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE> stmt_pair) const;
  // double LookUpCost(AExpr::EXPR_TYPE expr_type);
  // ** If more cost types are added CAlfCostCalculator might need to get updated **

  static void PrintAsTemplate(std::string file_name, bool print_prog_run, 
			      bool print_gen_nodes, bool print_ops, 
                              bool print_stmts, bool print_stmt_pairs);
protected:

  // Maps holding the costs of certain alf constructs
  double _prog_run_cost;
  std::map<CGenericNode::TYPE, double> _node_to_cost;
  std::map<COpNumExprTuple::OP_TYPE, double> _optype_to_cost;
  std::map<CGenericStmt::GS_TYPE, double> _stmt_to_cost;
  std::map<std::pair<CGenericStmt::GS_TYPE, CGenericStmt::GS_TYPE>, double> _stmt_pair_to_cost;
  
  // Help functions to create a cost lookup table
  // void SetDefaultTimingConstants();
  void SetAllTimingConstants(double value);
  void ReadTimingConstantsFromFile(const std::string & filename);

  // Help function for reading next identifier from file
  // std::string GetToken(std::ifstream & stream, const char separator=':');
};

}

#endif
