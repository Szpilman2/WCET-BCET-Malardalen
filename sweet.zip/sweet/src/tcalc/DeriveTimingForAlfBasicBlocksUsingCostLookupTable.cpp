#include <iostream>
#include <fstream>
#include <sstream>
#include <iostream>
#include <cstdlib>
#include <list>

#include "tcalc/DeriveTimingForAlfBasicBlocksUsingCostLookupTable.h"
#include "tcalc/CAlfCostLookupTable.h"
#include "tcalc/CAlfCostCalculator.h"
#include "program/CGenericStmt.h"
#include "program/alf/AStmt.h"
#include "program/alf/CLabelTuple.h"
#include "program/alf/CLRefTuple.h"

using namespace std;

// -------------------------------------------------------
// Help function for creating time database. Assumes that each
// basic block has a label. Not visible from the outside
// -------------------------------------------------------
void
DeriveTiming(const vector<CFlowGraph*> * flow_graphs,
             alf::CAlfCostCalculator * ccalc, ostream * tdb_stream)
{
  // Loop through all the cfg's of the program
  for (vector<CFlowGraph*>::const_iterator fg = flow_graphs->begin(); fg != flow_graphs->end(); fg++)
    {
      // Loop through all the basic blocks of the given cfg
      vector< list<CFlowGraphNode *> *> bbs;
      (*fg)->GetBasicBlocksAsNodeLists(&bbs);
      for (vector< list<CFlowGraphNode *> *>::iterator bb = bbs.begin();
           bb != bbs.end(); bb++) 
        {
          // Derive the timing for the basic block
          unsigned int sum = 0;
          unsigned int nr_of_stmts = 0;
          // Loop through all the nodes in the basic block
          for (list<CFlowGraphNode *>::iterator node = (*bb)->begin(); node != (*bb)->end(); node++)
            {
              // Derive the cost for the statement
              CGenericStmt * gstmt = (*node)->Stmt();
              assert(gstmt);
              alf::AStmt * astmt = dynamic_cast<alf::AStmt *>(gstmt);
              assert(astmt);
              // Add the cost for the statement to the cost of the basic block
              sum += ccalc->CalculateCost(astmt);
              nr_of_stmts++;
            }
	  // Extra check if the node is the entry node of teh basic block we should 
	  // add the cost for the func arg and decls management.
	  // if((*bb) == (*fg)->GetEntry()) {
	    // Get the ALF func tuple
	    // alf::CFuncTuple * func_tuple = dynamic_cast<alf::CFuncTuple*>(fg->Function());
	    // 
	    


          // Get the statement of the first node in the basic block
          assert((*bb)->size() > 0);
          CGenericStmt * gstmt = (*((*bb)->begin()))->Stmt();
          assert(gstmt);
          alf::AStmt * astmt = dynamic_cast<alf::AStmt *>(gstmt);
          assert(astmt);
          alf::CLabelTuple * label = astmt->GetLabel();
          // Print the cost of the node to stream
          if (label != 0)
            {
              alf::CLRefTuple * lref = label->GetLRef();
              assert(lref);
              (*tdb_stream) << lref->GetId() << " " << sum << endl;
            }
        }
      // Delete temporary lists
      for(vector< list<CFlowGraphNode *> *>::iterator bb = bbs.begin();
          bb != bbs.end(); bb++) {
        delete *bb;
      }
    }
}

// -------------------------------------------------------                                                    
// Read cost lookup table from second argument file and write result
// to third argument file
// -------------------------------------------------------
void 
DeriveTimingForAlfBasicBlocksUsingCostLookupTable(const vector<CFlowGraph*> * flow_graphs,
                                                  string clt_filename, string tdb_filename)
{
  // Open a file for reading
  ofstream tdb_stream(tdb_filename.c_str());
  if (!tdb_stream) { 
    cerr << "Output tdb file  '" << tdb_filename << "' cannot be opened!\n";
    exit(-2);
  }
  alf::CAlfCostLookupTable * ltable = new alf::CAlfCostLookupTable(clt_filename);
  // Create cost calculator using table (ltable will be deallocated by cost calculator)
  alf::CAlfCostCalculator ccalc(ltable);
  // Derive timing for basic blocks
  DeriveTiming(flow_graphs, &ccalc, &tdb_stream);
  // Close output stream
  tdb_stream.close();
}

// -------------------------------------------------------
// Read cost lookup table from second argument file and write result
// to stdout
// -------------------------------------------------------
void 
DeriveTimingForAlfBasicBlocksUsingCostLookupTable(const vector<CFlowGraph*> * flow_graphs,
                                                  string clt_filename)
{
  // Create a cost lookup table with input file name
  alf::CAlfCostLookupTable * ltable = new alf::CAlfCostLookupTable(clt_filename);
  // Create cost calculator using table (ltable will be deallocated by cost calculator)
  alf::CAlfCostCalculator ccalc(ltable);
  // Derive timing for basic blocks
  DeriveTiming(flow_graphs, &ccalc, &cout);
}

// -------------------------------------------------------
// Run using default cost values instead of reading from file. Write
// result to tdb_filename.
// -------------------------------------------------------
void 
DeriveTimingForAlfBasicBlocksUsingDefaultCostLookupTable(const vector<CFlowGraph*> * flow_graphs,
                                                         string tdb_filename)
{
  // Open a file for reading
  ofstream tdb_stream(tdb_filename.c_str());
  if (!tdb_stream) { 
    cerr << "Output tdb file  '" << tdb_filename << "' cannot be opened!\n";
    exit(-2);
  }
  // Create a cost lookup table with default timing costs
  alf::CAlfCostLookupTable * ltable = new alf::CAlfCostLookupTable;
  // Create cost calculator using table (ltable will be deallocated by cost calculator)
  alf::CAlfCostCalculator ccalc(ltable);
  // Derive timing for basic blocks
  DeriveTiming(flow_graphs, &ccalc, &tdb_stream);
  // Close output stream
  tdb_stream.close();
}

// -------------------------------------------------------
// Run using default cost values instead of reading from 
// file. Write result to stdout
// -------------------------------------------------------
void 
DeriveTimingForAlfBasicBlocksUsingDefaultCostLookupTable(const vector<CFlowGraph*> * flow_graphs)
{
  // Create a cost lookup table with default timing costs
  alf::CAlfCostLookupTable * ltable = new alf::CAlfCostLookupTable;
  // Create cost calculator using table (ltable will be deallocated by cost calculator)
  alf::CAlfCostCalculator ccalc(ltable);
  // Do the actual calculation
  DeriveTiming(flow_graphs, &ccalc, &cout);
}

