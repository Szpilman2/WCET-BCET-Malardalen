// $Id $

#ifndef ALF_COSTCALCULATOR_H
#define ALF_COSTCALCULATOR_H

#include "CAlfCostLookupTable.h"
#include "program/alf/CAlfTreeTraversor.h"
#include "program/alf/CGenericNode.h"

namespace alf
{
   class CAlfCostCalculator : public CAlfTreeTraversor::INodeVisitor
    {
    public:
      // To create the object. The lookup table will be owned by the
      // cost calculator and deleted when the calculator is deleted.
      CAlfCostCalculator(CAlfCostLookupTable * table);
      virtual ~CAlfCostCalculator();
      
      // To derive the cost for a statement
      int CalculateCost(const AStmt* stmt);
      // int CalculateCost(list<CGenericStmt> * node);

      // To calculate a cost for a certain node
      virtual bool onBeginVisit(const CGenericNode* node);
//       virtual bool onBeginVisit(COpNumExprTuple* node);
      virtual void onEndVisit(const CGenericNode* node);
 
    private:
      CAlfCostLookupTable * _table;
      int _cost;
      CAlfTreeTraversor * _traversor;
   };
}

#endif

