// -------------------------------------------------------
// This file holds help classes for storing ALF input value
// assignments.  Classes declared will be used as a temporary storage
// before inserted into the ALF CFG. The CALFAbsAnnotList is the 
// return value of the ALF input value annotation parser.
// 
// Author: andreas.ermedahl@mdh.se
// $Id: $
// -------------------------------------------------------

#ifndef CALFABSANNOT_H
#define CALFABSANNOT_H

#include <list>
#include <string>
#include <iostream>
#include <stdint.h>
#include "graphs/cfg/CFlowGraph.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CFuncTuple.h"
#include "program/alf/CAllocTuple.h"
#include "program/alf/CDeclList.h"
#include "program/alf/CArgDeclList.h"
#include "program/alf/CScopeTuple.h"
#include "program/alf/CGenericNode.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/ecfg/CECFGNode.h"
#include <sstream>

using namespace std;

// Predefinition of classes
class CALFAbsAnnotList;
class CALFAbsAnnot;
class CALFAbsAnnotPosition;
class CALFAbsAnnotPositionStmtEntry;
class CALFAbsAnnotPositionStmtExit;
class CALFAbsAnnotPositionFuncEntry;
class CALFAbsAnnotPositionProgramEntry;
class CALFAbsAnnotVar;
class CALFAbsAnnotVal;
class CALFAbsAnnotValInt;
class CALFAbsAnnotValFloat;
class CALFAbsAnnotValAddress;
class CALFAbsAnnotValLabel;
class CFRefIdOffsetPair;
class CLRefIdOffsetPair;
class CALFAbsAnnotStorage;

template <typename> class EInt;
typedef EInt<unsigned long long> Size;


// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// To open the file and read the abstract ALF value assignment
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

class CReadALFAbsAnnotsAndCreateALFAbsAnnotStorage
{
public:
  // To create and delete the object
  CReadALFAbsAnnotsAndCreateALFAbsAnnotStorage();
  virtual ~CReadALFAbsAnnotsAndCreateALFAbsAnnotStorage();
  
  // Run the algorithm. Returns NULL if not successful.
  CALFAbsAnnotStorage * Run(string annot_filename, const alf::CAlfTuple * alf_tuple);

protected:
  // To read annotations from a given file. Returns true if successful.
  bool ReadAnnotsFromFile(string filename, CALFAbsAnnotList ** abs_annot_list);

  // Check that the read annotations can be added to ALF program. Also stores the keys of referenced 
  // frefs and lrefs in the annots. Returns true if successful.
  bool CheckAnnotsAndSetKeys(CALFAbsAnnotList * abs_annot_list, const alf::CAlfTuple * alf_tuple);

  // Help functions
  bool CheckOverlappingAnnots(CALFAbsAnnotList * abs_annot_list, ostringstream & error_msg);
  bool CheckOkToAddAndSetKeysAndStmt(CALFAbsAnnotList * abs_annot_list, const alf::CAlfTuple * alf_tuple, 
                                     ostringstream & error_msg);
};

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// Annotation list class
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

// ---------------------------------
// CALFAbsAnnotList -
// A list of ALF input value annotations. Return value of 
// the ALF input value annotation parser.
// ---------------------------------
class CALFAbsAnnotList : public list<CALFAbsAnnot *> 
{
public:
  // To create and delete the content of the list
  CALFAbsAnnotList();
  virtual ~CALFAbsAnnotList();
  
  // To print the content of the list
  std::ostream & Print(std::ostream & o = std::cout) const;
};

inline std::ostream & operator <<(std::ostream & o, const CALFAbsAnnotList & a) {return a.Print(o);}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// Annotation class
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

// ---------------------------------
// CALFAbsAnnot -
// A single ALF input value annotation. Created by the annotation parser. 
// ---------------------------------
class CALFAbsAnnot 
{
public:

  // Enum holding the types of updates that exists
  enum UpdateType { ASSIGN, GLB, LUB };

  // To create and delete an ALF abstract annotation
  CALFAbsAnnot(CALFAbsAnnotPosition * position, CALFAbsAnnot::UpdateType update_type, 
               list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > * var_vals_list);
  virtual ~CALFAbsAnnot();

  // To get content of ALF abstract annotation
  const CALFAbsAnnotPosition * Position() const;
  CALFAbsAnnot::UpdateType Type() const;
  bool IsType(CALFAbsAnnot::UpdateType type) const { return _update_type == type; } 
  const list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > * VarValsList() const;
  list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > * GetModifyableVarValsList();

  // To print the abstract annotation
  std::ostream & Print(std::ostream & o = std::cout) const;

  // Checks that the entities in the annotation, such as function
  // names and variable names, really exists in the program and in the
  // given context. Also check that no all values are stored within
  // given frame borders. Prints error messages if erroneous annotation.
  // Returns true if no errors were found.
  bool CheckOkToAddAndSetKeysAndStmt(const alf::CAlfTuple *alf_tuple, ostringstream & error_msg);
 
  // To get the defs and addresses of the annot. For INT and FLOAT
  // annots, e.g. x := 1..10 no addresses are taken. For ADDRESS and
  // LRFEF annots, x := &y &z addresses are taken. Require that the
  // lrefs and frefs in the annots has been given keys by the
  // CheckOkToAddAndSetKeysAndStmt() function. The defs are all
  // referring to frefs. Addresses can refer to both frefs (data) and
  // lrefs (labels). Since there might be many parallel assignments
  // in an annot we have pairs of defs and addresses. Each def can
  // have zero or more addresses.
  void GetDefAddressesPairs(set<pair<int,set<int> > > * def_address_pairs) const;
  // If we only are intrested in all frefs that are defined in the annotation. This 
  // includes annotations which do not takes any address of, such as x := 1..10 annots.
  void GetDefs(set<int> * defs) const;
  // If we only are intrested in all frefs and labels that are whose
  // addresses are used in the annotation
  void GetAddresses(set<int> * addresses) const;
  // The union of GetDefs and GetAddresses
  void GetDefsAndAddresses(set<int> * defs_and_addresses) const; 

  // To set and get the CFG node it refers to. Will be NULL for PROG_ENTRY annots
  void SetStmt(alf::AStmt * stmt) { _stmt = stmt; }
  const alf::AStmt * GetStmt() { assert(_stmt); return _stmt; }
  const alf::CFuncTuple * GetFunc() { assert(_stmt); return dynamic_cast<const alf::CFuncTuple *>(_stmt->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE)); }

  // To copy the annotation
  CALFAbsAnnot * Copy() const;

  bool DeclaresFRefIdInCurrentOrParentScopesOrGlobalScopeOrImports(const alf::CAlfTuple *alf_tuple,
                                                                    const alf::CScopeTuple* scope,
                                                                    std::string frefid, Size * frame_size, unsigned int * key);

protected:

  // Help functions
  bool CheckOkToAddAtProgEntryAndSetKeysAndStmt(const alf::CAlfTuple *alf_tuple, ostringstream & error_msg);
  bool CheckOkToAddAtFuncEntryAndSetKeysAndStmt(const alf::CAlfTuple *alf_tuple, ostringstream & error_msg);
  bool CheckOkToAddAtStmtEntryOrStmtExitAndSetKeysAndStmt(const alf::CAlfTuple *alf_tuple, ostringstream & error_msg); 
  bool CheckOkToAddVolatileAndSetKeys(const alf::CAlfTuple *alf_tuple, ostringstream & error_msg);
  bool CheckOkToAddWhenCalledAndSetKeys(const alf::CAlfTuple *alf_tuple, ostringstream & error_msg);

  bool HasFRefIdInDecls(const alf::CDeclList * decls, std::string frefid, Size * frame_size, unsigned int * key);
  bool HasFRefIdInArgDecls(const alf::CArgDeclList * decls, std::string frefid, Size * frame_size, unsigned int * key);
  bool HasFRefIdInImports(const alf::CImportsTuple* imports, std::string frefid, Size * frame_size, unsigned int * key);
  bool HasFRefIdInGlobalDeclsOrImports(const alf::CAlfTuple * program, std::string frefid, Size * frame_size, unsigned int * key);
  bool HasFRefIdInDeclsOrImports(const alf::CDeclList * decls, const alf::CImportsTuple* imports, std::string frefid, Size * frame_size, unsigned int * key);
  bool HasLRefIdInImports(const alf::CImportsTuple* imports, std::string frefid, Size * frame_size, unsigned int * key);
  bool HasLRefIdInStmts(const alf::CAlfTuple * program, std::string lrefid, unsigned int offset, unsigned int * key);
  bool HasLRefIdInFuncsOrImports(const alf::CAlfTuple * program, std::string lrefid, unsigned int * key, alf::CFuncTuple **func); 

  // Internal data
  unsigned _line_no;
  CALFAbsAnnotPosition * _position;
  CALFAbsAnnot::UpdateType _update_type;
  list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > * _var_vals_list;
  alf::AStmt * _stmt;

};

inline std::ostream & operator <<(std::ostream & o, const CALFAbsAnnot & a) {return a.Print(o);}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// Position classes
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

// ---------------------------------
// CALFAbsAnnotPosition -
// General class that all position classes should inherit from
// ---------------------------------
class CALFAbsAnnotPosition 
{
public:
  // No create function
  virtual ~CALFAbsAnnotPosition();
  
  // Enum holding the type of positions that exists
  enum PositionType { PROG_ENTRY, FUNC_ENTRY, STMT_ENTRY, STMT_EXIT, VOLATILE, WHEN_CALLED };

  // To check what subtype it is
  PositionType Type() { return _position_type; }
  bool IsType(PositionType type) const { return _position_type == type; } 

  // To check if two positions are equal
  virtual bool IsEqual(const CALFAbsAnnotPosition * other) const = 0;

  // To print the position
  virtual std::ostream & Print(std::ostream & o = std::cout) const = 0;

  // To Copy the position 
  virtual CALFAbsAnnotPosition * Copy() const = 0;

protected:

  PositionType _position_type;

};

inline std::ostream & operator <<(std::ostream & o, const CALFAbsAnnotPosition & a) {return a.Print(o);}

// ---------------------------------
// CALFAbsAnnotPositionStmtEntry -
// To store annotation before execution of statement. 
// ---------------------------------
class CALFAbsAnnotPositionStmtEntry : public CALFAbsAnnotPosition
{
public:
  // Create and delete 
  CALFAbsAnnotPositionStmtEntry(std::string func, std::string lrefid, uint64_t loffs);
  virtual ~CALFAbsAnnotPositionStmtEntry();

  // Access functions
  std::string Func() const;
  std::string LRefId() const;
  uint64_t LOffs() const;

  // To check if two positions are equal
  bool IsEqual(const CALFAbsAnnotPosition * other) const;

  // To print the position
  std::ostream & Print(std::ostream & o = std::cout) const;

  // To copy the position 
  CALFAbsAnnotPositionStmtEntry * Copy() const;

protected:

  // Internal vars
  std::string _func;
  std::string _lrefid;
  uint64_t _loffs;
};

// ---------------------------------
// CALFAbsAnnotPositionStmtExit -
// To store annotation after execution of statement. 
// ---------------------------------
class CALFAbsAnnotPositionStmtExit : public CALFAbsAnnotPosition
{
public:
  // Create and delete 
  CALFAbsAnnotPositionStmtExit(std::string func, std::string lrefid, uint64_t loffs);
  virtual ~CALFAbsAnnotPositionStmtExit();

  // Access functions
  std::string Func() const;
  std::string LRefId() const;
  uint64_t LOffs() const;

  // To check if two positions are equal
  bool IsEqual(const CALFAbsAnnotPosition * other) const;

  // To print the position
  std::ostream & Print(std::ostream & o = std::cout) const;

  // To copy the position 
  CALFAbsAnnotPositionStmtExit * Copy() const;

protected:

  // Internal vars
  std::string _func;
  std::string _lrefid;
  uint64_t _loffs;
};

// ---------------------------------
// CALFAbsAnnotPositionFuncEntry -
// To store annotation after entry of function before first statement
// ---------------------------------
class CALFAbsAnnotPositionFuncEntry : public CALFAbsAnnotPosition
{
public:
  // Create and delete 
  CALFAbsAnnotPositionFuncEntry(std::string func);
  virtual ~CALFAbsAnnotPositionFuncEntry();

  // Access functions
  std::string Func() const;

  // To check if two positions are equal
  bool IsEqual(const CALFAbsAnnotPosition * other) const;

  // To print the position
  std::ostream &  Print(std::ostream & o = std::cout) const;

  // To copy the position 
  CALFAbsAnnotPositionFuncEntry * Copy() const;

protected:

  // Internal vars
  std::string _func;
};

// ---------------------------------
// CALFAbsAnnotPositionProgEntry -
// To store annotation after all globals declarations and annotations
// ---------------------------------
class CALFAbsAnnotPositionProgEntry : public CALFAbsAnnotPosition
{
public:
  // Create and delete 
  CALFAbsAnnotPositionProgEntry();
  virtual ~CALFAbsAnnotPositionProgEntry();

  // To check if two positions are equal
  bool IsEqual(const CALFAbsAnnotPosition * other) const;

  // To print the position
  std::ostream & Print(std::ostream & o = std::cout) const;

  // To copy the position 
  CALFAbsAnnotPositionProgEntry * Copy() const;
};

// ---------------------------------
// CALFAbsAnnotPositionVolatile -
// A volatile store of annotations
// ---------------------------------
class CALFAbsAnnotPositionVolatile : public CALFAbsAnnotPosition
{
public:
  // Create and delete 
  CALFAbsAnnotPositionVolatile();
  virtual ~CALFAbsAnnotPositionVolatile();

  // To check if two positions are equal
  bool IsEqual(const CALFAbsAnnotPosition * other) const;

  // To print the position
  std::ostream & Print(std::ostream & o = std::cout) const;

  // To copy the position 
  CALFAbsAnnotPositionVolatile * Copy() const;
};

// ---------------------------------
// CALFAbsAnnotPositionWhenCalled -
// An annotation valid whenever the given function is called
// ---------------------------------
class CALFAbsAnnotPositionWhenCalled : public CALFAbsAnnotPosition
{
public:
  // Create and delete 
  CALFAbsAnnotPositionWhenCalled(std::string func);
  virtual ~CALFAbsAnnotPositionWhenCalled();

  // Access functions
  std::string Func() const;

  // To check if two positions are equal
  bool IsEqual(const CALFAbsAnnotPosition * other) const;

  // To print the position
  std::ostream & Print(std::ostream & o = std::cout) const;

  // To copy the position 
  CALFAbsAnnotPositionWhenCalled * Copy() const;

protected:

  // Internal vars
  std::string _func;
};


// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// Variable classes
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

// ---------------------------------
// CALFAbsAnnotVar -
// Holds variable ref where to store the value 
// ---------------------------------
class CALFAbsAnnotVar
{
public:
  // Create and delete. The foffs is given in bits.
  CALFAbsAnnotVar( std::string frefid );
  CALFAbsAnnotVar( std::string frefid, int _no_of_derefs );
  CALFAbsAnnotVar( std::string frefid, uint64_t foffs_in_bits, Size size_in_bits );
  CALFAbsAnnotVar( std::string frefid, int _no_of_derefs, uint64_t foffs_in_bits, Size size_in_bits );
  CALFAbsAnnotVar( std::string frefid, uint64_t foffs_in_bits, Size size_in_bits, uint64_t repeat );
  CALFAbsAnnotVar( std::string frefid, int _no_of_derefs, uint64_t foffs_in_bits, Size size_in_bits, uint64_t repeat );
  virtual ~CALFAbsAnnotVar() {};

  // Access functions
  void SetFRefId(std::string);
  std::string FRefId() const;

  // If no offset was given then fOffs is equal to 0. 
  bool HasFOffs() const;
  uint64_t FOffsInBits() const;
  void SetFOffsInBits(uint64_t foffs);
  // If no size in bits has been given it will be set to the size of
  // the whole frame after check code. If SizeInBits is called without
  bool HasSize() const;
  Size SizeInBits() const;
  void SetSizeInBits(Size size_in_bits);
  // To get the number of repeats. If not set 1 will be returned.
  bool HasRepeat() const;
  uint64_t Repeat() const;
  void SetRepeat(uint64_t foffs);

  // To set and get the global key of the fref with the given id.
  void SetKey(unsigned int key) { _key = key; _has_key = true; };
  bool HasKey() { return _has_key; }
  unsigned int GetKey() { return _key; }
  
  // To set and get the number of dereferencing
  bool HasDerefs() { return _no_of_derefs > 0; }
  void SetNoOfDerefs(int no_of_derefs) { _no_of_derefs = no_of_derefs; }
  int GetNoOfDerefs() { return _no_of_derefs; }
   
  // For handlig the pointer sizes during dereferencing
  void AddPSizes(std::vector <int>);
  int PSize(int) const;

  // To check if two var annotations overlaps
  bool Overlaps(const CALFAbsAnnotVar * other) const;

  // To print the variable
  std::ostream & Print(std::ostream & o = std::cout) const;

  // To make a deep copy of the variable
  virtual CALFAbsAnnotVar * Copy() const;

  // To get if the variable is of RET_VAL type
  virtual bool IsReturnValueVar() const { return false; }
  
protected:
  // Internal vars
  std::string _frefid;
  bool _has_foffs;
  uint64_t _foffs_in_bits;
  bool _has_size;
  Size _size_in_bits;
  bool _has_repeat;
  uint64_t _repeat;
  unsigned int _key; 
  bool _has_key;
  int _no_of_derefs;
  vector <int> _psizes;

};

// ---------------------------------
// CALFAbsAnnotReturnValueVar -
// Holds a return value ref where to store the value 
// ---------------------------------
//class CALFAbsAnnotReturnValueVar : public CALFAbsAnnotVar
//{
//public:

  // Create and delete 
  //CALFAbsAnnotReturnValueVar( );
  //virtual ~CALFAbsAnnotReturnValueVar( ) {};

  // Removed since we can not statically check the size of functions return values for 
  // imported functions.
  // CALFAbsAnnotReturnValueVar(uint64_t foffs, Size size_in_bits );
  // CALFAbsAnnotReturnValueVar(uint64_t foffs, Size size_in_bits , uint64_t repeat );

  // To make a deep copy of the variable
  //CALFAbsAnnotVar * Copy() const;

  // To get if the variable is of RET_VAL type
  //bool IsReturnValueVar() const { return true; }

  //};

inline std::ostream & operator <<(std::ostream & o, const CALFAbsAnnotVar & a) {return a.Print(o);}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// Value annotation classes
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

// ---------------------------------
// CALFAbsAnnotVal -
// General class all value annotations should inherit from 
// ---------------------------------
class CALFAbsAnnotVal 
{
public:
  // Create (not possible) and delete
  CALFAbsAnnotVal(bool is_top);
  virtual ~CALFAbsAnnotVal();

  // Enum holding the types of vals that exists
  enum ValType { TOP, INT, FLOAT, ADDRESS, LABEL };

  // To check what subtype it is and if it has the top value
  ValType Type() const { return _val_type; }
  bool IsType(ValType type) const { return _val_type == type; }
  bool IsTOP() const { return ((_val_type == TOP) && _is_top); }
  bool IsTOP_INT() const { return ((_val_type == INT) && _is_top); }
  bool IsTOP_FLOAT() const { return ((_val_type == FLOAT) && _is_top); }
  bool IsTOP_ADDRESS() const { return ((_val_type == ADDRESS) && _is_top); }
  bool IsTOP_LABEL() const { return ((_val_type == LABEL) && _is_top); }
   
  // To check if to value annotations are equal, must be redefined in subclasses.
  virtual bool IsEqual(const CALFAbsAnnotVal* val) const = 0;
  
  // Eliminate duplicates in the annotation, must be redefined in subclasses.
  virtual void Eliminate_Duplicates(void) const = 0;

  // To get the keys used. For int and float vars the set is empty, For
  // FRef and LRef the set will include the keys of frefs and lrefs
  // referred. Assumes that check annots have been performed. Should be 
  // implemented by subclasses.
  virtual void GetKeys(set<int> * keys) = 0;

  // To make a deep copy of the value
  virtual CALFAbsAnnotVal * Copy() const = 0;

  // To print the value
  virtual std::ostream & Print(std::ostream & o = std::cout) const = 0;

protected:
  // Internal vars
  bool _is_top;
  ValType _val_type;
    
};  

inline std::ostream & operator <<(std::ostream & o, const CALFAbsAnnotVal & a) {return a.Print(o);}

// ---------------------------------
// CALFAbsAnnotValTop -
// TOP annotation
// ---------------------------------
class CALFAbsAnnotValTop : public CALFAbsAnnotVal
{
public:
   // Create and delete
   CALFAbsAnnotValTop(); // A TOP value
   
   // For checking if two abstract values are equal
   bool IsEqual(const CALFAbsAnnotVal* val) const;
   
   // Eliminate duplicates in the annotation, N/A.
   virtual void Eliminate_Duplicates(void) const { };
   
   // No keys in value
   void GetKeys(set<int> * keys) { };
   
   // To make a deep copy of the variable
   CALFAbsAnnotValTop * Copy() const;
   
   // To print the value
   std::ostream & Print(std::ostream & o = std::cout) const;
};

// ---------------------------------
// CALFAbsAnnotValInt -
// Integer value annotation
// ---------------------------------
class CALFAbsAnnotValInt : public CALFAbsAnnotVal
{
public:
  // Create and delete
  CALFAbsAnnotValInt(); // A TOP_INT value
  CALFAbsAnnotValInt(int64_t ilow);
  CALFAbsAnnotValInt(int64_t ilow, int64_t iupp);
  CALFAbsAnnotValInt(int64_t ilow, int64_t iupp, uint64_t icong);
  virtual ~CALFAbsAnnotValInt();
  
  // For checking if two abstract values are equal
  bool IsEqual(const CALFAbsAnnotVal* val) const;
  
  // Eliminate duplicates in the annotation, N/A.
  virtual void Eliminate_Duplicates(void) const { };
  
  // Access functions
  int64_t ILow() const;
  int64_t IUpp() const;
  uint64_t ICong() const;
  
  void SetILow(int64_t ilow);
  void SetIUpp(int64_t iupp);
  
  // No keys in value
  void GetKeys(set<int> * keys) { };

  // To make a deep copy of the variable
  CALFAbsAnnotValInt * Copy() const;

  // To print the value
  std::ostream & Print(std::ostream & o = std::cout) const;

protected:
  // Internal vars
  int64_t _ilow;
  int64_t _iupp;
  uint64_t _icong;
};

// ---------------------------------
// CALFAbsAnnotValFloat -
// Float value annotation
// ---------------------------------
class CALFAbsAnnotValFloat : public CALFAbsAnnotVal
{
public:
  // Create and delete
  CALFAbsAnnotValFloat(); // A TOP_FLOAT value
  CALFAbsAnnotValFloat(float flow);
  CALFAbsAnnotValFloat(float flow,  float fupp);
  virtual ~CALFAbsAnnotValFloat();
  
  // For checking if two abstract values are equal
  bool IsEqual(const CALFAbsAnnotVal* val) const;
  
  // Eliminate duplicates in the annotation, N/A.
  virtual void Eliminate_Duplicates(void) const { };
  
  // Access functions
  float FLow() const;
  bool HasFUpp() const;
  float FUpp() const;
  
  void SetFLow(float ilow);
  void SetFUpp(float iupp);

  // No keys in value
  void GetKeys(set<int> * keys) { };

  // To make a deep copy of the variable
  CALFAbsAnnotValFloat * Copy() const;

  // To print the value
  std::ostream & Print(std::ostream & o = std::cout) const;

protected:
  // Internal vars
  float _flow;
  bool _has_fupp;
  float _fupp;
};
  
// ---------------------------------
// CALFAbsAnnotValAddress -
// Address value annotation
// ---------------------------------
class CALFAbsAnnotValAddress : public CALFAbsAnnotVal 
{
public:
  // Create and delete
  CALFAbsAnnotValAddress(); // TOP_ADDR value
  CALFAbsAnnotValAddress(list<CFRefIdOffsetPair *> * frefid_offset_pair_list);
  virtual ~CALFAbsAnnotValAddress();
  
  // For checking if two abstract values are equal
  bool IsEqual(const CALFAbsAnnotVal* val) const;
  
  // Eliminate duplicates in the annotation.
  virtual void Eliminate_Duplicates(void) const;

  // Access functions
  const list<CFRefIdOffsetPair *> * FRefIdOffsetPairList() const;

  // Get keys in value
  void GetKeys(set<int> * keys);

  // To make a deep copy of the variable
  CALFAbsAnnotValAddress * Copy() const;

  // To print the value
  std::ostream & Print(std::ostream & o = std::cout) const;

protected:
  // Internal vars
  list<CFRefIdOffsetPair *> * _frefid_offset_pair_list;
};

// ---------------------------------
// CALFAbsAnnotValLabel -
// Label value annotation
// ---------------------------------
class CALFAbsAnnotValLabel : public CALFAbsAnnotVal
{
public:
  // Create and delete
  CALFAbsAnnotValLabel(); // TOP_LABEL value
  CALFAbsAnnotValLabel(list<CLRefIdOffsetPair *> * lrefid_offset_pair_list);
  virtual ~CALFAbsAnnotValLabel();
  
  // For checking if two abstract values are equal
  bool IsEqual(const CALFAbsAnnotVal* val) const;
  
  // Eliminate duplicates in the annotation.
  virtual void Eliminate_Duplicates(void) const;
  
  // Access functions
  const list<CLRefIdOffsetPair *> * LRefIdOffsetPairList() const;

  // Get keys in value
  void GetKeys(set<int> * keys);

  // To make a deep copy of the variable
  CALFAbsAnnotValLabel * Copy() const;

  // To print the value
  std::ostream & Print(std::ostream & o = std::cout) const;

protected:
  // Internal vars
  list<CLRefIdOffsetPair *> * _lrefid_offset_pair_list;
};

// ---------------------------------
// CFRefIdOffsetPair
// ---------------------------------
class CFRefIdOffsetPair 
{
public:
  CFRefIdOffsetPair(std::string frefid, int64_t offset);
  CFRefIdOffsetPair(std::string frefid, int64_t offset_L, int64_t offset_U);
  virtual ~CFRefIdOffsetPair();

  // To get access to the different parts
  std::string FRefId() { return _frefid; }
  int64_t Offset_L() { return _offset_L; }
  int64_t Offset_U() { return _offset_U; }

  // To set and get the global key of the fref with the given id.
  void SetKey(unsigned int key) { _key = key; };
  unsigned int Key() { return _key;}

  // To copy the id offset pair
  CFRefIdOffsetPair * Copy() const;

  // To print the id offset pair
  std::ostream & Print(std::ostream & o = std::cout) const;

protected:
  std::string _frefid;
  int64_t _offset_L;
  int64_t _offset_U;
  unsigned int _key;
};

// ---------------------------------
// CLRefIdOffsetPair
// ---------------------------------
class CLRefIdOffsetPair 
{
public:
  CLRefIdOffsetPair(std::string lrefid, int64_t offset);
  virtual ~CLRefIdOffsetPair();

  // To get access to the different parts
  std::string LRefId() { return _lrefid; }
  int64_t Offset() { return _offset; }

  // To set and get the global key of the statement with the given id and offset.
  void SetKey(unsigned int key) { _key = key; };
  unsigned int Key() { return _key;}

  // To copy the id offset pair
  CLRefIdOffsetPair * Copy() const;

  // To print the id offset pair
  std::ostream & Print(std::ostream & o = std::cout) const;

protected:
  std::string _lrefid;
  int64_t _offset;
  unsigned int _key;
};


// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
//  CALFAbsAnnotStorage
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

// Class that provides an interface to different analyses for given
// annotations. Each CALFAbsAnnot is associated to the entry or exit
// of a stmt or to the entry of the program.
class CALFAbsAnnotStorage
{
public:
  // To create and delete the class. The argument list and the annots
  // in the argument list will be owned by the storage.
  CALFAbsAnnotStorage(CALFAbsAnnotList * annots);
  virtual ~CALFAbsAnnotStorage();

  // To add an abstract annotation to the storage. The annotations
  // will be sorted and indexed on the nodes to which they should be
  // associated. The annotation will be owned by the storage.
  void AddALFAbsAnnot(CALFAbsAnnot * annot);

  // To get the abstract update (if any) that should be made after the
  // global initialization has been made, but before the first
  // statement is executed. GetXY returns NULL if no entry annots exists.
  bool HasProgEntryALFAbsAnnot() const;
  CALFAbsAnnot * GetProgEntryALFAbsAnnot() const;

  // To get the abstract updates that should be performed at each call
  // of the given function before any of its statements are
  // executed. If called with a flow graph the func tuple will the
  // first be derived and then used in the lookup. GetXY returns NULL
  // if no annots exists.
  bool HasFuncEntryALFAbsAnnot(alf::CFuncTuple * func) const;
  CALFAbsAnnot * GetFuncEntryALFAbsAnnot(alf::CFuncTuple * func);
  bool HasFuncEntryALFAbsAnnot(CFlowGraph * func) const;
  CALFAbsAnnot * GetFuncEntryALFAbsAnnot(CFlowGraph * func);
  
  // To get the abstract updates that should be performed before the
  // given stmt, flow graph node or ecfg node is processed. GetXY
  // returns NULL if no annots exists.
  bool HasStmtEntryALFAbsAnnot(alf::AStmt * stmt) const;
  list<CALFAbsAnnot *> * GetStmtEntryALFAbsAnnot(alf::AStmt * stmt);
  bool HasNodeEntryALFAbsAnnot(CFlowGraphNode * node) const;
  list<CALFAbsAnnot *> * GetNodeEntryALFAbsAnnot(CFlowGraphNode * node);
  bool HasNodeEntryALFAbsAnnot(CECFGNode * node) const;
  list<CALFAbsAnnot *> * GetNodeEntryALFAbsAnnot(CECFGNode * node);

  // To get the abstract update that should be performed after the
  // given stmt, flow graph node or ecfg node is processed. Get func
  // returns NULL if no exit annots exists.
  bool HasStmtExitALFAbsAnnot(alf::AStmt * stmt) const;
  list<CALFAbsAnnot *> * GetStmtExitALFAbsAnnot(alf::AStmt * stmt);
  bool HasNodeExitALFAbsAnnot(CFlowGraphNode * node) const;
  list<CALFAbsAnnot *> * GetNodeExitALFAbsAnnot(CFlowGraphNode * node);
  bool HasNodeExitALFAbsAnnot(CECFGNode * node) const;
  list<CALFAbsAnnot *> * GetNodeExitALFAbsAnnot(CECFGNode * node);

  // To get the abstract global volatile annotates. Get func will
  // return an empty list if no volatile abs annot exists.
  bool HasVolatileAbsAnnots() const;
  list<CALFAbsAnnot *> * GetVolatileAbsAnnots();

  // To get the abstract func call annotates. Either all such
  // annotations can be derivced or the annotations specific to a
  // certain function.
  bool HasWhenCalledAlfAbsAnnots(alf::CFuncTuple * func) const;
  CALFAbsAnnot * GetWhenCalledAlfAbsAnnots(alf::CFuncTuple * func);
  bool HasWhenCalledAlfAbsAnnots(CFlowGraph * cfg) const;
  CALFAbsAnnot * GetWhenCalledAlfAbsAnnots(CFlowGraph * cfg);
  bool HasWhenCalledAlfAbsAnnots(std::string func_name) const;
  CALFAbsAnnot * GetWhenCalledAlfAbsAnnots(std::string func_name);

  // To get all annots as a list. The list is owned by the storage.
  const CALFAbsAnnotList * GetAbsAnnotList() const;

  // To get the defs and addresses of all the annots. For INT and
  // FLOAT annots, e.g. x := 1..10 no addresses are taken. For ADDRESS
  // and LREF annots, x := &y &z addresses are taken. The defs are
  // all referring to frefs. Addresses can refer to both frefs (data)
  // and lrefs (labels). Since there might be many parallel
  // assignments in an annot we have pairs of defs and addresses. Each
  // def can have zero or more addresses.
  void GetDefAddressesPairs(set<pair<int,set<int> > > * def_address_pairs) const;
  // If we only are intrested in all frefs that are defined in an annotation. This 
  // includes annotations which do not takes any address of, such as x := 1..10 annots.
  void GetDefs(set<int> * defs) const;
  // If we only are interested in all frefs and labels whose addresses
  // are used in any annotation
  void GetAddresses(set<int> * addresses) const;
  // The union of GetDefs and GetAddress
  void GetDefsAndAddresses(set<int> * defs_and_addresses) const; 

  // To print the content of the storage
  std::ostream & Print(std::ostream & o = std::cout) const;

protected:

  // Help functions
  void AddALFAbsAnnot(CALFAbsAnnot * annot, bool add_to_list);

  // Internal pointers
  CALFAbsAnnotList * _annot_list;
  CALFAbsAnnot * _prog_entry_annot;
  map<const alf::CFuncTuple *, CALFAbsAnnot *> _func_to_entry_annot_map;
  map<const alf::AStmt *, list<CALFAbsAnnot *> *> _stmt_to_entry_annots_map;
  map<const alf::AStmt *, list<CALFAbsAnnot *> *> _stmt_to_exit_annots_map;
  map<std::string, CALFAbsAnnot *> _func_name_to_when_called_annots_map;
  std::list<CALFAbsAnnot *> _volatile_annots;
};

inline std::ostream & operator <<(std::ostream & o, const CALFAbsAnnotStorage & a) {return a.Print(o);}

#endif // CALFABSANNOT_H
