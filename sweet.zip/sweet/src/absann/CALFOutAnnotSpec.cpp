#include "absann/CALFOutAnnotSpec.h"
#include "parsers/out_ann_spec_ALF/out_ann_spec_ALF.h"
#include "program/alf/CGenericNode.h"
#include "program/alf/CDeclList.h"
#include "program/alf/CFuncTuple.h"
#include "program/alf/CFuncList.h"
#include "program/alf/CStmtList.h"
#include "program/alf/CLRefTuple.h"
#include "program/alf/CLabelTuple.h"
#include "program/alf/CAllocTuple.h"
#include "program/alf/CIntNumValTuple.h"
#include "program/alf/CNumber.h"
#include "program/alf/CSize.h"
#include "program/alf/AStmt.h"
#include "program/alf/CImportsTuple.h"
#include "program/alf/CFRefList.h"
#include "program/alf/CLRefList.h"
#include "program/alf/CFRefTuple.h"
#include "program/alf/CLRefTuple.h"
#include "program/alf/CFuncTuple.h"
#include "program_state/LAU.h"

#include <gmpxx.h>
#include <ciso646>

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// Class to read output annotation specifications and add them as abs stmts to cfg
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CReadALFOutAnnotSpecsAndCreateALFOutAnnots::
CReadALFOutAnnotSpecsAndCreateALFOutAnnots()
{}

CReadALFOutAnnotSpecsAndCreateALFOutAnnots::
~CReadALFOutAnnotSpecsAndCreateALFOutAnnots()
{}

CALFOutAnnotSpecStorage *
CReadALFOutAnnotSpecsAndCreateALFOutAnnots::
Run(string filename, const alf::CAlfTuple * alf_tuple)
{
  cout << "Parsing output annotation specifications file '" << filename << "'.\n";
  // Parse output annotation specifications
  CALFOutAnnotSpecList * out_annot_spec_list;
  bool read_ok = ReadOutAnnotSpecsFromFile(filename, &out_annot_spec_list);
  if(!read_ok) return NULL;
  
  // Check that output annotation specifications are ok 
  bool check_ok = CheckOutAnnotSpecsAndSetKeys(out_annot_spec_list, alf_tuple);
  
  if(!check_ok) return NULL;
  // Create the storage to be returned and add annots
  CALFOutAnnotSpecStorage * aus = new CALFOutAnnotSpecStorage(out_annot_spec_list);
  return aus;
}

// Returns false if error
bool
CReadALFOutAnnotSpecsAndCreateALFOutAnnots::
ReadOutAnnotSpecsFromFile(string filename, CALFOutAnnotSpecList ** out_annot_spec_list)
{
   // Open the file and set global file identifier exported by parser
   // (as given in file out_ann_spec.l.cpp)
   extern FILE * out_ann_spec_ALF_in;
   bool success = false;
   out_ann_spec_ALF_in = fopen(filename.c_str(), "rt");

   if (out_ann_spec_ALF_in) {
      int parse_error = out_ann_spec_ALF_parse(out_annot_spec_list);
      success = parse_error == 0;
      fclose(out_ann_spec_ALF_in);
      out_ann_spec_ALF_lex_destroy();
   }
   return success;
}

// To check that all annotations are semantically correct. Returns
// false and throws an error message if an error occurred.
bool 
CReadALFOutAnnotSpecsAndCreateALFOutAnnots::
CheckOutAnnotSpecsAndSetKeys(CALFOutAnnotSpecList * out_annot_spec_list, const alf::CAlfTuple * alf_tuple) 
{
  ostringstream error_msg;
  bool annots_ok = true;

  // Check that annotations do not overlap wrongly, i.e. that two
  // annots not are located in the same position.
  annots_ok &= CheckOverlappingAnnots(out_annot_spec_list, error_msg);
    
  // Check that each annotation refer to valid labels, that variables
  // referred are accessible in the given scope, that they not go
  // outside the size of the corresponding frames.
  annots_ok &= CheckOkToAddAndSetKeysAndStmt(out_annot_spec_list, alf_tuple, error_msg);

  if(!annots_ok)
    throw runtime_error(error_msg.str());

  return annots_ok;
}

// Check that annotations do not overlap wrongly. I.e. that two
// annots not are located in the same position, that an updated fref
// not have overlapping updates, or (parts of) the same fref not is
// referred by the same annot                                        
bool 
CReadALFOutAnnotSpecsAndCreateALFOutAnnots::
CheckOverlappingAnnots(CALFOutAnnotSpecList * out_annot_spec_list, ostringstream & error_msg)
{
  bool has_equal_positions = false;
  { // Check that there are not any annotations with equal positions 
    for(list<CALFOutAnnotSpec *>::iterator absann1 = out_annot_spec_list->begin(); 
        absann1 != out_annot_spec_list->end(); absann1++) {
      list<CALFOutAnnotSpec *>::iterator absann2 = absann1;
      for(absann2++; absann2 != out_annot_spec_list->end(); absann2++) {
        if((*absann1)->Position()->IsEqual((*absann2)->Position())) {
           error_msg << "ERROR: abstract annotation: " << endl << (**absann1) << endl 
                    << "and abstract annotation: " << endl << (**absann2) 
                    << endl << "have the same program position. Merge them into a parallel update with the || operator." << endl;
          has_equal_positions = true;
        }
      }
    }
  }

  // Return true if all annots were ok 
  bool annots_ok_to_add = !has_equal_positions;
  return annots_ok_to_add;
}


// Loop through all abs annots and call their corresponding check function.
// Returns true if all annots were ok to add.
bool 
CReadALFOutAnnotSpecsAndCreateALFOutAnnots::
CheckOkToAddAndSetKeysAndStmt(CALFOutAnnotSpecList * out_annot_spec_list, const alf::CAlfTuple * alf_tuple, 
                              ostringstream & error_msg)
{
  bool annots_ok = true;
  for(list<CALFOutAnnotSpec *>::iterator absann = out_annot_spec_list->begin(); 
      absann != out_annot_spec_list->end(); absann++) {
    if((*absann)->CheckOkToAddAndSetKeysAndStmt(alf_tuple, error_msg) == false) {
      annots_ok = false;
    }
  }
  return annots_ok;
}
 
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFOutAnnotSpecList
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

// To create a list of abstract annotations
CALFOutAnnotSpecList ::
CALFOutAnnotSpecList()
{
  // Do nothing
}

// To delete a list of abstract annotations
CALFOutAnnotSpecList::
~CALFOutAnnotSpecList()
{
  // Delete all members in the list
  for(list<CALFOutAnnotSpec *>::iterator out_ann_spec = begin(); out_ann_spec != end(); out_ann_spec++)
    delete *out_ann_spec;
}

// To print all the abstract annotation assignments
std::ostream & 
CALFOutAnnotSpecList::
Print(std::ostream & o) const
{
  int annot_nr = 1;
  for(list<CALFOutAnnotSpec *>::const_iterator out_ann_spec = begin(); out_ann_spec != end(); out_ann_spec++) {
    (*out_ann_spec)->Print(o);
    o << endl;
    annot_nr++;
  }
  return o;
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFOutAnnotSpec
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFOutAnnotSpec::
CALFOutAnnotSpec(const CALFOutAnnotSpecPosition * position,
             list<CALFOutAnnotSpecVar * > * var_list)
  : _position(position), _var_list(var_list), _stmt(NULL)
{
  // Do nothing
}
 

CALFOutAnnotSpec::
~CALFOutAnnotSpec()
{
  delete _position;
  for(list<CALFOutAnnotSpecVar * >::iterator var = _var_list->begin();
      var != _var_list->end(); var++) {
    delete *var;
  }
  delete _var_list;
}

const CALFOutAnnotSpecPosition * 
CALFOutAnnotSpec::
Position() const
{
  return _position;
}

const list<CALFOutAnnotSpecVar *> * 
CALFOutAnnotSpec::
VarList() const
{
  return _var_list;
}

// To print the annotation
std::ostream & 
CALFOutAnnotSpec::
Print(std::ostream & o) const
{
  _position->Print(o);
  o << " ";
  for(list<CALFOutAnnotSpecVar * >::iterator var = _var_list->begin();
      var != _var_list->end(); /* intentionally empty */ ) {
    (*var)->Print(o);
    ++var;
    if(var != _var_list->end())
      o << " || ";
  }
  o << " ;";
  return o;
}

// -------------------------------------------------------
// Check if it is ok to add the annotation at the stmt entry or exit
// and set keys of frefs and lrefs referred to in vars and vals. Will
// also derive and store the right CFG node with the annotation.
// -------------------------------------------------------
bool 
CALFOutAnnotSpec::
CheckOkToAddAndSetKeysAndStmt(const alf::CAlfTuple *alf_tuple, ostringstream & error_msg) 
{
  bool is_ok = true;

  // Get the function name, the lrefid and the offset where the
  // assignment should be stored
  string func_name;
  string lrefid;
  unsigned int loffset;
  func_name = Position()->Func();
  lrefid = Position()->LRefId();
  loffset = (unsigned)Position()->LOffs();
  
  // To hold the scope of the function
  const alf::CScopeTuple * scope = NULL;
  const alf::CFuncTuple * function = NULL;
  
  // To hold the node in the CFG at which the statement CFG node
  // should be inserted before or after
  alf::AStmt * stmt = NULL;

  // Derive function with the given func_name
  bool func_with_func_name_exists = false;
  const alf::CFuncList * funcs = alf_tuple->GetFuncs();
  for(alf::CFuncList::const_list_iterator func = funcs->ConstIterator(); func != funcs->InvalidIterator(); func++) {
    // Check if the function have the wanted name
    if((*func)->Name() == func_name) {
      // Yes, remember the scope and function
      scope = (*func)->GetScope();
      function = (*func);
      // Remember that we found a function 
      func_with_func_name_exists = true;
      break;
    }
  }

  // Check if function existed
  if(!func_with_func_name_exists) {
     error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
              << "refers to non existing function:" << endl << func_name << endl;
    is_ok = false;
  }
  else {    
    
    // Get all the statements in the function
    std::vector<CGenericStmt*> stmts;
    function->GetStmtsInFunctionScopeAndSubordinateScopes(&stmts);

    // Check if a statement exists with the given label
    bool label_with_lrefid_and_loffset_exists = false;
    for(std::vector<CGenericStmt*>::iterator s = stmts.begin(); s != stmts.end(); s++) {
      alf::AStmt * alf_stmt = dynamic_cast<alf::AStmt *>(*s);
      
      // Get the lrefid and offset from the label
      alf::CLabelTuple * label = alf_stmt->GetLabel();
      alf::CLRefTuple * lref = label->GetLRef();
      alf::CIntNumValTuple * offset = label->GetOffset();
      mpz_class offset_as_bignum = offset->GetNumber()->GetValueAsBignum();

      // Convert the loffs to a bignum 
      mpz_class loffs_as_bignum(loffset);

      assert (loffs_as_bignum >= 0);

      // If the offset in the annotation is > 0 the statement is found within the basic block
      if ((loffs_as_bignum > 0) && (lref->GetId() == lrefid)) {
       // Step forward to the wanted statement
        alf::AStmt * next_alf_stmt = NULL;
        for (mpz_class i=0; i<loffs_as_bignum; i++) {
          s++;
          next_alf_stmt = dynamic_cast<alf::AStmt *>(*s);
          if (!next_alf_stmt->HasInternalGeneratedLabel()) {
            error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
            << "refers to a statement which has has an own label" << endl;
            is_ok = false;
          }
        }
        label_with_lrefid_and_loffset_exists = true;
        stmt = next_alf_stmt;
        break;
      }
      
      // If offset = 0 check if the id and offset are the same
      if (loffs_as_bignum == 0) {
        if((lref->GetId() == lrefid) && (offset_as_bignum == loffs_as_bignum)) {
          label_with_lrefid_and_loffset_exists = true;
          stmt = alf_stmt;
          break;
        }
      }

    }

    // Check if we found a statement with the given label in function
    if(!label_with_lrefid_and_loffset_exists) {
       error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
           << "refers to non existing <lref,offset> pair <" 
           << lrefid << "," << loffset << "> in given function." << endl;
      is_ok = false;
    }
    else {

      // Check that it is not an annotation after a call, return, jump or switch statement 
      if(Position()->IsType(CALFAbsAnnotPosition::STMT_EXIT) && 
        (stmt->IsType(alf::CGenericNode::TYPE_CALL_STMT_TUPLE) || 
         stmt->IsType(alf::CGenericNode::TYPE_RETURN_STMT_TUPLE))) {
         error_msg << "ERROR: abstract annotation: " << endl << (*this) << " is erroneous;" << endl
          << "it is not allowed to associate AFTER annotations to call or return stmts" << endl;
        is_ok = false;
      }
      
      // Get the scope in which the stmt is positioned. Scope
      // statements are positioned in their surrounding scopes.
      const alf::CScopeTuple * scope = NULL;
      if(stmt->IsType(alf::CGenericNode::TYPE_SCOPE_TUPLE))
        scope = dynamic_cast<const alf::CScopeTuple *>(stmt);
      else
        scope = dynamic_cast<const alf::CScopeTuple *>(stmt->GetParent(alf::CGenericNode::TYPE_SCOPE_TUPLE));
      assert(scope);

      // Loop through all var val pairs
      for(list<CALFOutAnnotSpecVar * >::iterator var = _var_list->begin();
          var != _var_list->end(); var++ ) {
        
        // ---------------------------------
        // Check if the var is a correct 
        // ---------------------------------
        {

          // Get the variable to store the value in
          string frefid = (*var)->FRefId();
          
          // Check if the frameid is declared in the current scope, in one of the current scope
          // ancestral scopes or in the global scope.
          Size frame_size = 0;
          unsigned int key;
          bool var_exists_in_decls = DeclaresFRefIdInCurrentOrParentScopesOrGlobalScopeOrImports(alf_tuple, scope, frefid, 
                                                                                                 &frame_size, &key);
          if(!var_exists_in_decls) {
            ostringstream s;
             s << "ERROR: abstract annotation: " << endl << (*this) << endl
                 << "refers to non existing frefid:" << endl << frefid << endl;
            throw runtime_error(s.str());
            is_ok = false;
          } 
          // If declared, check that we do not refer outside the frame border
          else if((*var)->HasFOffs() && 
                  ((*var)->FOffsInBits() + (*var)->SizeInBits()) > frame_size) { 
             error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
             << "the needed storage for variable '" << frefid << "' (" << ((*var)->FOffsInBits() + (*var)->SizeInBits()) << ") exceeds size allocated in declaration (" << frame_size << ")" << endl;
            is_ok = false;
          }
	  // Check that we want to store value on even LAUs
	  else if((*var)->HasFOffs() && 
		  LAU::BitsToLAURoundUp((*var)->FOffsInBits()) != LAU::BitsToLAURoundDown((*var)->FOffsInBits())) {
	    error_msg << "ERROR: start address to store value at in abstract annotation: " << endl
		      << (*this) << endl << "is not evenly dividable with LAU size " << endl;
	    is_ok = false;
	  }
          else {
            (*var)->SetKey(key);

            // Set foffs and size in bits if not set
            if(!(*var)->HasFOffs() && !(*var)->HasSizeInBits()) {
              (*var)->SetFOffsInBits(0);
              (*var)->SetSizeInBits(frame_size);
            }
          }
        } // end check var
    } // end else
  } // end else  
  }
  // ---------------------------------
  // Set statement of annot
  // ---------------------------------
  SetStmt(stmt);

  return is_ok;
}     

bool
CALFOutAnnotSpec::
DeclaresFRefIdInCurrentOrParentScopesOrGlobalScopeOrImports(const alf::CAlfTuple *alf_tuple, const alf::CScopeTuple* scope, 
                                                            std::string frefid, Size * frame_size, unsigned int * key)
{
  // Check if the current scope has declared the frame id
  if(HasFRefIdInDecls(scope->GetDecls(), frefid, frame_size, key)) {
    return true;
  }
  else {
    // Get the parent scope (if any) in the ast and check if it declares the frameid
    const alf::CGenericNode * parent_node = scope->GetParent(alf::CGenericNode::TYPE_SCOPE_TUPLE);
    if(parent_node != NULL) {
      return DeclaresFRefIdInCurrentOrParentScopesOrGlobalScopeOrImports(alf_tuple, dynamic_cast<const alf::CScopeTuple *>(parent_node), frefid, frame_size, key);
    }
    else {
    // Else, check the formal function arguments 
      const alf::CGenericNode * func_node = scope->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE);
      assert(func_node != NULL);
      const alf::CFuncTuple * func_tuple = dynamic_cast<const alf::CFuncTuple *>(func_node);
      if(HasFRefIdInArgDecls(func_tuple->GetArgs(), frefid, frame_size, key)) {
        return true;
      }
      else {
        // Check if declared in the global scope 
        if(HasFRefIdInDecls(alf_tuple->GetDecls(), frefid, frame_size, key)) {
          return true;
        }
        else {
          // Check if it is declared in the global imports 
          if(HasFRefIdInImports(alf_tuple->GetImports(), frefid, frame_size, key)) {
            return true;
            // ostringstream s;
            //             s << "ERROR: abstract annotation: " << endl << (*this) << endl
            //                  << "refers to variable declared in the imports section. This is currently" << endl
            //                  << "       not allows since these variables do not have any given size." << endl;
            //             throw runtime_error(s.str());
            //             return false;            
          }
          else {
            return false;
          }
        }
      }
    }
  }
}

bool 
CALFOutAnnotSpec::   
HasFRefIdInDecls(const alf::CDeclList * decls, std::string frefid, Size * frame_size, unsigned * key)
{
  // Loop through all declararations
  for(alf::CDeclList::const_list_iterator decl = decls->ConstIterator(); 
      decl != decls->InvalidIterator(); decl++) {
    if((*decl)->Name() == frefid) {
      // Reset the frame size
      *frame_size = (*decl)->GetFrameSize()->GetSizeInBits();
      // Get the global key
      assert((*decl)->HasKey());
      *key = (*decl)->GetKey();
      return true;
    }
  }
  return false;
}

bool 
CALFOutAnnotSpec::   
HasFRefIdInGlobalDeclsOrImports(const alf::CAlfTuple *ast,std::string frefid, Size * frame_size, unsigned * key)
{
  return HasFRefIdInDeclsOrImports(ast->GetDecls(), ast->GetImports(), frefid, frame_size, key);
}

bool 
CALFOutAnnotSpec::   
HasFRefIdInDeclsOrImports(const alf::CDeclList * decls, const alf::CImportsTuple* imports, std::string frefid, Size * frame_size, unsigned * key)
{
  bool has_frefid_in_decls = HasFRefIdInDecls(decls, frefid, frame_size, key);
  if(!has_frefid_in_decls) {
    return HasFRefIdInImports(imports, frefid, frame_size, key);
  }
  else {
    return true;
  }
}

bool 
CALFOutAnnotSpec::   
HasFRefIdInArgDecls(const alf::CArgDeclList * decls, std::string frefid, Size * frame_size, unsigned * key)
{
  // Loop through all declararations
  for(alf::CArgDeclList::const_list_iterator decl = decls->ConstIterator(); 
      decl != decls->InvalidIterator(); decl++) {
    if((*decl)->Name() == frefid) {
      // Reset the frame size
      *frame_size = (*decl)->GetFrameSize()->GetSizeInBits();
      // Get the global key
      assert((*decl)->HasKey());
      *key = (*decl)->GetKey();
      return true;
    }
  }
  return false;
}

bool 
CALFOutAnnotSpec::   
HasFRefIdInImports(const alf::CImportsTuple* imports, std::string frefid, Size * frame_size, unsigned * key)
{
  // Get the lists of imported frfs 
  const alf::CFRefList * frefs = imports->GetFRefList();
  // Loop through all imported frefs
  for(alf::CFRefList::const_list_iterator fref = frefs->ConstIterator(); 
      fref != frefs->InvalidIterator(); fref++) {
    if((*fref)->GetId() == frefid) {
      // Get the global key
      assert((*fref)->HasKey());
      *key = (*fref)->GetKey();
      // A imported fref has infinite size
      *frame_size = Size::Infinity();
      return true;
    }
  }
  return false;
}
 
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFOutAnnotSpecPosition
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFOutAnnotSpecPosition::
CALFOutAnnotSpecPosition(CALFAbsAnnotPosition::PositionType position_type, string func, string lrefid, uint64_t loffs)
: _position_type(position_type), _func(func), _lrefid(lrefid), _loffs(loffs)
{
  // Do nothing
}

CALFOutAnnotSpecPosition::
~CALFOutAnnotSpecPosition()
{
  // Do nothing
}

CALFAbsAnnotPosition::PositionType 
CALFOutAnnotSpecPosition::
Type() const
{
  return _position_type;
}

string 
CALFOutAnnotSpecPosition::
Func() const
{
  return _func;
}

string 
CALFOutAnnotSpecPosition::
LRefId() const
{
  return _lrefid;
}

uint64_t
CALFOutAnnotSpecPosition::
LOffs() const
{
  return _loffs;
}

// To check if two positions are equal
bool 
CALFOutAnnotSpecPosition::
IsEqual(const CALFOutAnnotSpecPosition * other) const
{
  if((Type() == other->Type()) && 
     (Func() == other->Func()) && 
     (LRefId() == other->LRefId()) &&
     (LOffs() == other->LOffs()))
    return true;
  else
    return false;
}

std::ostream & 
CALFOutAnnotSpecPosition::
Print(std::ostream & o) const
{
  if (_position_type == CALFAbsAnnotPosition::STMT_ENTRY) o << "STMT_ENTRY "; 
  else if (_position_type == CALFAbsAnnotPosition::STMT_EXIT) o << "STMT_EXIT ";
  else assert("Cannot come here" == 0);
  o << "\"" << _func << "\" \"" << _lrefid << "\" " << _loffs;
  return o;
}

CALFOutAnnotSpecPosition * 
CALFOutAnnotSpecPosition::
Copy() const
{
  return new CALFOutAnnotSpecPosition(_position_type, _func, _lrefid, _loffs);
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFOutAnnotSpecVar
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFOutAnnotSpecVar::
CALFOutAnnotSpecVar(string frefid)
  : _frefid(frefid), _has_foffs(false), _foffs_in_bits(0),
    _has_size_in_bits(false), _size_in_bits(0), 
    _key(0), _has_key(false)
{
  // Do nothing
}

CALFOutAnnotSpecVar::
CALFOutAnnotSpecVar(string frefid, uint64_t foffs)
  : _frefid(frefid), _has_foffs(true), _foffs_in_bits(foffs),
    _has_size_in_bits(false), _size_in_bits(0), 
    _key(0), _has_key(false)
{
    // Do nothing
}

CALFOutAnnotSpecVar::
CALFOutAnnotSpecVar(string frefid, uint64_t foffs, Size size_in_bits )
  : _frefid(frefid), _has_foffs(true), _foffs_in_bits(foffs),
    _has_size_in_bits(true), _size_in_bits(size_in_bits), 
    _key(0), _has_key(false)
{
  // Do nothing
}

void
CALFOutAnnotSpecVar::
SetFRefId(string s)
{
  _frefid = s;
}

string
CALFOutAnnotSpecVar::
FRefId() const
{
  return _frefid;
}

bool 
CALFOutAnnotSpecVar::
HasFOffs() const
{
  return _has_foffs;
}

uint64_t
CALFOutAnnotSpecVar::
FOffsInBits() const
{
  return _foffs_in_bits;
}

void
CALFOutAnnotSpecVar::
SetFOffsInBits(uint64_t foffs) 
{
  _has_foffs = true;
  _foffs_in_bits = foffs;
}

uint64_t
CALFOutAnnotSpecVar::
FOffsInLAU() const
{
   return LAU::BitsToLAU(_foffs_in_bits);
}

void
CALFOutAnnotSpecVar::
SetFOffsInLAU(uint64_t foffs)
{
   _has_foffs = true;
   _foffs_in_bits = LAU::LAUToBits(foffs);
}

bool 
CALFOutAnnotSpecVar::
HasSizeInBits() const
{
  return _has_size_in_bits;
}

Size
CALFOutAnnotSpecVar::
SizeInBits() const
{
  assert(_has_size_in_bits);
  return _size_in_bits;
}

void
CALFOutAnnotSpecVar::
SetSizeInBits(Size size_in_bits) 
{
  _has_size_in_bits = true;
  _size_in_bits = size_in_bits;
}

CALFOutAnnotSpecVar * 
CALFOutAnnotSpecVar::
Copy() const
{
  // Since there are no pointers in the class we can copy in using the
  // built in copy constructor which copies all the internal fields.
  return new CALFOutAnnotSpecVar(*this);
}

std::ostream & 
CALFOutAnnotSpecVar::
Print(std::ostream & o) const
{
  if(_has_size_in_bits  and _has_foffs)
    o << "\"" << _frefid << "\" " << _foffs_in_bits << " " << _size_in_bits;
  else if(_has_foffs) 
    o << "\"" << _frefid << "\" " << _foffs_in_bits;
  else
    o << "\"" << _frefid << "\"";
  return o;
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFOutAnnotSpecStorage
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFOutAnnotSpecStorage::
CALFOutAnnotSpecStorage(CALFOutAnnotSpecList * annot_list)
{  
  // Remember the list
  _annot_list = annot_list;
  // Loop through all annots and add them to the right data structures
  // (but not to the list)
  for(list<CALFOutAnnotSpec *>::iterator out_ann_spec = annot_list->begin(); 
      out_ann_spec != annot_list->end(); out_ann_spec++) {
    AddALFOutAnnotSpec(*out_ann_spec, false);
  }
}

CALFOutAnnotSpecStorage::
~CALFOutAnnotSpecStorage()
{
  // Delete the CALFOutAnnotSpecList list (which will delete all included annots)
  delete _annot_list;

  // Delete the node entry annots and the map
  map<alf::AStmt *, list<CALFOutAnnotSpec *> *>::iterator s2ea;
  for(map<const alf::AStmt *, list<CALFOutAnnotSpec *> *>::iterator s2ea = _stmt_to_entry_annots_map.begin();
      s2ea != _stmt_to_entry_annots_map.end(); s2ea++) {
    list<CALFOutAnnotSpec *> * annots = (*s2ea).second;
    // Since all annots are deleted when deleting the _annot_list we
    // only need to delete the list but not the annot
    delete annots;
  }
  
  // Delete the node exit annots and the map
  for(map<const alf::AStmt *, list<CALFOutAnnotSpec *> *>::iterator s2ea = _stmt_to_exit_annots_map.begin();
      s2ea != _stmt_to_exit_annots_map.end(); s2ea++) {
    list<CALFOutAnnotSpec *> * annots = (*s2ea).second;
    // Since all annots are deleted when deleting the _annot_list we
    // only need to delete the list but not the annot
    delete annots;
  }
}

void
CALFOutAnnotSpecStorage::
AddALFOutAnnotSpec(CALFOutAnnotSpec * annot)
{
  // Add the annot to the datastructures and to the list
  AddALFOutAnnotSpec(annot, true);
}

void
CALFOutAnnotSpecStorage::
AddALFOutAnnotSpec(CALFOutAnnotSpec * out_ann_spec, bool add_to_list)
{
  // ---------------------------------
  // Add to list if needed
  // ---------------------------------
  if(add_to_list) {
    _annot_list->push_back(out_ann_spec);
  }
  
  // ---------------------------------
  // Entry Stmt annotation
  // ---------------------------------
  else if(out_ann_spec->Position()->IsType(CALFAbsAnnotPosition::STMT_ENTRY)) {
    const alf::AStmt* stmt = out_ann_spec->GetStmt();
    assert(stmt);    
    if(_stmt_to_entry_annots_map.find(stmt) == _stmt_to_entry_annots_map.end()) {
      // No annot list existed for node, create one and add node
      _stmt_to_entry_annots_map[stmt] = new list<CALFOutAnnotSpec *>();
      _stmt_to_entry_annots_map[stmt]->push_back(out_ann_spec);
    }
    else {
      // Annot list existed for node, make sure that annot is processed last
      _stmt_to_entry_annots_map[stmt]->push_back(out_ann_spec);
    }
  }

  // ---------------------------------
  // Exit Stmt annotation
  // ---------------------------------
  else if(out_ann_spec->Position()->IsType(CALFAbsAnnotPosition::STMT_EXIT)) {
    const alf::AStmt* stmt = out_ann_spec->GetStmt();
    assert(stmt);
    assert(_stmt_to_exit_annots_map.find(stmt) == _stmt_to_exit_annots_map.end());
    // Add list for node to exit map
    _stmt_to_exit_annots_map[stmt] = new list<CALFOutAnnotSpec *>();
    _stmt_to_exit_annots_map[stmt]->push_back(out_ann_spec);
  }
  else { 
    assert(0);
  }
}

// ---------------------------------
// Stmt or node entry
// ---------------------------------

bool 
CALFOutAnnotSpecStorage::
HasStmtEntryALFOutAnnotSpec(alf::AStmt * stmt) const
{
  return (_stmt_to_entry_annots_map.find(stmt) != _stmt_to_entry_annots_map.end());
}

list<CALFOutAnnotSpec *> * 
CALFOutAnnotSpecStorage::
GetStmtEntryALFOutAnnotSpec(alf::AStmt * stmt) 
{
  if(_stmt_to_entry_annots_map.find(stmt) != _stmt_to_entry_annots_map.end())
    return _stmt_to_entry_annots_map[stmt];
  else
    return NULL;
}

bool
CALFOutAnnotSpecStorage::
HasNodeEntryALFOutAnnotSpec(CFlowGraphNode * node) const
{
  alf::AStmt * stmt = dynamic_cast<alf::AStmt *>(node->Stmt());
  return HasStmtEntryALFOutAnnotSpec(stmt);
}

list<CALFOutAnnotSpec *> * 
CALFOutAnnotSpecStorage::
GetNodeEntryALFOutAnnotSpec(CFlowGraphNode * node) 
{
  alf::AStmt * stmt =  dynamic_cast<alf::AStmt *>(node->Stmt());
  return GetStmtEntryALFOutAnnotSpec(stmt);
}

bool 
CALFOutAnnotSpecStorage::
HasNodeEntryALFOutAnnotSpec(CECFGNode * node) const
{
  return HasNodeEntryALFOutAnnotSpec(node->GetFlowGraphNode());
}

list<CALFOutAnnotSpec *> *  
CALFOutAnnotSpecStorage::
GetNodeEntryALFOutAnnotSpec(CECFGNode * node)
{
  return GetNodeEntryALFOutAnnotSpec(node->GetFlowGraphNode());
}

// ---------------------------------
// Stmt or node exit
// ---------------------------------

bool 
CALFOutAnnotSpecStorage::
HasStmtExitALFOutAnnotSpec(alf::AStmt * stmt) const
{
  return (_stmt_to_exit_annots_map.find(stmt) != _stmt_to_exit_annots_map.end());
}

list<CALFOutAnnotSpec *> * 
CALFOutAnnotSpecStorage::
GetStmtExitALFOutAnnotSpec(alf::AStmt * stmt) 
{
  if(_stmt_to_exit_annots_map.find(stmt) != _stmt_to_exit_annots_map.end())
    return _stmt_to_exit_annots_map[stmt];
  else
    return NULL;
}

bool 
CALFOutAnnotSpecStorage::
HasNodeExitALFOutAnnotSpec(CFlowGraphNode * node) const
{
  alf::AStmt * stmt =  dynamic_cast<alf::AStmt *>(node->Stmt());
  return HasStmtExitALFOutAnnotSpec(stmt);
}

list<CALFOutAnnotSpec *> * 
CALFOutAnnotSpecStorage::
GetNodeExitALFOutAnnotSpec(CFlowGraphNode * node) 
{
  alf::AStmt * stmt =  dynamic_cast<alf::AStmt *>(node->Stmt());
  return GetStmtExitALFOutAnnotSpec(stmt);
}

bool 
CALFOutAnnotSpecStorage::
HasNodeExitALFOutAnnotSpec(CECFGNode * node) const
{
  return HasNodeExitALFOutAnnotSpec(node->GetFlowGraphNode());
}

list<CALFOutAnnotSpec *> *  
CALFOutAnnotSpecStorage::
GetNodeExitALFOutAnnotSpec(CECFGNode * node)
{
  return GetNodeExitALFOutAnnotSpec(node->GetFlowGraphNode());
}

const CALFOutAnnotSpecList * 
CALFOutAnnotSpecStorage::
GetOutAnnotSpecList() const
{
  return _annot_list;
}

// To print all the annotations
std::ostream & 
CALFOutAnnotSpecStorage::
Print(std::ostream & o) const
{

  // Print node entry annots if any (includes the func entry annots)
  if(_stmt_to_entry_annots_map.size() > 0) {
    o << "  STMT ENTRY ANNOTS: " << endl; 
    for(map<const alf::AStmt *, list<CALFOutAnnotSpec *> *>::const_iterator s2ea = _stmt_to_entry_annots_map.begin();
        s2ea != _stmt_to_entry_annots_map.end(); s2ea++) {
      const alf::AStmt * stmt = (*s2ea).first;
      list<CALFOutAnnotSpec *> * annots = (*s2ea).second;
      o << "    " << stmt->Name() << ": " << endl;
      for(list<CALFOutAnnotSpec *>::const_iterator annot = annots->begin(); annot != annots->end(); annot++) {
        o << "       " << *(*annot) << endl;
      }
    }
  }

  // Print node exit annots if any (includes the func entry annots)
  if(_stmt_to_exit_annots_map.size() > 0) {
    o << "  STMT EXIT ANNOTS: " << endl; 
    for(map<const alf::AStmt *, list<CALFOutAnnotSpec *> *>::const_iterator s2ea = _stmt_to_exit_annots_map.begin();
        s2ea != _stmt_to_exit_annots_map.end(); s2ea++) {
      const alf::AStmt * stmt = (*s2ea).first;
      list<CALFOutAnnotSpec *> * annots = (*s2ea).second;
      o << "    " << stmt->Name() << ": " << endl;
      for(list<CALFOutAnnotSpec *>::const_iterator annot = annots->begin(); annot != annots->end(); annot++) {
        o << "       " << *(*annot) << endl;
      }
    }
  }

  return o;
}
