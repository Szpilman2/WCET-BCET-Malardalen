#include "absann/CALFAbsAnnot.h"
#include "globals.h"
#include "parsers/absann_ALF/absann_ALF.h"
#include "program/alf/CGenericNode.h"
#include "program/alf/CDeclList.h"
#include "program/alf/CFuncTuple.h"
#include "program/alf/CFuncList.h"
#include "program/alf/CStmtList.h"
#include "program/alf/CLRefTuple.h"
#include "program/alf/CLabelTuple.h"
#include "program/alf/CAllocTuple.h"
#include "program/alf/CIntNumValTuple.h"
#include "program/alf/CNumber.h"
#include "program/alf/CSize.h"
#include "program/alf/AStmt.h"
#include "program/alf/CImportsTuple.h"
#include "program/alf/CFRefList.h"
#include "program/alf/CLRefList.h"
#include "program/alf/CFRefTuple.h"
#include "program/alf/CLRefTuple.h"
#include "program/alf/CFuncTuple.h"
#include "program_state/LAU.h"
#include <ciso646>
#include <gmpxx.h>
#include <stdexcept>

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// Class to read annotations and add them as abs stmts to cfg
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CReadALFAbsAnnotsAndCreateALFAbsAnnotStorage::
CReadALFAbsAnnotsAndCreateALFAbsAnnotStorage()
{
}

CReadALFAbsAnnotsAndCreateALFAbsAnnotStorage::
~CReadALFAbsAnnotsAndCreateALFAbsAnnotStorage()
{
}

CALFAbsAnnotStorage *
CReadALFAbsAnnotsAndCreateALFAbsAnnotStorage::
Run(string filename, const alf::CAlfTuple * alf_tuple)
{
  cout << "Parsing abstract annotations file '" << filename << "'.\n";
  // Parse annotations
  CALFAbsAnnotList * abs_annot_list;
  bool read_ok = ReadAnnotsFromFile(filename, &abs_annot_list);
  if(!read_ok) return NULL;
  // Check that annotations are ok
  bool check_ok = CheckAnnotsAndSetKeys(abs_annot_list, alf_tuple);
  if(!check_ok) return NULL;
  // Create the storage to be returned and add annots
  CALFAbsAnnotStorage * aus = new CALFAbsAnnotStorage(abs_annot_list);
  return aus;
}

// Returns false if error
bool
CReadALFAbsAnnotsAndCreateALFAbsAnnotStorage::
ReadAnnotsFromFile(string filename, CALFAbsAnnotList ** abs_annot_list)
{
   // Open the file and set global file identifier exported by parser
   // (as given in file absann.l.cpp)
   extern FILE * absann_ALF_in;
   bool success = false;
   absann_ALF_in = fopen(filename.c_str(), "rt");

   if (absann_ALF_in) {
      int parse_error = absann_ALF_parse(abs_annot_list);
      success = parse_error == 0;
      fclose(absann_ALF_in);
      absann_ALF_lex_destroy();
   }
   return success;
}

// To check that all annotations are semantically correct. Returns
// false and throws an error message if an error occurred.
bool 
CReadALFAbsAnnotsAndCreateALFAbsAnnotStorage::
CheckAnnotsAndSetKeys(CALFAbsAnnotList * abs_annot_list, const alf::CAlfTuple * alf_tuple) 
{
  ostringstream error_msg;
  bool annots_ok = true;

  // Check that annotations do not overlap wrongly. I.e. that two
  // annots not are located in the same position, that an updated fref
  // not have overlapping updates, or (parts of) the same fref not is
  // referred by the same annot
  annots_ok &= CheckOverlappingAnnots(abs_annot_list, error_msg);
    
  // Check that each annotation refers to valid labels, that variables
  // referred are accessible in the given scope, that they not go
  // outside the size of the corresponding frames.
  annots_ok &= CheckOkToAddAndSetKeysAndStmt(abs_annot_list, alf_tuple, error_msg);

  if(!annots_ok)
    throw runtime_error(error_msg.str());

  return annots_ok;
}


// Check that annotations do not overlap wrongly. I.e. that two
// annots not are located in the same position, that an updated fref
// not have overlapping updates, or (parts of) the same fref not is
// referred by the same annot                                        
bool 
CReadALFAbsAnnotsAndCreateALFAbsAnnotStorage::
CheckOverlappingAnnots(CALFAbsAnnotList * abs_annot_list, ostringstream & error_msg)
{
  bool has_equal_positions = false;
  { // Check that there are not any annotations with equal positions 
    for(list<CALFAbsAnnot *>::iterator absann1 = abs_annot_list->begin(); 
        absann1 != abs_annot_list->end(); absann1++) {
      // Skip checking VOLATILE annots
      if((*absann1)->Position()->IsType(CALFAbsAnnotPosition::VOLATILE))
        continue;
      list<CALFAbsAnnot *>::iterator absann2 = absann1;
      for(absann2++; absann2 != abs_annot_list->end(); absann2++) {
        if((*absann1)->Position()->IsEqual((*absann2)->Position())) {
           error_msg << "ERROR: abstract annotation: " << endl << (**absann1) << endl 
                    << "and abstract annotation: " << endl << (**absann2) 
                    << endl << "have the same program position. Merge them into a parallel update with the || operator." << endl;
          has_equal_positions = true;
        }
      }
    }
  }

  bool has_overlapping_var_stores = false;
  { // Check that no annotation has overlapping variable stores 
    for(list<CALFAbsAnnot *>::iterator absann = abs_annot_list->begin(); absann != abs_annot_list->end(); absann++) {
      const list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > * var_vals_list = (*absann)->VarValsList();
      for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::const_iterator var_vals1 = var_vals_list->begin();
          var_vals1 != var_vals_list->end(); var_vals1++) {
        list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::const_iterator var_vals2 = var_vals1;
        for(var_vals2++; var_vals2 != var_vals_list->end(); var_vals2++) {
          const CALFAbsAnnotVar * var1 = (*var_vals1).first;
          const CALFAbsAnnotVar * var2 = (*var_vals2).first;
          if(var1->Overlaps(var2)) {
             error_msg << "ERROR: abstract annotation: " << endl << (**absann) << endl
                      << "has overlapping variable stores "
                      << (*var1) << " and " << (*var2) << endl;
            has_overlapping_var_stores = true;
          }
        }
      }
    }
  }

  bool has_overlapping_var_stores_with_volatiles = false;
  { // Check that no annotations have overlappings variable stores with
    // volatile annotations
    for(list<CALFAbsAnnot *>::iterator absann1 = abs_annot_list->begin(); absann1 != abs_annot_list->end(); absann1++) {
      list<CALFAbsAnnot *>::iterator absann2 = absann1;
      for(absann2++; absann2 != abs_annot_list->end(); absann2++) {
        // At least one of the annotations must be a volatile
        // annotation to continue the check
        if(!((*absann1)->Position()->IsType(CALFAbsAnnotPosition::VOLATILE) ||
             (*absann2)->Position()->IsType(CALFAbsAnnotPosition::VOLATILE)))
          continue;
        // Loop through the variable of the first annotation
        const list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > * var_vals_list1 = (*absann1)->VarValsList();
        for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::const_iterator var_vals1 = var_vals_list1->begin();
            var_vals1 != var_vals_list1->end(); var_vals1++) {
          // Loop through the variable of the second annotation
          const list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > * var_vals_list2 = (*absann2)->VarValsList();
          for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::const_iterator var_vals2 = var_vals_list2->begin();
              var_vals2 != var_vals_list2->end(); var_vals2++) {
            const CALFAbsAnnotVar * var1 = (*var_vals1).first;
            const CALFAbsAnnotVar * var2 = (*var_vals2).first;
            if(var1->Overlaps(var2)) {
              error_msg << "ERROR: abstract annotations: " << endl << (**absann1) << " and " 
                        << endl << (**absann2) << endl
                        << "have overlapping variable stores " << (*var1) << " and " << (*var2) 
                        << ". Not allowed for volatile annotations." << endl;
              has_overlapping_var_stores_with_volatiles = true;
            }
          }
        }
      }
    }
  }

  // Return true if all annots were ok 
  bool annots_ok_to_add = !has_overlapping_var_stores && 
    !has_equal_positions && !has_overlapping_var_stores_with_volatiles;
  return annots_ok_to_add;
}


// Loop through all abs annots and call their corresponding check function.
// Returns true if all annots were ok to add.
bool 
CReadALFAbsAnnotsAndCreateALFAbsAnnotStorage::
CheckOkToAddAndSetKeysAndStmt(CALFAbsAnnotList * abs_annot_list, const alf::CAlfTuple * alf_tuple, 
                              ostringstream & error_msg)
{
  bool annots_ok = true;
  for(list<CALFAbsAnnot *>::iterator absann = abs_annot_list->begin(); 
      absann != abs_annot_list->end(); absann++) {
    if((*absann)->CheckOkToAddAndSetKeysAndStmt(alf_tuple, error_msg) == false) {
      annots_ok = false;
    }
  }
  return annots_ok;
}
 
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotList
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

// To create a list of abstract annotations
CALFAbsAnnotList ::
CALFAbsAnnotList()
{
  // Do nothing
}

// To delete a list of abstract annotations
CALFAbsAnnotList::
~CALFAbsAnnotList()
{
  // Delete all members in the list
  for(list<CALFAbsAnnot *>::iterator absann = begin(); absann != end(); absann++)
    delete *absann;
}

// To print all the abstract annotation assignments
std::ostream & 
CALFAbsAnnotList::
Print(std::ostream & o) const
{
  int annot_nr = 1;
  for(list<CALFAbsAnnot *>::const_iterator absann = begin(); absann != end(); absann++) {
    (*absann)->Print(o);
    o << endl;
    annot_nr++;
  }
  return o;
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnot
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnot::
CALFAbsAnnot(CALFAbsAnnotPosition * position,
             CALFAbsAnnot::UpdateType update_type,
             list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > * var_vals_list)
  : _position(position), _update_type(update_type), _var_vals_list(var_vals_list), _stmt(NULL)
{
  // Do nothing
}
 

CALFAbsAnnot::
~CALFAbsAnnot()
{
  delete _position;
  for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::iterator var_vals = _var_vals_list->begin();
    var_vals != _var_vals_list->end(); var_vals++) {
    delete (*var_vals).first;    
    for(list<CALFAbsAnnotVal *>::iterator val = (*var_vals).second->begin();
        val != (*var_vals).second->end(); val++) {    
      delete *val;
    }
    delete (*var_vals).second;
  }
  delete _var_vals_list;
}


const CALFAbsAnnotPosition * 
CALFAbsAnnot::
Position() const
{
  return _position;
}

CALFAbsAnnot::UpdateType
CALFAbsAnnot::
Type() const
{
  return _update_type;
}

const list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > * 
CALFAbsAnnot::
VarValsList() const
{
  return _var_vals_list;
}

list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > * 
CALFAbsAnnot::
GetModifyableVarValsList()
{
   return _var_vals_list;
}

// To print the annotation
std::ostream & 
CALFAbsAnnot::
Print(std::ostream & o) const
{
  _position->Print(o);
  if(_update_type == ASSIGN) o << " ASSIGN ";
  else if(_update_type == GLB) o << " GLB ";
  else if(_update_type == LUB) o << " LUB "; 
  for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::iterator var_vals = _var_vals_list->begin();
      var_vals != _var_vals_list->end(); /* intentionally empty */ ) {
    CALFAbsAnnotVar * var = (*var_vals).first;
    list<CALFAbsAnnotVal *> * val_list = (*var_vals).second;
    var->Print(o);
    o << " ";
    for(list<CALFAbsAnnotVal *>::iterator val = val_list->begin();
        val != val_list->end(); /* intentionally empty */ ) {
      (*val)->Print(o);
      ++val;
      if(val != val_list->end())
        o << " OR ";
    }
    ++var_vals;
    if(var_vals != _var_vals_list->end())
      o << " || ";
  }
  o << " ;";

/*
  // *** To be removed, just for debugging ***
  bool print_def_address_pairs = false;
  if(print_def_address_pairs) {
    o << " // def addresses pairs: ";
    set<pair<int,set<int> > > def_addresses_pairs;
    GetDefAddressesPairs(&def_addresses_pairs);
    for(set<pair<int,set<int> > >::iterator def_addresses_pair = def_addresses_pairs.begin();
        def_addresses_pair != def_addresses_pairs.end(); def_addresses_pair++) {
      o << (*def_addresses_pair).first << " -> { ";
      set<int> addresses = (*def_addresses_pair).second;
      for(set<int>::iterator address = addresses.begin(); address != addresses.end(); address++)
        o << (*address) << " ";
      o << "} ";
    }
  }
*/
  return o;
}


// Check if it is ok to add the annotation to the ALF program
bool 
CALFAbsAnnot::
CheckOkToAddAndSetKeysAndStmt(const alf::CAlfTuple *alf_tuple, ostringstream & error_msg)
{
  if(Position()->IsType(CALFAbsAnnotPosition::PROG_ENTRY)) {
    return CheckOkToAddAtProgEntryAndSetKeysAndStmt(alf_tuple, error_msg);
  }
  else if(Position()->IsType(CALFAbsAnnotPosition::FUNC_ENTRY)) {
    return CheckOkToAddAtFuncEntryAndSetKeysAndStmt(alf_tuple, error_msg);
  }
  else if (Position()->IsType(CALFAbsAnnotPosition::STMT_ENTRY) || 
           Position()->IsType(CALFAbsAnnotPosition::STMT_EXIT)) {
    return CheckOkToAddAtStmtEntryOrStmtExitAndSetKeysAndStmt(alf_tuple, error_msg);
  }
  else if(Position()->IsType(CALFAbsAnnotPosition::VOLATILE)) {
    return CheckOkToAddVolatileAndSetKeys(alf_tuple, error_msg);
  }
  else {
    assert(Position()->IsType(CALFAbsAnnotPosition::WHEN_CALLED)); 
    return CheckOkToAddWhenCalledAndSetKeys(alf_tuple, error_msg);
  }
}

void 
CALFAbsAnnot::
GetDefAddressesPairs(set<pair<int,set<int> > > * def_addresses_pairs) const
{
  // Loop through all var val pairs
  for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::iterator var_vals = _var_vals_list->begin();
      var_vals != _var_vals_list->end(); var_vals++ ) {
    // Extract the def and addresses keys and store pair in set
    CALFAbsAnnotVar * var = (*var_vals).first; 
    int def = var->GetKey();
    for(list<CALFAbsAnnotVal *>::iterator val = (*var_vals).second->begin();
        val != (*var_vals).second->end(); val++ ) {  
      set<int> addresses;
      (*val)->GetKeys(&addresses);
      def_addresses_pairs->insert(make_pair(def, addresses));
    }
  }
}

void 
CALFAbsAnnot::
GetDefs(set<int> * defs) const
{
  // Loop through all var val pairs
  for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::iterator var_vals = _var_vals_list->begin();
      var_vals != _var_vals_list->end(); var_vals++ ) {
    // Extract the def key and store in set
    CALFAbsAnnotVar * var = (*var_vals).first; 
    defs->insert(var->GetKey());
  }
}

void 
CALFAbsAnnot::
GetAddresses(set<int> * addresses) const
{
  // Loop through all var val pairs
  for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::iterator var_vals = _var_vals_list->begin();
      var_vals != _var_vals_list->end(); var_vals++ ) {
    for(list<CALFAbsAnnotVal *>::iterator val = (*var_vals).second->begin();
        val != (*var_vals).second->end(); val++ ) {  
      // Extract the used keys and store in set
      (*val)->GetKeys(addresses);
    }
  }
}

void 
CALFAbsAnnot::
GetDefsAndAddresses(set<int> * defs_and_addresses) const
{
  // Loop through all var val pairs
  for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::iterator var_vals = _var_vals_list->begin();
      var_vals != _var_vals_list->end(); var_vals++ ) {
    // Extract the def and addresses keys and store in set
    CALFAbsAnnotVar * var = (*var_vals).first;
    defs_and_addresses->insert(var->GetKey());
    for(list<CALFAbsAnnotVal *>::iterator val = (*var_vals).second->begin();
        val != (*var_vals).second->end(); val++ ) {
      (*val)->GetKeys(defs_and_addresses);
    }
  }
}


// ------------------------------------------------------- 
// Check if it is ok to add the annotation at the program entry and 
// set keys of frefs and lrefs referred to in vars and vals. 
// ------------------------------------------------------- 
bool 
CALFAbsAnnot::
CheckOkToAddAtProgEntryAndSetKeysAndStmt(const alf::CAlfTuple *alf_tuple, ostringstream & error_msg) 
{
  bool is_ok = true;

  // Loop through all var val pairs
  for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::iterator var_vals = _var_vals_list->begin();
      var_vals != _var_vals_list->end(); var_vals++ ) {
    
    // ---------------------------------
    // Check that the var is correct
    // ---------------------------------
    { 
      // Get the variable to store the value in
      CALFAbsAnnotVar * var = (*var_vals).first;
      string frefid = var->FRefId();
      
      // To hold if variable has been declared and its size is >=
      // size needed by annot
      bool var_exists_in_glob_decls = true;

      // Check if the frameid is declared in the global scope
      Size frame_size = 0;
      unsigned key = 0;
      var_exists_in_glob_decls = HasFRefIdInGlobalDeclsOrImports(alf_tuple, frefid, &frame_size, &key);
      if(!var_exists_in_glob_decls) {

        // Check if the variable id exists in imports section (then it has no size)
        // bool var_exists_in_imports = HasFRefIdInImports(alf_tuple->GetImports(), frefid, &key);

        // if(!var_exists_in_imports) {
         error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                  << "refers to non existing global frefid:" << endl << frefid << endl;
        is_ok = false;
      }
      
      // Given in a global decl. Check that we do not try to store
      // something outside the frame border
      else if(var->HasFOffs() && 
              (var->FOffsInBits() + (var->SizeInBits() * var->Repeat()) - 1) > frame_size) { 
         error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                  << "needs storage exeeding size allocated in global declaration " << endl;
        is_ok = false;
      }
      // Check that we want to store value on even LAUs
      else if(var->HasFOffs() &&
	      LAU::BitsToLAURoundUp(var->FOffsInBits()) != LAU::BitsToLAURoundDown(var->FOffsInBits())) {
          error_msg << "ERROR: start address to store value at in abstract annotation: " << endl 
                    << (*this) << endl << "is not evenly dividable with LAU size " << endl;
        is_ok = false;
      }
      else {
        // Set key of var
        var->SetKey(key);
      }

    } // end check var ok

    // ---------------------------------
    // Check if the val is correct 
    // ---------------------------------
    {
    for(list<CALFAbsAnnotVal *>::iterator val = (*var_vals).second->begin();
        val != (*var_vals).second->end(); val++ ) {
      {
        // Check if the val is a top value
        if((*val)->IsTOP() or (*val)->IsTOP_INT() or (*val)->IsTOP_FLOAT() or (*val)->IsTOP_ADDRESS() or (*val)->IsTOP_LABEL()) {
          // Do nothing
        }

        // Check if the val is a fref 
        else if((*val)->IsType(CALFAbsAnnotVal::ADDRESS)) {
          CALFAbsAnnotValAddress * fval = dynamic_cast<CALFAbsAnnotValAddress *>((*val));
          // Go through all frefid offs pairs
          const list<CFRefIdOffsetPair *> * frefid_offs_list =  fval->FRefIdOffsetPairList(); 
          for(list<CFRefIdOffsetPair *>::const_iterator fop = frefid_offs_list->begin();
              fop != frefid_offs_list->end(); fop++) {
            Size frame_size = 0;
            unsigned key = 0;
            string frefid = (*fop)->FRefId();
            bool var_exists_in_glob_decls = HasFRefIdInGlobalDeclsOrImports(alf_tuple, frefid, &frame_size, &key);
            if(!var_exists_in_glob_decls) {
               error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                         << "refers to non existing global frefid:" << endl << frefid << endl;
              is_ok = false;
            }
            else {
              (*fop)->SetKey(key);
            }
          } 
        }

        // Check if the val is a lref 
        else if((*val)->IsType(CALFAbsAnnotVal::LABEL)) {        
          CALFAbsAnnotValLabel * lval = dynamic_cast<CALFAbsAnnotValLabel *>((*val));
          // Go through all lrefid offs pairs
          const list<CLRefIdOffsetPair *> * lrefid_offs_list = lval->LRefIdOffsetPairList();
          for(list<CLRefIdOffsetPair *>::const_iterator lop = lrefid_offs_list->begin();
              lop != lrefid_offs_list->end(); lop++) {
            unsigned int key = 0;
            string lrefid = (*lop)->LRefId();
            int64_t offset = (*lop)->Offset();
            bool stmt_exists_in_program = HasLRefIdInStmts(alf_tuple, lrefid, (unsigned)offset, &key);
            if(!stmt_exists_in_program) {
              cout << "ERROR: abstract annotation: " << endl << (*this) << endl
                   << "refers to non existing label:" << endl << lrefid << " " << offset << endl;
              is_ok = false;
            }
            else {
              (*lop)->SetKey(key);                        
            }
          } 
        }
        else {
          assert((*val)->IsType(CALFAbsAnnotVal::INT) || (*val)->IsType(CALFAbsAnnotVal::FLOAT));
        }
      } // end check val ok
    } // end forall vals
    } 
  }// end forall var val pairs

  // ---------------------------------
  // Set stmt
  // ---------------------------------
  // The annotation has no statement
  SetStmt(NULL);
  
  return is_ok;
}

// -------------------------------------------------------
// Check if it is ok to add the annotation at the function entry and 
// set keys of frefs and lrefs referred to in vars and vals. Will
// also derive and store the right CFG node with the annotation.
// ------------------------------------------------------- 
bool 
CALFAbsAnnot::
CheckOkToAddAtFuncEntryAndSetKeysAndStmt(const alf::CAlfTuple *alf_tuple, ostringstream & error_msg) 
{
  bool is_ok = true;
  
  // Get the function name where the assignment should be stored
  string func_name = (dynamic_cast<const CALFAbsAnnotPositionFuncEntry *>(Position()))->Func();
  
  // To hold the scope of the function
  const alf::CScopeTuple * scope = NULL;
  
  // Derive function with the given func_name
  bool func_with_func_name_exists = false;
  const alf::CFuncList * funcs = alf_tuple->GetFuncs();
  for(alf::CFuncList::const_list_iterator func = funcs->ConstIterator(); func != funcs->InvalidIterator(); func++) {
    // Check if the function have the wanted name
    if((*func)->Name() == func_name) {
      // Yes, remember the scope
      scope = (*func)->GetScope();
      // Remember that we found a function 
      func_with_func_name_exists = true;
      break;
    }
  }
      
  // Check if function exists
  if(!func_with_func_name_exists) {
     error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
              << "refers to non existing function:" << endl << func_name << endl;
    is_ok = false;
  }
  else {        

    // Found func and scope
    // Loop through all var val pairs
    for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::iterator var_vals = _var_vals_list->begin();
        var_vals != _var_vals_list->end(); var_vals++ ) {
      
      // ---------------------------------
      // Check if the var is correct 
      // ---------------------------------
      {
        // Get the variable to store the value in

        CALFAbsAnnotVar * var = (*var_vals).first; 
        string frefid = var->FRefId();
        // Check if the frameid is declared in function or global scope
        Size frame_size = 0;
        unsigned int key;
        bool var_exists_in_decls = 
          DeclaresFRefIdInCurrentOrParentScopesOrGlobalScopeOrImports(alf_tuple, scope, frefid, &frame_size, &key);
        if(!var_exists_in_decls) {
           error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
               << "refers to non existing frefid:" << endl << frefid << endl;

          cout << "----------------------------" << endl;
          
          is_ok = false;
        } 
        // If declared, check that we do not refer outside the frame border
        else if(var->HasFOffs() && 
                (var->FOffsInBits() + (var->SizeInBits() * var->Repeat()) - 1) > frame_size) { 
           error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
               << "needs storage exeeding size allocated in declaration " << endl;
          is_ok = false;
        }
	// Check that we want to store value on even LAUs
	else if(var->HasFOffs() &&
		LAU::BitsToLAURoundUp(var->FOffsInBits()) != LAU::BitsToLAURoundDown(var->FOffsInBits())) {
	  error_msg << "ERROR: start address to store value at in abstract annotation: " << endl 
		    << (*this) << endl << "is not evenly dividable with LAU size " << endl;
	  is_ok = false;
	}
        else {
          // Set key of var
          var->SetKey(key);
        }
      } // end check var
      
      // ---------------------------------
      // Check if the val is correct 
      // ---------------------------------
      {
      for(list<CALFAbsAnnotVal *>::iterator val = (*var_vals).second->begin();
          val != (*var_vals).second->end(); val++ ) {  
        
        // Check if the val is a top value
        if((*val)->IsTOP() or (*val)->IsTOP_INT() or (*val)->IsTOP_FLOAT() or (*val)->IsTOP_ADDRESS() or (*val)->IsTOP_LABEL()) {
          // Do nothing
        }

        // Check if the val is a fref 
        else if((*val)->IsType(CALFAbsAnnotVal::ADDRESS)) {
          CALFAbsAnnotValAddress * fval = dynamic_cast<CALFAbsAnnotValAddress *>((*val));
          // Go through all frefid offs pairs and check that each frefid,offset is ok
          const list<CFRefIdOffsetPair *> * frefid_offs_list = fval->FRefIdOffsetPairList(); 
          for(list<CFRefIdOffsetPair *>::const_iterator fop = frefid_offs_list->begin();
              fop != frefid_offs_list->end(); fop++) {
            Size frame_size = 0;
            unsigned int key = 0;
            string frefid = (*fop)->FRefId();
            bool var_exists_in_decls = 
              DeclaresFRefIdInCurrentOrParentScopesOrGlobalScopeOrImports(alf_tuple, scope, frefid, &frame_size, &key);
            if(!var_exists_in_decls) {
               error_msg<< "ERROR: abstract annotation: " << endl << (*this) << endl
                   << "refers to non existing frefid:" << endl << frefid << endl;
              is_ok = false;
            }
            else {
              (*fop)->SetKey(key);
            }
          } 
        }

        // Check if the val is a lref 
        else if((*val)->IsType(CALFAbsAnnotVal::LABEL)) {
          CALFAbsAnnotValLabel * lval = dynamic_cast<CALFAbsAnnotValLabel *>((*val));
          // Go through all lrefid offs pairs and check that each lrefid,offset is ok
          const list<CLRefIdOffsetPair *> * lrefid_offs_list = lval->LRefIdOffsetPairList(); 
          for(list<CLRefIdOffsetPair *>::const_iterator lop = lrefid_offs_list->begin();
              lop != lrefid_offs_list->end(); lop++) {
            unsigned int key = 0;
            string lrefid = (*lop)->LRefId();
            int64_t offset = (*lop)->Offset();
            bool stmt_exits_in_program = HasLRefIdInStmts(alf_tuple, lrefid, (unsigned)offset, &key);
            if(!stmt_exits_in_program) {
               error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                   << "refers to non existing label:" << endl << lrefid << " " << offset << endl;
              is_ok = false;
            }
            else {
              (*lop)->SetKey(key);
            }
          } 
        }

        else {
          assert((*val)->IsType(CALFAbsAnnotVal::INT) || (*val)->IsType(CALFAbsAnnotVal::FLOAT));
        }
      } // end check val ok
    } // end var val list
  }
  } // end else 

  // ---------------------------------
  // Set stmt
  // ---------------------------------
  if(scope) {

    // Derive the first non-scope statement in the function
    alf::AStmt * stmt = *(scope->GetStmts()->Iterator());
    while(stmt->IsType(alf::CGenericNode::TYPE_SCOPE_TUPLE)) {
      alf::CScopeTuple* scope_stmt = dynamic_cast<alf::CScopeTuple*>(stmt);
      stmt = *(scope_stmt->GetStmts()->Iterator());
    }
    // Set the statement of the annotation
    assert(stmt);
    SetStmt(stmt);
  }

  return is_ok;
}

// -------------------------------------------------------
// Check if it is ok to add the annotation at the stmt entry or exit
// and set keys of frefs and lrefs referred to in vars and vals. Will
// also derive and store the right CFG node with the annotation.
// -------------------------------------------------------
bool 
CALFAbsAnnot::
CheckOkToAddAtStmtEntryOrStmtExitAndSetKeysAndStmt(const alf::CAlfTuple *alf_tuple, ostringstream & error_msg) 
{
  bool is_ok = true;

  // Get the function name, the lrefid and the offset where the
  // assignment should be stored
  string func_name;
  string lrefid;
  unsigned int loffset;
  if(Position()->IsType(CALFAbsAnnotPosition::STMT_ENTRY)) {
    func_name = (dynamic_cast<const CALFAbsAnnotPositionStmtEntry *>(Position()))->Func();
    lrefid = (dynamic_cast<const CALFAbsAnnotPositionStmtEntry *>(Position()))->LRefId();
    loffset = (unsigned)(dynamic_cast<const CALFAbsAnnotPositionStmtEntry *>(Position()))->LOffs();
    }
    else {
      func_name = (dynamic_cast<const CALFAbsAnnotPositionStmtExit *>(Position()))->Func();
      lrefid = (dynamic_cast<const CALFAbsAnnotPositionStmtExit *>(Position()))->LRefId();
      loffset = (unsigned)(dynamic_cast<const CALFAbsAnnotPositionStmtExit *>(Position()))->LOffs();
    }
    
    // To hold the scope of the function
  const alf::CScopeTuple * scope = NULL;
  const alf::CFuncTuple * function = NULL;
  
  // To hold the node in the CFG at which the statement CFG node
  // should be inserted before or after
  alf::AStmt * stmt = NULL;

  // Derive function with the given func_name
  bool func_with_func_name_exists = false;
  const alf::CFuncList * funcs = alf_tuple->GetFuncs();
  for(alf::CFuncList::const_list_iterator func = funcs->ConstIterator(); func != funcs->InvalidIterator(); func++) {
    // Check if the function have the wanted name
    if((*func)->Name() == func_name) {
      // Yes, remember the scope and     function
          scope = (*func)->GetScope();
          function = (*func);
          // Remember that we found a function 
          func_with_func_name_exists = true;
          break;
        }
      }

      // Check if function existed
      if(!func_with_func_name_exists) {
         error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                  << "refers to non existing function:" << endl << func_name << endl;
        is_ok = false;
      }
      else {    
        
        // Get all the statements in the function
        std::vector<CGenericStmt*> stmts;
        function->GetStmtsInFunctionScopeAndSubordinateScopes(&stmts);

        // Check if a statement exists with the given label
        bool label_with_lrefid_and_loffset_exists = false;
        for(std::vector<CGenericStmt*>::iterator s = stmts.begin(); s != stmts.end(); s++) {
          alf::AStmt * alf_stmt = dynamic_cast<alf::AStmt *>(*s);
          
          // Get the lrefid and offset from the label
          alf::CLabelTuple * label = alf_stmt->GetLabel();
          alf::CLRefTuple * lref = label->GetLRef();
          alf::CIntNumValTuple * offset = label->GetOffset();
          mpz_class offset_as_bignum = offset->GetNumber()->GetValueAsBignum();

          // Convert the loffs to a bignum 
          mpz_class loffs_as_bignum(loffset);

          assert (loffs_as_bignum >= 0);

          // If the offset in the annotation is > 0 the statement is found within the basic block
          if ((loffs_as_bignum > 0) && (lref->GetId() == lrefid)) {
           // Step forward to the wanted statement
            alf::AStmt * next_alf_stmt = NULL;
            for (mpz_class i=0; i<loffs_as_bignum; i++) {
              s++;
              next_alf_stmt = dynamic_cast<alf::AStmt *>(*s);
              if (!next_alf_stmt->HasInternalGeneratedLabel()) {
                error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                << "refers to a statement which has has an own label" << endl;
                is_ok = false;
              }
            }
            label_with_lrefid_and_loffset_exists = true;
            stmt = next_alf_stmt;
            break;
          }
          
          // If offset = 0 check if the id and offset are the same
          if (loffs_as_bignum == 0) {
            if((lref->GetId() == lrefid) && (offset_as_bignum == loffs_as_bignum)) {
              label_with_lrefid_and_loffset_exists = true;
              stmt = alf_stmt;
              break;
            }
          }
        }

        // Check if we found a statement with the given label in function
      if(!label_with_lrefid_and_loffset_exists) {
         error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
           << "refers to non existing <lref,offset> pair <" 
           << lrefid << "," << loffset << "> in given function." << endl;
      is_ok = false;
    }
    else {

      // Check that it is not an annotation after a call, return, jump or switch statement 
      if(Position()->IsType(CALFAbsAnnotPosition::STMT_EXIT) && 
        (stmt->IsType(alf::CGenericNode::TYPE_CALL_STMT_TUPLE) || 
         stmt->IsType(alf::CGenericNode::TYPE_RETURN_STMT_TUPLE))) {
         error_msg << "ERROR: abstract annotation: " << endl << (*this) << " is erroneous;" << endl
          << "it is not allowed to associate AFTER annotations to call or return stmts" << endl;
        is_ok = false;
      }
      
      // Get the scope in which the stmt is positioned. Scope
      // statements are positioned in their surrounding scopes.
      const alf::CScopeTuple * scope = NULL;
      if(stmt->IsType(alf::CGenericNode::TYPE_SCOPE_TUPLE))
        scope = dynamic_cast<const alf::CScopeTuple *>(stmt);
      else
        scope = dynamic_cast<const alf::CScopeTuple *>(stmt->GetParent(alf::CGenericNode::TYPE_SCOPE_TUPLE));
      assert(scope);

      // Loop through all var val pairs
      for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::iterator var_vals = _var_vals_list->begin();
          var_vals != _var_vals_list->end(); var_vals++ ) {
        
        // ---------------------------------
        // Check if the var is correct 
        // ---------------------------------
        {

          // Get the variable to store the value in
          CALFAbsAnnotVar * var = (*var_vals).first;
          string frefid = var->FRefId();
          
          // Check if the frameid is declared in the current scope, in one of the current scope
          // ancestral scopes or in the global scope.
          Size frame_size = 0;
          unsigned int key;
          bool var_exists_in_decls = DeclaresFRefIdInCurrentOrParentScopesOrGlobalScopeOrImports(alf_tuple, scope, frefid, 
                                                                                                 &frame_size, &key);
          if(!var_exists_in_decls) {
            ostringstream s;
             s << "ERROR: abstract annotation: " << endl << (*this) << endl
                 << "refers to non existing frefid:" << endl << frefid << endl;
            throw runtime_error(s.str());
            is_ok = false;
          } 
          // If declared, check that we do not refer outside the frame border
          else if(var->HasFOffs() && 
                  (var->FOffsInBits() + (var->SizeInBits() * var->Repeat()) - 1) > frame_size) { 
             error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                      << "the needed storage for variable '" << frefid << "' (" << (var->FOffsInBits() + (var->SizeInBits() * var->Repeat())) << ") exceeds size allocated in declaration (" << frame_size << ")" << endl;
            is_ok = false;
          }
          // Check that we want to store value on even LAUs
          else if(var->HasFOffs() &&
            LAU::BitsToLAURoundUp(var->FOffsInBits()) != LAU::BitsToLAURoundDown(var->FOffsInBits())) {
            error_msg << "ERROR: start address to store value at in abstract annotation: " << endl
                << (*this) << endl << "is not evenly dividable with LAU size " << endl;
            is_ok = false;
          }
          else {
            var->SetKey(key);
          }
        } // end check var

        // ---------------------------------
        // Check if the val is correct 
        // ---------------------------------
        {
        for(list<CALFAbsAnnotVal *>::iterator val = (*var_vals).second->begin();
            val != (*var_vals).second->end(); val++ ) {  

          // Check if the val is a top value
          if((*val)->IsTOP() or (*val)->IsTOP_INT() or (*val)->IsTOP_FLOAT() or (*val)->IsTOP_ADDRESS() or (*val)->IsTOP_LABEL()) {
            // Do nothing
          }

          // Check if the val is a fref 
          else if((*val)->IsType(CALFAbsAnnotVal::ADDRESS)) {
            CALFAbsAnnotValAddress * fval = dynamic_cast<CALFAbsAnnotValAddress *>((*val));
            // Go through all frefid offs pairs and check that each frefid,offset is ok
            const list<CFRefIdOffsetPair *> * frefid_offs_list = fval->FRefIdOffsetPairList(); 
            for(list<CFRefIdOffsetPair *>::const_iterator fop = frefid_offs_list->begin();
                fop != frefid_offs_list->end(); fop++) {
              Size frame_size = 0;
              unsigned int key = 0;
              string frefid = (*fop)->FRefId();
              bool var_exists_in_decls = 
                DeclaresFRefIdInCurrentOrParentScopesOrGlobalScopeOrImports(alf_tuple, scope, frefid, &frame_size, &key);
              if(!var_exists_in_decls) {
                 error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                           << "refers to non existing frefid:" << endl << frefid << endl;
                is_ok = false;
              }
              else {                
                (*fop)->SetKey(key);
              }
            } 
          }

          // Check if the val is a lref 
          else if((*val)->IsType(CALFAbsAnnotVal::LABEL)) {
            CALFAbsAnnotValLabel * lval = dynamic_cast<CALFAbsAnnotValLabel *>((*val));
             
              // Go through all lrefid offs pairs and check that each lrefid,offset is ok
            const list<CLRefIdOffsetPair *> * lrefid_offs_list = lval->LRefIdOffsetPairList(); 
            for(list<CLRefIdOffsetPair *>::const_iterator lop = lrefid_offs_list->begin();
                lop != lrefid_offs_list->end(); lop++) {
              unsigned int key = 0;
              string lrefid = (*lop)->LRefId();
              int64_t offset = (*lop)->Offset();
              alf::CFuncTuple * func;

                // For the moment we can not refer to local labels, only functions
              bool func_exists_in_program = HasLRefIdInFuncsOrImports(alf_tuple, lrefid, &key, &func);
              if(!func_exists_in_program) {
                error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                << "refers to non existing function label " << lrefid << " " << offset
                << ". References to local labels are currently not supported." << endl;
                is_ok = false;
              }
              else {
                (*lop)->SetKey(key);
              }
            } 
          }

          else {
            assert((*val)->IsType(CALFAbsAnnotVal::INT) || (*val)->IsType(CALFAbsAnnotVal::FLOAT));
          }
        } // end check val ok
      } // end check all var val
    } // end forall vals
    } // end else
  } // end else  

  // ---------------------------------
  // Set statement of annot
  // ---------------------------------
  SetStmt(stmt);

  return is_ok;
}        


// ------------------------------------------------------- 
// Check if it is ok to add a volatile annotation 
// set keys of frefs and lrefs referred to in vars and vals. 
// ------------------------------------------------------- 
bool 
CALFAbsAnnot::
CheckOkToAddVolatileAndSetKeys(const alf::CAlfTuple *alf_tuple, ostringstream & error_msg) 
{
  bool is_ok = true;

  // Loop through all var val pairs
  for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::iterator var_vals = _var_vals_list->begin();
      var_vals != _var_vals_list->end(); var_vals++ ) {
    
    // ---------------------------------
    // Check that the var is correct
    // ---------------------------------
    { 
      // Get the variable to store the value in
      CALFAbsAnnotVar * var = (*var_vals).first;
      string frefid = var->FRefId();
      
      // Check if the frameid is declared in the global scope
      Size frame_size = 0;
      unsigned key = 0;
      // Check if the variable exists in global decls ort imports
      bool var_exists_in_glob_decls_or_imports = 
        HasFRefIdInGlobalDeclsOrImports(alf_tuple, frefid, &frame_size, &key);
      if(!var_exists_in_glob_decls_or_imports) {
         error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                  << "refers to non existing global frefid:" << endl << frefid << endl;
        is_ok = false;
      }
      
      // Given in a global decl. Check that we do not try to store
      // something outside the frame border
      else if(var->HasFOffs() &&
              (var->FOffsInBits() + (var->SizeInBits() * var->Repeat()) - 1) > frame_size) { 
         error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                  << "       need storage exeeding size allocated in global declaration " << endl;
        is_ok = false;
      }
      else {
        // Set key of var
        var->SetKey(key);
        }

      } // end check var ok

      // ---------------------------------
      // Check if the val is correct 
      // ---------------------------------
      {
        for(list<CALFAbsAnnotVal *>::iterator val = (*var_vals).second->begin();
        val != (*var_vals).second->end(); val++ ) {  

          // Check if the val is a top value
          if((*val)->IsTOP() or (*val)->IsTOP_INT() or (*val)->IsTOP_FLOAT() or (*val)->IsTOP_ADDRESS() or (*val)->IsTOP_LABEL()) {
            // Do nothing
          }

          // Check if the val is a fref 
          else if((*val)->IsType(CALFAbsAnnotVal::ADDRESS)) {
            CALFAbsAnnotValAddress * fval = dynamic_cast<CALFAbsAnnotValAddress *>((*val));
            // Go through all frefid offs pairs
            const list<CFRefIdOffsetPair *> * frefid_offs_list =  fval->FRefIdOffsetPairList(); 
            for(list<CFRefIdOffsetPair *>::const_iterator fop = frefid_offs_list->begin();
                fop != frefid_offs_list->end(); fop++) {
              Size frame_size = 0;
              unsigned key = 0;
              string frefid = (*fop)->FRefId();
              bool var_exists_in_glob_decls = 
                HasFRefIdInGlobalDeclsOrImports(alf_tuple, frefid, &frame_size, &key);
              if(!var_exists_in_glob_decls) {
                 error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                          << "refers to non existing global frefid:" << endl << frefid << endl;
                is_ok = false;
              }
              else {
                (*fop)->SetKey(key);
              }
            } 
          }

          // Check if the val is a lref 
          else if((*val)->IsType(CALFAbsAnnotVal::LABEL)) {
            CALFAbsAnnotValLabel * lval = dynamic_cast<CALFAbsAnnotValLabel *>((*val));
            // Go through all lrefid offs pairs
            const list<CLRefIdOffsetPair *> * lrefid_offs_list = lval->LRefIdOffsetPairList();
            for(list<CLRefIdOffsetPair *>::const_iterator lop = lrefid_offs_list->begin();
                lop != lrefid_offs_list->end(); lop++) {
              unsigned int key = 0;
              string lrefid = (*lop)->LRefId();
              int64_t offset = (*lop)->Offset();
              bool stmt_exits_in_program = HasLRefIdInStmts(alf_tuple, lrefid, (unsigned)offset, &key);
              if(!stmt_exits_in_program) {
                 error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                     << "refers to non existing label " << lrefid << " " << offset << endl;
                is_ok = false;
              }
              else {
                (*lop)->SetKey(key);
              }
            } 
          }
          else {
            assert((*val)->IsType(CALFAbsAnnotVal::INT) || (*val)->IsType(CALFAbsAnnotVal::FLOAT));
          }
        } // end check (*val) ok
      } // end check vals ok
    } // end forall var val pairs

    // ---------------------------------
    // Set stmt
    // ---------------------------------

    // The annotation has no statement
    SetStmt(NULL);
  
  return is_ok;
}


// ------------------------------------------------------- 
// Check if it is ok to add a when called annotation 
// set keys of frefs and lrefs referred to in vars and vals. 
// ------------------------------------------------------- 
bool 
CALFAbsAnnot::
CheckOkToAddWhenCalledAndSetKeys(const alf::CAlfTuple *alf_tuple, ostringstream & error_msg)
{
  bool is_ok = true;
  
  // Get the function name where the assignment should be stored
  string func_name = (dynamic_cast<const CALFAbsAnnotPositionWhenCalled *>(Position()))->Func();
  alf::CFuncTuple * func = NULL;
  
  { // Check if the function is a declared function or in imports
    unsigned key = 0;
    bool func_or_imports_with_func_name_exists = HasLRefIdInFuncsOrImports(alf_tuple, func_name, &key, &func);
    
    // Check if we found a function
    if(!func_or_imports_with_func_name_exists) {
       error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                << "refers to non existing function " << func_name << endl;
      is_ok = false;
    }
  }

  { // Check that referred variables and values are ok (only globals and RET_VAL may be referred to)
    
    // Loop through all var val pairs
    for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::iterator var_vals = _var_vals_list->begin();
        var_vals != _var_vals_list->end(); var_vals++ ) {
      
      // ---------------------------------
      // Check if the var is correct 
      // ---------------------------------
      {
        // Get the variable to store the value in
        CALFAbsAnnotVar * var = (*var_vals).first;
        // Check if it is a return value var
        if(var->IsReturnValueVar()) {
          // If we have a function we should check that the function has exactly one return value
          if(func) {
            if(func->NrOfReturnValues() != 1) {
               error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                        << "       has RET_VAL variable for function " << func_name 
                        << ". This function has no return value." << endl;
              is_ok = false;
            }
          }
        }
        else {
          // Normal variable
          string frefid = var->FRefId();
          
          // Check if the frameid is declared in global scope
          Size frame_size = 0;
          unsigned int key;
          bool var_exists_in_decls = 
            HasFRefIdInGlobalDeclsOrImports(alf_tuple, frefid, &frame_size, &key);
          if(!var_exists_in_decls) {
             error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                      << "refers to non existing global or imported frefid:" << endl << frefid << endl;
            is_ok = false;
          } 
          // If declared, check that we do not refer outside the frame border
          else if(var->HasFOffs() &&
                  (var->FOffsInBits() + (var->SizeInBits() * var->Repeat()) - 1) > frame_size) { 
             error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                      << "needs storage exeeding size allocated in declaration " << endl;
            is_ok = false;
          }
          else {
            // Set key of var
            var->SetKey(key);
          }
        }
      } // end check var
      
      // ---------------------------------
      // Check if the val is correct 
      // ---------------------------------
      {    for(list<CALFAbsAnnotVal *>::iterator val = (*var_vals).second->begin();
               val != (*var_vals).second->end(); val++ ) {  

          // Check if the val is a top value
        if((*val)->IsTOP() or (*val)->IsTOP_INT() or (*val)->IsTOP_FLOAT() or (*val)->IsTOP_ADDRESS() or (*val)->IsTOP_LABEL()) {
            // Do nothing
          }

          // Check if the val is a fref 
          else if((*val)->IsType(CALFAbsAnnotVal::ADDRESS)) {
            CALFAbsAnnotValAddress * fval = dynamic_cast<CALFAbsAnnotValAddress *>((*val));
            // Go through all frefid offs pairs and check that each frefid,offset is ok
            const list<CFRefIdOffsetPair *> * frefid_offs_list = fval->FRefIdOffsetPairList(); 
            for(list<CFRefIdOffsetPair *>::const_iterator fop = frefid_offs_list->begin();
                fop != frefid_offs_list->end(); fop++) {
              Size frame_size = 0;
              unsigned int key = 0;
              string frefid = (*fop)->FRefId();
              bool var_exists_in_decls_or_imports = 
                HasFRefIdInGlobalDeclsOrImports(alf_tuple, frefid, &frame_size, &key);
              if(!var_exists_in_decls_or_imports) {
                 error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                          << "refers to non existing frefid:" << endl << frefid << endl;
                is_ok = false;
              }
              else {
                (*fop)->SetKey(key);
              }
            } 
          }

          // Check if the val is a lref 
          else if((*val)->IsType(CALFAbsAnnotVal::LABEL)) {
            CALFAbsAnnotValLabel * lval = dynamic_cast<CALFAbsAnnotValLabel *>((*val));
            // Go through all lrefid offs pairs and check that each lrefid,offset is ok
            const list<CLRefIdOffsetPair *> * lrefid_offs_list = lval->LRefIdOffsetPairList(); 
            for(list<CLRefIdOffsetPair *>::const_iterator lop = lrefid_offs_list->begin();
                lop != lrefid_offs_list->end(); lop++) {
              unsigned int key = 0;
              string lrefid = (*lop)->LRefId();
              int64_t offset = (*lop)->Offset();
              alf::CFuncTuple * func;
              // For the moment we can not refer to local labels, only functions
              bool func_exits_in_program = HasLRefIdInFuncsOrImports(alf_tuple, lrefid, &key, &func);
              if(!func_exits_in_program) {
                 error_msg << "ERROR: abstract annotation: " << endl << (*this) << endl
                          << "refers to non existing label " << lrefid << " " << offset << endl;
                is_ok = false;
              }
              else {
                (*lop)->SetKey(key);
              }
            } 
          }

          else {
            assert((*val)->IsType(CALFAbsAnnotVal::INT) || (*val)->IsType(CALFAbsAnnotVal::FLOAT));
          }
        } // end check val ok
      } // end check vals ok
    } // end var val list
  } // end else 

  // ---------------------------------
  // Set stmt
  // ---------------------------------

  // The annotation has no statement
  SetStmt(NULL);

  return is_ok;
}

bool
CALFAbsAnnot::
DeclaresFRefIdInCurrentOrParentScopesOrGlobalScopeOrImports(const alf::CAlfTuple *alf_tuple, const alf::CScopeTuple* scope, 
                                                            std::string frefid, Size * frame_size, unsigned int * key)
{
  // Check if the current scope has declared the frame id
  if(HasFRefIdInDecls(scope->GetDecls(), frefid, frame_size, key)) {
    return true;
  }
  else {
    // Get the parent scope (if any) in the ast and check if it declares the frameid
    const alf::CGenericNode * parent_node = scope->GetParent(alf::CGenericNode::TYPE_SCOPE_TUPLE);
    if(parent_node != NULL) {
      return DeclaresFRefIdInCurrentOrParentScopesOrGlobalScopeOrImports(alf_tuple, dynamic_cast<const alf::CScopeTuple *>(parent_node), frefid, frame_size, key);
    }
    else {
    // Else, check the formal function arguments 
      const alf::CGenericNode * func_node = scope->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE);
      assert(func_node != NULL);
      const alf::CFuncTuple * func_tuple = dynamic_cast<const alf::CFuncTuple *>(func_node);
      if(HasFRefIdInArgDecls(func_tuple->GetArgs(), frefid, frame_size, key)) {
        return true;
      }
      else {
        // Check if declared in the global scope 
        if(HasFRefIdInDecls(alf_tuple->GetDecls(), frefid, frame_size, key)) {
          return true;
        }
        else {
          // Check if it is declared in the global imports 
          if(HasFRefIdInImports(alf_tuple->GetImports(), frefid, frame_size, key)) {
            return true;
            // ostringstream s;
            //             s << "ERROR: abstract annotation: " << endl << (*this) << endl
            //                  << "refers to variable declared in the imports section. This is currently" << endl
            //                  << "       not allowed since these variables do not have any given size." << endl;
            //             throw runtime_error(s.str());
            //             return false;            
          }
          else {
            return false;
          }
        }
      }
    }
  }
}

bool 
CALFAbsAnnot::   
HasFRefIdInDecls(const alf::CDeclList * decls, std::string frefid, Size * frame_size, unsigned * key)
{
  // Loop through all declararations
  for(alf::CDeclList::const_list_iterator decl = decls->ConstIterator(); 
      decl != decls->InvalidIterator(); decl++) {
    if((*decl)->Name() == frefid) {
      // Reset the frame size
      *frame_size = (*decl)->GetFrameSize()->GetSizeInBits();
      // Get the global key
      assert((*decl)->HasKey());
      *key = (*decl)->GetKey();
      return true;
    }
  }
  return false;
}

bool 
CALFAbsAnnot::   
HasFRefIdInGlobalDeclsOrImports(const alf::CAlfTuple *ast,std::string frefid, Size * frame_size, unsigned * key)
{
  return HasFRefIdInDeclsOrImports(ast->GetDecls(), ast->GetImports(), frefid, frame_size, key);
}

bool 
CALFAbsAnnot::   
HasFRefIdInDeclsOrImports(const alf::CDeclList * decls, const alf::CImportsTuple* imports, std::string frefid, Size * frame_size, unsigned * key)
{
  bool has_frefid_in_decls = HasFRefIdInDecls(decls, frefid, frame_size, key);
  if(!has_frefid_in_decls) {
    return HasFRefIdInImports(imports, frefid, frame_size, key);
  }
  else {
    return true;
  }
}

bool 
CALFAbsAnnot::   
HasFRefIdInArgDecls(const alf::CArgDeclList * decls, std::string frefid, Size * frame_size, unsigned * key)
{
  // Loop through all declararations
  for(alf::CArgDeclList::const_list_iterator decl = decls->ConstIterator(); 
      decl != decls->InvalidIterator(); decl++) {
    if((*decl)->Name() == frefid) {
      // Reset the frame size
      *frame_size = (*decl)->GetFrameSize()->GetSizeInBits();
      // Get the global key
      assert((*decl)->HasKey());
      *key = (*decl)->GetKey();
      return true;
    }
  }
  return false;
}

bool 
CALFAbsAnnot::   
HasFRefIdInImports(const alf::CImportsTuple* imports, std::string frefid, Size * frame_size, unsigned * key)
{
  // Get the lists of imported frfs 
  const alf::CFRefList * frefs = imports->GetFRefList();
  // Loop through all imported frefs
  for(alf::CFRefList::const_list_iterator fref = frefs->ConstIterator(); 
      fref != frefs->InvalidIterator(); fref++) {
    if((*fref)->GetId() == frefid) {
      // Get the global key
      assert((*fref)->HasKey());
      *key = (*fref)->GetKey();
      // A imported fref has infinite size
      *frame_size = Size::Infinity();
      return true;
    }
  }
  return false;
}

bool 
CALFAbsAnnot::   
HasLRefIdInImports(const alf::CImportsTuple* imports, std::string lrefid, Size * frame_size, unsigned * key)
{
  // Get the lists of imported lrefs 
  const alf::CLRefList * lrefs = imports->GetLRefList();
  // Loop through all imported lrefs
  for(alf::CLRefList::const_list_iterator lref = lrefs->ConstIterator(); 
      lref != lrefs->InvalidIterator(); lref++) {
    if((*lref)->GetId() == lrefid) {
      // Get the global key
      assert((*lref)->HasKey());
      *key = (*lref)->GetKey();
      // A imported lref has infinite size
      *frame_size = Size::Infinity();
      return true;
    }
  }
  return false;
}

// Help function to check if a statement with given frefid and label
// exists in ALF program. Returns true if so and the key of the
// statement is given to key.
bool 
CALFAbsAnnot::   
HasLRefIdInStmts(const alf::CAlfTuple * program, std::string lrefid, unsigned int offset, 
                 unsigned int * key) 
{
    // Loop through all functions in the ALF program
  const alf::CFuncList* funcs = program->GetFuncs();
  for(alf::CFuncList::const_list_iterator func = funcs->ConstIterator(); 
      func != funcs->InvalidIterator(); func++) {
    // Extract all statements belonging to the function
    std::vector<CGenericStmt*> stmts;
    (*func)->GetStmtsInFunctionScopeAndSubordinateScopes(&stmts);
    // Loop through all statements to see if we have found a statement with the given label
    for(std::vector<CGenericStmt*>::iterator stmt = stmts.begin(); stmt != stmts.end(); stmt++) {
      // Get the label of the statement
      alf::AStmt * astmt = dynamic_cast<alf::AStmt *>(*stmt);
      alf::CLabelTuple * alabel = astmt->GetLabel();
      // Get the lrefid and offset from the label
      alf::CLRefTuple * alref = alabel->GetLRef();
      alf::CIntNumValTuple * aoffset = alabel->GetOffset();
      mpz_class aoffset_as_bignum = aoffset->GetNumber()->GetValueAsBignum();
      // Convert the offset to a bignum 
      mpz_class offset_as_bignum(offset);
      // Check if the id and offset are the same
      if((alref->GetId() == lrefid) && (aoffset_as_bignum == offset_as_bignum)) {
        // Yes, remember the key of the statement
        *key = astmt->Key();
        return true;
      }
    }
  }
  // No statement with the given label was found
  return false;
}

// Help function to check if a function with the given lrefid exists in program.
// It can either be a function name or an imported lref
bool 
CALFAbsAnnot::   
HasLRefIdInFuncsOrImports(const alf::CAlfTuple * alf_tuple, std::string lrefid, unsigned int * key, alf::CFuncTuple ** func) 
{
  // Check if function is among the functions of the program
  bool func_or_imports_with_func_name_exists = false;
  const alf::CFuncList * funcs = alf_tuple->GetFuncs();
  for(alf::CFuncList::const_list_iterator f = funcs->ConstIterator(); f != funcs->InvalidIterator(); f++) {
    // Check if the function have the wanted name
   if((*f)->Name() == lrefid) {
      // Remember that we found a function 
      *func = (*f);
      func_or_imports_with_func_name_exists = true;
      *key = (*func)->Key();
      break;
    }
  }
  
  // Check if function is imported
  if(!func_or_imports_with_func_name_exists) {
    // Check if the function name existed among imported lrefs
    Size frame_size = 0;
    unsigned key = 0;
    func_or_imports_with_func_name_exists = 
      HasLRefIdInImports(alf_tuple->GetImports(), lrefid, &frame_size, &key);
  }

  return func_or_imports_with_func_name_exists;
}
 
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotPosition
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnotPosition::
~CALFAbsAnnotPosition()
{
  // Do nothing
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotPositionStmtEntry
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnotPositionStmtEntry::
CALFAbsAnnotPositionStmtEntry(string func, string lrefid, uint64_t loffs)
  : _func(func), _lrefid(lrefid), _loffs(loffs)
{
  _position_type = CALFAbsAnnotPosition::STMT_ENTRY;
  // Do nothing
}

CALFAbsAnnotPositionStmtEntry::
~CALFAbsAnnotPositionStmtEntry()
{
  // Do nothing
} 

string 
CALFAbsAnnotPositionStmtEntry::
Func() const
{
  return _func;
}

string 
CALFAbsAnnotPositionStmtEntry::
LRefId() const
{
  return _lrefid;
}

uint64_t
CALFAbsAnnotPositionStmtEntry::
LOffs() const
{
  return _loffs;
}

// To check if two positions are equal
bool 
CALFAbsAnnotPositionStmtEntry::
IsEqual(const CALFAbsAnnotPosition * other) const
{
  if(!(other->IsType(CALFAbsAnnotPosition::STMT_ENTRY)))
    return false;

  const CALFAbsAnnotPositionStmtEntry * casted_other =
    dynamic_cast<const CALFAbsAnnotPositionStmtEntry *>(other);

  if((Func() == casted_other->Func()) && 
     (LRefId() == casted_other->LRefId()) &&
     (LOffs() == casted_other->LOffs()))
    return true;
  else
    return false;
}

std::ostream & 
CALFAbsAnnotPositionStmtEntry::
Print(std::ostream & o) const
{
  o << "STMT_ENTRY \"" << _func << "\" \"" << _lrefid << "\" " << _loffs;
  return o;
}

CALFAbsAnnotPositionStmtEntry * 
CALFAbsAnnotPositionStmtEntry::
Copy() const
{
  return new CALFAbsAnnotPositionStmtEntry(_func, _lrefid, _loffs);
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotPositionStmtExit
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnotPositionStmtExit::
CALFAbsAnnotPositionStmtExit(string func, string lrefid, uint64_t loffs)
  : _func(func), _lrefid(lrefid), _loffs(loffs)
{
  _position_type = CALFAbsAnnotPosition::STMT_EXIT;
  // Do nothing
}

CALFAbsAnnotPositionStmtExit::
~CALFAbsAnnotPositionStmtExit()
{
  // Do nothing
} 

string 
CALFAbsAnnotPositionStmtExit::
Func() const
{
  return _func;
}

string 
CALFAbsAnnotPositionStmtExit::
LRefId() const
{
  return _lrefid;
}

uint64_t
CALFAbsAnnotPositionStmtExit::
LOffs() const
{
  return _loffs;
}

// To check if two positions are equal
bool 
CALFAbsAnnotPositionStmtExit::
IsEqual(const CALFAbsAnnotPosition * other) const
{
  if(!(other->IsType(CALFAbsAnnotPosition::STMT_EXIT)))
    return false;

  const CALFAbsAnnotPositionStmtExit * casted_other =
    dynamic_cast<const CALFAbsAnnotPositionStmtExit *>(other);

  if((Func() == casted_other->Func()) && 
     (LRefId() == casted_other->LRefId()) &&
     (LOffs() == casted_other->LOffs()))
    return true;
  else
    return false;
}

std::ostream & 
CALFAbsAnnotPositionStmtExit::
Print(std::ostream & o) const
{
  o << "STMT_EXIT \"" << _func << "\" \"" << _lrefid << "\" " << _loffs;
  return o;
}

CALFAbsAnnotPositionStmtExit * 
CALFAbsAnnotPositionStmtExit::
Copy() const
{
  return new CALFAbsAnnotPositionStmtExit(_func, _lrefid, _loffs);
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotPositionFuncEntry
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnotPositionFuncEntry::
CALFAbsAnnotPositionFuncEntry(string func)
  : _func(func)
{
  _position_type = CALFAbsAnnotPosition::FUNC_ENTRY;
  // Do nothing
}

CALFAbsAnnotPositionFuncEntry::
~CALFAbsAnnotPositionFuncEntry()
{
  // Do nothing
} 

std::string 
CALFAbsAnnotPositionFuncEntry::
Func() const
{
  return _func;
}

// To check if two positions are equal
bool 
CALFAbsAnnotPositionFuncEntry::
IsEqual(const CALFAbsAnnotPosition * other) const
{
  if(!(other->IsType(CALFAbsAnnotPosition::FUNC_ENTRY)))
    return false;

  const CALFAbsAnnotPositionFuncEntry * casted_other =
    dynamic_cast<const CALFAbsAnnotPositionFuncEntry *>(other);

  if(Func() == casted_other->Func())
    return true;
  else
    return false;
}

std::ostream &
CALFAbsAnnotPositionFuncEntry::
Print(std::ostream & o) const
{
  o << "FUNC_ENTRY \"" << _func << "\"";
  return o;
}

CALFAbsAnnotPositionFuncEntry * 
CALFAbsAnnotPositionFuncEntry::
Copy() const
{
  return new CALFAbsAnnotPositionFuncEntry(_func);
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotPositionProgEntry
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnotPositionProgEntry::
CALFAbsAnnotPositionProgEntry()
{
  _position_type = CALFAbsAnnotPosition::PROG_ENTRY;
  // Do nothing
}

CALFAbsAnnotPositionProgEntry::
~CALFAbsAnnotPositionProgEntry()
{
  // Do nothing
} 

// To check if two positions are equal
bool 
CALFAbsAnnotPositionProgEntry::
IsEqual(const CALFAbsAnnotPosition * other) const
{
  if(other->IsType(CALFAbsAnnotPosition::PROG_ENTRY)) {
    return true;
  }
  else {
    return false;
  }
}

std::ostream &
CALFAbsAnnotPositionProgEntry::
Print(std::ostream & o) const
{
  o << "PROG_ENTRY";
  return o;
}

CALFAbsAnnotPositionProgEntry * 
CALFAbsAnnotPositionProgEntry::
Copy() const
{
  return new CALFAbsAnnotPositionProgEntry();
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotPositionVolatile
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnotPositionVolatile::
CALFAbsAnnotPositionVolatile()
{
  _position_type = CALFAbsAnnotPosition::VOLATILE;
  // Do nothing
}

CALFAbsAnnotPositionVolatile::
~CALFAbsAnnotPositionVolatile()
{
  // Do nothing
} 

// To check if two positions are equal
bool 
CALFAbsAnnotPositionVolatile::
IsEqual(const CALFAbsAnnotPosition * other) const
{
  if(other->IsType(CALFAbsAnnotPosition::VOLATILE)) {
    return true;
  }
  else {
    return false;
  }
}

std::ostream &
CALFAbsAnnotPositionVolatile::
Print(std::ostream & o) const
{
  o << "VOLATILE";
  return o;
}

CALFAbsAnnotPositionVolatile * 
CALFAbsAnnotPositionVolatile::
Copy() const
{
  return new CALFAbsAnnotPositionVolatile();
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotPositionWhenCalled
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnotPositionWhenCalled::
CALFAbsAnnotPositionWhenCalled(string func)
  : _func(func)
{
  _position_type = CALFAbsAnnotPosition::WHEN_CALLED;
  // Do nothing
}

CALFAbsAnnotPositionWhenCalled::
~CALFAbsAnnotPositionWhenCalled()
{
  // Do nothing
} 

std::string 
CALFAbsAnnotPositionWhenCalled::
Func() const
{
  return _func;
}

// To check if two positions are equal
bool 
CALFAbsAnnotPositionWhenCalled::
IsEqual(const CALFAbsAnnotPosition * other) const
{
  if(!(other->IsType(CALFAbsAnnotPosition::WHEN_CALLED)))
    return false;

  const CALFAbsAnnotPositionWhenCalled * casted_other =
    dynamic_cast<const CALFAbsAnnotPositionWhenCalled *>(other);

  if(Func() == casted_other->Func())
    return true;
  else
    return false;
}

std::ostream &
CALFAbsAnnotPositionWhenCalled::
Print(std::ostream & o) const
{
  o << "WHEN_CALLED \"" << _func << "\"";
  return o;
}

CALFAbsAnnotPositionWhenCalled * 
CALFAbsAnnotPositionWhenCalled::
Copy() const
{
  return new CALFAbsAnnotPositionWhenCalled(_func);
}


// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotVar
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnotVar::
CALFAbsAnnotVar(string frefid)
  : _frefid(frefid), _has_foffs(false), _foffs_in_bits(0),
    _has_size(false), _size_in_bits(0),
    _has_repeat(false), _repeat(1), _key(0), _has_key(false), _no_of_derefs(0)
{
    // Do nothing
}

CALFAbsAnnotVar::
CALFAbsAnnotVar(string frefid, int no_of_derefs)
  : _frefid(frefid), _has_foffs(false), _foffs_in_bits(0), 
    _has_size(false), _size_in_bits(0), 
    _has_repeat(false), _repeat(1), _key(0), _has_key(false), _no_of_derefs(no_of_derefs)
{
  // Do nothing
}

CALFAbsAnnotVar::
CALFAbsAnnotVar(string frefid, uint64_t foffs_in_bits, Size size_in_bits)
  : _frefid(frefid), _has_foffs(true), _foffs_in_bits(foffs_in_bits),
    _has_size(true), _size_in_bits(size_in_bits),
    _has_repeat(false), _repeat(1), _key(0), _has_key(false), _no_of_derefs(0)
{
    // Do nothing
}

CALFAbsAnnotVar::
CALFAbsAnnotVar(string frefid, int no_of_derefs, uint64_t foffs_in_bits, Size size_in_bits)
  : _frefid(frefid), _has_foffs(true), _foffs_in_bits(foffs_in_bits),
    _has_size(true), _size_in_bits(size_in_bits),
    _has_repeat(false), _repeat(1), _key(0), _has_key(false), _no_of_derefs(no_of_derefs)
{
  // Do nothing
}

CALFAbsAnnotVar::
CALFAbsAnnotVar(string frefid, uint64_t foffs_in_bits, Size size_in_bits, uint64_t repeat)
  : _frefid(frefid), _has_foffs(true), _foffs_in_bits(foffs_in_bits), 
    _has_size(true), _size_in_bits(size_in_bits), 
    _has_repeat(true), _repeat(repeat), _key(0), _has_key(false), _no_of_derefs(0)
{
  // Do nothing
}

CALFAbsAnnotVar::
CALFAbsAnnotVar(string frefid, int no_of_derefs, uint64_t foffs_in_bits, Size size_in_bits, uint64_t repeat)
: _frefid(frefid), _has_foffs(true), _foffs_in_bits(foffs_in_bits),
_has_size(true), _size_in_bits(size_in_bits),
_has_repeat(true), _repeat(repeat), _key(0), _has_key(false), _no_of_derefs(no_of_derefs)
{
    // Do nothing
}

void
CALFAbsAnnotVar::
AddPSizes(std::vector <int> psizes)
{
   for (std::vector<int>::reverse_iterator rit = psizes.rbegin(); rit!= psizes.rend(); ++rit) {
      _psizes.push_back(*rit);
   }
}

int
CALFAbsAnnotVar::
PSize(int pos) const
{
   return _psizes.at(pos);
}

void
CALFAbsAnnotVar::
SetFRefId(string s)
{
   _frefid = s;
}

string
CALFAbsAnnotVar::
FRefId() const
{
  return _frefid;
}

bool 
CALFAbsAnnotVar::
HasFOffs() const
{
  return _has_foffs;
}

uint64_t
CALFAbsAnnotVar::
FOffsInBits() const
{
  return _foffs_in_bits;
}

void
CALFAbsAnnotVar::
SetFOffsInBits(uint64_t foffs_in_bits)
{
  _has_foffs = true;
  _foffs_in_bits = foffs_in_bits;
}

bool 
CALFAbsAnnotVar::
HasSize() const
{
  return _has_size;
}

Size
CALFAbsAnnotVar::
SizeInBits() const
{
  assert(_has_size);
  return _size_in_bits;
}

void
CALFAbsAnnotVar::
SetSizeInBits(Size size_in_bits) 
{
  _has_size = true;
  _size_in_bits = size_in_bits;
}

bool 
CALFAbsAnnotVar::
HasRepeat() const
{
  return _has_repeat;
}

uint64_t
CALFAbsAnnotVar::
Repeat() const
{
  return _repeat;
}

void
CALFAbsAnnotVar::
SetRepeat(uint64_t repeat) 
{
  _has_repeat = true;
  _repeat = repeat;
}

bool
CALFAbsAnnotVar::
Overlaps(const CALFAbsAnnotVar * other) const
{
  // If the variables have different frefids they go to different
  // frame refs and can therefore not overlap.
  if(FRefId() != other->FRefId()) {
    return false;
  }
  // If one of the variables does not have any size, they are covering
  // the whole frame. Thus they must be overlapping the other one.
  else if(!HasSize() || !other->HasSize()) {
    return true;
  }
  // If the first one's starting offset is smaller than the other ones,
  // then they can only overlap if the first one + size is greater than
  // the other one's starting offset.
  else if(FOffsInBits() < other->FOffsInBits()) {
    if((FOffsInBits() + (SizeInBits() * Repeat()) - 1) < other->FOffsInBits())
      return false;
    else 
      return true;
  }
  // The same reasoning but with variable annotations switched
  else if(other->FOffsInBits() < FOffsInBits()) {
    if((other->FOffsInBits() + (other->SizeInBits() * other->Repeat()) - 1) < FOffsInBits())
      return false;
    else
      return true;
  }
  // Both have the same starting offset, thus they are overlapping
  else {
    return true;
  }
}

CALFAbsAnnotVar * 
CALFAbsAnnotVar::
Copy() const
{
  // Since there are no pointers in the class we can copy in using the
  // built in copy constructor which copies all the internal fields.
  return new CALFAbsAnnotVar(*this);
}

std::ostream & 
CALFAbsAnnotVar::
Print(std::ostream & o) const
{
  if (_no_of_derefs>0) {
    for (int i=0; i<_no_of_derefs; ++i)
      o << PSize(i) << " " << "* " ;
  }
  if(HasRepeat())
    o << "\"" << FRefId() << "\" " << FOffsInBits() << " " << SizeInBits() << " " << Repeat();
  else if(HasSize())
    o << "\"" << FRefId() << "\" " << FOffsInBits() << " " << SizeInBits();
  else
    o << "\"" << FRefId() << "\"";
  return o;
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotReturnValueVar
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

  //CALFAbsAnnotReturnValueVar::
  //CALFAbsAnnotReturnValueVar( )
  //: CALFAbsAnnotVar("RET_VAL")
  //{
  // Do nothing
  //}

// CALFAbsAnnotReturnValueVar::
// CALFAbsAnnotReturnValueVar(uint64_t foffs, Size size_in_bits)
//   : CALFAbsAnnotVar("RET_VAL", foffs, size_in_bits)
// {
//   // Do nothing
// }

// CALFAbsAnnotReturnValueVar::
// CALFAbsAnnotReturnValueVar(uint64_t foffs, Size size_in_bits, uint64_t repeat)
//   : CALFAbsAnnotVar("RET_VAL", foffs, size_in_bits, repeat)
// {
//   // Do nothing
// }

  //CALFAbsAnnotVar *
  //CALFAbsAnnotReturnValueVar::
  //Copy() const
  //{
  // Since there are no pointers in the class we can copy in using the
  // built in copy constructor which copies all the internal fields.
  //  return new CALFAbsAnnotReturnValueVar(*this);
  //}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotVal
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnotVal::
CALFAbsAnnotVal(bool is_top)
 : _is_top(is_top)
{
  // Do nothing
}

CALFAbsAnnotVal::
~CALFAbsAnnotVal()
{
  // Do nothing
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotValTop
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnotValTop::
CALFAbsAnnotValTop( )
: CALFAbsAnnotVal(true)
{
   _val_type = CALFAbsAnnotVal::TOP;
   // Do nothing
}

// For checking if two abstract values are equal
bool
CALFAbsAnnotValTop::
IsEqual(const CALFAbsAnnotVal* val) const {
   
   // Are they both TOP?
   if (!val->IsTOP()) return false;
   else return true;
}

CALFAbsAnnotValTop *
CALFAbsAnnotValTop::
Copy() const
{
    // Since there are no pointers in the class we can copy in using the
    // built in copy constructor which copies all the internal fields.
  return new CALFAbsAnnotValTop(*this);
}

std::ostream &
CALFAbsAnnotValTop::
Print(std::ostream & o) const
{
  o << "TOP";
  return o;
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotValInt
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnotValInt::
CALFAbsAnnotValInt( )
  : CALFAbsAnnotVal(true), _ilow(0), _iupp(0), _icong(1)
{
  _val_type = CALFAbsAnnotVal::INT;
  // Do nothing
}

CALFAbsAnnotValInt::
CALFAbsAnnotValInt(int64_t ilow)
  : CALFAbsAnnotVal(false), _ilow(ilow), _iupp(ilow), _icong(1)
{
  _val_type = CALFAbsAnnotVal::INT;
  // Do nothing
}

CALFAbsAnnotValInt::
CALFAbsAnnotValInt(int64_t ilow,  int64_t iupp)
  : CALFAbsAnnotVal(false), _ilow(ilow), _iupp(iupp), _icong(1)
{
   if (iupp < ilow) throw logic_error("CALFAbsAnnotValInt::CALFAbsAnnotValInt(): iupp < ilow");
   _val_type = CALFAbsAnnotVal::INT;
   // Do nothing
}

CALFAbsAnnotValInt::
CALFAbsAnnotValInt(int64_t ilow,  int64_t iupp, uint64_t icong)
  : CALFAbsAnnotVal(false), _ilow(ilow), _iupp(iupp), _icong(icong)
{
   if (iupp < ilow) throw logic_error("CALFAbsAnnotValInt::CALFAbsAnnotValInt(): iupp < ilow");
   if (icong == 0) {
      if (ilow != iupp) throw logic_error("CALFAbsAnnotValInt::CALFAbsAnnotValInt(): icong == 0 && ilow != iupp");
   } else {
      if ((iupp - ilow) % icong != 0) throw logic_error("CALFAbsAnnotValInt::CALFAbsAnnotValInt(): (iupp - ilow) % icong != 0");
   }
   if (ilow == iupp)
      _icong = 1; // to be consistent with the other constructors
   _val_type = CALFAbsAnnotVal::INT;
   // Do nothing
}

CALFAbsAnnotValInt::
~CALFAbsAnnotValInt()
{
  // Do nothing
}

// For checking if two abstract values are equal
bool
CALFAbsAnnotValInt::
IsEqual(const CALFAbsAnnotVal* val) const {
   // Are they both TOP_INT?
   if (this->IsTOP_INT() && val->IsTOP_INT()) return true;
   // Check if they are of the same type
   if (!val->IsType(CALFAbsAnnotVal::INT)) return false;
   // Downcast
   const CALFAbsAnnotValInt* val_as_int = dynamic_cast<const CALFAbsAnnotValInt*>(val);
   assert(val_as_int);

   // Check attributes of the two values
   return (ILow() == val_as_int->ILow() &&
           IUpp() == val_as_int->IUpp() &&
           ICong() == val_as_int->ICong());
}

int64_t 
CALFAbsAnnotValInt::
ILow() const
{
  return _ilow;
}

int64_t 
CALFAbsAnnotValInt::
IUpp() const
{
  return _iupp;
}

uint64_t 
CALFAbsAnnotValInt::
ICong() const
{
  return _icong;
}

void 
CALFAbsAnnotValInt::
SetILow(int64_t ilow)
{
  _ilow = ilow;
}

void 
CALFAbsAnnotValInt::
SetIUpp(int64_t iupp)
{
  _iupp = iupp;
}

CALFAbsAnnotValInt *
CALFAbsAnnotValInt::
Copy() const
{
  // Since there are no pointers in the class we can copy in using the
  // built in copy constructor which copies all the internal fields.
  return new CALFAbsAnnotValInt(*this);
} 

std::ostream & 
CALFAbsAnnotValInt::
Print(std::ostream & o) const
{
  if(IsTOP_INT()) {
    o << "TOP_INT";
  }
  else {
    o << "INT ";
    if(_icong > 1) {
      o << _ilow << " " << _iupp << " " << _icong;
    }
    else if (_ilow < _iupp) {
      o << _ilow << " " << _iupp;
    }    
    else {
      o << _ilow;
    }
  }
  return o;
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotValFloat
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnotValFloat::
CALFAbsAnnotValFloat()
  : CALFAbsAnnotVal(true), _flow(0), _has_fupp(false), _fupp(0)
{
  _val_type = CALFAbsAnnotVal::FLOAT;
  // Do nothing
}

CALFAbsAnnotValFloat::
CALFAbsAnnotValFloat(float flow)
  : CALFAbsAnnotVal(false), _flow(flow), _has_fupp(false), _fupp(flow)
{
  _val_type = CALFAbsAnnotVal::FLOAT;
  // Do nothing
}

CALFAbsAnnotValFloat::
CALFAbsAnnotValFloat(float flow,  float fupp)
  : CALFAbsAnnotVal(false), _flow(flow), _has_fupp(true), _fupp(fupp)
{
  _val_type = CALFAbsAnnotVal::FLOAT;
  // Do nothing
}

CALFAbsAnnotValFloat::
~CALFAbsAnnotValFloat()
{
  // Do nothing
}

// For checking if two abstract values are equal
bool
CALFAbsAnnotValFloat::
IsEqual(const CALFAbsAnnotVal* val) const {
    // Are they both TOP_FLOAT?
  if (IsTOP_FLOAT() and val->IsTOP_FLOAT()) return true;
    // Check if they are of the same type
  if (!val->IsType(CALFAbsAnnotVal::FLOAT)) return false;
    // Downcast
  const CALFAbsAnnotValFloat* val_as_float = dynamic_cast<const CALFAbsAnnotValFloat*>(val);
  assert(val_as_float);
  
    // Check attributes of the two values
  if(FLow() != val_as_float->FLow()) return false;
  if (HasFUpp()) {
    if (!val_as_float->HasFUpp()) return false;
    if (FUpp() != val_as_float->FUpp()) return false;
  }
    // All values are equal, return true
  return true;
}

float
CALFAbsAnnotValFloat::
FLow() const
{
  return _flow;
}

bool
CALFAbsAnnotValFloat::
HasFUpp() const
{
  return _has_fupp;
}

float 
CALFAbsAnnotValFloat::
FUpp() const
{
  return _fupp;
}

void 
CALFAbsAnnotValFloat::
SetFLow(float flow)
{
  _flow = flow;
}

void 
CALFAbsAnnotValFloat::
SetFUpp(float fupp)
{
  _fupp = fupp;
}

CALFAbsAnnotValFloat *
CALFAbsAnnotValFloat::
Copy() const
{
  // Since there are no pointers in the class we can copy in using the
  // built in copy constructor which copies all the internal fields.
  return new CALFAbsAnnotValFloat(*this);
} 

std::ostream & 
CALFAbsAnnotValFloat::
Print(std::ostream & o) const
{
  if(IsTOP_FLOAT()) {
    o << "TOP_FLOAT";
  }
  else {
    o << "FLOAT ";
    if(_has_fupp) { 
      o << _flow << " " << _fupp;
    }
    else { 
      o << _flow;
    }
  }
  return o;
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotValAddress
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnotValAddress::
CALFAbsAnnotValAddress()
  : CALFAbsAnnotVal(true), _frefid_offset_pair_list(NULL)
{
  _val_type = CALFAbsAnnotVal::ADDRESS;
  // Do nothing
}

CALFAbsAnnotValAddress::
CALFAbsAnnotValAddress(list<CFRefIdOffsetPair *> * frefid_offset_pair_list)
  : CALFAbsAnnotVal(false), _frefid_offset_pair_list(frefid_offset_pair_list)
{
  _val_type = CALFAbsAnnotVal::ADDRESS;
  // Do nothing
}

CALFAbsAnnotValAddress::
~CALFAbsAnnotValAddress()
{
  if(_frefid_offset_pair_list) {
    for(list<CFRefIdOffsetPair *>::iterator frefid_offset_pair = _frefid_offset_pair_list->begin();
        frefid_offset_pair != _frefid_offset_pair_list->end(); frefid_offset_pair++)
      delete (*frefid_offset_pair);
    delete _frefid_offset_pair_list;
  }
}

// For checking if two values are equal
bool
CALFAbsAnnotValAddress::
IsEqual(const CALFAbsAnnotVal* val) const {
    // Are they both TOP_ADDRESS?
  if (IsTOP_ADDRESS() and val->IsTOP_ADDRESS()) return true;
    // Check if they are of the same type
  if (!val->IsType(CALFAbsAnnotVal::ADDRESS)) return false;
    // Downcast
  const CALFAbsAnnotValAddress* val_as_address = dynamic_cast<const CALFAbsAnnotValAddress*>(val);
  assert(val_as_address);
  
    // Check attributes of the two values
  assert (FRefIdOffsetPairList()->size() == 1); // If size > 1, sorting of FRefIdOffsetPairs has to be done
  if (FRefIdOffsetPairList()->size() != val_as_address->FRefIdOffsetPairList()->size()) return false;
  list<CFRefIdOffsetPair *>::const_iterator fiop2 = val_as_address->FRefIdOffsetPairList()->begin();
  for(list<CFRefIdOffsetPair *>::iterator fiop1 = _frefid_offset_pair_list->begin();
      fiop1 != _frefid_offset_pair_list->end(); fiop1++, fiop2++) {
    if (((*fiop1)->FRefId() != (*fiop2)->FRefId()) or ((*fiop1)->Offset_L() != (*fiop2)->Offset_L())
        or ((*fiop1)->Offset_U() != (*fiop2)->Offset_U()) or ((*fiop1)->Key() != (*fiop2)->Key())) return false;
  }
    // All values are equal, return true
  return true;
}

// Eliminate duplicates in the annotation.
void
CALFAbsAnnotValAddress::
Eliminate_Duplicates(void) const
{
  for(list<CFRefIdOffsetPair *>::iterator fiop1 = _frefid_offset_pair_list->begin();
      fiop1 != _frefid_offset_pair_list->end(); fiop1++) {
    for(list<CFRefIdOffsetPair *>::iterator fiop2 = fiop1;
        fiop2 != _frefid_offset_pair_list->end();) {
        // Skip the first
      if (fiop2 == fiop1) {
        fiop2++;
      } else {
        if (((*fiop1)->FRefId() == (*fiop2)->FRefId()) and ((*fiop1)->Offset_L() == (*fiop2)->Offset_L()) and
            ((*fiop1)->Offset_U() == (*fiop2)->Offset_U()) and ((*fiop1)->Key() == (*fiop2)->Key())) {
          fiop2 = _frefid_offset_pair_list->erase(fiop2);
        } else {
          fiop2++;
        }
      }
    }
  }  
}

const list<CFRefIdOffsetPair *> *
CALFAbsAnnotValAddress::
FRefIdOffsetPairList() const
{
  return _frefid_offset_pair_list;
}

// Get keys in value
void 
CALFAbsAnnotValAddress::
GetKeys(set<int> * keys)
{
  if(!IsTOP_ADDRESS()) {
    for(list<CFRefIdOffsetPair *>::iterator fop = _frefid_offset_pair_list->begin();
        fop != _frefid_offset_pair_list->end(); fop++) {
      keys->insert((*fop)->Key());
    }
  }
}

CALFAbsAnnotValAddress *
CALFAbsAnnotValAddress::
Copy() const
{
  if(IsTOP_ADDRESS()) {
    return new CALFAbsAnnotValAddress();
  }
  else {
    assert(_frefid_offset_pair_list);
    // Copy the list
    list<CFRefIdOffsetPair *> * new_list  = new list<CFRefIdOffsetPair *>();
    for(list<CFRefIdOffsetPair *>::iterator frefid_offset_pair = _frefid_offset_pair_list->begin();
        frefid_offset_pair != _frefid_offset_pair_list->end(); frefid_offset_pair++) {
      new_list->push_back((*frefid_offset_pair)->Copy());
    }
    // Return the new fref
    return new CALFAbsAnnotValAddress(new_list);
  }
} 

std::ostream & 
CALFAbsAnnotValAddress::
Print(std::ostream & o) const
{
  if(IsTOP_ADDRESS()) {
    o << "TOP_ADDRESS";
  } 
  else {
    o << "ADDR ";
    assert(_frefid_offset_pair_list);
    for(list<CFRefIdOffsetPair *>::iterator fop = _frefid_offset_pair_list->begin();
        fop != _frefid_offset_pair_list->end(); /* intentionally empty */) {
      (*fop)->Print(o);
      fop++;
      if(fop != _frefid_offset_pair_list->end())
        o << " OR ";
    }
  }
  return o;
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotValLabel
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------


CALFAbsAnnotValLabel::
CALFAbsAnnotValLabel()
  : CALFAbsAnnotVal(true), _lrefid_offset_pair_list(NULL)
{
  _val_type = CALFAbsAnnotVal::LABEL;
  // Do nothing
}

CALFAbsAnnotValLabel::
CALFAbsAnnotValLabel(list<CLRefIdOffsetPair *> * lrefid_offset_pair_list)
  : CALFAbsAnnotVal(false), _lrefid_offset_pair_list(lrefid_offset_pair_list)
{
  _val_type = CALFAbsAnnotVal::LABEL;
  // Do nothing
}

CALFAbsAnnotValLabel::
~CALFAbsAnnotValLabel()
{
  if(_lrefid_offset_pair_list) {
    for(list<CLRefIdOffsetPair *>::iterator lrefid_offset_pair = _lrefid_offset_pair_list->begin();
        lrefid_offset_pair != _lrefid_offset_pair_list->end(); lrefid_offset_pair++)
      delete (*lrefid_offset_pair);
    delete _lrefid_offset_pair_list;
  }
}

// For checking if two values are equal
bool
CALFAbsAnnotValLabel::
IsEqual(const CALFAbsAnnotVal* val) const {
    // Are they both TOP?
  if (IsTOP_LABEL() and val->IsTOP_LABEL()) return true;
    // Check if they are of the same type
  if (!val->IsType(CALFAbsAnnotVal::LABEL)) return false;
    // Downcast
  const CALFAbsAnnotValLabel* val_as_label = dynamic_cast<const CALFAbsAnnotValLabel*>(val);
    assert(val_as_label);
   
    // Check attributes of the two values
  if (LRefIdOffsetPairList()->size() != val_as_label->LRefIdOffsetPairList()->size()) return false;
  assert (LRefIdOffsetPairList()->size() == 1); // If size > 1, sorting of LRefIdOffsetPairs has to be done
  list<CLRefIdOffsetPair *>::const_iterator liop2 = val_as_label->LRefIdOffsetPairList()->begin();
  for(list<CLRefIdOffsetPair *>::iterator liop1 = _lrefid_offset_pair_list->begin();
      liop1 != _lrefid_offset_pair_list->end(); liop1++, liop2++) {
    if (((*liop1)->LRefId() != (*liop2)->LRefId()) or ((*liop1)->Offset() != (*liop2)->Offset()) or ((*liop1)->Key() != (*liop2)->Key())) return false;
  }
    // All values are equal, return true
  return true;
}

// Eliminate duplicates in the annotation.
void
CALFAbsAnnotValLabel::
Eliminate_Duplicates(void) const
{
  for(list<CLRefIdOffsetPair *>::iterator liop1 = _lrefid_offset_pair_list->begin();
      liop1 != _lrefid_offset_pair_list->end(); liop1++) {
    for(list<CLRefIdOffsetPair *>::iterator liop2 = liop1;
        liop2 != _lrefid_offset_pair_list->end();) {
        // Skip the first
      if (liop2 == liop1) {
        liop2++;
      } else {
        if (((*liop1)->LRefId() == (*liop2)->LRefId()) and ((*liop1)->Offset() == (*liop2)->Offset()) and ((*liop1)->Key() == (*liop2)->Key())) {
          liop2 = _lrefid_offset_pair_list->erase(liop2);
        } else {
          liop2++;
        }
      }
    }
  }
}

const list<CLRefIdOffsetPair *> * 
CALFAbsAnnotValLabel::
LRefIdOffsetPairList() const
{
  return _lrefid_offset_pair_list;
}

// Get keys in value
void 
CALFAbsAnnotValLabel::
GetKeys(set<int> * keys)
{
  if(!IsTOP_LABEL()) {
    for(list<CLRefIdOffsetPair *>::iterator fop = _lrefid_offset_pair_list->begin();
        fop != _lrefid_offset_pair_list->end(); fop++) {
      keys->insert((*fop)->Key());
    }
  }
}

CALFAbsAnnotValLabel *
CALFAbsAnnotValLabel::
Copy() const
{
  if(IsTOP_LABEL()) {
    return new CALFAbsAnnotValLabel();
  }
  else {
    assert(_lrefid_offset_pair_list);
    // Copy the list
    list<CLRefIdOffsetPair *> * new_list = new list<CLRefIdOffsetPair *>();;
    for(list<CLRefIdOffsetPair *>::iterator lop = _lrefid_offset_pair_list->begin();
        lop != _lrefid_offset_pair_list->end(); lop++) {
      new_list->push_back((*lop)->Copy());
    }
    // Return the new lref
    return new CALFAbsAnnotValLabel(new_list);
  }
} 

std::ostream & 
CALFAbsAnnotValLabel::
Print(std::ostream & o) const
{
  if(IsTOP_LABEL()) {
    o << "TOP_LABEL";
  }
  else {
    o << "LABEL ";
    assert(_lrefid_offset_pair_list);
    for(list<CLRefIdOffsetPair *>::iterator lop = _lrefid_offset_pair_list->begin();
        lop != _lrefid_offset_pair_list->end(); /*intentionally empty */) {
      (*lop)->Print(o);
      lop++;
      if(lop != _lrefid_offset_pair_list->end()) {
        if (g_merged_outp_annots) {
          o << " ";
        }
        else {
          o << " OR ";
        }
      }
    }
  }
  return o;
}


// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CFRefIdOffsetPair
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CFRefIdOffsetPair::
CFRefIdOffsetPair(std::string frefid, int64_t offset)
  : _frefid(frefid), _offset_L(offset), _offset_U(offset), _key(0)
{
  // Do nothing
}

CFRefIdOffsetPair::
CFRefIdOffsetPair(std::string frefid, int64_t offset_L, int64_t offset_U)
: _frefid(frefid), _offset_L(offset_L), _offset_U(offset_U), _key(0)
{
    // Do nothing
}

CFRefIdOffsetPair::
~CFRefIdOffsetPair()
{
  // Do nothing
}

CFRefIdOffsetPair *
CFRefIdOffsetPair::
Copy() const
{
  CFRefIdOffsetPair * new_pair = new CFRefIdOffsetPair(_frefid, _offset_L, _offset_U);
  new_pair->SetKey(_key);
  return new_pair;
}

std::ostream & 
CFRefIdOffsetPair::
Print(std::ostream & o) const
{
  if ((_offset_L == _offset_U) && (_offset_L == 0)) {
    o << "\"" << _frefid << "\"";
  } else if (_offset_L == _offset_U) {
    o << "\"" << _frefid << "\" " << _offset_L;
  } else {
    o << "\"" << _frefid << "\" " << _offset_L << " " << _offset_U;
  }
  return o;
}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CLRefIdOffsetPair
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CLRefIdOffsetPair::
CLRefIdOffsetPair(std::string lrefid, int64_t offset)
  : _lrefid(lrefid), _offset(offset), _key(0)
{
  // Do nothing
}

CLRefIdOffsetPair::
~CLRefIdOffsetPair()
{
  // Do nothing
}

CLRefIdOffsetPair *
CLRefIdOffsetPair::
Copy() const
{
  CLRefIdOffsetPair * new_pair = new CLRefIdOffsetPair(_lrefid, _offset);
  new_pair->SetKey(_key);
  return new_pair;
}

std::ostream & 
CLRefIdOffsetPair::
Print(std::ostream & o) const
{
  o << _lrefid;
  if (_offset != 0) o << " " << _offset;
  return o;
}


// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFAbsAnnotStorage
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

CALFAbsAnnotStorage::
CALFAbsAnnotStorage(CALFAbsAnnotList * annot_list)
  : _prog_entry_annot(NULL)
{  
  // Remember the list
  _annot_list = annot_list;

  // Loop through all annots and add them to the right data structures
  // (but not to the list)
  for(list<CALFAbsAnnot *>::iterator absann = annot_list->begin(); 
      absann != annot_list->end(); absann++) {
    AddALFAbsAnnot(*absann, false);
  }
}

CALFAbsAnnotStorage::
~CALFAbsAnnotStorage()
{
  // Delete the CALFAbsAnnotList list (which will delete all included annots)
  delete _annot_list;

  // Delete the node entry annots and the map
  map<alf::AStmt *, list<CALFAbsAnnot *> *>::iterator s2ea;
  for(map<const alf::AStmt *, list<CALFAbsAnnot *> *>::iterator s2ea = _stmt_to_entry_annots_map.begin();
      s2ea != _stmt_to_entry_annots_map.end(); s2ea++) {
    list<CALFAbsAnnot *> * annots = (*s2ea).second;
    // Since all annots are deleted when deleting the _annot_list we
    // only need to delete the list but not the annot
    delete annots;
  }
  
  // Delete the node exit annots and the map
  for(map<const alf::AStmt *, list<CALFAbsAnnot *> *>::iterator s2ea = _stmt_to_exit_annots_map.begin();
      s2ea != _stmt_to_exit_annots_map.end(); s2ea++) {
    list<CALFAbsAnnot *> * annots = (*s2ea).second;
    // Since all annots are deleted when deleting the _annot_list we
    // only need to delete the list but not the annot
    delete annots;
  }
}

void
CALFAbsAnnotStorage::
AddALFAbsAnnot(CALFAbsAnnot * annot)
{
  // Add the annot to the datastructures and to the list
  AddALFAbsAnnot(annot, true);
}

void
CALFAbsAnnotStorage::
AddALFAbsAnnot(CALFAbsAnnot * absann, bool add_to_list)
{
  // ---------------------------------
  // Add to list if needed
  // ---------------------------------
  if(add_to_list) {
    _annot_list->push_back(absann);
  }

  // ---------------------------------
  // Entry Prog annotation
  // ---------------------------------
  if(absann->Position()->IsType(CALFAbsAnnotPosition::PROG_ENTRY)) {
    _prog_entry_annot = absann;
  }
  
  // ---------------------------------
  // Entry Func annotation
  // ---------------------------------
  else if(absann->Position()->IsType(CALFAbsAnnotPosition::FUNC_ENTRY)) {      
    const alf::CFuncTuple * func = absann->GetFunc();
    assert(func);
    _func_to_entry_annot_map[func] = absann;
  }

  // ---------------------------------
  // Entry Stmt annotation
  // ---------------------------------
  else if(absann->Position()->IsType(CALFAbsAnnotPosition::STMT_ENTRY)) {
    const alf::AStmt* stmt = absann->GetStmt();
    assert(stmt);
    if(_stmt_to_entry_annots_map.find(stmt) == _stmt_to_entry_annots_map.end()) {
      // No annot list existed for node, create one and add node
      _stmt_to_entry_annots_map[stmt] = new list<CALFAbsAnnot *>();
      _stmt_to_entry_annots_map[stmt]->push_back(absann);
    }
    else {
      // Annot list existed for node, make sure that annot is processed last
      _stmt_to_entry_annots_map[stmt]->push_back(absann);
    }
  }

  // ---------------------------------
  // Exit Stmt annotation
  // ---------------------------------
  else if(absann->Position()->IsType(CALFAbsAnnotPosition::STMT_EXIT)) {
    const alf::AStmt* stmt = absann->GetStmt();
    assert(stmt);
    assert(_stmt_to_exit_annots_map.find(stmt) == _stmt_to_exit_annots_map.end());
    // Add list for node to exit map
    _stmt_to_exit_annots_map[stmt] = new list<CALFAbsAnnot *>();
    _stmt_to_exit_annots_map[stmt]->push_back(absann);
  }

  // ---------------------------------
  // When called annotation
  // ---------------------------------
  else if(absann->Position()->IsType(CALFAbsAnnotPosition::WHEN_CALLED)) {
    const CALFAbsAnnotPositionWhenCalled * when_called_absann_position = 
      dynamic_cast<const CALFAbsAnnotPositionWhenCalled *>(absann->Position());
    std::string func_name = when_called_absann_position->Func();
    _func_name_to_when_called_annots_map[func_name] = absann;
  }

  // ---------------------------------
  // Volatile annotation
  // ---------------------------------
  else if(absann->Position()->IsType(CALFAbsAnnotPosition::VOLATILE)) {
    _volatile_annots.push_back(absann);
  }
  else { 
    assert(0);
  }
    
}

// ---------------------------------
// Program entry 
// ---------------------------------

// To test and get the prog entry annot
bool 
CALFAbsAnnotStorage::
HasProgEntryALFAbsAnnot() const
{
  return (_prog_entry_annot != NULL);
}


CALFAbsAnnot *
CALFAbsAnnotStorage::
GetProgEntryALFAbsAnnot() const
{
  return _prog_entry_annot;
}

// ---------------------------------
// Func entry 
// ---------------------------------

// To test and get the prog entry annot
bool 
CALFAbsAnnotStorage::
HasFuncEntryALFAbsAnnot(alf::CFuncTuple * func) const
{
  return (_func_to_entry_annot_map.find(func) != _func_to_entry_annot_map.end());
}


CALFAbsAnnot *
CALFAbsAnnotStorage::
GetFuncEntryALFAbsAnnot(alf::CFuncTuple * func) 
{
  return _func_to_entry_annot_map[func];
}

bool 
CALFAbsAnnotStorage::
HasFuncEntryALFAbsAnnot(CFlowGraph * func) const
{
  alf::CFuncTuple * ftuple = dynamic_cast<alf::CFuncTuple *>(func->Function());
  return HasFuncEntryALFAbsAnnot(ftuple);
}

CALFAbsAnnot *
CALFAbsAnnotStorage::
GetFuncEntryALFAbsAnnot(CFlowGraph * func) 
{
  alf::CFuncTuple * ftuple = dynamic_cast<alf::CFuncTuple *>(func->Function());
  return GetFuncEntryALFAbsAnnot(ftuple);
}

// ---------------------------------
// Stmt or node entry
// ---------------------------------

bool 
CALFAbsAnnotStorage::
HasStmtEntryALFAbsAnnot(alf::AStmt * stmt) const
{
  return (_stmt_to_entry_annots_map.find(stmt) != _stmt_to_entry_annots_map.end());
}

list<CALFAbsAnnot *> * 
CALFAbsAnnotStorage::
GetStmtEntryALFAbsAnnot(alf::AStmt * stmt) 
{
  if(_stmt_to_entry_annots_map.find(stmt) != _stmt_to_entry_annots_map.end())
    return _stmt_to_entry_annots_map[stmt];
  else
    return NULL;
}

bool 
CALFAbsAnnotStorage::
HasNodeEntryALFAbsAnnot(CFlowGraphNode * node) const
{
  alf::AStmt * stmt = dynamic_cast<alf::AStmt *>(node->Stmt());
  return HasStmtEntryALFAbsAnnot(stmt);
}

list<CALFAbsAnnot *> * 
CALFAbsAnnotStorage::
GetNodeEntryALFAbsAnnot(CFlowGraphNode * node) 
{
  alf::AStmt * stmt =  dynamic_cast<alf::AStmt *>(node->Stmt());
  return GetStmtEntryALFAbsAnnot(stmt);
}

bool 
CALFAbsAnnotStorage::
HasNodeEntryALFAbsAnnot(CECFGNode * node) const
{
  return HasNodeEntryALFAbsAnnot(node->GetFlowGraphNode());
}

list<CALFAbsAnnot *> *  
CALFAbsAnnotStorage::
GetNodeEntryALFAbsAnnot(CECFGNode * node)
{
  return GetNodeEntryALFAbsAnnot(node->GetFlowGraphNode());
}

// ---------------------------------
// Stmt or node exit
// ---------------------------------

bool 
CALFAbsAnnotStorage::
HasStmtExitALFAbsAnnot(alf::AStmt * stmt) const
{
  return (_stmt_to_exit_annots_map.find(stmt) != _stmt_to_exit_annots_map.end());
}

list<CALFAbsAnnot *> * 
CALFAbsAnnotStorage::
GetStmtExitALFAbsAnnot(alf::AStmt * stmt) 
{
  if(_stmt_to_exit_annots_map.find(stmt) != _stmt_to_exit_annots_map.end())
    return _stmt_to_exit_annots_map[stmt];
  else
    return NULL;
}

bool 
CALFAbsAnnotStorage::
HasNodeExitALFAbsAnnot(CFlowGraphNode * node) const
{
  alf::AStmt * stmt =  dynamic_cast<alf::AStmt *>(node->Stmt());
  return HasStmtExitALFAbsAnnot(stmt);
}

list<CALFAbsAnnot *> * 
CALFAbsAnnotStorage::
GetNodeExitALFAbsAnnot(CFlowGraphNode * node) 
{
  alf::AStmt * stmt =  dynamic_cast<alf::AStmt *>(node->Stmt());
  return GetStmtExitALFAbsAnnot(stmt);
}

bool 
CALFAbsAnnotStorage::
HasNodeExitALFAbsAnnot(CECFGNode * node) const
{
  return HasNodeExitALFAbsAnnot(node->GetFlowGraphNode());
}

list<CALFAbsAnnot *> *  
CALFAbsAnnotStorage::
GetNodeExitALFAbsAnnot(CECFGNode * node)
{
  return GetNodeExitALFAbsAnnot(node->GetFlowGraphNode());
}

// ---------------------------------
// Volatile annots
// ---------------------------------
bool 
CALFAbsAnnotStorage::
HasVolatileAbsAnnots() const
{
  return _volatile_annots.size() != 0;
}

list<CALFAbsAnnot *> *
CALFAbsAnnotStorage::
GetVolatileAbsAnnots()
{
  return &_volatile_annots;
}

// ---------------------------------
// When called annots
// ---------------------------------
bool 
CALFAbsAnnotStorage::
HasWhenCalledAlfAbsAnnots(alf::CFuncTuple * func) const
{
  std::string func_name = func->Name();
  return HasWhenCalledAlfAbsAnnots(func_name);
} 

CALFAbsAnnot *
CALFAbsAnnotStorage::
GetWhenCalledAlfAbsAnnots(alf::CFuncTuple * func) 
{
  std::string func_name = func->Name();
  return GetWhenCalledAlfAbsAnnots(func_name);
}

bool 
CALFAbsAnnotStorage::
HasWhenCalledAlfAbsAnnots(CFlowGraph * fg) const
{
  std::string func_name = fg->Function()->Name();
  return HasWhenCalledAlfAbsAnnots(func_name);
} 

CALFAbsAnnot *
CALFAbsAnnotStorage::
GetWhenCalledAlfAbsAnnots(CFlowGraph * fg) 
{
  std::string func_name = fg->Function()->Name();
  return GetWhenCalledAlfAbsAnnots(func_name);
} 

bool 
CALFAbsAnnotStorage::
HasWhenCalledAlfAbsAnnots(std::string func_name) const
{
  return _func_name_to_when_called_annots_map.find(func_name) != _func_name_to_when_called_annots_map.end();
} 

CALFAbsAnnot *
CALFAbsAnnotStorage::
GetWhenCalledAlfAbsAnnots(std::string func_name) 
{
  map<std::string, CALFAbsAnnot *>::iterator fn2a = _func_name_to_when_called_annots_map.find(func_name);
  if(fn2a != _func_name_to_when_called_annots_map.end())
    return (*fn2a).second;
  else
    return NULL;
} 

const CALFAbsAnnotList * 
CALFAbsAnnotStorage::
GetAbsAnnotList() const
{
  return _annot_list;
}

void
CALFAbsAnnotStorage::
GetDefAddressesPairs(set<pair<int,set<int> > > * def_addresses_pairs) const
{
  // Loop through all annots and add their def addresses pairs 
  for(list<CALFAbsAnnot *>::iterator absann = _annot_list->begin(); 
      absann != _annot_list->end(); absann++) {
    (*absann)->GetDefAddressesPairs(def_addresses_pairs);
  }
}

void
CALFAbsAnnotStorage::
GetDefs(set<int> * defs) const
{
  // Loop through all annots and add their addresses 
  for(list<CALFAbsAnnot *>::iterator absann = _annot_list->begin(); 
      absann != _annot_list->end(); absann++) {
    (*absann)->GetDefs(defs);
  }
}

void
CALFAbsAnnotStorage::
GetAddresses(set<int> * defs) const
{
  // Loop through all annots and add their defs
  for(list<CALFAbsAnnot *>::iterator absann = _annot_list->begin(); 
      absann != _annot_list->end(); absann++) {
    (*absann)->GetAddresses(defs);
  }
}

void
CALFAbsAnnotStorage::
GetDefsAndAddresses(set<int> * defs_and_addresses) const
{
  // Loop through all annots and add their defs and addresses 
  for(list<CALFAbsAnnot *>::iterator absann = _annot_list->begin(); 
      absann != _annot_list->end(); absann++) {
    (*absann)->GetDefsAndAddresses(defs_and_addresses);
  }
}

// To print all the abstract annotation assignments
std::ostream & 
CALFAbsAnnotStorage::
Print(std::ostream & o) const
{
  // Print program entry annot
  if(HasProgEntryALFAbsAnnot()) {
    o << "  PROGRAM ENTRY ANNOT: " << endl;
    o << "    " << *(GetProgEntryALFAbsAnnot());
    o << endl;
  }

  // Printy the func entry annots
  if(_func_to_entry_annot_map.size() > 0) {
    o << "  STMT FUNC ANNOTS: " << endl; 
    for(map<const alf::CFuncTuple *, CALFAbsAnnot *>::const_iterator f2a = _func_to_entry_annot_map.begin();
        f2a != _func_to_entry_annot_map.end(); f2a++) {
      const alf::CFuncTuple * func = (*f2a).first;
      CALFAbsAnnot * annot = (*f2a).second;
      o << "    " << func->Name() << ": " << *annot << endl;
    }
  }

  // Print node entry annots if any (includes the func entry annots)
  if(_stmt_to_entry_annots_map.size() > 0) {
    o << "  STMT ENTRY ANNOTS: " << endl; 
    for(map<const alf::AStmt *, list<CALFAbsAnnot *> *>::const_iterator s2ea = _stmt_to_entry_annots_map.begin();
        s2ea != _stmt_to_entry_annots_map.end(); s2ea++) {
      const alf::AStmt * stmt = (*s2ea).first;
      list<CALFAbsAnnot *> * annots = (*s2ea).second;
      o << "    " << stmt->Name() << ": " << endl;
      for(list<CALFAbsAnnot *>::const_iterator annot = annots->begin(); annot != annots->end(); annot++) {
        o << "       " << *(*annot) << endl;
      }
    }
  }

  // Print node exit annots if any (includes the func entry annots)
  if(_stmt_to_exit_annots_map.size() > 0) {
    o << "  STMT EXIT ANNOTS: " << endl; 
    for(map<const alf::AStmt *, list<CALFAbsAnnot *> *>::const_iterator s2ea = _stmt_to_exit_annots_map.begin();
        s2ea != _stmt_to_exit_annots_map.end(); s2ea++) {
      const alf::AStmt * stmt = (*s2ea).first;
      list<CALFAbsAnnot *> * annots = (*s2ea).second;
      o << "    " << stmt->Name() << ": " << endl;
      for(list<CALFAbsAnnot *>::const_iterator annot = annots->begin(); annot != annots->end(); annot++) {
        o << "       " << *(*annot) << endl;
      }
    }
  }

  return o;
}
