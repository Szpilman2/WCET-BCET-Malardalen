// -------------------------------------------------------
// This file holds help classes for storing ALF output value
// assignments specifications.  Classes declared will be used as a temporary storage
// before inserted into the ALF CFG. The CALFOutAnnotSpecList is the 
// return value of the ALF output value annotation specification parser.
// 
// Author: jan.gustafsson@mdh.se
// -------------------------------------------------------

#ifndef CALFOUTANNOTSPEC_H
#define CALFOUTANNOTSPEC_H

#include <list>
#include <string>
#include <iostream>
#include <stdint.h>
#include "graphs/cfg/CFlowGraph.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CFuncTuple.h"
#include "program/alf/CAllocTuple.h"
#include "program/alf/CDeclList.h"
#include "program/alf/CArgDeclList.h"
#include "program/alf/CScopeTuple.h"
#include "program/alf/CGenericNode.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/ecfg/CECFGNode.h"
#include "absann/CALFAbsAnnot.h"

#include <sstream>

using namespace std;

// Predefinition of classes
class CALFOutAnnotSpecList;
class CALFOutAnnotSpec;
class CALFOutAnnotSpecPosition;
class CALFOutAnnotSpecPositionStmtEntry;
class CALFOutAnnotSpecPositionStmtExit;
class CALFOutAnnotSpecVar;
class CALFOutAnnotSpecStorage;

template <typename> class EInt;
typedef EInt<unsigned long long> Size;


// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// To open the file and read the abstract ALF value assignment
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

class CReadALFOutAnnotSpecsAndCreateALFOutAnnots
{
public:
  // To create and delete the object
  CReadALFOutAnnotSpecsAndCreateALFOutAnnots();
  virtual ~CReadALFOutAnnotSpecsAndCreateALFOutAnnots();
  
  // Run the algorithm. Returns NULL if not successful.
  CALFOutAnnotSpecStorage * Run(string out_ann_spec_filename, const alf::CAlfTuple * alf_tuple);

protected:

  // To read annotations from a given file. Returns true if successful.
  bool ReadOutAnnotSpecsFromFile(string filename, CALFOutAnnotSpecList ** out_annot_spec_list);

  // Check that the read annotations can be added to ALF program. Also stores the keys of referenced 
  // frefs and lrefs in the annots. Returns true if successful.
  bool CheckOutAnnotSpecsAndSetKeys(CALFOutAnnotSpecList * out_annot_spec_list, const alf::CAlfTuple * alf_tuple);

  // Help functions
  bool CheckOverlappingAnnots(CALFOutAnnotSpecList * out_annot_spec_list, ostringstream & error_msg);
  bool CheckOkToAddAndSetKeysAndStmt(CALFOutAnnotSpecList * out_annot_spec_list, const alf::CAlfTuple * alf_tuple, ostringstream & error_msg);

};

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// Output annotation specification list class
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

// ---------------------------------
// CALFOutAnnotSpecList -
// A list of ALF output annotation specifications. Return value of 
// the parser.
// ---------------------------------
class CALFOutAnnotSpecList : public list<CALFOutAnnotSpec *> 
{
public:
  // To create and delete the content of the list
  CALFOutAnnotSpecList();
  virtual ~CALFOutAnnotSpecList();
  
  // To print the content of the list
  std::ostream & Print(std::ostream & o = std::cout) const;
};

inline std::ostream & operator <<(std::ostream & o, const CALFOutAnnotSpecList & a) {return a.Print(o);}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// CALFOutAnnotSpec class
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
 
// ---------------------------------
// CALFOutAnnotSpec -
// A single ALF output annotation specification. Created by the parser. 
// ---------------------------------
class CALFOutAnnotSpec 
{
public:

  // To create and delete an ALF output annotation specification
  CALFOutAnnotSpec(const CALFOutAnnotSpecPosition * position, list<CALFOutAnnotSpecVar *> * var_list);
  virtual ~CALFOutAnnotSpec();

  // To get content of ALF output annotation specification
  const CALFOutAnnotSpecPosition * Position() const;
  const list<CALFOutAnnotSpecVar *> * VarList() const;

  // To print the output annotation specification
  std::ostream & Print(std::ostream & o = std::cout) const;

  // Checks that the entities in the annotation, such as function
  // names and variable names, really exists in the program and in the
  // given context. Also check that no all values are stored within
  // given frame borders. Prints error messages if erroneous annotation.
  // Returns true if no errors were found.
  bool CheckOkToAddAndSetKeysAndStmt(const alf::CAlfTuple *alf_tuple, ostringstream & error_msg);

  // To set and get the CFG node it refers to. Will be NULL for PROG_ENTRY annots
  void SetStmt(alf::AStmt * stmt) { _stmt = stmt; }
  const alf::AStmt * GetStmt() { assert(_stmt); return _stmt; }
  const alf::CFuncTuple * GetFunc() { assert(_stmt); return dynamic_cast<const alf::CFuncTuple *>(_stmt->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE)); }

  // To copy the annotation
  CALFOutAnnotSpec * Copy() const;
  
  bool DeclaresFRefIdInCurrentOrParentScopesOrGlobalScopeOrImports(const alf::CAlfTuple *alf_tuple,
                                                                   const alf::CScopeTuple* scope,
                                                                   std::string frefid, Size * frame_size, unsigned int * key);

protected:
  bool HasFRefIdInDecls(const alf::CDeclList * decls, std::string frefid, Size * frame_size, unsigned int * key);
  bool HasFRefIdInArgDecls(const alf::CArgDeclList * decls, std::string frefid, Size * frame_size, unsigned int * key);
  bool HasFRefIdInImports(const alf::CImportsTuple* imports, std::string frefid, Size * frame_size, unsigned int * key);
  bool HasFRefIdInGlobalDeclsOrImports(const alf::CAlfTuple * program, std::string frefid, Size * frame_size, unsigned int * key);
  bool HasFRefIdInDeclsOrImports(const alf::CDeclList * decls, const alf::CImportsTuple* imports, std::string frefid, Size * frame_size, unsigned int * key);
  
  // Internal pointers
  unsigned _line_no;
  const CALFOutAnnotSpecPosition * _position;
  list<CALFOutAnnotSpecVar * > * _var_list;
  alf::AStmt * _stmt;

};

inline std::ostream & operator <<(std::ostream & o, const CALFOutAnnotSpec & a) {return a.Print(o);}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// Position classes
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

// ---------------------------------
// CALFOutAnnotSpecPosition
// ---------------------------------
class CALFOutAnnotSpecPosition 
{
public:
  // Enum holding the type of positions that exists
  CALFOutAnnotSpecPosition(CALFAbsAnnotPosition::PositionType position_type, std::string func, std::string lrefid, uint64_t loffs);
  virtual ~CALFOutAnnotSpecPosition();
   
  // Access functions
  virtual CALFAbsAnnotPosition::PositionType Type() const;
  virtual std::string Func() const;
  virtual std::string LRefId() const;
  virtual uint64_t LOffs() const;

  // To check what subtype it is
  bool IsType(CALFAbsAnnotPosition::PositionType position_type) const { return _position_type == position_type; } 

  // To check if two positions are equal
  virtual bool IsEqual(const CALFOutAnnotSpecPosition * other) const;

  // To print the position
  virtual std::ostream & Print(std::ostream & o = std::cout) const;

  // To copy the position 
  virtual CALFOutAnnotSpecPosition * Copy() const;

protected:
  // Internal vars
  CALFAbsAnnotPosition::PositionType _position_type;  
  std::string _func;
  std::string _lrefid;
  uint64_t _loffs;
};

inline std::ostream & operator <<(std::ostream & o, const CALFOutAnnotSpecPosition & a) {return a.Print(o);}

// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
// Variable classes
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

// ---------------------------------
// CALFOutAnnotSpecVar -
// Holds variable ref where to store the value 
// ---------------------------------
class CALFOutAnnotSpecVar
{
public:
  // Create and delete. The foffs is given in bits.
  CALFOutAnnotSpecVar( std::string frefid );
  CALFOutAnnotSpecVar( std::string frefid, uint64_t foffs_in_bits );
  CALFOutAnnotSpecVar( std::string frefid, uint64_t foffs_in_bits, Size size_in_bits );
  virtual ~CALFOutAnnotSpecVar() {};

  // Access functions
  void SetFRefId(std::string);
  std::string FRefId() const;

  // If no offset was given then fOffs is equal to 0. 
  bool HasFOffs() const;
  uint64_t FOffsInBits() const;
  void SetFOffsInBits(uint64_t foffs);
  uint64_t FOffsInLAU() const;
  void SetFOffsInLAU(uint64_t foffs);
  // If no size in bits has been given it will be set to the size of
  // the whole frame after check code. If SizeInBits is called without
  bool HasSizeInBits() const;
  Size SizeInBits() const;
  void SetSizeInBits(Size size_in_bits);
  // To get the number of repeats. If not set 1 will be returned.
  bool HasRepeat() const;
  uint64_t Repeat() const;
  void SetRepeat(uint64_t foffs);

  // To set and get the global key of the fref with the given id.
  void SetKey(unsigned int key) { _key = key; _has_key = true; };
  bool HasKey() { return _has_key; }
  unsigned int GetKey() { return _key;}

  // To print the variable
  std::ostream & Print(std::ostream & o = std::cout) const;

  // To make a deep copy of the variable
  virtual CALFOutAnnotSpecVar * Copy() const;

  // To get if the variable is of RET_VAL type
  virtual bool IsReturnValueVar() const { return false; }
  
protected:
  // Internal vars
  std::string _frefid;
  bool _has_foffs;
  uint64_t _foffs_in_bits;
  bool _has_size_in_bits;
  Size _size_in_bits;
  unsigned int _key; 
  bool _has_key;
};

inline std::ostream & operator <<(std::ostream & o, const CALFOutAnnotSpecVar & a) {return a.Print(o);}


// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------
//  CALFOutAnnotSpecStorage
// -------------------------------------------------------
// -------------------------------------------------------
// -------------------------------------------------------

// Class that provides an interface to different analyses for given
// annotations. Each CALFOutAnnotSpec is associated to the entry or exit
// of a stmt or to the entry of the program.
class CALFOutAnnotSpecStorage
{
public:
  // To create and delete the class. The argument list and the annots
  // in the argument list will be owned by the storage.
  CALFOutAnnotSpecStorage(CALFOutAnnotSpecList * out_ann_specs);
  virtual ~CALFOutAnnotSpecStorage();

  // To add an output annotation specification to the storage. The annotations
  // will be sorted and indexed on the nodes to which they should be
  // associated. The annotation will be owned by the storage.
  void AddALFOutAnnotSpec(CALFOutAnnotSpec * out_ann_spec);
  
  // To get the output annotation specifications that should be performed before the
  // given stmt, flow graph node or ecfg node is processed. GetXY
  // returns NULL if no annots exists.
  bool HasStmtEntryALFOutAnnotSpec(alf::AStmt * stmt) const;
  list<CALFOutAnnotSpec *> * GetStmtEntryALFOutAnnotSpec(alf::AStmt * stmt);
  bool HasNodeEntryALFOutAnnotSpec(CFlowGraphNode * node) const;
  list<CALFOutAnnotSpec *> * GetNodeEntryALFOutAnnotSpec(CFlowGraphNode * node);
  bool HasNodeEntryALFOutAnnotSpec(CECFGNode * node) const;
  list<CALFOutAnnotSpec *> * GetNodeEntryALFOutAnnotSpec(CECFGNode * node);

  // To get the output annotation specifications that should be performed after the
  // given stmt, flow graph node or ecfg node is processed. Get func
  // returns NULL if no exit annots exists.
  bool HasStmtExitALFOutAnnotSpec(alf::AStmt * stmt) const;
  list<CALFOutAnnotSpec *> * GetStmtExitALFOutAnnotSpec(alf::AStmt * stmt);
  bool HasNodeExitALFOutAnnotSpec(CFlowGraphNode * node) const;
  list<CALFOutAnnotSpec *> * GetNodeExitALFOutAnnotSpec(CFlowGraphNode * node);
  bool HasNodeExitALFOutAnnotSpec(CECFGNode * node) const;
  list<CALFOutAnnotSpec *> * GetNodeExitALFOutAnnotSpec(CECFGNode * node);

  // To get all output annotation specifications as a list. The list is owned by the storage.
  const CALFOutAnnotSpecList * GetOutAnnotSpecList() const;

  // If we are interested in all frefs that are defined in an annotation. This 
  // includes annotations which do not takes any address of, such as x := 1..10 annots.
  void GetDefs(set<int> * defs) const;
  // If we only are intrested in all frefs and labels whose addresses
  // are used in any annotation
  void GetAddresses(set<int> * addresses) const;
  // The union of GetDefs and GetAddress
  void GetDefsAndAddresses(set<int> * defs_and_addresses) const; 

  // To print the content of the storage
  std::ostream & Print(std::ostream & o = std::cout) const;

protected:

  // Help functions
  void AddALFOutAnnotSpec(CALFOutAnnotSpec * annot, bool add_to_list);

  // Internal pointers
  CALFOutAnnotSpecList * _annot_list;
  map<const alf::AStmt *, list<CALFOutAnnotSpec *> *> _stmt_to_entry_annots_map;
  map<const alf::AStmt *, list<CALFOutAnnotSpec *> *> _stmt_to_exit_annots_map;
};

inline std::ostream & operator <<(std::ostream & o, const CALFOutAnnotSpecStorage & a) {return a.Print(o);}

#endif // CALFOUTANNOTSPEC_H
