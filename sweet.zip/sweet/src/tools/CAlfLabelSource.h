// $Id: $

#ifndef CALF_LABEL_SOURCE_H_INCLUDED
#define CALF_LABEL_SOURCE_H_INCLUDED

#include <string>
#include <ostream>
#include <sstream>

/** \class CAlfLabelSource
   Holds source code information concerning one alf label. */

/** TODO: rename this class: it isn't specific to ALF or "labels" */
class CAlfLabelSource
{
public:
   /** Constructs a CAlfLabelSource
      \param source_code The c source code that generated a certain alf label.
      \param file_name The c source file where to find the c-source.
      \param line_number The line in the c source file where to find the c-source.
      \param column_number The column in the c source file where to find the c-source.
   */
   CAlfLabelSource(std::string source_code, std::string file_name, unsigned line_number, unsigned column_number) :
      source_code(source_code),
      file_name(file_name),
      line_number(line_number),
      column_number(column_number)
      { }

   /** \return The c source code that generated a certain alf label. */
   std::string GetCLine() const { return source_code; }

   /** \return The c source file where to find the c-source. */
   std::string GetFileName() const { return file_name; }

   /** \return The line in the c source file where to find the c-source. */
   unsigned GetLineNumber() const { return line_number; }

   /** \return The column in the c source file where to find the c-source. */
   unsigned GetColumnNumber() const  { return column_number; }

   /** Check if two sources holds eactly the same information */
   bool IsEqual(CAlfLabelSource * other) { return (this == other) || ((other->source_code == source_code) && 
                                                                      (other->file_name == file_name) && 
                                                                      (other->line_number == line_number) &&
                                                                      (other->column_number == column_number)); } 

   /** Compares file name, line number, and column number, in that order */
   bool operator <(const CAlfLabelSource &other) const {
      int fn_rel = this->file_name.compare(other.file_name);
      if (fn_rel < 0) return true;
      if (fn_rel > 0) return false;
      if (this->line_number < other.line_number) return true;
      if (this->line_number > other.line_number) return false;
      return this->column_number < other.column_number;
      // we skip comparing the `source_code' component, which would otherwise be compared last, since if the
      // other components are equal, it is safe to assume that `source_code' is equal too
   }

   /** \returns A string representation of this CAlfLabelSource, using \a delim as field separator */
   std::string ToString(const char delim[] = ":") const {
      std::ostringstream str(file_name, std::ostringstream::ate);
      str << delim << line_number << delim << column_number;
      return str.str();
   }
   
   std::ostream &Print(std::ostream &o, const char delim[] = ":") const {
      return o << file_name << delim << line_number << delim << column_number;
   }

private:
   std::string source_code;
   std::string file_name;
   unsigned line_number;
   unsigned column_number;
};

inline std::ostream& operator <<(std::ostream& o, const CAlfLabelSource& als) { return als.Print(o); }

#endif
