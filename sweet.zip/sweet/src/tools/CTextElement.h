// $Id: CTextElement.h 5125 2013-04-07 22:13:58Z lkg02 $

#ifndef CTEXT_ELEMENT_H_
#define CTEXT_ELEMENT_H_

#include <iostream>
#include <string>

/** \class CTextElement
   A CTextElement is a text component that may hold an indentation count.
*/

class CTextElement : public std::string
{
public:
   typedef enum COLOR {NONE, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, NR_OF_COLORS} COLOR;

   /** Constructs a new text line.
      \param text The text to be hold by this text component.
      \param indent The level of indentation. When printing this line the level will be
         interpreted as \a indent number of spaces.
      \param new_line Indicates if this line should be terminated with a new line or not.
         If \a true there will be a fine new line when printing this line.
   */
   CTextElement(std::string text, unsigned indent=0, bool new_line=false);
   ~CTextElement() {}

   /** \return an integer representing the indentation level.
   */
   int Indentation() const { return _indentation; }

   void SetColor(COLOR color) { _color = color; _has_property = true; }
   void SetBold() { _bold = true; _has_property = true; }

   /** Prints this line prefixed by an identation level according to the
      current indentation of this line, and terminates with a new line if it
      has a new line specified.
      \param o The output media.
      \param current_pos A pointer to the curren print position (the column
         number starting with 0).
      \param width The width of the output media. Text will not be printed
         beyond this edge. A value of 0 indicates an unlimited width.
      \param hide_properties Hide properties
   */
   void PrintIndented(std::ostream &o, unsigned *current_pos, unsigned width, bool hide_properties=false) const;

private:

   void Indent(std::ostream &o, unsigned *current_pos) const;
   void NewLine(std::ostream &o, unsigned *current_pos) const;
   void Wrap(std::ostream &o, unsigned *current_pos) const;

   unsigned _indentation;
   bool _new_line;

   bool _has_property;
   bool _bold;
   COLOR _color;
};

#endif
