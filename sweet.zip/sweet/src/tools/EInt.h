#ifndef EINT_H_INCLUDED
#define EINT_H_INCLUDED

#include <iostream>
#include <cassert>
#include <limits>

/** Extended integer. Adds the possibility to a base integer type (specified by @p BaseIntType)
of representing infinity. */
template <typename BaseIntType> class EInt
{
public:
   EInt() {}
   EInt(const BaseIntType & value) : _value(value) {}

   /// Create an @c EInt<BaseIntType> from some other type EInt
   template <typename T> EInt(const EInt<T> & other);

   /// Return an @c EInt representing infinity
   static EInt Infinity();

   /// Return the value of this extended integer represented in the base integer type
   /// @pre This is not infinity
   const BaseIntType & AsBaseIntType() const;

   bool IsInfinity() const {return _value == InfinityRep();}

   EInt operator -() const;

   EInt operator +(const EInt & y) const;
   EInt operator -(const EInt & y) const;
   EInt operator *(const EInt & y) const;

   /// Integer division operator.
   /// @pre (this != 0 || y != 0) && (this != Infinity() || y != Infinity())
   EInt operator /(const EInt & y) const;

   /// Modulo operator.
   /// @pre this != Infinity(), y != 0, y != Infinity()
   /// @note The implementation of the operation is inherited from the integer base type
   EInt operator %(const EInt & y) const;

   EInt & operator +=(const EInt & y) {*this = *this + y; return *this;}
   EInt & operator -=(const EInt & y) {*this = *this - y; return *this;}
   EInt & operator *=(const EInt & y) {*this = *this * y; return *this;}
   EInt & operator /=(const EInt & y) {*this = *this / y; return *this;}

   bool operator < (const EInt & y) const {return this->_value <  y._value;}
   bool operator <=(const EInt & y) const {return this->_value <= y._value;}
   bool operator ==(const EInt & y) const {return this->_value == y._value;}
   bool operator >=(const EInt & y) const {return this->_value >= y._value;}
   bool operator > (const EInt & y) const {return this->_value >  y._value;}
   bool operator !=(const EInt & y) const {return this->_value != y._value;}

private:
   BaseIntType _value;

   /// Return the @c BaseIntType value used to represent infinity (which is the largest
   /// number representable in the @c BaseIntType type)
   static BaseIntType InfinityRep();
};

// Some convenient typedefs
typedef EInt<int> EIntS;
typedef EInt<unsigned int> EIntU;
typedef EInt<long long> EIntLL;
typedef EInt<unsigned long long> EIntULL;

template <typename BaseIntType>
template <typename T> 
EInt<BaseIntType>::EInt(const EInt<T> & other)
{
   if (other.IsInfinity())
      *this = Infinity();
   else
      _value = static_cast<BaseIntType>(other.AsBaseIntType());
}

template <typename BaseIntType> EInt<BaseIntType> EInt<BaseIntType>::Infinity()
{
   return EInt(InfinityRep());
}

template <typename BaseIntType> const BaseIntType & EInt<BaseIntType>::AsBaseIntType() const
{
   assert(!IsInfinity());
   return _value;
}

template <typename T> EInt<T> EInt<T>::operator -() const
{
   assert(!IsInfinity());
   return EInt<T>(-this->_value);
}

template <typename T> EInt<T> EInt<T>::operator +(const EInt<T> & y) const
{
   if (this->IsInfinity() || y.IsInfinity())
      return EInt<T>::Infinity();
   else
      return this->_value + y._value;
}

template <typename T> EInt<T> EInt<T>::operator -(const EInt<T> & y) const
{
   assert(!y.IsInfinity());
   if (this->IsInfinity())
      return EInt<T>::Infinity();
   else
      return this->_value - y._value;
}

template <typename T> EInt<T> EInt<T>::operator *(const EInt<T> & y) const
{
   if (this->IsInfinity() || y.IsInfinity())
      return EInt<T>::Infinity();
   else
      return this->_value * y._value;
}

template <typename T> EInt<T> EInt<T>::operator /(const EInt<T> & y) const
{
   // The computation 0/0 is not defined
   assert(!(this->_value == 0 && y._value == 0));
   // The computation inf/inf is not defined
   assert(!(this->IsInfinity() && y.IsInfinity()));
   if (this->IsInfinity())
      return EInt<T>::Infinity();
   else if (y.IsInfinity())
      return 0;
   else if (y._value == 0)
      return EInt<T>::Infinity();
   else
      return this->_value / y._value;
}

template <typename T> EInt<T> EInt<T>::operator %(const EInt & y) const
{
   // The computation inf mod y is not defined:
   // inf mod y = inf - y * trunc(inf / y)
   //           = inf - y * trunc(inf)
   //           = inf - y * inf
   //           = inf - inf
   //           = ?
   assert(!this->IsInfinity());
   // The computation this mod 0 is not defined:
   // this mod 0 = this - 0 * trunc(this / 0)
   //            = this - 0 * trunc(inf)
   //            = this - 0 * inf
   //            = this - ?
   //            = ?
   assert(y != 0);
   // The computation this mod inf is not defined:
   // this mod inf = this - inf * trunc(this / inf)
   //              = this - inf * trunc(0)
   //              = this - inf * 0
   //              = this - ?
   //              = ?
   assert(!y.IsInfinity());
   // The definition of modulo used above is based on the trunc() function, and is in some implementations
   // based on, e.g., the floor() function, but the reasoning above still holds in those cases
   return this->_value % y._value;
}

template <typename BaseIntType> BaseIntType EInt<BaseIntType>::InfinityRep()
{
   static const BaseIntType infinity_rep = std::numeric_limits<BaseIntType>::max();
   return infinity_rep;
}

// Non-member functions starts here - - - - - - - - - - - - - -

// The following global functions are used to achieve implicit type conversions from the
// base integer type to an EInt of the left argument as well (while in the member functions this
// is only possible on the right argument)

template <typename T1, typename T2> EInt<T2> operator +(const T1 & x, const EInt<T2> & y)
{
   return EInt<T2>(x) + y;
}

template <typename T1, typename T2> EInt<T2> operator -(const T1 & x, const EInt<T2> & y)
{
   return EInt<T2>(x) - y;
}

template <typename T1, typename T2> EInt<T2> operator *(const T1 & x, const EInt<T2> & y)
{
   return EInt<T2>(x) * y;
}

template <typename T1, typename T2> EInt<T2> operator /(const T1 & x, const EInt<T2> & y)
{
   return EInt<T2>(x) / y;
}

template <typename T1, typename T2> EInt<T2> operator %(const T1 & x, const EInt<T2> & y)
{
   return EInt<T2>(x) % y;
}

template <typename T1, typename T2> bool operator <(const T1 & x, const EInt<T2> & y)
{
   return EInt<T2>(x) < y;
}

template <typename T1, typename T2> bool operator <=(const T1 & x, const EInt<T2> & y)
{
   return EInt<T2>(x) <= y;
}

template <typename T1, typename T2> bool operator ==(const T1 & x, const EInt<T2> & y)
{
   return EInt<T2>(x) == y;
}

template <typename T1, typename T2> bool operator >=(const T1 & x, const EInt<T2> & y)
{
   return EInt<T2>(x) >= y;
}

template <typename T1, typename T2> bool operator >(const T1 & x, const EInt<T2> & y)
{
   return EInt<T2>(x) > y;
}

template <typename T1, typename T2> bool operator !=(const T1 & x, const EInt<T2> & y)
{
   return EInt<T2>(x) != y;
}

template <typename T> inline std::ostream & operator <<(std::ostream & os, const EInt<T> & eint)
{
   if (eint.IsInfinity())
      return os << "inf";
   else
      return os << eint.AsBaseIntType();
}

template <typename T> inline std::istream & operator >>(std::istream & is, EInt<T> & eint)
{
   T value;
   is >> value;
   eint = EInt<T>(value);
   return is;
}

#endif   // EINT_H_INCLUDED
