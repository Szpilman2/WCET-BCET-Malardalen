#include <sstream>
#include <string>
#include <vector>
#include <algorithm>

class TextTable {
public:
   TextTable(const char *col_sep = " ", char row_sep = '\0')
      : table(1), row_sep(row_sep), col_sep(col_sep) {}

   void SetColSep(const char *col_sep) { this->col_sep = col_sep; }
   void SetRowSep(char row_sep) { this->row_sep = row_sep; }

   void Clear() { table.resize(1); table.front().clear(); }

   /** Returns a stream through which text can be written to the current cell.
       @note The current cell is not actually added to the table until
             either NextColumn() or NextRow() are called. */
   std::ostringstream &GetStream() { return stream; }

   /** Shorthand for writing `obj' to the stream returned by GetStream() */
   template <class T> TextTable &operator <<(const T &obj) {
      stream << obj;
      return *this;
   }

   /** Finishes the current cell and starts a new column in the same row */
   void NextColumn() {
      table_type::value_type &back = table.back();
      back.push_back( stream.str() );
      std::string &cell = back.back();
      std::replace(cell.begin(), cell.end(), '\t', ' ');
      stream.str("");
   }

   /** Finishes the current cell and starts a new row */
   void NextRow() {
      NextColumn();
      table.resize(table.size() + 1);
   }

   std::ostream &Print(std::ostream &os) const;

private:
   typedef std::vector<std::vector<std::string> > table_type;

   std::ostringstream stream;
   mutable table_type table;
   char row_sep;
   std::string col_sep;
};

inline std::ostream &operator <<(std::ostream &os, const TextTable &txt_table) {
   return txt_table.Print(os);
}
