#ifndef SIGNALHANDLING_H_INCLUDED
#define SIGNALHANDLING_H_INCLUDED

namespace SignalHandling
{

class Handler
{
public:
   virtual void operator ()(int parameter) = 0;
};

/** @note The caller is responsible for the memory pointed to by @a handler */
void RegisterSIGINTHandler(Handler * handler);

}

#endif   // #ifndef SIGNALHANDLING_H_INCLUDED
