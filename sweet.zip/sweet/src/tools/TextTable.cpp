#include "TextTable.h"
#include "tools/RangeIterator.h"

std::ostream &TextTable::Print(std::ostream &os) const {
   using namespace std;
   // the actual number of rows is always one less than what is allocated
   const int numrows = (int)table.size() - 1;
   // determine the `widths' of each column
   vector<string::size_type> widths(table.front().size(), 0);
   for (int ri = 0; ri < numrows; ++ri) {
      const table_type::value_type &row = table[ri];
      if (widths.size() < row.size()) // enlarge `widths' if necessary
         widths.resize(row.size(), 0);
      for (int ci = 0, cn = (int)row.size(); ci < cn; ++ci) {
         const string &cell = row[ci];
         string::size_type offs0 = 0, offs1, len = cell.length();
         for (;;) {
            // note: This code ignores carriage returns ('\r'),
            // vertical tabs ('\v'), and form feeds ('\r').  I'm just not
            // sure if there is any standard handling of these characters
            // that predictably affects the line length.  The worst
            // consequence is that the columns become too wide.
            offs1 = cell.find_first_of("\n", offs0);
            if (offs1 == string::npos) {
               widths[ci] = max(widths[ci], len - offs0);
               break;
            } else {
               widths[ci] = max(widths[ci], offs1 - offs0);
               // now find the next printable character in `cell'.
               // note: this loop stops at tabs (for which isprint() returns
               // false) as well, since all tabs were replaced by a single
               // space when `cell' was created.
               for (offs0 = offs1 + 1; offs0 < len && !isprint(cell[offs0]); ++offs0)
                  ;
            }
         }
      }
   }
   const string::size_type numcols = (string::size_type)widths.size();
   // Create a string `row_inter' to print between the table rows.  If
   // row_sep == '\0', `row_inter' will simply be left as a single newline.
   string row_inter(1, '\n');
   if (row_sep != '\0') {
      string::size_type totalwd = 0;
      for (RangeIterator<const vector<string::size_type> > ci(widths); ci; ++ci)
         totalwd += *ci;
      totalwd += (numcols - 1) * col_sep.length(); // for the column separators
      row_inter.append(totalwd, row_sep);
      row_inter.append(1, '\n');
   }
   // set/save flags on `os'
   streamsize prevwd = os.width();
   ostream::fmtflags prevflags = os.setf(ostream::left);
   char prevfill = os.fill(' ');
   // run through the table and print it
   vector<string::size_type> offsets(numcols);
   for (int ri = 0; ri < numrows; ++ri) {
      table_type::value_type &row = table[ri];
      // print each text line
      offsets.assign(numcols, 0);
      bool done;
      for (;;) { // while done == false
         done = true; // will be set to false if some column has more to print
         for (int ci = 0, cn = (int)row.size(); ci < cn; ++ci) {
            string &cell = row[ci];
            string::size_type offs0 = offsets[ci], offs1, len = cell.length();
            os.width(widths[ci]);
            if (offs0 < len) { // there is more in this cell to print
               offs1 = cell.find('\n', offs0);
               if (offs1 == string::npos) {
                  os << cell.c_str() + offs0;
                  offs0 = len;
               } else {
                  // temporarily insert a null character to terminate the column
                  char tmp = cell[offs1];
                  cell[offs1] = '\0';
                  os << cell.c_str() + offs0;
                  cell[offs1] = tmp;
                  // find the next printable character in the cell
                  for (offs0 = offs1 + 1; offs0 < len && !isprint(cell[offs0]); ++offs0)
                     ;
               }
               offsets[ci] = offs0; // save for the next text line
               done &= (offs0 == len); // update status
            } else { // cell is depleted
               os << "";
            }
            // maybe print the column separator
            if (ci < numcols - 1) {
               os.width(0);
               os << col_sep;
            }
         }
         // print any remaining empty columns
         for (int ei = (int)row.size(); ei < numcols - 1; ++ei) {
            os.width(widths[ei]);
            os << "";
            os.width(0);
            os << col_sep;
         }
         if (done) break;
         else os << endl;
      };
      // maybe print the row separator
      if (ri < numrows - 1)
         (os << row_inter).flush(); // flush() because we don't use endl here
   }
   // reset flags on `os'
   os.fill(prevfill);
   os.flags(prevflags);
   os.width(prevwd);
   return os;
}
