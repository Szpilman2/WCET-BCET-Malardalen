#ifndef DISASSEMBLEDFLOAT_H_INCLUDED
#define DISASSEMBLEDFLOAT_H_INCLUDED

#include <stdint.h>

/* Summary of the IEEE-754 floating-point formats (in the special case of single-precision floats,
   but double-precision floats have an analogous format):

   The fields of a floating-point bitstring, from the most significant to the least significant bit, are
      1 sign bit
      8 bits of exponent: ranges from 0 to 255. However, in computations a bias of -127 is added
                          to it which makes its effective range -127 to 128.
      23 bits of fraction (or significand)

   When the effective exponent e is -126 <= e <= 127, the bitstring represents the real value
   (1 - 2s) * 1.f * 2^e, where s is the value of the sign bit and f is the fraction. These are called
   normalized values. When e == -127, the bitstring represents the real value 
   (1 - 2s) * 0.f * 2^-126. These values are called denormalized values. An exponent of 128 is used
   to represent special values such as infinity and NaN. The values infinity and -infinity are 
   represented by e == 128, f == 0 and s being unset or set, respectively. When f != 0, the 
   bitstring represents various variants of NaN, where the implementation is free to use the 
   fraction bits arbitrarily. Also, note that because of the sign bit, there are two version of
   0, a positive and a negative. */

/** A "disassembled" floating-point value. Can be used to get information about the
    inner workings of a floating-point representation. It is recommended that some
    of the template specializations DisassembledFloat<float> or DisassembledFloat<double>
    (at the end of this file) is used.
    @params FloatRep A datatype for representing floating-point values, that
                     adheres to the IEEE-754 standard */
template <typename FloatRep>
class DisassembledFloat;

/** Base class of "disassembled"-float classes
    @param FloatRep The datatype used to represent floating-point values
    @param IntRep An integer datatype used to represent the bit string of the
                  floating-point value as an integer. Must be unsigned and have
                  the same size as @a FloatRep. */
template <typename FloatRep, typename IntRep>
class DisassembledFloatBase
{
public:
   typedef FloatRep FloatRepType;
   typedef IntRep IntRepType;

   /** Get the size in bits of the exponent part of the floating-point
       representation FloatRep */
   static int GetExpSize() {return exp_size;}

   /** Get the size in bits of the fraction part of the floating-point
       representation FloatRep */
   static int GetFracSize() {return frac_size;}

   /** Get the float value */
   FloatRep AsFloat() const {return value.float_rep;}

   /** Get the float's bit string representation as an integer */
   IntRep AsInt() const {return value.int_rep;}

   /** Get the sign bit.
      @return 0 if the sign bit is cleared, 1 otherwise */
   int GetSignBit() const;

   /** Get the effective (i.e. unbiased) exponent (however, note that for denormalized
      values, the effective exponent is 1 larger than the exponent of the represented
      value; see the summary at the top of this file) */
   long GetExponent() const;

   /** Get the significand bit sequence (as an integer) */
   IntRep GetSignificand() const;

   /** Get the significand with the hidden bit (which is implicitly a part of all
       normalized floating-point values) included */
   IntRep GetSignificandWithHiddenBit() const;

   /** Is this -0? */
   bool IsNegZero() const;

   /** Is this +0? */
   bool IsPosZero() const;

   /** Is this positive infinity? */
   bool IsInfinity() const;

   /** Is this negative infinity? */
   bool IsNegInfinity() const;

   /** Is this NaN (Not-a-Number)? */
   bool IsNaN() const;

   /** Perform bitstring comparison between this value and @a other */
   bool Equals(const DisassembledFloatBase<FloatRep, IntRep> & other) const;

   /** Increment the float to the smallest representable float larger than the current value.
      Handling of special float values: ++NaN = NaN; ++(-inf) = -floatmax, where floatmax is the
      largest representable value smaller than inf; ++inf = inf.
      @return The new value */
   DisassembledFloatBase & operator ++();

   /** Increment the float to the smallest representable float larger than the current value.
      See the pre increment version for how special float values are handled.
      @return The previous value */
   DisassembledFloatBase operator ++(int);

   /** Decrement the float to the largest representable float smaller than the current value.
      Handling of special float values: --NaN = NaN; --(-inf) = -inf; --inf = floatmax,
      where floatmax is the largest representable value smaller than inf.
      @return The new value */
   DisassembledFloatBase & operator --();

   /** Decrement the float to the largest representable float smaller than the current value.
      See the pre decrement version for how special float values are handled.
      @return The previous value */
   DisassembledFloatBase operator --(int);

protected:
   DisassembledFloatBase() {}

   /** Create a "disassembled" version of the floating-point value @a value */
   DisassembledFloatBase(FloatRep value);

   /** Create a "disassembled" float that have a bit string representation
       equal to @a value */
   DisassembledFloatBase(IntRep value);

   /** Create a float from its parts: the sign bit, exponent and significand */
   DisassembledFloatBase(bool sign, IntRep exponent, IntRep significand);

private:
   union
   {
      FloatRep float_rep;
      IntRep int_rep;
   } value;

   /** Size in bits of the exponent part of the bit string representing
       the floating-point value */
   static const int exp_size;

   /** Size in bits of the fraction part of the bit string representing
       the floating-point value */
   static const int frac_size;

   /** Returns the bias that is added to the exponent before it is stored */
   static long ExpBias() { return (long)((IntRep(1) << (exp_size - 1)) - 1); }

   static IntRep NegZeroBitstring() { return IntRep(1) << (8*sizeof(IntRep) - 1); }
};

/** A "disassembled" single-precision float. Uses an 32-bit integer representation
    (Problem: This will not work unless the compiler maps the type float to a
    32-bit IEEE-754 floating-point type). */
template <>
class DisassembledFloat<float> : public DisassembledFloatBase<float, uint32_t>
{
public:
   DisassembledFloat() {}

   DisassembledFloat(float value)
      : DisassembledFloatBase<float, uint32_t>(value) {}

   DisassembledFloat(uint32_t value)
      : DisassembledFloatBase<float, uint32_t>(value) {}

   DisassembledFloat(bool sign, uint32_t exponent, uint32_t significand)
      : DisassembledFloatBase<float, uint32_t>(sign, exponent, significand) {}
};

/** A "disassembled" double-precision float. Uses a 64-bit integer representation
    (Problem: This will not work unless the compiler maps the type double to a
    64-bit IEEE-754 floating-point type). */
template <>
class DisassembledFloat<double> : public DisassembledFloatBase<double, uint64_t>
{
public:
   DisassembledFloat() {}

   DisassembledFloat(double value)
      : DisassembledFloatBase<double, uint64_t>(value) {}

   DisassembledFloat(uint64_t value)
      : DisassembledFloatBase<double, uint64_t>(value) {}

   DisassembledFloat(bool sign, uint64_t exponent, uint64_t significand)
      : DisassembledFloatBase<double, uint64_t>(sign, exponent, significand) {}
};

#endif   // #ifndef DISASSEMBLEDFLOAT_H_INCLUDED
