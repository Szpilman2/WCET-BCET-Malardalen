#ifndef CHEAP_COPY_H_INCL
#define CHEAP_COPY_H_INCL

#include <memory>
#include <cassert>

/** Copy functor that calls the copy constructor of the type T */
template <class T>
struct default_copy {
   T *operator ()(T &ref) const { return new T(ref); }
};

/** Implements copy-on-write logic for a wrapped object. Each copy of a
    cheap_copy object should be thought of as an actual deep copy of the
    underlying object. As long as only immutable (const) methods/variables of
    the wrapped object are accessed (via get(), ->, etc.), it can be shared with
    other cheap_copy instances. Mutable members, however, can only be accessed
    via get_mutable(), which first performs a deep copy of the wrapped object
    (unless the cheap_copy object holds the only reference, in which case this
    is unnecessary). This way, cheap copies can be made of large data
    structures, while deferring the costly deep copying until it is actually
    needed.

    Note that the public interface of cheap_copy looks like a smart pointer
    merely for syntactical convenience. Each cheap_copy instance should
    conceptually be thought of as a unique copy of its underlying object, and
    not a pointer to it. Thus, copying a cheap_copy should only be done when
    this makes sense semantically, otherwise a pointer or reference to the
    cheap_copy should be used. */
template <class T, class C = default_copy<T>, class D = std::default_delete<T>>
class cheap_copy {
public:
   /** Creates an empty cheap_copy */
   cheap_copy() {
      hub = &null_hub;
      ++hub->nrefs;
   }

   /** @note The pointer is a gift to this cheap_copy */
   explicit cheap_copy(T *ptr) {
      if (ptr == nullptr) {
         hub = &null_hub;
         ++hub->nrefs;
      } else {
         hub = new ref_hub;
         hub->ptr = ptr;
         hub->nrefs = 1;
      }
   }

   cheap_copy(const cheap_copy &other) {
      hub = other.hub;
      ++hub->nrefs;
   }

   /** Move constructor
       @post other.get() == nullptr */
   cheap_copy(cheap_copy &&other) {
      hub = other.hub;
      other.hub = &null_hub;
      ++other.hub->nrefs;
   }

   cheap_copy &operator =(const cheap_copy &other) {
      ref_hub *oldhub = hub;
      hub = other.hub;
      ++hub->nrefs;
      remove_ref(oldhub);
      return *this;
   }

   /** Move assignment
       @post other.get() == nullptr */
   cheap_copy &operator =(cheap_copy &&other) {
      if (this == &other)
         return *this;
      ref_hub *oldhub = hub;
      hub = other.hub;
      other.hub = &null_hub;
      ++other.hub->nrefs;
      remove_ref(oldhub);
      return *this;
   }

   ~cheap_copy() { remove_ref(hub); }

   /** @note The pointer is a gift to this cheap_copy */
   void reset(T *ptr) {
      if (hub->nrefs != 1) {
         ref_hub *oldhub = hub;
         hub = new ref_hub;
         hub->ptr = ptr;
         hub->nrefs = 1;
         remove_ref(oldhub);
      } else {
         // this is the only reference; reuse the hub object for the new pointer
         D()(hub->ptr);
         hub->ptr = ptr;
      }
   }

   /** @name Immutable access methods
       @{ */
   const T *get() const { return hub->ptr; }
   const T *operator ->() const { return hub->ptr; }
   const T &get_ref() const { return *hub->ptr; }
   const T &operator *() const { return *hub->ptr; }
   /** @} */

   /** @name Mutable access methods
       @{ */
   T *get_mutable() {
      if (hub->nrefs != 1) {
         ref_hub *oldhub = hub;
         hub = new ref_hub;
         hub->ptr = C()(*oldhub->ptr);
         hub->nrefs = 1;
         remove_ref(oldhub);
      }
      return hub->ptr;
   }

   T &get_mutable_ref() { return *get_mutable(); }
   /** @} */

   operator bool() const { return get() != nullptr; }

   /** Mainly for testing/debugging purposes */
   int get_num_refs() const { return hub->nrefs; }

private:
   struct ref_hub {
      T *ptr;
      int nrefs;
   };

   static ref_hub null_hub;
   ref_hub *hub;

   static void remove_ref(ref_hub *hub) {
      --hub->nrefs;
      if (hub->nrefs == 0) {
         D()(hub->ptr);
         delete hub;
      }
   }
};

template <class T, class C, class D>
typename cheap_copy<T,C,D>::ref_hub cheap_copy<T,C,D>::null_hub = { nullptr, 1 };

#endif // ifndef CHEAP_COPY_H_INCL
