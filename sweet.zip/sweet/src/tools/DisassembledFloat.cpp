#include "DisassembledFloat.h"
#include <limits>

using namespace std;

template <typename FloatRep, typename IntRep>
int DisassembledFloatBase<FloatRep, IntRep>::GetSignBit() const
{
   // The position of the sign bit in FloatRep is the same
   // as the position of the most significant bit in IntRep, since
   // IntRep is assumed to be of the same size as FloatRep. Shift
   // the sign bit down to the least significant position and return it.
   int sign_bit_index = 8*sizeof(IntRep) - 1;
   return (int)(value.int_rep >> sign_bit_index);
}

template <typename FloatRep, typename IntRep>
long DisassembledFloatBase<FloatRep, IntRep>::GetExponent() const
{
   // Mask out the exponent part of the float value
   IntRep exponent = value.int_rep >> frac_size;
   IntRep mask = (IntRep(1) << exp_size) - 1;
   exponent &= mask;
   // Unbias and return it
   return ((long)exponent) - ExpBias();
}

template <typename FloatRep, typename IntRep>
IntRep DisassembledFloatBase<FloatRep, IntRep>::GetSignificand() const
{
   IntRep mask = (IntRep(1) << frac_size) - 1;
   return value.int_rep & mask;
}

template <typename FloatRep, typename IntRep>
IntRep DisassembledFloatBase<FloatRep, IntRep>::GetSignificandWithHiddenBit() const
{
   IntRep significand = GetSignificand();
   // Do not add the hidden bit if the effective exponent has the smallest
   // possible value
   if (GetExponent() > -ExpBias())
      significand |= (IntRep(1) << frac_size);
   return significand;
}

template <typename FloatRep, typename IntRep>
bool DisassembledFloatBase<FloatRep, IntRep>::IsNegZero() const
{
   return value.int_rep == NegZeroBitstring();
}

template <typename FloatRep, typename IntRep>
bool DisassembledFloatBase<FloatRep, IntRep>::IsPosZero() const
{
   return value.int_rep == 0;
}

template <typename FloatRep, typename IntRep>
bool DisassembledFloatBase<FloatRep, IntRep>::IsInfinity() const
{
   return value.float_rep == numeric_limits<FloatRep>::infinity();
}

template <typename FloatRep, typename IntRep>
bool DisassembledFloatBase<FloatRep, IntRep>::IsNegInfinity() const
{
   return value.float_rep == -numeric_limits<FloatRep>::infinity();
}

template <typename FloatRep, typename IntRep>
bool DisassembledFloatBase<FloatRep, IntRep>::IsNaN() const
{
   return !(value.float_rep == value.float_rep);
}

template <typename FloatRep, typename IntRep>
bool DisassembledFloatBase<FloatRep, IntRep>::
Equals(const DisassembledFloatBase<FloatRep, IntRep> & other) const
{
   return value.int_rep == other.value.int_rep;
}

template <typename FloatRep, typename IntRep>
DisassembledFloatBase<FloatRep, IntRep> & 
DisassembledFloatBase<FloatRep, IntRep>::operator ++()
{
   if (IsNaN()) return *this;
   if (IsInfinity()) return *this;
   if (IsNegInfinity()) 
   {
      value.float_rep = -numeric_limits<FloatRep>::max();
      return *this;
   }
   IntRep only_sign_bit = NegZeroBitstring();
   // If -0, make it +0
   if (value.int_rep == only_sign_bit)
      value.int_rep = 0;
   // If negative, decrease the integer representation
   else if ((value.int_rep & only_sign_bit) != 0)
      --value.int_rep;
   // Positive; increase the integer representation
   else 
      ++value.int_rep;
   return *this;
}

template <typename FloatRep, typename IntRep>
DisassembledFloatBase<FloatRep, IntRep> 
DisassembledFloatBase<FloatRep, IntRep>::operator ++(int)
{
   DisassembledFloatBase copy(*this);
   ++*this;
   return copy;
}

template <typename FloatRep, typename IntRep>
DisassembledFloatBase<FloatRep, IntRep> & 
DisassembledFloatBase<FloatRep, IntRep>::operator --()
{
   if (IsNaN()) return *this;
   if (IsNegInfinity()) return *this;
   if (IsInfinity())
   {
      value.float_rep = numeric_limits<FloatRep>::max();
      return *this;
   }
   IntRep only_sign_bit = NegZeroBitstring();
   // If +0, make it -0
   if (value.int_rep == 0)
      value.int_rep = only_sign_bit;
   // If negative, increase the integer representation
   else if ((value.int_rep & only_sign_bit) != 0)
      ++value.int_rep;
   // Positive; decrease the integer representation
   else
      --value.int_rep;
   return *this;
}

template <typename FloatRep, typename IntRep>
DisassembledFloatBase<FloatRep, IntRep> 
DisassembledFloatBase<FloatRep, IntRep>::operator --(int)
{
   DisassembledFloatBase copy(*this);
   --*this;
   return copy;
}

// Protected members - - - - - - - - - - - - - - - ->

template <typename FloatRep, typename IntRep>
DisassembledFloatBase<FloatRep, IntRep>::DisassembledFloatBase(FloatRep value)
{
   // Create two dummy arrays to get help from the compiler to ensure that
   // sizeof(FloatRep) == sizeof(IntRep) (if they differ, one of the arrays
   // will get a size < 1, and the compiler will complain)
   {
      int dummy_arr1[sizeof(FloatRep) - sizeof(IntRep) + 1];
      int dummy_arr2[sizeof(IntRep) - sizeof(FloatRep) + 1];
      // This is just to fool the compiler that the arrays are used to make it shut up
      dummy_arr1[0] = dummy_arr2[0] = 0;
   }
   DisassembledFloatBase::value.float_rep = value;
}

template <typename FloatRep, typename IntRep>
DisassembledFloatBase<FloatRep, IntRep>::DisassembledFloatBase(IntRep value)
{
   // Create two dummy arrays to get help from the compiler to ensure that
   // sizeof(FloatRep) == sizeof(IntRep) (if they differ, one of the arrays
   // will get a size < 1, and the compiler will complain)
   {
      int dummy_arr1[sizeof(FloatRep) - sizeof(IntRep) + 1];
      int dummy_arr2[sizeof(IntRep) - sizeof(FloatRep) + 1];
      // This is just to fool the compiler that the arrays are used to make it shut up
      dummy_arr1[0] = dummy_arr2[0] = 0;
   }
   DisassembledFloatBase::value.int_rep = value;
}

template <typename FloatRep, typename IntRep>
DisassembledFloatBase<FloatRep, IntRep>::
DisassembledFloatBase(bool sign, IntRep exponent, IntRep significand)
{
   // Create two dummy arrays to get help from the compiler to ensure that
   // sizeof(FloatRep) == sizeof(IntRep) (if they differ, one of the arrays
   // will get a size < 1, and the compiler will complain)
   {
      int dummy_arr1[sizeof(FloatRep) - sizeof(IntRep) + 1];
      int dummy_arr2[sizeof(IntRep) - sizeof(FloatRep) + 1];
      // This is just to fool the compiler that the arrays are used to make it shut up
      dummy_arr1[0] = dummy_arr2[0] = 0;
   }
   value.int_rep = significand;
   value.int_rep |= (exponent + ExpBias()) << frac_size;
   if (sign)
   {
      IntRep sign_bit = IntRep(1) << (exp_size + frac_size);
      value.int_rep |= sign_bit;
   }
}

// Explicit instantiations - - - - - - -

template <> const int DisassembledFloatBase<float, uint32_t>::exp_size = 8;
template <> const int DisassembledFloatBase<float, uint32_t>::frac_size = 23;
template class DisassembledFloatBase<float, uint32_t>;

template <> const int DisassembledFloatBase<double, uint64_t>::exp_size = 11;
template <> const int DisassembledFloatBase<double, uint64_t>::frac_size = 52;
template class DisassembledFloatBase<double, uint64_t>;
