/* -*-c++-*- */
/* $Id: integer_utilities.h 6801 2014-11-03 23:44:08Z lkg02 $ */
#ifndef INTEGER_UTILITIES_H_
#define INTEGER_UTILITIES_H_

#include <string>
#include <iostream>
#include <algorithm>

/** Prints 'val' as a bit pattern of length 'bits' to 's' */
template <typename IntType>
void print_num_binary(const IntType & val, unsigned int bits, std::ostream * s)
{
   IntType shifted = val;
   std::string str; str.reserve(bits);
   for (unsigned i = 0; i != bits; ++i) {
      str.push_back((shifted & 1) == 1? '1' : '0');
      shifted >>= 1;
   }
   std::reverse(str.begin(), str.end());
   *s << str;
}

template <typename T> inline T min4(const T &a, const T &b, const T &c, const T &d) {return std::min(std::min(a, b), std::min(c, d));}
template <typename T> inline T max4(const T &a, const T &b, const T &c, const T &d) {return std::max(std::max(a, b), std::max(c, d));}

/** Return the smallest unsigned integer that is representable with @a bit_precision bits */
template <typename T>
inline T SmallestRepresentableUnsigned(unsigned long long bit_precision) { return T(0); }

/** Return the largest unsigned integer that is representable with @a bit_precision bits.
    @a T is the type used to represent the value, and should be chosen to be large enough,
    i\.e\., <tt>sizeof(T) >= bit_precision</tt>. */
template <typename T>
inline T LargestRepresentableUnsigned(unsigned long long bit_precision)
{ return (T(1) << bit_precision) - 1; }

/** Return the smallest signed integer that is representable with @a bit_precision bits.
    @a T is the type used to represent the value, and should be chosen to be large enough,
    i\.e\., <tt>sizeof(T) >= bit_precision</tt>, and should be signed. */
template <typename T>
inline T SmallestRepresentableSigned(unsigned long long bit_precision)
{ return T(-1) << (bit_precision - 1); }

/** Return the largest signed integer that is representable with @a bit_precision bits.
    @a T is the type used to represent the value, and should be chosen to be large enough,
    i\.e\., <tt>sizeof(T) >= bit_precision</tt>, and should be signed. */
template <typename T>
inline T LargestRepresentableSigned(unsigned long long bit_precision)
{ return LargestRepresentableUnsigned<T>(bit_precision - 1); }

template <typename T>
T RepresentableRangeWidth(unsigned long long bit_precision) { return T(1) << bit_precision; }

#endif
