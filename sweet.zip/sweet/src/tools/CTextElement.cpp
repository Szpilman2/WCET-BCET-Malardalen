// $Id: CTextElement.cpp 7975 2018-11-23 15:24:04Z lkg02 $

#include "CTextElement.h"
#include <sstream>
#include <cassert>

#ifdef NOCSI
   #define CSI_SUFFIX         ""
   #define CSI_COLOR_PREFIX   ""
   #define CSI_BOLD           ""
   #define CSI_RESET          ""
#else
   #define CSI_PREFIX         "\033["
   #define CSI_SUFFIX         "m"
   #define CSI_COLOR_PREFIX   CSI_PREFIX "3"
   #define CSI_BOLD           CSI_PREFIX "1" CSI_SUFFIX
   #define CSI_RESET          CSI_PREFIX "0" CSI_SUFFIX
#endif

using namespace std;

CTextElement::
CTextElement(std::string text, unsigned indent, bool new_line) :
      std::string(text),
      _indentation(indent),
      _new_line(new_line),
      _has_property(false),
      _bold(false),
      _color(NONE)
      { }

void
CTextElement::
Indent(ostream &o, unsigned *current_pos) const
{
   for (; *current_pos<_indentation; ++(*current_pos)) {
      o << " ";
   }
}

void
CTextElement::
NewLine(ostream &o, unsigned *current_pos) const
{
   o << endl;
   *current_pos = 0;
}

void
CTextElement::
Wrap(ostream &o, unsigned *current_pos) const
{
   NewLine(o, current_pos);
   Indent(o, current_pos);
}

void
CTextElement::
PrintIndented(ostream &o, unsigned *current_pos, unsigned width, bool hide_properties) const
{
   string::size_type index_of_last_space_before_margin;
   static unsigned color_code_table[NR_OF_COLORS]={0, 1, 2, 3, 4, 5, 6};

   Indent(o, current_pos);
   CTextElement copy = *this;
   if (width > 0) {
      if (_color != NONE && !hide_properties) {
         assert(_color < NR_OF_COLORS);
         o << CSI_COLOR_PREFIX << color_code_table[_color] << CSI_SUFFIX;
      }
      if (_bold && !hide_properties) {
         o << CSI_BOLD;
      }
      // Print text on all rows that will be full
      while (*current_pos + copy.length() > width) {
         unsigned index_at_margin = width - *current_pos;
         index_of_last_space_before_margin = copy.find_last_of(' ', index_at_margin);
         if (index_of_last_space_before_margin == string::npos) {
            // Not even the first single word fit into the rest of the row
            if (*current_pos > _indentation) {
               // The start position was not at the indentation level. Maybe we
               // can recover by making a new row.
               unsigned index_at_margin = width - _indentation;
               index_of_last_space_before_margin = copy.find_last_of(' ', index_at_margin);
               if (index_of_last_space_before_margin == string::npos) {
                  // Give up (just dump it onto the output as it is)
                  break;
               } else {
                  // OK a new row should work, then make one.
                  Wrap(o, current_pos);
               }
            } else {
               // Give up
               break;
            }
         }
         o << copy.substr(0, index_of_last_space_before_margin);
         copy = copy.substr(index_of_last_space_before_margin + 1);
         if (copy.length() > 0) {
            Wrap(o, current_pos);
         }
      }
   }

   // Print text that fits on one row
   o << copy;
   *current_pos += (unsigned)copy.length();

   if (_new_line) {
      NewLine(o, current_pos);
   }
   if (_has_property && !hide_properties) {
      o << CSI_RESET;
   }
}
