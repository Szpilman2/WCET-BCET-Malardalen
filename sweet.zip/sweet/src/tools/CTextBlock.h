// $Id: CTextBlock.h 5125 2013-04-07 22:13:58Z lkg02 $

#ifndef CTEXT_BLOCK_H_
#define CTEXT_BLOCK_H_

#include <iostream>
#include <vector>
#include "CTextElement.h"



/** \class CTextBlock
   A text block is a collection of 0 or more text components. Currently it is
   able to print text components in a way formatted for consol output, i.e.
   they will be indented with spaces and terminated with a new line.
*/

class CTextBlock : public std::vector<CTextElement>
{
public:
   /** Outputs its text content to a stream, formatted according to the
      different CLines.
      \param o The stream to output text to.
      \param width The width of the output media (0 means infinite).
         Text that are too long to fit into that width are broken in between
         two words the rest to be continued on the subsequent rows on the
         output medium at the indentation level specified by the text component
         that contained the text that did not fit.
      \param hide_properties Hide properties
   */
   void Show(std::ostream &o=std::cout, int width=0, bool hide_properties=false) const;
};

#endif
