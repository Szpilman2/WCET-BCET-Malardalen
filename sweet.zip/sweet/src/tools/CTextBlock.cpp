// $Id: CTextBlock.cpp 1333 2009-11-04 20:36:02Z csg01 $

#include "CTextBlock.h"
#include "CTextElement.h"

using namespace std;

void
CTextBlock::
Show(std::ostream &o, int width, bool hide_properties) const
{
   unsigned current_pos = 0;
   for (const_iterator line_it=begin(); line_it!=end(); line_it++) {
      const CTextElement *line = &*line_it;
      line->PrintIndented(o, &current_pos, width, hide_properties);
   }
}

