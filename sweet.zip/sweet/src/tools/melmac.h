#ifndef MELMAC_H_INCLUDED
#define MELMAC_H_INCLUDED

#include <string>

namespace melmac {

   inline std::string Unmangle(std::string mangled_id)
   {
      return mangled_id.substr(0, mangled_id.find(':'));
   }

}

#endif
