#ifndef INDENTINGOSTREAM_H_INCLUDED
#define INDENTINGOSTREAM_H_INCLUDED

#include <cassert>
#include <typeinfo>
#include <string>

/** Indenting output stream. It works by wrapping a basic_streambuf, which is given to
    it in the constructor, and delegating all actual output to that object. A basic_streambuf
    can be retrieved by calling rdbuf() on some class derived from basic_ostream, such as
    an ofstream or cout. For most purposes, the template instantiation IndentingOStream can
    be used. */
template <typename charT, typename Traits = std::char_traits<charT> >
class IndentingOStreamBase : public std::basic_ostream<charT, Traits> 
{
public:
   typedef std::basic_streambuf<charT, Traits> BaseStreamBuf;

   /** Create an indenting output stream
       @param stream_buffer A pointer to a basic_streambuf object, which all actual output is
                            delegated to. It can be retrieved by calling the function rdbuf() on 
                            some other class derived from basic_ostream. The stream from which it
                            came must be kept alive as long as this stream is used.
       @param indent_size The number of spaces to use for each level of indentation
       @param indent_string   The string to insert as indentation */
   IndentingOStreamBase(std::basic_streambuf<charT, Traits> * stream_buffer, 
                        const std::string & indent_string = ".\t")
      : std::basic_ostream<charT, Traits>(&buf), buf(stream_buffer, indent_string)
   {

   }

   /** Increase the level of indentation by @a levels */
   void IncrIndent(unsigned levels = 1) {buf.IncrIndent(levels);}

   /** Decrease the level of indentation by @a levels. The lowest level of 
       indentation is 0. */
   void DecrIndent(unsigned levels = 1) {buf.DecrIndent(levels);}

private:
   /** Implements a basic_streambuf subclass which handles all output of indentation.
       Uses an internal stream buffer which all write calls are delegated to. */
   class IndentingStreamBufBase : public std::basic_streambuf<charT, Traits>
   {
   public:
      IndentingStreamBufBase(std::basic_streambuf<charT, Traits> * stream_buffer,
                             const std::string & indent_string)
         : internal_sb(stream_buffer), last_endl(true),
           indent_string(indent_string), indent_level(0) {}

      /** Increase the level of indentation by @a levels */
      void IncrIndent(unsigned levels = 1) {indent_level += levels;}

      /** Decrease the level of indentation by @a levels. The lowest level of 
      indentation is 0. */
      void DecrIndent(unsigned levels = 1)
      {
         if (levels <= indent_level) indent_level -= levels;
         else indent_level = 0;
      }

      /** Here is where all output is being carried out. This function is called from the
          base class when the internal buffer is full, and its contents should be dumped
          to wherever (in this case it's the internal stream buffer). @a c is the first
          character that didn't fit in the now full buffer. */
      virtual typename BaseStreamBuf::int_type overflow(typename BaseStreamBuf::int_type c = Traits::eof())
      {
         assert(BaseStreamBuf::pptr() == BaseStreamBuf::pbase() ||
                "Only support for non-buffered output at the moment" == 0);

         // If the previously written value was an newline character,
         // create an indentation string and put it to the internal stream buffer
         if (last_endl)
         {
            std::string indentation;
            for (unsigned l = 0; l < indent_level; ++l)
            {
               indentation += indent_string;
            }
            internal_sb->sputn(indentation.c_str(), indentation.length());
            last_endl = false;
         }

         // Put the character
         if (c != Traits::eof())
            internal_sb->sputc(c);

         // If the current character is a newline character, record that for the
         // next time something is written
         if (c == '\n')
            last_endl = true;

         return Traits::not_eof(c);
      }

   private:
      std::basic_streambuf<charT, Traits> * internal_sb;
      bool last_endl;
      std::string indent_string;
      unsigned indent_level;
   };

   IndentingStreamBufBase buf;
};

/** Convenient typedef suitable for most situations */
typedef IndentingOStreamBase<char> IndentingOStream;

/** Manipulator for increasing the level of indentation by one. Has no effect on other basic_ostreams
    than IndentingOStreamBase. Example of use:
    @verbatim
        cout << "Some text" << endl << IncrIndent << "Some more, indented, text" << endl;
    @endverbatim */
template <typename charT, typename Traits>
std::basic_ostream<charT, Traits> & IncrIndent(std::basic_ostream<charT, Traits> & stream)
{
   IndentingOStreamBase<charT, Traits>* stream_ = dynamic_cast<IndentingOStreamBase<charT, Traits>*>(&stream);
   if (stream_ != 0)
      stream_->IncrIndent();
   return stream;
}

/** Manipulator for decreasing the level of indentation by one. Has no effect on other basic_ostreams
    than IndentingOStreamBase. Example of use:
    @verbatim
        cout << IncrIndent << "Some indented text" << endl << DecrIndent << "Some more, unindented, text" << endl;
    @endverbatim */
template <typename charT, typename Traits>
std::basic_ostream<charT, Traits> & DecrIndent(std::basic_ostream<charT, Traits> & stream)
{
   IndentingOStreamBase<charT, Traits>* stream_ = dynamic_cast<IndentingOStreamBase<charT, Traits>*>(&stream);
   if (stream_ != 0)
      stream_->DecrIndent();
   return stream;
}

#endif   // #ifndef INDENTINGOSTREAM_H_INCLUDED
