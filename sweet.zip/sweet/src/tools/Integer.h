#ifndef LARGEINTEGER_H_INCLUDED
#define LARGEINTEGER_H_INCLUDED

#include <gmpxx.h>
#include <ostream>
#include <vector>
#include <stack>
#include <cassert>
#include <limits>
#include <stdexcept>
#include <sstream>
#include "tools/StrStream.h"

template <typename T>
class Pool
{
public:
   Pool(int increment) : increment(increment), next_unused(increment) {}

   ~Pool()
   {
      for (typename std::vector<T *>::iterator a = pool.begin();
           a != pool.end(); ++a)
      {
         delete [] *a;
      }
   }

   T & Get()
   {
      if (recycled.empty())
      {
         if (next_unused == PoolIndex(increment))
         {
            pool.push_back(new T[increment]);
            next_unused = 0;
         }
         return pool.back()[next_unused++];
      }
      else
      {
         T * obj = recycled.top();
         recycled.pop();
         return *obj;
      }
   }

   void Return(T & obj)
   {
      recycled.push(&obj);
   }

private:
   typedef typename std::vector<T *>::size_type PoolIndex;

   std::vector<T *> pool;
   int increment;
   PoolIndex next_unused;
   std::stack<T *, std::vector<T*> > recycled;
};

/** Help function to perform a right shift of @a val by the amount given by @a amt. 
   This function is necessary because the >> operator already defined for mpz_class
   does not treat the shifted value as a two's complement value, and gives the
   wrong result if the shifted value is negative and odd. */
inline void RightShift(mpz_class& val, mp_bitcnt_t amt)
{
   mpz_ptr val_ = val.get_mpz_t();
   mpz_fdiv_q_2exp(val_, val_, amt);
}

class Integer
{
   friend std::ostream & operator <<(std::ostream & o, const Integer & mp_int);
  
public:
   Integer() : mp_int(pool.Get()) {mp_int = 0;}

   template <typename T> 
   explicit Integer(const T & val) : mp_int(pool.Get()) {mp_int = val;}

   explicit Integer(long long val);

   explicit Integer(unsigned long long val);

   Integer(const mpz_class & val) : mp_int(pool.Get()) {mp_int = val;}

   Integer(const Integer & other) : mp_int(pool.Get()) {mp_int = other.mp_int;}

   ~Integer() {pool.Return(mp_int);}

   template <typename T>
   Integer & operator =(const T & val) {mp_int = val; return *this;}

   Integer & operator =(const Integer & other)
   {
      mp_int = other.mp_int;
      return *this;
   }

   /** Returns a constant reference to this Integer's internal mpz_class object */
   const mpz_class &GetMpz() const { return mp_int; }
   mpz_class & GetMpz() { return mp_int; }

   /** Returns whether or not this Integer can be represented by the basic type 'T'
      @pre 'T' is a basic integer or floating-point type */
   template <typename T> bool Fits() const { 
      throw std::logic_error("Integer::Fits<>(): only basic C integer or floating-point types are supported");
      return false;
   }
   
   /** Returns this Integer converted to the basic type 'T'
      @pre Fits<T>() == true */
   template <typename T> T As() const;

   /** @name Operators
      @{ */
   Integer operator -() const {return Integer(-mp_int);}
   template <typename T> Integer operator +(const T & y) const;
   template <typename T> Integer operator -(const T & y) const;
   template <typename T> Integer operator *(const T & y) const;
   template <typename T> Integer operator /(const T & y) const;
   template <typename T> Integer operator %(const T & y) const;
   Integer operator ~() const {return Integer(~mp_int);}
   template <typename T> Integer operator &(const T & y) const;
   template <typename T> Integer operator |(const T & y) const;
   template <typename T> Integer operator ^(const T & y) const;
   template <typename T> Integer operator <<(const T & y) const;
   template <typename T> Integer operator >>(const T & y) const;
   Integer & operator ++() {++mp_int; return *this;}
   Integer & operator --() {--mp_int; return *this;}
   template <typename T> Integer & operator +=(const T & y);
   template <typename T> Integer & operator -=(const T & y);
   template <typename T> Integer & operator *=(const T & y);
   template <typename T> Integer & operator /=(const T & y);
   template <typename T> Integer & operator &=(const T & y);
   template <typename T> Integer & operator |=(const T & y);
   template <typename T> Integer & operator ^=(const T & y);
   template <typename T> Integer & operator <<=(const T & y);
   template <typename T> Integer & operator >>=(const T & y);
   template <typename T> bool operator <(const T & y) const;
   template <typename T> bool operator <=(const T & y) const;
   template <typename T> bool operator ==(const T & y) const;
   template <typename T> bool operator !=(const T & y) const;
   template <typename T> bool operator >=(const T & y) const;
   template <typename T> bool operator >(const T & y) const;
   /** @} */

private:
   static Pool<mpz_class> pool;
   mpz_class & mp_int;

   template <int Size_SLL> void Set_SLL(long long val);
   template <int Size_ULL> void Set_ULL(unsigned long long val);

   template <int Size_SLL> bool Fits_SLL() const {
      // these are static for efficiency
      static const mpz_class sll_l = mpz_class(-1) << (8 * sizeof(long long) - 1),
         sll_u = (mpz_class(1) << (8 * sizeof(long long) - 1)) - 1;
      return sll_l <= this->mp_int && this->mp_int <= sll_u;
   }

   template <int Size_ULL> bool Fits_ULL() const {
      static const mpz_class ull_u = (mpz_class(1) << (8 * sizeof(unsigned long long))) - 1; // static for efficiency
      return 0 <= this->mp_int && this->mp_int <= ull_u;
   }

   template <int Size_SLL> long long As_SLL() const;
   template <int Size_ULL> unsigned long long As_ULL() const;
};

// ------------------------------------------------------------------------------>
// Below follows forward declarations of all template specializations, to avoid
// compilation problems.  All definitions follow farther down.  Note that some
// templates were defined already in the class definition above, but this is
// valid since they do not call other templates that have specializations.

template <> inline bool Integer::Fits<char>() const;
template <> inline bool Integer::Fits<signed char>() const;
template <> inline bool Integer::Fits<unsigned char>() const;
template <> inline bool Integer::Fits<short>() const;
template <> inline bool Integer::Fits<unsigned short>() const;
template <> inline bool Integer::Fits<int>() const;
template <> inline bool Integer::Fits<unsigned int>() const;
template <> inline bool Integer::Fits<long>() const;
template <> inline bool Integer::Fits<unsigned long>() const;
template <> inline bool Integer::Fits<long long>() const;
template <> inline bool Integer::Fits<unsigned long long>() const;
template <> inline bool Integer::Fits<float>() const;
template <> inline bool Integer::Fits<double>() const;
template <> inline bool Integer::Fits<long double>() const;

template <> inline long long Integer::As<long long>() const;
template <> inline unsigned long long Integer::As<unsigned long long>() const;
template <> inline float Integer::As<float>() const;
template <> inline double Integer::As<double>() const;
template <> inline long double Integer::As<long double>() const;

template <> inline void Integer::Set_SLL<sizeof(long)>(long long val);
template <> inline void Integer::Set_ULL<sizeof(unsigned long)>(unsigned long long val);

template <> inline bool Integer::Fits_SLL<sizeof(long)>() const;
template <> inline bool Integer::Fits_ULL<sizeof(unsigned long)>() const;

template <> inline long long Integer::As_SLL<sizeof(long)>() const;
template <> inline unsigned long long Integer::As_ULL<sizeof(unsigned long)>() const;

template <> inline Integer Integer::operator +<Integer>(const Integer & y) const;
template <> inline Integer Integer::operator -<Integer>(const Integer & y) const;
template <> inline Integer Integer::operator *<Integer>(const Integer & y) const;
template <> inline Integer Integer::operator /<Integer>(const Integer & y) const;
template <> inline Integer Integer::operator %<Integer>(const Integer & y) const;
template <> inline Integer Integer::operator &<Integer>(const Integer & y) const;
template <> inline Integer Integer::operator |<Integer>(const Integer & y) const;
template <> inline Integer Integer::operator ^<Integer>(const Integer & y) const;
template <> inline Integer Integer::operator << <Integer>(const Integer & y) const;
template <> inline Integer Integer::operator >><Integer>(const Integer & y) const;
template <> inline Integer & Integer::operator +=<Integer>(const Integer & y);
template <> inline Integer & Integer::operator -=<Integer>(const Integer & y);
template <> inline Integer & Integer::operator *=<Integer>(const Integer & y);
template <> inline Integer & Integer::operator /=<Integer>(const Integer & y);
template <> inline Integer & Integer::operator &=<Integer>(const Integer & y);
template <> inline Integer & Integer::operator |=<Integer>(const Integer & y);
template <> inline Integer & Integer::operator ^=<Integer>(const Integer & y);
template <> inline Integer & Integer::operator <<=<Integer>(const Integer & y);
template <> inline Integer & Integer::operator >>=<Integer>(const Integer & y);
template <> inline bool Integer::operator < <Integer>(const Integer & y) const;
template <> inline bool Integer::operator <=(const long long & y) const;
template <> inline bool Integer::operator <=(const unsigned long long & y) const;
template <> inline bool Integer::operator <= <Integer>(const Integer & y) const;
template <> inline bool Integer::operator ==<Integer>(const Integer & y) const;
template <> inline bool Integer::operator !=<Integer>(const Integer & y) const;
template <> inline bool Integer::operator >=<Integer>(const Integer & y) const;
template <> inline bool Integer::operator ><Integer>(const Integer & y) const;

// <------------------------------------------------------------------------------

inline Integer::Integer(long long val) : mp_int(pool.Get()) { Set_SLL<sizeof(long long)>(val); }

inline Integer::Integer(unsigned long long val) : mp_int(pool.Get()) { Set_ULL<sizeof(unsigned long long)>(val); }

template <>
inline bool Integer::Fits<char>() const {
   return (long)std::numeric_limits<char>::min() <= mp_int &&
      mp_int <= (long)std::numeric_limits<char>::max();
}

template <>
inline bool Integer::Fits<signed char>() const {
   return (long)std::numeric_limits<signed char>::min() <= mp_int &&
      mp_int <= (long)std::numeric_limits<signed char>::max();
}

template <>
inline bool Integer::Fits<unsigned char>() const {
   return (unsigned long)std::numeric_limits<unsigned char>::min() <= mp_int &&
      mp_int <= (unsigned long)std::numeric_limits<unsigned char>::max();
}

template <> inline bool Integer::Fits<short>() const { return mp_int.fits_sshort_p(); }
template <> inline bool Integer::Fits<unsigned short>() const { return mp_int.fits_ushort_p(); }
template <> inline bool Integer::Fits<int>() const { return mp_int.fits_sint_p(); }
template <> inline bool Integer::Fits<unsigned int>() const { return mp_int.fits_uint_p(); }
template <> inline bool Integer::Fits<long>() const { return mp_int.fits_slong_p(); }
template <> inline bool Integer::Fits<unsigned long>() const { return mp_int.fits_ulong_p(); }
template <> inline bool Integer::Fits<long long>() const { return Fits_SLL<sizeof(long long)>(); }
template <> inline bool Integer::Fits<unsigned long long>() const { return Fits_ULL<sizeof(unsigned long long)>(); }
// TODO: theoretically, a Integer can be bigger than what is representable with any of the below float types, but this is
// swept under the rug here
template <> inline bool Integer::Fits<float>() const { return true; }
template <> inline bool Integer::Fits<double>() const { return true; }
template <> inline bool Integer::Fits<long double>() const { return true; }

template <typename T>
T Integer::As() const {
   if (!Fits<T>()) {
      throw std::logic_error((StrStream() << "Integer::As<>(): the value " << *this <<
         " cannot be represented with type 'T' (" << 8 * sizeof(T) << " bits)").Str());
   }
   // note: due to the test above, no information will be lost here
   if (mp_int.fits_slong_p()) return T(mp_int.get_si());
   else return T(mp_int.get_ui());
}

template <> inline long long Integer::As<long long>() const { return As_SLL<sizeof(long long)>(); }
template <> inline unsigned long long Integer::As<unsigned long long>() const { return As_ULL<sizeof(unsigned long long)>(); }
// TODO: theoretically, a Integer can be bigger than what is representable with any of the below float types, but this is
// swept under the rug here (no Fits<>() check is made)
template <> inline float Integer::As<float>() const { return (float)mp_int.get_d(); }
template <> inline double Integer::As<double>() const { return mp_int.get_d(); }
template <> inline long double Integer::As<long double>() const { return mp_int.get_d(); }

template <int Size_SLL>
void Integer::Set_SLL(long long val) {
   Set_ULL<sizeof(unsigned long long)>((unsigned long long)(val < 0? -val : val));
   if (val < 0) mp_int = -mp_int;
}

template <int Size_ULL>
void Integer::Set_ULL(unsigned long long val)
{
   static mpz_class temp;  // Made static for efficiency
   // Convert val to an mp_int by dividing it into chunks of
   // sizeof(unsigned long) bytes that are ORed into the mp_int value.
   mp_int = 0;
   unsigned long long mask = std::numeric_limits<unsigned long>::max();
   for (unsigned shamt = 0; shamt < 8 * sizeof(unsigned long long); shamt += 8 * sizeof(unsigned long)) {
      if (val == 0) break;
      temp = (unsigned long)(val & mask);
      temp <<= shamt;
      mp_int |= temp;
      // Shift val 8 * sizeof(unsigned long) bits to the right (done in two
      // steps to avoid the undefined result of shifting too many bits in
      // the same operation)
      val >>= 4 * sizeof(unsigned long);
      val >>= 4 * sizeof(unsigned long);
   }
}

// specializations made for platforms where sizeof(long long) == sizeof(long)
template <> inline void Integer::Set_SLL<sizeof(long)>(long long val) { mp_int = (long)val; }
template <> inline void Integer::Set_ULL<sizeof(unsigned long)>(unsigned long long val) { mp_int = (unsigned long)val; }

// specializations made for platforms where sizeof(long long) == sizeof(long)
template <> inline bool Integer::Fits_SLL<sizeof(long)>() const { return mp_int.fits_slong_p(); }
template <> inline bool Integer::Fits_ULL<sizeof(unsigned long)>() const { return mp_int.fits_ulong_p(); }

template <int Size_SLL>
long long Integer::As_SLL() const
{
   if (!Fits<long long>()) {
      throw std::logic_error((StrStream() << "Integer::As_SLL<>(): the value " << *this <<
         " cannot be represented with type long long (" << 8 * sizeof(long long) << " bits)").Str());
   }
   if (this->mp_int < 0) {
      Integer this_ = -*this;
      long long result(this_.As<unsigned long long>());
      return -result;
   } else
      return (long long)As<unsigned long long>();
}

template <int Size_ULL>
unsigned long long Integer::As_ULL() const
{
   // Some variables that are made static for efficiency
   static const mpz_class mask(std::numeric_limits<unsigned long>::max());
   static mpz_class shifted, temp;
   if (!Fits<unsigned long long>()) {
      throw std::logic_error((StrStream() << "Integer::As_ULL<>(): the value " << *this <<
         " cannot be represented with type unsigned long long (" << 8 * sizeof(unsigned long long) << " bits)").Str());
   }
   unsigned long long result = 0;
   shifted = this->mp_int;
   for (unsigned shamt = 0; shamt < 8 * sizeof(unsigned long long); shamt += 8 * sizeof(unsigned long)) {
      if (shifted == 0) break;
      // Extract the least significant part of shifted, convert it to
      // an unsigned long long (via an unsigned long), and then OR it
      // into the right position of result
      temp = shifted;
      temp &= mask;
      unsigned long long temp1 = temp.get_ui();
      temp1 <<= shamt;
      result |= temp1;
      RightShift(shifted, 8 * sizeof(unsigned long));
   }
   return result;
}

// specializations made for platforms where sizeof(long long) == sizeof(long)
template <> inline long long Integer::As_SLL<sizeof(long)>() const { return As<long>(); }
template <> inline unsigned long long Integer::As_ULL<sizeof(unsigned long)>() const { return As<unsigned long>(); }

// Operator + - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer Integer::operator +(const T & y) const
{
   Integer result(mp_int);
   result.mp_int += y;
   return result;
}

template <>
Integer Integer::operator +<Integer>(const Integer & y) const
{
   Integer result(mp_int);
   result.mp_int += y.mp_int;
   return result;
}

// Operator - (minus) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer Integer::operator -(const T & y) const
{
   Integer result(mp_int);
   result.mp_int -= y;
   return result;
}

template <>
Integer Integer::operator -<Integer>(const Integer & y) const
{
   Integer result(mp_int);
   result.mp_int -= y.mp_int;
   return result;
}

// Operator * - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer Integer::operator *(const T & y) const
{
   Integer result(mp_int);
   result.mp_int *= y;
   return result;
}

template <>
Integer Integer::operator *<Integer>(const Integer & y) const
{
   Integer result(mp_int);
   result.mp_int *= y.mp_int;
   return result;
}

// Operator / - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer Integer::operator /(const T & y) const
{
   Integer result(mp_int);
   result.mp_int /= y;
   return result;
}

template <>
Integer Integer::operator /<Integer>(const Integer & y) const
{
   Integer result(mp_int);
   result.mp_int /= y.mp_int;
   return result;
}

// Operator % - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer Integer::operator %(const T & y) const
{
   Integer result(mp_int);
   result.mp_int %= y;
   return result;
}

template <>
Integer Integer::operator %<Integer>(const Integer & y) const
{
   Integer result(mp_int);
   result.mp_int %= y.mp_int;
   return result;
}

// Operator & - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer Integer::operator &(const T & y) const
{
   Integer result(mp_int);
   result.mp_int &= mpz_class(y);
   return result;
}

template <>
Integer Integer::operator &<Integer>(const Integer & y) const
{
   Integer result(mp_int);
   result.mp_int &= y.mp_int;
   return result;
}

// Operator | - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer Integer::operator |(const T & y) const
{
   Integer result(mp_int);
   result.mp_int |= y;
   return result;
}

template <>
Integer Integer::operator |<Integer>(const Integer & y) const
{
   Integer result(mp_int);
   result.mp_int |= y.mp_int;
   return result;
}

// Operator ^ - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer Integer::operator ^(const T & y) const
{
   Integer result(mp_int);
   result.mp_int ^= y;
   return result;
}

template <>
Integer Integer::operator ^<Integer>(const Integer & y) const
{
   Integer result(mp_int);
   result.mp_int ^= y.mp_int;
   return result;
}

// Operator << - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer Integer::operator <<(const T & y) const
{
   Integer result(mp_int);
   result.mp_int <<= y;
   return result;
}

template <>
Integer Integer::operator <<<Integer>(const Integer & y) const
{
   Integer result(mp_int);
   result.mp_int <<= y.As<unsigned long>();
   return result;
}

// Operator >> - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer Integer::operator >>(const T & y) const
{
   Integer result(mp_int);
   RightShift(result.mp_int, y);
   return result;
}

template <>
Integer Integer::operator >><Integer>(const Integer & y) const
{
   Integer result(mp_int);
   RightShift(result.mp_int, y.As<unsigned long>());
   return result;
}

// Operator += - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer & Integer::operator +=(const T & y)
{
   mp_int += y;
   return *this;
}

template <>
Integer & Integer::operator +=<Integer>(const Integer & y)
{
   mp_int += y.mp_int;
   return *this;
}

// Operator -= - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer & Integer::operator -=(const T & y)
{
   mp_int -= y;
   return *this;
}

template <>
Integer & Integer::operator -=<Integer>(const Integer & y)
{
   mp_int -= y.mp_int;
   return *this;
}

// Operator *= - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer & Integer::operator *=(const T & y)
{
   mp_int *= y;
   return *this;
}

template <>
Integer & Integer::operator *=<Integer>(const Integer & y)
{
   mp_int *= y.mp_int;
   return *this;
}

// Operator /= - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer & Integer::operator /=(const T & y)
{
   mp_int /= y;
   return *this;
}

template <>
Integer & Integer::operator /=<Integer>(const Integer & y)
{
   mp_int /= y.mp_int;
   return *this;
}

// Operator &= - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer & Integer::operator &=(const T & y)
{
   mp_int &= y;
   return *this;
}

template <>
Integer & Integer::operator &=<Integer>(const Integer & y)
{
   mp_int &= y.mp_int;
   return *this;
}

// Operator |= - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer & Integer::operator |=(const T & y)
{
   mp_int |= y;
   return *this;
}

template <>
Integer & Integer::operator |=<Integer>(const Integer & y)
{
   mp_int |= y.mp_int;
   return *this;
}

// Operator ^= - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer & Integer::operator ^=(const T & y)
{
   mp_int ^= y;
   return *this;
}

template <>
Integer & Integer::operator ^=<Integer>(const Integer & y)
{
   mp_int ^= y.mp_int;
   return *this;
}

// Operator <<= - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer & Integer::operator <<=(const T & y)
{
   mp_int <<= y;
   return *this;
}

template <>
Integer & Integer::operator <<=<Integer>(const Integer & y)
{
   mp_int <<= y.As<unsigned long>();
   return *this;
}

// Operator >>= - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
Integer & Integer::operator >>=(const T & y)
{
   RightShift(mp_int, y);
   return *this;
}

template <>
Integer & Integer::operator >>=<Integer>(const Integer & y)
{
   RightShift(mp_int, y.As<unsigned long>());
   return *this;
}

// Operator < - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
bool Integer::operator <(const T & y) const {return mp_int < y;}
  
template <>
bool Integer::operator < <Integer>(const Integer & y) const {return mp_int < y.mp_int;}

// Operator <= - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
bool Integer::operator <=(const T & y) const {return mp_int <= y;}
  
template <>
bool Integer::operator <=(const long long & y) const {return *this <= Integer(y);}

template <>
bool Integer::operator <=(const unsigned long long & y) const {return *this <= Integer(y);}

template <>
bool Integer::operator <= <Integer>(const Integer & y) const {return mp_int <= y.mp_int;}

// Operator == - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
bool Integer::operator ==(const T & y) const {return mp_int == y;}
  
template <>
bool Integer::operator == <Integer>(const Integer & y) const {return mp_int == y.mp_int;}

// Operator != - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
bool Integer::operator !=(const T & y) const {return mp_int != y;}
  
template <>
bool Integer::operator != <Integer>(const Integer & y) const {return mp_int != y.mp_int;}

// Operator >= - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
bool Integer::operator >=(const T & y) const {return mp_int >= y;}
  
template <>
bool Integer::operator >= <Integer>(const Integer & y) const {return mp_int >= y.mp_int;}

// Operator > - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template <typename T>
bool Integer::operator >(const T & y) const {return mp_int > y;}
  
template <>
bool Integer::operator > <Integer>(const Integer & y) const {return mp_int > y.mp_int;}

// Other operations - - - - - - - - - - - - - - - - - - - - - - - - - - - -

inline Integer abs(const Integer & x) {return Integer(abs(x.GetMpz()));}

inline std::ostream & operator <<(std::ostream & o, const Integer & mp_int) {return o << mp_int.mp_int.get_str();}

inline int log2(const Integer &x) { return (int)mpz_scan1(x.GetMpz().get_mpz_t(), 0); }

#endif   // LARGEINTEGER_H_INCLUDED
