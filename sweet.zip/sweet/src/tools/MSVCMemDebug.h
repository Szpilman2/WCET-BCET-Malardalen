#ifndef MSVCMEMDEBUG_H_INCLUDED
#define MSVCMEMDEBUG_H_INCLUDED

//#define MSVCMEMDEBUG_ENABLED

#ifdef MSVCMEMDEBUG_ENABLED

#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

#endif   // #ifdef MSVCMEMDEBUG_ENABLED

#endif   // #ifndef MSVCMEMDEBUG_H_INCLUDED
