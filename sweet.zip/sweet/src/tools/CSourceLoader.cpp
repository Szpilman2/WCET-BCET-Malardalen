// $Id: $

#include "CSourceLoader.h"
#include "program/alf/AlfLinker.h"
#include "program/alf/AStmt.h"
#include "tools/CTextBlock.h"
#include "flow_facts/RapitaIntermediate.h"
#include "tools/CAlfLabelSource.h"
#include <fstream>
#include <stdexcept>
#include <vector>
#include <cstdlib>
#include <memory>
#include <cassert>
#include <iostream>
#include <sstream>

using namespace std;

CSourceLoader::
CSourceLoader(string file_name, std::string alf_file_name, const std::set<std::string> &valid_labels, bool read_c_source)
{
   _alf_file.swap(alf_file_name);

   // We use this map to cache the c-files refered in the mapping file
   map <string, vector<string> > c_files_content;

   ifstream label_map_file;
   label_map_file.open(file_name.c_str());
   if (label_map_file.fail()) {
      throw runtime_error("Label mapping file "+file_name+" could not be opened");
   }

   // Parse the mapping file, line by line
   string line;
   vector <string> elements; elements.reserve(4);
   do {
      getline(label_map_file, line);
      if (line.empty())
         continue;

      // Parse a line by simply splitting it up in the fixed number of ; delimited elements
      size_t scan_start = 0;
      size_t match_pos;
      elements.clear();
      do {
         match_pos = line.find(';', scan_start);
         size_t length = match_pos - scan_start;
         elements.push_back(line.substr(scan_start, length));
         scan_start = match_pos + 1;
      } while (match_pos != string::npos);

      if (elements.size() != 4) {
         throw runtime_error("Label mapping file "+file_name+" is corrupt");
      }
      int idx = 0;
      const string &label       = elements[idx++];
      const string &c_file_name = elements[idx++];
      unsigned line_number      = atoi(elements[idx++].c_str());
      unsigned column_number    = atoi(elements[idx++].c_str());
      if (column_number == 0 && line_number == 0) {
         // Skip false (generated) mappings
      } 
      // Check that the label is valid (i.e., it actually occurs in the ALF file)
      else if (valid_labels.find(label) == valid_labels.end()) {
         cerr << "Warning: the label \""+label+"\", referenced in "+file_name+", does not exist in file "+_alf_file+". Ignored." << endl;
      }
      else if(!read_c_source) {
         // Skip reading c lines
         CAlfLabelSource * source = new CAlfLabelSource("", c_file_name, line_number, column_number);
         _label_to_source[label] = source;
         InsertInFirstSourceMap(source); 
        
      }
      else {
         // Map a new label source to the current label
         map<string, vector<string> >::iterator file_cont = c_files_content.find(c_file_name);
         if (file_cont == c_files_content.end()) {
            // Need to first parse since this file was not refered in any previous line
            file_cont = c_files_content.insert(make_pair(c_file_name, vector<string>())).first;
            ifstream c_file;
            c_file.open(c_file_name.c_str());
            if (c_file.fail()) {
               throw runtime_error("File "+c_file_name+"refered in label mapping file "+file_name+" could not be opened");
            }
            string c_line;
            do {
               getline(c_file, c_line);
               file_cont->second.push_back(c_line);
            } while (c_file.good());
            c_file.close();
         }
         const string &c_line = file_cont->second[line_number-1];
         CAlfLabelSource * source = new CAlfLabelSource(c_line.substr(column_number-1), c_file_name,
                                                        line_number, column_number);
         _label_to_source[label] = source;
         InsertInFirstSourceMap(source);
      }
   } while (label_map_file.good());
   label_map_file.close();
}

CSourceLoader::
~CSourceLoader()
{
  // Delete all created alf label sources
  for(std::map<std::string, CAlfLabelSource *>::iterator s2a = _label_to_source.begin();
      s2a != _label_to_source.end(); ++s2a) {
    delete (*s2a).second;
  }
}

void 
CSourceLoader::
Link(std::vector<CSourceLoader*>& linked, const alf::LinkLog& link_log)
{
   if (linked.size() < 2)
      return;

   // Go through the linked CSourceLoader objects and rename their labels using the link log
   for (std::vector<CSourceLoader*>::iterator s = linked.begin(); s != linked.end(); ++s)
   {
      const alf::LinkLog::Renames& renames = link_log.GetLRefRenames((*s)->GetAlfFileName());
      for (alf::LinkLog::Renames::const_iterator r = renames.begin(); r != renames.end(); ++r)
      {
         std::map<std::string, CAlfLabelSource *>::iterator found_lts = (*s)->_label_to_source.find(r->first);
         if (found_lts == (*s)->_label_to_source.end())
            // The renamed label is not included in the map file
            continue;
         unique_ptr<CAlfLabelSource> alf_label_source(found_lts->second);
         found_lts->second = 0;
         (*s)->_label_to_source.erase(found_lts);
         (*s)->_label_to_source.insert(make_pair(r->second, alf_label_source.release()));
      }      
   }

   // Add the contents of all CSourceLoader objects to the first object in the list
   CSourceLoader* first_sl = linked.front();
   while (linked.size() > 1)
   {
      CSourceLoader* last_sl = linked.back();

      // Add the contents of the last CSourceLoader to the first.

      // TODO: why was the check of whether the same lref appears in several
      // CSourceLoader objects added?  This should never happen, because
      // duplicate lrefs are mangled by the linker.  Besides, the code now leaks
      // memory if the warning fires.
      
      const std::map<std::string, CAlfLabelSource *> * f_l2s = &(first_sl->_label_to_source);
      const std::map<std::string, CAlfLabelSource *> * l_l2s = &(last_sl->_label_to_source);
      // Loop over all things in the last mapping
      for (std::map<std::string, CAlfLabelSource *>::const_iterator l_it = l_l2s->begin(); 
           l_it != l_l2s->end(); ++l_it) {
        // Get the label and the source of the first mapping
        std::string l_label = l_it->first;
        CAlfLabelSource * l_source = l_it->second;
        // Check if the identifier already exists in a mapping in the first source loader map
        map <string, CAlfLabelSource *>::const_iterator f_it = f_l2s->find(l_label);
        if (f_it != f_l2s->end()) {
          // The identifier already existed in the map. Check if the
          // sources are equal or not
          CAlfLabelSource * f_source = f_it->second;
          if(!(f_source->IsEqual(l_source))) {
            // The label was mapped to a source with another map
            // information, generate an error
            cout << "Warning: Potential map file linking error: The identifier " << l_label 
                 << " exists in several of the included map files but with different source info." << endl;
            cout << "First location: " << *f_source << endl;
            cout << "Second location: " << *l_source << endl << endl;
          }
        }
        else {
          // Insert the mapping in the first source loader
          first_sl->_label_to_source[l_label] = l_source;
          // If source is first in a line in the last sl map we set
          // it as being the same in the first sl map
          if(last_sl->IsInFirstSourceMap(l_source))
            first_sl->InsertInFirstSourceMap(l_source);
        }
      }

      // Destroy the last CSourceLoader
      last_sl->_label_to_source.clear();
      delete last_sl;
      linked.pop_back();
   }
   first_sl->_alf_file = "?";
}

const CAlfLabelSource *
CSourceLoader::
GetSourceOfLabel(string label) const
{
   map <string, CAlfLabelSource *>::const_iterator code_it = _label_to_source.find(label);
   const CAlfLabelSource *source = NULL;
   if (code_it != _label_to_source.end()) {
      source = code_it->second;
   }
   return source;
}

string
CSourceLoader::
GetCLine(string label) const
{
   const CAlfLabelSource *source = GetSourceOfLabel(label);
   string c_code;
   if (source) {
      c_code = source->GetCLine();
   }
   return c_code;
}

std::string 
CSourceLoader::
GetCSourceNameFromLabel(const string &label, const char delim[]) const
{
   if (const CAlfLabelSource *source = GetSourceOfLabel(label)) {
      if (delim) return source->ToString(delim);
      else       return source->ToString();
   }
   return label;
}

// We should, for each c_file_name,line_number pair which has alf
// labaler only keep track of the one which comes first in the source
// code line, i.e the one with the smallest column number
void
CSourceLoader::
InsertInFirstSourceMap(CAlfLabelSource * source)
{
  std::string c_file_name = source->GetFileName();
  unsigned line_number = source->GetLineNumber();

  std::pair<std::string, unsigned> p = make_pair(c_file_name, line_number);
  if(_first_source_map.find(p) == _first_source_map.end()) {
    _first_source_map[p] = source;
  }
  else {
    CAlfLabelSource * other_source = _first_source_map[p];
    if(other_source->GetColumnNumber() > source->GetColumnNumber())
      _first_source_map[p] = source;
  }
}


bool
CSourceLoader::
IsInFirstSourceMap(const CAlfLabelSource * source) const
{
  std::string c_file_name = source->GetFileName();
  unsigned line_number = source->GetLineNumber();
  std::pair<std::string, unsigned> p = std::make_pair(c_file_name, line_number);
  std::map<std::pair<std::string, unsigned>, CAlfLabelSource *>::const_iterator fl2s = _first_source_map.find(p); 
  if((fl2s != _first_source_map.end()) && ((*fl2s).second == source))
    return true;
  else
    return false;
}
  
const CAlfLabelSource *
CSourceLoader::
GetSourceOfLabelIfFirstInCLine(string label) const
{
  const CAlfLabelSource * source = GetSourceOfLabel(label);
  if(source && IsInFirstSourceMap(source))
    return source;
  else
    return NULL;
}

bool 
CSourceLoader::
NoNameCollisions(const std::map<std::string, CAlfLabelSource *>& first,
                                     const std::map<std::string, CAlfLabelSource *>& second)
{
   for (std::map<std::string, CAlfLabelSource *>::const_iterator n = first.begin(); n != first.end(); ++n)
      if (second.find(n->first) != second.end()) 
         return false;
   return true;
}



bool 
CSourceLoader::
AssertAndErrorMessageIfNameCollisions(const std::map<std::string, CAlfLabelSource *>& first,
                                      const std::map<std::string, CAlfLabelSource *>& second)
{
   for (std::map<std::string, CAlfLabelSource *>::const_iterator n = first.begin(); n != first.end(); ++n)
     if (second.find(n->first) != second.end()) {
       cout << "Map file linking error: The identifier " << n->first 
            << " exists in several of the included map files\n";
       assert(0);
       return false;
     }
   return true;
}

bool 
CSourceLoader::
HasCSourceInfoForAllNodes(const std::vector<CFlowGraph *> & flow_graphs, bool check_only_basic_blocks,
                          RapitaIntermediate * ri) const
{
  bool has_c_cource_info_for_all_nodes = true;

  // Loop through all flow graphs
  for (unsigned i=0; i<flow_graphs.size(); ++i) {
    CFlowGraph *flow_graph = flow_graphs[i];
    // Loop through all nodes in the flow graph
    for(CFlowGraph::node_iterator node = flow_graph->NodesBegin(); 
        node != flow_graph->NodesEnd(); ++node) {
      // Check if only basic blocks should be tested
      if(!(*node)->IsBeginOfBasicBlock() && check_only_basic_blocks) 
        continue;
      // If the node not is a valid Rapita path node we can continue
      // with the next node
      if(ri && !ri->IsValidRapitaPathNode(*node))
        continue;
      // If the node is a function start node then we do not need the
      // rapita path node
      if(ri && (*node) == flow_graph->GetEntry())
        continue;

      // If the node has a c_source we can continue with the next node
      const CAlfLabelSource * c_source = GetSourceOfLabel((*node)->Name());
      if(c_source) 
        continue;      
      // If the nodes does not have a c_source and we should only
      // check basic blocks, then we should search through the nodes
      // in the basic block
      if(!c_source && check_only_basic_blocks) {
        CFlowGraphNode * walker_node = (*node);
        while(!walker_node->IsEndOfBasicBlock() && !c_source) {
          walker_node = walker_node->SuccBegin()->node;
          c_source = GetSourceOfLabel(walker_node->Name());
        }     
      }
      if(c_source) 
        continue;

      // If we have not got a c_source label print an error message
      if(!c_source) {
        alf::AStmt * stmt = dynamic_cast<alf::AStmt*>((*node)->Stmt());
        cout << "Error: Can not derive c_source info for alf stmt located in file: " << *(stmt->GetSourceFile())
             << " row: " << stmt->GetLine()
             << " column: " << stmt->GetColumn() << " alf_label: " << (*node)->Name() << endl;
        stmt->Print(cout);
        cout << endl << endl;
        has_c_cource_info_for_all_nodes = false;
      }
    }
  }
  return has_c_cource_info_for_all_nodes;
}

std::string CSourceLoader::PrettifyFileName(const std::string &name)
{
   // Search until we get to a (back)slash or we reach the beginning
   for (int i=(int)name.length()-1; i >= 0; --i) {
      char c = name[i];
      if(c == '/' || c == '\\') {
         // Derive the first part of the name without the slash
         return name.substr(i+1);
      }
   }

   // Else, return the untouched name
   return name;
}

std::string CSourceLoader::PrettifyFuncName(const std::string &name)
{
   // Search until we get to a ':' or we reach end of file
   for (string::size_type i=1, n=name.length(); i<n; ++i) {
      char c = name[i];
      if(c == ':') {
         // Derive the first part of the name without :
         return name.substr(0, i);
      }
   }

   // Else, return the untouched name
   return name;
}

std::ostream& CSourceLoader::Print(std::ostream& o) const
{
   for (map<string, CAlfLabelSource*>::const_iterator l = _label_to_source.begin();
      l != _label_to_source.end(); ++l)
   {
      o << l->first << ';'; l->second->Print(o, ";") << endl;
   }
   return o;
}


std::ostream& CSourceLoader::PrintFiltered(std::ostream& o, std::set<std::string> * label_filter) const
{
   for (map<string, CAlfLabelSource*>::const_iterator l = _label_to_source.begin();
      l != _label_to_source.end(); ++l)
   {
     // Print only those labels that occur in the given filter
     if(label_filter->find(l->first) != label_filter->end()) {
       o << l->first << ';'; l->second->Print(o, ";") << endl;
     }
   }
   return o;
}
