#ifndef STRSTREAM_H_INCLUSION_GUARD
#define STRSTREAM_H_INCLUSION_GUARD

#include <sstream>

/** Wrapper for std::ostringstream to easily create temporary strings with
   the << operator. Useful for e.g. creating error messages for exceptions:

   @verbatim
      throw SomeException((StrStream() << "The object " << some_obj
         << " is broken, and the object " << some_other_obj
         << " is also broken.").Str());
   @endverbatim

   (Note the call to Str() at the end.) This cannot be done with std::ostringstream,
   because the << operator returns a reference to a superclass of std::ostringstream,
   so the function str() cannot be called as easily as above (the returned reference
   needs to be cast down first). */
class StrStream {
public:
   /** Implementation of the << operator. @return A reference to this object. */
   template <typename T>
   StrStream& operator <<(const T& obj) { str_stream << obj; return *this; }

   /** Get the string. Corresponds to the str() function in std::ostringstream. */
   std::string Str() { return str_stream.str(); }

private:
   /** The actual output string stream */
   std::ostringstream str_stream; 
};

#endif
