#ifndef RANGEITERATOR_H_INCL
#define RANGEITERATOR_H_INCL

template <typename Container>
class RangeIterator : public Container::iterator
{
	typedef typename Container::iterator BaseIterator;

public:
	explicit RangeIterator(Container& container)
		: BaseIterator(container.begin()), end(container.end())
	{}

	operator bool() const { return (BaseIterator&)*this != end; }

private:
	BaseIterator end;
};

template <typename Container>
class RangeIterator<const Container> : public Container::const_iterator
{
	typedef typename Container::const_iterator BaseIterator;

public:
	explicit RangeIterator(const Container& container)
		: BaseIterator(container.begin()), end(container.end())
	{}

	operator bool() const { return (BaseIterator&)*this != end; }

private:
	BaseIterator end;
};

#endif	// ifndef RANGEITERATOR_H_INCL
