#ifndef XYOSTREAM_H_INCL
#define XYOSTREAM_H_INCL

#include <ostream>
#include <streambuf>
#include <map>
#include <string>

/** Output stream that performs replacements ("x to y") before writing to a wrapped output stream
   Example usage:
   @verbatim
      xyostream xyos(cout); // wraps 'cout' in 'xyos'
      xyos.set('.', "?");
      xyos << "This is not a question." << endl; // writes "This is not a question?" to 'cout'
   @endverbatim */
template <class charT, class traits = std::char_traits<charT> >
class basic_xyostream : public std::basic_ostream<charT, traits> {
public:
   typedef std::basic_ostream<charT, traits> ostream_type;
   typedef std::basic_streambuf<charT, traits> buf_type;

   basic_xyostream(const ostream_type &towrap)
      : std::basic_ostream<charT, traits>(buf = new basic_xystreambuf(towrap.rdbuf())) {}

   basic_xyostream(buf_type *towrap)
      : std::basic_ostream<charT, traits>(buf = new basic_xystreambuf(towrap)) {}

   /** Registers a replacement of character 'x' by the string 'y' */
   void set(charT x, const charT y[]) { buf->set(x, y); }

   ~basic_xyostream() { delete ostream_type::rdbuf(buf = 0); }

protected:
   class basic_xystreambuf : public buf_type {
   public:
      typedef std::basic_string<charT, traits> string_type;
      typedef std::map<charT, string_type> map_type;

      basic_xystreambuf(buf_type *towrap) : wrapped(towrap) {}

      void set(charT x, const charT y[]) { x2y[x] = string_type(y); }

   protected:
      buf_type *wrapped;
      map_type x2y;

      /** Since no buffer is used, this function is invoked for every character (which is a bit inefficient) */
      virtual typename buf_type::int_type overflow(typename buf_type::int_type c) {
         if (c == traits::eof()) return c;
         typename map_type::const_iterator y = x2y.find(c);
         if (y == x2y.end()) // no replacement was found; simply put the character
            return wrapped->sputc(c);
         // write the replacement text instead
         std::streamsize nput = wrapped->sputn(y->second.c_str(), (std::streamsize)y->second.length());
         return ((typename string_type::size_type)nput == y->second.length()? c : traits::eof());
      }

      // these functions simply delegate everything to the wrapped streambuf
      virtual void imbue(const std::locale &loc) { wrapped->pubimbue(loc); }
      virtual buf_type *setbuf(charT *s, std::streamsize n) { return wrapped->pubsetbuf(s, n); }
      virtual typename buf_type::pos_type seekoff(typename buf_type::off_type off, std::ios_base::seekdir way, std::ios_base::openmode which)
      { return wrapped->pubseekoff(off, way, which); }
      virtual typename buf_type::pos_type seekpos(typename buf_type::pos_type pos, std::ios_base::openmode which)
      { return wrapped->pubseekpos(pos, which); }
      virtual int sync() { return wrapped->pubsync(); }
   }
   *buf;
};

typedef basic_xyostream<std::ostream::char_type, std::ostream::traits_type> xyostream;

#endif // ifndef XYOSTREAM_H_INCL
