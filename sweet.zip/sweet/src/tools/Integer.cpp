#include "Integer.h"

Pool<mpz_class> Integer::pool = Pool<mpz_class>(1000);
