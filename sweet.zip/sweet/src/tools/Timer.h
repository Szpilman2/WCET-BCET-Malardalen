#ifndef TIMER_H_INCLUDED
#define TIMER_H_INCLUDED

#include <ctime>

class Timer
{
public:
	Timer() {Restart();}

   void Restart() {start_time = clock();}

	double GetTime()
	{
      clock_t end_time = clock();
		return double(end_time - start_time) / double(CLOCKS_PER_SEC);
	}

private:
	clock_t start_time;
};

#endif   // #ifndef TIMER_H_INCLUDED
