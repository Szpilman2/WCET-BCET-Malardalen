// $Id: $

#ifndef CSOURCE_LOADER_H_INCLUDED
#define CSOURCE_LOADER_H_INCLUDED

#include "CAlfLabelSource.h"
#include <string>
#include <map>
#include <vector>
#include <set>
#include <fstream>
#include "graphs/cfg/CFlowGraph.h"

namespace alf
{
class LinkLog;
}

class RapitaIntermediate;

/** \class CSourceLoader
   Holds a mapping from alf labels to source code objects. */
class CSourceLoader
{
public:
   typedef std::map<std::string,CAlfLabelSource*>::const_iterator ConstIter;

   /** Constructs a CSourceLoader. Throws an exception if \a file_name can
      not be opened, if any file named in it can not be opened or if some
      mapping information is incomplete.
      \param file_name The map file name to load source code information from.
      \param alf_file_name Name of the ALF file that the map concerns
      \param valid_labels The set of labels occurring in the ALF file @a alf_file_name, do to correctness checking
      \param read_c_source Boolean deciding if lines should be read from referenced c source files.
      \post All information concerning alf labels mapping to c-source
         that can be obtained in \a file_name are loaded. */
   CSourceLoader(std::string file_name, std::string alf_file_name, const std::set<std::string> &valid_labels, bool read_c_source=false);
   ~CSourceLoader();

   /** Link the CSourceLoader objects pointed to by @a linked, resolving name collisions using
      the @a link_log. After the call, @a linked will hold a single pointer to the resulting 
      linked CSourceLoader */
   static void Link(std::vector<CSourceLoader*>& linked, const alf::LinkLog& link_log);

   /** Get the file name of the ALF program that the map concerns */
   const std::string& GetAlfFileName() const {return _alf_file;}

   /** Checks if there is a mapping from a label to some source code object.
      \param alf_label The label to look for.
      \return A pointer to the source code object or NULL if the label has no mapping. */
   const CAlfLabelSource *GetSourceOfLabel(std::string alf_label) const;

   /** Checks if there is a mapping from a label to some source code object and it is 
       the first label of the line in the C source code.
      \param alf_label The label to look for.
      \return A pointer to the source code object or NULL if the label has no mapping 
      or if it is not the first label in the C line */
   const CAlfLabelSource *GetSourceOfLabelIfFirstInCLine(std::string alf_label) const;

   /** Checks if there is a mapping from a label to some c-source line.
      \param alf_label The label to look for.
      \return A string containing the source code portion or an empty string if nothing is known about \a label. */
   std::string GetCLine(std::string alf_label) const;

   /** To get a more informative name from an alf label.
      \param alf_label The label to look for.
      \param delim     The delimiter to separate the file name,
                       line number, and column number.  If this parameter is 0,
                       the default delimiter of CAlfLabelSource is used. */
   std::string GetCSourceNameFromLabel(const std::string &label, const char delim[] = 0) const;

   /** Returns an iterator over the (label,source) pairs */
   ConstIter IterBegin() const { return _label_to_source.begin(); }

   /** @see IterBegin() */
   ConstIter IterEnd() const { return _label_to_source.end(); }

   /** Checks that each basic block or cfg node in the ALF control
       flow graphs has a corresponding c source. The statements of the
       nodes that does not fulfil this are printed out to screen. If
       second argument is false all nodes will be tested, otherwise
       only basic blocks. If basic blocks is tested, it is sufficient
       that at least one of the nodes in teh bb has a c_source
       mapping. Returns true if all nodes have c source info. */
   bool HasCSourceInfoForAllNodes(const std::vector<CFlowGraph *> & flow_graphs, 
                                  bool check_only_basic_blocks=true, RapitaIntermediate * ri=NULL) const;

   /** Returns the file name without the preceding path */
   static std::string PrettifyFileName(const std::string &name);

   /** Returns the given func name or alf label without a lot of ::'s */
   static std::string PrettifyFuncName(const std::string &name);

   /** Print this .map file to the output stream @a o */
   std::ostream& Print(std::ostream& o) const;

   /** Print this .map file to the file named @a file_name */
   void PrintToFile(const std::string& file_name) const
      {std::ofstream file_stream(file_name.c_str()); Print(file_stream);}

   /** Print a .map file only containing the alf labels which occur in the set */
   std::ostream& PrintFiltered(std::ostream& o, std::set<std::string> * label_filter) const;

   void PrintToFileFiltered(const std::string& file_name, std::set<std::string> * label_filter) const
   {std::ofstream file_stream(file_name.c_str()); PrintFiltered(file_stream, label_filter);}

private:

   /** Checks if this is the first source associated with the given source code line. */
   bool IsInFirstSourceMap(const CAlfLabelSource * source) const;
   void InsertInFirstSourceMap(CAlfLabelSource * source);

   /** Returns whether there are name conflicts between @a first and @a second, which means
      that they both map from the same identifier */
   static bool NoNameCollisions(const std::map<std::string, CAlfLabelSource *>& first,
      const std::map<std::string, CAlfLabelSource *>& second);
   static bool AssertAndErrorMessageIfNameCollisions(const std::map<std::string, CAlfLabelSource *>& first,
      const std::map<std::string, CAlfLabelSource *>& second);

   /** The file name of the ALF program that the map concerns */
   std::string _alf_file;

   /** To keep track of the first source item of each c source code line */ 
   std::map<std::pair<std::string, unsigned>, CAlfLabelSource *> _first_source_map;
   std::map<std::string, CAlfLabelSource *> _label_to_source;
};

inline std::ostream& operator <<(std::ostream& o, const CSourceLoader& source_loader)
   {return source_loader.Print(o);}

#endif
