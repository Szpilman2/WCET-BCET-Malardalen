#ifndef XASSERT_H_INCLUDED
#define XASSERT_H_INCLUDED

#include <stdexcept>
#include <sstream>

#ifndef NDEBUG

#define XASSERT(pred) \
   if (!(pred)) \
      throw FailedXAssert(#pred, __FILE__, __LINE__)

#else // #ifndef NDEBUG

class Void
{
public:
   template <typename T> Void& operator <<(const T& object) {return *this;}
};

#define XASSERT(pred) \
   if (false) Void()

#endif // #ifndef NDEBUG

class FailedXAssert : public std::logic_error
{
public:
   FailedXAssert(const char* assertion, const char* file_name, unsigned line_nr)
      : std::logic_error("")
   {
      *this << "File " << file_name << ", line " << line_nr << ": Assertion "
         << assertion << " failed. ";
   }

   FailedXAssert(const FailedXAssert& other)
      : std::logic_error(other), msg_string(other.msg_string) {}

   virtual ~FailedXAssert() throw() {}

   template <typename T> FailedXAssert& operator <<(const T& object)
   {
      msg_stream << object;
      msg_string += msg_stream.str();
      msg_stream.str(std::string());
      return *this;
   }

   virtual const char* what() const throw() {return msg_string.c_str();}

private:
   std::ostringstream msg_stream;
   std::string msg_string;
};

#endif   // #ifndef XASSERT_H_INCLUDED
