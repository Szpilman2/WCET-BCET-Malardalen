#include "SignalHandling.h"
#include <csignal>

namespace SignalHandling
{

Handler * sigint_handler = 0;

static void SIGINTHandler(int parameter)
{
   (*sigint_handler)(parameter);
   signal(SIGINT, &SIGINTHandler);
}

void RegisterSIGINTHandler(Handler * handler)
{
   sigint_handler = handler;
   signal(SIGINT, &SIGINTHandler);
}

}
