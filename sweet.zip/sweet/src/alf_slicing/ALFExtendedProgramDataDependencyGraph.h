#ifndef ALFEXTENDEDPROGRAMDATADEPENDENCYGRAPH_H_
#define ALFEXTENDEDPROGRAMDATADEPENDENCYGRAPH_H_

#include "absann/CALFAbsAnnot.h"
#include "graphs/cg/CCallGraph.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CInitList.h"
#include "program/alf/CInitTuple.h"
#include "program/alf/AStmt.h"
#include "rd/ALFReachingDefinitionsAnalysis.h"
#include "dfa/ALFDefsAndUsesAnalysis.h"
#include "alf_slicing/ALFExtendedProgramGraphNode.h"
#include "alf_slicing/ALFExtendedProgramControlFlowGraph.h"
#include "graphs/tools/CGraph.h"
#include "symtab/CSymTabBase.h"

#include <set>
#include <vector>
#include <list>

using namespace alf;

// -------------------------------------------------------
// A data dependency graph PDDG over the whole program. The nodes are extended
// program nodes, meaning that each node can hold either a statement, a
// annot, a declaration or an initialization or an assignment. The 
// graph is created from a PCFG, and the ids of the nodes of the two graphs
// are mapped to each other using the Id():s of the nodes. Basically, a node
// in the PCFG with a Id() of i are mapped to the node in the PDDG with an
// Id() of i. This fact are used in the building of the PDG.
// -------------------------------------------------------
class 
ALFExtendedProgramDataDependencyGraph : public CGraph<ALFExtendedProgramGraphNode, ALFExtendedProgramGraphEdge>
{
public:
  // To create and delete the graph
  ALFExtendedProgramDataDependencyGraph() {};
  virtual ~ALFExtendedProgramDataDependencyGraph () {};

  // To draw the created graph
  void Draw(std::ostream & s = std::cout);

protected:

};

// -------------------------------------------------------
// A class for building a program data dependency graph.
// -------------------------------------------------------
class 
ALFExtendedProgramDataDependencyGraphBuilder
{
public:

  // ---------------------------------
  // To create and delete the builder class. Argument is owned by caller.
  // ---------------------------------
  ALFExtendedProgramDataDependencyGraphBuilder() { };
  virtual ~ALFExtendedProgramDataDependencyGraphBuilder() { };

  // To create an extended program dependency graph
  ALFExtendedProgramDataDependencyGraph * Build(ALFExtendedProgramControlFlowGraph * epcfg, ALFReachingDefinitionsAnalysis * rd, 
						ALFDefsAndUsesAnalysis * du, CSymTabBase * symtab);
			
protected:

  // To hold the program dependendency graph created
  ALFExtendedProgramDataDependencyGraph * _epddg;

};

#endif
