#ifndef ALFEXTENDEDPROGRAMDEPENDENCYGRAPH_H_
#define ALFEXTENDEDPROGRAMDEPENDENCYGRAPH_H_

#include "absann/CALFAbsAnnot.h"
#include "graphs/cg/CCallGraph.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CInitTuple.h"
#include "program/alf/AStmt.h"
#include "rd/ALFReachingDefinitionsAnalysis.h"
#include "alf_slicing/ALFExtendedProgramGraphNode.h"
#include "alf_slicing/ALFExtendedProgramGraphEdge.h"
#include "alf_slicing/ALFExtendedProgramControlDependencyGraph.h"
#include "alf_slicing/ALFExtendedProgramDataDependencyGraph.h"
#include "dfa/ALFDefsAndUsesAnalysis.h"
#include "graphs/tools/CGraph.h"
#include "graphs/tools/CNode.h"
#include "symtab/CSymTabBase.h"

#include <set>
#include <vector>
#include <list>

using namespace alf;

// -------------------------------------------------------
// A dependency graph over the whole program. The nodes are extended
// program nodes, meaning that each node can hold either a statement, a
// annot, a declaration or an initialization.
// -------------------------------------------------------
class 
ALFExtendedProgramDependencyGraph : public CGraph<ALFExtendedProgramGraphNode, ALFExtendedProgramGraphEdge>
{
public:
  // To create and delete the graph
  ALFExtendedProgramDependencyGraph () {};
  virtual ~ALFExtendedProgramDependencyGraph () {};

  // To draw the created graph
  void Draw(std::ostream & s = std::cout);
  // To draw a specific slice of the graph
  void DrawSlice(std::ostream & s = std::cout, std::set<ALFExtendedProgramGraphNode *> * nodes_in_slice=NULL,
		  std::set<ALFExtendedProgramGraphEdge *> * edges_in_slice=NULL);
};

// ------------------------------------------------------- 
// Class for deriving an extended program dependency graph (PDG).  The
// PDG is the underlying graph that is used in traditional slicing to
// derive what variables and statements that may affect or may be
// affected by a given variable or statement. 
// 
// To derive a PDG we make use of the follwing graphs:
//
// 1. PCFG - a control-flow graph that goes over the *whole* program
// and may include several function CFGs and function call and return
// edges. I.e. an union of all CFGs and the CG. 
//
// 2. PCDG - a program control dependency graph. A graph which gives
// all the control dependencies between nodes in the PCFG. A n1 is
// control dependent on a condition node n2 if the execution of n2 may
// decide whether or not n1 will be executed.
//
// 3. PDDG - a program data dependency graph. A graph holding the data
// dependencies between the nodes in the PCFG. If a node n may use a
// variable v and a definition of v may reach n from a node m, then
// there is a edge from m to n in the PDDG. Derived using a def use
// (DU) analysis and a reaching definition (RD) made on the whole
// program. Both the DU and RD analyses makes use of a pointer
// analysis (PA) result.
//
// The PDG is then the union of the PCDG and PDDG. 
//
// The nodes in the different graphs are extended program graph nodes. 
// Each node is a container pointing to a stmt, an annot, a declaration (alloc) 
// or and init. The reason for including more than statements is that 
// they all may define variables. 
//
// All created graphs will have the same number of nodes as the PCFG.
// To fuse the different graphs into one PDG graph we make use of the 
// node->Id() mapping between the different graphs. ALso, we might make
// use of the graph->NodeAt(i) mapping. I.e. if we create nodes n_pdg
// n_pddg and n_pcdg from a node n_pcfg we assume that we later on can 
// go between the different nodes using the given mappings. 
// 
// Since the RD analysis is made on another graph than PCFG we use 
// the stmt, annots, allocs and inits in the nodes to map results 
// from the RD analysis to the PDDG analysis.  This requires that 
// the same stmt, annot, alloc or init does not occur in more than
// one node in the PDG. Thus, a context-sensitive PDG is currently 
// hard to derive... 
// -------------------------------------------------------
class 
ALFExtendedProgramDependencyGraphBuilder
{
public:

  // To create and delete the builder class. 
  ALFExtendedProgramDependencyGraphBuilder() { };
  virtual ~ALFExtendedProgramDependencyGraphBuilder() { };

  // To create an extended program dependency graph.  
  ALFExtendedProgramDependencyGraph * Build(ALFExtendedProgramControlFlowGraph * epcfg,
					    ALFReachingDefinitionsAnalysis * rd,
					    ALFDefsAndUsesAnalysis * du,
					    CSymTabBase * symtab);
  // To create the dependency grap. Will also return some other
  // interesting graphs. Caller is responsible to deallocate them.
  ALFExtendedProgramDependencyGraph * Build(ALFExtendedProgramControlFlowGraph * epcfg,
					    ALFReachingDefinitionsAnalysis * rd,
					    ALFDefsAndUsesAnalysis * du,
					    CSymTabBase * symtab,
					    ALFExtendedProgramControlDependencyGraph **epcdg,
					    ALFExtendedProgramDataDependencyGraph **epddg);
protected:

  // Help functions

  // Add nodes to epdg according to the nodes found in the epcfg
  void AddNodes(ALFExtendedProgramDependencyGraph * epdg,
		ALFExtendedProgramControlFlowGraph * epcfg);
  // Add edges to epdg according to the edges found in the epcdg 
  void AddControlDependencyEdges(ALFExtendedProgramDependencyGraph * epdg,
				 ALFExtendedProgramControlDependencyGraph * epcdg);
  // Add edges to epdg according to the edges found in the epddg 
  void AddDataDependencyEdges(ALFExtendedProgramDependencyGraph * epdg, 
			      ALFExtendedProgramDataDependencyGraph * epddg);

};

#endif
