#include "alf_slicing/ALFExtendedProgramGraphNode.h"
#include "program/alf/CFuncTuple.h"
#include "program/alf/CGenericNode.h"
#include "graphs/tools/CNode.inl"
#include "program/alf/CInitTuple.h"
#include "program/alf/CRefTuple.h"
#include "program/alf/CExprList.h"

// -------------------------------------------------------
// ALFExtendedProgramGraphNode
// -------------------------------------------------------

// Function for drawing nodes in a nice format
void
ALFExtendedProgramGraphNode::
Draw(std::ostream & s) const 
{
  // Call detailed draw function
  DrawContent(s);

  // Draw the type of the node
  s << GetTypeAsString();
  s << " " << Id() << "";
}

void
ALFExtendedProgramGraphNodeFuncAlloc::
DrawContent(std::ostream & s) const
{
  alf::CFuncTuple * func = 
    dynamic_cast<alf::CFuncTuple *>(_alloc->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE));
  s << func->Name() << " ";
  s << "var: " << _alloc->Name();
  if(_alloc->HasKey()) {
    s << " " << _alloc->GetKey();
  }
  s << "\\n";
}

void
ALFExtendedProgramGraphNodeGlobalAlloc::
DrawContent(std::ostream & s) const
{
  s << "var: " << _alloc->Name();
  if(_alloc->HasKey()) {
    s << " " << _alloc->GetKey();
  }
  s << "\\n";
}

void
ALFExtendedProgramGraphNodeCallEnterAssign::
DrawContent(std::ostream & s) const
{
  // Derive the argument index
  unsigned int arg_index = 0; 
  const alf::CExprList * call_exprs = GetCallStmt()->GetExprs();
  for(alf::CExprList::const_list_iterator call_expr = call_exprs->ConstIterator();
      call_expr != call_exprs->InvalidIterator(); ++call_expr, arg_index++) {
    if((*call_expr) == _call_expr) 
      break;
  }
  // Print the result
  s << GetCallStmt()->Name() << " " << GetCallFunc()->Name() << " -> " << GetEnterFunc()->Name();
  s << "\\n" << "arg: " << arg_index << " "; 
}

void
ALFExtendedProgramGraphNodeReturnResultAssign::
DrawContent(std::ostream & s) const
{
  // Derive the argument index
  unsigned int arg_index = 0; 
  const alf::CExprList * return_exprs = GetReturnStmt()->GetExprs();
  for(alf::CExprList::const_list_iterator return_expr = return_exprs->ConstIterator();
      return_expr != return_exprs->InvalidIterator(); ++return_expr, arg_index++) {
    if((*return_expr) == _return_expr) 
      break;
  }
  // Print the result
  s << GetReturnStmt()->Name() << " " << GetReturnFunc()->Name() << " -> " 
    << GetResultStmt()->Name() << " " << GetResultFunc()->Name();
  s << "\\n" << "arg: " << arg_index << " "; 
}

void
ALFExtendedProgramGraphNodeRootFuncEnterAssign::
DrawContent(std::ostream & s) const
{
  // Derive the argument index
  unsigned int arg_index = 0; 
  const alf::CArgDeclList * arg_allocs = 
    dynamic_cast<alf::CArgDeclList *>(_enter_alloc->GetParent(alf::CGenericNode::TYPE_ARGDECL_LIST));
  for(alf::CArgDeclList::const_list_iterator arg_alloc = arg_allocs->ConstIterator();
      arg_alloc != arg_allocs->InvalidIterator(); ++arg_alloc, arg_index++) {
    if((*arg_alloc) == _enter_alloc) 
      break;
  } 
  // Print the result
  s << GetEnterFunc()->Name() << " arg: " << arg_index << "\\n"; 
}


void
ALFExtendedProgramGraphNodeRootFuncReturnAssign::
DrawContent(std::ostream & s) const
{
  // Derive the argument index
  unsigned int arg_index = 0; 
  const alf::CExprList * return_exprs = GetReturnStmt()->GetExprs();
  for(alf::CExprList::const_list_iterator return_expr = return_exprs->ConstIterator();
      return_expr != return_exprs->InvalidIterator(); ++return_expr, arg_index++) {
    if((*return_expr) == _return_expr) 
      break;
  }
  // Print the result
  s << GetReturnStmt()->Name() << " " << GetReturnFunc()->Name()  << " arg: " << arg_index << "\\n"; 
}

void
ALFExtendedProgramGraphNodeGlobalInit::
DrawContent(std::ostream & s) const
{
  const alf::CRefTuple * ref = _init->GetRef();
  s << "var: " << ref->Name();
  s << "\\n";
}


void
ALFExtendedProgramGraphNodeStmt::
DrawContent(std::ostream & s) const
{
  s << _stmt->Name();
  alf::CFuncTuple * func = 
    dynamic_cast<alf::CFuncTuple *>(_stmt->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE));
  s << " " << func->Name();
  s << "\\n";
}

void
ALFExtendedProgramGraphNodeFuncEntry::
DrawContent(std::ostream & s) const
{
  s << "func: " << _func->Name();
  s << "\\n";
}

// To print the ALFExtendedProgramGraphNode
void
ALFExtendedProgramGraphNode::
Print(std::ostream & s) const 
{
  Draw(s);
}

string
ALFExtendedProgramGraphNode::
GetTypeAsString(TYPE type) const
{
  switch(type)
    {
    case PROG_ENTRY: { return "PROG_ENTRY"; } 
    case PROG_EXIT: { return "PROG_EXIT"; } 
    case FUNC_ENTRY: { return "FUNC_ENTRY"; } 

    case FUNC_ENTRY_ANNOT: { return "FUNC_ENTRY_ANNOT"; } 
    case PROG_ENTRY_ANNOT: { return "PROG_ENTRY_ANNOT"; }
    case STMT_ENTRY_ANNOT: { return "STMT_ENTRY_ANNOT"; }
    case STMT_EXIT_ANNOT: { return "STMT_EXIT_ANNOT"; }

    case GLOBAL_ALLOC_ASSIGN: { return "GLOBAL_ALLOC_ASSIGN"; }
    case GLOBAL_INIT: { return "GLOBAL_INIT"; }
    case FUNC_ALLOC_ASSIGN: { return "FUNC_ALLOC_ASSIGN"; }

    case CALL_ENTER_ASSIGN: { return "CALL_ENTER_ASSIGN"; }
    case RETURN_RESULT_ASSIGN: { return "RETURN_RESULT_ASSIGN"; }
    case ROOT_FUNC_ENTER_ASSIGN: { return "ROOT_FUNC_ENTER_ASSIGN"; }
    case ROOT_FUNC_RETURN_ASSIGN: { return "ROOT_FUNC_RETURN_ASSIGN"; }

    case STORE_STMT: { return "STORE_STMT"; }
    case CALL_STMT: { return "CALL_STMT"; }   
    case RESULT_STMT: { return "RESULT_STMT"; }
    case RETURN_STMT: { return "RETURN_STMT"; }      
    case NULL_STMT: { return "NULL_STMT"; }        
    case SWITCH_STMT: { return "SWITCH_STMT"; }      
    case JUMP_STMT: { return "JUMP_STMT"; }        
    case FREE_STMT: { return "FREE_STMT"; }        
    }
  return "";
} 

// Alternative printing function
ostream &operator << (ostream &o, ALFExtendedProgramGraphNode &a) 
{
  a.Print(o);
  return o;
}

// -------------------------------------------------------
// Functions for creating a node of a certain type
// -------------------------------------------------------
ALFExtendedProgramGraphNode * 
ALFExtendedProgramGraphNode::
CreateNode(TYPE type)
{
  switch(type) {
  case PROG_ENTRY: {
    return new ALFExtendedProgramGraphNodeProgEntry();
    break;
  }
  case PROG_EXIT: {
    return new ALFExtendedProgramGraphNodeProgExit();
    break;
  }
  default: {
    assert(0);
    return NULL;
  }
  }
} 

ALFExtendedProgramGraphNode * 
ALFExtendedProgramGraphNode::
CreateNode(alf::CFuncTuple * func, TYPE type)
{
  assert(type == FUNC_ENTRY);
  return new ALFExtendedProgramGraphNodeFuncEntry(func);
}

ALFExtendedProgramGraphNode * 
ALFExtendedProgramGraphNode::
CreateNode(CALFAbsAnnot * annot, TYPE type, alf::CFuncTuple * func, alf::AStmt * stmt)
{
  switch(type) {
  case PROG_ENTRY_ANNOT: {
    return new ALFExtendedProgramGraphNodeProgEntryAnnot(annot);
    break;
  }
  case FUNC_ENTRY_ANNOT: {
    assert(func);
    return new ALFExtendedProgramGraphNodeFuncEntryAnnot(annot, func);
    break;
  }
  case STMT_ENTRY_ANNOT: {
    assert(stmt);
    return new ALFExtendedProgramGraphNodeStmtEntryAnnot(annot, stmt);
    break;
  }
  case STMT_EXIT_ANNOT: {
    assert(stmt);
    return new ALFExtendedProgramGraphNodeStmtExitAnnot(annot, stmt);
    break;
  }
default: {
    assert(0);
    return NULL;
  }
  }
} 

ALFExtendedProgramGraphNode * 
ALFExtendedProgramGraphNode::
CreateNode(alf::CAllocTuple * alloc, TYPE type)
{
  if(type == GLOBAL_ALLOC_ASSIGN) {
    return new ALFExtendedProgramGraphNodeGlobalAlloc(alloc);
  }
  else if(type == FUNC_ALLOC_ASSIGN) {
    return new ALFExtendedProgramGraphNodeFuncAlloc(alloc);
  }
  else if(type == ROOT_FUNC_ENTER_ASSIGN) {
    return new ALFExtendedProgramGraphNodeRootFuncEnterAssign(alloc);
  }
  else {
    assert(0);
    return NULL;
  }
}

ALFExtendedProgramGraphNode * 
ALFExtendedProgramGraphNode::
CreateNode(alf::CInitTuple * init, TYPE type)
{
  assert(type == GLOBAL_INIT);
  return new ALFExtendedProgramGraphNodeGlobalInit(init);
}

ALFExtendedProgramGraphNode * 
ALFExtendedProgramGraphNode::
CreateNode(alf::AStmt * stmt, TYPE type)
{
  switch(type) {
  case STORE_STMT: {
    return new ALFExtendedProgramGraphNodeStoreStmt(dynamic_cast<alf::CStoreStmtTuple *>(stmt));
    break;
  }
  case CALL_STMT: {
    return new ALFExtendedProgramGraphNodeCallStmt(dynamic_cast<alf::CCallStmtTuple *>(stmt));
    break;
  }
  case RESULT_STMT: {
    return new ALFExtendedProgramGraphNodeResultStmt(dynamic_cast<alf::CCallStmtTuple *>(stmt));
    break;
  }
  case RETURN_STMT: {
    return new ALFExtendedProgramGraphNodeReturnStmt(dynamic_cast<alf::CReturnStmtTuple *>(stmt));
    break;
  }
  case NULL_STMT: {
    return new ALFExtendedProgramGraphNodeNullStmt(dynamic_cast<alf::CNullStmtTuple *>(stmt));
    break;
  }
  case SWITCH_STMT: {
    return new ALFExtendedProgramGraphNodeSwitchStmt(dynamic_cast<alf::CSwitchStmtTuple *>(stmt));
    break;
  }
  case JUMP_STMT: {
    return new ALFExtendedProgramGraphNodeJumpStmt(dynamic_cast<alf::CJumpStmtTuple *>(stmt));
    break;
  }
  case FREE_STMT: {
    return new ALFExtendedProgramGraphNodeFreeStmt(dynamic_cast<alf::CFreeStmtTuple *>(stmt));
    break;
  }
  default: {
    assert(0);
    return NULL;
  }
  }
}

ALFExtendedProgramGraphNode * 
ALFExtendedProgramGraphNode::
CreateNode(alf::AExpr * return_expr, TYPE type)
{
  assert(type == ROOT_FUNC_RETURN_ASSIGN);
  return new ALFExtendedProgramGraphNodeRootFuncReturnAssign(return_expr);
}

ALFExtendedProgramGraphNode * 
ALFExtendedProgramGraphNode::
CreateNode(alf::AExpr * call_expr, alf::CAllocTuple * enter_alloc, TYPE type)
{
  assert(type == CALL_ENTER_ASSIGN);
  return new ALFExtendedProgramGraphNodeCallEnterAssign(call_expr, enter_alloc);
}

ALFExtendedProgramGraphNode * 
ALFExtendedProgramGraphNode::
CreateNode(alf::AExpr * return_expr, alf::AExpr * result_expr, TYPE type)
{
  assert(type == RETURN_RESULT_ASSIGN);
  return new ALFExtendedProgramGraphNodeReturnResultAssign(return_expr, result_expr);
}

// Static help function to partition nodes
void
ALFExtendedProgramGraphNode::
PartitionNodesBasedOnFunctionNameTheyBelongsTo(const std::vector<ALFExtendedProgramGraphNode *> * nodes,
					       std::vector<ALFExtendedProgramGraphNode *> * global_nodes,
					       std::map<std::string, std::vector<ALFExtendedProgramGraphNode *> *> * func_name_to_nodes)
{
  for(std::vector<ALFExtendedProgramGraphNode *>::const_iterator n = nodes->begin(); n != nodes->end(); ++n) {
    // Get the function name
    std::string func_name = (*n)->GetNameOfFunctionNodeBelongsTo();
    // Treat global nodes specially
    if(func_name == "") {
      global_nodes->push_back(*n);
    }
    else {
      // Add the node to the vector of teh function
      if(func_name_to_nodes->find(func_name) == func_name_to_nodes->end()) 
	(*func_name_to_nodes)[func_name] = new std::vector<ALFExtendedProgramGraphNode *>;
      (*func_name_to_nodes)[func_name]->push_back(*n);
    }
  }
}

// To get nodes of a certain type
void 
ALFExtendedProgramGraphNode::
ExtractNodesOfType(const std::vector<ALFExtendedProgramGraphNode *> * nodes, 
		   TYPE type, std::vector<ALFExtendedProgramGraphNode *> * nodes_with_type)
{
  for(std::vector<ALFExtendedProgramGraphNode *>::const_iterator n = nodes->begin(); n != nodes->end(); ++n) {
    if((*n)->GetType() == type)
      nodes_with_type->push_back(*n);
  }
}

void 
ALFExtendedProgramGraphNode::
ExtractNodesOfBaseType(const std::vector<ALFExtendedProgramGraphNode *> * nodes, 
		       BASE_TYPE base_type, std::vector<ALFExtendedProgramGraphNode *> * nodes_with_base_type)
{
  for(std::vector<ALFExtendedProgramGraphNode *>::const_iterator n = nodes->begin(); n != nodes->end(); ++n) {
    if((*n)->GetBaseType() == base_type)
      nodes_with_base_type->push_back(*n);
  }
}
  
