#ifndef ALFSLICING_H_
#define ALFSLICING_H_

#include "absann/CALFAbsAnnot.h"
#include "graphs/cg/CCallGraph.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CInitTuple.h"
#include "graphs/scopes/CScope.h"
#include "alf_slicing/ALFExtendedProgramDependencyGraph.h"
#include "alf_slicing/ALFExtendedProgramGraphNode.h"
#include "symtab/CSymTabBase.h"

#include <set>
#include <list>
#include <map>

// -------------------------------------------------------
// ALFSlicing -- 
// Slicing algorithm based on a Extended Program Dependency Graph
// (EPDG). All slicing calls will first derive the cfg node / stmts that
// corresponds to the given start condition. The corresponding epg
// nodes will then be derived from the cfg nodes / stmts and use as start
// nodes in the slice. The slice will be made on the epdg graph as a
// forward or backward reachability search. The pdg nodes in the
// resulting slice is then use to derive the stmts, annots, allocs and
// inits to keep in the slice. Optionally, the vars which have
// declarations in the slice can be return as a set of variable keys
// (unsigned int). If the draw_slice_stream is given we may print a 
// resulting udot graph to the given stream.
// -------------------------------------------------------
class ALFSlicing
{
public:

  // To create and delete the slicing analysis. 
  ALFSlicing(ALFExtendedProgramDependencyGraph * epdg, ALFDefsAndUsesAnalysis * du);
  virtual ~ALFSlicing();
  
  // We can either do forward or backward slicing
  typedef enum SLICE_DIRECTION { FORWARD, BACKWARD } SLICE_DIRECTION;
  
  // -------------------------------------------------------
  // Slicing functions
  // -------------------------------------------------------

  // To get the slice of a certain statement or a certain set of statements
  void GetSliceOfStmt(alf::AStmt * stmt, SLICE_DIRECTION dir,
		      std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
		      std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
		      std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);
  void GetSliceOfStmts(std::set<alf::AStmt *> * ss, SLICE_DIRECTION dir, std::set<unsigned int> * vars);
  void GetSliceOfStmts(std::set<alf::AStmt *> * ss, SLICE_DIRECTION dir,
		       std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
		       std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
		       std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);

  // To get the slice of the conditional nodes in all cfgs in a cg 
  void GetConditionalNodesOfCGSlice(CCallGraph * cg, SLICE_DIRECTION dir, std::set<unsigned int> * vars);
  void GetConditionalNodesOfCGSlice(CCallGraph * cg, SLICE_DIRECTION dir,
				    std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
				    std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
				    std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);

  // To get the slice of the conditional nodes in a set of cfgs 
  void GetConditionalNodesOfCFGsSlice(std::set<CFlowGraph *> * cfgs, SLICE_DIRECTION dir, std::set<unsigned int> * vars);
  void GetConditionalNodesOfCFGsSlice(std::set<CFlowGraph *> * cfgs, SLICE_DIRECTION dir,
				      std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
				      std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
				      std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);

  // To get the slice of the conditional nodes in a cfg 
  void GetConditionalNodesOfCFGSlice(CFlowGraph * cfg, SLICE_DIRECTION dir, std::set<unsigned int> * vars);
  void GetConditionalNodesOfCFGSlice(CFlowGraph * cfg, SLICE_DIRECTION dir,
				     std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
				     std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
				     std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);

  // To get the slice of the conditional nodes in a scope 
  void GetConditionalNodesOfScopeSlice(CScope * scope, SLICE_DIRECTION dir, std::set<unsigned int> * vars);
  void GetConditionalNodesOfScopeSlice(CScope * scope, SLICE_DIRECTION dir,
				       std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
				       std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
				       std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);
  
  // To get the slice of the conditional conditions in a component as slicing condition
  void GetConditionalNodesOfComponentSlice(CComponent<CFlowGraphNode> * component, SLICE_DIRECTION dir, std::set<unsigned int> * vars);
  void GetConditionalNodesOfComponentSlice(CComponent<CFlowGraphNode> * component, SLICE_DIRECTION dir,
					   std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
					   std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
					   std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);

  // To get the slice of the loop exit conditions in all cfgs in a cg as slicing condition
  void GetLoopExitNodesOfCGSlice(CCallGraph * cg, SLICE_DIRECTION dir, std::set<unsigned int> * vars);
  void GetLoopExitNodesOfCGSlice(CCallGraph * cg, SLICE_DIRECTION dir,
				 std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
				 std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
				 std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);

  // To get the slice of the loop exit conditions in a set of cfgs as slicing condition
  void GetLoopExitNodesOfCFGsSlice(std::set<CFlowGraph *> * cfgs, SLICE_DIRECTION dir, std::set<unsigned int> * vars);
  void GetLoopExitNodesOfCFGsSlice(std::set<CFlowGraph *> * cfgs, SLICE_DIRECTION dir,
				   std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
				   std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
				   std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);

  // To get the slice of the loop exit conditions in a cfg as slicing condition
  void GetLoopExitNodesOfCFGSlice(CFlowGraph * cfg, SLICE_DIRECTION dir, std::set<unsigned int> * vars);
  void GetLoopExitNodesOfCFGSlice(CFlowGraph * cfg, SLICE_DIRECTION dir,
				  std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
				  std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
				  std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);

  // To get the slice of the loop exit conditions in a scope as slicing condition
  void GetLoopExitNodesOfScopeSlice(CScope * scope, SLICE_DIRECTION dir, std::set<unsigned int> * vars);
  void GetLoopExitNodesOfScopeSlice(CScope * scope, SLICE_DIRECTION dir,
				    std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
				    std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
				    std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);

  // To get the slice of the loop exit conditions in a component as slicing condition
  void GetLoopExitNodesOfComponentSlice(CComponent<CFlowGraphNode> * component, SLICE_DIRECTION dir, std::set<unsigned int> * vars);
  void GetLoopExitNodesOfComponentSlice(CComponent<CFlowGraphNode> * component, SLICE_DIRECTION dir,
					std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
					std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
					std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);

  // To get the slice of things that may be affected by a given variable. We first derive all PDG nodes that
  // may use the given var. After that we derive a forward slice upon these nodes. 
  void GetAffectedByVarSlice(unsigned int v, std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			     std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			     std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);
  void GetAffectedByVarsSlice(std::set<unsigned int> * vs, std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			     std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			     std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);

  // To get the slice of things that may affect the value of given var(s). We first derive all PDG nodes
  // that may define var(s). After that we derive a backward slice upon these nodes.
  void GetAffectingVarSlice(unsigned int v, std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			    std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			    std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);
  void GetAffectingVarsSlice(std::set<unsigned int> * vs, std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			     std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			     std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);

  // To get the things that may affect the return value of the program. This is derived by doing a backward
  // slice with the return nodes of root node in the CG as criterion.
  void GetProgramReturnValueSlice(CCallGraph * cg, std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
				  std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
				  std::set<unsigned int> * vars, std::ostream * draw_slice_stream=NULL);

  // To get conditional cfg nodes in a given code part
  void GetConditionalNodesOfCG(CCallGraph * cg, std::list<CFlowGraphNode *> * cond_nodes);
  void GetConditionalNodesOfCFGs(std::set<CFlowGraph *> * cfgs, std::list<CFlowGraphNode *> * cond_nodes);
  void GetConditionalNodesOfCFG(CFlowGraph * cfg, std::list<CFlowGraphNode *> * cond_nodes);
  void GetConditionalNodesOfScope(CScope * scope, std::list<CFlowGraphNode *> * cond_nodes);
  void GetConditionalNodesOfComponent(CComponent<CFlowGraphNode> *component, std::list<CFlowGraphNode *> * cond_nodes);
  
  // To get loop exit cfg nodes in a given code part
  void GetLoopExitNodesOfCG(CCallGraph * cg, std::list<CFlowGraphNode *> * loop_exit_nodes);
  void GetLoopExitNodesOfCFGs(std::set<CFlowGraph *> * cfgs, std::list<CFlowGraphNode *> * loop_exit_nodes);
  void GetLoopExitNodesOfCFG(CFlowGraph * cfg, std::list<CFlowGraphNode *> * loop_exit_nodes);
  void GetLoopExitNodesOfScope(CScope * scope, std::list<CFlowGraphNode *> * loop_exit_nodes);
  void GetLoopExitNodesOfComponent(CComponent<CFlowGraphNode> * component, std::list<CFlowGraphNode *> * loop_exit_nodes);

protected:

  // -------------------------------------------------------
  // Help functions
  // -------------------------------------------------------

  // To get the epfg nodes that corresponds to given cfg nodes 
  void GetEPGNodesFromCFGNodes(std::list<CFlowGraphNode *> * cfg_nodes, std::set<ALFExtendedProgramGraphNode *> * epg_nodes);

  // To get epfg nodes from statements
  void GetEPGNodesFromStmts(std::set<alf::AStmt *> * start_stmts, 
			    std::set<ALFExtendedProgramGraphNode *> * epg_start_nodes);
  void GetEPGNodesFromStmt(alf::AStmt * start_stmt, 
			   std::set<ALFExtendedProgramGraphNode *> * epg_start_nodes);

  // To get epfg nodes which may define given vars
  void GetEPGNodesWhichMayDefineVars(std::set<unsigned int> * vars, 
				     std::set<ALFExtendedProgramGraphNode *> * epg_start_nodes);
  void GetEPGNodesWhichMayUseVars(std::set<unsigned int> * vars, 
				  std::set<ALFExtendedProgramGraphNode *> * epg_start_nodes);
  
  // To get the slice of epg nodes given a set of start nodes
  void GetSlice(ALFExtendedProgramGraphNode * start_node, 
		std::set<ALFExtendedProgramGraphNode *> * nodes_in_slice, 
		std::set<ALFExtendedProgramGraphEdge *> * edges_in_slice, 
		SLICE_DIRECTION dir);
  void GetSlice(std::set<ALFExtendedProgramGraphNode *> * start_nodes, 
		std::set<ALFExtendedProgramGraphNode *> * nodes_in_slice, 
		std::set<ALFExtendedProgramGraphEdge *> * edges_in_slice, 
		SLICE_DIRECTION dir);

  // To partion nodes in slice based on their type. Will also extract
  // the keys of the variables declared in the slice.
  void PartitionNodesOnTypes(std::set<ALFExtendedProgramGraphNode *> * pdg_nodes,
			     std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			     std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			     std::set<unsigned int> * vars);
  
  // For fast retrieval of epdg node corresponding to a given statement
  std::map<alf::AStmt *, std::set<ALFExtendedProgramGraphNode *> *> _stmt_to_nodes;

  // The pdg graph upon which the actual slice derivation will be made
  ALFExtendedProgramDependencyGraph * _epdg;
  ALFDefsAndUsesAnalysis * _du;
};


#endif



    
    
  
    

	    


