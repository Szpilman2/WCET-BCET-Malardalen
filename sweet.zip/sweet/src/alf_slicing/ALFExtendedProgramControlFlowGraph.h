#ifndef ALFEXTENDEDPROGRAMCONTROLFLOWGRAPH_H_
#define ALFEXTENDEDPROGRAMCONTROLFLOWGRAPH_H_

#include "absann/CALFAbsAnnot.h"
#include "graphs/cg/CCallGraph.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CFuncTuple.h"
#include "program/alf/CInitList.h"
#include "program/alf/CInitTuple.h"
#include "program/alf/AStmt.h"
#include "program/alf/CCallStmtTuple.h"
#include "program/alf/CReturnStmtTuple.h"
#include "alf_slicing/ALFExtendedProgramGraphNode.h"
#include "alf_slicing/ALFExtendedProgramGraphEdge.h"
#include "graphs/tools/CGraph.h"

#include <set>
#include <vector>
#include <list>

using namespace alf;



// -------------------------------------------------------
// A control flow graph over the whole program. The nodes are extended
// program nodes, meaning that each node can hold either a statement, a
// annot, a declaration or an initialization.
// -------------------------------------------------------
class 
ALFExtendedProgramControlFlowGraph : public CGraph<ALFExtendedProgramGraphNode, ALFExtendedProgramGraphEdge>
{
public:
  // To create and delete the graph
  ALFExtendedProgramControlFlowGraph() {};
  virtual ~ALFExtendedProgramControlFlowGraph() {};

  void Draw(std::ostream & s = std::cout);
  
};

// -------------------------------------------------------
// A class for building a program control flow graph.
// -------------------------------------------------------
class 
ALFExtendedProgramControlFlowGraphBuilder
{
public:

  // ---------------------------------
  // To create and delete the builder class. Argument is owned by caller.
  // ---------------------------------
  ALFExtendedProgramControlFlowGraphBuilder() { };
  virtual ~ALFExtendedProgramControlFlowGraphBuilder() { };

  // To create an extended program flow graph
  ALFExtendedProgramControlFlowGraph * Build(CCallGraph * cg, CALFAbsAnnotStorage * annots, 
					     alf::CAlfTuple * alf_ast);

protected:
  // ---------------------------------
  // Help functions for building the RD analysis 
  // ---------------------------------
  void CreateInternals(CCallGraph * cg, CALFAbsAnnotStorage * annots, CDeclList * global_decls, CInitList * global_inits); 

  // To create and add a unique program start node and exit node 
  void AddAndConnectProgramStartNode(CCallGraph * cg, 
				     std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> * node_to_epfg_nodes);
  void AddAndConnectProgramExitNode(CCallGraph * cg, 
				    std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> * node_to_epfg_nodes);

  // To create and connecting a set of internal nodes according to the things accessible from the call graph
  void CreateEPFGNodes(CCallGraph * cg, 
		       CALFAbsAnnotStorage * annots, CDeclList * global_decls, CInitList * global_inits, 
		       std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> * cfg_node_to_epfg_nodes);

  void CreateEPFGNodesForCFGNode(CFlowGraphNode * cfg_node, CCallGraph * cg, CFlowGraphNode * prog_entry_node, CFlowGraphNode * func_entry_node,
				 CALFAbsAnnotStorage * annots, CDeclList * global_decls, CInitList * global_inits, 
				 std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes);
  
  void ConnectEPFGNodesInVectors(std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> * node_to_epfg_nodes);
  void ConnectEPFGNodesInVector(std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes, bool include_edges_from_call_nodes=false); 

  void ConnectEPFGNodesAccordingToCGAndCFGEdges(CCallGraph * cg, 
						std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> * node_to_epfg_nodes);
  void ConnectEPFGNodesAccordingToCGEdges(CCallGraph * cg, 
					  std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> * node_to_epfg_nodes); 
  void ConnectEPFGNodesAccordingToCFGEdges(CFlowGraph * cfg, 
					   std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> * node_to_epfg_nodes);
    							     
  // Create internal nodes according to global initialization
  void CreateEPFGNodesForInit(CInitTuple * init, ALFExtendedProgramGraphNode::TYPE type, 
			      std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes);

  // Create internal nodes according to annotation
  void CreateEPFGNodesForAnnot(CALFAbsAnnot * annot, ALFExtendedProgramGraphNode::TYPE type, 
			       std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes,
			       alf::CFuncTuple * func=NULL, alf::AStmt * stmt=NULL);

  // Create nodes for root function arguments
  void CreateEPFGNodesForRootFuncArgs(alf::CFuncTuple * func, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes);

  // Create nodes for root function return arguments
  void CreateEPFGNodesForRootFuncReturnArgs(alf::CReturnStmtTuple * return_stmt, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes);

  // Create entry node for a function
  void CreateEPFGNodesForFunc(alf::CFuncTuple * func, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes);

  // Help function for creating epfg_nodes for the function arguments and declarations
  // void CreateEPFGNodesForFuncArgs(alf::CFuncTuple * func, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes);

  // Help function for creating epfg_nodes for declarations in function 
  void CreateEPFGNodesForFuncAllocs(alf::CFuncTuple * func, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes);    

  // Help function to create internal nodes for decls 
  void CreateEPFGNodesForAlloc(alf::CAllocTuple * alloc, ALFExtendedProgramGraphNode::TYPE type, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes);

  // Help functions for creating internal nodes from the argument statement 
  void CreateEPFGNodesForStmt(alf::AStmt * stmt, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes);

  // Check to make sure that we do not have any when called annots. 
  // ********** Should be supported in the future
  bool HasWhenCalledAnnotsForCFGsInCG(CALFAbsAnnotStorage * annots, CCallGraph * cg);

  // void CreateEPFGNodesForCallParamAssigns(CCallStmtTuple * call_stmt, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes);
  // void CreateEPFGNodesForResultArgAssigns(CCallStmtTuple * call_stmt, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes);
  // void CreateEPFGNodesForReturnParamAssigns(CReturnStmtTuple * return_stmt, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes);

  // ---------------------------------
  // Help functions and data structures for creating internal nodes
  // ---------------------------------

  // To create a RD unit which holds a pointer to an annot
  ALFExtendedProgramGraphNode * CreateEPFGNode(CALFAbsAnnot * annot, ALFExtendedProgramGraphNode::TYPE type, alf::CFuncTuple * func=NULL, alf::AStmt * stmt=NULL);
  ALFExtendedProgramGraphNode * CreateEPFGNode(alf::CAllocTuple * alloc, ALFExtendedProgramGraphNode::TYPE type);
  ALFExtendedProgramGraphNode * CreateEPFGNode(alf::CInitTuple * init, ALFExtendedProgramGraphNode::TYPE type);
  ALFExtendedProgramGraphNode * CreateEPFGNode(alf::AStmt * stmt, ALFExtendedProgramGraphNode::TYPE type);
  ALFExtendedProgramGraphNode * CreateEPFGNode(alf::AExpr * func_call_arg, alf::CAllocTuple * func_enter_var);
  ALFExtendedProgramGraphNode * CreateEPFGNode(alf::AExpr * func_return_arg, alf::AExpr * func_result_var);
  ALFExtendedProgramGraphNode * CreateEPFGNode(alf::AExpr * return_arg, ALFExtendedProgramGraphNode::TYPE type);
  ALFExtendedProgramGraphNode * CreateEPFGNode(alf::CFuncTuple * func);
  ALFExtendedProgramGraphNode * CreateProgramEntryEPFGNode();
  ALFExtendedProgramGraphNode * CreateProgramExitEPFGNode();
  
  // A vector keeping track of created internal nodes. 
  std::vector<ALFExtendedProgramGraphNode *> _epfg_nodes;

  // The graph to be created and returned
  ALFExtendedProgramControlFlowGraph * _epfg; 
				      
};

#endif


