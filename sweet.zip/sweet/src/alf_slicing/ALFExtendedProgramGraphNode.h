#ifndef ALFEXTENDEDPROGRAMGRAPHNODE_H_
#define ALFEXTENDEDPROGRAMGRAPHNODE_H_

#include "absann/CALFAbsAnnot.h"
#include "program/alf/CAllocTuple.h"
#include "program/alf/CInitTuple.h"
#include "program/alf/AExpr.h"
#include "program/alf/AStmt.h"
#include "program/alf/CStoreStmtTuple.h"
#include "program/alf/CCallStmtTuple.h"
#include "program/alf/CReturnStmtTuple.h"
#include "program/alf/CNullStmtTuple.h"
#include "program/alf/CSwitchStmtTuple.h"
#include "program/alf/CJumpStmtTuple.h"
#include "program/alf/CFreeStmtTuple.h"
#include "program/alf/CGenericNode.h"
#include "alf_slicing/ALFExtendedProgramGraphEdge.h"

// A node cointaining a specific ALF entity. Each node can contain
// either a stmt, an annot, an alloc, an init or a expression in the
// ALF code. Used for program dependency analysis. 
class ALFExtendedProgramGraphNode : public CNode<ALFExtendedProgramGraphNode, ALFExtendedProgramGraphEdge>
{
public:

  // To delete the node
  virtual ~ALFExtendedProgramGraphNode() {}

  // The type of thing the DG unit originate from
  typedef enum TYPE { PROG_ENTRY,       // An entry node of the program cfg. Virtual node.
		      PROG_EXIT,        // An exit node of the program cfg. Virtual node.
		      FUNC_ENTRY,       // An entry node of a function in the program CFG. Virtual node. 

		      PROG_ENTRY_ANNOT, // An annotation valid at the start of the program. Contains an ALFAbsAnnot.
		      FUNC_ENTRY_ANNOT, // An annotation valid at the start of a specific function. Contains an ALFAbsAnnot.
		      STMT_ENTRY_ANNOT, // An annotation valid at the start of a specif CFG node. Contains an ALFAbsAnnot.
		      STMT_EXIT_ANNOT,  // An annotation valid at the start of a specif CFG node. Contains an ALFAbsAnnot. 

		      GLOBAL_ALLOC_ASSIGN, // A global declaration of a variable (fref). Part of CProgramTuple. Contains a CAllocTuple. Is an implicit assignment since the fref is given a value.
		      GLOBAL_INIT,         // A global initialization of a variable (fref). Part of CProgramTuple. Contains a CInitTuple. 
		      FUNC_ALLOC_ASSIGN,   // A local declared variable at the start of the function. Contains a CAllocTuple. Is an implicit assignment since the fref is given a value.

		      CALL_ENTER_ASSIGN,    // An assignment of a func call argument to a newly allocated enter variable in the called function. Contains an AExpr and an CAllocTuple. CAllocTuple := AExpr 
		      RETURN_RESULT_ASSIGN, // An assignment of a func return argument to an address of the calling function. 
		      ROOT_FUNC_ENTER_ASSIGN, // An allocation of a function argument in the root fucntion. No call argument is present.
		      ROOT_FUNC_RETURN_ASSIGN, // An return expression of the root function without any assignment to a calling function. 

		      STORE_STMT,       // Contains a CStoreStmtTuple
		      CALL_STMT,        // The first part of a call stmt. Contains a CCallStmtTuple.
		      RESULT_STMT,      // The second part of a call stmt. Contains a CCallStmtTuple.
		      RETURN_STMT,      // Contains a CReturnStmtTuple.
		      NULL_STMT,        // Contains a CNullStmtTuple. 
		      SWITCH_STMT,      // Contains a CSwitchStmtTuple.
		      JUMP_STMT,        // Contains a CJumpStmtTuple.
		      FREE_STMT        // Contains a CFreeStmtTuple.

  } TYPE;  

  // To get the type of the node. Must be provided by subclasses.
  virtual TYPE GetType() const = 0;

  // To get the basic type of the node
  typedef enum BASE_TYPE { VIRTUAL,
			   STMT, 
			   ALLOC, 
			   INIT, 
			   ANNOT,
			   ASSIGN 
  } BASE_TYPE;

  // To get the base type of the node. Must be provided by subclasses.
  virtual BASE_TYPE GetBaseType() const = 0;

  // Overwrites parent print and draw 
  virtual void Print(std::ostream & s = std::cout) const;
  virtual void Draw(std::ostream & s = std::cout) const;
  std::string GetTypeAsString() const { return GetTypeAsString(GetType()); } 

  // To get the name of the function the node belongs to. For global
  // nodes the name is "". Used in graph print routines. 
  virtual std::string GetNameOfFunctionNodeBelongsTo() = 0;

  // To copy the node (but not its edges). Must be provided by subclasses.
  virtual ALFExtendedProgramGraphNode * Copy() = 0;

  // Help functions to extract and partition nodes (should maybe be part of graph class?)
  static void PartitionNodesBasedOnFunctionNameTheyBelongsTo(const std::vector<ALFExtendedProgramGraphNode *> * nodes, 
							     std::vector<ALFExtendedProgramGraphNode *> * global_nodes, 
							     std::map<std::string, std::vector<ALFExtendedProgramGraphNode *> *> * func_name_to_nodes);
  static void ExtractNodesOfType(const std::vector<ALFExtendedProgramGraphNode *> * nodes, 
				 TYPE type, std::vector<ALFExtendedProgramGraphNode *> * nodes_with_type);
  static void ExtractNodesOfBaseType(const std::vector<ALFExtendedProgramGraphNode *> * nodes, 
				     BASE_TYPE base_type, std::vector<ALFExtendedProgramGraphNode *> * nodes_with_base_type);

  // -------------------------------------------------------
  // Help functions to create nodes of a certain type with a certain content
  // -------------------------------------------------------

  // Type must be PROG_ENTRY or PROG_EXIT.
  static ALFExtendedProgramGraphNode * CreateNode(TYPE type);
  // Type must be FUNC_ENTRY
  static ALFExtendedProgramGraphNode * CreateNode(alf::CFuncTuple * func, TYPE type=FUNC_ENTRY);
  // Type must be one of FUNC_ENTRY_ANNOT, PROG_ENTRY_ANNOT, STMT_ENTRY_ANNOT, STMT_EXIT_ANNOT
  static ALFExtendedProgramGraphNode * CreateNode(CALFAbsAnnot * annot, TYPE type,
						  alf::CFuncTuple * func=NULL, alf::AStmt * stmt=NULL);
  // Type must be GLOBAL_ALLOC_ASSIGN, FUNC_ALLOC_ASSIGN or ROOT_FUNC_ENTER_ASSIGN
  static ALFExtendedProgramGraphNode * CreateNode(alf::CAllocTuple * created_from_alloc, TYPE type);
  // Type must be GLOBAL_INIT  
  static ALFExtendedProgramGraphNode * CreateNode(alf::CInitTuple * init, TYPE type=GLOBAL_INIT);
  // Type mus be STORE_STMT, CALL_STMT, RESULT_STMT, RETURN_STMT,
  // NULL_STMT, SWITCH_STMT, JUMP_STMT or FREE_STMT
  static ALFExtendedProgramGraphNode * CreateNode(alf::AStmt * stmt, TYPE type);
  // Type must be ROOT_FUNC_RETURN_ASSIGN
  static ALFExtendedProgramGraphNode * CreateNode(alf::AExpr * expr, TYPE type=ROOT_FUNC_RETURN_ASSIGN);
  // Type must be CALL_ENTER_ASSIGN
  static ALFExtendedProgramGraphNode * CreateNode(alf::AExpr * func_call_arg, alf::CAllocTuple * func_enter_var, 
						  TYPE type=CALL_ENTER_ASSIGN);
  // Type must be RETURN_RESULT_ASSIGN
  static ALFExtendedProgramGraphNode * CreateNode(alf::AExpr * func_return_arg, alf::AExpr * func_result_var, 
						  TYPE type=RETURN_RESULT_ASSIGN);
  
protected:

  // To draw the node content. May be overloaded
  virtual void DrawContent(std::ostream & s) const { };

  // To get the type as a string
  std::string GetTypeAsString(TYPE type) const;

};

// Alternative printing function
std::ostream &operator << (std::ostream &o, ALFExtendedProgramGraphNode &a);

// -------------------------------------------------------
// Virtual node 
// -------------------------------------------------------
class ALFExtendedProgramGraphNodeVirtual : public ALFExtendedProgramGraphNode
{
public:
  ALFExtendedProgramGraphNodeVirtual() {}
  virtual ~ALFExtendedProgramGraphNodeVirtual() {}
  BASE_TYPE GetBaseType() const { return VIRTUAL; }
};

// Program start node 
class ALFExtendedProgramGraphNodeProgEntry : public ALFExtendedProgramGraphNodeVirtual
{
public:
  ALFExtendedProgramGraphNodeProgEntry() {}
  virtual ~ALFExtendedProgramGraphNodeProgEntry() {}
  TYPE GetType() const { return PROG_ENTRY; }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeProgEntry(); }
  std::string GetNameOfFunctionNodeBelongsTo() { return ""; }
};

// Program exit node
class ALFExtendedProgramGraphNodeProgExit : public ALFExtendedProgramGraphNodeVirtual
{
public:
  ALFExtendedProgramGraphNodeProgExit() {}
  virtual ~ALFExtendedProgramGraphNodeProgExit() {}
  TYPE GetType() const { return PROG_EXIT; }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeProgExit(); }
  std::string GetNameOfFunctionNodeBelongsTo() { return ""; }
};

// Function entry node
class ALFExtendedProgramGraphNodeFuncEntry : public ALFExtendedProgramGraphNodeVirtual
{
public:
 ALFExtendedProgramGraphNodeFuncEntry(alf::CFuncTuple * func) : _func(func) {}
  virtual ~ALFExtendedProgramGraphNodeFuncEntry() {}
  TYPE GetType() const { return FUNC_ENTRY; }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeFuncEntry(_func); }
  alf::CFuncTuple * GetFunc() const { return _func; }
  std::string GetNameOfFunctionNodeBelongsTo() { return _func->Name(); }
protected:
  void DrawContent(std::ostream & s) const;
  alf::CFuncTuple * _func;
};

// -------------------------------------------------------
// Annotation node
// -------------------------------------------------------

// If the node contains an abstract annotation 
class ALFExtendedProgramGraphNodeAnnot : public ALFExtendedProgramGraphNode
{
public: 
  ALFExtendedProgramGraphNodeAnnot(CALFAbsAnnot * annot) { _annot = annot; };
  virtual ~ALFExtendedProgramGraphNodeAnnot() {}
  BASE_TYPE GetBaseType() const { return ANNOT; }
  CALFAbsAnnot * GetAnnot() const { return _annot; }
protected:
  CALFAbsAnnot * _annot;
};

// If the node contains an abstract program entry annotation 
class ALFExtendedProgramGraphNodeProgEntryAnnot : public ALFExtendedProgramGraphNodeAnnot
{
public: 
  ALFExtendedProgramGraphNodeProgEntryAnnot(CALFAbsAnnot * annot) : ALFExtendedProgramGraphNodeAnnot(annot) { }
  virtual ~ALFExtendedProgramGraphNodeProgEntryAnnot() {}
  TYPE GetType() const { return PROG_ENTRY_ANNOT; }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeProgEntryAnnot(_annot); }
  std::string GetNameOfFunctionNodeBelongsTo() { return ""; }

};

// If the node contains an abstract function entry annotation 
class ALFExtendedProgramGraphNodeFuncEntryAnnot : public ALFExtendedProgramGraphNodeAnnot
{
public: 
  ALFExtendedProgramGraphNodeFuncEntryAnnot(CALFAbsAnnot * annot, alf::CFuncTuple * func) : ALFExtendedProgramGraphNodeAnnot(annot), _func(func) { }
  virtual ~ALFExtendedProgramGraphNodeFuncEntryAnnot() {}
  TYPE GetType() const { return FUNC_ENTRY_ANNOT; }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeFuncEntryAnnot(_annot, _func); }
  std::string GetNameOfFunctionNodeBelongsTo() { return (dynamic_cast<CALFAbsAnnotPositionFuncEntry *>(_annot))->Func(); }
  alf::CFuncTuple * GetFunc() { return _func; }
protected:
  alf::CFuncTuple * _func;
};

// If the node contains an abstract stmt entry annotation 
class ALFExtendedProgramGraphNodeStmtEntryAnnot : public ALFExtendedProgramGraphNodeAnnot
{
public: 
  ALFExtendedProgramGraphNodeStmtEntryAnnot(CALFAbsAnnot * annot, alf::AStmt * stmt) : ALFExtendedProgramGraphNodeAnnot(annot), _stmt(stmt) { }
  virtual ~ALFExtendedProgramGraphNodeStmtEntryAnnot() {}
  TYPE GetType() const { return STMT_ENTRY_ANNOT; }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeStmtEntryAnnot(_annot, _stmt); }
  std::string GetNameOfFunctionNodeBelongsTo() { return (dynamic_cast<CALFAbsAnnotPositionStmtEntry *>(_annot))->Func(); }
  alf::AStmt * GetStmt() { return _stmt; }
protected:
  alf::AStmt * _stmt;
};

// If the node contains an abstract stmt exit annotation 
class ALFExtendedProgramGraphNodeStmtExitAnnot : public ALFExtendedProgramGraphNodeAnnot
{
public: 
  ALFExtendedProgramGraphNodeStmtExitAnnot(CALFAbsAnnot * annot, alf::AStmt * stmt) : ALFExtendedProgramGraphNodeAnnot(annot), _stmt(stmt) { }
  virtual ~ALFExtendedProgramGraphNodeStmtExitAnnot() {}
  TYPE GetType() const { return STMT_EXIT_ANNOT; }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeStmtExitAnnot(_annot, _stmt); }
  std::string GetNameOfFunctionNodeBelongsTo() { return (dynamic_cast<CALFAbsAnnotPositionStmtExit *>(_annot))->Func(); }
  alf::AStmt * GetStmt() { return _stmt; }
protected:
  alf::AStmt * _stmt;};

// -------------------------------------------------------
// Alloc node
// -------------------------------------------------------

class ALFExtendedProgramGraphNodeAlloc : public ALFExtendedProgramGraphNode
{
public:
  ALFExtendedProgramGraphNodeAlloc(alf::CAllocTuple * alloc) : _alloc(alloc) {}
  virtual ~ALFExtendedProgramGraphNodeAlloc() {}
  BASE_TYPE GetBaseType() const { return ALLOC; }
  alf::CAllocTuple * GetAlloc() const { return _alloc; }
protected:
  alf::CAllocTuple * _alloc;
};

// If the node contains an abstract annotation 
class ALFExtendedProgramGraphNodeGlobalAlloc : public ALFExtendedProgramGraphNodeAlloc
{
public: 
  ALFExtendedProgramGraphNodeGlobalAlloc(alf::CAllocTuple * alloc) : ALFExtendedProgramGraphNodeAlloc(alloc) {}
  virtual ~ALFExtendedProgramGraphNodeGlobalAlloc() {}
  TYPE GetType() const { return GLOBAL_ALLOC_ASSIGN; }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeGlobalAlloc(_alloc); }
  std::string GetNameOfFunctionNodeBelongsTo() { return ""; }
protected:
  void DrawContent(std::ostream & s) const;
};

// If the node contains an abstract annotation 
class ALFExtendedProgramGraphNodeFuncAlloc : public ALFExtendedProgramGraphNodeAlloc
{
public: 
  ALFExtendedProgramGraphNodeFuncAlloc(alf::CAllocTuple * alloc) : ALFExtendedProgramGraphNodeAlloc(alloc) {}
  virtual ~ALFExtendedProgramGraphNodeFuncAlloc() {}
  TYPE GetType() const { return FUNC_ALLOC_ASSIGN; }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeFuncAlloc(_alloc); }
  std::string GetNameOfFunctionNodeBelongsTo() { return (dynamic_cast<alf::CFuncTuple *>(_alloc->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE)))->Name(); }
protected:
  void DrawContent(std::ostream & s) const;
};

// -------------------------------------------------------
// Global init node
// -------------------------------------------------------

// If the node contains an abstract annotation 
class ALFExtendedProgramGraphNodeGlobalInit : public ALFExtendedProgramGraphNode
{
public: 
  ALFExtendedProgramGraphNodeGlobalInit(alf::CInitTuple * init) : _init(init) {}
  virtual ~ALFExtendedProgramGraphNodeGlobalInit() {}
  TYPE GetType() const { return GLOBAL_INIT; }
  BASE_TYPE GetBaseType() const { return INIT; }
  alf::CInitTuple * GetInit() const { return _init; }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeGlobalInit(_init); }
  std::string GetNameOfFunctionNodeBelongsTo() { return ""; }
protected:
  void DrawContent(std::ostream & s) const;
  alf::CInitTuple * _init;
};

// -------------------------------------------------------
// An assignment of a function call argument expression to function call enter var
// EnterVar := CallArg
// -------------------------------------------------------
class ALFExtendedProgramGraphNodeCallEnterAssign : public ALFExtendedProgramGraphNode
{
public:
  ALFExtendedProgramGraphNodeCallEnterAssign(alf::AExpr * call_expr, alf::CAllocTuple * enter_alloc) : _call_expr(call_expr), _enter_alloc(enter_alloc) {}
  virtual ~ALFExtendedProgramGraphNodeCallEnterAssign() {}
  TYPE GetType() const { return CALL_ENTER_ASSIGN; }
  BASE_TYPE GetBaseType() const { return ASSIGN; }
  alf::AExpr * GetCallExpr() const { return _call_expr; }
  alf::CCallStmtTuple * GetCallStmt() const { return dynamic_cast<alf::CCallStmtTuple *>(_call_expr->GetParent(alf::CGenericNode::TYPE_CALL_STMT_TUPLE)); }
  alf::CFuncTuple * GetCallFunc() const { return dynamic_cast<alf::CFuncTuple *>(_call_expr->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE)); }
  alf::CAllocTuple * GetEnterAlloc() const { return _enter_alloc; }
  alf::CFuncTuple * GetEnterFunc() const { return dynamic_cast<alf::CFuncTuple *>(_enter_alloc->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE)); }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeCallEnterAssign(_call_expr, _enter_alloc); }
  std::string GetNameOfFunctionNodeBelongsTo() { return ""; }
protected:
  void DrawContent(std::ostream & s) const;
  alf::CCallStmtTuple * _call_stmt;
  alf::AExpr * _call_expr;
  alf::CAllocTuple * _enter_alloc;
};

// -------------------------------------------------------
// An assignment of a function return argument expression to function call result expression (which shluld evalute to an address)
// ResultVar := ReturnArg
// -------------------------------------------------------
class ALFExtendedProgramGraphNodeReturnResultAssign : public ALFExtendedProgramGraphNode
{
public:
  ALFExtendedProgramGraphNodeReturnResultAssign(alf::AExpr * return_expr, alf::AExpr * result_expr) : _return_expr(return_expr), _result_expr(result_expr) {}
  virtual ~ALFExtendedProgramGraphNodeReturnResultAssign() {}
  TYPE GetType() const { return RETURN_RESULT_ASSIGN; }
  BASE_TYPE GetBaseType() const { return ASSIGN; }
  alf::AExpr * GetReturnExpr() const { return _return_expr; }
  alf::CReturnStmtTuple * GetReturnStmt() const { return dynamic_cast<alf::CReturnStmtTuple *>(_return_expr->GetParent(alf::CGenericNode::TYPE_RETURN_STMT_TUPLE)); }
  alf::CFuncTuple * GetReturnFunc() const { return dynamic_cast<alf::CFuncTuple *>(_return_expr->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE)); }
  alf::AExpr * GetResultExpr() const { return _result_expr; }
  alf::CCallStmtTuple * GetResultStmt() const { return dynamic_cast<alf::CCallStmtTuple *>(_result_expr->GetParent(alf::CGenericNode::TYPE_CALL_STMT_TUPLE)); }
  alf::CFuncTuple * GetResultFunc() const { return dynamic_cast<alf::CFuncTuple *>(_result_expr->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE)); }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeReturnResultAssign(_return_expr, _result_expr); }
  std::string GetNameOfFunctionNodeBelongsTo() { return ""; }
protected:
  void DrawContent(std::ostream & s) const;
  alf::AExpr * _return_expr;
  alf::AExpr * _result_expr;
};

// -------------------------------------------------------
// An argument allocation in teh ropot function of the program.
// No call argumment expression is present. 
// -------------------------------------------------------
class ALFExtendedProgramGraphNodeRootFuncEnterAssign : public ALFExtendedProgramGraphNode
{
public:
  ALFExtendedProgramGraphNodeRootFuncEnterAssign(alf::CAllocTuple * enter_alloc) : _enter_alloc(enter_alloc) {}
  virtual ~ALFExtendedProgramGraphNodeRootFuncEnterAssign() {}
  TYPE GetType() const { return ROOT_FUNC_ENTER_ASSIGN; }
  BASE_TYPE GetBaseType() const { return ASSIGN; }
  alf::CAllocTuple * GetEnterAlloc() const { return _enter_alloc; }
  alf::CFuncTuple * GetEnterFunc() const { return dynamic_cast<alf::CFuncTuple *>(_enter_alloc->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE)); }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeRootFuncEnterAssign(_enter_alloc); }
  std::string GetNameOfFunctionNodeBelongsTo() { return ""; }
protected:
  void DrawContent(std::ostream & s) const;
  alf::CAllocTuple * _enter_alloc;
};

// -------------------------------------------------------
// An assignment of root function return argument expression.
// No result expression is present. 
// -------------------------------------------------------
class ALFExtendedProgramGraphNodeRootFuncReturnAssign : public ALFExtendedProgramGraphNode
{
public:
  ALFExtendedProgramGraphNodeRootFuncReturnAssign(alf::AExpr * return_expr) : _return_expr(return_expr) {}
  virtual ~ALFExtendedProgramGraphNodeRootFuncReturnAssign() {}
  TYPE GetType() const { return ROOT_FUNC_RETURN_ASSIGN; }
  BASE_TYPE GetBaseType() const { return ASSIGN; }
  alf::AExpr * GetReturnExpr() const { return _return_expr; }
  alf::CReturnStmtTuple * GetReturnStmt() const { return dynamic_cast<alf::CReturnStmtTuple *>(_return_expr->GetParent(alf::CGenericNode::TYPE_RETURN_STMT_TUPLE)); }
  alf::CFuncTuple * GetReturnFunc() const { return dynamic_cast<alf::CFuncTuple *>(_return_expr->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE)); }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeRootFuncReturnAssign(_return_expr); }
  std::string GetNameOfFunctionNodeBelongsTo() { return ""; }
protected:
  void DrawContent(std::ostream & s) const;
  alf::AExpr * _return_expr;
};

// -------------------------------------------------------
// Statement nodes
// -------------------------------------------------------

// A parent class for statements
class ALFExtendedProgramGraphNodeStmt : public ALFExtendedProgramGraphNode
{
public:
 ALFExtendedProgramGraphNodeStmt(alf::AStmt * stmt) : _stmt(stmt) {}
  virtual ~ALFExtendedProgramGraphNodeStmt() {}
  BASE_TYPE GetBaseType() const { return STMT; }
  alf::AStmt * GetStmt() const { return _stmt; }
  std::string GetNameOfFunctionNodeBelongsTo() { return (dynamic_cast<alf::CFuncTuple *>(_stmt->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE)))->Name(); }
protected:
  void DrawContent(std::ostream & s) const;
  alf::AStmt * _stmt;
};

// Store statement
class ALFExtendedProgramGraphNodeStoreStmt : public ALFExtendedProgramGraphNodeStmt
{
public:
  ALFExtendedProgramGraphNodeStoreStmt(alf::CStoreStmtTuple * stmt) : ALFExtendedProgramGraphNodeStmt(stmt) {}
  virtual ~ALFExtendedProgramGraphNodeStoreStmt() {}
  TYPE GetType() const { return STORE_STMT; }
  alf::CStoreStmtTuple * GetStoreStmt() const { return dynamic_cast<alf::CStoreStmtTuple *>(_stmt); }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeStoreStmt(dynamic_cast<alf::CStoreStmtTuple *>(_stmt)); }

};

// Call statement
class ALFExtendedProgramGraphNodeCallStmt : public ALFExtendedProgramGraphNodeStmt
{
public:
  ALFExtendedProgramGraphNodeCallStmt(alf::CCallStmtTuple * stmt) : ALFExtendedProgramGraphNodeStmt(stmt) {}
  virtual ~ALFExtendedProgramGraphNodeCallStmt() {}
  TYPE GetType() const { return CALL_STMT; }
  alf::CCallStmtTuple * GetCallStmt() const { return dynamic_cast<alf::CCallStmtTuple *>(_stmt); }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeCallStmt(dynamic_cast<alf::CCallStmtTuple *>(_stmt)); }
};

// Result statement
class ALFExtendedProgramGraphNodeResultStmt : public ALFExtendedProgramGraphNodeStmt
{
public:
  ALFExtendedProgramGraphNodeResultStmt(alf::CCallStmtTuple * stmt) : ALFExtendedProgramGraphNodeStmt(stmt) {}
  virtual ~ALFExtendedProgramGraphNodeResultStmt() {}
  TYPE GetType() const { return RESULT_STMT; }
  alf::CCallStmtTuple * GetResultStmt() const { return dynamic_cast<alf::CCallStmtTuple *>(_stmt); }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeResultStmt(dynamic_cast<alf::CCallStmtTuple *>(_stmt)); }
};

// Return statement
class ALFExtendedProgramGraphNodeReturnStmt : public ALFExtendedProgramGraphNodeStmt
{
public:
  ALFExtendedProgramGraphNodeReturnStmt(alf::CReturnStmtTuple * stmt) : ALFExtendedProgramGraphNodeStmt(stmt) {}
  virtual ~ALFExtendedProgramGraphNodeReturnStmt() {}
  TYPE GetType() const { return RETURN_STMT; }
  alf::CReturnStmtTuple * GetReturnStmt() const { return dynamic_cast<alf::CReturnStmtTuple *>(_stmt); }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeReturnStmt(dynamic_cast<alf::CReturnStmtTuple *>(_stmt)); }
};

// Null statement
class ALFExtendedProgramGraphNodeNullStmt : public ALFExtendedProgramGraphNodeStmt
{
public:
  ALFExtendedProgramGraphNodeNullStmt(alf::CNullStmtTuple * stmt) : ALFExtendedProgramGraphNodeStmt(stmt) {}
  virtual ~ALFExtendedProgramGraphNodeNullStmt() {}
  TYPE GetType() const { return NULL_STMT; }
  alf::CNullStmtTuple * GetNullStmt() const { return dynamic_cast<alf::CNullStmtTuple *>(_stmt); }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeNullStmt(dynamic_cast<alf::CNullStmtTuple *>(_stmt)); }
};

// Switch statement
class ALFExtendedProgramGraphNodeSwitchStmt : public ALFExtendedProgramGraphNodeStmt
{
public:
  ALFExtendedProgramGraphNodeSwitchStmt(alf::CSwitchStmtTuple * stmt) : ALFExtendedProgramGraphNodeStmt(stmt) {}
  virtual ~ALFExtendedProgramGraphNodeSwitchStmt() {}
  TYPE GetType() const { return SWITCH_STMT; }
  alf::CSwitchStmtTuple * GetSwitchStmt() const { return dynamic_cast<alf::CSwitchStmtTuple *>(_stmt); }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeSwitchStmt(dynamic_cast<alf::CSwitchStmtTuple *>(_stmt)); }
};

// Jump statement
class ALFExtendedProgramGraphNodeJumpStmt : public ALFExtendedProgramGraphNodeStmt
{
public:
  ALFExtendedProgramGraphNodeJumpStmt(alf::CJumpStmtTuple * stmt) : ALFExtendedProgramGraphNodeStmt(stmt) {}
  virtual ~ALFExtendedProgramGraphNodeJumpStmt() {}
  TYPE GetType() const { return JUMP_STMT; }
  alf::CJumpStmtTuple * GetJumpStmt() const { return dynamic_cast<alf::CJumpStmtTuple *>(_stmt); }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeJumpStmt(dynamic_cast<alf::CJumpStmtTuple *>(_stmt)); }
};

// Free statement
class ALFExtendedProgramGraphNodeFreeStmt : public ALFExtendedProgramGraphNodeStmt
{
public:
  ALFExtendedProgramGraphNodeFreeStmt(alf::CFreeStmtTuple * stmt) : ALFExtendedProgramGraphNodeStmt(stmt) {}
  virtual ~ALFExtendedProgramGraphNodeFreeStmt() {}
  TYPE GetType() const { return FREE_STMT; }
  alf::CFreeStmtTuple * GetFreeStmt() const { return dynamic_cast<alf::CFreeStmtTuple *>(_stmt); }
  ALFExtendedProgramGraphNode * Copy() { return new ALFExtendedProgramGraphNodeFreeStmt(dynamic_cast<alf::CFreeStmtTuple *>(_stmt)); }
};

  

#endif


