#include "alf_slicing/ALFExtendedProgramDependencyGraph.h"
#include "alf_slicing/ALFExtendedProgramControlFlowGraph.h"
#include "rd/ALFReachingDefinitionsAnalysisBuilder.h"
#include <iostream>
#include <sstream>
#include <string>

void
ALFExtendedProgramDependencyGraph::
Draw(std::ostream & os)
{
  ALFExtendedProgramDependencyGraph * epdg = this;

  os << "digraph PDG {" << endl;
  os << "label=\"Program Dependency Graph (PDG)\\ngreen = data-dependency, blue = control-dependency\"" << endl; 
  os << "size=\"11.4,7.8\"" << endl;
  os << "rankdir=\"TB\"" << endl;
  os << "center=1" << endl;
  os << "rotate=0" << endl;
  os << "orientation=\"portrait\"" << endl;
  os << "fontsize=5;" << endl;
  os << "nodesep=0.1;" << endl;
  os << "subgraph \"" << "pdg" << "\" {" << endl;

  // Partition nodes based on the function they belong to
  std::vector<ALFExtendedProgramGraphNode *> nodes;
  for(ALFExtendedProgramDependencyGraph::node_iterator n = epdg->NodesBegin(); n != epdg->NodesEnd(); ++n){
    nodes.push_back(*n);
  }
  std::vector<ALFExtendedProgramGraphNode *> global_nodes;
  std::map<std::string, std::vector<ALFExtendedProgramGraphNode *> *> func_name_to_nodes;
  ALFExtendedProgramGraphNode::PartitionNodesBasedOnFunctionNameTheyBelongsTo(&nodes, &global_nodes, &func_name_to_nodes);
  
  // Print global nodes
  os << "   /* Global nodes */\n";
  for(std::vector<ALFExtendedProgramGraphNode *>::iterator n = global_nodes.begin();
      n != global_nodes.end(); ++n) {
    os << "   \"" << (*n)->Id() << "\"[label=\"";
    (*n)->Draw(os);
    os << "\",fontsize=5,width=0.01,height=0.01,margin=\"0.01,0.01\"]" << endl; 
  }
  os << endl;

  // Print nodes in clusters
  for(std::map<std::string, std::vector<ALFExtendedProgramGraphNode *> *>::iterator fn2ns = func_name_to_nodes.begin();
      fn2ns != func_name_to_nodes.end(); ++fn2ns) {
    os << "   /* Nodes belonging to function " << (*fn2ns).first << " */\n";
    os << "subgraph \"cluster_" << (*fn2ns).first << "\" {" << endl;
    os << "   label=\"" << (*fn2ns).first << "\"" << endl;
    std::vector<ALFExtendedProgramGraphNode *> * nodes = (*fn2ns).second;
    for( std::vector<ALFExtendedProgramGraphNode *>::iterator n = nodes->begin(); n != nodes->end(); ++n) {
      os << "   \"" << (*n)->Id() << "\"[label=\"";
      (*n)->Draw(os);
      os << "\",fontsize=5,width=0.01,height=0.01,margin=\"0.01,0.01\"]" << endl; 
    }
    os << "}" << endl << endl;
  }

  // Print edges
  for(ALFExtendedProgramDependencyGraph::node_iterator n = epdg->NodesBegin();
      n != epdg->NodesEnd(); ++n){
    for(ALFExtendedProgramGraphNode::succ_iterator se = (*n)->SuccBegin();
	se != (*n)->SuccEnd(); ++se) {
      ALFExtendedProgramGraphNode * succ = (*se).node; 
      ALFExtendedProgramGraphEdge * edge = (*se).edge_annot;
      os << "   \"" << (*n)->Id() << "\" -> \""; 
      os << succ->Id() << "\"";
      if(edge->IsDataDependencyEdge())
	os << "[style=solid,color=green";
      else
	os << "[style=solid,color=blue";
      os << ",label=\"" << edge->GetLabel() << "\"";
      os << ",fontsize=5,margin=\"0.01,0.01\"]" << endl;
    }
  }
  os << "  }" << endl;
  os << "}" << endl;
  
  // Delete temporaries
  for(std::map<std::string, std::vector<ALFExtendedProgramGraphNode *> *>::iterator fn2ns = func_name_to_nodes.begin();
      fn2ns != func_name_to_nodes.end(); ++fn2ns) {
    delete (*fn2ns).second;
  }
}

void
ALFExtendedProgramDependencyGraph::
DrawSlice(std::ostream & os,  std::set<ALFExtendedProgramGraphNode *> * nodes_in_slice,
	  std::set<ALFExtendedProgramGraphEdge *> * edges_in_slice)
{
  ALFExtendedProgramDependencyGraph * epdg = this;

  os << "digraph PDG {" << endl;
  os << "label=\"Program Dependency Graph (PDG) with marked slice\\ngrey = not in slice, black = in slice\"" << endl; 
  os << "size=\"11.4,7.8\"" << endl;
  os << "rankdir=\"TB\"" << endl;
  os << "center=1" << endl;
  os << "rotate=0" << endl;
  os << "orientation=\"portrait\"" << endl;
  os << "fontsize=5;" << endl;
  os << "nodesep=0.1;" << endl;
  os << "subgraph \"" << "epcfg_cdg" << "\" {" << endl;

  // Partition nodes based on the function they belong to
  std::vector<ALFExtendedProgramGraphNode *> nodes;
  for(ALFExtendedProgramDependencyGraph::node_iterator n = epdg->NodesBegin(); n != epdg->NodesEnd(); ++n){
    nodes.push_back(*n);
  }
  std::vector<ALFExtendedProgramGraphNode *> global_nodes;
  std::map<std::string, std::vector<ALFExtendedProgramGraphNode *> *> func_name_to_nodes;
  ALFExtendedProgramGraphNode::PartitionNodesBasedOnFunctionNameTheyBelongsTo(&nodes, &global_nodes, &func_name_to_nodes);
  
  // Print global nodes
  os << "   /* Global nodes */\n";
  for(std::vector<ALFExtendedProgramGraphNode *>::iterator n = global_nodes.begin();
      n != global_nodes.end(); ++n) {
    // Print nodes differently depending on if they are in the slice or not
    os << "   \"" << (*n)->Id() << "\"[";
    if(nodes_in_slice) {
      if(nodes_in_slice->find(*n) != nodes_in_slice->end())
	os << "color=black,style=filled,fillcolor=black,fontcolor=white,";
      else
	os << "color=grey,style=solid,fontcolor=grey,";
    }
    os << "label=\"";
    (*n)->Draw(os);
    os << "\",fontsize=5,width=0.01,height=0.01,margin=\"0.01,0.01\"]" << endl; 
  }
  os << endl;

  // Print nodes in clusters
  for(std::map<std::string, std::vector<ALFExtendedProgramGraphNode *> *>::iterator fn2ns = func_name_to_nodes.begin();
      fn2ns != func_name_to_nodes.end(); ++fn2ns) {
    os << "subgraph \"cluster_" << (*fn2ns).first << "\" {" << endl;
    os << "   /* Function " << (*fn2ns).first << " */\n";
    os << "   label=\"" << (*fn2ns).first << "\"" << endl;
    std::vector<ALFExtendedProgramGraphNode *> * nodes = (*fn2ns).second;
    for( std::vector<ALFExtendedProgramGraphNode *>::iterator n = nodes->begin(); n != nodes->end(); ++n) {
      // Print nodes differently depending on if they are in the slice or not
      os << "   \"" << (*n)->Id() << "\"[";
      if(nodes_in_slice) {
	if(nodes_in_slice->find(*n) != nodes_in_slice->end())
	  os << "color=black,style=filled,fillcolor=black,fontcolor=white,";
	else
	  os << "color=grey,style=solid,fontcolor=grey,";
      }
      os << "label=\"";
      (*n)->Draw(os);
      os << "\",fontsize=5,width=0.01,height=0.01,margin=\"0.01,0.01\"]" << endl; 
    }
    os << "}" << endl << endl;
  }

  // Print edges differently depnding or not if they are in the slice or not
  for(ALFExtendedProgramDependencyGraph::node_iterator n = epdg->NodesBegin();
      n != epdg->NodesEnd(); ++n){
    for(ALFExtendedProgramGraphNode::succ_iterator se = (*n)->SuccBegin();
	se != (*n)->SuccEnd(); ++se) {
      ALFExtendedProgramGraphNode * succ = (*se).node;
      ALFExtendedProgramGraphEdge * edge = (*se).edge_annot;
      os << "   \"" << (*n)->Id() << "\" -> \""; 
      os << succ->Id() << "\"";
      if(edges_in_slice) {
	if(edges_in_slice->find(edge) != edges_in_slice->end()) 
	  os << "[style=bold,fontcolor=black";
	else
	  os << "[style=solid,fontcolor=grey,color=grey";
      }
      os << ",label=\"" << edge->GetLabel() << "\"";
      os << ",fontsize=5,margin=\"0.01,0.01\"]" << endl;
    }
  }
  os << "  }" << endl;
  os << "}" << endl;

  // Delete temporaries
  for(std::map<std::string, std::vector<ALFExtendedProgramGraphNode *> *>::iterator fn2ns = func_name_to_nodes.begin();
      fn2ns != func_name_to_nodes.end(); ++fn2ns) {
    delete (*fn2ns).second;
  }
}


ALFExtendedProgramDependencyGraph * 
ALFExtendedProgramDependencyGraphBuilder::
Build(ALFExtendedProgramControlFlowGraph * epcfg, ALFReachingDefinitionsAnalysis * rd, 
      ALFDefsAndUsesAnalysis * du, CSymTabBase * symtab)
{
  // Create temporary pointers which will be initialized by calling real Build function
  ALFExtendedProgramControlDependencyGraph * epcdg = NULL;
  ALFExtendedProgramDataDependencyGraph * epddg = NULL;
  ALFExtendedProgramDependencyGraph * epdg = Build(epcfg, rd, du, symtab, &epcdg, &epddg);
  // Delete temporary graphs
  delete epcdg;
  delete epddg;
  // Return the resulting program dependency graph
  return epdg;
}

ALFExtendedProgramDependencyGraph * 
ALFExtendedProgramDependencyGraphBuilder::
Build(ALFExtendedProgramControlFlowGraph * epcfg, ALFReachingDefinitionsAnalysis * rd, 
      ALFDefsAndUsesAnalysis * du, CSymTabBase * symtab,
      ALFExtendedProgramControlDependencyGraph ** _epcdg, 
      ALFExtendedProgramDataDependencyGraph ** _epddg) 
{
  assert(epcfg);
  assert(rd);
  assert(du);
  assert(symtab);
  
  // ---------------------------------
  // Create the resulting program dependency graph.
  // ---------------------------------
  ALFExtendedProgramDependencyGraph * epdg = new ALFExtendedProgramDependencyGraph();

  // ---------------------------------
  // Add nodes to epdg according to epcfg
  // ---------------------------------
  AddNodes(epdg, epcfg);

  // ---------------------------------
  // Calculate program control dependency graph based on epcfg 
  // ---------------------------------
  ALFExtendedProgramControlDependencyGraphBuilder epcdg_builder;
  ALFExtendedProgramControlDependencyGraph * epcdg = epcdg_builder.Build(epcfg);
  
  // ---------------------------------
  // Add control dependency edges according to calculated control dependency graph
  // ---------------------------------
  AddControlDependencyEdges(epdg, epcdg);

  // ---------------------------------
  // Calculate program data dependency graph 
  // ---------------------------------
  ALFExtendedProgramDataDependencyGraphBuilder epddg_builder;
  ALFExtendedProgramDataDependencyGraph * epddg = epddg_builder.Build(epcfg, rd, du, symtab); 

  // ---------------------------------
  // Add data dependency edges to epdg according to epddg
  // ---------------------------------
  AddDataDependencyEdges(epdg, epddg);
  // Reset argument pointer to crateted graphs
  (*_epcdg) = epcdg;
  (*_epddg) = epddg;

  // Return the created dependency graph
  return epdg;
}

// Add nodes according to calculated control flow graph 
void
ALFExtendedProgramDependencyGraphBuilder::
AddNodes(ALFExtendedProgramDependencyGraph * epdg,
	 ALFExtendedProgramControlFlowGraph * epcfg) 
{
  // Loop through all nodes in the graph
  for(ALFExtendedProgramControlFlowGraph::node_iterator n = epcfg->NodesBegin();
      n != epcfg->NodesEnd(); ++n) {
    // Copy the node and add it to the new graph
    ALFExtendedProgramGraphNode * new_node = (*n)->Copy();
    epdg->AddNode(new_node);
  }
}
 
// Add control dependency edges according to calculated control dependency graph edges
void
ALFExtendedProgramDependencyGraphBuilder::
AddControlDependencyEdges(ALFExtendedProgramDependencyGraph * epdg,
			  ALFExtendedProgramControlDependencyGraph *epcdg) 
{
  // Loop through all nodes in the graph
  for(ALFExtendedProgramControlDependencyGraph::node_iterator from = epcdg->NodesBegin();
      from != epcdg->NodesEnd(); ++from) {
    unsigned int from_id = (*from)->Id(); 
    // Loop through all its successors
    for(ALFExtendedProgramGraphNode::succ_iterator succ = (*from)->SuccBegin();
	succ != (*from)->SuccEnd(); ++succ) {
      unsigned int to_id = (*succ).node->Id();
      // Add control dependency edge in resulting dependency graph
      ALFExtendedProgramGraphEdge * edge_annot = new ALFExtendedProgramGraphEdge(ALFExtendedProgramGraphEdge::CONTROL);
      epdg->AddEdge(from_id, to_id, edge_annot);
    }
  }
}

// Add control dependency edges according to calculated control dependency graph edges
void
ALFExtendedProgramDependencyGraphBuilder::
AddDataDependencyEdges(ALFExtendedProgramDependencyGraph * epdg,
		       ALFExtendedProgramDataDependencyGraph *epddg) 
{
  // Loop through all nodes in the graph
  for(ALFExtendedProgramDataDependencyGraph::node_iterator from = epddg->NodesBegin();
      from != epddg->NodesEnd(); ++from) {
    unsigned int from_id = (*from)->Id(); 
    // Loop through all its successors
    for(ALFExtendedProgramGraphNode::succ_iterator succ = (*from)->SuccBegin();
	succ != (*from)->SuccEnd(); ++succ) {
      unsigned int to_id = (*succ).node->Id();
      // Add data dependency edge in resulting dependency graph
      ALFExtendedProgramGraphEdge * org_edge_annot = (*succ).edge_annot;
      ALFExtendedProgramGraphEdge * edge_annot = new ALFExtendedProgramGraphEdge(org_edge_annot->GetType(), org_edge_annot->GetLabel());
      epdg->AddEdge(from_id, to_id, edge_annot);
    }
  }
}




