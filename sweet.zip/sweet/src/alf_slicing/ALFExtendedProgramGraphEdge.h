#ifndef ALFEXTENDEDPROGRAMGRAPHEDGE_H_
#define ALFEXTENDEDPROGRAMGRAPHEDGE_H_

#include <string>

// -------------------------------------------------------
// Edge to be used in extended program graphs
// -------------------------------------------------------
class ALFExtendedProgramGraphEdge 
{
public:

  typedef enum EDGE_TYPE { DATA, CONTROL } EDGE_TYPE;

  ALFExtendedProgramGraphEdge(EDGE_TYPE type, std::string label="") { _type = type; _label = label; }
  ~ALFExtendedProgramGraphEdge() {};

  EDGE_TYPE GetType() { return _type; }
  bool IsDataDependencyEdge() { return _type == DATA; }
  bool IsControlDependencyEdge() { return _type == CONTROL; }

  void SetLabel(const std::string &label) { _label = label; }
  std::string GetLabel() { return _label; }

  ALFExtendedProgramGraphEdge * Copy() { return new ALFExtendedProgramGraphEdge(_type, _label); }  

protected:
  
  ALFExtendedProgramGraphEdge();
  EDGE_TYPE _type;
  std::string _label;
};

#endif
