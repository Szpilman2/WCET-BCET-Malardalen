#include "alf_slicing/ALFExtendedProgramControlFlowGraph.h"
#include "alf_slicing/ALFExtendedProgramGraphNode.h"
#include "tools/StrStream.h"
#include "program/alf/CExprList.h"
#include "graphs/tools/CGraph.inl"
#include "graphs/tools/CNode.inl"

// -------------------------------------------------------
// -------------------------------------------------------
// ALFExtendedProgramControlFlowGraph
// -------------------------------------------------------
// -------------------------------------------------------

void
ALFExtendedProgramControlFlowGraph::
Draw(std::ostream & os)
{
  ALFExtendedProgramControlFlowGraph * epcfg = this;

  os << "digraph PCFG {" << endl;
  os << "label=\"Program Control-Flow Graph (PCFG)\"" << endl; 
  os << "size=\"11.4,7.8\"" << endl;
  os << "rankdir=\"TB\"" << endl;
  os << "center=1" << endl;
  os << "rotate=0" << endl;
  os << "orientation=\"portrait\"" << endl;
  os << "fontsize=5;" << endl;
  os << "nodesep=0.1;" << endl;
  os << "subgraph \"" << "pcfg" << "\" {" << endl;

  // Partition nodes based on the function they belong to
  std::vector<ALFExtendedProgramGraphNode *> nodes;
  for(ALFExtendedProgramControlFlowGraph::node_iterator n = epcfg->NodesBegin(); n != epcfg->NodesEnd(); ++n){
    nodes.push_back(*n);
  }
  std::vector<ALFExtendedProgramGraphNode *> global_nodes;
  std::map<std::string, std::vector<ALFExtendedProgramGraphNode *> *> func_name_to_nodes;
  ALFExtendedProgramGraphNode::PartitionNodesBasedOnFunctionNameTheyBelongsTo(&nodes, &global_nodes, &func_name_to_nodes);
  
  // Print global nodes
  os << "   /* Global nodes */\n";
  for(std::vector<ALFExtendedProgramGraphNode *>::iterator n = global_nodes.begin();
      n != global_nodes.end(); ++n) {
    os << "   \"" << (*n)->Id() << "\"[label=\"";
    (*n)->Draw(os);
    os << "\",fontsize=5,width=0.01,height=0.01,margin=\"0.01,0.01\"]" << endl; 
  }
  os << endl;

  // Print nodes in clusters
  for(std::map<std::string, std::vector<ALFExtendedProgramGraphNode *> *>::iterator fn2ns = func_name_to_nodes.begin();
      fn2ns != func_name_to_nodes.end(); ++fn2ns) {
    os << "   /* Nodes belonging to function " << (*fn2ns).first << "*/\n";
    os << "   subgraph \"cluster_" << (*fn2ns).first << "\" {" << endl;
    os << "   label=\"" << (*fn2ns).first << "\"" << endl;
    std::vector<ALFExtendedProgramGraphNode *> * nodes = (*fn2ns).second;
    for( std::vector<ALFExtendedProgramGraphNode *>::iterator n = nodes->begin(); n != nodes->end(); ++n) {
      os << "      \"" << (*n)->Id() << "\"[label=\"";
      (*n)->Draw(os);
      os << "\",fontsize=5,width=0.01,height=0.01,margin=\"0.01,0.01\"]" << endl; 
    }
    os << "   }" << endl;
    // Delete temporaries
    delete nodes;
  }

  // Print edges
  os << "   /* Control-flow graph edges */\n";
  for(ALFExtendedProgramControlFlowGraph::node_iterator n = epcfg->NodesBegin();
      n != epcfg->NodesEnd(); ++n){
    for(ALFExtendedProgramGraphNode::succ_iterator se = (*n)->SuccBegin();
	se != (*n)->SuccEnd(); ++se) {
      ALFExtendedProgramGraphNode * succ = (*se).node;
      ALFExtendedProgramGraphEdge * edge = (*se).edge_annot;
      os << "   \"" << (*n)->Id() << "\" -> \""; 
      os << succ->Id() << "\"";
      os << "[style=solid";
      if(edge)
	os << ",label=\"" << edge->GetLabel() << "\"";
      os << ",fontsize=5,margin=\"0.01,0.01\"]" << endl;
    }
  }

  // Print false edges inbetween call and return nodes that goes to the same alf call stmt
  os << "   /* False edges */\n";
  std::vector<ALFExtendedProgramGraphNode *> call_nodes;  
  ALFExtendedProgramGraphNode::ExtractNodesOfType(&nodes, ALFExtendedProgramGraphNode::CALL_STMT, &call_nodes);
  std::vector<ALFExtendedProgramGraphNode *> result_nodes;  
  ALFExtendedProgramGraphNode::ExtractNodesOfType(&nodes, ALFExtendedProgramGraphNode::RESULT_STMT, &result_nodes);
  for(std::vector<ALFExtendedProgramGraphNode *>::iterator call_node = call_nodes.begin();
      call_node != call_nodes.end(); ++call_node) {
    alf::AStmt * call_stmt = (dynamic_cast<ALFExtendedProgramGraphNodeCallStmt *>(*call_node))->GetStmt();
    for(std::vector<ALFExtendedProgramGraphNode *>::iterator result_node = result_nodes.begin();
      result_node != result_nodes.end(); ++result_node) {
      alf::AStmt * result_stmt = (dynamic_cast<ALFExtendedProgramGraphNodeResultStmt *>(*result_node))->GetStmt();
      if(call_stmt == result_stmt) {
	os << "   \"" << (*call_node)->Id() << "\" -> \"" << (*result_node)->Id() << "\"";
	os << "[style=dotted]" << endl;
      }
    }
  }

  os << "  }" << endl;
  os << "}" << endl;
}

// -------------------------------------------------------
// -------------------------------------------------------
// ALFExtendedProgramControlFlowGraphBuilder
// -------------------------------------------------------
// -------------------------------------------------------

// To create the DG analysis builder class
ALFExtendedProgramControlFlowGraph *
ALFExtendedProgramControlFlowGraphBuilder::
Build(CCallGraph * cg, CALFAbsAnnotStorage * annots, alf::CAlfTuple * alf_ast)
{
  // Extract the global declarations and initializations from the ALF ast
  CDeclList * global_decls = alf_ast->GetDecls();
  CInitList * global_inits = alf_ast->GetInits();

  // Make sure that we do not have any when called abs annots 
  if(annots != NULL && HasWhenCalledAnnotsForCFGsInCG(annots, cg))
    assert("When called annots not supported by DG analysis" == 0);
  
  // Set the graph to be returned
  _epfg = new ALFExtendedProgramControlFlowGraph();

  // Create nodes and edges from the cfgs, annots, inits and decls. Also connect the 
  // nodes according to the edge sin the call graph and cfgs.
  CreateInternals(cg, annots, global_decls, global_inits);

  // Compress the created graph t make sure that all nodes have indexes
  // in subsequent order
  _epfg->CompressGraph();

  // Return the created graph
  return _epfg;
}

// -------------------------------------------------------
// To create and connecting a set of internal nodes according to 
// the things accessible from a call graph  
// -------------------------------------------------------
void 
ALFExtendedProgramControlFlowGraphBuilder::
CreateInternals(CCallGraph * cg, CALFAbsAnnotStorage * annots, CDeclList * global_decls, CInitList * global_inits) 
{
  // Create internal nodes for all CFG nodes. This includes nodes for
  // annots and global decls and inits. Each created inetranl node
  // will be associated with a cfg node.
  std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> node_to_epfg_nodes;
  CreateEPFGNodes(cg, annots, global_decls, global_inits, &node_to_epfg_nodes);

  // Create connections between internal nodes according to the vector
  // associated with each cfg node
  ConnectEPFGNodesInVectors(&node_to_epfg_nodes);

  // Create connections between internal nodes according to the pred,succ pairs in
  // the cfg graphs and the call-func and result->call pairs in the cg
  ConnectEPFGNodesAccordingToCGAndCFGEdges(cg, &node_to_epfg_nodes);
  
  // Add program start node
  AddAndConnectProgramStartNode(cg, &node_to_epfg_nodes);

  // Add program exit node
  AddAndConnectProgramExitNode(cg, &node_to_epfg_nodes);

  // Delete temporary vectors. The included nodes should however not be deleted
  for(std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *>::iterator n2en = node_to_epfg_nodes.begin();
      n2en != node_to_epfg_nodes.end(); ++n2en) {
    delete (*n2en).second;
  }
}

// -------------------------------------------------------
// To add a special start program node to the graph
// -------------------------------------------------------
void 
ALFExtendedProgramControlFlowGraphBuilder::
AddAndConnectProgramStartNode(CCallGraph * cg, std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> * node_to_epfg_nodes)
{
  // Get the program entry start node
  CFlowGraphNode * cfg_entry_node = cg->Root()->FlowGraph()->GetEntry();

  // Get the corresponding node in the list of nodes
  std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes = (*node_to_epfg_nodes)[cfg_entry_node];
  assert(epfg_nodes->size() > 0);

  // Get the first node in the list 
  ALFExtendedProgramGraphNode * old_epfg_entry_node = *(epfg_nodes->begin());
  
  // Create a new epfg prog entry start node
  ALFExtendedProgramGraphNode * new_epfg_entry_node = CreateProgramEntryEPFGNode();

  // Add connection to graph
  _epfg->AddEdge(new_epfg_entry_node, old_epfg_entry_node);

  // Make sure that the graph root node is the given node
  assert(_epfg->Root() == new_epfg_entry_node);
}
  
// -------------------------------------------------------
// To add a special exit program node to the graph
// -------------------------------------------------------
void 
ALFExtendedProgramControlFlowGraphBuilder::
AddAndConnectProgramExitNode(CCallGraph * cg, std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> * node_to_epfg_nodes)
{
  // Get the program exit nodes (it might be several)
  std::list<CFlowGraphNode *> cfg_exit_nodes;
  cg->Root()->FlowGraph()->GetExitNodes(&cfg_exit_nodes);
  assert(cfg_exit_nodes.size() > 0);

  // Create a new epfg prog exit node
  ALFExtendedProgramGraphNode * new_epfg_exit_node = CreateProgramExitEPFGNode();

  // Loop through the cfg exit nodes, find their corresponding epg
  // nodes and connect them to the new exit node
  for(std::list<CFlowGraphNode *>::iterator n = cfg_exit_nodes.begin(); n != cfg_exit_nodes.end(); ++n) {

    // Get the corresponding list of nodes
    std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes = (*node_to_epfg_nodes)[*n];
    assert(epfg_nodes->size() > 0);

    // Get the last node in the list 
    ALFExtendedProgramGraphNode * old_epfg_exit_node = *(epfg_nodes->rbegin());
  
    // Add connection to graph
    _epfg->AddEdge(old_epfg_exit_node, new_epfg_exit_node);
  }

  // Make sure that the graph exit node is the given node
  assert(_epfg->Exit() == new_epfg_exit_node);
}
  

// -------------------------------------------------------
// To create internal nodes from CFG nodes. This includes internal nodes for
// annots, global decls and inits, local decls, function arguments,
// etc. Each created dg unit will be associated with a node.
// -------------------------------------------------------
void 
ALFExtendedProgramControlFlowGraphBuilder::
CreateEPFGNodes(CCallGraph * cg, CALFAbsAnnotStorage * annots, 
		CDeclList * global_decls, CInitList * global_inits, 
		std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> * cfg_node_to_epfg_nodes)
{
  // Get the program entry start node
  CFlowGraphNode * prog_entry_node = cg->Root()->FlowGraph()->GetEntry();

  // Loop through all the cfgs in the cg
  for(CCallGraph::node_iterator cg_node = cg->NodesBegin(); cg_node != cg->NodesEnd(); ++cg_node) {

    // Get the corresponding flow graph
    CFlowGraph * cfg = (*cg_node)->FlowGraph();
    
    // Get the cfg start node
    CFlowGraphNode * func_entry_node = cfg->GetEntry();
    
    // Loop through all the cfg nodes
    for(CFlowGraph::node_iterator cfg_node = cfg->NodesBegin(); cfg_node != cfg->NodesEnd(); ++cfg_node) {

      // Create a vector of internal nodes to be associated with the cfg node
      std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes = new std::vector<ALFExtendedProgramGraphNode *>;

      // Create the internal nodes
      CreateEPFGNodesForCFGNode(*cfg_node, cg, prog_entry_node, func_entry_node, 
				annots, global_decls, global_inits, epfg_nodes);

      // Update maps with vectors
      (*cfg_node_to_epfg_nodes)[*cfg_node] = epfg_nodes;
    }
  }
}


// -------------------------------------------------------
// To create internal nodes for a CFG node. Will also create internal nodes
// annots, global decls and inits, local decls, function arguments,
// etc. Each created dg unit will be stored in the vector of internal nodes.
// -------------------------------------------------------
void 
ALFExtendedProgramControlFlowGraphBuilder::
CreateEPFGNodesForCFGNode(CFlowGraphNode * cfg_node, CCallGraph * cg, CFlowGraphNode * prog_entry_node, 
			  CFlowGraphNode * func_entry_node,
			  CALFAbsAnnotStorage * annots, CDeclList * global_decls, CInitList * global_inits, 
			  std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes)
{
   // ---------------------------------
   // Handle program entry nodes 
   // ---------------------------------
   if(prog_entry_node == cfg_node) {

      { // Create internal nodes for global declarations
         if(global_decls != NULL && global_decls->ElementCount() > 0) { 
            for(CDeclList::list_iterator decl = global_decls->Iterator(); decl != global_decls->InvalidIterator(); ++decl) {
               CreateEPFGNodesForAlloc(*decl, ALFExtendedProgramGraphNode::GLOBAL_ALLOC_ASSIGN, epfg_nodes);
            }
         }
      }

      { // Create internal nodes for initializations
         if(global_inits != NULL && global_inits->ElementCount() > 0) { 
            for(CInitList::list_iterator init = global_inits->Iterator(); init != global_inits->InvalidIterator(); ++init) {
               CreateEPFGNodesForInit(*init, ALFExtendedProgramGraphNode::GLOBAL_INIT, epfg_nodes);
            }
         }
      }

      { // Create internal nodes for prog entry annot
         if(annots != NULL && annots->HasProgEntryALFAbsAnnot()) {
            CALFAbsAnnot * annot = annots->GetProgEntryALFAbsAnnot(); 
            CreateEPFGNodesForAnnot(annot, ALFExtendedProgramGraphNode::PROG_ENTRY_ANNOT, epfg_nodes);
         }
      }

      { // Create nodes for arguments to root function (if any)
         alf::CFuncTuple * func = dynamic_cast<alf::CFuncTuple*>(cfg_node->FlowGraph()->Function());
         CreateEPFGNodesForRootFuncArgs(func, epfg_nodes);
      }
   }

   // ---------------------------------
   // Handle function entry nodes 
   // ---------------------------------
   if(func_entry_node == cfg_node) {

      { // Create node for function entry
         alf::CFuncTuple * func = dynamic_cast<alf::CFuncTuple*>(cfg_node->FlowGraph()->Function());
         CreateEPFGNodesForFunc(func, epfg_nodes);
      }

      { // Create internal nodes for function local declarations
         alf::CFuncTuple * func = dynamic_cast<alf::CFuncTuple*>(cfg_node->FlowGraph()->Function());
         assert(func);
         CreateEPFGNodesForFuncAllocs(func, epfg_nodes);
      }

      { // Create internal nodes according to func entry annots
         CFlowGraph * cfg = cfg_node->FlowGraph();
         if(annots != NULL && annots->HasFuncEntryALFAbsAnnot(cfg)) {
            CALFAbsAnnot * annot = annots->GetFuncEntryALFAbsAnnot(cfg); 
            alf::CFuncTuple * func = dynamic_cast<alf::CFuncTuple *>(cfg->Function());
            CreateEPFGNodesForAnnot(annot, ALFExtendedProgramGraphNode::FUNC_ENTRY_ANNOT, epfg_nodes, func);
         }
      }
   }

   // ---------------------------------
   // Handle the cfg node
   // ---------------------------------
   {
      { // Create internal nodes for node entry annots
         if(annots != NULL && annots->HasNodeEntryALFAbsAnnot(cfg_node)) {
            list<CALFAbsAnnot *> * anns = annots->GetNodeEntryALFAbsAnnot(cfg_node);
            alf::AStmt * stmt = dynamic_cast<alf::AStmt *>(cfg_node->Stmt());
            for(list<CALFAbsAnnot *>::iterator ann = anns->begin(); ann != anns->end(); ++ann) {
               CreateEPFGNodesForAnnot(*ann, ALFExtendedProgramGraphNode::STMT_ENTRY_ANNOT, epfg_nodes, NULL, stmt);
            }
         }
      }

      { // Create internal nodes for the statement in the CFG node
         alf::AStmt * astmt = dynamic_cast<alf::AStmt *>(cfg_node->Stmt());
         assert(astmt);
         CreateEPFGNodesForStmt(astmt, epfg_nodes);
      }

      { // Check if we are at root function and is a return statement
         if(cfg_node->FlowGraph()->Function() == prog_entry_node->FlowGraph()->Function() && 
            cfg_node->Stmt()->Type() == CGenericStmt::GS_RETURN) {
               alf::CReturnStmtTuple * return_stmt = dynamic_cast<alf::CReturnStmtTuple *>(cfg_node->Stmt());
               CreateEPFGNodesForRootFuncReturnArgs(return_stmt, epfg_nodes);
         }
      }

      { // Create internal nodes for node exit annots
         if(annots != NULL && annots->HasNodeExitALFAbsAnnot(cfg_node)) {
            list<CALFAbsAnnot *> * anns = annots->GetNodeExitALFAbsAnnot(cfg_node);
            alf::AStmt * stmt = dynamic_cast<alf::AStmt *>(cfg_node->Stmt());
            for(list<CALFAbsAnnot *>::iterator ann = anns->begin(); ann != anns->end(); ++ann) {
               CreateEPFGNodesForAnnot(*ann, ALFExtendedProgramGraphNode::STMT_EXIT_ANNOT, epfg_nodes, NULL, stmt);
            }
         }
      }
   }

   // Make sure that we have got some units
   assert(epfg_nodes->size() > 0);
}


// -------------------------------------------------------
// Help functions for connecting all pred,succ pairs in a list
// -------------------------------------------------------
void
ALFExtendedProgramControlFlowGraphBuilder::
ConnectEPFGNodesInVectors(std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> * node_to_epfg_nodes)
{
  // Loop through all mappings 
  for(std::map<CFlowGraphNode *, vector<ALFExtendedProgramGraphNode *> *>::iterator n2u = node_to_epfg_nodes->begin();
      n2u != node_to_epfg_nodes->end(); ++n2u) {
    std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes = (*n2u).second;
    ConnectEPFGNodesInVector(epfg_nodes);
  }
}

// Create connections between internal nodes according to the vector
// associated with each cfg node. Special treatment of call->func internal nodes.
void
ALFExtendedProgramControlFlowGraphBuilder::
ConnectEPFGNodesInVector(std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes, bool include_edges_from_call_nodes) 
{
   for(std::vector<ALFExtendedProgramGraphNode *>::const_iterator epfg_node = epfg_nodes->begin();
       epfg_node != epfg_nodes->end(); ++epfg_node) {
         std::vector<ALFExtendedProgramGraphNode *>::const_iterator next_epfg_node = epfg_node;
         ++next_epfg_node;
         if(next_epfg_node != epfg_nodes->end()) {
            // We skip making pairs to nodes succeeding internal nodes originating
            // from call statements. This is because this node should be
            // going to the dg unit corresponding to the called function.
            ALFExtendedProgramGraphNode * alf_epfg_node = dynamic_cast<ALFExtendedProgramGraphNode *>(*epfg_node);
            if(alf_epfg_node->GetType() != ALFExtendedProgramGraphNode::CALL_STMT ||
               include_edges_from_call_nodes) {
                  _epfg->AddEdge(*epfg_node, *next_epfg_node);
            }
         }
   }
}

// -------------------------------------------------------
// Create connections between internal nodes according to the pred,succ pairs in
// the cfg graphs and the call-func and result->call pairs in the cg
// -------------------------------------------------------
void
ALFExtendedProgramControlFlowGraphBuilder::
ConnectEPFGNodesAccordingToCGAndCFGEdges(CCallGraph * cg, 
					 std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> * node_to_epfg_nodes)
{
  // Connect internal nodes according to edges in the call graph
  ConnectEPFGNodesAccordingToCGEdges(cg, node_to_epfg_nodes);

  // Connect internal nodes according to edges in the cfgs
  for(CCallGraph::node_iterator cg_node = cg->NodesBegin(); cg_node != cg->NodesEnd(); ++cg_node) {
    CFlowGraph * cfg = (*cg_node)->FlowGraph();
    ConnectEPFGNodesAccordingToCFGEdges(cfg, node_to_epfg_nodes);
  }
}

// Connect internal nodes according to the edges in the call graph
void 
ALFExtendedProgramControlFlowGraphBuilder::
ConnectEPFGNodesAccordingToCGEdges(CCallGraph * cg, 
				   std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> * node_to_epfg_nodes) 
{
   // collect all call sites of the program, so that we can later check that the
   // call graph has an outgoing edge for every one of them (if not, this means
   // that there are function definitions missing from the program, which in
   // turn means that the PCFG cannot be built properly)
   std::set<CFlowGraphNode*> unconn_call_sites;
   for (auto cn = cg->NodesBegin(), ce = cg->NodesEnd(); cn != ce; ++cn) {
      CFlowGraph *fg = (*cn)->FlowGraph();
      for (auto fn = fg->NodesBegin(), fe = fg->NodesEnd(); fn != fe; ++fn) {
         if ((*fn)->Stmt()->Type() == CGenericStmt::GS_CALL) {
            unconn_call_sites.insert(*fn);
         }
      }
   }

   // Get and iterate through all edges in the call graph 
   CCallGraph::T_edge_list cg_edges;
   cg->Edges(&cg_edges);
   for(CCallGraph::T_edge_list_iterator e = cg_edges.begin(); e != cg_edges.end(); ++e) {

      // Get the edge data 
      // CCallGraphNode * call_node = (*e).from;
      CCallGraphNode * enter_node = (*e).to;
      CCallGraphEdgeAnnot * edge_annot = (*e).edge_annot;

      // Get the flow graph of the enter node
      CFlowGraph * enter_cfg = enter_node->FlowGraph();

      // Get the flow graph node the call goes from
      CFlowGraphNode * call_cfg_node = edge_annot->CallSite();
      unconn_call_sites.erase(call_cfg_node);

      // Get the internal nodes of the call node
      std::vector<ALFExtendedProgramGraphNode *> * call_epfg_nodes = (*node_to_epfg_nodes)[call_cfg_node];

      {  // ---------------------------------
         // Connect the nodes according to the func call edge
         // (call->enter). This includes creating nodes which assign func
         // call arguments to frames allocated in the called function.
         // ---------------------------------

         // Get the node corresponding to the call node from the calling epfg node
         ALFExtendedProgramGraphNode * call_epfg_node = NULL;
         for(std::vector<ALFExtendedProgramGraphNode *>::iterator c = call_epfg_nodes->begin(); 
             c != call_epfg_nodes->end(); ++c) {
               ALFExtendedProgramGraphNode * alf_epfg_node = dynamic_cast<ALFExtendedProgramGraphNode *>(*c);
               if(alf_epfg_node->GetType() == ALFExtendedProgramGraphNode::CALL_STMT) {
                  call_epfg_node = (*c);	  
                  break;
               }
         }
         assert(call_epfg_node);
         // Get the call statement from the node and its argument expressions
         ALFExtendedProgramGraphNodeCallStmt * call_stmt_epfg_node = 
            dynamic_cast<ALFExtendedProgramGraphNodeCallStmt *>(call_epfg_node);
         CCallStmtTuple * call_stmt = call_stmt_epfg_node->GetCallStmt();
         const CExprList * call_args = call_stmt->GetExprs();

         // Get the flow graph node the call goes to and the corresponding enter epfg node
         CFlowGraphNode * enter_cfg_node = enter_cfg->GetEntry();
         std::vector<ALFExtendedProgramGraphNode *> * enter_epfg_nodes = (*node_to_epfg_nodes)[enter_cfg_node];
         ALFExtendedProgramGraphNode * enter_epfg_node = *(enter_epfg_nodes->begin());

         // Get the function tuple of the called function and its corresponding arguments
         const alf::CFuncTuple * enter_func = dynamic_cast<const alf::CFuncTuple *>(enter_cfg->Function()); 
         const CArgDeclList* enter_func_args = enter_func->GetArgs();

         // Create a vector for the nodes to connect
         std::vector<ALFExtendedProgramGraphNode *> epfg_nodes_to_connect;

         // Add the call node
         epfg_nodes_to_connect.push_back(call_epfg_node);
         // Create nodes which connects the calling function arguments with the enter function params
         CArgDeclList::const_list_iterator efa = enter_func_args->ConstIterator();
         CExprList::const_list_iterator ca = call_args->ConstIterator();
         for(; efa != enter_func_args->InvalidIterator() && ca != call_args->InvalidIterator(); efa++, ca++) {
            epfg_nodes_to_connect.push_back(CreateEPFGNode(*ca, *efa));
         }
         // Add the enter node
         epfg_nodes_to_connect.push_back(enter_epfg_node);

         // Connect all the nodes in the vector, including edges from call nodes
         ConnectEPFGNodesInVector(&epfg_nodes_to_connect, true);
      }

      {  // ---------------------------------
         // Connect internal nodes according to func call return edges (return->result)
         // This include creating function return expressions to result address expressions
         // ---------------------------------

         // Get all the return nodes of the flow graph of the called function
         std::vector<CFlowGraphNode *> return_cfg_nodes;
         enter_cfg->ExitNodes(&return_cfg_nodes);

         // Get the internal nodes of result type from calling cfg node internal nodes
         ALFExtendedProgramGraphNode * result_epfg_node = NULL;
         for(std::vector<ALFExtendedProgramGraphNode *>::iterator c = call_epfg_nodes->begin(); 
             c != call_epfg_nodes->end(); ++c) {
               ALFExtendedProgramGraphNode * alf_epfg_node = dynamic_cast<ALFExtendedProgramGraphNode *>(*c);
               if(alf_epfg_node->GetType() == ALFExtendedProgramGraphNode::RESULT_STMT) {
                  result_epfg_node = (*c);
                  break;
               }
         }
         assert(result_epfg_node);
         // Get the call statement from the node and its result argument expressions
         ALFExtendedProgramGraphNodeResultStmt * result_stmt_epfg_node = 
            dynamic_cast<ALFExtendedProgramGraphNodeResultStmt *>(result_epfg_node);
         CCallStmtTuple * call_stmt = result_stmt_epfg_node->GetResultStmt();
         const CExprList * result_arg_vals =  call_stmt->GetAddrExprs();

         // Connect the last dg unit of all the exit nodes with the result dg unit
         for(std::vector<CFlowGraphNode *>::iterator return_cfg_node = return_cfg_nodes.begin();
             return_cfg_node != return_cfg_nodes.end(); ++return_cfg_node) {

               std::vector<ALFExtendedProgramGraphNode *> * return_epfg_nodes = (*node_to_epfg_nodes)[*return_cfg_node];
               ALFExtendedProgramGraphNode * return_epfg_node = *(return_epfg_nodes->rbegin());
               assert(return_epfg_node->GetType() == ALFExtendedProgramGraphNode::RETURN_STMT);

               // Get the return statement from the node and its return argument expressions
               ALFExtendedProgramGraphNodeReturnStmt * return_stmt_epfg_node = 
                  dynamic_cast<ALFExtendedProgramGraphNodeReturnStmt *>(return_epfg_node);
               alf::CReturnStmtTuple * return_stmt = return_stmt_epfg_node->GetReturnStmt();
               const alf::CExprList * return_arg_vals = return_stmt->GetExprs();

               // Create a vector for the nodes to connect
               std::vector<ALFExtendedProgramGraphNode *> epfg_nodes_to_connect;

               // Add the return efpg node
               epfg_nodes_to_connect.push_back(return_epfg_node);
               // Create nodes which connects the calling function arguments with the enter function params
               CExprList::const_list_iterator ret_arg = return_arg_vals->ConstIterator();
               CExprList::const_list_iterator res_arg = result_arg_vals->ConstIterator();
               for(; ret_arg != return_arg_vals->InvalidIterator() && res_arg != result_arg_vals->InvalidIterator(); ret_arg++, res_arg++) {
                  epfg_nodes_to_connect.push_back(CreateEPFGNode(*ret_arg, *res_arg));
               }
               // Add the result node
               epfg_nodes_to_connect.push_back(result_epfg_node);

               // Connect all the nodes in the vector
               ConnectEPFGNodesInVector(&epfg_nodes_to_connect);	
         }
      }
   }

   if (unconn_call_sites.size() > 0) {
      throw runtime_error("The PCFG could not be built, since there appears to be "
                          "function definitions missing from the program");
   }
}

// Connect internal nodes according to edges in the cfg
void 
ALFExtendedProgramControlFlowGraphBuilder::
ConnectEPFGNodesAccordingToCFGEdges(CFlowGraph * cfg, 
				    std::map<CFlowGraphNode *, std::vector<ALFExtendedProgramGraphNode *> *> * node_to_epfg_nodes)
{
  // Get the edges of the cfg
  CFlowGraph::T_edge_list edges;
  cfg->Edges(&edges);

  // Loop through all edges 
  for(CFlowGraph::T_edge_list_iterator e = edges.begin(); e != edges.end(); ++e ) {

    // Get the edge data 
    CFlowGraphNode * from_node = (*e).from;
    CFlowGraphNode * to_node = (*e).to;
    CFlowGraphEdgeAnnot * edge_annot = (*e).edge_annot;
      
    // If the edge is a false edge we should not generate any
    // connection for it (this is handled when we generate
    // connections for call edges)
    if(!edge_annot->IsFalseEdge()) {
      
      // The edge is a normal edge

      // Get the epfg_nodes of the from and to nodes
      std::vector<ALFExtendedProgramGraphNode *> * from_epfg_nodes = (*node_to_epfg_nodes)[from_node];
      std::vector<ALFExtendedProgramGraphNode *> * to_epfg_nodes = (*node_to_epfg_nodes)[to_node];
      
      assert(from_epfg_nodes->size() > 0);
      assert(to_epfg_nodes->size() > 0);

      // Connect last epfg_node of the from node with the first epfg_node of the to node 
      ALFExtendedProgramGraphNode * last_from_epfg_node = *(from_epfg_nodes->rbegin());
      ALFExtendedProgramGraphNode * first_to_epfg_node = *(to_epfg_nodes->begin());
      _epfg->AddEdge(last_from_epfg_node, first_to_epfg_node);
    }
  }
}

// -------------------------------------------------------
// CreateEPFGNodesForAlloc -
// To create epfg_nodes for an alloc
// -------------------------------------------------------
void
ALFExtendedProgramControlFlowGraphBuilder::
CreateEPFGNodesForAlloc(alf::CAllocTuple * alloc, ALFExtendedProgramGraphNode::TYPE type, 
		       std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes)
{
  // Create a internal node and add it last to the vector 
  ALFExtendedProgramGraphNode * epfg_node = CreateEPFGNode(alloc, type);
  epfg_nodes->push_back(epfg_node);
}

// -------------------------------------------------------
// CreateEPFGNodesForInit -
// To create epfg_nodes for an init
// -------------------------------------------------------
void
ALFExtendedProgramControlFlowGraphBuilder::
CreateEPFGNodesForInit(alf::CInitTuple * init, ALFExtendedProgramGraphNode::TYPE type, 
		       std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes)
{
  // Create a internal node and add it last to the vector 
  ALFExtendedProgramGraphNode * epfg_node = CreateEPFGNode(init, type);
  epfg_nodes->push_back(epfg_node);
}


// -------------------------------------------------------
// CreateEPFGNodesForAnnot -
// To create epfg_nodes for ALF abstract annotations
// -------------------------------------------------------
void
ALFExtendedProgramControlFlowGraphBuilder ::
CreateEPFGNodesForAnnot(CALFAbsAnnot * annot, ALFExtendedProgramGraphNode::TYPE type, 
			std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes, 
			alf::CFuncTuple * func, alf::AStmt * stmt)
{
  // Create a annot node and add it last to the vector 
  ALFExtendedProgramGraphNode * epfg_node = CreateEPFGNode(annot, type, func, stmt);
  epfg_nodes->push_back(epfg_node);
}

// -------------------------------------------------------
// Help function for creating epfg nodes for root function arguments
// -------------------------------------------------------
void
ALFExtendedProgramControlFlowGraphBuilder ::
CreateEPFGNodesForRootFuncArgs(alf::CFuncTuple * func, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes)
{
  const alf::CArgDeclList * arg_allocs = func->GetArgs();
  for(alf::CArgDeclList::const_list_iterator arg_alloc = arg_allocs->ConstIterator();
      arg_alloc != arg_allocs->InvalidIterator(); ++arg_alloc) {
    ALFExtendedProgramGraphNode * epfg_node = CreateEPFGNode(*arg_alloc, ALFExtendedProgramGraphNode::ROOT_FUNC_ENTER_ASSIGN);
    epfg_nodes->push_back(epfg_node);
  }
}

// -------------------------------------------------------
// Help function for creating epfg nodes for root function return arguments
// -------------------------------------------------------
void
ALFExtendedProgramControlFlowGraphBuilder::
CreateEPFGNodesForRootFuncReturnArgs(alf::CReturnStmtTuple * return_stmt, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes)
{
  // Get the return arguments (if any)
  const CExprList* return_exprs = return_stmt->GetExprs();
  // Create nodes for return arguments of root function
  for(alf::CExprList::const_list_iterator return_expr = return_exprs->ConstIterator();
      return_expr != return_exprs->InvalidIterator(); ++return_expr) {
    ALFExtendedProgramGraphNode * epfg_node = CreateEPFGNode(*return_expr, ALFExtendedProgramGraphNode::ROOT_FUNC_RETURN_ASSIGN);
    epfg_nodes->push_back(epfg_node);
  }
}

// -------------------------------------------------------
// Help function for creating epfg nodes for the function 
// -------------------------------------------------------
void
ALFExtendedProgramControlFlowGraphBuilder ::
CreateEPFGNodesForFunc(alf::CFuncTuple * func, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes)
{
  ALFExtendedProgramGraphNode * epfg_node = CreateEPFGNode(func);
  epfg_nodes->push_back(epfg_node);
}



// // -------------------------------------------------------
// // Help function for creating epfg nodes for the function arguments
// // -------------------------------------------------------
// void
// ALFExtendedProgramControlFlowGraphBuilder ::
// CreateEPFGNodesForFuncArgs(alf::CFuncTuple * func, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes)
// {
//   // For all arguments to the function we create a node
//   const CArgDeclList * fargs = func->GetArgs();
//   for(CArgDeclList::const_list_iterator farg = fargs->ConstIterator(); farg != fargs->InvalidIterator(); ++farg) {
//     epfg_nodes->push_back(CreateEPFGNode(*farg, ALFExtendedProgramGraphNode::FUNC_ENTER_ARG_ASSIGN));
//   }
// }
 
// -------------------------------------------------------
// Help function for creating epfg_nodes for declarations in function 
// -------------------------------------------------------
void
ALFExtendedProgramControlFlowGraphBuilder ::
CreateEPFGNodesForFuncAllocs(alf::CFuncTuple * func, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes)
{
  // For all local declarations in the function we create a node. 

  // Extract and loop through all the scope statements in the function
  vector<CGenericStmt *> scope_stmts;
  scope_stmts.push_back((CScopeTuple *) func->GetScope());
  func->GetStmtsInFunctionScopeAndSubordinateScopes(&scope_stmts, CGenericNode::TYPE_SCOPE_TUPLE);
  for (vector<CGenericStmt *>::const_iterator sc = scope_stmts.begin(); sc != scope_stmts.end(); ++sc) {
    const CScopeTuple * scope_tuple = dynamic_cast<const CScopeTuple *>(*sc);
    assert(scope_tuple != 0);
    // Create an internal node for each scope local declaration made
    const alf::CDeclList * decls = scope_tuple->GetDecls();
    for(CDeclList::const_list_iterator decl = decls->ConstIterator(); decl != decls->InvalidIterator(); ++decl) {
      CreateEPFGNodesForAlloc(*decl, ALFExtendedProgramGraphNode::FUNC_ALLOC_ASSIGN, epfg_nodes);
    }

    // Extra check to make sure that no inits are made (should have been caught in static check)
    assert(scope_tuple->GetInits()->ElementCount() == 0);
  }
} 

// -------------------------------------------------------
// Help function for creating internal nodes from the argument statement 
// -------------------------------------------------------
void
ALFExtendedProgramControlFlowGraphBuilder ::
CreateEPFGNodesForStmt(alf::AStmt * stmt, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes)
{

   // Check what type of statement we have and call the corresponding
   // create internal nodes function
   switch(stmt->GetNodeType()) {
   // Null, jump and switch statements do not generate any defines
   case CGenericNode::TYPE_NULL_STMT_TUPLE:
   {
      // NULL statement
      epfg_nodes->push_back(CreateEPFGNode(stmt, ALFExtendedProgramGraphNode::NULL_STMT));
      break;
   }
   case CGenericNode::TYPE_JUMP_STMT_TUPLE:
   {
      // Jump statement
      epfg_nodes->push_back(CreateEPFGNode(stmt, ALFExtendedProgramGraphNode::JUMP_STMT));
      break;
   }
   case CGenericNode::TYPE_SWITCH_STMT_TUPLE:
   {
      // Switch statement 
      epfg_nodes->push_back(CreateEPFGNode(stmt, ALFExtendedProgramGraphNode::SWITCH_STMT));
      break;
   }
   case CGenericNode::TYPE_STORE_STMT_TUPLE:
   {
      // Store statement 
      epfg_nodes->push_back(CreateEPFGNode(stmt, ALFExtendedProgramGraphNode::STORE_STMT));
      break;
   }
   case CGenericNode::TYPE_CALL_STMT_TUPLE:
   {
      // We add two nodes in the graph to be able to handle the case of returning flow  
      epfg_nodes->push_back(CreateEPFGNode(stmt, ALFExtendedProgramGraphNode::CALL_STMT));
      epfg_nodes->push_back(CreateEPFGNode(stmt, ALFExtendedProgramGraphNode::RESULT_STMT));
      break;
   }
   case CGenericNode::TYPE_RETURN_STMT_TUPLE:
   {
      // Create a node for the return statement
      epfg_nodes->push_back(CreateEPFGNode(stmt, ALFExtendedProgramGraphNode::RETURN_STMT));
      break;
   }
   // Free and other type of statements are not supported yet 
   case CGenericNode::TYPE_FREE_STMT_TUPLE:
   default: {
      assert("ALF DG analysis - unsupported statement" == 0);
      break;
   }
   } // end switch
}

// Returns true if any of the cfgs in the cfg set has an when called annot
bool
ALFExtendedProgramControlFlowGraphBuilder::
HasWhenCalledAnnotsForCFGsInCG(CALFAbsAnnotStorage * annots, CCallGraph * cg)
{
  // Loop through all the cfgs in the cg
  for(CCallGraph::node_iterator cg_node = cg->NodesBegin(); cg_node != cg->NodesEnd(); ++cg_node) {

    // Get the corresponding flow graph
    CFlowGraph * cfg = (*cg_node)->FlowGraph();

    // Check if we have a when called annot for this cfg
    if(annots->HasWhenCalledAlfAbsAnnots(cfg))
      return true;
  }
  // No annot found on the given cfgs
  return false;
}

// // -------------------------------------------------------
// // Help functions for creating nodes for func call param assignments 
// // -------------------------------------------------------
// void
// ALFExtendedProgramControlFlowGraphBuilder::
// CreateEPFGNodesForCallParamAssigns(CCallStmtTuple * call_stmt, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes)
// {
//   // Get the list of expressions to store in the parameter passing area
//   const alf::CExprList * arg_exprs = call_stmt->GetExprs();
//   // Create a EPFG node for each expression
//   for(alf::CExprList::const_list_iterator arg_expr = arg_exprs->ConstIterator(); 
//       arg_expr != arg_exprs->InvalidIterator(); ++arg_expr) {
//     epfg_nodes->push_back(CreateEPFGNode((*arg_expr), ALFExtendedProgramGraphNode::FUNC_CALL_PARAM_ASSIGN));
//   }
// }

// // -------------------------------------------------------
// // Help functions for creating nodes for result argument assignments
// // -------------------------------------------------------
// void
// ALFExtendedProgramControlFlowGraphBuilder::
// CreateEPFGNodesForResultArgAssigns(CCallStmtTuple * call_stmt, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes)
// {
//   // Get the list of expressions where to store values from the return parameter passing area
//   const CExprList * addr_exprs = call_stmt->GetAddrExprs();
//   for(CExprList::const_list_iterator addr_expr = addr_exprs->ConstIterator(); 
//       addr_expr != addr_exprs->InvalidIterator(); ++addr_expr) {
//     epfg_nodes->push_back(CreateEPFGNode((*addr_expr), ALFExtendedProgramGraphNode::FUNC_RESULT_ARG_ASSIGN));
//   }
// }

// // -------------------------------------------------------
// // Help functions for creating nodes for return parameter area assignments
// // -------------------------------------------------------
// void
// ALFExtendedProgramControlFlowGraphBuilder::
// CreateEPFGNodesForReturnParamAssigns(CReturnStmtTuple * return_stmt, std::vector<ALFExtendedProgramGraphNode *> * epfg_nodes)
// {
//   // Get the list of expressions where to store values from the return parameter passing area
//   const CExprList * ret_val_exprs = return_stmt->GetExprs();
//   for(CExprList::const_list_iterator ret_val_expr = ret_val_exprs->ConstIterator(); 
//       ret_val_expr != ret_val_exprs->InvalidIterator(); ++ret_val_expr) {
//     epfg_nodes->push_back(CreateEPFGNode((*ret_val_expr), ALFExtendedProgramGraphNode::FUNC_RETURN_PARAM_ASSIGN));
//   }
// }

// -------------------------------------------------------
// Help functions for creating ALFExtendedProgramGraphNodes with annots
// -------------------------------------------------------

// To create an internal node for an annot
ALFExtendedProgramGraphNode *
ALFExtendedProgramControlFlowGraphBuilder::
CreateEPFGNode(CALFAbsAnnot * annot, ALFExtendedProgramGraphNode::TYPE type, 
	       alf::CFuncTuple * func, alf::AStmt * stmt)
{
  ALFExtendedProgramGraphNode * epfg_node = ALFExtendedProgramGraphNode::CreateNode(annot, type, func, stmt);
  _epfg->AddNode(epfg_node);
  _epfg_nodes.push_back(epfg_node);
  return epfg_node;
}

// -------------------------------------------------------
// Help functions for creating ALFExtendedProgramGraphNodes with allocs
// -------------------------------------------------------

// To create an internal node for an alloc
ALFExtendedProgramGraphNode *
ALFExtendedProgramControlFlowGraphBuilder::
CreateEPFGNode(alf::CAllocTuple * alloc, ALFExtendedProgramGraphNode::TYPE type)
{
  ALFExtendedProgramGraphNode * epfg_node = ALFExtendedProgramGraphNode::CreateNode(alloc, type);
  _epfg->AddNode(epfg_node);
  _epfg_nodes.push_back(epfg_node);
  return epfg_node;
}

// -------------------------------------------------------
// Help functions for creating ALFExtendedProgramGraphNodes with init
// -------------------------------------------------------

// To create an interal node for an init 
ALFExtendedProgramGraphNode *
ALFExtendedProgramControlFlowGraphBuilder::
CreateEPFGNode(alf::CInitTuple * init, ALFExtendedProgramGraphNode::TYPE type)
{
  ALFExtendedProgramGraphNode * epfg_node = ALFExtendedProgramGraphNode::CreateNode(init, type);
  _epfg->AddNode(epfg_node);
  _epfg_nodes.push_back(epfg_node);
  return epfg_node;
}

// -------------------------------------------------------
// Help functions for creating ALFExtendedProgramGraphNodes with stmt
// -------------------------------------------------------

// To create a DG unit which do not result in any variable definitions
ALFExtendedProgramGraphNode *
ALFExtendedProgramControlFlowGraphBuilder::
CreateEPFGNode(alf::AStmt * stmt, ALFExtendedProgramGraphNode::TYPE type)
{
  ALFExtendedProgramGraphNode * epfg_node = ALFExtendedProgramGraphNode::CreateNode(stmt, type);
  _epfg->AddNode(epfg_node);
  _epfg_nodes.push_back(epfg_node);
  return epfg_node;
}

// -------------------------------------------------------
// Help functions for creating ALFExtendedProgramGraphNodes with return expression 
// -------------------------------------------------------

// To create a DG unit which do not result in any variable definitions
ALFExtendedProgramGraphNode *
ALFExtendedProgramControlFlowGraphBuilder::
CreateEPFGNode(alf::AExpr * expr, ALFExtendedProgramGraphNode::TYPE type)
{
  ALFExtendedProgramGraphNode * epfg_node = ALFExtendedProgramGraphNode::CreateNode(expr, type);
  _epfg->AddNode(epfg_node);
  _epfg_nodes.push_back(epfg_node);
  return epfg_node;
}

// -------------------------------------------------------
// CreateProgramEntryEPFGNode -
// To create a start program epfg_node
// -------------------------------------------------------
ALFExtendedProgramGraphNode * 
ALFExtendedProgramControlFlowGraphBuilder::
CreateProgramEntryEPFGNode() 
{
  ALFExtendedProgramGraphNode * epfg_node = new ALFExtendedProgramGraphNodeProgEntry();
  _epfg->AddNode(epfg_node);
  _epfg_nodes.push_back(epfg_node);
  return epfg_node;
}


// -------------------------------------------------------
// CreateProgramStartEPFGNode -
// To create a exit program epfg_node
// -------------------------------------------------------
ALFExtendedProgramGraphNode * 
ALFExtendedProgramControlFlowGraphBuilder::
CreateProgramExitEPFGNode() 
{
  ALFExtendedProgramGraphNode * epfg_node = new ALFExtendedProgramGraphNodeProgExit();
  _epfg->AddNode(epfg_node);
  _epfg_nodes.push_back(epfg_node);
  return epfg_node;
}

// -------------------------------------------------------
// CreateProgramStartEPFGNode -
// To create a exit program epfg_node
// -------------------------------------------------------
ALFExtendedProgramGraphNode * 
ALFExtendedProgramControlFlowGraphBuilder::
CreateEPFGNode(alf::CFuncTuple * func) 
{
  ALFExtendedProgramGraphNode * epfg_node = ALFExtendedProgramGraphNode::CreateNode(func);
  _epfg->AddNode(epfg_node);
  _epfg_nodes.push_back(epfg_node);
  return epfg_node;
}

// -------------------------------------------------------
// Help functions for creating ALFExtendedProgramGraphNode
// -------------------------------------------------------
ALFExtendedProgramGraphNode *
ALFExtendedProgramControlFlowGraphBuilder::
CreateEPFGNode(alf::AExpr * func_call_arg, alf::CAllocTuple * func_enter_var)
{
  ALFExtendedProgramGraphNode * epfg_node = ALFExtendedProgramGraphNode::CreateNode(func_call_arg, func_enter_var);
  _epfg->AddNode(epfg_node);
  _epfg_nodes.push_back(epfg_node);
  return epfg_node;
}

// -------------------------------------------------------
// Help functions for creating ALFExtendedProgramGraphNode
// -------------------------------------------------------
ALFExtendedProgramGraphNode *
ALFExtendedProgramControlFlowGraphBuilder::
CreateEPFGNode(alf::AExpr * func_return_arg, alf::AExpr * func_result_var)
{
  ALFExtendedProgramGraphNode * epfg_node = ALFExtendedProgramGraphNode::CreateNode(func_return_arg, func_result_var);
  _epfg->AddNode(epfg_node);
  _epfg_nodes.push_back(epfg_node);
  return epfg_node;
}



