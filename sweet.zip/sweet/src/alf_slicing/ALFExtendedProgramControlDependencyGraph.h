#ifndef ALFEXTENDEDPROGRAMCONTROLDEPENDENCYGRAPH_H_
#define ALFEXTENDEDPROGRAMCONTROLDEPENDENCYGRAPH_H_

#include "absann/CALFAbsAnnot.h"
#include "graphs/cg/CCallGraph.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CInitList.h"
#include "program/alf/CInitTuple.h"
#include "program/alf/AStmt.h"
#include "alf_slicing/ALFExtendedProgramGraphNode.h"
#include "alf_slicing/ALFExtendedProgramGraphEdge.h"
#include "alf_slicing/ALFExtendedProgramControlFlowGraph.h"
#include "graphs/tools/CGraph.h"

#include <set>
#include <vector>
#include <list>

using namespace alf;

// -------------------------------------------------------
// A control dependency graph over the whole program. The nodes are extended
// program nodes, meaning that each node can hold either a statement, a
// annot, a declaration or an initialization.
// -------------------------------------------------------
class 
ALFExtendedProgramControlDependencyGraph : public CGraph<ALFExtendedProgramGraphNode, ALFExtendedProgramGraphEdge>
{
public:
  // To create and delete the graph
  ALFExtendedProgramControlDependencyGraph() {};
  virtual ~ALFExtendedProgramControlDependencyGraph() {};
  
  // To draw the resulting graph
  void Draw(std::ostream & s = std::cout);

};

// -------------------------------------------------------
// A class for building a program control flow graph.
// -------------------------------------------------------
class 
ALFExtendedProgramControlDependencyGraphBuilder
{
public:

  // ---------------------------------
  // To create and delete the builder class. Argument is owned by caller.
  // ---------------------------------
  ALFExtendedProgramControlDependencyGraphBuilder() { };
  virtual ~ALFExtendedProgramControlDependencyGraphBuilder() { };

  // We create an extended program control dependency graph from an extended program flow graph
  ALFExtendedProgramControlDependencyGraph * Build(ALFExtendedProgramControlFlowGraph * epcfg);

protected:

  // Help function which returnsthe control depenency graph as a
  // mapping from node index to the nodes that are control dependant
  // on this node.
  bool CalculateControlDependency(ALFExtendedProgramControlFlowGraph *org_graph, 
				  std::map<unsigned int, std::set<unsigned int> *> *cd,
				  unsigned int *entry_node_id);

  // The graph to be created and returned (not owned by the builder)
  ALFExtendedProgramControlDependencyGraph * _epcdg; 
				      
};

#endif


