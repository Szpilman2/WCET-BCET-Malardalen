#include "alf_slicing/ALFSlicing.h"
 
ALFSlicing::
ALFSlicing(ALFExtendedProgramDependencyGraph * epdg, ALFDefsAndUsesAnalysis * du)
  : _epdg(epdg), _du(du)
{
  // Create mapping from epfg nodes to statements. Used to find the epg nodes to start
  // slicing from.
  for(ALFExtendedProgramDependencyGraph::node_iterator n = epdg->NodesBegin(); n != epdg->NodesEnd(); ++n) {
    alf::AStmt * stmt = NULL;
    alf::AStmt * stmt2 = NULL;

    // Extract statements if any...
    switch((*n)->GetBaseType()) {
    // Statement nodes refer naturally to statements 
    case ALFExtendedProgramGraphNode::STMT: {
      ALFExtendedProgramGraphNodeStmt * stmt_node = dynamic_cast<ALFExtendedProgramGraphNodeStmt *>(*n);
      stmt = stmt_node->GetStmt();
    }
    // Some annot nodes refer to statements
    case ALFExtendedProgramGraphNode::ANNOT: {
      if((*n)->GetType() == ALFExtendedProgramGraphNode::STMT_ENTRY_ANNOT) {
	ALFExtendedProgramGraphNodeStmtEntryAnnot * stmt_entry_annot_node =
	  dynamic_cast<ALFExtendedProgramGraphNodeStmtEntryAnnot *>(*n);
	stmt = stmt_entry_annot_node->GetStmt();
      }
      else if((*n)->GetType() == ALFExtendedProgramGraphNode::STMT_EXIT_ANNOT) {
      	ALFExtendedProgramGraphNodeStmtExitAnnot * stmt_exit_annot_node =
	  dynamic_cast<ALFExtendedProgramGraphNodeStmtExitAnnot *>(*n);
	stmt = stmt_exit_annot_node->GetStmt();
      }
    }
    // Some assign nodes refer to statements
    case ALFExtendedProgramGraphNode::ASSIGN: {
      if((*n)->GetType() == ALFExtendedProgramGraphNode::CALL_ENTER_ASSIGN) {
	ALFExtendedProgramGraphNodeCallEnterAssign * call_enter_assign_node =
	  dynamic_cast<ALFExtendedProgramGraphNodeCallEnterAssign *>(*n);
	stmt = call_enter_assign_node->GetCallStmt();
      }
      else if((*n)->GetType() == ALFExtendedProgramGraphNode::RETURN_RESULT_ASSIGN) {
	ALFExtendedProgramGraphNodeReturnResultAssign * return_result_assign_node =
	  dynamic_cast<ALFExtendedProgramGraphNodeReturnResultAssign *>(*n);
	stmt = return_result_assign_node->GetReturnStmt();
	stmt2 = return_result_assign_node->GetResultStmt();
      }
      else if((*n)->GetType() == ALFExtendedProgramGraphNode::ROOT_FUNC_RETURN_ASSIGN) {
	ALFExtendedProgramGraphNodeRootFuncReturnAssign * root_func_return_assign_node =
	  dynamic_cast<ALFExtendedProgramGraphNodeRootFuncReturnAssign *>(*n);
	stmt = root_func_return_assign_node->GetReturnStmt();
      }
    }
    default: {
      // Do nothing
    }
    }

    // Add resulting stmt to node connection
    if(stmt) {
      if(_stmt_to_nodes.find(stmt) == _stmt_to_nodes.end())
	_stmt_to_nodes[stmt] = new std::set<ALFExtendedProgramGraphNode *>; 
      _stmt_to_nodes[stmt]->insert(*n);
    }
    if(stmt2) {
      if(_stmt_to_nodes.find(stmt2) == _stmt_to_nodes.end())
	_stmt_to_nodes[stmt2] = new std::set<ALFExtendedProgramGraphNode *>; 
      _stmt_to_nodes[stmt2]->insert(*n);
    }
  }
}

ALFSlicing::
~ALFSlicing()
{
  // Delete created vectors
  for(std::map<alf::AStmt *, std::set<ALFExtendedProgramGraphNode *> *>::iterator s2v = _stmt_to_nodes.begin();
      s2v != _stmt_to_nodes.end(); ++s2v) {
    delete (*s2v).second;
  }
}

// -------------------------------------------------------
// To get the slice of a certain (set of) statement(s) 
// -------------------------------------------------------
void
ALFSlicing::
GetSliceOfStmt(alf::AStmt * stmt, SLICE_DIRECTION dir,
	       std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
	       std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
	       std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Create a temporary set and insert stmt in this
  std::set<alf::AStmt *> start_stmts;
  start_stmts.insert(stmt);
  // Call the real function
  GetSliceOfStmts(&start_stmts, dir, stmts, annots, allocs, inits, vars, draw_slice);
}

void 
ALFSlicing::
GetSliceOfStmts(std::set<alf::AStmt *> * start_stmts, SLICE_DIRECTION dir, std::set<unsigned int> * vars)
{
  // Create temporary sets
  std::set<AStmt *> stmts;
  std::set<CALFAbsAnnot *> annots;
  std::set<alf::CAllocTuple *> allocs; 
  std::set<alf::CInitTuple *> inits;
  // Call the real function
  GetSliceOfStmts(start_stmts, dir, &stmts, &annots, &allocs, &inits, vars);
} 

void
ALFSlicing::
GetSliceOfStmts(std::set<alf::AStmt *> * start_stmts, SLICE_DIRECTION dir,
		std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
		std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
		std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Get the start set of epfg nodes from the statements
  std::set<ALFExtendedProgramGraphNode *> epg_start_nodes;
  GetEPGNodesFromStmts(start_stmts, &epg_start_nodes);

  // Derive the slice
  std::set<ALFExtendedProgramGraphNode *> nodes_in_slice;
  std::set<ALFExtendedProgramGraphEdge *> edges_in_slice;
  GetSlice(&epg_start_nodes, &nodes_in_slice, &edges_in_slice, dir);

  // Draw the slice if required
  if(draw_slice) _epdg->DrawSlice((*draw_slice), &nodes_in_slice, &edges_in_slice);
  
  // Partition the slice into argument sets to be returned
  PartitionNodesOnTypes(&nodes_in_slice, stmts, annots, allocs, inits, vars);  
}


// -------------------------------------------------------
// To get the slice of the conditional conditions in a CG
// -------------------------------------------------------
void
ALFSlicing::
GetConditionalNodesOfCGSlice(CCallGraph * cg, SLICE_DIRECTION dir, std::set<unsigned int> * vars)
{
  // Create temporary sets
  std::set<AStmt *> stmts;
  std::set<CALFAbsAnnot *> annots;
  std::set<alf::CAllocTuple *> allocs; 
  std::set<alf::CInitTuple *> inits;
  // Call the real function
  GetConditionalNodesOfCGSlice(cg, dir, &stmts, &annots, &allocs, &inits, vars);
}

void
ALFSlicing::
GetConditionalNodesOfCGSlice(CCallGraph * cg, SLICE_DIRECTION dir,
			     std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			     std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			     std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Extract the start CG nodes
  std::list<CFlowGraphNode *> cfg_start_nodes;
  GetConditionalNodesOfCG(cg, &cfg_start_nodes);
  // Extract the corresponding EPG nodes
  std::set<ALFExtendedProgramGraphNode *> epg_start_nodes;
  GetEPGNodesFromCFGNodes(&cfg_start_nodes, &epg_start_nodes);
  // Derive the slice
  std::set<ALFExtendedProgramGraphNode *> nodes_in_slice;
  std::set<ALFExtendedProgramGraphEdge *> edges_in_slice;
  GetSlice(&epg_start_nodes, &nodes_in_slice, &edges_in_slice, dir);
  // Draw the slice if required
  if(draw_slice) _epdg->DrawSlice((*draw_slice), &nodes_in_slice, &edges_in_slice);
  // Partition the slice into argument sets to be returned
  PartitionNodesOnTypes(&nodes_in_slice, stmts, annots, allocs, inits, vars);  
}

// -------------------------------------------------------
// To get the slice of the conditional conditions in a set of CFGs
// -------------------------------------------------------
void
ALFSlicing::
GetConditionalNodesOfCFGsSlice(std::set<CFlowGraph *> * cfgs, SLICE_DIRECTION dir, std::set<unsigned int> * vars)
{
  // Create temporary sets
  std::set<AStmt *> stmts;
  std::set<CALFAbsAnnot *> annots;
  std::set<alf::CAllocTuple *> allocs; 
  std::set<alf::CInitTuple *> inits;
  // Call the real function
  GetConditionalNodesOfCFGsSlice(cfgs, dir, &stmts, &annots, &allocs, &inits, vars);
}

void
ALFSlicing::
GetConditionalNodesOfCFGsSlice(std::set<CFlowGraph *> * cfgs, SLICE_DIRECTION dir,
			   std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			   std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			   std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Extract the start CFG nodes
  std::list<CFlowGraphNode *> cfg_start_nodes;
  GetConditionalNodesOfCFGs(cfgs, &cfg_start_nodes);
  // Extract the corresponding EPG nodes
  std::set<ALFExtendedProgramGraphNode *> epg_start_nodes;
  GetEPGNodesFromCFGNodes(&cfg_start_nodes, &epg_start_nodes);
  // Derive the slice
  std::set<ALFExtendedProgramGraphNode *> nodes_in_slice;
  std::set<ALFExtendedProgramGraphEdge *> edges_in_slice;
  GetSlice(&epg_start_nodes, &nodes_in_slice, &edges_in_slice, dir);
  // Draw the slice if required
  if(draw_slice) _epdg->DrawSlice((*draw_slice), &nodes_in_slice, &edges_in_slice);
  // Partition the slice into argument sets to be returned
  PartitionNodesOnTypes(&nodes_in_slice, stmts, annots, allocs, inits, vars);  
}

// -------------------------------------------------------
// To get the slice of the conditional conditions in a CFG
// -------------------------------------------------------
void
ALFSlicing::
GetConditionalNodesOfCFGSlice(CFlowGraph * cfg, SLICE_DIRECTION dir, std::set<unsigned int> * vars)
{
  // Create temporary sets
  std::set<AStmt *> stmts;
  std::set<CALFAbsAnnot *> annots;
  std::set<alf::CAllocTuple *> allocs; 
  std::set<alf::CInitTuple *> inits;
  // Call the real function
  GetConditionalNodesOfCFGSlice(cfg, dir, &stmts, &annots, &allocs, &inits, vars);
}

void
ALFSlicing::
GetConditionalNodesOfCFGSlice(CFlowGraph * cfg, SLICE_DIRECTION dir,
			     std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			     std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			     std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Extract the start CFG nodes
  std::list<CFlowGraphNode *> cfg_start_nodes;
  GetConditionalNodesOfCFG(cfg, &cfg_start_nodes);
  // Extract the corresponding EPG nodes
  std::set<ALFExtendedProgramGraphNode *> epg_start_nodes;
  GetEPGNodesFromCFGNodes(&cfg_start_nodes, &epg_start_nodes);
  // Derive the slice
  std::set<ALFExtendedProgramGraphNode *> nodes_in_slice;
  std::set<ALFExtendedProgramGraphEdge *> edges_in_slice;
  GetSlice(&epg_start_nodes, &nodes_in_slice, &edges_in_slice, dir);
  // Draw the slice if required
  if(draw_slice) _epdg->DrawSlice((*draw_slice), &nodes_in_slice, &edges_in_slice);
  // Partition the slice into argument sets to be returned
  PartitionNodesOnTypes(&nodes_in_slice, stmts, annots, allocs, inits, vars);  
}

// -------------------------------------------------------
// To get the slice of the conditional conditions in a scope
// -------------------------------------------------------
void
ALFSlicing::
GetConditionalNodesOfScopeSlice(CScope * scope, SLICE_DIRECTION dir, std::set<unsigned int> * vars)
{
  // Create temporary sets
  std::set<AStmt *> stmts;
  std::set<CALFAbsAnnot *> annots;
  std::set<alf::CAllocTuple *> allocs; 
  std::set<alf::CInitTuple *> inits;
  // Call the real function
  GetConditionalNodesOfScopeSlice(scope, dir, &stmts, &annots, &allocs, &inits, vars);
}

void
ALFSlicing::
GetConditionalNodesOfScopeSlice(CScope * scope, SLICE_DIRECTION dir,
			     std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			     std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			     std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Extract the start CFG nodes
  std::list<CFlowGraphNode *> cfg_start_nodes;
  GetConditionalNodesOfScope(scope, &cfg_start_nodes);
  // Extract the corresponding EPG nodes
  std::set<ALFExtendedProgramGraphNode *> epg_start_nodes;
  GetEPGNodesFromCFGNodes(&cfg_start_nodes, &epg_start_nodes);
  // Derive the slice
  std::set<ALFExtendedProgramGraphNode *> nodes_in_slice;
  std::set<ALFExtendedProgramGraphEdge *> edges_in_slice;
  GetSlice(&epg_start_nodes, &nodes_in_slice, &edges_in_slice, dir);
  // Draw the slice if required
  if(draw_slice) _epdg->DrawSlice((*draw_slice), &nodes_in_slice, &edges_in_slice);
  // Partition the slice into argument sets to be returned
  PartitionNodesOnTypes(&nodes_in_slice, stmts, annots, allocs, inits, vars);  
}

// -------------------------------------------------------
// To get the slice of the conditional conditions in a component
// -------------------------------------------------------
void
ALFSlicing::
GetConditionalNodesOfComponentSlice(CComponent<CFlowGraphNode> * component, SLICE_DIRECTION dir, std::set<unsigned int> * vars)
{
  // Create temporary sets
  std::set<AStmt *> stmts;
  std::set<CALFAbsAnnot *> annots;
  std::set<alf::CAllocTuple *> allocs; 
  std::set<alf::CInitTuple *> inits;
  // Call the real function
  GetConditionalNodesOfComponentSlice(component, dir, &stmts, &annots, &allocs, &inits, vars);
}

void 
ALFSlicing::
GetConditionalNodesOfComponentSlice(CComponent<CFlowGraphNode> * component, SLICE_DIRECTION dir,
				    std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
				    std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
				    std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Extract the start CFG nodes
  std::list<CFlowGraphNode *> cfg_start_nodes;
  GetConditionalNodesOfComponent(component, &cfg_start_nodes);
  // Extract the corresponding EPG nodes
  std::set<ALFExtendedProgramGraphNode *> epg_start_nodes;
  GetEPGNodesFromCFGNodes(&cfg_start_nodes, &epg_start_nodes);
  // Derive the slice
  std::set<ALFExtendedProgramGraphNode *> nodes_in_slice;
  std::set<ALFExtendedProgramGraphEdge *> edges_in_slice;
  GetSlice(&epg_start_nodes, &nodes_in_slice, &edges_in_slice, dir);
  // Draw the slice if required
  if(draw_slice) _epdg->DrawSlice((*draw_slice), &nodes_in_slice, &edges_in_slice);
  // Partition the slice into argument sets to be returned
  PartitionNodesOnTypes(&nodes_in_slice, stmts, annots, allocs, inits, vars);  
}

// -------------------------------------------------------
// To get the slice of the loop exit conditions in a CG
// -------------------------------------------------------
void
ALFSlicing::
GetLoopExitNodesOfCGSlice(CCallGraph * cg, SLICE_DIRECTION dir, std::set<unsigned int> * vars)
{
  // Create temporary sets
  std::set<AStmt *> stmts;
  std::set<CALFAbsAnnot *> annots;
  std::set<alf::CAllocTuple *> allocs; 
  std::set<alf::CInitTuple *> inits;
  // Call the real function
  GetLoopExitNodesOfCGSlice(cg, dir, &stmts, &annots, &allocs, &inits, vars);
}

void
ALFSlicing::
GetLoopExitNodesOfCGSlice(CCallGraph * cg, SLICE_DIRECTION dir,
			  std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			  std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			  std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Extract the start CG nodes
  std::list<CFlowGraphNode *> cfg_start_nodes;
  GetLoopExitNodesOfCG(cg, &cfg_start_nodes);
  // Extract the corresponding EPG nodes
  std::set<ALFExtendedProgramGraphNode *> epg_start_nodes;
  GetEPGNodesFromCFGNodes(&cfg_start_nodes, &epg_start_nodes);
  // Derive the slice
  std::set<ALFExtendedProgramGraphNode *> nodes_in_slice;
  std::set<ALFExtendedProgramGraphEdge *> edges_in_slice;
  GetSlice(&epg_start_nodes, &nodes_in_slice, &edges_in_slice, dir);
  // Draw the slice if required
  if(draw_slice) _epdg->DrawSlice((*draw_slice), &nodes_in_slice, &edges_in_slice);
  // Partition the slice into argument sets to be returned
  PartitionNodesOnTypes(&nodes_in_slice, stmts, annots, allocs, inits, vars);  
}

// -------------------------------------------------------
// To get the slice of the loop exit conditions in a set of CFGs
// -------------------------------------------------------
void
ALFSlicing::
GetLoopExitNodesOfCFGsSlice(std::set<CFlowGraph *> * cfgs, SLICE_DIRECTION dir, std::set<unsigned int> * vars)
{
  // Create temporary sets
  std::set<AStmt *> stmts;
  std::set<CALFAbsAnnot *> annots;
  std::set<alf::CAllocTuple *> allocs; 
  std::set<alf::CInitTuple *> inits;
  // Call the real function
  GetLoopExitNodesOfCFGsSlice(cfgs, dir, &stmts, &annots, &allocs, &inits, vars);
}

void
ALFSlicing::
GetLoopExitNodesOfCFGsSlice(std::set<CFlowGraph *> * cfgs, SLICE_DIRECTION dir,
			   std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			   std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			   std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Extract the start CFG nodes
  std::list<CFlowGraphNode *> cfg_start_nodes;
  GetLoopExitNodesOfCFGs(cfgs, &cfg_start_nodes);
  // Extract the corresponding EPG nodes
  std::set<ALFExtendedProgramGraphNode *> epg_start_nodes;
  GetEPGNodesFromCFGNodes(&cfg_start_nodes, &epg_start_nodes);
  // Derive the slice
  std::set<ALFExtendedProgramGraphNode *> nodes_in_slice;
  std::set<ALFExtendedProgramGraphEdge *> edges_in_slice;
  GetSlice(&epg_start_nodes, &nodes_in_slice, &edges_in_slice, dir);
  // Draw the slice if required
  if(draw_slice) _epdg->DrawSlice((*draw_slice), &nodes_in_slice, &edges_in_slice);
  // Partition the slice into argument sets to be returned
  PartitionNodesOnTypes(&nodes_in_slice, stmts, annots, allocs, inits, vars);  
}

// -------------------------------------------------------
// To get the slice of the loop exit conditions in a CFG
// -------------------------------------------------------
void
ALFSlicing::
GetLoopExitNodesOfCFGSlice(CFlowGraph * cfg, SLICE_DIRECTION dir, std::set<unsigned int> * vars)
{
  // Create temporary sets
  std::set<AStmt *> stmts;
  std::set<CALFAbsAnnot *> annots;
  std::set<alf::CAllocTuple *> allocs; 
  std::set<alf::CInitTuple *> inits;
  // Call the real function
  GetLoopExitNodesOfCFGSlice(cfg, dir, &stmts, &annots, &allocs, &inits, vars);
}

void
ALFSlicing::
GetLoopExitNodesOfCFGSlice(CFlowGraph * cfg, SLICE_DIRECTION dir,
			     std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			     std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			     std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Extract the start CFG nodes
  std::list<CFlowGraphNode *> cfg_start_nodes;
  GetLoopExitNodesOfCFG(cfg, &cfg_start_nodes);
  // Extract the corresponding EPG nodes
  std::set<ALFExtendedProgramGraphNode *> epg_start_nodes;
  GetEPGNodesFromCFGNodes(&cfg_start_nodes, &epg_start_nodes);
  // Derive the slice
  std::set<ALFExtendedProgramGraphNode *> nodes_in_slice;
  std::set<ALFExtendedProgramGraphEdge *> edges_in_slice;
  GetSlice(&epg_start_nodes, &nodes_in_slice, &edges_in_slice, dir);
  // Draw the slice if required
  if(draw_slice) _epdg->DrawSlice((*draw_slice), &nodes_in_slice, &edges_in_slice);
  // Partition the slice into argument sets to be returned
  PartitionNodesOnTypes(&nodes_in_slice, stmts, annots, allocs, inits, vars);  
}

// -------------------------------------------------------
// To get the slice of the loop exit conditions in a scope
// -------------------------------------------------------
void
ALFSlicing::
GetLoopExitNodesOfScopeSlice(CScope * scope, SLICE_DIRECTION dir, std::set<unsigned int> * vars)
{
  // Create temporary sets
  std::set<AStmt *> stmts;
  std::set<CALFAbsAnnot *> annots;
  std::set<alf::CAllocTuple *> allocs; 
  std::set<alf::CInitTuple *> inits;
  // Call the real function
  GetLoopExitNodesOfScopeSlice(scope, dir, &stmts, &annots, &allocs, &inits, vars);
}

void
ALFSlicing::
GetLoopExitNodesOfScopeSlice(CScope * scope, SLICE_DIRECTION dir,
			     std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			     std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			     std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Extract the start CFG nodes
  std::list<CFlowGraphNode *> cfg_start_nodes;
  GetLoopExitNodesOfScope(scope, &cfg_start_nodes);
  // Extract the corresponding EPG nodes
  std::set<ALFExtendedProgramGraphNode *> epg_start_nodes;
  GetEPGNodesFromCFGNodes(&cfg_start_nodes, &epg_start_nodes);
  // Derive the slice
  std::set<ALFExtendedProgramGraphNode *> nodes_in_slice;
  std::set<ALFExtendedProgramGraphEdge *> edges_in_slice;
  GetSlice(&epg_start_nodes, &nodes_in_slice, &edges_in_slice, dir);
  // Draw the slice if required
  if(draw_slice) _epdg->DrawSlice((*draw_slice), &nodes_in_slice, &edges_in_slice);
  // Partition the slice into argument sets to be returned
  PartitionNodesOnTypes(&nodes_in_slice, stmts, annots, allocs, inits, vars);  
}



// -------------------------------------------------------
// To get the slice of the loop exit conditions in a component
// -------------------------------------------------------
void
ALFSlicing::
GetLoopExitNodesOfComponentSlice(CComponent<CFlowGraphNode> * component, SLICE_DIRECTION dir, std::set<unsigned int> * vars)
{
  // Create temporary sets
  std::set<AStmt *> stmts;
  std::set<CALFAbsAnnot *> annots;
  std::set<alf::CAllocTuple *> allocs; 
  std::set<alf::CInitTuple *> inits;
  // Call the real function
  GetLoopExitNodesOfComponentSlice(component, dir, &stmts, &annots, &allocs, &inits, vars);
}

void 
ALFSlicing::
GetLoopExitNodesOfComponentSlice(CComponent<CFlowGraphNode> * component, SLICE_DIRECTION dir,
				 std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
				 std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
				 std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Extract the start CFG nodes
  std::list<CFlowGraphNode *> cfg_start_nodes;
  GetLoopExitNodesOfComponent(component, &cfg_start_nodes);

  // Extract the corresponding EPG nodes
  std::set<ALFExtendedProgramGraphNode *> epg_start_nodes;
  GetEPGNodesFromCFGNodes(&cfg_start_nodes, &epg_start_nodes);

  // Derive the slice
  std::set<ALFExtendedProgramGraphNode *> nodes_in_slice;
  std::set<ALFExtendedProgramGraphEdge *> edges_in_slice;
  GetSlice(&epg_start_nodes, &nodes_in_slice, &edges_in_slice, dir);

  // Draw the slice if required
  if(draw_slice) _epdg->DrawSlice((*draw_slice), &nodes_in_slice, &edges_in_slice);
  // Partition the slice into argument sets to be returned
  PartitionNodesOnTypes(&nodes_in_slice, stmts, annots, allocs, inits, vars);  
}

// -------------------------------------------------------
// To get the code parts that may be affected by a given var
// -------------------------------------------------------
void
ALFSlicing::
GetAffectedByVarSlice(unsigned int v, std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
		      std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
		      std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Insert the variable in a temporary set and call the real function
  std::set<unsigned int> vs;
  vs.insert(v);
  GetAffectedByVarsSlice(&vs, stmts, annots, allocs, inits, vars, draw_slice);
}
  
void
ALFSlicing::
GetAffectedByVarsSlice(std::set<unsigned int> * vs, std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
		       std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
		       std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // A set holding the start nodes for the slicing
  std::set<ALFExtendedProgramGraphNode *> epg_start_nodes;

  // Get the EPG nodes which contain statements which may use the var
  GetEPGNodesWhichMayUseVars(vs, &epg_start_nodes);

  // Derive the statements and vars that may be affacted by these nodes by a forward slice
  std::set<ALFExtendedProgramGraphNode *> nodes_in_slice;
  std::set<ALFExtendedProgramGraphEdge *> edges_in_slice;
  GetSlice(&epg_start_nodes, &nodes_in_slice, &edges_in_slice, FORWARD);

  // Draw the slice if required
  if(draw_slice) _epdg->DrawSlice((*draw_slice), &nodes_in_slice, &edges_in_slice);
  // Partition the slice into argument sets to be returned
  PartitionNodesOnTypes(&nodes_in_slice, stmts, annots, allocs, inits, vars);  
}

// -------------------------------------------------------
// To get the code parts that may affect a given var
// -------------------------------------------------------
void
ALFSlicing::
GetAffectingVarSlice(unsigned int v, std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			  std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			  std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Insert the variable in a temporary set and call the real function
  std::set<unsigned int> vs;
  vs.insert(v);
  GetAffectingVarsSlice(&vs, stmts, annots, allocs, inits, vars, draw_slice);
}

void
ALFSlicing::
GetAffectingVarsSlice(std::set<unsigned int> * vs, std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
		      std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
		      std::set<unsigned int> * vars, std::ostream * draw_slice)
{

  // A set holding the start nodes for the slicing
  std::set<ALFExtendedProgramGraphNode *> epg_start_nodes;

  // Get the EPG nodes which contain statements which may define a var in vars
  GetEPGNodesWhichMayDefineVars(vs, &epg_start_nodes);

  // Derive the slice
  std::set<ALFExtendedProgramGraphNode *> nodes_in_slice;
  std::set<ALFExtendedProgramGraphEdge *> edges_in_slice;
  GetSlice(&epg_start_nodes, &nodes_in_slice, &edges_in_slice, BACKWARD);

  // Draw the slice if required
  if(draw_slice) _epdg->DrawSlice((*draw_slice), &nodes_in_slice, &edges_in_slice);
  // Partition the slice into argument sets to be returned
  PartitionNodesOnTypes(&nodes_in_slice, stmts, annots, allocs, inits, vars);  
}

// -------------------------------------------------------
// To get the code parts that may affect the result value
// -------------------------------------------------------
void
ALFSlicing::
GetProgramReturnValueSlice(CCallGraph * cg, std::set<AStmt *> * stmts, std::set<CALFAbsAnnot *> * annots,
			   std::set<alf::CAllocTuple *> * allocs, std::set<alf::CInitTuple *> * inits,
			   std::set<unsigned int> * vars, std::ostream * draw_slice)
{
  // Extract the root node in the CG
  CCallGraphNode * cg_root_node = cg->Root();
  // Get the corresponding cfg
  CFlowGraph * cfg = cg_root_node->FlowGraph();
  // Get the cfg nodes that are return statements in the cfg (maybe we
  // should check that all exit nodes also are return nodes?)
  std::list<CFlowGraphNode *> cfg_return_nodes;
  cfg->ExitNodes(&cfg_return_nodes);
  // Extract the corresponding EPG nodes
  std::set<ALFExtendedProgramGraphNode *> epg_start_nodes;
  GetEPGNodesFromCFGNodes(&cfg_return_nodes, &epg_start_nodes);
  // Derive the slice
  std::set<ALFExtendedProgramGraphNode *> nodes_in_slice;
  std::set<ALFExtendedProgramGraphEdge *> edges_in_slice;
  GetSlice(&epg_start_nodes, &nodes_in_slice, &edges_in_slice, BACKWARD);
  // Draw the slice if required
  if(draw_slice) _epdg->DrawSlice((*draw_slice), &nodes_in_slice, &edges_in_slice);
  // Partition the slice into argument sets to be returned
  PartitionNodesOnTypes(&nodes_in_slice, stmts, annots, allocs, inits, vars);  
}


// =======================================================
// Help functions
// =======================================================

// -------------------------------------------------------
// Help functions for extracting epg nodes from cfg nodes
// -------------------------------------------------------
void
ALFSlicing::
GetEPGNodesFromCFGNodes(std::list<CFlowGraphNode *> * cfg_nodes, 
			std::set<ALFExtendedProgramGraphNode *> * epg_nodes)
{
  for(std::list<CFlowGraphNode *>::iterator cfg_node = cfg_nodes->begin();
      cfg_node != cfg_nodes->end(); ++cfg_node) {
    // Use the statement of the cfg node as a mapping
    alf::AStmt * stmt = dynamic_cast<alf::AStmt *>((*cfg_node)->Stmt());
    // Get the epg nodes from the statement
    GetEPGNodesFromStmt(stmt, epg_nodes);
  }
}

// -------------------------------------------------------
// Help functions for extracting epg nodes from stmts
// -------------------------------------------------------
void
ALFSlicing::
GetEPGNodesFromStmts(std::set<alf::AStmt *> * start_stmts, 
		     std::set<ALFExtendedProgramGraphNode *> * epg_nodes)
{
  // Get the EPG nodes of the statements
  for(std::set<alf::AStmt *>::iterator stmt = start_stmts->begin(); stmt != start_stmts->end(); ++stmt) {
    // Get the epg nodes from the statement
    GetEPGNodesFromStmt(*stmt, epg_nodes);
  }
}

void
ALFSlicing::
GetEPGNodesFromStmt(alf::AStmt * stmt, std::set<ALFExtendedProgramGraphNode *> * epg_nodes)
{
  std::set<ALFExtendedProgramGraphNode *> * epg_nodes_of_stmt = _stmt_to_nodes[stmt];
  assert(epg_nodes_of_stmt);
  for(std::set<ALFExtendedProgramGraphNode *>::iterator epg_node_of_stmt = epg_nodes_of_stmt->begin();
      epg_node_of_stmt != epg_nodes_of_stmt->end(); ++epg_node_of_stmt) {
    epg_nodes->insert(*epg_node_of_stmt);
  }
}

// -------------------------------------------------------
// Help functions for extracting epg nodes which may define given vars 
// -------------------------------------------------------
void
ALFSlicing::
GetEPGNodesWhichMayDefineVars(std::set<unsigned int> * vars, 
			     std::set<ALFExtendedProgramGraphNode *> * epg_start_nodes)
{
  // Loop through all nodes in epdg and check if it defines the any of
  // the variables in the vs set  
  for(ALFExtendedProgramDependencyGraph::node_iterator n = _epdg->NodesBegin();
      n != _epdg->NodesEnd(); ++n) {

    // Partition the node based on the content and get their defs from
    // the DU analysis
    std::set<unsigned int> defs;
    _du->GetDefsOfEPGNode(*n, &defs);

    // Check if there are any var in the intersection of the two sets
    bool has_var = false;
    for(std::set<unsigned int>::iterator d = defs.begin(); d != defs.end(); ++d) {
      if(vars->find(*d) != vars->end()) {
	has_var = true;
	break;
      }
    }

    // If there was a common var, we should include the epg node in
    // the starting set
    if(has_var) {
      epg_start_nodes->insert(*n);
    }
  }
}
 
// -------------------------------------------------------
// Help functions for extracting epg nodes which may define given vars 
// -------------------------------------------------------
void
ALFSlicing::
GetEPGNodesWhichMayUseVars(std::set<unsigned int> * vars, 
			   std::set<ALFExtendedProgramGraphNode *> * epg_start_nodes)
{
  // Loop through all nodes in epdg and check if it defines the any of
  // the variables in the vs set  
  for(ALFExtendedProgramDependencyGraph::node_iterator n = _epdg->NodesBegin();
      n != _epdg->NodesEnd(); ++n) {

    // Partition the node based on the content and get their uses from
    // the DU analysis
    std::set<unsigned int> uses;
    _du->GetUsesOfEPGNode(*n, &uses);

    // Check if there are any var in the intersection of the two sets
    bool has_var = false;
    for(std::set<unsigned int>::iterator u = uses.begin(); u != uses.end(); ++u) {
      if(vars->find(*u) != vars->end()) {
	has_var = true;
	break;
      }
    }

    // If there was a common var, we should include the ewpg node in
    // the starting set
    if(has_var) {
      epg_start_nodes->insert(*n);
    }
  }
}


// -------------------------------------------------------
// Help function for getting the cfg nodes that corresponds to loop
// exit nodes in all cfgs in a call graph
// -------------------------------------------------------
void
ALFSlicing::
GetConditionalNodesOfCG(CCallGraph * cg, std::list<CFlowGraphNode *> * cond_nodes)
{
  // Loop through all cfg nodes in cg
  for(CCallGraph::node_iterator cg_node = cg->NodesBegin(); cg_node != cg->NodesEnd(); ++cg_node) {
    // Get the corresponding flow graph
    CFlowGraph * cfg = (*cg_node)->FlowGraph();
    // Get the conditional nodes of the CFG
    GetConditionalNodesOfCFG(cfg, cond_nodes);
  }
}

// -------------------------------------------------------
// Help function for getting the cfg nodes that corresponds to loop
// exit nodes in a set of cfgs
// -------------------------------------------------------
void
ALFSlicing::
GetConditionalNodesOfCFGs(std::set<CFlowGraph *> * cfgs, std::list<CFlowGraphNode *> * cond_nodes)
{
  // Loop through all cfg nodes
  for(std::set<CFlowGraph *>::iterator cfg = cfgs->begin(); cfg != cfgs->end(); ++cfg) {
    // Get the conditional nodes of the CFG
    GetConditionalNodesOfCFG(*cfg, cond_nodes);
  }
}
   
// -------------------------------------------------------
// Help function for getting getting the conditional cfg 
// nodes in a cfg
// -------------------------------------------------------
void
ALFSlicing::
GetConditionalNodesOfCFG(CFlowGraph * cfg, std::list<CFlowGraphNode *> * cond_nodes)
{
  // Loop through all cfg nodes and add those nodes that holds conditional statements
  for(CFlowGraph::node_iterator n = cfg->NodesBegin(); n != cfg->NodesEnd(); ++n) {
    const alf::AStmt * stmt = dynamic_cast<const AStmt *>((*n)->Stmt());
    if(stmt->Type() == CGenericStmt::GS_COND) {
      cond_nodes->push_back(*n);
    }
  }
}

// -------------------------------------------------------
// Help function for getting getting the conditional cfg 
// nodes in a scope
// -------------------------------------------------------
void
ALFSlicing::
GetConditionalNodesOfScope(CScope * scope, std::list<CFlowGraphNode *> * cond_nodes)
{
  // Get the corresponding component and get its conditional nodes
  CComponent<CFlowGraphNode> * comp = scope->Component();
  GetConditionalNodesOfComponent(comp, cond_nodes);
}

// -------------------------------------------------------
// Help function for extracting all conditional cfg nodes in a component
// -------------------------------------------------------
void 
ALFSlicing::
GetConditionalNodesOfComponent(CComponent<CFlowGraphNode> *component, 
			       std::list<CFlowGraphNode *> * cond_nodes)
{
  // Loop through all cfg nodes in the component
  for(CComponent<CFlowGraphNode>::subnode_iterator n = component->SubNodeBegin();
      n != component->SubNodeEnd(); ++n) {
    const alf::AStmt * stmt = dynamic_cast<const AStmt *>((*n)->Stmt());
    if(stmt->Type() == CGenericStmt::GS_COND) {
      cond_nodes->push_back(*n);
    }
  }
}

// -------------------------------------------------------
// Help function for getting the cfg nodes that corresponds to loop
// exit nodes in all cfgs in a call graph
// -------------------------------------------------------
void
ALFSlicing::
GetLoopExitNodesOfCG(CCallGraph * cg, std::list<CFlowGraphNode *> * loop_exit_nodes)
{
  // Loop through all cfg nodes
  for(CCallGraph::node_iterator cg_node = cg->NodesBegin(); cg_node != cg->NodesEnd(); ++cg_node) {
    // Get the corresponding flow graph
    CFlowGraph * cfg = (*cg_node)->FlowGraph();
    // Get the loop exit conditions of the CFG
    GetLoopExitNodesOfCFG(cfg, loop_exit_nodes);
  }
}

// -------------------------------------------------------
// Help function for getting the cfg nodes that corresponds to loop
// exit nodes in a set of cfgs
// -------------------------------------------------------
void
ALFSlicing::
GetLoopExitNodesOfCFGs(std::set<CFlowGraph *> * cfgs, std::list<CFlowGraphNode *> * loop_exit_nodes)
{
  // Loop through all cfg nodes
  for(std::set<CFlowGraph *>::iterator cfg = cfgs->begin(); cfg != cfgs->end(); ++cfg) {
    // Get the loop exit condition nodes of the CFG
    GetLoopExitNodesOfCFG(*cfg, loop_exit_nodes);
  }
}
   
// -------------------------------------------------------
// Help function for getting getting the cfg nodes that corresponds to
// loop exit nodes in a cfg
// -------------------------------------------------------
void
ALFSlicing::
GetLoopExitNodesOfCFG(CFlowGraph * cfg, std::list<CFlowGraphNode *> * loop_exit_nodes)
{
  // Get all looping components in the cfg
  std::list<CComponent<CFlowGraphNode> *> loop_components;
  cfg->GetLoopingComponents(&loop_components);

  // Get all loop exit condition nodes in these loop components
  for(std::list<CComponent<CFlowGraphNode> *>::iterator c = loop_components.begin();
      c != loop_components.end(); ++c) {
    GetLoopExitNodesOfComponent(*c, loop_exit_nodes);
  }
}

// -------------------------------------------------------
// Help function for getting the cfg nodes that corresponds to
// loop exit nodes in a scope
// -------------------------------------------------------
void
ALFSlicing::
GetLoopExitNodesOfScope(CScope * scope, std::list<CFlowGraphNode *> * loop_exit_nodes)
{
  // Get the corresponding component and get its loop exit nodes
  CComponent<CFlowGraphNode> * comp = scope->Component();
  GetLoopExitNodesOfComponent(comp, loop_exit_nodes);
}

// -------------------------------------------------------
// Help function for getting the ecfg nodes that corresponds to loop
// exit nodes in a component
// -------------------------------------------------------
void 
ALFSlicing::
GetLoopExitNodesOfComponent(CComponent<CFlowGraphNode> * component, 
			    std::list<CFlowGraphNode *> * loop_exit_nodes)
{
   // Unpack some data
   CFlowGraphNode *header = component->Head();
   CFlowGraph *cfg = header->FlowGraph();
   const std::list<CFlowGraphNode*> *exit_nodes = cfg->ExitNodesOfComponent(component);

   // Loop through all component exit nodes and extract their
   // corresponding epg node
   for(std::list<CFlowGraphNode*>::const_iterator n = exit_nodes->begin(); 
       n != exit_nodes->end(); ++n) {
     loop_exit_nodes->push_back(*n);
   }
}

// -------------------------------------------------------
// To get the slice forward or backward reachable of a single epg node
// -------------------------------------------------------
void
ALFSlicing::
GetSlice(ALFExtendedProgramGraphNode * start_node, 
	 std::set<ALFExtendedProgramGraphNode *> * nodes_in_slice, 
	 std::set<ALFExtendedProgramGraphEdge *> * edges_in_slice, 
	 SLICE_DIRECTION dir)
{
  if(dir == BACKWARD) {
    _epdg->BackwardReachableNodesAndEdges(start_node, nodes_in_slice, edges_in_slice);
  }
  else {
    _epdg->ForwardReachableNodesAndEdges(start_node, nodes_in_slice, edges_in_slice);
  }
}

// -------------------------------------------------------
// To get the slice forward or backward reachable of a set of epg node
// -------------------------------------------------------
void
ALFSlicing::
GetSlice(std::set<ALFExtendedProgramGraphNode *> * start_nodes, 
	 std::set<ALFExtendedProgramGraphNode *> * nodes_in_slice, 
	 std::set<ALFExtendedProgramGraphEdge *> * edges_in_slice, 
	 SLICE_DIRECTION dir)
{
  if(dir == BACKWARD) {
    _epdg->BackwardReachableNodesAndEdges(start_nodes, nodes_in_slice, edges_in_slice);
  }
  else {
    _epdg->ForwardReachableNodesAndEdges(start_nodes, nodes_in_slice, edges_in_slice);
  }
}

// -------------------------------------------------------
// Partition the nodes depending on the thing they where created from
// -------------------------------------------------------
void
ALFSlicing::
PartitionNodesOnTypes(std::set<ALFExtendedProgramGraphNode *> * pdg_nodes,
		      std::set<AStmt *> * stmts,
		      std::set<CALFAbsAnnot *> * annots,
		      std::set<alf::CAllocTuple *> * allocs,
		      std::set<alf::CInitTuple *> * inits,
		      std::set<unsigned int> * vars)
{
  // We use the def use analysis to derive what variables to keep. We
  // should be able to see this from the allocs, but these are treated
  // as assign statements and might therefore by not included in the
  // final slice... :( Maybe it is enough to only extract the defs
  // instead of both the defs and uses?

  for(std::set<ALFExtendedProgramGraphNode *>::iterator n = pdg_nodes->begin();
      n != pdg_nodes->end(); ++n) {

    // Get the defs and uses of the node
    _du->GetDefsAndUsesOfEPGNode(*n, vars, vars);

    // Partition the node based on the content
    switch ((*n)->GetBaseType()) {
    case ALFExtendedProgramGraphNode::STMT: 
      { 
	ALFExtendedProgramGraphNodeStmt * stmt_node = dynamic_cast<ALFExtendedProgramGraphNodeStmt *>(*n);
	alf::AStmt * stmt = stmt_node->GetStmt();
	stmts->insert(stmt);
	break;
      }
    case ALFExtendedProgramGraphNode::ANNOT: 
      {
	ALFExtendedProgramGraphNodeAnnot * annot_node = dynamic_cast<ALFExtendedProgramGraphNodeAnnot *>(*n);
	CALFAbsAnnot * annot = annot_node->GetAnnot();
	annots->insert(annot);
	break;
      }
    case ALFExtendedProgramGraphNode::ALLOC: 
      {
	ALFExtendedProgramGraphNodeAlloc * alloc_node = dynamic_cast<ALFExtendedProgramGraphNodeAlloc *>(*n);
	alf::CAllocTuple * alloc = alloc_node->GetAlloc();
	allocs->insert(alloc);
	break;
      }  
    case ALFExtendedProgramGraphNode::INIT: 
      {
	ALFExtendedProgramGraphNodeGlobalInit * init_node = dynamic_cast<ALFExtendedProgramGraphNodeGlobalInit *>(*n);
	alf::CInitTuple * init = init_node->GetInit();
	_du->GetDefsAndUsesOfInit(init, vars, vars);
	break;
      }
    case ALFExtendedProgramGraphNode::VIRTUAL:
      {
	// Do nothing, it is a fictious node
	break;
      }
    case ALFExtendedProgramGraphNode::ASSIGN:
      {
	if((*n)->GetType() == ALFExtendedProgramGraphNode::CALL_ENTER_ASSIGN) {
	  ALFExtendedProgramGraphNodeCallEnterAssign * call_enter_assign_node =
	    dynamic_cast<ALFExtendedProgramGraphNodeCallEnterAssign *>(*n);
	  // Add the calling statement to the statements
	  stmts->insert(call_enter_assign_node->GetCallStmt());
	  // Add the func arg allocation to the allocs	  
	  allocs->insert(call_enter_assign_node->GetEnterAlloc());
	}
	else if((*n)->GetType() == ALFExtendedProgramGraphNode::RETURN_RESULT_ASSIGN) {
	  ALFExtendedProgramGraphNodeReturnResultAssign * return_result_assign_node =
	    dynamic_cast<ALFExtendedProgramGraphNodeReturnResultAssign *>(*n);
	  // Add both the calling and the returning statement
	  stmts->insert(return_result_assign_node->GetReturnStmt());
	  stmts->insert(return_result_assign_node->GetResultStmt());
	}
	else if((*n)->GetType() == ALFExtendedProgramGraphNode::ROOT_FUNC_ENTER_ASSIGN) {
	  ALFExtendedProgramGraphNodeRootFuncEnterAssign * root_func_enter_assign_node =
	    dynamic_cast<ALFExtendedProgramGraphNodeRootFuncEnterAssign *>(*n);
	  // Add the func arg allocation to the allocs	  
	  allocs->insert(root_func_enter_assign_node->GetEnterAlloc());
	} 
	else if((*n)->GetType() == ALFExtendedProgramGraphNode::ROOT_FUNC_RETURN_ASSIGN) {
	  ALFExtendedProgramGraphNodeRootFuncReturnAssign * root_func_return_assign_node =
	    dynamic_cast<ALFExtendedProgramGraphNodeRootFuncReturnAssign *>(*n);
	  // Add the returning statement
	  stmts->insert(root_func_return_assign_node->GetReturnStmt());
	}
	break;
      }
    }
  }
}
