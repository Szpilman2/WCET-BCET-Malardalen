#include "alf_slicing/ALFExtendedProgramControlDependencyGraph.h"
#include "alf_slicing/ALFExtendedProgramControlFlowGraph.h"
#include "graphs/tools/CGraph.h"
#include "graphs/tools/CGraph.inl"
#include "graphs/tools/CNode.h"
#include "graphs/tools/CNode.inl"
#include <map>
#include <set>
#include "graphs/tools/Dominance.h" 
#include <iostream>
#include <sstream>
#include <string>

// To draw the created graph
void
ALFExtendedProgramControlDependencyGraph::
Draw(std::ostream & os)
{
  ALFExtendedProgramControlDependencyGraph * epcdg = this;

  os << "digraph PCDG {" << endl;
  os << "label=\"Program Control Dependency Graph (PCDG)\"" << endl; 
  os << "size=\"11.4,7.8\"" << endl;
  os << "rankdir=\"TB\"" << endl;
  os << "center=1" << endl;
  os << "rotate=0" << endl;
  os << "orientation=\"portrait\"" << endl;
  os << "fontsize=5;" << endl;
  os << "nodesep=0.1;" << endl;
  os << "subgraph \"" << "pcdg" << "\" {" << endl;

  // Partition nodes based on the function they belong to
  std::vector<ALFExtendedProgramGraphNode *> nodes;
  for(ALFExtendedProgramControlDependencyGraph::node_iterator n = epcdg->NodesBegin(); n != epcdg->NodesEnd(); ++n){
    nodes.push_back(*n);
  }
  std::vector<ALFExtendedProgramGraphNode *> global_nodes;
  std::map<std::string, std::vector<ALFExtendedProgramGraphNode *> *> func_name_to_nodes;
  ALFExtendedProgramGraphNode::PartitionNodesBasedOnFunctionNameTheyBelongsTo(&nodes, &global_nodes, &func_name_to_nodes);
  
  // Print global nodes
  os << "   /* Global nodes */\n";
  for(std::vector<ALFExtendedProgramGraphNode *>::iterator n = global_nodes.begin();
      n != global_nodes.end(); ++n) {
    os << "   \"" << (*n)->Id() << "\"[label=\"";
    (*n)->Draw(os);
    os << "\",fontsize=5,width=0.01,height=0.01,margin=\"0.01,0.01\"]" << endl; 
  }
  os << endl;

  // Print nodes in clusters
  for(std::map<std::string, std::vector<ALFExtendedProgramGraphNode *> *>::iterator fn2ns = func_name_to_nodes.begin();
      fn2ns != func_name_to_nodes.end(); ++fn2ns) {
    os << "   /* Nodes belonging to function " << (*fn2ns).first << "*/\n";
    os << "   subgraph \"cluster_" << (*fn2ns).first << "\" {" << endl;
    os << "   label=\"" << (*fn2ns).first << "\"" << endl;
    std::vector<ALFExtendedProgramGraphNode *> * nodes = (*fn2ns).second;
    for( std::vector<ALFExtendedProgramGraphNode *>::iterator n = nodes->begin(); n != nodes->end(); ++n) {
      os << "      \"" << (*n)->Id() << "\"[label=\"";
      (*n)->Draw(os);
      os << "\",fontsize=5,width=0.01,height=0.01,margin=\"0.01,0.01\"]" << endl; 
    }
    os << "   }" << endl;
    // Delete temporaries
    delete nodes;
  }

  // Print edges
  for(ALFExtendedProgramControlDependencyGraph::node_iterator n = epcdg->NodesBegin();
      n != epcdg->NodesEnd(); ++n){
    for(ALFExtendedProgramGraphNode::succ_iterator se = (*n)->SuccBegin();
	se != (*n)->SuccEnd(); ++se) {
      ALFExtendedProgramGraphNode * succ = (*se).node;
      os << "   \"" << (*n)->Id() << "\" -> \""; 
      os << succ->Id() << "\""; 
      os << "[style=solid";
      os << ",fontsize=5,margin=\"0.01,0.01\"]" << endl;
    }
  }
  os << "  }" << endl;
  os << "}" << endl;
}

// To create a program control dependency graph
ALFExtendedProgramControlDependencyGraph * 
ALFExtendedProgramControlDependencyGraphBuilder::
Build(ALFExtendedProgramControlFlowGraph * epcfg)
{
  // Calculate control dependency mapping based on epcfg. 
  std::map<unsigned int, std::set<unsigned int> *> cd;
  unsigned int entry_node; 
  bool added_entry_node = CalculateControlDependency(epcfg, &cd, &entry_node);
  assert(!added_entry_node);
  (void)added_entry_node; // to silence warning in Release builds
  
  // Create the graph to be returned
  _epcdg = new ALFExtendedProgramControlDependencyGraph();
  
  // ---------------------------------
  // Add nodes according to epcfg
  // ---------------------------------

  // Create nodes for the resulting data dependency graph based on the epcfg nodes
  for(unsigned int i = 0; i < epcfg->NrOfNodes(); i++) {
    ALFExtendedProgramGraphNode * epcfg_node = epcfg->NodeAt(i);
    assert(epcfg_node);
    // Create node and add it to the new graph
    ALFExtendedProgramGraphNode * epcdg_node = epcfg_node->Copy();
    _epcdg->AddNode(epcdg_node);
    // Make sure that the nodes have the same indexes
    assert(epcdg_node->Id() == epcfg_node->Id());
  }
  
  // ---------------------------------
  // Add edges according to control dependency analysis
  // ---------------------------------
  
  // Use created mapping to add edges inbetween the nodes
  for(std::map<unsigned int, std::set<unsigned int > *>::iterator n2ns = cd.begin(); n2ns != cd.end(); ++n2ns) {
    unsigned int from_node_id = (*n2ns).first;
    std::set<unsigned int> * to_node_ids = (*n2ns).second;
    for(std::set<unsigned int>::iterator to_node_id = to_node_ids->begin();
	to_node_id != to_node_ids->end(); ++to_node_id) {
      ALFExtendedProgramGraphNode * from_node = _epcdg->NodeAt(from_node_id);
      ALFExtendedProgramGraphNode * to_node = _epcdg->NodeAt(*to_node_id);
      _epcdg->AddEdge(from_node, to_node);
    }
  }

  // Return the created graph
  return _epcdg;
}

// We want nodes holding just an id
class _Empty
{
public:
   _Empty *Copy() { return NULL; }
};

class IdNode : public CNode<IdNode, _Empty>
{
public:
  IdNode(void) {};
  IdNode *Copy() { return new IdNode(); }
  virtual ~IdNode(void) {};
};

// When we want to return the control depenency graph as a mapping from node
// index to the nodes that are control dependant on this node.
bool
ALFExtendedProgramControlDependencyGraphBuilder::
CalculateControlDependency(ALFExtendedProgramControlFlowGraph *org_graph, 
			   std::map<unsigned int, std::set<unsigned int> *> *cd,
			   unsigned int *entry_node_id)
{
  // We create a id node graph with nodes only holding node id:s
  CGraph<IdNode, _Empty> id_graph;

  // Loop through all org nodes and create corresponding id nodes.
  unsigned nr_of_nodes = org_graph->NrOfNodes();
  for(unsigned i = 0; i < nr_of_nodes; i++) {
      // Create a new id node
      IdNode * id_node = new IdNode();
      id_graph.AddNode(id_node);
      // Make sure that the newly created node has got the right id
      assert(id_node->Id() == i);
    }

  // To hold entry and exit node.
  IdNode * entry_id_node = NULL; 
  IdNode * exit_id_node = NULL;

  // To hold if new entry and exit nodes has been created
  bool new_entry_id_node_created = false;
  bool new_exit_id_node_created = false;

  // Check if we need to create a new entry id node
  bool unique_entry_node = org_graph->FindRoot();
  if(unique_entry_node) {
    // Org node ok, set corresponding id node as entry
    ALFExtendedProgramGraphNode * entry_node = org_graph->Root();
    entry_id_node = id_graph.NodeAt(entry_node->Id());
  }
  else {
    // Org node not ok,  create new id node
    entry_id_node = new IdNode();
    id_graph.AddNode(entry_id_node);
    new_entry_id_node_created = true;
  }

  // Create new exit node 
  exit_id_node = new IdNode();
  id_graph.AddNode(exit_id_node);
  new_exit_id_node_created = true;

  // Loop through all the nodes again and for each org edge we create
  // an edge in the new id node graph
  for(unsigned i = 0; i < nr_of_nodes; i++) {
    // Get the node in the graph and its id
    ALFExtendedProgramGraphNode * node = org_graph->NodeAt(i);
    assert(node);
    int node_id = node->Id();
    // Get the corresponding node in the graph
    IdNode * id_node = id_graph.NodeAt(node_id);
    // Loop through all successors of the original graph
    for(ALFExtendedProgramGraphNode::succ_iterator succ = node->SuccBegin();
	succ != node->SuccEnd(); succ++) {
      // Get the id of the succ
      assert((*succ).node);
      int succ_id = (*succ).node->Id();
      // Get the corresponding node in the graph
      IdNode * succ_id_node = id_graph.NodeAt(succ_id);
      // Create the edge
      id_graph.AddEdge(id_node, succ_id_node);
    }
  }

  // If needed, add edges from entry id node to org entry nodes 
  if(new_entry_id_node_created) {
    std::list<ALFExtendedProgramGraphNode*> org_entry_nodes;
    org_graph->GetEntryNodes(&org_entry_nodes);
    for(std::list<ALFExtendedProgramGraphNode*>::iterator oen = org_entry_nodes.begin();
	oen != org_entry_nodes.end(); ++oen) {
      // Get node id and the corresponding id node
      int id = (*oen)->Id();
      IdNode * id_node = id_graph.NodeAt(id);
      // Add edge from id_node to start id_node in id graph
      id_graph.AddEdge(entry_id_node, id_node);
    }
  }

  // If needed, add edges from exit id node to id nodes corresponding to org exit nodes 
  if(new_exit_id_node_created) {
    std::list<ALFExtendedProgramGraphNode*> org_exit_nodes;
    org_graph->GetExitNodes(&org_exit_nodes);
    for(std::list<ALFExtendedProgramGraphNode*>::iterator oen = org_exit_nodes.begin();
	oen != org_exit_nodes.end(); ++oen) {
      // Get node id and the corresponding id node
      int id = (*oen)->Id();
      IdNode * id_node = id_graph.NodeAt(id);
      // Add edge from exit id_node to identified id_node 
      id_graph.AddEdge(id_node, exit_id_node);
    }
  }

  // If needed, add edge from start node to exit node
  if(!entry_id_node->IsSucc(exit_id_node)) {
    id_graph.AddEdge(entry_id_node, exit_id_node);
  }    

  // Calculate the control dependency on the new id graph. This returns 
  // a mapping between id_nodes and their control dependant nodes
  std::map<IdNode*, std::set<IdNode*> *> id_cd;
  CDominance<IdNode, _Empty> dominance;
  dominance.CalculateControlDependency2(&id_graph, &id_cd);

  // Go through the derived control dependencies and update argument
  // map accordingly
  for(std::map<IdNode*, std::set<IdNode*> *>::iterator id_n2ns = id_cd.begin();
      id_n2ns != id_cd.end(); ++id_n2ns) {
	
    // Get the mapping between id nodes <and their control dependant id nodes
    IdNode* id_node = (*id_n2ns).first;    
    unsigned id = (*id_n2ns).first->Id();

    // Skip exit node
    if(new_exit_id_node_created && id_node == exit_id_node)
      continue;

    // Create an empty set for the ids
    std::set<unsigned int> * cds = new std::set<unsigned int>;

    std::set<IdNode*> * id_nodes = (*id_n2ns).second;
    for(std::set<IdNode *>::iterator n = id_nodes->begin();
        n != id_nodes->end(); ++n) {
      // Skip the exit node
      if(new_exit_id_node_created && (*n) == exit_id_node)
	continue;
      // Add the id to the resulting set
      cds->insert((*n)->Id());
    }
    
    // Add the created set to the resulting map
    (*cd)[id] = cds;      
  }

  // Delete temporary sets 
  for(std::map<IdNode*, std::set<IdNode*> *>::iterator id_n2ns = id_cd.begin();
      id_n2ns != id_cd.end(); ++id_n2ns) {
    delete (*id_n2ns).second;
  }
  
  // Mapping has been updated, return entry node id and if we created
  // a new entry node or not
  (*entry_node_id) = entry_id_node->Id();
  return new_entry_id_node_created;
}
