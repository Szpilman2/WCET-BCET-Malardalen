#include "alf_slicing/ALFExtendedProgramDataDependencyGraph.h"
#include "rd/ALFReachingDefinitionsAnalysis.h"
 
void
ALFExtendedProgramDataDependencyGraph::
Draw(std::ostream & os)
{
  ALFExtendedProgramDataDependencyGraph * epdg = this;

  os << "digraph PDDG {" << endl;
  os << "label=\"Program Data Dependency Graph (PDDG)\"" << endl; 
  os << "size=\"11.4,7.8\"" << endl;
  os << "rankdir=\"TB\"" << endl;
  os << "center=1" << endl;
  os << "rotate=0" << endl;
  os << "orientation=\"portrait\"" << endl;
  os << "fontsize=5;" << endl;
  os << "nodesep=0.1;" << endl;
  os << "subgraph \"" << "ppdg" << "\" {" << endl;

  // Partition nodes based on the function they belong to
  std::vector<ALFExtendedProgramGraphNode *> nodes;
  for(ALFExtendedProgramDataDependencyGraph::node_iterator n = epdg->NodesBegin(); n != epdg->NodesEnd(); ++n){
    nodes.push_back(*n);
  }
  std::vector<ALFExtendedProgramGraphNode *> global_nodes;
  std::map<std::string, std::vector<ALFExtendedProgramGraphNode *> *> func_name_to_nodes;
  ALFExtendedProgramGraphNode::PartitionNodesBasedOnFunctionNameTheyBelongsTo(&nodes, &global_nodes, &func_name_to_nodes);
  
  // Print global nodes
  os << "   /* Global nodes */\n";
  for(std::vector<ALFExtendedProgramGraphNode *>::iterator n = global_nodes.begin();
      n != global_nodes.end(); ++n) {
    os << "   \"" << (*n)->Id() << "\"[label=\"";
    (*n)->Draw(os);
    os << "\",fontsize=5,width=0.01,height=0.01,margin=\"0.01,0.01\"]" << endl; 
  }
  os << endl;

  // Print nodes in clusters
  for(std::map<std::string, std::vector<ALFExtendedProgramGraphNode *> *>::iterator fn2ns = func_name_to_nodes.begin();
      fn2ns != func_name_to_nodes.end(); ++fn2ns) {
    os << "   /* Nodes belonging to function " << (*fn2ns).first << "*/\n";
    os << "   subgraph \"cluster_" << (*fn2ns).first << "\" {" << endl;
    os << "   label=\"" << (*fn2ns).first << "\"" << endl;
    std::vector<ALFExtendedProgramGraphNode *> * nodes = (*fn2ns).second;
    for( std::vector<ALFExtendedProgramGraphNode *>::iterator n = nodes->begin(); n != nodes->end(); ++n) {
      os << "      \"" << (*n)->Id() << "\"[label=\"";
      (*n)->Draw(os);
      os << "\",fontsize=5,width=0.01,height=0.01,margin=\"0.01,0.01\"]" << endl; 
    }
    os << "   }" << endl;
    // Delete temporaries
    delete nodes;
  }

  // Print edges
  for(ALFExtendedProgramDataDependencyGraph::node_iterator n = epdg->NodesBegin();
      n != epdg->NodesEnd(); ++n){
    for(ALFExtendedProgramGraphNode::succ_iterator se = (*n)->SuccBegin();
	se != (*n)->SuccEnd(); ++se) {
      ALFExtendedProgramGraphNode * succ = (*se).node;
      ALFExtendedProgramGraphEdge * edge = ((*se).edge_annot);
      os << "   \"" << (*n)->Id() << "\" -> \""; 
      os << succ->Id() << "\"";
      assert(edge->IsDataDependencyEdge());
      os << "[style=solid";
      if(edge) os << ",label=\"" << edge->GetLabel() << "\"";
      os << ",fontsize=5,margin=\"0.01,0.01\"]" << endl;
    }
  }
  os << "  }" << endl;
  os << "}" << endl;
}  


// Add data dependency edges according to result of reaching definitions and uses 
// Basically, if we have a definition of a variable v at node n1 that reaches a use 
// of the same variable v at a node n2, then we should have a data dependency edge 
// inbetween n1 and n2.
ALFExtendedProgramDataDependencyGraph *
ALFExtendedProgramDataDependencyGraphBuilder::
Build(ALFExtendedProgramControlFlowGraph * epcfg, ALFReachingDefinitionsAnalysis * rd, 
      ALFDefsAndUsesAnalysis * du, CSymTabBase * symtab)
{
  assert(epcfg);
  assert(rd);
  assert(du);

  // Create a new program data dependecy graph
  _epddg = new ALFExtendedProgramDataDependencyGraph();
  
  // ---------------------------------
  // Add nodes according to epcfg
  // ---------------------------------

  // Create nodes for the resulting data dependency graph based on the epcfg nodes
  for(unsigned int i = 0; i < epcfg->NrOfNodes(); i++) {
    ALFExtendedProgramGraphNode * epcfg_node = epcfg->NodeAt(i);
    assert(epcfg_node);
    // Create node and add it to the new graph
    ALFExtendedProgramGraphNode * epddg_node = epcfg_node->Copy();
    _epddg->AddNode(epddg_node);
    // Make sure that the nodes have the same indexes
    assert(epddg_node->Id() == epcfg_node->Id());
  }
  // ---------------------------------
  // Add edges according to rd and du analysis
  // ---------------------------------

  // Loop through all the nodes in the epcfg
  for(unsigned int i = 0; i < epcfg->NrOfNodes(); i++) {
    ALFExtendedProgramGraphNode * epcfg_node = epcfg->NodeAt(i);
    assert(epcfg_node);
    // Get the uses of the node
    std::set<unsigned int> uses;
    du->GetUsesOfEPGNode(epcfg_node, &uses);    

    if(uses.size() > 0) {
      // Get the to node
      ALFExtendedProgramGraphNode * to_node = _epddg->NodeAt(epcfg_node->Id());
      assert(to_node->GetType() == epcfg_node->GetType());

      // Loop through all uses
      for(std::set<unsigned int>::iterator u = uses.begin(); u != uses.end(); u++) {

        // Get the definitions of the used variable 
        std::set<ALFExtendedProgramGraphNode *> def_epcfg_nodes; 
        rd->GetDefsOfVarThatMayReachEPGNode(epcfg_node, (*u), &def_epcfg_nodes);

        if(def_epcfg_nodes.size() > 0) {
          // Extract a label to add on the edge
          const CSymTabEntry * symtab_entry = symtab->Lookup(*u);
          stringstream ss;
          ss << "var: " << symtab_entry->Name() << ' ' << (*u);
          std::string edge_label = ss.str();

          // Go through all defining epcfg nodes, find their corresponding
          // nodes in the epddg, add an edge from the def node to use node
          for(std::set<ALFExtendedProgramGraphNode *>::iterator def_epcfg_node = def_epcfg_nodes.begin();
              def_epcfg_node != def_epcfg_nodes.end(); ++def_epcfg_node)
          {
            // Get the from node
            ALFExtendedProgramGraphNode * from_node = _epddg->NodeAt((*def_epcfg_node)->Id());
            assert(from_node->GetType() == (*def_epcfg_node)->GetType());

            ALFExtendedProgramGraphEdge * edge;
            if (_epddg->Edge(from_node, to_node, &edge)) {
              // An edge already exists; update its label
              edge->SetLabel( edge->GetLabel() + '\n' + edge_label );
            } else {
              // Add the new edge in-between the nodes in the epdg
              edge = new ALFExtendedProgramGraphEdge(ALFExtendedProgramGraphEdge::DATA, edge_label);
              _epddg->AddEdge(from_node, to_node, edge);
            }
          }
        }
      }
    }
  } 
  // Return the created graph
  return _epddg;
}




// // Add data dependency edges according to result of reaching definitions and uses 
// // Basically, if we have a definition of a variable v at node n1 that reaches a use 
// // of the same variable v at a node n2, then we should have a data dependency edge 
// // inbetween n1 and n2.
// ALFExtendedProgramDataDependencyGraph *
// ALFExtendedProgramDataDependencyGraphBuilder::
// Build(ALFExtendedProgramControlFlowGraph * epcfg, 
//       CCallGraph * cg, ALFReachingDefinitionsAnalysis * rd, 
//       ALFDefsAndUsesAnalysis * du, CSymTabBase * symtab)
// {
//   // For fast retrieval of epdg node corresponding to a certain annot, alloc, init or statement
//   std::map<CALFAbsAnnot *, ALFExtendedProgramGraphNode *> annot_to_node;
//   std::map<alf::CAllocTuple *, ALFExtendedProgramGraphNode *> alloc_to_node;
//   std::map<alf::CInitTuple *, ALFExtendedProgramGraphNode *> init_to_node;
//   std::map<alf::AStmt *, ALFExtendedProgramGraphNode *> stmt_to_node;

//   // Create a new program data dependecy graph
//   _epddg = new ALFExtendedProgramDataDependencyGraph();

//   // ---------------------------------
//   // Add nodes according to epddg
//   // ---------------------------------

//   // Create nodes for the resulting data dependency graph based on the epcfg nodes
//   for(ALFExtendedProgramControlFlowGraph::node_iterator n = epcfg->NodesBegin();
//       n != epcfg->NodesEnd(); ++n) {
//     // Create node and add it to the new graph
//     ALFExtendedProgramGraphNode * new_node = (*n)->Copy();
//     _epddg->AddNode(new_node);
//     // Update internal mapping. These are used in the data dependency graph calculation
//     switch (new_node->GetBaseType()) {
//     case ALFExtendedProgramGraphNode::STMT: {
//       ALFExtendedProgramGraphNodeStmt * stmt_node = dynamic_cast<ALFExtendedProgramGraphNodeStmt *>(new_node);
//       stmt_to_node[stmt_node->GetStmt()] = new_node;
//       break;
//     }
//     case ALFExtendedProgramGraphNode::ANNOT: { 
//       ALFExtendedProgramGraphNodeAnnot * annot_node = dynamic_cast<ALFExtendedProgramGraphNodeAnnot *>(new_node);
//       annot_to_node[annot_node->GetAnnot()] = new_node;
//       break;
//     }
//     case ALFExtendedProgramGraphNode::ALLOC: {
//       ALFExtendedProgramGraphNodeAlloc * alloc_node = dynamic_cast<ALFExtendedProgramGraphNodeAlloc *>(new_node);
//       alloc_to_node[alloc_node->GetAlloc()] = new_node;
//       break;
//     }
//     case ALFExtendedProgramGraphNode::INIT: {
//       ALFExtendedProgramGraphNodeGlobalInit * init_node = dynamic_cast<ALFExtendedProgramGraphNodeGlobalInit *>(new_node);
//       init_to_node[init_node->GetInit()] = new_node;
//       break;
//     }
//     case ALFExtendedProgramGraphNode::VIRTUAL:
//     case ALFExtendedProgramGraphNode::ASSIGN': {
//       break;
//     }
//     }
//   }
  
//   // ---------------------------------
//   // Add edges according to rd and du analysis
//   // ---------------------------------

//   // Loop through all the cfgs in the cg
//   for(CCallGraph::node_iterator cg_node = cg->NodesBegin(); cg_node != cg->NodesEnd(); ++cg_node) {
//     CFlowGraph * cfg = (*cg_node)->FlowGraph();
//     // Loop through all the nodes in the cfg 
//     for(CFlowGraph::node_iterator cfg_node = cfg->NodesBegin(); cfg_node != cfg->NodesEnd(); ++cfg_node) {
//       // Get the statement of the node and its uses 
//       alf::AStmt * to_stmt = dynamic_cast<alf::AStmt *>((*cfg_node)->Stmt());
//       ALFExtendedProgramGraphNode * to_node = stmt_to_node[to_stmt];
//       std::set<unsigned int> uses;
//       du->GetUsesOfStmt(to_stmt, &uses);
//       // Loop through all uses
//       for(std::set<unsigned int>::iterator u = uses.begin(); u != uses.end(); u++) {
// 	// Get the definitions of the used variable that may reach the given cfg node
// 	std::set<alf::AStmt *> defining_stmts; 
// 	std::set<CALFAbsAnnot *> defining_annots;
// 	std::set<alf::CAllocTuple *> defining_allocs;
// 	std::set<alf::CInitTuple *> defining_inits;
// 	rd->GetDefsOfVarThatMayReachStmt(to_stmt, (*u), &defining_stmts, 
// 					 &defining_annots, &defining_allocs, &defining_inits);
// 	// cout << "    def of use " << (*u) << " comes from: \n";
// 	// Extract a label to add on the edge
// 	const CSymTabEntry * symtab_entry = symtab->Lookup(*u);
// 	stringstream ss;
// 	ss << "var: " << symtab_entry->Name() << " " << (*u) << "";
// 	std::string edge_label = ss.str();
// 	// Go through the defining cfg nodes, find their corresponding
// 	// nodes in the epddg using the inherent stmt, and add an edge
// 	// from the def node to use node
// 	if(defining_stmts.size() > 0) {
// 	  for(std::set<alf::AStmt *>::iterator n = defining_stmts.begin();
// 	      n != defining_stmts.end(); ++n) {
// 	    alf::AStmt * from_stmt = (*n);
// 	    ALFExtendedProgramGraphNode * from_node = stmt_to_node[from_stmt];
// 	    // cout << "     node: " << *from_node << endl;
// 	    // Add the edge inbetween the nodes in the epdg
// 	    ALFExtendedProgramGraphEdge * edge = new ALFExtendedProgramGraphEdge(ALFExtendedProgramGraphEdge::DATA, edge_label);
// 	    _epddg->AddEdge(from_node, to_node, edge);
// 	  }
// 	}
// 	// Go through the annot definitions, find their corresponding
// 	// nodes in the epfg, and add an edge from the def to use 
// 	if(defining_annots.size() > 0) {
// 	  for(std::set<CALFAbsAnnot *>::iterator a = defining_annots.begin(); a != defining_annots.end(); ++a) {
// 	    ALFExtendedProgramGraphNode * from_node = annot_to_node[*a];
// 	    // cout << "     node: " << *from_node << endl;
// 	    // Add the edge inbetween the nodes in the epdg
// 	    ALFExtendedProgramGraphEdge * edge = new ALFExtendedProgramGraphEdge(ALFExtendedProgramGraphEdge::DATA, edge_label);
// 	    _epddg->AddEdge(from_node, to_node, edge);
// 	  }
// 	}
// 	// Go through the alloc definitions, find their corresponding
// 	// nodes in the epfg, and add an edge from the def to use 
// 	if(defining_allocs.size() > 0) {
// 	  for(std::set<alf::CAllocTuple *>::iterator a = defining_allocs.begin(); a != defining_allocs.end(); ++a) {
// 	    ALFExtendedProgramGraphNode * from_node = alloc_to_node[*a];
// 	    // cout << "     node: " << *from_node << endl;
// 	    // Add the edge inbetween the nodes in the epdg
// 	    ALFExtendedProgramGraphEdge * edge = new ALFExtendedProgramGraphEdge(ALFExtendedProgramGraphEdge::DATA, edge_label);
// 	    _epddg->AddEdge(from_node, to_node, edge);
// 	  }
// 	}
// 	// Go through the init definitions, find their corresponding
// 	// nodes in the epfg, and add an edge from the def to use 
// 	if(defining_inits.size() > 0) {
// 	  for(std::set<alf::CInitTuple *>::iterator a = defining_inits.begin(); a != defining_inits.end(); ++a) {
// 	    ALFExtendedProgramGraphNode * from_node = init_to_node[*a];
// 	    /// cout << "     node: " << *from_node << endl;
// 	    // Add the edge inbetween the nodes in the epdg
// 	    ALFExtendedProgramGraphEdge * edge = new ALFExtendedProgramGraphEdge(ALFExtendedProgramGraphEdge::DATA, edge_label);
// 	    _epddg->AddEdge(from_node, to_node, edge);
// 	  }
// 	}
//       } // end for all uses
//     } // end for all cfg nodes
//   } // end for all cfgs
 
//   // Return the created graph
//   return _epddg;
// }


