#ifndef CACHELINESETMAY_H_
#define CACHELINESETMAY_H_

#include "cache_analysis/CacheLineSet.h"

//----------------------------------------------------------------------
//
// CacheLineSetMay
// -- Implements a MAY cache analysis. May functionality inher�ted 
//   from CacheLineSet. 
// -- MAY join means 1. union - if one of the two cachelines has the block we should
//    insert it and 2. minimal age - if both has the memory block insert
//    the block at the youngest cacheline).
//
//----------------------------------------------------------------------
class CacheLineSetMay : public CacheLineSet
{
public:

  // To create and delete the cache line set
  CacheLineSetMay(unsigned int nr_of_cache_lines);
  virtual ~CacheLineSetMay();
  
  // To create a new cache line set. Virtual in parent class.
  CacheLineSet * CreateCacheLineSet(unsigned int nr_of_cache_lines);

protected:

  // To insert a memoryblock as the result of a join
  virtual void InsertMemoryBlockNrAfterJoin(unsigned int memory_block, 
					    unsigned int cache_line_nr1,
					    unsigned int cache_line_nr2);
};

#endif
