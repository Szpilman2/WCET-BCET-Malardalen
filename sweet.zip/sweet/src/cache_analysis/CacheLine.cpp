#include "cache_analysis/CacheLine.h"

// -------------------------------------------------------
// CacheLine
// -------------------------------------------------------

// For creating a cache line
CacheLine ::
CacheLine()
{
  // Do nothing, the set of memeory blocks is empty
}

// For deleting a cache line
CacheLine ::
~CacheLine()
{
  // Do nothing, the set of memory blocks will be automatically deleted 
}


// For copying a cache line
CacheLine *
CacheLine ::
Copy() const
{
  // Create a new cacheline
  CacheLine * cache_line = new CacheLine();

  // Copy all elements in the current cacheline
  for(std::set<unsigned int>::const_iterator mbn = _memory_block_nr_set.begin(); 
      mbn != _memory_block_nr_set.end(); mbn++)
    {
      cache_line->AddMemoryBlockNr(*mbn);
    }

  // All numbers have been copied, return the new cacheline
  return cache_line;
}

// For checking if two cache lines are equal. They are equal if they
// contain the same memory blocks.
bool
CacheLine ::
IsEqual(const CacheLine * cache_line) const
{
  // If they have different amount of memory block nrs they can not be equal 
  if(_memory_block_nr_set.size() != cache_line->_memory_block_nr_set.size())
    return false;
     
  // Check that all memory block elements is in the other cacheline
  for(std::set<unsigned int>::const_iterator mbn = _memory_block_nr_set.begin(); 
      mbn != _memory_block_nr_set.end(); mbn++) {
    if(!cache_line->HasMemoryBlockNr(*mbn))
      return false;
  }
  
  // All elements contained in both sets
  return true;
}

// To add a memory block nr to the cache line
void
CacheLine::
AddMemoryBlockNr(unsigned int memory_block_nr)
{
  // Add it to the set
  _memory_block_nr_set.insert(memory_block_nr);
}

// To delete a memory block nr from the cache line
void
CacheLine::
DeleteMemoryBlockNr(unsigned int memory_block_nr)
{
  // Delete it from the set
  _memory_block_nr_set.erase(memory_block_nr);
}

// To check if a cache line contains a certain memory block
bool 
CacheLine::
HasMemoryBlockNr(unsigned int memory_block_nr) const
{
  // Search the set for the memory block nr
  if(_memory_block_nr_set.find(memory_block_nr) == _memory_block_nr_set.end())
    return false;
  else
    return true;
}

// To delete all memory block nrs in the current cache line
void
CacheLine ::
Reset()
{
  _memory_block_nr_set.erase(_memory_block_nr_set.begin(),
			     _memory_block_nr_set.end());
}

// To check if the cache line is empty
bool
CacheLine ::
IsEmpty() const
{
  return _memory_block_nr_set.empty();
}
 
// For getting all memoryblocks in a cache line
void 
CacheLine ::
AllMemoryBlockNrs(std::set<unsigned int> * memory_block_nrs) const
{
  // Go through all memory blocks in the list and add them to the set
  for(std::set<unsigned int>::const_iterator mbn = _memory_block_nr_set.begin(); 
      mbn != _memory_block_nr_set.end(); mbn++) {
    memory_block_nrs->insert(*mbn);
  }
}

// To printing all elements in a cache line 
void
CacheLine ::
Print(std::ostream & s) const
{
  // Go through all memory blocks in the list and print them
  for(std::set<unsigned int>::const_iterator mbn = _memory_block_nr_set.begin(); 
      mbn != _memory_block_nr_set.end(); /* intentionally empty */ ) {
    
    // Print the memory block number
    (s) << (*mbn);
    // Detect last variable to not print an unneccessary comma
    mbn++;
    if(mbn != _memory_block_nr_set.end())
      (s) << ",";
  }
}

// To draw the elements in a cache line
void
CacheLine ::
Draw(std::ostream & s) const
{
  //Just call the print function
  Print(s);
}
