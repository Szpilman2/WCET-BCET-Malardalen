#ifndef CACHECHARACTERISTICS_H_
#define CACHECHARACTERISTICS_H_

#include <string>
#include <iostream>
#include <vector>

// -------------------------------------------------------
// CacheCharacteristics : Class holding concrete information about a cache. 
// -- cache_size: The size of the inxstruction cache. 
// -- cache_line_size: The size of a cacheline. 
//    The number of cache lines is then: cache_size / cache_line_size.
// -- start_address_offset: The address where the space starts (normally 0). 
// -- nr_of_cache_line_sets: Defines if we have an associative cache
//    or not. For a directmapped cache nr_of_cache_line_sets ==  
//    number of cachelines, i.e. each line gets its own set. Default 
//    fully associative, ie all cache lines belong to the same set.
// -- cache_type - what to be stored in the cache. Can be instructions, 
//    data or both (called shared). 
// -- replacement_strategy: How to replace memoryblocks in cacheline sets.
//    Can be LRU (Least Recently Used), FIFO (If block already in cache, 
//    then no change, otherwise place first). Default LRU.
//
// NOTE: Should maybe be extended to handle a complete cache hierarchy?
// -------------------------------------------------------
class CacheCharacteristics 
{
public:
  // ---------------------------------
  // Enums needed to describe the characteristics of a cache 
  // ---------------------------------
  enum CACHE_TYPE { INSTR, DATA, SHARED };
  enum CACHE_LEVEL { L1 }; // We should be adding L2, L3 etc
  enum REPLACEMENT_STRATEGY { LRU, FIFO }; // We should be adding PLRU, RANDOM, etc

  // ---------------------------------
  // To create and delete the cache characteristics
  // ---------------------------------
  CacheCharacteristics(unsigned int cache_size, unsigned int cache_line_size, 
		       unsigned int start_address_offset=0, unsigned int nr_of_cache_line_sets=1,
		       CACHE_LEVEL cache_level=L1,
		       CACHE_TYPE cache_type=INSTR,
		       REPLACEMENT_STRATEGY replacement_strategy=LRU);
  virtual ~CacheCharacteristics() {};

  // ---------------------------------
  // For getting info on the cache characteristics
  // ---------------------------------
  unsigned int GetCacheSize() const;
  unsigned int GetCacheLineSize() const;
  unsigned int GetNrOfCacheLines() const;
  unsigned int GetStartAddressOffset() const;
  unsigned int GetNrOfCacheLineSets() const;
  unsigned int GetNrOfCacheLinesInCacheLineSet() const;
  CACHE_TYPE GetCacheType() const;
  CACHE_LEVEL GetCacheLevel() const;
  REPLACEMENT_STRATEGY GetReplacementStrategy() const;

  // ---------------------------------
  // For getting the memory block certain addresses belongs to. 
  // ---------------------------------
  void GetMemoryBlockNrsOfAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * address_size_pairs, 
				    std::vector<unsigned int> * memory_block_nrs) const;

  // ---------------------------------
  // To get the cache line set a certain memory block belongs to. I.e
  // the cache line set to which the memory block will be mapped. 
  // Default calculated as: aMemoryBlockNr % aNrOfCacheLineSetsInCache
  // ---------------------------------
  unsigned int GetCacheLineSetNrOfMemoryBlock(unsigned int memory_block_nr) const;

  // To print the cache characteristics
  void Print(std::ostream & s = std::cout) const;

protected:

  // ---------------------------------
  // Internal variables
  // ---------------------------------
  unsigned int _cache_size;
  unsigned int _cache_line_size;
  // nr_of_cache_lines = cache_size / cache_line_size;
  unsigned int _nr_of_cache_lines;
  unsigned int _start_address_offset;
  unsigned int _nr_of_cache_line_sets;
  // unsigned int nr_of_cache_lines_in_cache_line_set = nr_of_cache_lines / nr_of_cache_line_sets;
  CACHE_LEVEL _cache_level;
  CACHE_TYPE _cache_type;
  REPLACEMENT_STRATEGY _replacement_strategy;

  // Virtual help function. Memory blocks are stored in a vector
  // vector since an address might be large and cover two or
  // several memory blocks. Default calculated as: memory_block_nr =
  // (address - start_address_offset) % cache_line_size
  virtual void GetMemoryBlockNrsOfAddress(std::pair<unsigned int, unsigned int> address_size_pair, 
					  std::vector<unsigned int> * memory_block_nrs) const ;

};

#endif
