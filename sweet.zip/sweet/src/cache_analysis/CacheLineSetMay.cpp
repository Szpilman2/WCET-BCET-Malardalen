#include "cache_analysis/CacheLineSetMay.h"

//----------------------------------------------------------------------
//
// CacheLineSetMay
//
//----------------------------------------------------------------------

// To create a MAY cacheline set
CacheLineSetMay ::
CacheLineSetMay(unsigned int nr_of_cache_lines) 
  : CacheLineSet(nr_of_cache_lines)
{
  
}

// To delete a MAY cacheline set. Actual delete will be made in parent.
CacheLineSetMay ::
~CacheLineSetMay() 
{
  
}

// To create a new may cache line set
CacheLineSet *
CacheLineSetMay ::
CreateCacheLineSet(unsigned int nr_of_cache_lines)
{
  return new CacheLineSetMay(nr_of_cache_lines);
}

// The real binary join function. Implements union + minimal age
void
CacheLineSetMay ::
InsertMemoryBlockNrAfterJoin(unsigned int memory_block_nr, unsigned int cache_line_nr1, unsigned int cache_line_nr2)
{
  // Make sure that one of the cacheline nrs are within the 
  // specified borders
  if(cache_line_nr1 >= _nr_of_cache_lines && cache_line_nr2 >= _nr_of_cache_lines)
    // No, skip the update
    return;

  // Get which cacheline nr that is the smallest
  unsigned int smallest_cache_line_nr = cache_line_nr2;
  if(cache_line_nr1 < cache_line_nr2)
    smallest_cache_line_nr = cache_line_nr1;

  // Insert the memoryblock at the cacheline with smallest value
  GetCacheLine(smallest_cache_line_nr)->AddMemoryBlockNr(memory_block_nr);
}

