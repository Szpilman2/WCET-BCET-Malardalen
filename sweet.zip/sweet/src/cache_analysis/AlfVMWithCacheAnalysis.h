#include "cache_analysis/StmtToInstrAndDataAddresses.h"
#include "cache_analysis/StateWithCacheState.h"
#include "program_state/AlfVM.h"
#include <memory>

// -------------------------------------------------------
//
// AlfVMWithCacheAnalysis
// -- VM needed to run AE together with cache analysis
//
// -------------------------------------------------------
class AlfVMWithCacheAnalysis : public AlfVM  
{
public:
  // To create and delete the virtual machine
  AlfVMWithCacheAnalysis(std::unique_ptr<StmtToInstrAndDataAddresses> mapper);
  virtual ~AlfVMWithCacheAnalysis();

   /** Initialize the state to make it ready to be updated by running
       the program, where start_function is the entry function. Will
       after initializing the cache analyses states call the parent
       initialize state function. The fifth arguments is optional. If given 
       the keys will be processed in left to right order, adding each 
       corresponding address to the abstract caches in the state. The symbol table 
       provided by the program will be used to check if a given key is valid and 
       if it corresponds to an instruction or to data. */
  virtual void InitializeState(const alf::CAlfTuple * program, const alf::CFuncTuple * start_function,
                               StateWithCacheState * state, bool ignore_volatile,
                               std::vector<unsigned> * keys_of_instr_and_data_to_preload=NULL);

	/** @copydoc AlfVM::InitializeState */
	using AlfVM::InitializeState;
	
   /** Execute the ALF statement at the current program point in the state @p state.
       The resulting state(s) will be returned in @p next_states. Will update the cache 
       state with the instruction and data and then call the parent StepStmt function. 
       The parent StepStmt funbction will call the program counter with the new program 
       point. The instructions and the corresponding data to this new program point has not 
       yet been processed and can be or not be in the cache. The abstract state's cache 
       analysis part can therefore update its misses and hits accordingly. **/
  virtual void StepStmt(std::unique_ptr<State> state, std::vector<State *> & next_states);
   
protected:

  // Class needed to get the addresses that correspond to a certain statement and to certain data 
  StmtToInstrAndDataAddresses * _mapper;

};

