#ifndef ALFSTMTTOINSTRANDDATAADDRESSESBYSTMTKEY_H_
#define ALFSTMTTOINSTRANDDATAADDRESSESBYSTMTKEY_H_

#include "cache_analysis/StmtToInstrAndDataAddresses.h"
#include "program/alf/AStmt.h"
#include "program_state/State.h"

// -------------------------------------------------------
//
// AlfStmtToInstrAndDataAddressesByKey -
// -- Class for getting what instruction addresses a certain 
//    ALF stmt corresponds to.
// -- Input argument is size of addresses to use. Will use
//    AStmt::Key() to get a unique key of the alf statement. The
//    instruction address will then be = key * size and have a bit
//    size of address_size.
// 
// -------------------------------------------------------
class AlfStmtToInstrAndDataAddressesByKey : public StmtToInstrAndDataAddresses
{
public:
  // To create and delete the class. 
  AlfStmtToInstrAndDataAddressesByKey(unsigned int address_size);
  virtual ~AlfStmtToInstrAndDataAddressesByKey();

  // Function which checks that stmt is an alf stmt and then uses the
  // stmt key to create an instr address
  virtual void GetInstrAddressesOfStmt(const CGenericStmt * stmt, 
				       std::vector<std::pair<unsigned int, unsigned int> > * instr_address_size_pairs) const;

  // Uses the provided state to derive alla data stmt can access. For
  // these data the corresponding addresses are collected.
  virtual void GetDataAddressesOfStmt(const CGenericStmt * stmt, const State * state, 
				      std::vector<std::pair<unsigned int, unsigned int> > * data_address_size_pairs) const;

  // We need something that gets the addresses of the global data used in the program.
  // Useful when preallocating global data in the cache.
  // virtual void GetDataAddressesOfGlobalData();

protected:

  // Help functions which return the addresses corresponding to a key
  virtual void GetAddressesOfKey(unsigned int stmt_key, std::vector<std::pair<unsigned int, unsigned int> > * data_address_size_pairs) const;

  unsigned int _address_size;

};

#endif
