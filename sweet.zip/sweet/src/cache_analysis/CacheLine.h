#ifndef CACHELINE_H_
#define CACHELINE_H_

#include <vector>
#include <set>
#include <iostream>

//----------------------------------------------------------------------
//
// CacheLine
// -- Can be abstract since it may hold *several* memory blocks (a
//    concrete cache line can only hold one memory block).
// -- Implemented as a set. Should maybe be implemented using a
//    BitVector. The problem is that we do not know the largest memory
//    blocks nr that we will be using...
//
//----------------------------------------------------------------------
class
CacheLine 
{
public:
  // ---------------------------------
  // For creating and deleting a CacheLine
  // ---------------------------------
  CacheLine();
  virtual ~CacheLine();

  // ---------------------------------
  // For getting a copy of the current instruction cache line set 
  // ---------------------------------
  CacheLine * Copy() const;

  // ---------------------------------
  // For checking if two instruction cache line sets are equal
  // ---------------------------------
  bool IsEqual(const CacheLine * cache_line) const;

  // ---------------------------------
  // For adding and deleting elements from a cacheline
  // ---------------------------------

  // Add a memory block to the current cacheline
  void AddMemoryBlockNr(unsigned int memory_block_nr);

  // Delete a memory block from the current cacheline
  void DeleteMemoryBlockNr(unsigned int memory_block_nr);

  // To check if a cacheline contains a certain memory block
  bool HasMemoryBlockNr(unsigned int memory_block_nr) const;
  
  // Delete all memory blocks in the current cacheline
  void Reset();

  // For checking if a cacheline is empty
  bool IsEmpty() const;

  // ---------------------------------
  // For getting all the memory blocks in a set
  // ---------------------------------
  void AllMemoryBlockNrs(std::set<unsigned int> * memory_block_nrs) const;

  // ---------------------------------
  // Print and draw functions
  // ---------------------------------
  void Print(std::ostream & s = std::cout) const;
  void Draw(std::ostream & s = std::cout) const;

protected:

  // ---------------------------------
  // Internal variables
  // ---------------------------------
  
  // Is internally represented as a set of memory block numbers (no
  // duplicates allowed)
  std::set<unsigned int> _memory_block_nr_set;
}; 

#endif
