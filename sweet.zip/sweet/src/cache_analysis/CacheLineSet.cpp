#include "cache_analysis/CacheLineSet.h"
#include "cache_analysis/CacheLine.h"
#include <assert.h>

// -------------------------------------------------------
// CacheLineSet
// -------------------------------------------------------

// For creation of a cache line set
CacheLineSet::
CacheLineSet(unsigned int nr_of_cache_lines)
  : _nr_of_cache_lines(nr_of_cache_lines)
{
  // Allocated a list
  _cache_lines = new std::vector<CacheLine *>;

  // Create and insert empty cache lines
  for(unsigned int i = 0; i < _nr_of_cache_lines; i++) {
    _cache_lines->push_back(new CacheLine());
  }
}

// For deletion of the cache line set 
CacheLineSet::
~CacheLineSet()
{
  // Delete the cache lines
  for(unsigned int i = 0; i < _nr_of_cache_lines; i++) {
    delete GetCacheLine(i);
  }
  // Finally, delete the vector holding the cache lines
  delete _cache_lines;
}

unsigned int 
CacheLineSet::
NrOfCacheLines()
{
  return _nr_of_cache_lines;
}


// To copy the current cacheline set. Will be calling virtual function 
// hat must be implemented by subclasses.
CacheLineSet *
CacheLineSet::
Copy()
{
  // Get a new empty cacheline set, by calling virtual create function
  CacheLineSet * cache_line_set = CreateCacheLineSet(_nr_of_cache_lines);

  // Go through all the cachelines and copy them to the new cacheline set
  for(unsigned int i = 0; i < _nr_of_cache_lines; i++)
    {
      // Copy the i:th cacheline
      CacheLine * copied_cache_line = this->GetCacheLine(i)->Copy();
      // Add it to the new cacheline set, removing the empty one
      cache_line_set->SetCacheLine(i, copied_cache_line);
    }
  // We are done, return the new cacheline set
  return cache_line_set;
}

// To check if two cacheline sets are equal, true if they contain
// exact the same elements
bool
CacheLineSet::
IsEqual(CacheLineSet * other_cache_line_set)
{
  // First check that they have the same number of cachelines
  if(other_cache_line_set->NrOfCacheLines() != this->NrOfCacheLines())
    return false;
  
  // If the same number of cachelines check that each cacheline 
  // contains the same elements
  for(unsigned int i = 0; i < _nr_of_cache_lines; i++)
    {
      if(!(GetCacheLine(i)->IsEqual(other_cache_line_set->GetCacheLine(i))))
	return false;
    }
  
  // All cachelines where equal
  return true;
}

// For updating a cacheline set with a referenced memory block.
// We are using a LRU replacement strategy
void
CacheLineSet::
UpdateForLRU(unsigned int memory_block_nr)
{
  // Check that the length of the list is correct
  assert(_cache_lines->size() == _nr_of_cache_lines);

  // First, remove all references of the memoryblock nr
  // from the cacheline set (might create an empty cacheline)
  unsigned int cache_line_that_held_memory_block_nr = _nr_of_cache_lines;
  for(unsigned int i = 0; i < _nr_of_cache_lines; i++)
    {
      if(GetCacheLine(i)->HasMemoryBlockNr(memory_block_nr))
	{
	  // Delete the current occurence of the memory block
	  GetCacheLine(i)->DeleteMemoryBlockNr(memory_block_nr);
	  // Keep track of cache line from which the memory block
	  // where taken from
	  cache_line_that_held_memory_block_nr = i;
	  break;
	}
    }

  // Second, create a new cacheline with the cache block nr 
  // (not the real cacheblock) inside
  CacheLine * cache_line = new CacheLine();
  cache_line->AddMemoryBlockNr(memory_block_nr);

  // Insert the new cacheline first in the list and push the other
  // cache lines downwards until we reached the last one or until we
  // reached an empty set. This set is the removed.
  CacheLine * to_be_inserted = cache_line;
  CacheLine * to_be_removed = NULL;
  for(unsigned int i = 0; i < _nr_of_cache_lines; i++)
    {
      // First, get the next element to be removed
      to_be_removed = (*_cache_lines)[i];
      // Set the new element at its position
      (*_cache_lines)[i] = to_be_inserted;

      // Check if the place now is empty
      if(to_be_removed->IsEmpty()) {
	// Yes, then we should do nothing more
	break;
      } 
      else {
	// If not, we should move the cacheline one step back in the array
	to_be_inserted = to_be_removed;
      }
    }

  // Delete the removed cacheline (the last one or the empty one)
  delete to_be_removed;

  // Make sure that we have the right element
  assert(_cache_lines->size() == _nr_of_cache_lines);
}

// For updating a cacheline set with a referenced memory block.
// We are using a FIFO replacement strategy. As LRU but with the 
// difference that if a referenced memory block already is in the
// cache it will not be moved first.
void
CacheLineSet::
UpdateForFIFO(unsigned int memory_block_nr)
{
  // Check that the length of the list is correct
  assert(_cache_lines->size() == _nr_of_cache_lines);

  // First, get if the memoryblock is located in the cacheline already
  // Will tell us where the memoryblock will be located afterwards. 
  // 0 = not found = first among the cacheline sets
  // i = found = will be placed at the same place
  int cache_line_to_hold_memory_block_nr = 0;
  for(unsigned int i = 0; i < _nr_of_cache_lines; i++)
    {
      if(GetCacheLine(i)->HasMemoryBlockNr(memory_block_nr))
	{
	  // Delete the current occurence of the memory block
	  GetCacheLine(i)->DeleteMemoryBlockNr(memory_block_nr);
	  // Keep track of where the memory block should be inserted
	  cache_line_to_hold_memory_block_nr = i;
	  break;
	}
    }

  // Secondly, create a new cacheline with the cacheblocknr 
  // (not the real cacheblock) inside
  CacheLine * cache_line = new CacheLine();
  // Insert the block in the cacheline
  cache_line->AddMemoryBlockNr(memory_block_nr);

  // Insert the new cacheline at i:th position.
  // push each lower cacheline downwards until we reached the last one
  CacheLine * to_be_inserted = cache_line;
  CacheLine * to_be_removed = NULL;
  for(unsigned int i = cache_line_to_hold_memory_block_nr; i < _nr_of_cache_lines; i++)
    {
      // First, get the next element to be removed 
      to_be_removed = (*_cache_lines)[i];
      // Set the new element at its position
      (*_cache_lines)[i] = to_be_inserted;
      // Check if this was the previous place for the memoryblock
      // and if the place now is empty
      if(to_be_removed->IsEmpty()) {
	// Yes, then we should do nothing more
	break;
      }
      // Else, we should move the cacheline one step back in the array
      to_be_inserted = to_be_removed;
    }
  // Delete the removed cacheline (the last one or the empty one)
  delete to_be_removed;

  // Make sure that we have the right element
  assert(_cache_lines->size() == _nr_of_cache_lines);
}

CacheLineSet *
CacheLineSet::
Join(CacheLineSet * cls)
{
  // Make sure that the argument is correct in respect to
  // the current cacheline set
  assert(cls);
  assert(cls->NrOfCacheLines() == _nr_of_cache_lines);

  // Create a new cache line set of the correct size and with empty cache lines.
  CacheLineSet * resulting_cache_line_set = CreateCacheLineSet(_nr_of_cache_lines);
  
  // Create a set which will hold all memory blocks that are in any of
  // the both cache line sets. A set since no duplicates are allowed
  std::set<unsigned int> memory_block_nr_set;
  // Get all memoryblocks in the two sets
  cls->AllMemoryBlockNrs(&memory_block_nr_set);
  this->AllMemoryBlockNrs(&memory_block_nr_set);

  // Loop through all the memory block nrs
  for(std::set<unsigned int>::iterator mbn = memory_block_nr_set.begin(); mbn != memory_block_nr_set.end(); mbn++)
    {
      // Get where the memory block is located in each cacheline set
      unsigned int cache_line_nr1 = this->CacheLineNrOfMemoryBlock(*mbn);
      unsigned int cache_line_nr2 = cls->CacheLineNrOfMemoryBlock(*mbn);

      // Insert the memory block in the new list of cachelines
      resulting_cache_line_set->InsertMemoryBlockNrAfterJoin(*mbn, cache_line_nr1, cache_line_nr2);
    }

  // Check that the new cacheline set is ok
  assert(resulting_cache_line_set->NrOfCacheLines() == _nr_of_cache_lines);

  // We are done, return the created cache line set
  return resulting_cache_line_set;
}

// To check if amemoryblock is wiithin a cacheline set
bool
CacheLineSet::
HasMemoryBlock(unsigned int memory_block_nr) const
{
  // Go through the list of cachelines and see if the block is in any 
  // of them
  for(unsigned int i = 0; i < _nr_of_cache_lines; i++)
    {
      if((GetCacheLine(i))->HasMemoryBlockNr(memory_block_nr))
	return true;
    }
  // The block where not in the cacheline set
  return false;
}

void
CacheLineSet::
Print(std::ostream & s) const
{
  (s) << "CACHE LINE SET PRINT TO BE ADDED...." << std::endl;
}

void
CacheLineSet::
Draw(std::ostream & s) const
{
  (s) << "CACHE LINE SET DRAW TO BE ADDED...." << std::endl;
}



CacheLine * 
CacheLineSet::
GetCacheLine(unsigned int index) const
{
  assert(index <= _nr_of_cache_lines);
  assert((*_cache_lines)[index] != NULL);
  return (*_cache_lines)[index];
}

void
CacheLineSet::
SetCacheLine(unsigned int index, CacheLine * cache_line)
{
  assert(index <= _nr_of_cache_lines);
  assert((*_cache_lines)[index] != NULL);
  delete (*_cache_lines)[index];
  (*_cache_lines)[index] = cache_line;
}

void
CacheLineSet::
AllMemoryBlockNrs(std::set<unsigned int> * memory_block_nrs) const
{
  // Ask each cacheline to fill in the number of memoryblocks it 
  // contains
  for(unsigned int i = 0; i < _nr_of_cache_lines; i++) {
    GetCacheLine(i)->AllMemoryBlockNrs(memory_block_nrs);
  }
  // We are done, the set has been updated
  return;
}

unsigned int 
CacheLineSet::
CacheLineNrOfMemoryBlock(unsigned int memory_block_nr) const
{
  // Ask each cacheline if the number is there 
  unsigned int i = 0;
  for( ; i < _nr_of_cache_lines; i++)
    {
      if((GetCacheLine(i))->HasMemoryBlockNr(memory_block_nr))
	break;
    }
  // Return number where memery block where located or
  // _nr_of_cache_lines if its was not in any of the sets
  return i;
}

