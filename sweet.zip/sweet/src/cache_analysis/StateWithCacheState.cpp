#include "cache_analysis/StateWithCacheState.h"

#include "program_state/PPEnviron.h"
#include "program_state/VarEnviron.h"
#include "program_state/CallStack.h"
#include "program_state/memory/Memory.h"
#include "program_state/program_counter/ProgramCounterECFG.h"

// Macro for creating a key with four elements
#define CREATE_MULTIKEY(ct, cl, rs, at) (std::make_pair(std::make_pair(ct, cl), std::make_pair(rs, at)))

// ---------------------------------
// To create the abs state with the specified abstract cache states
// ---------------------------------
StateWithCacheState::
StateWithCacheState(std::unique_ptr<ProgramCounterECFG> pc, std::unique_ptr<PPEnviron> pp_environ,
                    const std::vector< std::pair< CacheCharacteristics *, AbsCacheState::ANALYSIS_TYPE > > * cache_analyses,
                    bool is_bottom)
   : State(move(pc), move(pp_environ), is_bottom)
{
  std::vector< std::pair< CacheCharacteristics *, AbsCacheState::ANALYSIS_TYPE > >::const_iterator ct;
  for(ct = cache_analyses->begin(); ct != cache_analyses->end(); ++ct) {
    // Extract the important stuff
    CacheCharacteristics * cc = (*ct).first;
    AbsCacheState::ANALYSIS_TYPE analysis_type = (*ct).second;

    // Create the corresponding cache state
    AbsCacheState * acs = new AbsCacheState(cc, analysis_type);

    // Store it in the map
    _keys_to_cache_state[CREATE_MULTIKEY(cc->GetCacheType(), cc->GetCacheLevel(), 
					 cc->GetReplacementStrategy(), analysis_type)] = acs;
  }
}

// ---------------------------------
// To delete the abs state (including the abstract cache states)
// ---------------------------------
StateWithCacheState::
~StateWithCacheState()
{
  std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, 
    std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * >::iterator c;
  for(c = _keys_to_cache_state.begin(); c != _keys_to_cache_state.end(); ++c) {
    // Delete the abstract cache state
    delete (*c).second;
  }
  // The remaining parts will be automatically deleted when the map is deleted
} 


// To get the cache state correspoinding to the given arguments
const
AbsCacheState * 
StateWithCacheState::
GetCacheState(CacheCharacteristics::CACHE_TYPE cache_type, 
              CacheCharacteristics::CACHE_LEVEL cache_level,
              CacheCharacteristics::REPLACEMENT_STRATEGY replacement_strategy,
              AbsCacheState::ANALYSIS_TYPE analysis_type) const
{
  // Get the cache state corresponding to the given arguments
  std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, 
    std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * >::const_iterator c;
  c = _keys_to_cache_state.find(CREATE_MULTIKEY(cache_type, cache_level, replacement_strategy, analysis_type));
  assert(c != _keys_to_cache_state.end());
  return (*c).second;
}

// To create a deep copy of the current state
State *
StateWithCacheState::
Copy() const
{
  if(IsBottom()) {
    return State::Copy();
  }
  else {
    return new StateWithCacheState(*this);
  }
}

// To check if both states are equal
bool 
StateWithCacheState::
IsEqual(const State * other_state) const
{
  // If the parent class thinks they are different we consider them different
  if(!(State::IsEqual(other_state)))
    return false;

  // Check if the other is state is a StateWithCacheState
  const StateWithCacheState * other_state_with_caches = dynamic_cast<const StateWithCacheState *>(other_state);
  if(!(other_state_with_caches))
    return false;

  // The number of abstract cache states must be the same
  if(_keys_to_cache_state.size() != (*other_state_with_caches)._keys_to_cache_state.size()) {
    assert(0);
    return false;
  }
  
  // Loop through the elements in the first map
  std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, 
    std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * >::const_iterator it;
  for(it = _keys_to_cache_state.begin(); it != _keys_to_cache_state.end(); ++it) {
    // Get the things that identifies the abstract state
    CacheCharacteristics::CACHE_TYPE cache_type = (*it).first.first.first;
    CacheCharacteristics::CACHE_LEVEL cache_level = (*it).first.first.second;
    CacheCharacteristics::REPLACEMENT_STRATEGY replacement_strategy = (*it).first.second.first;
    AbsCacheState::ANALYSIS_TYPE analysis_type = (*it).first.second.second;
    // Get the abstract cache state
    AbsCacheState * acs = (*it).second;
    assert(acs);
    // Get the corresponding abstract cache state from the other state
    std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, 
      std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * >::const_iterator other_it;
    other_it = (*other_state_with_caches)._keys_to_cache_state.find(CREATE_MULTIKEY(cache_type, cache_level, replacement_strategy, analysis_type));
    assert(other_it != (*other_state_with_caches)._keys_to_cache_state.end());
    AbsCacheState * other_acs = (*other_it).second;
    assert(other_acs);
    // If the abstract cache states not are equal the state are not equal
    if(!(acs->IsEqual(other_acs))) {
      return false;
    }
  }
  
   return true;
}

// To join to abstract states 
State *
StateWithCacheState::
LUB(const State * state2) const
{
   // Check if one of the states are bottom
   const StateWithCacheState * state1 = this;
   const StateWithCacheState * state2_with_caches = dynamic_cast<const StateWithCacheState *>(state2);
   assert(state2_with_caches);

   if (state1->IsBottom())
      return state2->Copy();
   else if (state2->IsBottom())
      return state1->Copy();
  
   assert(state1->GetGlobEnviron()->IsEqual(state2->GetGlobEnviron()) ||
          "The global environments of the two states must be equal in order to compute their LUB" == NULL);

   // Create new LUB:d environment, memory, parameter area and callstack.
   std::unique_ptr<Memory> lub_mem(state1->GetMemory()->LUB(state2->GetMemory()));
   cheap_copy<CallStack> lub_cs;
   if (state1->_call_stack.get() == state2_with_caches->_call_stack.get())
      lub_cs = state1->_call_stack;
   else
      lub_cs.reset( state1->_call_stack->LUB(state2_with_caches->_call_stack.get()) );

   // LUB should never give bottom
   assert(lub_mem.get());
   assert(lub_cs.get());

   // LUB the pc:s, but use the same global environment
   std::unique_ptr<ProgramCounterECFG> lub_pc(state1->GetProgramCounterECFG()->LUB(state2->GetProgramCounterECFG()));
  
   // To hold the lub:ed abstract states
   std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * > lub_keys_to_cache_state; 

   // The number of abstract cache states must be the same
   assert(_keys_to_cache_state.size() == (*state2_with_caches)._keys_to_cache_state.size());
   // Loop through the elements in the first map
   std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * >::const_iterator it;
   for(it = _keys_to_cache_state.begin(); it != _keys_to_cache_state.end(); ++it) {
      // Get the things that identifies the abstract state
      CacheCharacteristics::CACHE_TYPE cache_type = (*it).first.first.first;
      CacheCharacteristics::CACHE_LEVEL cache_level = (*it).first.first.second;
      CacheCharacteristics::REPLACEMENT_STRATEGY replacement_strategy = (*it).first.second.first;
      AbsCacheState::ANALYSIS_TYPE analysis_type = (*it).first.second.second;
      // Get the abstract cache state
      AbsCacheState * acs = (*it).second;
      assert(acs);
      // Get the corresponding abstract cache state from the other state
      std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, 
                         std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * >::const_iterator other_it;
      other_it = (*state2_with_caches)._keys_to_cache_state.find(CREATE_MULTIKEY(cache_type, cache_level, replacement_strategy, analysis_type));
      assert(other_it != (*state2_with_caches)._keys_to_cache_state.end());
      AbsCacheState * other_acs = (*other_it).second;
      assert(other_acs);
      // Create a LUB:ed abstract cache state 
      AbsCacheState * lub_acs = acs->LUB(other_acs);
      // Insert it in the map
      lub_keys_to_cache_state[CREATE_MULTIKEY(cache_type, cache_level, replacement_strategy, analysis_type)] = lub_acs;
   }

   // Create a new state with cache states
   return new StateWithCacheState(move(lub_pc), state1->_genv, move(lub_mem), move(lub_cs),
                                  state1->_pp_environ, &lub_keys_to_cache_state);
}  

// State *
// StateWithCacheState::
// GLB(const State * state2) const
// {
//    const State* state1 = this;

//    if (state1->IsBottom())
//       return state1->Copy();
//    if (state2->IsBottom())
//       return state2->Copy();

//    assert(state1->GEnv()->IsEqual(state2->GEnv()) || 
//       "The global environments of the two states must be equal in order to compute their GLB" == NULL);

//    unique_ptr<Memory> glb_mem(state1->Mem()->GLB(state2->Mem()));
//    unique_ptr<CallStack> glb_cs(state1->GetCallStack()->GLB(state2->GetCallStack()));

//    // Check if we got an erroneous value
//    if (glb_mem->IsBottom() || glb_cs->IsBottom()) {
//       return CreateBottomState(unique_ptr<ProgramCounterECFG>(state1->GetProgramCounterECFG()->Copy()));
//    }
//    else {
 
//      // Glb the PCs but use the same global environment
//      unique_ptr<ProgramCounterECFG> glb_pc = 
//        unique_ptr<ProgramCounterECFG>(state1->GetProgramCounterECFG()->GLB(state2->GetProgramCounterECFG()));
//      VarEnviron glb_env = *state1->GEnv();

//    // To hold the lub:ed abstract states
//     std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * > glb_keys_to_cache_state; 

//     const StateWithCacheState * state2_with_caches = dynamic_cast<const StateWithCacheState *>(state2);
//     assert(state2_with_caches);
    
//     // The number of abstract cache states must be the same
//     assert(_keys_to_cache_state.size() == (*state2_with_caches)._keys_to_cache_state.size());

//     // Loop through the elements in the first map
//     std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * >::const_iterator it;
//     for(it = _keys_to_cache_state.begin(); it != _keys_to_cache_state.end(); ++it) {
//       // Get the things that identifies the abstract state
//       CacheCharacteristics::CACHE_TYPE cache_type = (*it).first.first.first;
//       CacheCharacteristics::CACHE_LEVEL cache_level = (*it).first.first.second;
//       CacheCharacteristics::REPLACEMENT_STRATEGY replacement_strategy = (*it).first.second.first;
//       AbsCacheState::ANALYSIS_TYPE analysis_type = (*it).first.second.second;
//       // Get the abstract cache state
//       AbsCacheState * acs = (*it).second;
//       assert(acs);
//       // Get the corresponding abstract cache state from the other state
//       std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, 
// 	std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * >::const_iterator other_it;
//       other_it = (*state2_with_caches)._keys_to_cache_state.find(CREATE_MULTIKEY(cache_type, cache_level, replacement_strategy, analysis_type));
//       assert(other_it != (*state2_with_caches)._keys_to_cache_state.end());
//       AbsCacheState * other_acs = (*other_it).second;
//       assert(other_acs);
//       // Create a GLB:ed abstract cache state 
//       AbsCacheState * glb_acs = acs->GLB(other_acs);
//       // Insert it in the map
//       glb_keys_to_cache_state[CREATE_MULTIKEY(cache_type, cache_level, replacement_strategy, analysis_type)] = glb_acs;
//     }

//     // Create a new state with cache states
//     return new StateWithCacheState(glb_pc, *state1->GEnv(), glb_mem, glb_cs, state1->GetPPEnviron(),
// 				       &glb_keys_to_cache_state);
//   }  
// }


// To update the abstract caches with some instructions
void 
StateWithCacheState::
UpdateCacheStatesWithInstrAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * instr_address_size_pairs)
{
  // Find the abstract caches that holds instructions
  std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, 
    std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * >::iterator c;
  for(c = _keys_to_cache_state.begin(); c != _keys_to_cache_state.end(); ++c) {
    // Extract the important information from the map element
    CacheCharacteristics::CACHE_TYPE cache_type = (*c).first.first.first;
    // Check if the type hold instructions
    if(cache_type == CacheCharacteristics::INSTR || cache_type == CacheCharacteristics::SHARED) {
      AbsCacheState * acs = (*c).second;
      acs->UpdateWithAddresses(instr_address_size_pairs);
    }
  }
}

// To update the abstract caches with some data
void 
StateWithCacheState::
UpdateCacheStateWithDataAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * data_address_size_pairs)
{
  // Find the abstract caches that holds data
  std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, 
    std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * >::iterator c;
  for(c = _keys_to_cache_state.begin(); c != _keys_to_cache_state.end(); ++c) {
    // Extract the important information from the map element
    CacheCharacteristics::CACHE_TYPE cache_type = (*c).first.first.first;
    // Check if the type hold instructions
    if(cache_type == CacheCharacteristics::DATA || cache_type == CacheCharacteristics::SHARED) {
      AbsCacheState * acs = (*c).second;
      acs->UpdateWithAddresses(data_address_size_pairs);
    }
  }
}

// To make a deep copy of an abstract state with caches
StateWithCacheState::
StateWithCacheState(const StateWithCacheState & other)
  // Most copying is made in parent class  
  : State(other)
{
  // Copy all the abstract cache states and insert the in teh new states map
  std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, 
    std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * >::const_iterator c;
  for(c = other._keys_to_cache_state.begin(); c != other._keys_to_cache_state.end(); ++c) {
    // Get the things that identifies the abstract state
    CacheCharacteristics::CACHE_TYPE cache_type = (*c).first.first.first;
    CacheCharacteristics::CACHE_LEVEL cache_level = (*c).first.first.second;
    CacheCharacteristics::REPLACEMENT_STRATEGY replacement_strategy = (*c).first.second.first;
    AbsCacheState::ANALYSIS_TYPE analysis_type = (*c).first.second.second;
    // Create a copy of the abstract state
    AbsCacheState * acs_copy = (*c).second->Copy();
    // Insert the copy in the map
    _keys_to_cache_state[CREATE_MULTIKEY(cache_type, cache_level, replacement_strategy, analysis_type)] = acs_copy;
  }
}

// To create and abstract state with cache states
StateWithCacheState::
StateWithCacheState(std::unique_ptr<ProgramCounterECFG> pc, cheap_copy<VarEnviron> genv,
                    std::unique_ptr<Memory> mem, cheap_copy<CallStack> call_stack,
                    cheap_copy<PPEnviron> pp_environ, 
                    const std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, 
                    std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * > * keys_to_cache_state)
  : State(move(pc), move(genv), move(mem), move(call_stack), move(pp_environ)),
    _keys_to_cache_state(*keys_to_cache_state)
{
  
}
 
// To print the state and the abstract cache states
std::ostream & 
StateWithCacheState::
Print(std::ostream & os) const
{
  os << "StateWithCacheState \n";
  State::Print(os);
  return os;
}

ostream &
StateWithCacheState::
Draw(ostream & os)
const
{  
  os << "StateWithCacheState \n";
  State::Draw(os);
  return os;
}
