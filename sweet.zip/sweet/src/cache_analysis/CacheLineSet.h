#ifndef CACHELINESET_H_
#define CACHELINESET_H_

#include <vector>
#include <set>
#include <string>
#include <iostream>
#include "cache_analysis/CacheLine.h"

//----------------------------------------------------------------------
//
// CacheLineSet
// -- Class for holding a set of cache lines
// -- Is used by AbsCacheState
// -- Is virtual since the Transfer and Join functions will differ depending on 
//    what type of analysis we want to make.
//
// ** Maybe we should use the RefCounter class to get copy-on-write functionality?  
//
//----------------------------------------------------------------------
class CacheLineSet
{

public:
  // ---------------------------------
  // For creating and deleting the set
  // ---------------------------------
  CacheLineSet(unsigned int nr_of_cache_lines);
  virtual ~CacheLineSet();

  // ---------------------------------
  // For getting the number of cache lines 
  // ---------------------------------
  unsigned int NrOfCacheLines();

  // ---------------------------------
  // For getting a copy of the current instruction cache line set 
  // ---------------------------------
  CacheLineSet * Copy();

  // ---------------------------------
  // For checking if two instruction cache line sets are equal
  // ---------------------------------
  bool IsEqual(CacheLineSet * other_cache_line_set);

  // ---------------------------------
  // Different update functions depending of what type of 
  // replacement strategy the instruction cache has
  // ---------------------------------

  // Will replace the current cacheline set, make sure to save it 
  // before updating if you need it later on.

  // If we are using a LRU replacement strategy
  void UpdateForLRU(unsigned int memory_block_nr);
  // If we are using a FIFO replacement strategy
  void UpdateForFIFO(unsigned int memory_block_nr);

  // ---------------------------------
  // Join()
  // ---------------------------------

  // For joining two different set of cachelines.
  // Will return a new PBInstructionCacheLineSet. 
  // Make sure to free the set when you don't need it any longer
  virtual CacheLineSet * Join(CacheLineSet * other_cache_line_set);

  // ---------------------------------
  // To check if the block is in the cache line set or not.
  // ---------------------------------
  bool HasMemoryBlock(unsigned int memory_block_nr) const;

  // ---------------------------------
  // Printing functions
  // ---------------------------------
  void Print(std::ostream & s = std::cout) const;
  void Draw(std::ostream & s = std::cout) const;

protected:

  // ---------------------------------
  // For getting and setting the different cache lines
  // The cache line sets are numbered from 0 to nr_of_cache_lines-1.
  // ---------------------------------
  CacheLine * GetCacheLine(unsigned int index) const;
  // When setting a cacher line the previous one at the index will be deleted
  void SetCacheLine(unsigned int index, CacheLine * cache_line);

  // ---------------------------------
  // Virtual function that must be implemented by subclasses
  // ---------------------------------

  // For insert a memoryblock as the result of a join, will be 
  // implemented differently by subclasses depending on if 
  // May, Must, etc analysis should be made...
  virtual void InsertMemoryBlockNrAfterJoin(unsigned int memory_block, 
					    unsigned int cache_line_nr1,
					    unsigned int cache_line_nr2) = 0;

  // For creating a new cacheline set, called by the Copy function
  virtual CacheLineSet * CreateCacheLineSet(unsigned int nr_of_cache_lines) = 0;
				
  // ---------------------------------
  // Internal functions
  // ---------------------------------

  // To get all memory blocks in the instr cache line set as a set
  void AllMemoryBlockNrs(std::set<unsigned int> * memory_block_nrs) const;
      
  // To get the cacheline nr of a certain memory block
  // We number the cachelines 0..._nr_of_cache_lines-1.
  // Returns _nr_of_cache_lines if it is not found.
  unsigned int CacheLineNrOfMemoryBlock(unsigned int memory_block) const;

  // ---------------------------------
  // Internal variables
  // ---------------------------------
 
  // The set is really implemented as a vector of cache lines since we
  // need to keep an order between the elements. Each cache line holds
  // zero, one or more memory blocks.
  std::vector<CacheLine *> * _cache_lines;
  
  unsigned int _nr_of_cache_lines;
};

#endif
