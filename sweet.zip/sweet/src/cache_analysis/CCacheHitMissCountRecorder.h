/* -*-c++-*- */

//----------------------------------------------------------------------
//
// THIS FILE: A recorder which keeps track of the number of hits and
// misses of a given cache for a certain instruction represented by a
// ecfg node. We will have one recorder per cache. Since the cache may
// be shared data and instructions hits and misses may be kept track
// of. The recorder will ask the state of the content of the abstract
// cache(s) corresponding to cache with the given characteristics.
//
// ----------------------------------------------------------------------

#ifndef CCacheHitMissCountRecorder_H_
#define CCacheHitMissCountRecorder_H_

// Includes
#include "cache_analysis/CacheCharacteristics.h"
#include "cache_analysis/StateWithCacheState.h"
#include "cache_analysis/StmtToInstrAndDataAddresses.h"
#include "program_state/State.h"
#include "graphs/ecfg/CECFGNode.h"
#include "ae/CRecorder.h"
#include "ae/CCollector.h"
#include "ae/CIntegerRange.h"
#include <map>

// -------------------------------------------------------
//
// CCacheHitMissCountRecorder 
//
// -------------------------------------------------------
class CCacheHitMissCountRecorder : public CRecorder
{
public:

  //----------------------------------
  // Creation and deletion.
  //----------------------------------

  // The recorder will ask the state if the current instruction/data is in the cache or not.
  // To do this a lot of details of the corresponding cache must be provided.
  CCacheHitMissCountRecorder(CacheCharacteristics::CACHE_TYPE cache_type, 
			     CacheCharacteristics::CACHE_LEVEL cache_level,
			     CacheCharacteristics::REPLACEMENT_STRATEGY replacement_strategy,
			     StmtToInstrAndDataAddresses * stmt_to_instr_and_data_addresses);
  virtual ~CCacheHitMissCountRecorder(void);

  //----------------------------------
  // To update the recorder with a new execution of a node
  //---------------------------------
  void UpdateWithProgramCounterChange(State * abs_state, CECFGNode * pc_before, CECFGNode * pc_after);
  void UpdateWithProgramExit(State * abs_state, CECFGNode * pc_before);
  // These functions should not be called, but musat be exported by the class
  void UpdateWithProgramCounterChange(CECFGNode * pc_before, CECFGNode * pc_after) { assert(0); };
  void UpdateWithProgramExit(CECFGNode * pc_before) { assert(0); };


  //----------------------------------
  // To merge two recorders (LUB)
  //---------------------------------
  CRecorder * Merge(CRecorder * other_recorder);

  // ---------------------------------
  // To copy two recorders
  // ---------------------------------
  CRecorder * Copy();

  // ---------------------------------
  // Reset recorder. Will remove all mappings.
  // ---------------------------------
  void Reset();

  // ---------------------------------
  // For printing the recorder
  // ---------------------------------
  void Print(std::ostream * o = &std::cout) { /* Code should be added */ };

protected:

  // ---------------------------------
  // Specialized functions
  // ---------------------------------

  // To update the recorder with a ecfg node 
  void UpdateWithProgramCounterChange(StateWithCacheState * abs_state, CECFGNode * pc_before, CECFGNode * pc_after);
  void UpdateWithProgramExit(StateWithCacheState * abs_state, CECFGNode * pc_before);

  // To merge two recorders
  CCacheHitMissCountRecorder * Merge(CCacheHitMissCountRecorder * other_recorder);

  // To update the range of a given node. This is made by incrementing
  // the lower and upper values of the range according to incr args.
  void AddToRange(CECFGNode * node, std::map<CECFGNode *, CIntegerRange *> * node_to_range, int l_incr, int u_incr);  

  // Help function for merging the content of two node to range count
  // maps into a new map.
  void MergeMaps(std::map<CECFGNode *, CIntegerRange*> * node_to_range1, 
		 std::map<CECFGNode *, CIntegerRange*> * node_to_range2, 
		 std::map<CECFGNode *, CIntegerRange*> * new_node_to_range);

  // Help function for copying teh content of a map to a new map.
  void CopyMap(std::map<CECFGNode *, CIntegerRange*> * node_to_range, 
	       std::map<CECFGNode *, CIntegerRange*> * new_node_to_range);

  // Help function for resetting a mapping
  void ResetMap(std::map<CECFGNode *, CIntegerRange*> * node_to_range);

  // For each node we keep track on the number of instruction and data
  // hits or misses that its corresponding assembler addresses might
  // result in. This is implemented as several mappings. We keep track
  // of both instruction and data at the same time since we might have
  // shared caches.
  std::map<CECFGNode *, CIntegerRange*> _node_to_ihit;
  std::map<CECFGNode *, CIntegerRange*> _node_to_imiss;
  std::map<CECFGNode *, CIntegerRange*> _node_to_dhit;
  std::map<CECFGNode *, CIntegerRange*> _node_to_dmiss;

  // Variables holding the characteristics of the abstract cache state
  CacheCharacteristics::CACHE_TYPE _cache_type;
  CacheCharacteristics::CACHE_LEVEL _cache_level;
  CacheCharacteristics::REPLACEMENT_STRATEGY _replacement_strategy;

  // A mapper between stmts to instr and data adresses
  StmtToInstrAndDataAddresses * _stmt_to_instr_and_data_addresses;

};

#endif 
