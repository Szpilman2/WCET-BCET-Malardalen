#include "cache_analysis/CCacheHitMissCountRecorder.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include <vector>

// We need to keep track of the number of cache hits and miesses 
// that result from each instruction.

// Each instruction is represented by an CECFGNode.
// Each ALF instruction may access 0 or more assembler instruction addresses.
  // 
  // We keep either track of the number of hits or the number of misses to a certain instruction.

  // alf_instruction -> one ass instructions -> set of memory blocks -> <mb1,hit>,<mb2,miss>


  // For an cache analysis hit/miss recorder we have that the CECFGNode
  // represent an ALF instruction. To each ALF instruction we can, using
  // an AlfStmtToAddresses derive an ordered vector of assembler
  // addresses (normally just one). Each address correspond to one or
  // more memory blocks (can the amount change dynamically for data
  // caches?).



//----------------------------------
// Creation of recorder
//----------------------------------
CCacheHitMissCountRecorder::
CCacheHitMissCountRecorder(CacheCharacteristics::CACHE_TYPE cache_type, 
			   CacheCharacteristics::CACHE_LEVEL cache_level,
			   CacheCharacteristics::REPLACEMENT_STRATEGY replacement_strategy,
			   StmtToInstrAndDataAddresses * stmt_to_instr_and_data_addresses)
// Set internal variables
: _cache_type(cache_type), 
  _cache_level(cache_level),
  _replacement_strategy(replacement_strategy),
  _stmt_to_instr_and_data_addresses(stmt_to_instr_and_data_addresses)
{
  // Do nothing
}

//----------------------------------
// Deletion of recorder
//----------------------------------
CCacheHitMissCountRecorder::
~CCacheHitMissCountRecorder(void)
{
  // Remove all ranges in all maps
  Reset();

  // The actual maps will delete themselves
}  

//----------------------------------
// To update the recorder with a new execution of a node
//---------------------------------
void
CCacheHitMissCountRecorder::
UpdateWithProgramCounterChange(State * abs_state, CECFGNode * pc_before, CECFGNode * pc_after)
{
  // Check if we can get the right type of abstract state
  StateWithCacheState * abs_state_with_cache_state =
    dynamic_cast<StateWithCacheState *>(abs_state);
  assert(abs_state_with_cache_state);

  // Update recorder with program counter change 
  UpdateWithProgramCounterChange(abs_state_with_cache_state, pc_before, pc_after);
}

void
CCacheHitMissCountRecorder::
UpdateWithProgramExit(State * abs_state, CECFGNode * pc_before)
{
  // Do nothing
}


//----------------------------------
// To update the cache miss hit count recorders with the ECFG node change.
// The update will be made according to the content of the cache MUST and 
// MAY analyses. Holds code for updating both instruction and data miss hit 
// counts, since we might have shared caches 
// ---------------------------------  
void
CCacheHitMissCountRecorder::
UpdateWithProgramCounterChange(StateWithCacheState * abs_state, CECFGNode * pc_before, CECFGNode * pc_after)
{
  // Get the must and may cache states corresponding to the cache characteristics
  const AbsCacheState * must_cache_state = abs_state->GetCacheState(_cache_type, _cache_level, _replacement_strategy, AbsCacheState::MUST);
  const AbsCacheState * may_cache_state = abs_state->GetCacheState(_cache_type, _cache_level, _replacement_strategy, AbsCacheState::MAY);

  // Get the statement that will be accessed in the following program point
  CGenericStmt * stmt = pc_after->GetFlowGraphNode()->Stmt();
  assert(stmt);

  // ---------------------------------
  // Instructions
  // ---------------------------------

  // If instructions are stored in the cache 
  if(_cache_type == CacheCharacteristics::INSTR || _cache_type == CacheCharacteristics::SHARED) {
    
    // To hold the addresses accessed
    std::vector<std::pair<unsigned int, unsigned int> > instr_address_size_pairs;
    
    // Get the instruction addresses accessed
    _stmt_to_instr_and_data_addresses->GetInstrAddresses(stmt, &instr_address_size_pairs);

    // If i's memory blocks are in the MUST cache state we should
    // perform i_hit = 1..1 + i_hit
    if(must_cache_state->HasAddresses(&instr_address_size_pairs)) {
      AddToRange(pc_after, &_node_to_ihit, 1, 1);
      // Make sure that the stmt also is in the MAY state
      assert(may_cache_state->HasAddresses(&instr_address_size_pairs));
    }
    // If i's memory blocks not are in the MUST cache state, but in the MAY 
    // state we should perform i_hit = 0..1 + i_hit and i_miss = 0..1 + i_miss
    else if(may_cache_state->HasAddresses(&instr_address_size_pairs)) {
     AddToRange(pc_after, &_node_to_ihit, 0, 1);
     AddToRange(pc_after, &_node_to_imiss, 0, 1);
    } 

    // if i's memory block not is in MAY it must be a miss
    else {
      AddToRange(pc_after, &_node_to_imiss, 0, 1);
    } 
  }

  // ---------------------------------
  // Data
  // ---------------------------------
  
  // If data are stored in the cache 
  if(_cache_type == CacheCharacteristics::DATA || _cache_type == CacheCharacteristics::SHARED) {
    
    // To hold the addresses accessed
    std::vector<std::pair<unsigned int, unsigned int> > data_address_size_pairs;

    // Get the data addresses accessed
    _stmt_to_instr_and_data_addresses->GetDataAddresses(stmt, abs_state, &data_address_size_pairs);
    
    // If i's memory blocks are in the MUST cache state we should
    // perform d_hit = 1..1 + d_hit
    if(must_cache_state->HasAddresses(&data_address_size_pairs)) {
      AddToRange(pc_after, &_node_to_dhit, 1, 1);
      // Make sure that the stmt also is in the MAY state
      assert(may_cache_state->HasAddresses(&data_address_size_pairs));
    }
    // If i's memory blocks not are in the MUST cache state, but in the MAY 
    // state we should perform d_hit = 0..1 + d_hit and d_miss = 0..1 + d_miss
    else if(may_cache_state->HasAddresses(&data_address_size_pairs)) {
     AddToRange(pc_after, &_node_to_dhit, 0, 1);
     AddToRange(pc_after, &_node_to_dmiss, 0, 1);
    } 

    // if i's memory block not is in MAY it must be a miss
    else {
      AddToRange(pc_after, &_node_to_dmiss, 0, 1);
    } 
  }

  // ** Do we need to handle somehow that instr and data may be mapped
  // to the same memory block? **
  
  // The maps have been updated, return
  return;
}

//----------------------------------
// Will add l_incr..u_incr to the old range for a given node. If the
// range not existed it will create a new range.
//----------------------------------
void
CCacheHitMissCountRecorder::
AddToRange(CECFGNode * node, std::map<CECFGNode *, CIntegerRange *> * node_to_range, int l_incr, int u_incr)
{
  // Check if the node exists since before
  if(node_to_range->find(node) == node_to_range->end()) {
    // Nope, create and set the range
    CIntegerRange* new_range = new CIntegerRange(l_incr, u_incr);
    (*node_to_range)[node] = new_range; 
  }
  else {
    // Yes, add l_incr..u_incr to the old range value
    CIntegerRange* old_range = (*node_to_range)[node];
    int64_t new_l = old_range->L() + l_incr;
    int64_t new_u = old_range->U() + u_incr;
    CIntegerRange* new_range = new CIntegerRange(new_l, new_u);
    delete old_range;
    (*node_to_range)[node] = new_range;
  }
}

//----------------------------------
// Merge two recorders
//---------------------------------
CRecorder *
CCacheHitMissCountRecorder::
Merge(CRecorder * other_recorder)
{
  // Call the more specialized method
  return Merge(dynamic_cast<CCacheHitMissCountRecorder *>(other_recorder));
}

//----------------------------------
// Merge two cache hit miss recorders
//---------------------------------
CCacheHitMissCountRecorder *
CCacheHitMissCountRecorder::
Merge(CCacheHitMissCountRecorder * other_recorder)
{
  // Create a new recorder with empty mappings
  CCacheHitMissCountRecorder * new_recorder = 
    new CCacheHitMissCountRecorder(_cache_type, _cache_level, _replacement_strategy, _stmt_to_instr_and_data_addresses);
  
  // Merge the different mappings into the new recorder's corresponding mapping
  MergeMaps(&(this->_node_to_ihit), &(other_recorder->_node_to_ihit), &(new_recorder->_node_to_ihit));
  MergeMaps(&(this->_node_to_imiss), &(other_recorder->_node_to_imiss), &(new_recorder->_node_to_imiss));
  MergeMaps(&(this->_node_to_dhit), &(other_recorder->_node_to_dhit), &(new_recorder->_node_to_dhit));
  MergeMaps(&(this->_node_to_dmiss), &(other_recorder->_node_to_dmiss), &(new_recorder->_node_to_dmiss));
  
  // We are done, return the new recorder
  return new_recorder;
}

// Help function for merging the content of two node to range count
// maps into a new map.
void
CCacheHitMissCountRecorder::
MergeMaps(std::map<CECFGNode *, CIntegerRange*> * node_to_range1, 
	  std::map<CECFGNode *, CIntegerRange*> * node_to_range2, 
	  std::map<CECFGNode *, CIntegerRange*> * new_node_to_range)
{
  // Loop through the first mapping
  for(std::map<CECFGNode *, CIntegerRange*>::iterator n2r1 = node_to_range1->begin();
      n2r1 != node_to_range1->end(); ++n2r1) {

    // Get the node and the range
    CECFGNode * node = (*n2r1).first;
    CIntegerRange* range1 = (*n2r1).second;
     
    // Check if the second map has a range for the node
    if(node_to_range2->find(node) == node_to_range2->end()) {

      // No range, this means that the node has not been
      // taken in the other state
      
      // Create a [0..0] range
      CIntegerRange* zero_range = new CIntegerRange(0,0);

      // Merge the current range with the zero range
      CIntegerRange* new_range = range1->Merge(zero_range);
      
      // Delete the temporary range
      delete zero_range;

      // Add the new range to the recorder for the node
      (*new_node_to_range)[node] = new_range;
    }
    else {

      // Get the range of the other map
      CIntegerRange* range2 = (*node_to_range2)[node];

      // Merge ranges
      CIntegerRange* new_range = range1->Merge(range2);

      // Add the new range to the recorder for the node
      (*new_node_to_range)[node] = new_range;
    }
  }
  
  // Loop through the second mapping
  for(std::map<CECFGNode *, CIntegerRange*>::iterator n2r2 = node_to_range2->begin();
      n2r2 != node_to_range2->end(); ++n2r2) {

    // Get the node and the range
    CECFGNode * node = (*n2r2).first;
    CIntegerRange* range2 = (*n2r2).second;

    // Check if the first map has a range for the node
    if(node_to_range1->find(node) == node_to_range1->end()) {

      // No range, this means that the node has not been
      // taken in the other state. The case that both maps
      // has the node has been handled in first loop.
      
      // Create a [0..0] range
      CIntegerRange* zero_range = new CIntegerRange(0,0);

      // Merge the current range with the zero range
      CIntegerRange* new_range = range2->Merge(zero_range);
      
      // Delete the temporary range
      delete zero_range;

      // Add the new range to the recorder for the node
      (*new_node_to_range)[node] = new_range;
    }
  }

  // We are done, return the updated map
}

//----------------------------------
// Copy the recorder
//---------------------------------
CRecorder *
CCacheHitMissCountRecorder::
Copy()
{
  // Create a new recorder with empty mappings
  CCacheHitMissCountRecorder * new_recorder = 
    new CCacheHitMissCountRecorder(_cache_type, _cache_level, _replacement_strategy, _stmt_to_instr_and_data_addresses);

  // Copy the different mappings into the new recorder's corresponding mapping
  CopyMap(&(this->_node_to_ihit), &(new_recorder->_node_to_ihit));
  CopyMap(&(this->_node_to_imiss), &(new_recorder->_node_to_imiss));
  CopyMap(&(this->_node_to_dhit), &(new_recorder->_node_to_dhit));
  CopyMap(&(this->_node_to_dmiss), &(new_recorder->_node_to_dmiss));
  
  // We are done, return the new recorder
  return new_recorder;
}

// Help function for copying the conent of a map to a new map
void
CCacheHitMissCountRecorder::
CopyMap(std::map<CECFGNode *, CIntegerRange*> * node_to_range, 
	std::map<CECFGNode *, CIntegerRange*> * new_node_to_range)
{
  // Go through all the node to range mappings, copy the ranges and
  // create new mappings
  for(std::map<CECFGNode *, CIntegerRange*>::iterator n2r = node_to_range->begin();
      n2r != node_to_range->end(); ++n2r) {
      CECFGNode * node = (*n2r).first;
      CIntegerRange* range = (*n2r).second;
      CIntegerRange* new_range = range->Copy();
      (*new_node_to_range)[node] = new_range;
    }

  // We are done the mapping has been updated
  return;
}


//----------------------------------
// Reset the recorder
//---------------------------------
void
CCacheHitMissCountRecorder::
Reset()
{
  // Call the more specialized functions
  ResetMap(&_node_to_ihit);
  ResetMap(&_node_to_imiss);
  ResetMap(&_node_to_dhit);
  ResetMap(&_node_to_dmiss);
}


// Reset a map by removing all ranges and all mappings
void
CCacheHitMissCountRecorder::
ResetMap(std::map<CECFGNode *, CIntegerRange*> * node_to_range)
{
  // Delete all the ranges in the map
  for(std::map<CECFGNode *, CIntegerRange*>::iterator n2r = node_to_range->begin();
      n2r != node_to_range->end(); ++n2r) {
    delete (*n2r).second;
  }

  // Remove all the mappings
  node_to_range->erase(node_to_range->begin(), node_to_range->end());
}


