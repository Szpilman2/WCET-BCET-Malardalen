#include "cache_analysis/AbsCacheState.h"
#include <assert.h>
#include "cache_analysis/CacheLineSetMust.h"
#include "cache_analysis/CacheLineSetMay.h"

//----------------------------------------------------------------------
//
// AbsCacheState 
//
//----------------------------------------------------------------------

AbsCacheState::
AbsCacheState(const CacheCharacteristics * cache_characteristics, ANALYSIS_TYPE analysis_type, 
	      std::vector<CacheLineSet *> * cache_line_sets)
: _cache_characteristics(cache_characteristics),
  _analysis_type(analysis_type)
{
  assert(_cache_characteristics);

  // Get the number of cacheline sets
  unsigned int nr_of_cache_line_sets = _cache_characteristics->GetNrOfCacheLineSets();

  // Get the number of cache lines in each cache line set
  unsigned int nr_of_cache_lines_in_cache_line_set = _cache_characteristics->GetNrOfCacheLinesInCacheLineSet();
  
  // Allocate the cache line sets if not given
  if(cache_line_sets != NULL) {
    _cache_line_sets = cache_line_sets;
  }
  else {
    _cache_line_sets = new std::vector<CacheLineSet *>;
    for(unsigned int i = 0; i < nr_of_cache_line_sets; i++) {
      if(AbsCacheState::MUST == analysis_type)
	_cache_line_sets->push_back(new CacheLineSetMust(nr_of_cache_lines_in_cache_line_set));
      else if(AbsCacheState::MAY == analysis_type)
	_cache_line_sets->push_back(new CacheLineSetMay(nr_of_cache_lines_in_cache_line_set));
      else
	assert(0);
    }
  }
}

AbsCacheState::
~AbsCacheState()
{
  // Get the number of cacheline sets
  unsigned int nr_of_cache_line_sets = _cache_characteristics->GetNrOfCacheLineSets();

  // We should delete all cache line sets in the vector
  for(unsigned int i = 0; i < nr_of_cache_line_sets; i++) {
    delete (*_cache_line_sets)[i];
  }

  // Finally, we delete the vector itself
  delete _cache_line_sets;
}

AbsCacheState * 
AbsCacheState::
Copy() const
{
  // Get the number of cacheline sets
  unsigned int nr_of_cache_line_sets = _cache_characteristics->GetNrOfCacheLineSets();

  // Create a new vector of cache line sets where each element is a copy of the old one
  std::vector<CacheLineSet *> * cache_line_sets = new std::vector<CacheLineSet *>;
  for(unsigned int i = 0; i < nr_of_cache_line_sets; i++) {
    cache_line_sets->push_back((*_cache_line_sets)[i]->Copy());
  }
  
  // Return the new cache state
  return new AbsCacheState(_cache_characteristics, _analysis_type, cache_line_sets);
}

bool
AbsCacheState::
IsEqual(AbsCacheState * other_state) const
{
  // Get the number of cacheline sets
  unsigned int nr_of_cache_line_sets = _cache_characteristics->GetNrOfCacheLineSets();

  // Two states are equal if all of their cache line states are equal
  for(unsigned int i = 0; i < nr_of_cache_line_sets; i++) {
    CacheLineSet * cache_line_set1 = (*_cache_line_sets)[i];
    CacheLineSet * cache_line_set2 = (*(other_state->_cache_line_sets))[i];
    if(!cache_line_set1->IsEqual(cache_line_set2))
      return false;
  }
  return true;
}

AbsCacheState * 
AbsCacheState::
LUB(const AbsCacheState * other_state) const
{
  // Get the number of cacheline sets
  unsigned int nr_of_cache_line_sets = _cache_characteristics->GetNrOfCacheLineSets();

  // Create a new vector of cache line sets where each element is a join of cache line sets 
  std::vector<CacheLineSet *> * cache_line_sets = new std::vector<CacheLineSet *>;
  for(unsigned int i = 0; i < nr_of_cache_line_sets; i++) {
    CacheLineSet * cache_line_set1 = (*_cache_line_sets)[i];
    CacheLineSet * cache_line_set2 = (*(other_state->_cache_line_sets))[i];
    CacheLineSet * joined_cache_line_set = cache_line_set1->Join(cache_line_set2);
    cache_line_sets->push_back(joined_cache_line_set);
  }  

  // Return the new cache state
  return new AbsCacheState(_cache_characteristics, _analysis_type, cache_line_sets);
}

// void
// AbsCacheState::
// UpdateWithInstrAddresses(const std::vector<std::pair<unsigned int, unsigned int > > * instr_address_size_pairs)
// {
//   // Skip updating cache if it is a data cache 
//   if(_cache_characteristics->GetCacheType() == CacheCharacteristics::DATA)
//     return;
  
//   // It is a shared or a instr cache
//   assert(_cache_characteristics->GetCacheType() == CacheCharacteristics::INSTR ||
// 	 _cache_characteristics->GetCacheType() == CacheCharacteristics::SHARED);

//   // Call the real update function
//   UpdateWithAddresses(instr_address_size_pairs);
// }

// void
// AbsCacheState::
// UpdateWithDataAddresses(const std::vector<std::pair<unsigned int, unsigned int > > * data_address_size_pairs)
// {
//   // Skip updating cache if it is a data cache 
//   if(_cache_characteristics->GetCacheType() == CacheCharacteristics::INSTR)
//     return;
  
//   // It is a shared or a data cache
//   assert(_cache_characteristics->GetCacheType() == CacheCharacteristics::DATA ||
// 	 _cache_characteristics->GetCacheType() == CacheCharacteristics::SHARED);

//   // Call the real update function
//   UpdateWithAddresses(data_address_size_pairs);
// }

// ** Should we maybe collect all addresses that goes to the same cache line and make a joined update?
void
AbsCacheState::
UpdateWithAddresses(const std::vector<std::pair<unsigned int, unsigned int > > * address_size_pairs)
{
  // Get the memory blocks the addresses belongs to
  std::vector<unsigned int> memory_block_nrs;
  _cache_characteristics->GetMemoryBlockNrsOfAddresses(address_size_pairs, &memory_block_nrs);

  // Loop over all the memory blocks (the order is important!)
  for(std::vector<unsigned int>::const_iterator mbn = memory_block_nrs.begin();
      mbn != memory_block_nrs.end(); mbn++) {

    // Get the number of the cache line set the memory block belongs to
    unsigned int cache_line_set_nr = _cache_characteristics->GetCacheLineSetNrOfMemoryBlock(*mbn);
    
    // Get the corresponding cache line set
    CacheLineSet * cache_line_set = (*_cache_line_sets)[cache_line_set_nr];

    // Update the cache line set with the memory block
    switch(_cache_characteristics->GetReplacementStrategy())
      {
      case CacheCharacteristics::LRU:
	// We should update for Least Recently Used
	cache_line_set->UpdateForLRU(*mbn);
	break;
      case CacheCharacteristics::FIFO:
	// We should update for FIFO
	cache_line_set->UpdateForFIFO(*mbn);
	break;
      default:
	assert(0);
      }
  }
}
  
// bool
// AbsCacheState::
// HasInstrAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * instr_address_size_pairs)
// {
//   // Not true if it is a data cache 
//   if(_cache_characteristics->GetCacheType() == CacheCharacteristics::DATA)
//     return false;
  
//   // It is a shared or a instr cache
//   assert(_cache_characteristics->GetCacheType() == CacheCharacteristics::INSTR ||
// 	 _cache_characteristics->GetCacheType() == CacheCharacteristics::SHARED);

//   // Call the real function
//   return HasAddresses(instr_address_size_pairs);
// }

// bool
// AbsCacheState::
// HasDataAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * data_address_size_pairs)
// {
//   // Not true if it is an instr cache 
//   if(_cache_characteristics->GetCacheType() == CacheCharacteristics::INSTR)
//     return false;
  
//   // It is a shared or a data cache
//   assert(_cache_characteristics->GetCacheType() == CacheCharacteristics::DATA ||
// 	 _cache_characteristics->GetCacheType() == CacheCharacteristics::SHARED);

//   // Call the real function
//   return HasAddresses(data_address_size_pairs);
// }

bool
AbsCacheState::
HasAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * address_size_pairs) const
{
  // Get the memory blocks the addresses belongs to
  std::vector<unsigned int> memory_block_nrs;
  _cache_characteristics->GetMemoryBlockNrsOfAddresses(address_size_pairs, &memory_block_nrs);

  // Loop over all the memory blocks to see if each block is in a cache line set
  for(std::vector<unsigned int>::const_iterator mbn = memory_block_nrs.begin();
      mbn != memory_block_nrs.end(); mbn++) {

    // Get the number of the cache line set the memory block belongs to
    unsigned int cache_line_set_nr = _cache_characteristics->GetCacheLineSetNrOfMemoryBlock(*mbn);
    
    // Get the corresponding cache line set
    CacheLineSet * cache_line_set = (*_cache_line_sets)[cache_line_set_nr];

    if(!cache_line_set->HasMemoryBlock(*mbn))
      return false;
  }
  
  // All memory blocks where in some cache line set
  return true;
}

// To print the cache state 
void
AbsCacheState ::
Print(std::ostream & s)
{
  // Print the cache characteristics
  _cache_characteristics->Print(s);

  // Get the number of cacheline sets
  unsigned int nr_of_cache_line_sets = _cache_characteristics->GetNrOfCacheLineSets();

  // Go through all the cachelines and print each of them
  for(unsigned int i = 0; i < nr_of_cache_line_sets; i++)
    {
      (s) << "cache line set: " << i << std::endl;
      (*_cache_line_sets)[i]->Print(s);
      (s) << std::endl;
    }
  // We are done
  return;
}

// To draw the cache state 
void
AbsCacheState ::
Draw(std::ostream & s)
{
  // Get the number of cacheline sets
  unsigned int nr_of_cache_line_sets = _cache_characteristics->GetNrOfCacheLineSets();

  // Go through all the cachelines and draw each of them
  for(unsigned int i = 0; i < nr_of_cache_line_sets; /* Intentionally empty */)
    {
      // Draw the cacheline set
      (*_cache_line_sets)[i]->Draw(s);
      i++;

	// Print two || between all instruction cache line sets
      if(i != nr_of_cache_line_sets) {
	(s) << " || ";
      }
    }
  // We are done
  return;
}

