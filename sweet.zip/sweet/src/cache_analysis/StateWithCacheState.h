#include "program_state/State.h"
#include "cache_analysis/CacheCharacteristics.h"
#include "cache_analysis/AbsCacheState.h"
#include <vector>
#include <memory>

class ProgramCounterECFG;
class PPEnviron;

//----------------------------------------------------------------------
//
// StateWithCacheState
// -- Abstract state which additionally to the normal abstract values 
//    also holds one or more abstract cache states. 
// -- Overloads State therby getting all the abstract value handling
//    provided by this class.
// -- Supports MUST, MAY and PERS analysis of instruction and data caches.
//
// *** We should later on add support for multilevel caches ****
//
//----------------------------------------------------------------------

class StateWithCacheState : public State
{
public: 

  // ---------------------------------
  // To create and delete the state. We can have several cache states associated with an 
  // abstract state. Will assert if there are more than one cache state that has identical cache type, 
  // level, replacement strategy, and analysis type.
  // ---------------------------------
  StateWithCacheState(std::unique_ptr<ProgramCounterECFG> pc, std::unique_ptr<PPEnviron> pp_environ,
                      const std::vector<std::pair<CacheCharacteristics *, AbsCacheState::ANALYSIS_TYPE > > * cache_analyses,
                      bool is_bottom = false);
  virtual ~StateWithCacheState();

  // ---------------------------------
  // To get a certain cache analysis state. Returns NULL if no such
  // cache analysis is performed. A call might look like:
  // state->GetCacheState(CacheCharacteristics::INSTR, CacheCharacteristics::L1, 
  //                      CacheCharacteristics::LRU, AbsCacheState::MUST);
  // ---------------------------------
  const AbsCacheState * GetCacheState(CacheCharacteristics::CACHE_TYPE cache_type, 
				      CacheCharacteristics::CACHE_LEVEL cache_level,
				      CacheCharacteristics::REPLACEMENT_STRATEGY replacement_strategy,
				      AbsCacheState::ANALYSIS_TYPE analysis_type) const;

  // ---------------------------------
  // Things that should be overloaded. Basically updating the included abstract cache states 
  // accordingly, and then calls the parent function to update the abstract ALF state. 
  // ---------------------------------
  
  // To get a deep copy of the abstract state
  State * Copy() const;  
  
  // To check if two states are equal
  bool IsEqual(const State* other) const;

  // To take union and intersection of two states
  State* LUB(const State* state2) const;
  // State* GLB(const State* state2) const;

  // To perform widening and narrowing of two states
  // State* Widening(const State* state2) const; 
  // State* Narrowing(const State* state2) const;

  std::ostream & Print(std::ostream & os) const;
  std::ostream & Draw(std::ostream & os) const;
  
  // ---------------------------------
  // To update included cache states we addresses
  // ---------------------------------
  void UpdateCacheStatesWithInstrAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * instr_address_size_pairs);
  void UpdateCacheStateWithDataAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * data_address_size_pairs);

protected:

  // To make a deep copy of another state
  StateWithCacheState(const StateWithCacheState & other);

  // To create a state with all included parts (used by LUB, GLB, etc)
  StateWithCacheState(std::unique_ptr<ProgramCounterECFG> pc, cheap_copy<VarEnviron> genv,
                      std::unique_ptr<Memory> mem, cheap_copy<CallStack> call_stack,
                      cheap_copy<PPEnviron> pp_environ, 
                      const std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, 
                      std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * > * keys_to_cache_state);

  // ---------------------------------
  // The cache analysis states are indexed upon their content 
  // and what type of analyses to be performed 
  // ---------------------------------
  std::map<std::pair<std::pair<CacheCharacteristics::CACHE_TYPE, CacheCharacteristics::CACHE_LEVEL>, 
                     std::pair<CacheCharacteristics::REPLACEMENT_STRATEGY, AbsCacheState::ANALYSIS_TYPE> >, AbsCacheState * > _keys_to_cache_state; 

};


