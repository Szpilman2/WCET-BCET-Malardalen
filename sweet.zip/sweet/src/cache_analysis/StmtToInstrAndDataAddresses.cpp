#include "cache_analysis/StmtToInstrAndDataAddresses.h"

// -------------------------------------------------------
//
//  StmtToInstrAndDataAddresses
//
// -------------------------------------------------------

StmtToInstrAndDataAddresses::
StmtToInstrAndDataAddresses() 
{
  // Do nothing
}

StmtToInstrAndDataAddresses::
~StmtToInstrAndDataAddresses() 
{
  // Do nothing
}


  

