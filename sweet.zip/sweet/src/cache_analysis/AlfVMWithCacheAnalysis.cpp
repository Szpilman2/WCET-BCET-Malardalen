#include "cache_analysis/AlfVMWithCacheAnalysis.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CDeclList.h"
#include "program/alf/CAllocTuple.h"
#include "program/CGenericFunction.h"

// -------------------------------------------------------
//
// AlfVMWithCacheAnalysis
//
// -------------------------------------------------------

// To create the VM
AlfVMWithCacheAnalysis::
AlfVMWithCacheAnalysis(std::unique_ptr<StmtToInstrAndDataAddresses> mapper)
  : _mapper(mapper.release())
{
  // Do nothing
}

// To delete the VM
AlfVMWithCacheAnalysis::
~AlfVMWithCacheAnalysis()
{
  // Do nothing
}  

// 
void
AlfVMWithCacheAnalysis::
InitializeState(const alf::CAlfTuple * program, const alf::CFuncTuple * start_function,
		StateWithCacheState * state, bool ignore_volatile,
		std::vector<unsigned> * keys_of_funcs_and_data_to_preload)
{
  // Check if globals should be preloaded into the cache
  if(keys_of_funcs_and_data_to_preload != NULL) {
    // Get the symbol table from the program 
    const CSymTabBase * symbol_table = program->GetSymTab();
    // Process all the keys
    for(std::vector<unsigned>::const_iterator key = keys_of_funcs_and_data_to_preload->begin();
	key != keys_of_funcs_and_data_to_preload->end(); key++) {
      // Get the symbol table entry of the given key
      const CSymTabEntry * ste = symbol_table->Lookup(*key);

      // Check if key corresponds to a function
      if(ste->IsFunction()) {
	// Get the corresponding function
	CGenericFunction * func = ste->GetCodeIdentifier()->GetFunction();
	// Get all the statements of the function
	std::vector<CGenericStmt*> stmts;
	func->Stmts(&stmts);
	// Go through all stmts and add each statement to the cache of the abstract state
	for(std::vector<CGenericStmt*>::iterator stmt = stmts.begin();
	    stmt != stmts.end(); stmt++) {
	  // Get the addresses of the stmt by the mapper
	  std::vector<std::pair<unsigned int, unsigned int> > instr_address_size_pairs;
	  _mapper->GetInstrAddresses(*stmt, &instr_address_size_pairs);
	  // Update the abstract cache states with the addresses 
	  state->UpdateCacheStatesWithInstrAddresses(&instr_address_size_pairs);	
	}
      }

      // Check if key corresponds to a global data 
      else if(ste->IsData() && ste->IsGlobal()) {
	// Find corresponding entry the in the program's list of declarations
	const alf::CDeclList * decls = program->GetDecls();
	for(alf::CDeclList::const_list_iterator di = decls->ConstIterator(); di != decls->InvalidIterator(); ++di) {
	  if((*di)->GetKey() == *key) {
       //	    Size frame_size = (*di)->GetFrameSize()->GetSizeInBits();
	    // Get the corresponding data (it must be a fref)

	    /************ ADD CODE *****************/
	    /************ ADD CODE *****************/

	    // CFRefTuple * fref = dynamic_cast<CFRefTuple *>(
	    //						   CGenericFunction * func = ste->GetIdentifier();
	  }
	}
      }
    }
    std::cout << "ERROR: Preloading of cache content not supported yet!\n";
    exit(1);
  }
  // Call parent class initialize function
  AlfVM::InitializeState(program, start_function, state, ignore_volatile);
}

void 
AlfVMWithCacheAnalysis::
StepStmt(std::unique_ptr<State> state, std::vector<State *> & next_states)
{
  /************ ADD CODE *****************/
  /************ ADD CODE *****************/
}


// void 
// AlfVMWithCacheAnalysis::
// InitializeState(const alf::CAlfTuple * program, const alf::CFuncTuple * start_function,
// 		CState * state, bool ignore_volatile, AlfStmtToAddressis * mapper,
// 		std::vector<std::pair<CacheCharacteristics * cc, AbsCacheState::ANALYSIS_TYPE> > * cache_analyses) const;
