#include "cache_analysis/CacheCharacteristics.h"
#include <assert.h>

// -------------------------------------------------------
// CacheCharacteristics
// -------------------------------------------------------

// To create and delete the state characteristics class
CacheCharacteristics::
CacheCharacteristics(unsigned int cache_size, unsigned int cache_line_size, 
		     unsigned int start_address_offset, unsigned int nr_of_cache_line_sets,
		     CACHE_LEVEL cache_level, CACHE_TYPE cache_type,
		     REPLACEMENT_STRATEGY replacement_strategy)
: _cache_size(cache_size),
  _cache_line_size(cache_line_size),
  _start_address_offset(start_address_offset),
  _nr_of_cache_line_sets(nr_of_cache_line_sets),
  _cache_level(cache_level),
  _cache_type(cache_type),
  _replacement_strategy(replacement_strategy)
{
  assert((_cache_size % cache_line_size) == 0);
  _nr_of_cache_lines = _cache_size / cache_line_size; 
}
		
unsigned int 
CacheCharacteristics::
GetCacheSize() const
{
  return _cache_size;
}
		
unsigned int 
CacheCharacteristics::
GetCacheLineSize() const
{
  return _cache_line_size;
}
		
unsigned int 
CacheCharacteristics::
GetStartAddressOffset() const
{
  return _start_address_offset;
}
		
unsigned int 
CacheCharacteristics::
GetNrOfCacheLineSets() const
{
  return _nr_of_cache_line_sets;
}

unsigned int 
CacheCharacteristics::
GetNrOfCacheLinesInCacheLineSet() const
{
  assert((_nr_of_cache_lines % _nr_of_cache_line_sets) == 0);
  return _nr_of_cache_lines / _nr_of_cache_line_sets;
}

CacheCharacteristics::CACHE_TYPE 
CacheCharacteristics::
GetCacheType() const
{
  return _cache_type;
}

CacheCharacteristics::CACHE_LEVEL 
CacheCharacteristics::
GetCacheLevel() const
{
  return _cache_level;
}

CacheCharacteristics::REPLACEMENT_STRATEGY 
CacheCharacteristics::
GetReplacementStrategy() const
{
  return _replacement_strategy;
}

void 
CacheCharacteristics::
GetMemoryBlockNrsOfAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * address_size_pairs, 
			     std::vector<unsigned int> * memory_block_nrs) const
{
  if(address_size_pairs->size() == 0) 
    return;

  for(std::vector<std::pair<unsigned int, unsigned int> >::const_iterator asp = address_size_pairs->begin();
      asp != address_size_pairs->end(); ++asp) {
    GetMemoryBlockNrsOfAddress(*asp, memory_block_nrs);
  }
}

void 
CacheCharacteristics::
GetMemoryBlockNrsOfAddress(std::pair<unsigned int, unsigned int> address_size_pair, 
			   std::vector<unsigned int> * memory_block_nrs) const
{
  // Get the address and size of the address 
  unsigned int address = address_size_pair.first;
  unsigned int size = address_size_pair.second;
  
  // Get the first memory block nr
  unsigned int first_memory_block_nr = (address - _start_address_offset) / _cache_line_size;
     
  // Get the last memoryblock nr
  unsigned int last_memory_block_nr = (address + size - _start_address_offset) / _cache_line_size;

  // Loop to get all memory blocks covered by the instruction
  for(int i = 0; first_memory_block_nr + i <= last_memory_block_nr; i++) {
    // Insert the memoryblock last in the vector
    memory_block_nrs->push_back(first_memory_block_nr + i);
  }
} 

unsigned int 
CacheCharacteristics::
GetCacheLineSetNrOfMemoryBlock(unsigned int memory_block_nr) const
{
  return memory_block_nr % _nr_of_cache_line_sets;
}

void
CacheCharacteristics::
Print(std::ostream & s) const
{
  (s) << "CACHE CHARACTERISTICS TO ADDED...." << std::endl;
}
