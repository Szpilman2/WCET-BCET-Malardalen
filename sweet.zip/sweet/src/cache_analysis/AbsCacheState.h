#ifndef ABSCACHESTATE_H_
#define ABSCACHESTATE_H_

#include <vector>
#include <string>
#include "cache_analysis/CacheCharacteristics.h"
#include "cache_analysis/CacheLineSet.h"

//----------------------------------------------------------------------
//
// AbsCacheState 
// -- Holds a set of cachelines.  
//
//----------------------------------------------------------------------
class AbsCacheState 
{
public:

  // Maybe add PERS analysis type?
  enum ANALYSIS_TYPE { MAY, MUST };

  // ---------------------------------
  // For creating and deleting the state
  // ---------------------------------
  AbsCacheState(const CacheCharacteristics * cache_characteristics, ANALYSIS_TYPE analysis_type,
		std::vector<CacheLineSet *> * cache_line_sets = NULL);
  virtual ~AbsCacheState();

  // ---------------------------------
  // For getting a copy of the cache state
  // ---------------------------------
  virtual AbsCacheState * Copy() const;

  // ---------------------------------
  // For checking if two cache states are equal 
  // ---------------------------------
  virtual bool IsEqual(AbsCacheState * other_state) const;

  // ---------------------------------
  // For joining and globing two cache states
  // ---------------------------------
  AbsCacheState * LUB(const AbsCacheState * other_state) const;
  // AbsCacheState * GLB(const AbsCacheState * other_state) const;

  // ---------------------------------
  // To update the cache line sets with some addresses
  // ---------------------------------
  void UpdateWithAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * address_size_pairs);

  // ---------------------------------
  // If all memory blocks that correspond to the given addresses are
  // in the cache we return true, otherwise false
  // ---------------------------------
  bool HasAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * address_size_pairs) const;

  // ---------------------------------
  // For printing and drawing a cache state
  // ---------------------------------
  void Print(std::ostream & s = std::cout);
  void Draw(std::ostream & s = std::cout);
  
private:

  // The set of cache lines. Will be created according to cache characteristics argument and 
  // the wanted analysis.
  const CacheCharacteristics * _cache_characteristics;
  std::vector<CacheLineSet *> * _cache_line_sets;
  ANALYSIS_TYPE _analysis_type;

  // **** The below functions should maybe be removed? ****

  // ---------------------------------
  // For updating the cache state with one or several instr or data
  // addresses.  Addresses not handled by the cache (as given by the
  // cache characteristics) will be ignored. If addresses should be
  // handled it will first derive which memory block and cachelineset
  // the instruction belongs to. Then it will call the Update()
  // function of the cachelineset.
  // ---------------------------------
  // void UpdateWithInstrAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * instr_address_size_pairs);
  // void UpdateWithDataAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * data_address_size_pairs);

  // ---------------------------------
  // To check if a given address is in the cache analysis state or
  // not. If the cache handles the given type of address, its
  // corresponding memory block(s) will be derived and each of them
  // will be checked if they are in the cache. If so, true will be
  // returned, otherwise false.  
  // ---------------------------------
  // bool HasInstrAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * instr_address_size_pairs);
  // bool HasDataAddresses(const std::vector<std::pair<unsigned int, unsigned int> > * data_address_size_pairs);

};

#endif
