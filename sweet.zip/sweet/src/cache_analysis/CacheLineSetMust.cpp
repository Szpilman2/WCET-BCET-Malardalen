#include "cache_analysis/CacheLineSetMust.h"

//----------------------------------------------------------------------
//
// CacheLineSetMust
//
//----------------------------------------------------------------------

// To create a must cacheline set
CacheLineSetMust::
CacheLineSetMust(unsigned int nr_of_cache_lines) 
 : CacheLineSet(nr_of_cache_lines)
{
  // Do nothing
}

// To delete a MUST cacheline set. Actual delete will be made in parent.
CacheLineSetMust ::
~CacheLineSetMust() 
{
  
}

// To create a new must cache line set
CacheLineSet *
CacheLineSetMust::
CreateCacheLineSet(unsigned int nr_of_cache_lines)
{
  return new CacheLineSetMust(nr_of_cache_lines);
}


// The real binary join function. Implements intersection + 
// maximal age
void
CacheLineSetMust::
InsertMemoryBlockNrAfterJoin(unsigned int memory_block_nr, unsigned int cache_line_nr1, unsigned int cache_line_nr2)
{
  // Get the largest cache line nr that is the largest
  unsigned int largest_cache_line_nr = cache_line_nr2;
  if(cache_line_nr1 > cache_line_nr2)
    largest_cache_line_nr = cache_line_nr1;

  // Check if the largest cacheline nr are outside the specified 
  // borders
  if(largest_cache_line_nr >= _nr_of_cache_lines)
    // Yes, do no insert
    return;

  // Insert the memoryblock at the largest cacheline
  GetCacheLine(largest_cache_line_nr)->AddMemoryBlockNr(memory_block_nr);
}

