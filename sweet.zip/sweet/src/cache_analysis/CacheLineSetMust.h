#ifndef CACHELINESETMUST_H_
#define CACHELINESETMUST_H_

#include "cache_analysis/CacheLineSet.h"

//----------------------------------------------------------------------
//
// CacheLineSetMust
// -- Implements a MUST cache analysis. Must functionality inher�ted 
//   from CacheLineSet. 
// -- MUST join means 1. intersection - both cachelines must have the
//   block if the resulting cacheline should have it, and 2. maximal
//   age - the block is inserted at the cacheline with the oldest age.
//
//----------------------------------------------------------------------
class CacheLineSetMust : public CacheLineSet
{
public:

  // To create and delete the cache line set
  CacheLineSetMust(unsigned int nr_of_cache_lines);
  virtual ~CacheLineSetMust();
  
  // To create a new cache line set. Virtual in parent class.
  CacheLineSet * CreateCacheLineSet(unsigned int nr_of_cache_lines);

protected:

  // To insert a memoryblock as the result of a join
  virtual void InsertMemoryBlockNrAfterJoin(unsigned int memory_block, 
					    unsigned int cache_line_nr1,
					    unsigned int cache_line_nr2);
};

#endif
