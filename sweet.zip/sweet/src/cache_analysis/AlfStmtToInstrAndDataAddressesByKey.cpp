#include "cache_analysis/AlfStmtToInstrAndDataAddressesByKey.h"

// -------------------------------------------------------
//
//  AlfStmtToInstrAndDataAddressesByKey
//
// -------------------------------------------------------

AlfStmtToInstrAndDataAddressesByKey::
AlfStmtToInstrAndDataAddressesByKey(unsigned int address_size)
  : _address_size(address_size)
{
  
}

AlfStmtToInstrAndDataAddressesByKey::
~AlfStmtToInstrAndDataAddressesByKey()
{
}

// Get the addresses from the instr corresponding to a stmt
void
AlfStmtToInstrAndDataAddressesByKey::
GetInstrAddressesOfStmt(const CGenericStmt * stmt, 
			std::vector<std::pair<unsigned int, unsigned int> > * instr_address_size_pairs) const
{
  // Check that the stmt can be converted to an alf stmt
  const alf::AStmt * alf_stmt = dynamic_cast<const alf::AStmt *>(stmt);
  assert(alf_stmt != NULL);

  GetAddressesOfKey(alf_stmt->Key(), instr_address_size_pairs);
}


// Get the addresses from the data accessed by a stmt
void
AlfStmtToInstrAndDataAddressesByKey::
GetDataAddressesOfStmt(const CGenericStmt * stmt, const State * state, 
		       std::vector<std::pair<unsigned int, unsigned int> > * data_address_size_pairs) const
{
  // Do nothing
}

// Get the addresses by the key
void
AlfStmtToInstrAndDataAddressesByKey::
GetAddressesOfKey(unsigned int stmt_key, std::vector<std::pair<unsigned int, unsigned int> > * address_size_pairs) const
{
  address_size_pairs->push_back(std::make_pair(stmt_key * _address_size, _address_size));
}



