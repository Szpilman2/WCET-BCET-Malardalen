#ifndef STMTTOINSTRANDDATAADDRESSES_H_
#define STMTTOINSTRANDDATAADDRESSES_H_

#include "program/CGenericStmt.h"
#include "program/alf/AStmt.h"
#include "program_state/State.h"
#include <vector>


// -------------------------------------------------------
//
// StmtToInstrAndDataAddresses -
// -- Class for getting what instruction addresses or data addresses
//    that a certain generic stmt corresponds to.
// -- Each function returns a vector since a statement may
//    correspond to several assembler addresses and each stmt may 
//    reference several data addresses.
// -- When looking up data addresses also the current state must be 
//    provided since the addresses touch by an instruction depends on
//    current variable values and how call stack looks like.  
// -- An instruction/data address is represented by a pair of integers, where 
//    the first integer is the address and the second one is the 
//    instruction/data size.
// 
// -------------------------------------------------------
class StmtToInstrAndDataAddresses
{
public:
  // To create and delete the class
  StmtToInstrAndDataAddresses();
  virtual ~StmtToInstrAndDataAddresses();

  // To get the instruction addresses of a certain stmt. The stmt 
  virtual void GetInstrAddresses(const CGenericStmt * stmt, 
				 std::vector<std::pair<unsigned int, unsigned int> > * instr_address_size_pairs) const = 0;
  
  // To get the data addresses which may be accessed by load and
  // stores in certain ALF stmt. Requires that an abstract state is
  // provided. This is because the data addresses we might access
  // depends on the addresses hold by variables in the current state.
  virtual void GetDataAddresses(const CGenericStmt * stmt, const State * state, 
				std::vector<std::pair<unsigned int, unsigned int> > * data_address_size_pairs) const = 0;

};

#endif
