#ifndef _OUT_ANN_SPEC_ALF_Y_H
#define _OUT_ANN_SPEC_ALF_Y_H
// $Id: out_ann_spec_ALF.h $

int out_ann_spec_ALF_parse(void *);

int out_ann_spec_ALF_lex_destroy(void );

#endif
