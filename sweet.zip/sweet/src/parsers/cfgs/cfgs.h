#ifndef CFGS_H_INCLUDED
#define CFGS_H_INCLUDED
// $Id: cfgs.h 3779 2011-12-20 09:02:57Z sbe01 $

int cfgs_parse(void *);
#include <stdio.h>

extern FILE *cfgs_in;

#endif
