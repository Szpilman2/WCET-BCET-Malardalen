#include "CParser.h"
#include "alf.y.hpp"
#include <cstdio>
#include <memory>

using namespace alf;
using namespace std;

CAlfTuple* CParser::ParseFile(string file)
{
   unique_ptr<CAlfTuple> ast;
   FILE* alf_file = fopen(file.c_str(), "r");
   alf_parse(alf_file, ast);
   alf_lex_destroy();
   fclose(alf_file);
   return ast.release();
}
