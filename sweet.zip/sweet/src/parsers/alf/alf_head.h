#include "program/alf/alf.h"
#include <string>
#include <cctype>
#include <stdexcept>

inline bool IsValidNumber(const std::string& number)
{
   const char* str = number.c_str();
   for (std::string::size_type i = 0, n = number.size(); i != n; ++i) {
      if (!isdigit(str[i]))
         return false;
   }
   return true;
}

inline bool IsValidHexNumber(const std::string& number)
{
   const char* str = number.c_str();
   for (std::string::size_type i = 0, n = number.size(); i != n; ++i) {
      if (!isxdigit(str[i]))
         return false;
   }
   return true;
}

inline bool IsValidBinaryNumber(const std::string& number)
{
   const char* str = number.c_str();
   for (std::string::size_type i = 0, n = number.size(); i != n; ++i) {
      if (str[i] != '0' && str[i] != '1')
         return false;
   }
   return true;
}

inline alf::AExpr* CreateAddrNode(alf::COORD coord, alf::CSize* size, alf::AExpr* fref, alf::AExpr* num)
{
   using namespace alf;

   // Is it the '{' 'addr' SIZE FREF OFFSET '}' rule?
   if (dynamic_cast<CFRefTuple*>(fref) != NULL && dynamic_cast<CIntNumValTuple*>(num) != NULL)
      return new CAddrTuple(coord, size, dynamic_cast<CFRefTuple*>(fref), dynamic_cast<CIntNumValTuple*>(num));
   else
      return new CCompAddrTuple(coord, size, fref, num);
}

inline alf::AExpr* CreateLabelNode(alf::COORD coord, alf::CSize* size, alf::AExpr* lref, alf::AExpr* num)
{
   using namespace alf;
   if (lref->IsType(CGenericNode::TYPE_LREF_TUPLE) && num->IsType(CGenericNode::TYPE_INTVAL_TUPLE))
      return new CLabelTuple(coord, size, (CLRefTuple*)lref, (CIntNumValTuple*)num);
   else
      return new CCompLabelTuple(coord, size, lref, num);
}

namespace alf {
class CParserHelper
{
public:
   static void AttachLabel(AStmt *stmt, CGenericNode *label)
   {
      stmt->label = &dynamic_cast<CLabelTuple&>(*label);
      stmt->SetParent(label);
   }

   static std::vector<AStmt*>* AttachLabels(const std::vector<CGenericNode*>& nodes)
   {
      unique_ptr<std::vector<AStmt*> > stmts( new std::vector<AStmt*> );
      CLabelTuple* label_node = NULL;
      for (std::vector<CGenericNode*>::size_type i = 0, n = nodes.size(); i != n; ++i)
      {
         CGenericNode* node = nodes[i];
         AStmt* stmt;

         if (node->IsType(CGenericNode::TYPE_LABEL_TUPLE))
         {
            if (label_node != NULL)
               throw std::logic_error("Found two labels after each other, expected a stmt, macrocall or macroformalarg.");

            label_node = dynamic_cast<CLabelTuple*>(node);
            continue;
         }
         else if (node->IsType(CGenericNode::TYPE_STMT))
            stmt = dynamic_cast<AStmt*>(node);
         else if (node->IsType(CGenericNode::TYPE_MACRO_CALL_TUPLE))
            stmt = new CUnknownStmt(node->GetCoord(), dynamic_cast<CMacroCallTuple*> (node));
         else if (node->IsType(CGenericNode::TYPE_MACRO_FORMAL_ARG))
            stmt = new CUnknownStmt(node->GetCoord(), dynamic_cast<CMacroFormalArg*> (node));
         else
            throw std::logic_error("Node with unsupported type found in CParserHelper::CreateStmtList, expected a label, stmt, macrocall or macroformalarg.");

         if (label_node) {
            stmt->label = label_node;
            stmt->SetParent(label_node);
            label_node = NULL;
         }
         else
            stmt->GenerateLabel();
         stmts->push_back(stmt);
      }

      return stmts.release();
   }
};
}

inline void SetAllowedTypesIfUnknown(alf::CGenericNode* node, const std::string& grammar_type)
{
   using namespace alf;
   if (node->IsType(CGenericNode::TYPE_UNKNOWN_EXPR))
   {
      std::vector<CGenericNode::TYPE> allowed_types;
      if (grammar_type == "FREF_EXPR")
      {
         allowed_types.push_back(CGenericNode::TYPE_FREF_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_DYNALLOC_EXPR_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_LOAD_EXPR_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE);
      }
      if (grammar_type == "LREF_EXPR")
      {
         allowed_types.push_back(CGenericNode::TYPE_LREF_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_LOAD_EXPR_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE);
      }
      else if (grammar_type == "NUM_EXPR")
      {
         allowed_types.push_back(CGenericNode::TYPE_INTVAL_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_FLOATVAL_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_OP_EXPR_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_LOAD_EXPR_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE);
      }
      else if (grammar_type == "LABEL_EXPR")
      {
         allowed_types.push_back(CGenericNode::TYPE_LABEL_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_OP_EXPR_TUPLE); //TODO: Only 'add' and 'sub', restrict this in some way?
         allowed_types.push_back(CGenericNode::TYPE_LOAD_EXPR_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE);
      }
      else if (grammar_type == "ADDR_EXPR")
      {
         allowed_types.push_back(CGenericNode::TYPE_ADDR_EXPR_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_COMPADDR_EXPR_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_OP_EXPR_TUPLE); //TODO: Only 'add' and 'sub', restrict this in some way?
         allowed_types.push_back(CGenericNode::TYPE_LOAD_EXPR_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE);
      }
      else if (grammar_type == "EXPR")
      {
         // SHARED
         allowed_types.push_back(CGenericNode::TYPE_OP_EXPR_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_LOAD_EXPR_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE);

         // FREF_EXPR
         allowed_types.push_back(CGenericNode::TYPE_FREF_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_DYNALLOC_EXPR_TUPLE);

         // LREF_EXPR
         allowed_types.push_back(CGenericNode::TYPE_LREF_TUPLE);

         // NUM_EXPR
         allowed_types.push_back(CGenericNode::TYPE_INTVAL_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_FLOATVAL_TUPLE);

         // LABEL_EXPR
         allowed_types.push_back(CGenericNode::TYPE_LABEL_TUPLE);

         // ADDR_EXPR
         allowed_types.push_back(CGenericNode::TYPE_ADDR_EXPR_TUPLE);
         allowed_types.push_back(CGenericNode::TYPE_COMPADDR_EXPR_TUPLE);
      }
      else
      {
         throw std::logic_error("Unknown grammar_type for SetAllowedTypesIfUnknown");
         return;
      }

      CUnknownExpr* expr = dynamic_cast<CUnknownExpr*>(node);
      expr->SetValidExpandingTypes(allowed_types);

   }
   //TODO: More unknown nodes here when implemented/needed.
}

inline void SetAllowedTypesIfUnknown(std::vector<alf::AExpr*>& nodes, const std::string& grammar_type)
{
   for (std::vector<alf::AExpr*>::size_type i = 0, n = nodes.size(); i != n; ++i)
      SetAllowedTypesIfUnknown((alf::CGenericNode*)nodes[i], grammar_type);
}
