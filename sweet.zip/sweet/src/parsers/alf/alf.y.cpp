/* A Bison parser, made by GNU Bison 2.5.  */

/* Bison implementation for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2011 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.5"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Using locations.  */
#define YYLSP_NEEDED 1

/* Substitute the variable and function names.  */
#define yyparse         alf_parse
#define yylex           alf_lex
#define yyerror         alf_error
#define yylval          alf_lval
#define yychar          alf_char
#define yydebug         alf_debug
#define yynerrs         alf_nerrs
#define yylloc          alf_lloc

/* Copy the first part of user declarations.  */



#include "alf.y.hpp"
#include "alf_head.h"
#include "program/alf/alf.h"
#include <string>
#include <iostream>
#include <cctype>

// workaround for incompatibility with MSVC
#define YY_LOCATION_PRINT(FILE, LOC) ((void)0)

//#define YYDEBUG 1 // uncomment to get debug output during parsing

using namespace alf;
using namespace std;

extern int alf_lex(YYSTYPE* semantic_value, YYLTYPE* location);

// full copy of the current source file
static string src;

// pointers to the individual source lines in src
static vector<const char*> src_lines;

// Strings returned from the lexer are represented by their source file coordinates. This function
// turns the coordinates into a string by looking it up in src (using src_lines).
static inline string get_src(YYLTYPE loc) {
	return string(src_lines[loc.first_line - 1] + loc.first_column - 1,
		src_lines[loc.last_line - 1] + loc.last_column - 1);
}

static void init_src(FILE* alf_file)
{
	src.clear(); src_lines.clear();
	while (!feof(alf_file)) src.push_back((char)fgetc(alf_file));
	rewind(alf_file);
	const char* src_ = src.c_str();
	src_lines.push_back(src_);
	for (string::size_type i = 1, n = src.size(); i < n; ++i) {
		if (src_[i-1] == '\n')
			src_lines.push_back(src_ + i);
	}
	src_lines.push_back(src_ + src.size()); // dummy element
}

static inline COORD mkCOORD(YYLTYPE& loc)
{
	COORD coord = { 0, loc.first_line, loc.first_column };
	return coord;
}

// garbage collection of semantic values --------

template <class T>
static inline void gc(T&) { /* non-pointer type: do nothing */ }

template <class T>
static inline void gc(T* ptr) { delete ptr; }

template <class T>
static inline void gc(std::vector<T*>* ptr) {
	for (int i = 0, n = (int)ptr->size(); i != n; ++i)
		delete ptr->at(i);
	delete ptr;
}

// -----------------------------------------------------

void print_alf_error(YYLTYPE* loc, const char* msg)
{
	cerr << "At " << loc->first_line << '.' << loc->first_column << '-' <<
		loc->last_line << '.' << loc->last_column << ':' << "\n\n";

	// Print the source line in question
	string line(src_lines[loc->first_line - 1], src_lines[loc->first_line] - 1);
	const char* line_ = line.c_str();
	cerr << line << '\n';

	// Print curvy line
	int i = 0;
	for (const int n = loc->first_column - 1; i != n; ++i) {
		if (isspace(line_[i])) cerr << line_[i]; // we want to print tabs
		else cerr << ' ';
	}
	if (loc->first_line == loc->last_line)
		for (const int n = loc->last_column - 1; i != n; ++i) cerr << '~';
	else
		for (const int n = (int)line.length(); i != n; ++i) cerr << '~';
	
	cerr << "\n\n" << msg;
	// Add a period if the error message happens to not be terminated by a punctuation character
	if (!ispunct(msg[strlen(msg) - 1])) cerr << '.';
	cerr << endl;
}

static void alf_error(YYLTYPE* loc, FILE*, unique_ptr<CAlfTuple>&, const char* msg) { print_alf_error(loc, msg); }




/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 1
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

/* "%code requires" blocks.  */


	#include "program/alf/alf.h"
	#include <cstdio>
	#include <vector>
	#include <memory>




/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     OP = 258,
     IDENTIFIER = 259,
     QSTRING = 260,
     INTEGER = 261,
     FLOATVAL = 262,
     little_endian = 263,
     big_endian = 264,
     alf_ = 265,
     macro_defs = 266,
     macrocall = 267,
     label = 268,
     null = 269,
     store = 270,
     jump = 271,
     switch_ = 272,
     call = 273,
     return_ = 274,
     free_ = 275,
     scope = 276,
     stmts = 277,
     funcs = 278,
     least_addr_unit = 279,
     exports = 280,
     imports = 281,
     frefs = 282,
     lrefs = 283,
     fref = 284,
     lref = 285,
     decls = 286,
     alloc = 287,
     inits = 288,
     init = 289,
     ref_ = 290,
     const_repeat = 291,
     const_list = 292,
     hex_list = 293,
     dec_list = 294,
     udec_list = 295,
     bin_list = 296,
     float_list = 297,
     func = 298,
     target = 299,
     default_ = 300,
     load = 301,
     undefined = 302,
     addr = 303,
     minus_ = 304,
     arg_decls = 305,
     bin_val = 306,
     dec_signed = 307,
     dec_unsigned = 308,
     char_string = 309,
     float_val = 310,
     def = 311,
     dyn_alloc = 312,
     hex_val = 313,
     inf = 314,
     leaving = 315,
     read_only = 316,
     result = 317,
     volatile_ = 318,
     with = 319
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{


	alf::COpNumExprTuple::OP_TYPE OP_TYPE_;
	alf::CInitTuple::InitOption InitOption_;

	alf::CGenericNode* CGenericNode_;
	alf::CMacroDefList* CMacroDefList_;
	alf::CMacroDefTuple* CMacroDefTuple_;
	alf::CMacroCallTuple* CMacroCallTuple_;
	alf::CMacroFormalArg* CMacroFormalArg_;
	alf::CLauTuple* CLauTuple_;
	alf::CExportsTuple* CExportsTuple_;
	alf::CImportsTuple* CImportsTuple_;
	alf::CFRefList* CFRefList_;
	alf::CLRefList* CLRefList_;
	alf::CDeclList* CDeclList_;
	alf::CAllocTuple* CAllocTuple_;
	alf::CInitList* CInitList_;
	alf::CInitTuple* CInitTuple_; 
	alf::CRefTuple* CRefTuple_;
	alf::CFuncList* CFuncList_;
	alf::CFuncTuple* CFuncTuple_; 
	alf::CArgDeclList* CArgDeclList_;
	alf::CScopeTuple* CScopeTuple_;
	alf::CStmtList* CStmtList_;
	alf::AStmt* AStmt_;
	alf::ATarget* ATarget_;
	alf::CSize* CSize_;
	alf::CString* CString_;
	alf::AVal* AVal_;
	alf::ANumVal* ANumVal_;
	alf::AConst* AConst_;
	alf::AExpr* AExpr_;
	alf::CIntNumValTuple* CIntNumValTuple_;
	alf::CFRefTuple* CFRefTuple_;
	alf::CLRefTuple* CLRefTuple_;
	alf::CAddrTuple* CAddrTuple_;
	alf::CLabelTuple* CLabelTuple_;

	std::vector<alf::CGenericNode*>* vector_CGenericNode;
	std::vector<alf::CMacroDefTuple*>* vector_CMacroDefTuple;
	std::vector<alf::CMacroFormalArg*>* vector_CMacroFormalArg;
	std::vector<alf::CSize*>* vector_CSize;
	std::vector<alf::CAllocTuple*>* vector_CAllocTuple;
	std::vector<alf::CInitTuple*>* vector_CInitTuple;
	std::vector<alf::CFuncTuple*>* vector_CFuncTuple;
	std::vector<alf::CString*>* vector_CString;
	std::vector<alf::AConst*>* vector_AConst;
	std::vector<alf::AExpr*>* vector_AExpr;
	std::vector<alf::CFRefTuple*>* vector_CFRefTuple;
	std::vector<alf::CLRefTuple*>* vector_CLRefTuple;
	std::vector<alf::ATarget*>* vector_ATarget;



} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

/* "%code provides" blocks.  */


	/** Parses an ALF program from @a alf_file and returns the AST in @a ast_out
		@returns 0 iff parsing was successful
		@post    @a ast_out is empty if parsing was unsuccessful */
	int alf_parse(FILE* alf_file, std::unique_ptr<alf::CAlfTuple>& ast_out);

	/** Should be called after the last parse (it can also be called after every parse)
		to clean up dynamic memory allocated by the lexer */
	int alf_lex_destroy();




/* Copy the second part of user declarations.  */



#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int yyi)
#else
static int
YYID (yyi)
    int yyi;
#endif
{
  return yyi;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL \
	     && defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE) + sizeof (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
	Stack = &yyptr->Stack_alloc;					\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  4
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   900

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  68
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  87
/* YYNRULES -- Number of rules.  */
#define YYNRULES  217
/* YYNRULES -- Number of states.  */
#define YYNSTATES  448

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   319

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,    67,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    65,     2,    66,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     5,     7,     8,    20,    22,    24,    29,
      33,    34,    43,    47,    48,    51,    53,    55,    57,    59,
      65,    70,    74,    75,    77,    79,    81,    83,    85,    87,
      89,    91,    93,    98,   100,   102,   108,   114,   118,   123,
     127,   130,   134,   139,   143,   146,   152,   154,   156,   158,
     160,   162,   164,   170,   172,   174,   176,   178,   180,   182,
     186,   191,   195,   198,   205,   207,   209,   211,   213,   215,
     217,   219,   223,   228,   232,   235,   242,   248,   250,   252,
     254,   256,   257,   259,   261,   263,   265,   267,   269,   271,
     277,   282,   288,   294,   300,   306,   313,   318,   320,   322,
     324,   326,   328,   333,   335,   337,   339,   341,   343,   345,
     349,   352,   356,   359,   361,   366,   368,   370,   372,   376,
     379,   381,   383,   385,   387,   391,   394,   396,   398,   400,
     402,   404,   406,   408,   412,   415,   417,   419,   421,   423,
     427,   430,   432,   434,   436,   438,   440,   442,   444,   448,
     453,   457,   460,   467,   471,   476,   483,   485,   487,   489,
     493,   498,   501,   503,   505,   508,   510,   512,   514,   518,
     525,   532,   538,   544,   551,   558,   566,   570,   575,   580,
     582,   586,   589,   591,   593,   600,   602,   604,   609,   615,
     622,   626,   631,   636,   642,   649,   651,   653,   655,   659,
     662,   664,   671,   677,   683,   689,   695,   697,   699,   701,
     708,   715,   717,   719,   721,   725,   728,   734
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
      71,     0,    -1,     1,    -1,    69,    -1,    -1,    65,    10,
      73,    82,    83,    84,    85,    96,   102,   132,    66,    -1,
       4,    -1,     5,    -1,    65,    11,    74,    66,    -1,    74,
      70,    75,    -1,    -1,    65,    56,    65,    72,    76,    66,
      78,    66,    -1,    76,    70,    77,    -1,    -1,    67,    72,
      -1,    81,    -1,    98,    -1,   104,    -1,   105,    -1,    65,
      12,    72,    80,    66,    -1,    65,    72,    80,    66,    -1,
      80,    70,    81,    -1,    -1,   143,    -1,    72,    -1,   117,
      -1,   138,    -1,   141,    -1,     7,    -1,   111,    -1,    79,
      -1,    77,    -1,    65,    24,   101,    66,    -1,     8,    -1,
       9,    -1,    65,    25,    86,    88,    66,    -1,    65,    26,
      86,    88,    66,    -1,    65,    27,    66,    -1,    65,    27,
      87,    66,    -1,    87,    70,    92,    -1,    70,    92,    -1,
      65,    28,    66,    -1,    65,    28,    89,    66,    -1,    89,
      70,    95,    -1,    70,    95,    -1,    65,    29,   101,    91,
      66,    -1,    72,    -1,    79,    -1,    77,    -1,    90,    -1,
      79,    -1,    77,    -1,    65,    30,   101,    94,    66,    -1,
      72,    -1,    79,    -1,    77,    -1,    93,    -1,    79,    -1,
      77,    -1,    65,    31,    66,    -1,    65,    31,    97,    66,
      -1,    97,    70,    99,    -1,    70,    99,    -1,    65,    32,
     101,    91,   101,    66,    -1,    98,    -1,    79,    -1,   120,
      -1,    59,    -1,   100,    -1,    79,    -1,    77,    -1,    65,
      33,    66,    -1,    65,    33,   103,    66,    -1,   103,    70,
     108,    -1,    70,   108,    -1,    65,    34,   106,   110,   107,
      66,    -1,    65,    35,    91,   149,    66,    -1,   105,    -1,
      79,    -1,    63,    -1,    61,    -1,    -1,   104,    -1,    79,
      -1,   112,    -1,   111,    -1,   109,    -1,    79,    -1,    77,
      -1,    65,    36,   113,   114,    66,    -1,    65,    37,   115,
      66,    -1,    65,    39,   101,   116,    66,    -1,    65,    40,
     101,   119,    66,    -1,    65,    38,   101,   122,    66,    -1,
      65,    41,   101,   125,    66,    -1,    65,    42,   101,   101,
     128,    66,    -1,    65,    54,   131,    66,    -1,   147,    -1,
      90,    -1,   150,    -1,    93,    -1,   151,    -1,    65,    47,
     101,    66,    -1,   112,    -1,    79,    -1,    77,    -1,   120,
      -1,    79,    -1,    77,    -1,   115,    70,   113,    -1,    70,
     113,    -1,   116,    70,   118,    -1,    70,   118,    -1,   120,
      -1,    65,    49,     6,    66,    -1,   117,    -1,    79,    -1,
      77,    -1,   119,    70,   121,    -1,    70,   121,    -1,     6,
      -1,   120,    -1,    79,    -1,    77,    -1,   122,    70,   124,
      -1,    70,   124,    -1,     6,    -1,     4,    -1,    56,    -1,
       3,    -1,   123,    -1,    79,    -1,    77,    -1,   125,    70,
     127,    -1,    70,   127,    -1,     6,    -1,   126,    -1,    79,
      -1,    77,    -1,   128,    70,   129,    -1,    70,   129,    -1,
       7,    -1,    79,    -1,    77,    -1,     5,    -1,   130,    -1,
      79,    -1,    77,    -1,    65,    23,    66,    -1,    65,    23,
     133,    66,    -1,   133,    70,   134,    -1,    70,   134,    -1,
      65,    43,   152,   135,   137,    66,    -1,    65,    50,    66,
      -1,    65,    50,    97,    66,    -1,    65,    21,    96,   102,
     138,    66,    -1,   136,    -1,    79,    -1,    77,    -1,    65,
      22,    66,    -1,    65,    22,   139,    66,    -1,   139,   140,
      -1,   140,    -1,   141,    -1,    69,   141,    -1,   151,    -1,
      79,    -1,    77,    -1,    65,    14,    66,    -1,    65,    15,
     142,    64,   142,    66,    -1,    65,    16,   145,    60,   121,
      66,    -1,    65,    17,   145,   153,    66,    -1,    65,    18,
     145,    62,    66,    -1,    65,    18,   145,   142,    62,    66,
      -1,    65,    18,   145,    62,   142,    66,    -1,    65,    18,
     145,   142,    62,   142,    66,    -1,    65,    19,    66,    -1,
      65,    19,   142,    66,    -1,    65,    20,   145,    66,    -1,
     136,    -1,   142,    70,   145,    -1,    70,   145,    -1,   147,
      -1,    90,    -1,    65,    48,   101,   145,   145,    66,    -1,
      93,    -1,   144,    -1,    65,    47,   101,    66,    -1,    65,
      46,   101,   145,    66,    -1,    65,    57,   101,    91,   145,
      66,    -1,    65,     3,    66,    -1,    65,     3,   146,    66,
      -1,    65,     3,   142,    66,    -1,    65,     3,   146,   142,
      66,    -1,    65,    13,   101,   145,   145,    66,    -1,   143,
      -1,    79,    -1,    77,    -1,   146,    70,   100,    -1,    70,
     100,    -1,   148,    -1,    65,    55,   101,   101,   129,    66,
      -1,    65,    52,   101,   118,    66,    -1,    65,    53,   101,
     121,    66,    -1,    65,    58,   101,   124,    66,    -1,    65,
      51,   101,   127,    66,    -1,   148,    -1,    79,    -1,    77,
      -1,    65,    48,   101,    92,   149,    66,    -1,    65,    13,
     101,    95,   149,    66,    -1,   151,    -1,    79,    -1,    77,
      -1,   153,    70,   154,    -1,    70,   154,    -1,    65,    44,
     149,   145,    66,    -1,    65,    45,   145,    66,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   264,   264,   278,   278,   281,   292,   293,   296,   299,
     300,   304,   318,   319,   323,   338,   339,   340,   341,   346,
     357,   371,   372,   378,   379,   380,   389,   390,   400,   401,
     402,   403,   406,   408,   408,   410,   412,   415,   416,   420,
     421,   425,   426,   430,   431,   434,   437,   438,   439,   443,
     444,   445,   448,   451,   452,   453,   457,   458,   459,   463,
     464,   468,   469,   472,   475,   476,   480,   481,   485,   486,
     487,   491,   492,   496,   497,   500,   502,   505,   506,   510,
     511,   512,   516,   517,   521,   522,   526,   527,   528,   532,
     534,   536,   538,   540,   542,   544,   546,   552,   553,   554,
     555,   556,   557,   561,   562,   563,   567,   568,   569,   573,
     574,   578,   579,   583,   584,   597,   598,   599,   603,   604,
     608,   621,   622,   623,   627,   628,   632,   643,   654,   656,
     669,   670,   671,   675,   676,   680,   693,   694,   695,   699,
     700,   704,   705,   706,   709,   712,   713,   714,   718,   719,
     723,   724,   727,   730,   731,   734,   737,   738,   739,   743,
     744,   755,   756,   760,   761,   762,   763,   764,   768,   769,
     777,   782,   788,   793,   800,   807,   816,   817,   823,   828,
     832,   833,   837,   838,   839,   845,   846,   847,   848,   853,
     862,   863,   864,   865,   874,   883,   884,   885,   891,   892,
     896,   897,   902,   904,   906,   908,   913,   914,   915,   918,
     920,   923,   924,   925,   929,   930,   934,   935
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "\"operator\"", "\"identifier\"",
  "\"quoted string\"", "\"integer\"", "\"float\"", "little_endian",
  "big_endian", "\"alf\"", "macro_defs", "macrocall", "label", "null",
  "store", "jump", "\"switch\"", "call", "\"return\"", "\"free\"", "scope",
  "stmts", "funcs", "least_addr_unit", "exports", "imports", "frefs",
  "lrefs", "fref", "lref", "decls", "alloc", "inits", "init", "\"ref\"",
  "const_repeat", "const_list", "hex_list", "dec_list", "udec_list",
  "bin_list", "float_list", "func", "target", "\"default \"", "load",
  "undefined", "addr", "\"minus\"", "arg_decls", "bin_val", "dec_signed",
  "dec_unsigned", "char_string", "float_val", "def", "dyn_alloc",
  "hex_val", "inf", "leaving", "read_only", "result", "\"volatile\"",
  "with", "'{'", "'}'", "'@'", "$accept", "Error", "MaybeError", "Alf",
  "Identifier", "MacroDefs", "MacroDefList", "MacroDef",
  "MacroFormalArgList", "MacroFormalArg", "Definable", "MacroCall",
  "MacroActualList", "MacroActual", "Lau", "Endian", "Exports", "Imports",
  "FRefs", "FRefList", "LRefs", "LRefList", "FRef_C", "FRefId", "FRef",
  "LRef_C", "LRefId", "LRef", "Decls", "AllocList", "Alloc_C", "Alloc",
  "Size_C", "Size", "Inits", "InitList", "Init_C", "Ref_C", "Ref",
  "InitOpt", "Init", "Val_C", "Val", "ValLists", "Const_C", "Const",
  "Repeats", "ConstList", "SignedValList", "SignedVal_C", "SignedVal",
  "UnsignedStringList", "UnsignedString_C", "UnsignedString",
  "HexStringList", "HexString_C", "HexString", "BinStringList",
  "BinString_C", "BinString", "FloatValList", "FloatVal", "CharString_C",
  "CharString", "Funcs", "FuncList", "Func", "ArgDecls", "Scope_C",
  "Scope", "Stmts", "LabelStmtList", "LabelStmt", "Stmt", "ExprList",
  "Expr_C", "LabelExpr", "Expr", "SizeList", "NumVal", "IntNumVal_C",
  "IntNumVal", "Addr", "Label_C", "Label", "TargetList", "Target", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   123,   125,    64
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    68,    69,    70,    70,    71,    72,    72,    73,    74,
      74,    75,    76,    76,    77,    78,    78,    78,    78,    79,
      79,    80,    80,    81,    81,    81,    81,    81,    81,    81,
      81,    81,    82,    83,    83,    84,    85,    86,    86,    87,
      87,    88,    88,    89,    89,    90,    91,    91,    91,    92,
      92,    92,    93,    94,    94,    94,    95,    95,    95,    96,
      96,    97,    97,    98,    99,    99,   100,   100,   101,   101,
     101,   102,   102,   103,   103,   104,   105,   106,   106,   107,
     107,   107,   108,   108,   109,   109,   110,   110,   110,   111,
     111,   111,   111,   111,   111,   111,   111,   112,   112,   112,
     112,   112,   112,   113,   113,   113,   114,   114,   114,   115,
     115,   116,   116,   117,   117,   118,   118,   118,   119,   119,
     120,   121,   121,   121,   122,   122,   123,   123,   123,   123,
     124,   124,   124,   125,   125,   126,   127,   127,   127,   128,
     128,   129,   129,   129,   130,   131,   131,   131,   132,   132,
     133,   133,   134,   135,   135,   136,   137,   137,   137,   138,
     138,   139,   139,   140,   140,   140,   140,   140,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     142,   142,   143,   143,   143,   143,   143,   143,   143,   143,
     143,   143,   143,   143,   144,   145,   145,   145,   146,   146,
     147,   147,   148,   148,   148,   148,   149,   149,   149,   150,
     151,   152,   152,   152,   153,   153,   154,   154
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     1,     0,    11,     1,     1,     4,     3,
       0,     8,     3,     0,     2,     1,     1,     1,     1,     5,
       4,     3,     0,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     4,     1,     1,     5,     5,     3,     4,     3,
       2,     3,     4,     3,     2,     5,     1,     1,     1,     1,
       1,     1,     5,     1,     1,     1,     1,     1,     1,     3,
       4,     3,     2,     6,     1,     1,     1,     1,     1,     1,
       1,     3,     4,     3,     2,     6,     5,     1,     1,     1,
       1,     0,     1,     1,     1,     1,     1,     1,     1,     5,
       4,     5,     5,     5,     5,     6,     4,     1,     1,     1,
       1,     1,     4,     1,     1,     1,     1,     1,     1,     3,
       2,     3,     2,     1,     4,     1,     1,     1,     3,     2,
       1,     1,     1,     1,     3,     2,     1,     1,     1,     1,
       1,     1,     1,     3,     2,     1,     1,     1,     1,     3,
       2,     1,     1,     1,     1,     1,     1,     1,     3,     4,
       3,     2,     6,     3,     4,     6,     1,     1,     1,     3,
       4,     2,     1,     1,     2,     1,     1,     1,     3,     6,
       6,     5,     5,     6,     6,     7,     3,     4,     4,     1,
       3,     2,     1,     1,     6,     1,     1,     4,     5,     6,
       3,     4,     4,     5,     6,     1,     1,     1,     3,     2,
       1,     6,     5,     5,     5,     5,     1,     1,     1,     6,
       6,     1,     1,     1,     3,     2,     5,     4
};

/* YYDEFACT[STATE-NAME] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     0,     0,     0,     1,     0,     0,    10,     0,     0,
       0,     0,    33,    34,     0,     2,     8,     3,     0,   120,
      67,     0,     0,    70,    69,    68,     0,    66,     0,     0,
       0,     9,     6,     7,     0,    22,    14,    32,     0,     0,
       0,     0,    22,     0,     0,     0,     0,     0,     0,     0,
       0,    20,     0,     0,     0,     0,     0,     0,     0,     0,
      13,    19,    28,     0,    24,    31,    30,    21,   183,   185,
      29,    25,   113,   179,    26,    27,    23,   186,   182,   200,
      37,     0,     0,     0,    35,     0,    59,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    51,    50,    49,    40,    38,
       0,    41,     0,     0,    36,     0,    65,    64,    62,    60,
       0,    71,     0,     0,     0,     5,     0,     0,   190,     0,
       0,     0,     0,   168,     0,     0,     0,   197,   196,   195,
       0,     0,     0,   176,     0,     0,     0,     0,   159,     0,
     167,   166,     0,   162,   163,   165,     0,     0,     0,   105,
     104,    98,   100,   103,     0,    97,    99,   101,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   144,   147,   146,   145,     0,     0,     0,     0,
      39,     0,    58,    57,    56,    44,    42,     0,     0,    61,
       0,    83,    82,    74,    72,     0,   148,     0,     0,     0,
       0,    15,    16,    17,    18,    12,   199,   181,   192,     0,
     191,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     177,   178,     0,     0,     0,   164,   160,   161,    46,    48,
      47,     0,    53,    55,    54,     0,     0,     0,   108,   107,
       0,   106,   110,    90,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   187,     0,   114,   135,   138,
     137,   136,     0,     0,   117,   116,   115,     0,   123,   122,
     121,     0,    96,     0,     0,   129,   127,   126,   128,   132,
     131,   130,     0,    43,     0,     0,    73,     0,   151,   149,
       0,     0,    11,   180,   198,   193,     0,     0,     0,     0,
     215,   171,     0,   172,     0,     0,     0,     0,     0,    45,
      52,     0,     0,    89,   109,   125,    93,     0,   112,    91,
       0,   119,    92,     0,   134,    94,     0,     0,     0,   188,
       0,   205,   202,   203,   141,   143,   142,     0,     0,   204,
       0,     0,    78,    77,     0,     0,   150,     0,   194,   169,
     170,     0,     0,   214,   174,   173,     0,   155,     0,   102,
       0,   124,   111,   118,   133,   140,    95,     0,   184,   201,
     189,     0,     0,    88,    87,    86,    81,    85,    84,     0,
     213,   212,   211,     0,     0,   208,   207,   206,     0,     0,
       0,   175,     0,     0,   139,    63,    80,    79,     0,     0,
       0,    76,     0,   217,   210,   209,    75,     0,     0,   158,
     157,   156,     0,   216,   153,     0,   152,   154
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    17,   239,     2,    35,     6,    10,    31,    92,    23,
     230,    24,    43,    67,     9,    14,    29,    40,    45,    82,
      55,   133,    68,   261,   128,    69,   265,   215,    48,    88,
     137,   138,    25,    26,    59,   143,   222,   234,   374,   428,
     223,   405,   406,    70,   183,   184,   270,   189,   278,   296,
     297,   280,    27,   301,   276,   311,   312,   282,   291,   292,
     358,   367,   205,   206,    91,   228,   318,   430,    73,   442,
      74,   172,   173,    75,   150,   159,    77,   237,   151,    78,
      79,   418,   186,   187,   413,   247,   330
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -348
static const yytype_int16 yypact[] =
{
     -44,     7,    24,   -33,  -348,    44,    -7,  -348,    46,   145,
     165,   261,  -348,  -348,    34,  -348,  -348,  -348,    54,  -348,
    -348,   193,   189,  -348,  -348,  -348,    92,  -348,   138,   113,
     169,  -348,  -348,  -348,   189,  -348,  -348,  -348,   152,   215,
     183,   194,  -348,   238,   260,   200,   152,   257,   241,   189,
     278,  -348,   583,    83,   296,   269,   200,   210,   274,   262,
    -348,  -348,  -348,   756,  -348,  -348,  -348,  -348,  -348,  -348,
    -348,  -348,  -348,  -348,  -348,  -348,  -348,  -348,  -348,  -348,
    -348,   -28,   109,   155,  -348,   275,  -348,   277,   251,   273,
     323,   285,    27,   256,   261,   290,   188,   -11,   -11,   -11,
     351,   -11,   183,   354,   261,   261,    -6,   188,   261,   261,
     261,   261,   261,   261,   261,   261,   375,   261,   261,   261,
     123,   261,   261,   261,   598,  -348,  -348,  -348,  -348,  -348,
     -28,  -348,    73,   382,  -348,   127,  -348,  -348,  -348,  -348,
     277,  -348,   321,   301,   378,  -348,   590,   320,  -348,   492,
     387,   348,   -11,  -348,   -11,   142,   812,  -348,  -348,  -348,
     335,    30,   397,  -348,   403,   336,   241,   814,  -348,   341,
    -348,  -348,   428,  -348,  -348,  -348,   365,   365,   594,  -348,
    -348,  -348,  -348,  -348,    42,  -348,  -348,  -348,    -6,   435,
     294,   105,   105,   105,   261,   -11,   344,   -11,   371,   326,
     504,    42,  -348,  -348,  -348,  -348,   380,   261,   365,   243,
    -348,   487,  -348,  -348,  -348,  -348,  -348,    73,   261,  -348,
      18,  -348,  -348,  -348,  -348,   321,  -348,   376,   400,   698,
     391,  -348,  -348,  -348,  -348,  -348,  -348,  -348,  -348,   -11,
    -348,   492,   438,   -11,   188,    42,   396,   407,   441,   449,
    -348,  -348,   406,   261,   675,  -348,  -348,  -348,  -348,  -348,
    -348,   419,  -348,  -348,  -348,   420,   261,   261,  -348,  -348,
     423,  -348,  -348,  -348,    -6,   243,   308,   504,    10,    42,
      59,   326,   357,   393,   447,  -348,   -11,  -348,  -348,  -348,
    -348,  -348,   453,   478,  -348,  -348,  -348,   457,  -348,  -348,
    -348,   462,  -348,   226,   -11,  -348,  -348,  -348,  -348,  -348,
    -348,  -348,   471,  -348,   365,   476,  -348,   509,  -348,  -348,
     376,   365,  -348,  -348,  -348,  -348,   489,   480,   501,   191,
    -348,  -348,   396,  -348,   483,   496,   546,   506,    73,  -348,
    -348,   512,   -28,  -348,  -348,  -348,  -348,   243,  -348,  -348,
     504,  -348,  -348,    42,  -348,  -348,   326,   226,   135,  -348,
     513,  -348,  -348,  -348,  -348,  -348,  -348,   514,   515,  -348,
     261,    22,  -348,  -348,   161,   213,  -348,   373,  -348,  -348,
    -348,   373,   -11,  -348,  -348,  -348,   508,  -348,   373,  -348,
     373,  -348,  -348,  -348,  -348,  -348,  -348,   226,  -348,  -348,
    -348,   518,   842,  -348,  -348,  -348,   414,  -348,  -348,   600,
    -348,  -348,  -348,   505,   626,  -348,  -348,  -348,   525,   -11,
     526,  -348,   535,   545,  -348,  -348,  -348,  -348,   548,   568,
     499,  -348,   553,  -348,  -348,  -348,  -348,   511,   604,  -348,
    -348,  -348,   554,  -348,  -348,   520,  -348,  -348
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -348,   -84,   -10,  -348,    19,  -348,  -348,  -348,  -348,   279,
    -348,    15,   580,   488,  -348,  -348,  -348,  -348,   587,  -348,
     581,  -348,   -61,  -206,  -123,   -88,  -348,  -216,   538,   206,
     498,   519,  -136,   421,   485,  -348,   516,   343,  -348,  -348,
     439,  -348,  -348,   289,   291,  -182,  -348,  -348,  -348,   -48,
    -269,  -348,   -16,  -233,  -348,  -348,  -260,  -348,  -348,  -267,
    -348,  -347,  -348,  -348,  -348,  -348,   346,  -348,   240,  -348,
     416,  -348,   500,   -68,   -71,   -43,  -348,   -35,  -348,  -103,
    -339,  -244,  -348,   -98,  -348,  -348,   339
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -5
static const yytype_int16 yytable[] =
{
      18,   313,   304,   185,    71,   175,   272,   210,   348,    76,
     395,    15,   328,   236,   354,   345,    -4,     3,   182,   169,
     127,     1,    32,    33,     4,   155,    32,    33,    15,   164,
      34,    15,     5,    52,    34,   174,    72,   124,   417,    22,
      52,    36,   417,    81,   214,   181,   351,    87,    19,   417,
     424,   417,   315,    42,   156,     7,    22,   321,     8,   178,
      15,    22,   160,   161,   162,    -4,   165,    66,    60,   127,
      11,    64,   130,   132,   175,    -4,   349,    -4,   140,   142,
     242,   392,   147,   149,    15,   185,   154,   391,   169,   394,
     154,   249,   344,   146,    -4,    -4,   126,   188,    71,    28,
     182,   255,   136,    76,   174,   324,    15,    21,   370,    22,
      15,    -4,   158,   158,   158,   377,   158,   243,   171,    30,
     393,   180,   388,   217,    -4,   352,    -4,   181,   202,   214,
      72,    32,    33,   225,   227,   204,    15,   419,   211,    34,
      22,   241,    -4,    15,   422,   126,   423,   213,    -4,    80,
      -4,   246,   154,    12,    13,   136,    15,   221,    37,   218,
     284,    66,   286,    38,   158,    64,    15,   158,   271,   158,
      -4,   185,    -4,   327,    -4,   129,    -4,   334,    39,   274,
     275,   277,   279,   281,    72,   300,   182,   171,    21,    15,
      22,   260,   264,    32,    33,   258,   262,    32,    33,   269,
      -4,   396,    -4,   180,   323,    34,   244,    -4,   326,    -4,
     158,    15,   158,   181,   290,   295,   299,    44,   320,   390,
      -4,   131,    -4,   260,   310,    41,   402,   258,    22,   300,
      -4,    16,   213,   364,   154,   381,   382,   332,   154,    15,
     221,    46,    -4,    -4,    -4,    -4,   305,   306,    47,   307,
     214,   360,    15,    -4,   158,    -4,   158,    15,   158,    49,
     299,    72,    -4,   300,   386,    54,   347,    19,   350,   368,
     353,   185,   356,   357,    15,    -4,    86,   412,   409,    15,
      22,   127,    -4,    -4,    -4,    -4,   182,    53,    57,   180,
     310,    21,   295,    22,   299,    15,   290,    -4,    -4,   308,
      -4,   158,    15,    -4,    51,    -4,    58,    89,    21,    15,
      22,    -4,    -4,   181,    -4,    -4,    -4,   139,   366,   158,
      20,    -4,   148,    -4,    83,   154,    21,    90,    22,   260,
     372,    65,   288,   258,    72,    84,   260,   300,    -4,   141,
     258,   134,   135,    -4,    61,    -4,   144,   420,   397,    15,
      -4,   145,    15,   213,    -4,    15,   153,   126,    15,    -4,
     125,    -4,   310,    -4,    -4,   295,    -4,   224,   299,    32,
      33,   290,   366,    -4,   346,    -4,   157,   157,   157,    15,
     157,   198,   170,    15,   432,   179,   220,    22,    15,   404,
     411,    21,   416,    22,    15,   245,   416,   158,    15,   203,
      -4,    15,   251,   416,    15,   416,   254,    -4,    15,   125,
     285,   212,   366,    -4,   240,    -4,    -4,   163,    -4,   167,
     168,    22,    -4,   355,    -4,    65,   235,    87,   157,    15,
      21,   157,    22,   157,   158,   140,    15,   287,   414,    15,
      22,   317,    15,    -4,   226,   440,   302,    -4,   216,    -4,
      15,   170,    -4,   238,    -4,   259,   263,   322,    -4,   248,
      -4,   329,    -4,   268,    -4,    -4,   319,   179,    -4,   250,
      -4,   336,    -4,   331,   157,   426,   157,   427,   289,   294,
     298,    15,    32,    33,    15,   339,   340,   259,   309,   343,
      34,    32,    33,   167,   256,    22,   212,    15,    19,    34,
      -4,   273,    -4,    -4,   325,    -4,    -4,   333,    -4,    15,
      19,   335,    15,   359,    -4,   152,    -4,   105,   157,   361,
     157,    15,   157,   362,   298,   176,   177,   116,   363,   190,
     191,   192,   193,   194,   195,   196,   197,   369,   199,   200,
     201,   371,   207,   208,   209,    -4,   379,    -4,    -4,   384,
      -4,    20,   375,   179,   309,   378,   294,   156,   298,    22,
     289,    -4,   385,    -4,   438,   157,    22,   380,   103,   293,
     429,    22,   387,    -4,   421,    -4,    -4,   444,   389,   398,
     399,   400,   365,   157,   425,    -4,   447,    32,    33,    19,
      62,   431,   433,   259,    32,    33,    19,    62,    32,    33,
     259,   434,    32,    33,    32,    33,    34,   253,    32,    33,
      34,   435,    34,   253,   436,   283,    34,   212,   437,   443,
     446,   125,    50,   104,   105,   102,   309,   104,   303,   294,
      32,    33,   298,    56,   231,   289,   365,    85,    34,   314,
     166,   266,   267,   445,   232,   117,   118,   119,    63,   121,
      22,   252,   123,   403,   410,   229,   415,    22,   373,   219,
     415,   157,   233,   407,   316,   408,   376,   415,   337,   415,
     441,   383,   257,     0,   338,     0,   365,   117,   118,   119,
       0,     0,     0,     0,   123,     0,     0,   341,   342,    95,
      96,    97,    98,    99,   100,   101,   102,     0,   157,     0,
       0,    93,    32,    33,     0,     0,     0,     0,     0,   439,
      34,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     103,     0,     0,     0,     0,     0,     0,   104,   105,     0,
     218,     0,   315,   321,   106,   107,   108,   109,   110,   111,
     112,     0,     0,     0,   113,   114,   115,   116,     0,   117,
     118,   119,   120,   121,     0,   122,   123,     0,     0,    93,
      32,    33,     0,     0,     0,     0,     0,     0,    34,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,     0,
       0,     0,     0,     0,     0,   104,   105,     0,     0,     0,
       0,   401,   106,   107,   108,   109,   110,   111,   112,     0,
       0,     0,   113,   114,   115,   116,     0,   117,   118,   119,
     120,   121,     0,   122,   123,    93,    32,    33,    32,    33,
       0,     0,     0,     0,    34,    94,    34,   253,    95,    96,
      97,    98,    99,   100,   101,   102,     0,     0,     0,     0,
       0,   104,   105,     0,     0,     0,    32,    33,     0,     0,
       0,     0,     0,     0,    34,   253,     0,     0,   113,   114,
     115,     0,     0,   117,   118,   119,     0,   121,     0,   122,
     123,   104,   105,     0,     0,     0,     0,     0,   106,   107,
     108,   109,   110,   111,   112,     0,     0,     0,     0,   266,
     267,     0,     0,   117,   118,   119,   120,   121,     0,     0,
     123
};

#define yypact_value_is_default(yystate) \
  ((yystate) == (-348))

#define yytable_value_is_error(yytable_value) \
  YYID (0)

static const yytype_int16 yycheck[] =
{
      10,   217,   208,   106,    52,   103,   188,   130,   277,    52,
     357,     1,   245,   149,   281,   275,     6,    10,   106,   103,
      81,    65,     4,     5,     0,    96,     4,     5,     1,   100,
      12,     1,    65,    43,    12,   103,    52,    65,   377,    67,
      50,    22,   381,    53,   132,   106,   279,    57,     6,   388,
     397,   390,    34,    34,    65,    11,    67,    35,    65,    65,
       1,    67,    97,    98,    99,     6,   101,    52,    49,   130,
      24,    52,    82,    83,   172,    65,    66,    67,    88,    89,
     151,   350,    92,    93,     1,   188,    96,   347,   172,   356,
     100,   162,   274,    66,    67,    65,    81,   107,   146,    65,
     188,   169,    87,   146,   172,   241,     1,    65,   314,    67,
       1,     6,    97,    98,    99,   321,   101,   152,   103,    65,
     353,   106,   338,   133,    65,    66,    67,   188,     5,   217,
     146,     4,     5,   143,   144,   120,     1,   381,    65,    12,
      67,   151,     7,     1,   388,   130,   390,   132,    65,    66,
      67,   161,   162,     8,     9,   140,     1,   142,    66,    32,
     195,   146,   197,    25,   149,   146,     1,   152,   184,   154,
      65,   274,    67,   244,    65,    66,    67,   248,    65,   189,
     190,   191,   192,   193,   200,   201,   274,   172,    65,     1,
      67,   176,   177,     4,     5,   176,   177,     4,     5,   184,
      65,    66,    67,   188,   239,    12,    64,    65,   243,    67,
     195,     1,   197,   274,   199,   200,   201,    65,   228,   342,
      65,    66,    67,   208,   209,    56,    65,   208,    67,   245,
      65,    66,   217,     7,   244,    44,    45,   247,   248,     1,
     225,    26,     4,     5,     6,     7,     3,     4,    65,     6,
     338,   286,     1,    65,   239,    67,   241,     1,   243,    65,
     245,   277,     6,   279,   335,    65,   276,     6,   278,   304,
     280,   374,   282,   283,     1,    65,    66,   375,    65,     1,
      67,   342,     4,     5,     6,     7,   374,    27,    31,   274,
     275,    65,   277,    67,   279,     1,   281,     3,     4,    56,
       6,   286,     1,    65,    66,    67,    65,    33,    65,     1,
      67,     3,     4,   374,     6,    59,    65,    66,   303,   304,
      59,    65,    66,    67,    28,   335,    65,    65,    67,   314,
     315,    52,     6,   314,   350,    66,   321,   353,    65,    66,
     321,    66,    65,    65,    66,    67,    23,   382,   358,     1,
      56,    66,     1,   338,     6,     1,    66,   342,     1,    65,
      81,    67,   347,     6,    56,   350,    65,    66,   353,     4,
       5,   356,   357,    65,    66,    67,    97,    98,    99,     1,
     101,     6,   103,     1,   419,   106,    65,    67,     1,   374,
     375,    65,   377,    67,     1,    60,   381,   382,     1,   120,
       7,     1,    66,   388,     1,   390,    65,    59,     1,   130,
      66,   132,   397,    65,    66,    67,    65,    66,    67,    65,
      66,    67,    65,    66,    67,   146,   147,   437,   149,     1,
      65,   152,    67,   154,   419,   445,     1,    66,    65,     1,
      67,    65,     1,    65,    66,   430,    66,    65,    66,    67,
       1,   172,    65,    66,    67,   176,   177,    66,    65,    62,
      67,    65,    65,   184,    67,    65,    66,   188,    65,    66,
      67,    65,    65,    66,   195,    61,   197,    63,   199,   200,
     201,     1,     4,     5,     1,    66,    66,   208,   209,    66,
      12,     4,     5,    65,    66,    67,   217,     1,     6,    12,
      65,    66,    67,    65,    66,    67,    65,    66,    67,     1,
       6,    62,     1,    66,    65,    94,    67,    30,   239,    66,
     241,     1,   243,    66,   245,   104,   105,    49,    66,   108,
     109,   110,   111,   112,   113,   114,   115,    66,   117,   118,
     119,    65,   121,   122,   123,    65,    66,    67,    65,    66,
      67,    59,    43,   274,   275,    66,   277,    65,   279,    67,
     281,    65,    66,    67,    65,   286,    67,    66,    22,    65,
      65,    67,    66,    65,    66,    67,    65,    66,    66,    66,
      66,    66,   303,   304,    66,    65,    66,     4,     5,     6,
       7,    66,    66,   314,     4,     5,     6,     7,     4,     5,
     321,    66,     4,     5,     4,     5,    12,    13,     4,     5,
      12,    66,    12,    13,    66,   194,    12,   338,    50,    66,
      66,   342,    42,    29,    30,    21,   347,    29,   207,   350,
       4,     5,   353,    46,   146,   356,   357,    56,    12,   218,
     102,    47,    48,   437,   146,    51,    52,    53,    65,    55,
      67,   166,    58,   374,   375,    65,   377,    67,   315,   140,
     381,   382,   146,   374,   225,   374,   320,   388,   252,   390,
     430,   332,   172,    -1,   253,    -1,   397,    51,    52,    53,
      -1,    -1,    -1,    -1,    58,    -1,    -1,   266,   267,    14,
      15,    16,    17,    18,    19,    20,    21,    -1,   419,    -1,
      -1,     3,     4,     5,    -1,    -1,    -1,    -1,    -1,   430,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    -1,    -1,    -1,    -1,    -1,    -1,    29,    30,    -1,
      32,    -1,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    -1,    -1,    -1,    46,    47,    48,    49,    -1,    51,
      52,    53,    54,    55,    -1,    57,    58,    -1,    -1,     3,
       4,     5,    -1,    -1,    -1,    -1,    -1,    -1,    12,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    -1,
      -1,    -1,    -1,    -1,    -1,    29,    30,    -1,    -1,    -1,
      -1,   370,    36,    37,    38,    39,    40,    41,    42,    -1,
      -1,    -1,    46,    47,    48,    49,    -1,    51,    52,    53,
      54,    55,    -1,    57,    58,     3,     4,     5,     4,     5,
      -1,    -1,    -1,    -1,    12,    13,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    -1,    -1,    -1,    -1,
      -1,    29,    30,    -1,    -1,    -1,     4,     5,    -1,    -1,
      -1,    -1,    -1,    -1,    12,    13,    -1,    -1,    46,    47,
      48,    -1,    -1,    51,    52,    53,    -1,    55,    -1,    57,
      58,    29,    30,    -1,    -1,    -1,    -1,    -1,    36,    37,
      38,    39,    40,    41,    42,    -1,    -1,    -1,    -1,    47,
      48,    -1,    -1,    51,    52,    53,    54,    55,    -1,    -1,
      58
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    65,    71,    10,     0,    65,    73,    11,    65,    82,
      74,    24,     8,     9,    83,     1,    66,    69,    70,     6,
      59,    65,    67,    77,    79,   100,   101,   120,    65,    84,
      65,    75,     4,     5,    12,    72,    72,    66,    25,    65,
      85,    56,    72,    80,    65,    86,    26,    65,    96,    65,
      80,    66,    70,    27,    65,    88,    86,    31,    65,   102,
      72,    66,     7,    65,    72,    77,    79,    81,    90,    93,
     111,   117,   120,   136,   138,   141,   143,   144,   147,   148,
      66,    70,    87,    28,    66,    88,    66,    70,    97,    33,
      65,   132,    76,     3,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    29,    30,    36,    37,    38,    39,
      40,    41,    42,    46,    47,    48,    49,    51,    52,    53,
      54,    55,    57,    58,    65,    77,    79,    90,    92,    66,
      70,    66,    70,    89,    66,    65,    79,    98,    99,    66,
      70,    66,    70,   103,    23,    66,    66,    70,    66,    70,
     142,   146,   101,    66,    70,   142,    65,    77,    79,   143,
     145,   145,   145,    66,   142,   145,    96,    65,    66,    69,
      77,    79,   139,   140,   141,   151,   101,   101,    65,    77,
      79,    90,    93,   112,   113,   147,   150,   151,    70,   115,
     101,   101,   101,   101,   101,   101,   101,   101,     6,   101,
     101,   101,     5,    77,    79,   130,   131,   101,   101,   101,
      92,    65,    77,    79,    93,    95,    66,    70,    32,    99,
      65,    79,   104,   108,    66,    70,    66,    70,   133,    65,
      78,    81,    98,   104,   105,    77,   100,   145,    66,    70,
      66,    70,   142,   145,    64,    60,    70,   153,    62,   142,
      66,    66,   102,    13,    65,   141,    66,   140,    72,    77,
      79,    91,    72,    77,    79,    94,    47,    48,    77,    79,
     114,   120,   113,    66,    70,    70,   122,    70,   116,    70,
     119,    70,   125,   101,   145,    66,   145,    66,     6,    77,
      79,   126,   127,    65,    77,    79,   117,   118,    77,    79,
     120,   121,    66,   101,    91,     3,     4,     6,    56,    77,
      79,   123,   124,    95,   101,    34,   108,    65,   134,    66,
      70,    35,    66,   145,   100,    66,   145,   142,   121,    65,
     154,    66,    70,    66,   142,    62,    65,   138,   101,    66,
      66,   101,   101,    66,   113,   124,    66,    70,   118,    66,
      70,   121,    66,    70,   127,    66,    70,    70,   128,    66,
     145,    66,    66,    66,     7,    77,    79,   129,   145,    66,
      91,    65,    79,   105,   106,    43,   134,    91,    66,    66,
      66,    44,    45,   154,    66,    66,   142,    66,    95,    66,
      92,   124,   118,   121,   127,   129,    66,    70,    66,    66,
      66,   101,    65,    77,    79,   109,   110,   111,   112,    65,
      77,    79,   151,   152,    65,    77,    79,   148,   149,   149,
     145,    66,   149,   149,   129,    66,    61,    63,   107,    65,
     135,    66,   145,    66,    66,    66,    66,    50,    65,    77,
      79,   136,   137,    66,    66,    97,    66,    66
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  However,
   YYFAIL appears to be in use.  Nevertheless, it is formally deprecated
   in Bison 2.4.2's NEWS entry, where a plan to phase it out is
   discussed.  */

#define YYFAIL		goto yyerrlab
#if defined YYFAIL
  /* This is here to suppress warnings from the GCC cpp's
     -Wunused-macros.  Normally we don't worry about that warning, but
     some users do, and we want to make it easy for users to remove
     YYFAIL uses, which will produce warnings from Bison 2.5.  */
#endif

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (&yylloc, alf_file, ast_out, YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (&yylval, &yylloc, YYLEX_PARAM)
#else
# define YYLEX yylex (&yylval, &yylloc)
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value, Location, alf_file, ast_out); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, FILE* alf_file, std::unique_ptr<alf::CAlfTuple>& ast_out)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep, yylocationp, alf_file, ast_out)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
    YYLTYPE const * const yylocationp;
    FILE* alf_file;
    std::unique_ptr<alf::CAlfTuple>& ast_out;
#endif
{
  if (!yyvaluep)
    return;
  YYUSE (yylocationp);
  YYUSE (alf_file);
  YYUSE (ast_out);
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, FILE* alf_file, std::unique_ptr<alf::CAlfTuple>& ast_out)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep, yylocationp, alf_file, ast_out)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
    YYLTYPE const * const yylocationp;
    FILE* alf_file;
    std::unique_ptr<alf::CAlfTuple>& ast_out;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  YY_LOCATION_PRINT (yyoutput, *yylocationp);
  YYFPRINTF (yyoutput, ": ");
  yy_symbol_value_print (yyoutput, yytype, yyvaluep, yylocationp, alf_file, ast_out);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
#else
static void
yy_stack_print (yybottom, yytop)
    yytype_int16 *yybottom;
    yytype_int16 *yytop;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, YYLTYPE *yylsp, int yyrule, FILE* alf_file, std::unique_ptr<alf::CAlfTuple>& ast_out)
#else
static void
yy_reduce_print (yyvsp, yylsp, yyrule, alf_file, ast_out)
    YYSTYPE *yyvsp;
    YYLTYPE *yylsp;
    int yyrule;
    FILE* alf_file;
    std::unique_ptr<alf::CAlfTuple>& ast_out;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       , &(yylsp[(yyi + 1) - (yynrhs)])		       , alf_file, ast_out);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, yylsp, Rule, alf_file, ast_out); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (0, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  YYSIZE_T yysize1;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = 0;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - Assume YYFAIL is not used.  It's too flawed to consider.  See
       <http://lists.gnu.org/archive/html/bison-patches/2009-12/msg00024.html>
       for details.  YYERROR is fine as it does not invoke this
       function.
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                yysize1 = yysize + yytnamerr (0, yytname[yyx]);
                if (! (yysize <= yysize1
                       && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                  return 2;
                yysize = yysize1;
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  yysize1 = yysize + yystrlen (yyformat);
  if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
    return 2;
  yysize = yysize1;

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp, FILE* alf_file, std::unique_ptr<alf::CAlfTuple>& ast_out)
#else
static void
yydestruct (yymsg, yytype, yyvaluep, yylocationp, alf_file, ast_out)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
    YYLTYPE *yylocationp;
    FILE* alf_file;
    std::unique_ptr<alf::CAlfTuple>& ast_out;
#endif
{
  YYUSE (yyvaluep);
  YYUSE (yylocationp);
  YYUSE (alf_file);
  YYUSE (ast_out);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {
      case 3: /* "\"operator\"" */

	{ gc((yyvaluep->OP_TYPE_)); };

	break;
      case 72: /* "Identifier" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 73: /* "MacroDefs" */

	{ gc((yyvaluep->CMacroDefList_)); };

	break;
      case 74: /* "MacroDefList" */

	{ gc((yyvaluep->vector_CMacroDefTuple)); };

	break;
      case 75: /* "MacroDef" */

	{ gc((yyvaluep->CMacroDefTuple_)); };

	break;
      case 76: /* "MacroFormalArgList" */

	{ gc((yyvaluep->vector_CMacroFormalArg)); };

	break;
      case 77: /* "MacroFormalArg" */

	{ gc((yyvaluep->CMacroFormalArg_)); };

	break;
      case 78: /* "Definable" */

	{ gc((yyvaluep->CGenericNode_)); };

	break;
      case 79: /* "MacroCall" */

	{ gc((yyvaluep->CMacroCallTuple_)); };

	break;
      case 80: /* "MacroActualList" */

	{ gc((yyvaluep->vector_CGenericNode)); };

	break;
      case 81: /* "MacroActual" */

	{ gc((yyvaluep->CGenericNode_)); };

	break;
      case 82: /* "Lau" */

	{ gc((yyvaluep->CLauTuple_)); };

	break;
      case 84: /* "Exports" */

	{ gc((yyvaluep->CExportsTuple_)); };

	break;
      case 85: /* "Imports" */

	{ gc((yyvaluep->CImportsTuple_)); };

	break;
      case 86: /* "FRefs" */

	{ gc((yyvaluep->CFRefList_)); };

	break;
      case 87: /* "FRefList" */

	{ gc((yyvaluep->vector_CFRefTuple)); };

	break;
      case 88: /* "LRefs" */

	{ gc((yyvaluep->CLRefList_)); };

	break;
      case 89: /* "LRefList" */

	{ gc((yyvaluep->vector_CLRefTuple)); };

	break;
      case 90: /* "FRef_C" */

	{ gc((yyvaluep->CFRefTuple_)); };

	break;
      case 91: /* "FRefId" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 92: /* "FRef" */

	{ gc((yyvaluep->CFRefTuple_)); };

	break;
      case 93: /* "LRef_C" */

	{ gc((yyvaluep->CLRefTuple_)); };

	break;
      case 94: /* "LRefId" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 95: /* "LRef" */

	{ gc((yyvaluep->CLRefTuple_)); };

	break;
      case 96: /* "Decls" */

	{ gc((yyvaluep->CDeclList_)); };

	break;
      case 97: /* "AllocList" */

	{ gc((yyvaluep->vector_CAllocTuple)); };

	break;
      case 98: /* "Alloc_C" */

	{ gc((yyvaluep->CAllocTuple_)); };

	break;
      case 99: /* "Alloc" */

	{ gc((yyvaluep->CAllocTuple_)); };

	break;
      case 100: /* "Size_C" */

	{ gc((yyvaluep->CSize_)); };

	break;
      case 101: /* "Size" */

	{ gc((yyvaluep->CSize_)); };

	break;
      case 102: /* "Inits" */

	{ gc((yyvaluep->CInitList_)); };

	break;
      case 103: /* "InitList" */

	{ gc((yyvaluep->vector_CInitTuple)); };

	break;
      case 104: /* "Init_C" */

	{ gc((yyvaluep->CInitTuple_)); };

	break;
      case 105: /* "Ref_C" */

	{ gc((yyvaluep->CRefTuple_)); };

	break;
      case 106: /* "Ref" */

	{ gc((yyvaluep->CRefTuple_)); };

	break;
      case 107: /* "InitOpt" */

	{ gc((yyvaluep->InitOption_)); };

	break;
      case 108: /* "Init" */

	{ gc((yyvaluep->CInitTuple_)); };

	break;
      case 109: /* "Val_C" */

	{ gc((yyvaluep->AVal_)); };

	break;
      case 110: /* "Val" */

	{ gc((yyvaluep->AVal_)); };

	break;
      case 111: /* "ValLists" */

	{ gc((yyvaluep->AVal_)); };

	break;
      case 112: /* "Const_C" */

	{ gc((yyvaluep->AConst_)); };

	break;
      case 113: /* "Const" */

	{ gc((yyvaluep->AConst_)); };

	break;
      case 114: /* "Repeats" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 115: /* "ConstList" */

	{ gc((yyvaluep->vector_AConst)); };

	break;
      case 116: /* "SignedValList" */

	{ gc((yyvaluep->vector_CString)); };

	break;
      case 117: /* "SignedVal_C" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 118: /* "SignedVal" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 119: /* "UnsignedStringList" */

	{ gc((yyvaluep->vector_CString)); };

	break;
      case 120: /* "UnsignedString_C" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 121: /* "UnsignedString" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 122: /* "HexStringList" */

	{ gc((yyvaluep->vector_CString)); };

	break;
      case 123: /* "HexString_C" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 124: /* "HexString" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 125: /* "BinStringList" */

	{ gc((yyvaluep->vector_CString)); };

	break;
      case 126: /* "BinString_C" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 127: /* "BinString" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 128: /* "FloatValList" */

	{ gc((yyvaluep->vector_CString)); };

	break;
      case 129: /* "FloatVal" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 130: /* "CharString_C" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 131: /* "CharString" */

	{ gc((yyvaluep->CString_)); };

	break;
      case 132: /* "Funcs" */

	{ gc((yyvaluep->CFuncList_)); };

	break;
      case 133: /* "FuncList" */

	{ gc((yyvaluep->vector_CFuncTuple)); };

	break;
      case 134: /* "Func" */

	{ gc((yyvaluep->CFuncTuple_)); };

	break;
      case 135: /* "ArgDecls" */

	{ gc((yyvaluep->CArgDeclList_)); };

	break;
      case 136: /* "Scope_C" */

	{ gc((yyvaluep->CScopeTuple_)); };

	break;
      case 137: /* "Scope" */

	{ gc((yyvaluep->CScopeTuple_)); };

	break;
      case 138: /* "Stmts" */

	{ gc((yyvaluep->CStmtList_)); };

	break;
      case 139: /* "LabelStmtList" */

	{ gc((yyvaluep->vector_CGenericNode)); };

	break;
      case 140: /* "LabelStmt" */

	{ gc((yyvaluep->CGenericNode_)); };

	break;
      case 141: /* "Stmt" */

	{ gc((yyvaluep->AStmt_)); };

	break;
      case 142: /* "ExprList" */

	{ gc((yyvaluep->vector_AExpr)); };

	break;
      case 143: /* "Expr_C" */

	{ gc((yyvaluep->AExpr_)); };

	break;
      case 144: /* "LabelExpr" */

	{ gc((yyvaluep->AExpr_)); };

	break;
      case 145: /* "Expr" */

	{ gc((yyvaluep->AExpr_)); };

	break;
      case 146: /* "SizeList" */

	{ gc((yyvaluep->vector_CSize)); };

	break;
      case 147: /* "NumVal" */

	{ gc((yyvaluep->ANumVal_)); };

	break;
      case 148: /* "IntNumVal_C" */

	{ gc((yyvaluep->CIntNumValTuple_)); };

	break;
      case 149: /* "IntNumVal" */

	{ gc((yyvaluep->CIntNumValTuple_)); };

	break;
      case 150: /* "Addr" */

	{ gc((yyvaluep->CAddrTuple_)); };

	break;
      case 151: /* "Label_C" */

	{ gc((yyvaluep->CLabelTuple_)); };

	break;
      case 152: /* "Label" */

	{ gc((yyvaluep->CLabelTuple_)); };

	break;
      case 153: /* "TargetList" */

	{ gc((yyvaluep->vector_ATarget)); };

	break;
      case 154: /* "Target" */

	{ gc((yyvaluep->ATarget_)); };

	break;

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (FILE* alf_file, std::unique_ptr<alf::CAlfTuple>& ast_out);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */


/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (FILE* alf_file, std::unique_ptr<alf::CAlfTuple>& ast_out)
#else
int
yyparse (alf_file, ast_out)
    FILE* alf_file;
    std::unique_ptr<alf::CAlfTuple>& ast_out;
#endif
#endif
{
/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Location data for the lookahead symbol.  */
YYLTYPE yylloc;

    /* Number of syntax errors so far.  */
    int yynerrs;

    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       `yyss': related to states.
       `yyvs': related to semantic values.
       `yyls': related to locations.

       Refer to the stacks thru separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    /* The location stack.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls;
    YYLTYPE *yylsp;

    /* The locations where the error started and ended.  */
    YYLTYPE yyerror_range[3];

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yytoken = 0;
  yyss = yyssa;
  yyvs = yyvsa;
  yyls = yylsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */
  yyssp = yyss;
  yyvsp = yyvs;
  yylsp = yyls;

#if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
  /* Initialize the default location before parsing starts.  */
  yylloc.first_line   = yylloc.last_line   = 1;
  yylloc.first_column = yylloc.last_column = 1;
#endif

/* User initialization code.  */

{
	extern void alf_restart(FILE*);
	init_src(alf_file);
	alf_restart(alf_file);
#	if YYDEBUG
	extern int yydebug;
	yydebug = 1;
#	endif
}


  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;
	YYLTYPE *yyls1 = yyls;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);

	yyls = yyls1;
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss_alloc, yyss);
	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
	YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;
  *++yylsp = yylloc;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location.  */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:

    {
		//system("pause");
		if (alf_char == YYEOF) YYABORT; // to avoid infinite error recovery
		yyclearin;
		//yyerrok;
	}
    break;

  case 5:

    {
		ast_out.reset( new CAlfTuple(mkCOORD((yylsp[(1) - (11)])), (yyvsp[(3) - (11)].CMacroDefList_), (yyvsp[(4) - (11)].CLauTuple_), get_src((yylsp[(5) - (11)])), (yyvsp[(6) - (11)].CExportsTuple_), (yyvsp[(7) - (11)].CImportsTuple_), (yyvsp[(8) - (11)].CDeclList_), (yyvsp[(9) - (11)].CInitList_), (yyvsp[(10) - (11)].CFuncList_)) );
		if (alf_nerrs != 0) {
			ast_out.reset(0);
			YYABORT;
		}
	}
    break;

  case 6:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), get_src((yylsp[(1) - (1)]))); }
    break;

  case 7:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), get_src((yylsp[(1) - (1)]))); }
    break;

  case 8:

    { (yyval.CMacroDefList_) = new CMacroDefList(mkCOORD((yylsp[(1) - (4)])), *(yyvsp[(3) - (4)].vector_CMacroDefTuple)); delete (yyvsp[(3) - (4)].vector_CMacroDefTuple); }
    break;

  case 9:

    { (yyval.vector_CMacroDefTuple) = (yyvsp[(1) - (3)].vector_CMacroDefTuple); (yyval.vector_CMacroDefTuple)->push_back((yyvsp[(3) - (3)].CMacroDefTuple_)); }
    break;

  case 10:

    { (yyval.vector_CMacroDefTuple) = new vector<CMacroDefTuple*>; }
    break;

  case 11:

    {
		// TODO: 
		//MACRO_DEF.is_macro_definition = 1;
		(yyval.CMacroDefTuple_) = new CMacroDefTuple(mkCOORD((yylsp[(1) - (8)])), (yyvsp[(4) - (8)].CString_), new CMacroFormalArgList(mkCOORD((yylsp[(5) - (8)])), *(yyvsp[(5) - (8)].vector_CMacroFormalArg)), (yyvsp[(7) - (8)].CGenericNode_));
		delete (yyvsp[(5) - (8)].vector_CMacroFormalArg);
		print_alf_error(&(yylsp[(2) - (8)]), "Unfortunately, macros are currently not supported in SWEET, so macro_defs must be empty");
		gc((yyval.CMacroDefTuple_)); // right-hand side semantic values are destroyed here too
		++alf_nerrs;
		YYERROR;
	}
    break;

  case 12:

    { (yyval.vector_CMacroFormalArg) = (yyvsp[(1) - (3)].vector_CMacroFormalArg); (yyval.vector_CMacroFormalArg)->push_back((yyvsp[(3) - (3)].CMacroFormalArg_)); }
    break;

  case 13:

    { (yyval.vector_CMacroFormalArg) = new vector<CMacroFormalArg*>; }
    break;

  case 14:

    {
		// TODO:
		/* Make sure that macro formal-argument-identifier strings is only used within macrodefinitions. */
		//IF(NOT(INCLUDING (ALF.is_macro_definition, MACRO_DEF.is_macro_definition)), message(ERROR, "A macro formal-argument-identifier string can only be used within macro definitions!", 0, COORDREF));
		(yyval.CMacroFormalArg_) = new CMacroFormalArg(mkCOORD((yylsp[(1) - (2)])), (yyvsp[(2) - (2)].CString_)->Get());
		delete (yyvsp[(2) - (2)].CString_);
		print_alf_error(&(yyloc), "Unfortunately, macros are currently not supported in SWEET, so formal macro arguments cannot be used");
		gc((yyval.CMacroFormalArg_));
		++alf_nerrs;
		YYERROR;
	}
    break;

  case 15:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].CGenericNode_); }
    break;

  case 16:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].CAllocTuple_); }
    break;

  case 17:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].CInitTuple_); }
    break;

  case 18:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].CRefTuple_); }
    break;

  case 19:

    {
		// TODO:
		//MACROCALL.is_macrocall = true;
		(yyval.CMacroCallTuple_) = new CMacroCallTuple(mkCOORD((yylsp[(1) - (5)])), (yyvsp[(3) - (5)].CString_), new CGenericList(mkCOORD((yylsp[(4) - (5)])), *(yyvsp[(4) - (5)].vector_CGenericNode), false, false));
		delete (yyvsp[(4) - (5)].vector_CGenericNode);
		print_alf_error(&(yylsp[(2) - (5)]), "Unfortunately, macros are currently not supported in SWEET");
		gc((yyval.CMacroCallTuple_)); // right-hand side semantic values are destroyed here too
		++alf_nerrs;
		YYERROR;
	}
    break;

  case 20:

    {
		// TODO:
		//MACROCALL.is_macrocall = true;
		(yyval.CMacroCallTuple_) = new CMacroCallTuple(mkCOORD((yylsp[(1) - (4)])), (yyvsp[(2) - (4)].CString_), new CGenericList(mkCOORD((yylsp[(3) - (4)])), *(yyvsp[(3) - (4)].vector_CGenericNode), false, false));
		delete (yyvsp[(3) - (4)].vector_CGenericNode);
		print_alf_error(&(yylsp[(2) - (4)]), "Unfortunately, macros are currently not supported in SWEET");
		gc((yyval.CMacroCallTuple_)); // right-hand side semantic values are destroyed here too
		++alf_nerrs;
		YYERROR;
	}
    break;

  case 21:

    { (yyval.vector_CGenericNode) = (yyvsp[(1) - (3)].vector_CGenericNode); (yyval.vector_CGenericNode)->push_back((yyvsp[(3) - (3)].CGenericNode_)); }
    break;

  case 22:

    { (yyval.vector_CGenericNode) = new vector<CGenericNode*>; }
    break;

  case 23:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].AExpr_); }
    break;

  case 24:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].CString_); }
    break;

  case 25:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].CString_); }
    break;

  case 26:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].CStmtList_); }
    break;

  case 27:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].AStmt_); }
    break;

  case 28:

    { (yyval.CGenericNode_) = new CString(mkCOORD((yylsp[(1) - (1)])), get_src((yylsp[(1) - (1)]))); }
    break;

  case 29:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].AVal_); }
    break;

  case 30:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].CMacroCallTuple_); }
    break;

  case 31:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].CMacroFormalArg_); }
    break;

  case 32:

    { (yyval.CLauTuple_) = new CLauTuple(mkCOORD((yylsp[(1) - (4)])), (yyvsp[(3) - (4)].CSize_)); }
    break;

  case 35:

    { (yyval.CExportsTuple_) = new CExportsTuple(mkCOORD((yylsp[(1) - (5)])), (yyvsp[(3) - (5)].CFRefList_), (yyvsp[(4) - (5)].CLRefList_)); }
    break;

  case 36:

    { (yyval.CImportsTuple_) = new CImportsTuple(mkCOORD((yylsp[(1) - (5)])), (yyvsp[(3) - (5)].CFRefList_), (yyvsp[(4) - (5)].CLRefList_)); }
    break;

  case 37:

    { (yyval.CFRefList_) = new CFRefList(mkCOORD((yylsp[(1) - (3)]))); }
    break;

  case 38:

    { (yyval.CFRefList_) = new CFRefList(mkCOORD((yylsp[(1) - (4)])), *(yyvsp[(3) - (4)].vector_CFRefTuple)); delete (yyvsp[(3) - (4)].vector_CFRefTuple); }
    break;

  case 39:

    { (yyval.vector_CFRefTuple) = (yyvsp[(1) - (3)].vector_CFRefTuple); (yyval.vector_CFRefTuple)->push_back((yyvsp[(3) - (3)].CFRefTuple_)); }
    break;

  case 40:

    { (yyval.vector_CFRefTuple) = new vector<CFRefTuple*>(1, (yyvsp[(2) - (2)].CFRefTuple_)); }
    break;

  case 41:

    { (yyval.CLRefList_) = new CLRefList(mkCOORD((yylsp[(1) - (3)]))); }
    break;

  case 42:

    { (yyval.CLRefList_) = new CLRefList(mkCOORD((yylsp[(1) - (4)])), *(yyvsp[(3) - (4)].vector_CLRefTuple)); delete (yyvsp[(3) - (4)].vector_CLRefTuple); }
    break;

  case 43:

    { (yyval.vector_CLRefTuple) = (yyvsp[(1) - (3)].vector_CLRefTuple); (yyval.vector_CLRefTuple)->push_back((yyvsp[(3) - (3)].CLRefTuple_)); }
    break;

  case 44:

    { (yyval.vector_CLRefTuple) = new vector<CLRefTuple*>(1, (yyvsp[(2) - (2)].CLRefTuple_)); }
    break;

  case 45:

    { (yyval.CFRefTuple_) = new CFRefTuple(mkCOORD((yylsp[(1) - (5)])), (yyvsp[(3) - (5)].CSize_), (yyvsp[(4) - (5)].CString_)); }
    break;

  case 47:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 48:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 50:

    { (yyval.CFRefTuple_) = new CFRefTuple(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 51:

    { (yyval.CFRefTuple_) = new CFRefTuple(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 52:

    { (yyval.CLRefTuple_) = new CLRefTuple(mkCOORD((yylsp[(1) - (5)])), (yyvsp[(3) - (5)].CSize_), (yyvsp[(4) - (5)].CString_)); }
    break;

  case 54:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 55:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 57:

    { (yyval.CLRefTuple_) = new CLRefTuple(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 58:

    { (yyval.CLRefTuple_) = new CLRefTuple(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 59:

    { (yyval.CDeclList_) = new CDeclList(mkCOORD((yylsp[(1) - (3)]))); }
    break;

  case 60:

    { (yyval.CDeclList_) = new CDeclList(mkCOORD((yylsp[(1) - (4)])), *(yyvsp[(3) - (4)].vector_CAllocTuple)); delete (yyvsp[(3) - (4)].vector_CAllocTuple); }
    break;

  case 61:

    { (yyval.vector_CAllocTuple) = (yyvsp[(1) - (3)].vector_CAllocTuple); (yyval.vector_CAllocTuple)->push_back((yyvsp[(3) - (3)].CAllocTuple_)); }
    break;

  case 62:

    { (yyval.vector_CAllocTuple) = new vector<CAllocTuple*>(1, (yyvsp[(2) - (2)].CAllocTuple_)); }
    break;

  case 63:

    { (yyval.CAllocTuple_) = new CAllocTuple(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].CSize_), (yyvsp[(4) - (6)].CString_), (yyvsp[(5) - (6)].CSize_)); }
    break;

  case 65:

    { (yyval.CAllocTuple_) = new CAllocTuple(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 66:

    { (yyval.CSize_) = new CSize(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CString_)); }
    break;

  case 67:

    { (yyval.CSize_) = new CSize(mkCOORD((yylsp[(1) - (1)]))); }
    break;

  case 69:

    { (yyval.CSize_) = new CSize(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 70:

    { (yyval.CSize_) = new CSize(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 71:

    { (yyval.CInitList_) = new CInitList(mkCOORD((yylsp[(1) - (3)]))); }
    break;

  case 72:

    { (yyval.CInitList_) = new CInitList(mkCOORD((yylsp[(1) - (4)])), *(yyvsp[(3) - (4)].vector_CInitTuple)); delete (yyvsp[(3) - (4)].vector_CInitTuple); }
    break;

  case 73:

    { (yyval.vector_CInitTuple) = (yyvsp[(1) - (3)].vector_CInitTuple); (yyval.vector_CInitTuple)->push_back((yyvsp[(3) - (3)].CInitTuple_)); }
    break;

  case 74:

    { (yyval.vector_CInitTuple) = new vector<CInitTuple*>(1, (yyvsp[(2) - (2)].CInitTuple_)); }
    break;

  case 75:

    { (yyval.CInitTuple_) = new CInitTuple(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].CRefTuple_), (yyvsp[(4) - (6)].AVal_), (yyvsp[(5) - (6)].InitOption_)); }
    break;

  case 76:

    { (yyval.CRefTuple_) = new CRefTuple(mkCOORD((yylsp[(1) - (5)])), (yyvsp[(3) - (5)].CString_), (yyvsp[(4) - (5)].CIntNumValTuple_)); }
    break;

  case 78:

    { (yyval.CRefTuple_) = new CRefTuple(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 79:

    { (yyval.InitOption_) = CInitTuple::VOLATILE; }
    break;

  case 80:

    { (yyval.InitOption_) = CInitTuple::READ_ONLY; }
    break;

  case 81:

    { (yyval.InitOption_) = CInitTuple::NONE; }
    break;

  case 83:

    { (yyval.CInitTuple_) = new CInitTuple(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 84:

    { (yyval.AVal_) = (yyvsp[(1) - (1)].AConst_); }
    break;

  case 87:

    { (yyval.AVal_) = new CUnknownVal(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 88:

    { (yyval.AVal_) = new CUnknownVal(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 89:

    { (yyval.AVal_) = new CConstRepeatTuple(mkCOORD((yylsp[(1) - (5)])), (yyvsp[(3) - (5)].AConst_), (yyvsp[(4) - (5)].CString_)); }
    break;

  case 90:

    { (yyval.AVal_) = new CConstList(mkCOORD((yylsp[(1) - (4)])), *(yyvsp[(3) - (4)].vector_AConst)); delete (yyvsp[(3) - (4)].vector_AConst); }
    break;

  case 91:

    { (yyval.AVal_) = new CIntListTuple(mkCOORD((yylsp[(1) - (5)])), CIntNumValTuple::DEC_SIGNED, (yyvsp[(3) - (5)].CSize_), *(yyvsp[(4) - (5)].vector_CString)); delete (yyvsp[(4) - (5)].vector_CString); }
    break;

  case 92:

    { (yyval.AVal_) = new CIntListTuple(mkCOORD((yylsp[(1) - (5)])), CIntNumValTuple::DEC_UNSIGNED, (yyvsp[(3) - (5)].CSize_), *(yyvsp[(4) - (5)].vector_CString)); delete (yyvsp[(4) - (5)].vector_CString); }
    break;

  case 93:

    { (yyval.AVal_) = new CIntListTuple(mkCOORD((yylsp[(1) - (5)])), CIntNumValTuple::HEX, (yyvsp[(3) - (5)].CSize_), *(yyvsp[(4) - (5)].vector_CString)); delete (yyvsp[(4) - (5)].vector_CString); }
    break;

  case 94:

    { (yyval.AVal_) = new CIntListTuple(mkCOORD((yylsp[(1) - (5)])), CIntNumValTuple::BIN, (yyvsp[(3) - (5)].CSize_), *(yyvsp[(4) - (5)].vector_CString)); delete (yyvsp[(4) - (5)].vector_CString); }
    break;

  case 95:

    { (yyval.AVal_) = new CFloatListTuple(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].CSize_), (yyvsp[(4) - (6)].CSize_), *(yyvsp[(5) - (6)].vector_CString)); delete (yyvsp[(5) - (6)].vector_CString); }
    break;

  case 96:

    { (yyval.AVal_) = new CCharStringTuple(mkCOORD((yylsp[(1) - (4)])), (yyvsp[(3) - (4)].CString_)); }
    break;

  case 97:

    { (yyval.AConst_) = (yyvsp[(1) - (1)].ANumVal_); }
    break;

  case 98:

    { (yyval.AConst_) = (yyvsp[(1) - (1)].CFRefTuple_); }
    break;

  case 99:

    { (yyval.AConst_) = (yyvsp[(1) - (1)].CAddrTuple_); }
    break;

  case 100:

    { (yyval.AConst_) = (yyvsp[(1) - (1)].CLRefTuple_); }
    break;

  case 101:

    { (yyval.AConst_) = (yyvsp[(1) - (1)].CLabelTuple_); }
    break;

  case 102:

    { (yyval.AConst_) = new CUndefinedExprTuple(mkCOORD((yylsp[(1) - (4)])), (yyvsp[(3) - (4)].CSize_)); }
    break;

  case 104:

    { (yyval.AConst_) = new CUnknownConst(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 105:

    { (yyval.AConst_) = new CUnknownConst(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 107:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 108:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 109:

    { (yyval.vector_AConst) = (yyvsp[(1) - (3)].vector_AConst); (yyval.vector_AConst)->push_back((yyvsp[(3) - (3)].AConst_)); }
    break;

  case 110:

    { (yyval.vector_AConst) = new vector<AConst*>(1, (yyvsp[(2) - (2)].AConst_)); }
    break;

  case 111:

    { (yyval.vector_CString) = (yyvsp[(1) - (3)].vector_CString); (yyval.vector_CString)->push_back((yyvsp[(3) - (3)].CString_)); }
    break;

  case 112:

    { (yyval.vector_CString) = new vector<CString*>(1, (yyvsp[(2) - (2)].CString_)); }
    break;

  case 114:

    {
		string tmp = get_src((yylsp[(3) - (4)]));
		if (!IsValidNumber(tmp)) {
			print_alf_error(&(yylsp[(3) - (4)]), "Invalid decimal number");
			++alf_nerrs;
			YYERROR;
		}
		(yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (4)])), string("-") + tmp);
	}
    break;

  case 116:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 117:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 118:

    { (yyval.vector_CString) = (yyvsp[(1) - (3)].vector_CString); (yyval.vector_CString)->push_back((yyvsp[(3) - (3)].CString_)); }
    break;

  case 119:

    { (yyval.vector_CString) = new vector<CString*>(1, (yyvsp[(2) - (2)].CString_)); }
    break;

  case 120:

    {
		string tmp = get_src((yylsp[(1) - (1)]));
		if (!IsValidNumber(tmp)) {
			print_alf_error(&(yylsp[(1) - (1)]), "Invalid decimal number");
			++alf_nerrs;
			YYERROR;
		}
		(yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), tmp);
	}
    break;

  case 122:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 123:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 124:

    { (yyval.vector_CString) = (yyvsp[(1) - (3)].vector_CString); (yyval.vector_CString)->push_back((yyvsp[(3) - (3)].CString_)); }
    break;

  case 125:

    { (yyval.vector_CString) = new vector<CString*>(1, (yyvsp[(2) - (2)].CString_)); }
    break;

  case 126:

    {
		string tmp = get_src((yylsp[(1) - (1)]));
		if (!IsValidHexNumber(tmp)) {
			print_alf_error(&(yylsp[(1) - (1)]), "Invalid hexadecimal number");
			++alf_nerrs;
			YYERROR;
		}		
		(yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), tmp);
	}
    break;

  case 127:

    {
		string tmp = get_src((yylsp[(1) - (1)]));
		if (!IsValidHexNumber(tmp)) {
			print_alf_error(&(yylsp[(1) - (1)]), "Invalid hexadecimal number");
			++alf_nerrs;
			YYERROR;
		}
		(yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), tmp);
	}
    break;

  case 128:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), "def"); }
    break;

  case 129:

    {
		if ((yyvsp[(1) - (1)].OP_TYPE_) == COpNumExprTuple::OP_TYPE_ADD)
			(yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), "add");
		else {
			print_alf_error(&(yylsp[(1) - (1)]), "Invalid hexadecimal number");
			++alf_nerrs;
			YYERROR;
		}
	}
    break;

  case 131:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 132:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 133:

    { (yyval.vector_CString) = (yyvsp[(1) - (3)].vector_CString); (yyval.vector_CString)->push_back((yyvsp[(3) - (3)].CString_)); }
    break;

  case 134:

    { (yyval.vector_CString) = new vector<CString*>(1, (yyvsp[(2) - (2)].CString_)); }
    break;

  case 135:

    {
		string tmp = get_src((yylsp[(1) - (1)]));
		if (!IsValidBinaryNumber(tmp)) {
			print_alf_error(&(yylsp[(1) - (1)]), "Invalid binary number");
			++alf_nerrs;
			YYERROR;
		}
		(yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), tmp);
	}
    break;

  case 137:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 138:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 139:

    { (yyval.vector_CString) = (yyvsp[(1) - (3)].vector_CString); (yyval.vector_CString)->push_back((yyvsp[(3) - (3)].CString_)); }
    break;

  case 140:

    { (yyval.vector_CString) = new vector<CString*>(1, (yyvsp[(2) - (2)].CString_)); }
    break;

  case 141:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), get_src((yylsp[(1) - (1)]))); }
    break;

  case 142:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 143:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 144:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), get_src((yylsp[(1) - (1)]))); }
    break;

  case 146:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 147:

    { (yyval.CString_) = new CString(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 148:

    { (yyval.CFuncList_) = new CFuncList(mkCOORD((yylsp[(1) - (3)]))); }
    break;

  case 149:

    { (yyval.CFuncList_) = new CFuncList(mkCOORD((yylsp[(1) - (4)])), *(yyvsp[(3) - (4)].vector_CFuncTuple)); delete (yyvsp[(3) - (4)].vector_CFuncTuple); }
    break;

  case 150:

    { (yyval.vector_CFuncTuple) = (yyvsp[(1) - (3)].vector_CFuncTuple); (yyval.vector_CFuncTuple)->push_back((yyvsp[(3) - (3)].CFuncTuple_)); }
    break;

  case 151:

    { (yyval.vector_CFuncTuple) = new vector<CFuncTuple*>(1, (yyvsp[(2) - (2)].CFuncTuple_)); }
    break;

  case 152:

    { (yyval.CFuncTuple_) = new CFuncTuple(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].CLabelTuple_), (yyvsp[(4) - (6)].CArgDeclList_), (yyvsp[(5) - (6)].CScopeTuple_)); }
    break;

  case 153:

    { (yyval.CArgDeclList_) = new CArgDeclList(mkCOORD((yylsp[(1) - (3)]))); }
    break;

  case 154:

    { (yyval.CArgDeclList_) = new CArgDeclList(mkCOORD((yylsp[(1) - (4)])), *(yyvsp[(3) - (4)].vector_CAllocTuple)); delete (yyvsp[(3) - (4)].vector_CAllocTuple); }
    break;

  case 155:

    { (yyval.CScopeTuple_) = new CScopeTuple(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].CDeclList_), (yyvsp[(4) - (6)].CInitList_), (yyvsp[(5) - (6)].CStmtList_)); }
    break;

  case 157:

    { (yyval.CScopeTuple_) = new CScopeTuple(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 158:

    { (yyval.CScopeTuple_) = new CScopeTuple(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 159:

    { (yyval.CStmtList_) = new CStmtList(mkCOORD((yylsp[(1) - (3)]))); }
    break;

  case 160:

    {
		unique_ptr<vector<AStmt*> > tmp(CParserHelper::AttachLabels(*(yyvsp[(3) - (4)].vector_CGenericNode)));
		delete (yyvsp[(3) - (4)].vector_CGenericNode);
		(yyval.CStmtList_) = new CStmtList(mkCOORD((yylsp[(1) - (4)])), *tmp);
	}
    break;

  case 161:

    { (yyval.vector_CGenericNode) = (yyvsp[(1) - (2)].vector_CGenericNode); (yyval.vector_CGenericNode)->push_back((yyvsp[(2) - (2)].CGenericNode_)); }
    break;

  case 162:

    { (yyval.vector_CGenericNode) = new vector<CGenericNode*>(1, (yyvsp[(1) - (1)].CGenericNode_)); }
    break;

  case 163:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].AStmt_); }
    break;

  case 164:

    { (yyval.CGenericNode_) = (yyvsp[(2) - (2)].AStmt_); }
    break;

  case 165:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].CLabelTuple_); }
    break;

  case 166:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].CMacroCallTuple_); }
    break;

  case 167:

    { (yyval.CGenericNode_) = (yyvsp[(1) - (1)].CMacroFormalArg_); }
    break;

  case 168:

    { (yyval.AStmt_) = new CNullStmtTuple(mkCOORD((yylsp[(1) - (3)]))); }
    break;

  case 169:

    {
		SetAllowedTypesIfUnknown(*(yyvsp[(3) - (6)].vector_AExpr), "ADDR_EXPR");
		SetAllowedTypesIfUnknown(*(yyvsp[(5) - (6)].vector_AExpr), "EXPR");
		(yyval.AStmt_) = new CStoreStmtTuple(mkCOORD((yylsp[(1) - (6)])), new CExprList(mkCOORD((yylsp[(3) - (6)])), *(yyvsp[(3) - (6)].vector_AExpr)), new CExprList(mkCOORD((yylsp[(5) - (6)])), *(yyvsp[(5) - (6)].vector_AExpr)));
		delete (yyvsp[(3) - (6)].vector_AExpr);
		delete (yyvsp[(5) - (6)].vector_AExpr);
	}
    break;

  case 170:

    {
		SetAllowedTypesIfUnknown((yyvsp[(3) - (6)].AExpr_), "LABEL_EXPR");
		(yyval.AStmt_) = new CJumpStmtTuple(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].AExpr_), (yyvsp[(5) - (6)].CString_));
	}
    break;

  case 171:

    {
		SetAllowedTypesIfUnknown((yyvsp[(3) - (5)].AExpr_), "NUM_EXPR");
		(yyval.AStmt_) = new CSwitchStmtTuple(mkCOORD((yylsp[(1) - (5)])), (yyvsp[(3) - (5)].AExpr_), new CTargetList(mkCOORD((yylsp[(4) - (5)])), *(yyvsp[(4) - (5)].vector_ATarget)));
		delete (yyvsp[(4) - (5)].vector_ATarget);
	}
    break;

  case 172:

    {
		SetAllowedTypesIfUnknown((yyvsp[(3) - (5)].AExpr_), "LABEL_EXPR");
		(yyval.AStmt_) = new CCallStmtTuple(mkCOORD((yylsp[(1) - (5)])), (yyvsp[(3) - (5)].AExpr_));
	}
    break;

  case 173:

    {
		SetAllowedTypesIfUnknown((yyvsp[(3) - (6)].AExpr_), "LABEL_EXPR");
		SetAllowedTypesIfUnknown(*(yyvsp[(4) - (6)].vector_AExpr), "EXPR");
		(yyval.AStmt_) = new CCallStmtTuple(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].AExpr_), new CExprList(mkCOORD((yylsp[(4) - (6)])), *(yyvsp[(4) - (6)].vector_AExpr)), CCallStmtTuple::EXPR_VECTOR);
		delete (yyvsp[(4) - (6)].vector_AExpr);
	}
    break;

  case 174:

    {
		SetAllowedTypesIfUnknown((yyvsp[(3) - (6)].AExpr_), "LABEL_EXPR");
		SetAllowedTypesIfUnknown(*(yyvsp[(5) - (6)].vector_AExpr), "ADDR_EXPR");
		(yyval.AStmt_) = new CCallStmtTuple(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].AExpr_), new CExprList(mkCOORD((yylsp[(5) - (6)])), *(yyvsp[(5) - (6)].vector_AExpr)), CCallStmtTuple::ADDR_VECTOR);
		delete (yyvsp[(5) - (6)].vector_AExpr);
	}
    break;

  case 175:

    {
		SetAllowedTypesIfUnknown((yyvsp[(3) - (7)].AExpr_), "LABEL_EXPR");
		SetAllowedTypesIfUnknown(*(yyvsp[(4) - (7)].vector_AExpr), "EXPR");
		SetAllowedTypesIfUnknown(*(yyvsp[(6) - (7)].vector_AExpr), "ADDR_EXPR");
		(yyval.AStmt_) = new CCallStmtTuple(mkCOORD((yylsp[(1) - (7)])), (yyvsp[(3) - (7)].AExpr_), new CExprList(mkCOORD((yylsp[(4) - (7)])), *(yyvsp[(4) - (7)].vector_AExpr)), new CExprList(mkCOORD((yylsp[(6) - (7)])), *(yyvsp[(6) - (7)].vector_AExpr)));
		delete (yyvsp[(4) - (7)].vector_AExpr);
		delete (yyvsp[(6) - (7)].vector_AExpr);
	}
    break;

  case 176:

    { (yyval.AStmt_) = new CReturnStmtTuple(mkCOORD((yylsp[(1) - (3)])), new CExprList(mkCOORD((yylsp[(3) - (3)])), vector<AExpr*>())); }
    break;

  case 177:

    {
		SetAllowedTypesIfUnknown(*(yyvsp[(3) - (4)].vector_AExpr), "EXPR");
		(yyval.AStmt_) = new CReturnStmtTuple(mkCOORD((yylsp[(1) - (4)])), new CExprList(mkCOORD((yylsp[(3) - (4)])), *(yyvsp[(3) - (4)].vector_AExpr)));
		delete (yyvsp[(3) - (4)].vector_AExpr); 
	}
    break;

  case 178:

    {
		SetAllowedTypesIfUnknown((yyvsp[(3) - (4)].AExpr_), "FREF_EXPR");
		(yyval.AStmt_) = new CFreeStmtTuple(mkCOORD((yylsp[(1) - (4)])), (yyvsp[(3) - (4)].AExpr_));
	}
    break;

  case 179:

    { (yyval.AStmt_) = (yyvsp[(1) - (1)].CScopeTuple_); }
    break;

  case 180:

    { (yyval.vector_AExpr) = (yyvsp[(1) - (3)].vector_AExpr); (yyval.vector_AExpr)->push_back((yyvsp[(3) - (3)].AExpr_)); }
    break;

  case 181:

    { (yyval.vector_AExpr) = new vector<AExpr*>(1, (yyvsp[(2) - (2)].AExpr_)); }
    break;

  case 182:

    { (yyval.AExpr_) = (yyvsp[(1) - (1)].ANumVal_); }
    break;

  case 183:

    { (yyval.AExpr_) = (yyvsp[(1) - (1)].CFRefTuple_); }
    break;

  case 184:

    {
		SetAllowedTypesIfUnknown((yyvsp[(4) - (6)].AExpr_), "FREF_EXPR");
		SetAllowedTypesIfUnknown((yyvsp[(5) - (6)].AExpr_), "NUM_EXPR");
		(yyval.AExpr_) = CreateAddrNode(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].CSize_), (yyvsp[(4) - (6)].AExpr_), (yyvsp[(5) - (6)].AExpr_));
	}
    break;

  case 185:

    { (yyval.AExpr_) = (yyvsp[(1) - (1)].CLRefTuple_); }
    break;

  case 187:

    { (yyval.AExpr_) = new CUndefinedExprTuple(mkCOORD((yylsp[(1) - (4)])), (yyvsp[(3) - (4)].CSize_)); }
    break;

  case 188:

    {
		SetAllowedTypesIfUnknown((yyvsp[(4) - (5)].AExpr_), "ADDR_EXPR");
		(yyval.AExpr_) = new CLoadExprTuple(mkCOORD((yylsp[(1) - (5)])), (yyvsp[(3) - (5)].CSize_), (yyvsp[(4) - (5)].AExpr_));
	}
    break;

  case 189:

    {
		unique_ptr<CFRefTuple> fref( new CFRefTuple(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].CSize_)->Copy(), (yyvsp[(4) - (6)].CString_)) );
		(yyval.AExpr_) = new CDynAllocTuple(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].CSize_), fref.release(), (yyvsp[(5) - (6)].AExpr_));
		print_alf_error(&(yylsp[(2) - (6)]), "Unfortunately, dyn_alloc is currently not supported in SWEET");
		gc((yyval.AExpr_)); // right-hand side semantic values are destroyed here too
		++alf_nerrs;
		YYERROR;
	}
    break;

  case 190:

    { (yyval.AExpr_) = new COpNumExprTuple(mkCOORD((yylsp[(1) - (3)])), (yyvsp[(2) - (3)].OP_TYPE_)); }
    break;

  case 191:

    { (yyval.AExpr_) = new COpNumExprTuple(mkCOORD((yylsp[(1) - (4)])), (yyvsp[(2) - (4)].OP_TYPE_), new CSizeList(mkCOORD((yylsp[(3) - (4)])), *(yyvsp[(3) - (4)].vector_CSize))); delete (yyvsp[(3) - (4)].vector_CSize); }
    break;

  case 192:

    { (yyval.AExpr_) = new COpNumExprTuple(mkCOORD((yylsp[(1) - (4)])), (yyvsp[(2) - (4)].OP_TYPE_), new CExprList(mkCOORD((yylsp[(3) - (4)])), *(yyvsp[(3) - (4)].vector_AExpr))); delete (yyvsp[(3) - (4)].vector_AExpr); }
    break;

  case 193:

    {
		(yyval.AExpr_) = new COpNumExprTuple(mkCOORD((yylsp[(1) - (5)])), (yyvsp[(2) - (5)].OP_TYPE_), new CSizeList(mkCOORD((yylsp[(3) - (5)])), *(yyvsp[(3) - (5)].vector_CSize)), new CExprList(mkCOORD((yylsp[(4) - (5)])), *(yyvsp[(4) - (5)].vector_AExpr)));
		delete (yyvsp[(3) - (5)].vector_CSize);
		delete (yyvsp[(4) - (5)].vector_AExpr);
	}
    break;

  case 194:

    {
		SetAllowedTypesIfUnknown((yyvsp[(4) - (6)].AExpr_), "LREF_EXPR");
		SetAllowedTypesIfUnknown((yyvsp[(5) - (6)].AExpr_), "NUM_EXPR");
		(yyval.AExpr_) = CreateLabelNode(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].CSize_), (yyvsp[(4) - (6)].AExpr_), (yyvsp[(5) - (6)].AExpr_));
	}
    break;

  case 196:

    { (yyval.AExpr_) = new CUnknownExpr(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 197:

    { (yyval.AExpr_) = new CUnknownExpr(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 198:

    { (yyval.vector_CSize) = (yyvsp[(1) - (3)].vector_CSize); (yyval.vector_CSize)->push_back((yyvsp[(3) - (3)].CSize_)); }
    break;

  case 199:

    { (yyval.vector_CSize) = new vector<CSize*>(1, (yyvsp[(2) - (2)].CSize_)); }
    break;

  case 200:

    { (yyval.ANumVal_) = (yyvsp[(1) - (1)].CIntNumValTuple_); }
    break;

  case 201:

    { (yyval.ANumVal_) = new CFloatValTuple(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].CSize_), (yyvsp[(4) - (6)].CSize_), (yyvsp[(5) - (6)].CString_)); }
    break;

  case 202:

    { (yyval.CIntNumValTuple_) = new CIntNumValTuple(mkCOORD((yylsp[(1) - (5)])), (yyvsp[(3) - (5)].CSize_), (yyvsp[(4) - (5)].CString_)); }
    break;

  case 203:

    { (yyval.CIntNumValTuple_) = new CIntNumValTuple(mkCOORD((yylsp[(1) - (5)])), CIntNumValTuple::DEC_UNSIGNED, (yyvsp[(3) - (5)].CSize_), (yyvsp[(4) - (5)].CString_)); }
    break;

  case 204:

    { (yyval.CIntNumValTuple_) = new CIntNumValTuple(mkCOORD((yylsp[(1) - (5)])), CIntNumValTuple::HEX, (yyvsp[(3) - (5)].CSize_), (yyvsp[(4) - (5)].CString_)); }
    break;

  case 205:

    { (yyval.CIntNumValTuple_) = new CIntNumValTuple(mkCOORD((yylsp[(1) - (5)])), CIntNumValTuple::BIN, (yyvsp[(3) - (5)].CSize_), (yyvsp[(4) - (5)].CString_)); }
    break;

  case 207:

    { (yyval.CIntNumValTuple_) = new CIntNumValTuple(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 208:

    { (yyval.CIntNumValTuple_) = new CIntNumValTuple(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 209:

    { (yyval.CAddrTuple_) = new CAddrTuple(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].CSize_), (yyvsp[(4) - (6)].CFRefTuple_), (yyvsp[(5) - (6)].CIntNumValTuple_)); }
    break;

  case 210:

    { (yyval.CLabelTuple_) = new CLabelTuple(mkCOORD((yylsp[(1) - (6)])), (yyvsp[(3) - (6)].CSize_), (yyvsp[(4) - (6)].CLRefTuple_), (yyvsp[(5) - (6)].CIntNumValTuple_)); }
    break;

  case 212:

    { (yyval.CLabelTuple_) = new CLabelTuple(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroCallTuple_)); }
    break;

  case 213:

    { (yyval.CLabelTuple_) = new CLabelTuple(mkCOORD((yylsp[(1) - (1)])), (yyvsp[(1) - (1)].CMacroFormalArg_)); }
    break;

  case 214:

    { (yyval.vector_ATarget) = (yyvsp[(1) - (3)].vector_ATarget); (yyval.vector_ATarget)->push_back((yyvsp[(3) - (3)].ATarget_)); }
    break;

  case 215:

    { (yyval.vector_ATarget) = new vector<ATarget*>(1, (yyvsp[(2) - (2)].ATarget_)); }
    break;

  case 216:

    { (yyval.ATarget_) = new CTargetTuple(mkCOORD((yylsp[(1) - (5)])), (yyvsp[(3) - (5)].CIntNumValTuple_), (yyvsp[(4) - (5)].AExpr_)); }
    break;

  case 217:

    { (yyval.ATarget_) = new CDefaultTuple(mkCOORD((yylsp[(1) - (4)])), (yyvsp[(3) - (4)].AExpr_)); }
    break;



      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (&yylloc, alf_file, ast_out, YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (&yylloc, alf_file, ast_out, yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }

  yyerror_range[1] = yylloc;

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval, &yylloc, alf_file, ast_out);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  yyerror_range[1] = yylsp[1-yylen];
  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp, yylsp, alf_file, ast_out);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  *++yyvsp = yylval;

  yyerror_range[2] = yylloc;
  /* Using YYLLOC is tempting, but would change the location of
     the lookahead.  YYLOC is available though.  */
  YYLLOC_DEFAULT (yyloc, yyerror_range, 2);
  *++yylsp = yyloc;

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined(yyoverflow) || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (&yylloc, alf_file, ast_out, YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, &yylloc, alf_file, ast_out);
    }
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp, yylsp, alf_file, ast_out);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}



