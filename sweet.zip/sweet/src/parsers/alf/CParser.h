
#ifndef ALF_CPARSER_H_
#define ALF_CPARSER_H_

#include <string>

namespace alf
{
class CAlfTuple;

/** This is the public interface to the ALF-parser.
 */
class CParser
{
public:
   /**	Get an abstract syntax tree from a file containing alf-code.
    		Note: This method can only be called once, how can we reset
         the state of eli so this isn't a restriction?

    		@return	The abstract syntax tree created from the alf-code 
    					or NULL if there was an error.
    */
   static CAlfTuple* ParseFile(std::string file);
};

}

#endif
