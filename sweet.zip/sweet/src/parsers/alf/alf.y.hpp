/* A Bison parser, made by GNU Bison 2.5.  */

/* Bison interface for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2011 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* "%code requires" blocks.  */


	#include "program/alf/alf.h"
	#include <cstdio>
	#include <vector>
	#include <memory>




/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     OP = 258,
     IDENTIFIER = 259,
     QSTRING = 260,
     INTEGER = 261,
     FLOATVAL = 262,
     little_endian = 263,
     big_endian = 264,
     alf_ = 265,
     macro_defs = 266,
     macrocall = 267,
     label = 268,
     null = 269,
     store = 270,
     jump = 271,
     switch_ = 272,
     call = 273,
     return_ = 274,
     free_ = 275,
     scope = 276,
     stmts = 277,
     funcs = 278,
     least_addr_unit = 279,
     exports = 280,
     imports = 281,
     frefs = 282,
     lrefs = 283,
     fref = 284,
     lref = 285,
     decls = 286,
     alloc = 287,
     inits = 288,
     init = 289,
     ref_ = 290,
     const_repeat = 291,
     const_list = 292,
     hex_list = 293,
     dec_list = 294,
     udec_list = 295,
     bin_list = 296,
     float_list = 297,
     func = 298,
     target = 299,
     default_ = 300,
     load = 301,
     undefined = 302,
     addr = 303,
     minus_ = 304,
     arg_decls = 305,
     bin_val = 306,
     dec_signed = 307,
     dec_unsigned = 308,
     char_string = 309,
     float_val = 310,
     def = 311,
     dyn_alloc = 312,
     hex_val = 313,
     inf = 314,
     leaving = 315,
     read_only = 316,
     result = 317,
     volatile_ = 318,
     with = 319
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{


	alf::COpNumExprTuple::OP_TYPE OP_TYPE_;
	alf::CInitTuple::InitOption InitOption_;

	alf::CGenericNode* CGenericNode_;
	alf::CMacroDefList* CMacroDefList_;
	alf::CMacroDefTuple* CMacroDefTuple_;
	alf::CMacroCallTuple* CMacroCallTuple_;
	alf::CMacroFormalArg* CMacroFormalArg_;
	alf::CLauTuple* CLauTuple_;
	alf::CExportsTuple* CExportsTuple_;
	alf::CImportsTuple* CImportsTuple_;
	alf::CFRefList* CFRefList_;
	alf::CLRefList* CLRefList_;
	alf::CDeclList* CDeclList_;
	alf::CAllocTuple* CAllocTuple_;
	alf::CInitList* CInitList_;
	alf::CInitTuple* CInitTuple_; 
	alf::CRefTuple* CRefTuple_;
	alf::CFuncList* CFuncList_;
	alf::CFuncTuple* CFuncTuple_; 
	alf::CArgDeclList* CArgDeclList_;
	alf::CScopeTuple* CScopeTuple_;
	alf::CStmtList* CStmtList_;
	alf::AStmt* AStmt_;
	alf::ATarget* ATarget_;
	alf::CSize* CSize_;
	alf::CString* CString_;
	alf::AVal* AVal_;
	alf::ANumVal* ANumVal_;
	alf::AConst* AConst_;
	alf::AExpr* AExpr_;
	alf::CIntNumValTuple* CIntNumValTuple_;
	alf::CFRefTuple* CFRefTuple_;
	alf::CLRefTuple* CLRefTuple_;
	alf::CAddrTuple* CAddrTuple_;
	alf::CLabelTuple* CLabelTuple_;

	std::vector<alf::CGenericNode*>* vector_CGenericNode;
	std::vector<alf::CMacroDefTuple*>* vector_CMacroDefTuple;
	std::vector<alf::CMacroFormalArg*>* vector_CMacroFormalArg;
	std::vector<alf::CSize*>* vector_CSize;
	std::vector<alf::CAllocTuple*>* vector_CAllocTuple;
	std::vector<alf::CInitTuple*>* vector_CInitTuple;
	std::vector<alf::CFuncTuple*>* vector_CFuncTuple;
	std::vector<alf::CString*>* vector_CString;
	std::vector<alf::AConst*>* vector_AConst;
	std::vector<alf::AExpr*>* vector_AExpr;
	std::vector<alf::CFRefTuple*>* vector_CFRefTuple;
	std::vector<alf::CLRefTuple*>* vector_CLRefTuple;
	std::vector<alf::ATarget*>* vector_ATarget;



} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif



#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



/* "%code provides" blocks.  */


	/** Parses an ALF program from @a alf_file and returns the AST in @a ast_out
		@returns 0 iff parsing was successful
		@post    @a ast_out is empty if parsing was unsuccessful */
	int alf_parse(FILE* alf_file, std::unique_ptr<alf::CAlfTuple>& ast_out);

	/** Should be called after the last parse (it can also be called after every parse)
		to clean up dynamic memory allocated by the lexer */
	int alf_lex_destroy();



