/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     AA_STMT_ENTRY = 258,
     AA_STMT_EXIT = 259,
     AA_FUNC_ENTRY = 260,
     AA_PROG_ENTRY = 261,
     AA_VOLATILE = 262,
     AA_WHEN_CALLED = 263,
     AA_RET_VAL = 264,
     AA_STRING = 265,
     AA_SEMICOLON = 266,
     AA_PARALLEL = 267,
     AA_ASSIGN = 268,
     AA_STAR = 269,
     AA_GLB = 270,
     AA_LUB = 271,
     AA_OR = 272,
     AA_INT = 273,
     AA_FLOAT = 274,
     AA_ADDR = 275,
     AA_LABEL = 276,
     AA_INUM = 277,
     AA_FNUM = 278,
     AA_TOP = 279,
     AA_TOP_INT = 280,
     AA_TOP_FLOAT = 281,
     AA_TOP_ADDR = 282,
     AA_TOP_LABEL = 283
   };
#endif
/* Tokens.  */
#define AA_STMT_ENTRY 258
#define AA_STMT_EXIT 259
#define AA_FUNC_ENTRY 260
#define AA_PROG_ENTRY 261
#define AA_VOLATILE 262
#define AA_WHEN_CALLED 263
#define AA_RET_VAL 264
#define AA_STRING 265
#define AA_SEMICOLON 266
#define AA_PARALLEL 267
#define AA_ASSIGN 268
#define AA_STAR 269
#define AA_GLB 270
#define AA_LUB 271
#define AA_OR 272
#define AA_INT 273
#define AA_FLOAT 274
#define AA_ADDR 275
#define AA_LABEL 276
#define AA_INUM 277
#define AA_FNUM 278
#define AA_TOP 279
#define AA_TOP_INT 280
#define AA_TOP_FLOAT 281
#define AA_TOP_ADDR 282
#define AA_TOP_LABEL 283




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE

{
  unsigned int line_no;
  CALFAbsAnnotList * aa_absann_list;
  CALFAbsAnnot * aa_absann;
  CALFAbsAnnotPosition * aa_position;
  CALFAbsAnnot::UpdateType aa_update;
  list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > * aa_var_vals_list;
  CALFAbsAnnotVar * aa_var;
  list<CALFAbsAnnotVal *> * aa_val_list;
  CALFAbsAnnotVal * aa_val;
  list<CFRefIdOffsetPair *> * aa_frefid_offs_list;
  list<CLRefIdOffsetPair *> * aa_lrefid_offs_list;
  string * aa_string;
  long long aa_inum;
  float aa_fnum;
}
/* Line 1529 of yacc.c.  */

	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE absann_ALF_lval;

