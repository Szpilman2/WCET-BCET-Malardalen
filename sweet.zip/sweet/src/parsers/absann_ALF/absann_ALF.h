#ifndef _ABSANN_ALF_Y_H
#define _ABSANN_ALF_Y_H
// $Id: absann.h 326 2009-05-06 07:59:13Z msl01 $

int absann_ALF_parse(void *);

int absann_ALF_lex_destroy (void );

#endif
