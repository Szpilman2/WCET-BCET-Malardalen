// $Id $

#ifndef COMMAND_CHECK_H_INCLUDED
#define COMMAND_CHECK_H_INCLUDED

#include "CCommand.h"
#include <string>

namespace cmd {

/** \class CCommandCheck
   Checks the AST for errors that would otherwise be needed in variuous places.
*/
class CCommandCheck : public CCommand
{
public:
  typedef enum KEY { SIZE, CONNECTED, EXTERNAL_REFS, FCALLS, ON, OFF } KEY;

   void Validate(const CSession *session) {}

   void Execute(const CSession *session);

   CCommand *Copy() const { return new CCommandCheck(*this); }

private:
   /** If turned on, perform a semantic check on the AST. Inconsistencies that can be found
      statically will be checked. This saves a lot of checks in the analyses.
      This is currently only implemented in ALF. */
   bool Size(const CSession *session, std::string& error_message) const;

   /** In turned on, check the program for unresolved references */
   bool UnresolvedRefs(const CSession *session, std::string& error_message) const;

   /** If turned on, check for ambiguous starting point for the analysis */
   bool StartingPoint(const CSession *session, std::string& error_message) const;

   /** If turned on, check that (non-function-pointer) function calls are made
      with right amount of arguments, that each function has at
      least one return statement, that all return statements has the
      same amount of arguments, and that calls and returns are
      consistent in terms of arguments. */
   bool FunctionCalls(const CSession *session, std::string& error_message) const;

   /** If turned on, do a rudimentary type analysis of the current program. This
      works only for ALF programs. */
   bool TypeAnalysis(const CSession* session, std::string& error_message) const;
};
}

#endif
