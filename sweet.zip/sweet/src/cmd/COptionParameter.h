#ifndef OPTION_PARAMETER_H_
#define OPTION_PARAMETER_H_


#include "CVal.h"

#include <string>
#include <cassert>

namespace cmd {

/** \class  COptionParameter
   Contains a specification of an allowed command line option's parameter.
   A parameter has a key value, a name (a keyword) and descriptions of what
   it means. Optionally a parameter may require a value.
*/
class COptionParameter
{
public:
   /** Constructs a new parameter.
      \param parameter_key A key identifying this parameter in the C++ code
         uniquely among other parameters to the same option.
      \param name A string keyword unique among the parameters to the same
         option. To be matched with the user input.
      \param short_description An description of the parameter's meaning. There
         is no special limit of the text length, but to conform to the standard
         it can be a good idea to pass a text in the range of 20-200 characters.
      \param detailed_description An optional detailed description of the
         parameter. This is the place for a detailed description of the
         semantics of this parameter.
      \post \a NeedVal() returns false. */
   COptionParameter(int parameter_key,
                    std::string name,
                    std::string short_description,
                    std::string detailed_description="") :
                           parameter_key(parameter_key),
                           name(name),
                           short_description(short_description),
                           detailed_description(detailed_description),
                           need_val(false),
                           is_mandatory(false)
   { }

   /** \return The key of this parameter. */
   int GetParameterKey() const { return parameter_key; }

   /** \return The name of this parameter. */
   std::string GetName() const { return name; }

   /** \return The short description of this parameter. */
   std::string GetShortDescription() const { return short_description; }

   /** \return The detailed description of this parameter, or, if there is none,
      the short one.*/
   std::string GetDetailedDescription() const
   {
      if (detailed_description.empty()) {
         return short_description;
      } else {
         return detailed_description;
      }
   }

   /** Checks if this parameter needs a value to be used.
      \return True if it needs a value, else false. */
   bool NeedVal() const { return need_val; }

   /** Checks if this parameter is mandatory.
      \return True if it is mandatory, else false. */
   bool IsMandatory() const { return is_mandatory; }

   /** \return A pointer to the value specification of this parameter.
      \pre \a NeedVal() returns true. */
   const CVal *GetVal() const { return &val; }

   /** Assigns a value specification to this parameter.
      \pre \a NeedVal() returns false. 
      \post \a NeedVal() returns true. */
   COptionParameter &operator=(CVal new_value) {
      assert(!need_val);
//       assert(!(val.HasDefaultVal() && is_mandatory));
      val = new_value;
      need_val=true;
      return *this;
   }

   /** Set the "mandatory" property of this option.
      \post \a IsMandatory() returns true. */
   COptionParameter &operator!() { is_mandatory = true; return *this; }

private:
   int parameter_key;
   std::string name;
   std::string short_description;
   std::string detailed_description;
   CVal val;
   bool need_val;
   bool is_mandatory;
};
}

#endif
