#ifndef CCOMMAND_PDG_H_
#define CCOMMAND_PDG_H_

#include "cmd/CCommand.h"
#include <map>
#include "rd/ReachingDefinitionsAnalysis.h"
#include "rd/ALFReachingDefinitionsAnalysis.h"
#include "dfa/ALFDefsAndUsesAnalysis.h"
#include "alf_slicing/ALFExtendedProgramControlFlowGraph.h"
#include "alf_slicing/ALFExtendedProgramControlDependencyGraph.h"
#include "alf_slicing/ALFExtendedProgramDataDependencyGraph.h"
#include "alf_slicing/ALFExtendedProgramDependencyGraph.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/ecfg/CECFGNode.h"

// -------------------------------------------------------
// Code for genearting a program dependency graph (PDG) based on a ALF
// code. Can run on an CG. Resulting graph is used in slicing. Can also 
// proint a lot of subgraphs. Require a RD analysis.
// -------------------------------------------------------

namespace cmd {

class CSession;

class CCommandPDG : public CCommand
{
public:

  // To create and delete the value analysis object
  CCommandPDG();
  ~CCommandPDG();

  // An enum holding all values that can be set by the user
  typedef enum KEY {} KEY;

  // Check if the arguments are valid. 
  void Validate(const CSession *session);

  // Runs the analysis to generated the EPDG graph 
  void Execute(const CSession *session);

  // To copy the commando 
  CCommand *Copy() const;

  // To get the generated program control dependency graph
  ALFExtendedProgramControlDependencyGraph * GetPCDG() { return _pcdg; }
  // To get the generated program data dependency graph
  ALFExtendedProgramDataDependencyGraph * GetPDDG() { return _pddg; }
  // To get the generated program dependency graph (the join of the first two graphs)
  ALFExtendedProgramDependencyGraph * GetPDG() { return _pdg; }
  
protected:
  
  // The objects created when deriving the program dependency graph
  ALFExtendedProgramControlDependencyGraph * _pcdg;
  ALFExtendedProgramDataDependencyGraph * _pddg;
  ALFExtendedProgramDependencyGraph * _pdg;

};

} // end cmd namespace

#endif

 
