// $Id $

#include "CCommandPrint.h"
#include "CCommandParse.h"
#include "CSession.h"
#include "graphs/cfg/CFlowGraph.h"
#include "graphs/cg/CCallGraph.h"
#include "graphs/scopes/CScopeGraph.h"
#include "graphs/scopes/CScope.h"
#include "graphs/scopes/CreateScopes.h"
#include "graphs/ecfg/CECFG.h"
#include "ptranal/CSteensgaardPA.h"
#include "program/CGenericProgram.h"
#include "program/CGenericFunction.h"
#include "symtab/CSymTabBase.h"
#include <iostream>
#include <fstream>
#include "tools/CTextBlock.h"

using namespace std;

namespace cmd {

CCommandPrint::
~CCommandPrint()
{
}

CCommand *
CCommandPrint::
Copy() const
{
   return new CCommandPrint(*this);
}

void
CCommandPrint::
Validate(const CSession *session)
{
   ValidateFiles(session, FILE_NAME, GRAPHS, "", STDOUT);

   // ---------------------------------
   // Set external after linkage options
   // ---------------------------------

   // Set default values
   _astl = false;
   _astl_file_name = "";
   _expl = false;
   _expl_file_name = "";
   _impl = false;
   _impl_file_name = "";

   // Go through and reset value if given by user
   for (unsigned i=0; i<output_settings.outputs.size(); ++i) {
      OutputSettings::Output output = output_settings.outputs[i];
      switch (output.key) {
      case ASTL: {
         _astl = true;
         if (!output.file_name.empty()) {
            _astl_file_name = output.file_name.c_str();
         }
         break;
      }
      case EXPL: {
         _expl = true;
         if (!output.file_name.empty()) {
            _expl_file_name = output.file_name.c_str();
         }
         break;
      }
      case IMPL: {
         _impl = true;
         if (!output.file_name.empty()) {
            _impl_file_name = output.file_name.c_str();
         }
         break;
      }
      default:
         break;
      }
   }
}

void
CCommandPrint::
Execute(const CSession *session)
{
   CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
   for (unsigned i=0; i<output_settings.outputs.size(); ++i) {
      OutputSettings::Output output = output_settings.outputs[i];
      // To avoid overwriting already written values (made in CCommandParse)
      if(output.key == ASTL || output.key == IMPL || output.key == EXPL) continue; 
      // Else, open stream to write output to
      ostream *out_stream;
      ofstream fs;
      if (output.file_name.empty()) {
         out_stream = &cout;
      } else {
         fs.open(output.file_name.c_str(), ios::out);
         out_stream = &fs;
      }
      // Check what we should print
      switch (output.key) {
      case CFG: {
         CCallGraph *cg = command_parse->GetCallGraph();
         const vector<CFlowGraph*> &flow_graphs = command_parse->GetFlowGraphs();
         for (unsigned j=0; j<flow_graphs.size(); ++j) {
            CFlowGraph *cfg = flow_graphs[j];
            PrintCFGAsBNFGrammar(*out_stream, cfg, cg);
            *out_stream << endl;
         }
         break;
      }
      case CFGD: {
         const vector<CFlowGraph*> &flow_graphs = command_parse->GetFlowGraphs();
         for (unsigned j=0; j<flow_graphs.size(); ++j) {
            CFlowGraph *cfg = flow_graphs[j];
            cfg->PrintDetailed(*out_stream);
            *out_stream << endl;
         }
         break;
      }
      case SG: {
         CScopeGraph *scope_graph;
         CCallGraphNode *start_node = command_parse->GetStartNode();
         CCallGraph *call_graph = command_parse->GetCallGraph();
         scope_graph = new CScopeGraph(new CECFG());
         CGenericProgram *ast = command_parse->GetAst();
         const CSteensgaardPA *pa = command_parse->GetPointerAnalysis();
         CreateScopes::ContextSensitive(scope_graph, call_graph, start_node, ast->GetSymTab(), *pa);
         scope_graph->PrintFlowFactFile(*out_stream);
         delete scope_graph;
         break;
      }
      case CG: {
         CCallGraph *call_graph = command_parse->GetCallGraph();
         call_graph->Print(*out_stream);
         break;
      }
      case AST: {
         CGenericProgram *ast = command_parse->GetAst();
         CTextBlock text_block;
         ast->AsText(&text_block);
         text_block.Show(*out_stream);
         break;
      }
      case PA: {
         const CSteensgaardPA *pa = command_parse->GetPointerAnalysis();
         pa->PrintAsPointsToSets(command_parse->GetAst()->GetSymTab(), *out_stream);
         break;
      }
      case SYMTAB: {
         CTextBlock textblock;
         command_parse->GetAst()->GetSymTab()->AsText(&textblock);
         textblock.Show(*out_stream);
         break;
      }
      default:
         break;
      }
      if (fs.is_open()) {
         fs.close();
      }
   }
}

void 
CCommandPrint::
PrintCFGAsBNFGrammar(std::ostream &o, CFlowGraph * cfg, CCallGraph * cg)
{
   o << "begin CFG " << endl;
   o << "  name " << cfg->Function()->PrettifiedName() << " ;" << endl;
   o << "  startnode " << cfg->GetEntry()->Name() << " ;" << endl;
   
   {
      o << "  nodes" << endl << "    ";
      for (unsigned i=0; i < cfg->NrOfNodes(); i++) {
         o << cfg->NodeAt(i)->Name() << " ";
      }
      o << ";" << endl;
   }

   // Print the edges in the CFG and extract edges from call-sites
   {
      o << "  edges" << endl << "    ";
      CFlowGraph::T_edge_list edges;
      cfg->Edges(&edges);
      for (CFlowGraph::T_edge_list_iterator edge_it = edges.begin(); edge_it != edges.end(); ++edge_it) {
         o << edge_it->from->Name() << "->" << edge_it->to->Name() << " ";
      }
      o << ";" << endl;
   }

   // To keep track of the call sites and where the calls go to
   std::map<CFlowGraphNode *, std::set<CFlowGraph *> > call_node_to_called_cfgs_map;

   // Print the calls edges in the given CFG
   {
      o << "  calls" << endl << "    ";
      // Extract the corresponding call graph node
      CCallGraphNode * cg_node = cg->FindNodeOfFunction(cfg->Function());
      // Extract all the call edges from nodes within this CFG
      for(CCallGraphNode::succ_iterator call_it = cg_node->SuccBegin();
         call_it != cg_node->SuccEnd(); ++call_it) {
         CFlowGraphNode * call_node = call_it->edge_annot->CallSite();
         CFlowGraph * called_cfg = call_it->node->FlowGraph();
         assert(call_node);
         assert(called_cfg);
         o << call_node->Name() << "->" << called_cfg->Function()->PrettifiedName() << " ";
      }
      o << ";" << endl;
   }
  
   // end CFG printout
   o << "end CFG" << endl;
}



}

