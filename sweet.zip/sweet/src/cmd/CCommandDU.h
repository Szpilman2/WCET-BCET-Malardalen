#ifndef CCOMMAND_DU_H_
#define CCOMMAND_DU_H_

#include "CCommand.h"
#include "dfa/ALFDefsAndUsesAnalysis.h"

// -------------------------------------------------------
// Code for setting up a def-use (DU) analysis on a ALF
// code. Resulting DU analysis algorithm class can be used 
// as input to other analyses.
// -------------------------------------------------------

namespace cmd {

class CSession;

/** \class CCommandDU
   Performs defines and use analysis on the input program.
*/
class CCommandDU : public CCommand
{
public:

  // To create and delete the value analysis object
  CCommandDU();
  ~CCommandDU();

  // An enum holding all values that can be set by the user
  typedef enum KEY { PRINT_ANALYSIS_RESULT, NOTHING } KEY;

  // Check if the arguments are valid. 
  void Validate(const CSession *session);

  // Runs the DU analysis alogrithm on the current cg or ecfg. 
  void Execute(const CSession *session);

  // To copy the commando 
  CCommand *Copy() const;

  // Returns a pointer to the resulting DU analysis result. 
  ALFDefsAndUsesAnalysis * GetDUAnalysis() const { return _du; }

protected:

   // The DU analysis objects 
   bool _print_analysis_result;
   std::string _output_file_name;
   ALFDefsAndUsesAnalysis * _du;

};

} // end cmd namespace

#endif
