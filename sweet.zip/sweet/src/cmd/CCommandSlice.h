#ifndef CCOMMAND_SLICE_H_
#define CCOMMAND_SLICE_H_

#include "cmd/CSession.h"
#include "cmd/CCommand.h"
#include "alf_slicing/ALFSlicing.h"

#include <vector>
#include <set>

#include <iostream>
#include <string>

// -------------------------------------------------------
// Code for doing program slicing based on a ALF code. The
// slice is based on a program dependency graph (PDG). The 
// slice can be performed on many type of code parts, such
// as single loops, single statements, all loops, all conditions.
// and individual globals. It can be a backward or a forward 
// slice. Makes mostly use of the code in ALFSlicing.
// -------------------------------------------------------

namespace cmd {

class CSession;

class CCommandSlice : public CCommand
{
public:

  // ---------------------------------
  // To create and delete the commando
  // ---------------------------------

  // To create and delete the value analysis object
  CCommandSlice();
  ~CCommandSlice();

  // An enum holding all values that can be set by the user
  typedef enum KEY { ENTITIES, LOOPS, CONDS, GLOBALS, ROOT_FUNC_INPUTS, ROOT_FUNC_RETURNS, 
                     LABELS, 
                     VARS, 
                     MUL, TOGETHER, INDIVIDUAL, 
                     DIRECTION, BACKWARD, FORWARD, 
                     PRINT, RES_ALL, RES_STMTS, RES_FUNCS, RES_GLOBALS, RES_LOCALS, RES_SCOPED_LOCALS, INVERT,
                     DRAW } KEY;

  // Check if the arguments are valid. 
  void Validate(const CSession *session);

  // Runs the analysis to generated the ESLICE graph 
  void Execute(const CSession *session);

  // To copy the commando 
  CCommand *Copy() const;

protected:

  // ---------------------------------
  // Help functions
  // ---------------------------------

  // Help functions for doing slicing on a set of statements 
  void SliceOnStmtsAndPrintAndDraw(std::set<alf::AStmt *> * start_stmts, std::string file_name_part);
  void SliceOnStmtsAndPrintAndDraw2(std::set<alf::AStmt *> * start_stmts, std::ostream * ds, std::ostream * ps);
 
  // Help functions for doing slicing on a set of variables
  void SliceOnVarsAndPrintAndDraw(std::set<unsigned int> * start_vars, std::string file_name_part);
  void SliceOnVarsAndPrintAndDraw2(std::set<unsigned int> * start_vars, std::ostream * ds, std::ostream * ps);

  // Help function for printing a slice. What things to including in
  // the printout is decided by values set by the user.
  void PrintResultingSlice(std::ostream * ps, std::set<alf::AStmt *> * stmts, std::set<unsigned int> * vars); 

  // ---------------------------------
  // Internal data structures
  // ---------------------------------

  const alf::CAlfTuple * _ast;

  // The algorithm class upon which the slicing is made
  ALFSlicing * _slicing_algo; 

  // Variables defining specific code entities to start slicing upon
  bool _has_entities;
  bool _slice_on_loops;
  bool _slice_on_conds;
  bool _slice_on_globals;
  bool _slice_on_root_func_inputs;
  bool _slice_on_root_func_returns;

  // If the user has provided a set of statement names to start slicing upon
  bool _has_labels;
  std::vector<std::string> _unsorted_labels;

  // If the user has provided a set of variable names to start slicing upon
  bool _has_vars;
  std::vector<std::string> _unsorted_vars;

  // To hold the things we should slice upon. Derived from given arguments. 
  std::set<alf::AStmt *> _stmts_to_slice_upon;
  std::set<unsigned int> _vars_to_slice_upon;

  // Boolean deciding if we should do individual slices on all
  // selected code entities or just one large single slice.
  bool _individual_slices;

  // Enum decinding if we should forward or backward slicing
  ALFSlicing::SLICE_DIRECTION _direction;

  // Determines whether the slice should be inverted or not
  bool _invert;

  // Booleans deciding if the slice should be printed and what
  // entities that should be printed
  bool _print_result;
  bool _print_res_stmts;
  bool _print_res_funcs;
  bool _print_res_globals;
  bool _print_res_locals;
  bool _print_res_scoped_locals;

  // Boolean deciding if the slice should be drawn
  bool _draw_result;

  // A pointer to the synmbol table. Is NOT owned by the class...
  CSymTabBase * _symtab;
};

} // end cmd namespace

#endif
