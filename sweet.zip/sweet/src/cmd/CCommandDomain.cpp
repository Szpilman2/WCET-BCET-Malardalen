// $Id $

#include "CCommandDomain.h"
#include "ae/AlfAbstractExecution.h"
#include <vector>
#include "globals.h"

using namespace std;

namespace cmd {

CCommandDomain::
~CCommandDomain()
{
   if (domain_settings) {
      delete domain_settings;
   }
}

CCommand *
CCommandDomain::
Copy() const
{
   assert(domain_settings==NULL);
   return new CCommandDomain(*this);
}

void
CCommandDomain::
Validate(const CSession *session)
{
   domain_settings = new CDomainSettings();

   {
      // ---------------------------------
      // Handle type options 
      // ---------------------------------
      // Transfer the argument to the settings structure (happens to be one-to-one)
      const CCommandArgument *type_argument = GetArgument(TYPE);

      switch (type_argument->GetVal()->AsKey()) {
      case INTERVAL:
         domain_settings->type = CDomainSettings::INTERVAL;
         break;
      case CLP:
         domain_settings->type = CDomainSettings::CLP;
         break;
         //     case CONGRUENCE:
         //       domain_settings->type = CDomainSettings::CONGRUENCE;
         //       break;
         //     case MIXED_INT:
         //       domain_settings->type = CDomainSettings::MIXED_INT;
         //       break;
         //     case PRODUCT:
         //       domain_settings->type = CDomainSettings::PRODUCT;
         //       break;
      }
   }
   
   // ---------------------------------
   // Determine floating point treatment
   // ---------------------------------
   {
      const CCommandArgument* float_arg = GetArgument(FLOATS);
      if (float_arg != 0) {
         switch (float_arg->GetVal()->AsKey())
         {
            case TOP_FLOATS:
               domain_settings->top_float = true;
               break;
            case ESTIM_FLOATS:
               domain_settings->top_float = false;
               break;
         };
      }
   }   

   {
     // ---------------------------------
     // Handle reuse options
     // ---------------------------------
     const CCommandArgument *reuse_argument = GetArgument(REUSE);
     vector <int> reuse_alternatives = reuse_argument->GetVal()->AsKeySet();
     
     // Check that not the alternative "none" and some specific reuse are specified together
     AssertUniqueAlternative(reuse_argument, NONE);
     // Same for all
     AssertUniqueAlternative(reuse_argument, ALL);
     
     // First, check if ALL or NONE has been set 
     bool all_or_none_reuse_set = false;
     for (unsigned i=0; i<reuse_alternatives.size(); ++i) {
       int reuse_alt = reuse_alternatives[i];
       switch (reuse_alt) {
       case NONE:
         memset(&domain_settings->reuse, false, sizeof(domain_settings->reuse));
         all_or_none_reuse_set = true;
         break;
       case ALL:
         memset(&domain_settings->reuse, true, sizeof(domain_settings->reuse));
         all_or_none_reuse_set = true;
         break;
       default:
         break;
       }
     }
   
     // Second, set things individually if neither NONE or ALL has been set
     if(!all_or_none_reuse_set) 
       {
         // Set all items to false initially
         memset(&domain_settings->reuse, false, sizeof(domain_settings->reuse));
         // Set each reuse item individually
         for (unsigned i=0; i<reuse_alternatives.size(); ++i) {
           int reuse_alt = reuse_alternatives[i];
           switch (reuse_alt) {
           case MEMORY:
             domain_settings->reuse.memory = true;
             break;
           case CALL_STACK:
             domain_settings->reuse.call_stack = true;
             break;
           case RECORDER:
             domain_settings->reuse.recorder = true;
             break;
           case RECORDER_HOLDER:
             domain_settings->reuse.recorder_holder = true;
             break;
//          case ECV:
//             domain_settings->reuse.ecv = true;
//             break;
//          case PATH:
//             domain_settings->reuse.path = true;
//             break;
//          case PT:
//             domain_settings->reuse.path_tree = true;
//             break;
//          case NCR:
//             domain_settings->reuse.node_recorder = true;
//             break;
//          case ECR:
//             domain_settings->reuse.edge_recorder = true;
//             break;
//          case ITER:
//             domain_settings->reuse.iter_recorder = true;
//             break;
//          case GV:
//             domain_settings->reuse.global_value_recorder = true;
//             break;
           default:
             break;
           }
         }
       }
   }
}

void
CCommandDomain::
Execute(const CSession *session)
{
   InitDomain(domain_settings);
}

}

