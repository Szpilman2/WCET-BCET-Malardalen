#include "CInputOptions.h"
#include "CInputExpr.h"
#include <stdexcept>
#include <iostream>

namespace cmd {

using namespace std;

CInputOptions::
CInputOptions(int nr_of_args, char **args)
{
   if (nr_of_args > 1) {
      ++args;
      if (**args == '-') {
         CInputOption *input_option = NULL;
         for (int i=1; i<nr_of_args; ++i) {
            char *current_string = *args++;
            if (*current_string == '-') {
               current_string++;
               bool long_name = false;
               if (*current_string == '-') {
                  current_string++;
                  long_name = true;
               }
               input_option = new CInputOption(current_string, long_name);
               push_back(input_option);
            } else {
               CInputOptionArgument *input_argument = new CInputOptionArgument(current_string);
               input_option->AddArgument(input_argument);
            }
         }
      } else {
         throw runtime_error(string(*args) + " is not an option. Options in sweet start with a '-'");
      }
   } else {
      throw runtime_error("No options given. At least an input file must be specified");
   }
}

CInputOptions::
~CInputOptions()
{
   for (unsigned i=0; i<size(); ++i) {
      delete at(i);
   }
}

}

