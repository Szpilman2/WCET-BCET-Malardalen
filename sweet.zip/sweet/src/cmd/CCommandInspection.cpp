// $Id $

#include "CCommandInspection.h"
#include "CCommandParse.h"
#include "CSession.h"
#include "graphs/ecfg/CECFG.h"
#include "graphs/cfg/CFlowGraph.h"
#include "graphs/scopes/CreateScopes.h"
#include "graphs/scopes/CScopeGraph.h"
#include "graphs/scopes/CScope.h"
#include "program/CGenericProgram.h"
#include "program/CGenericFunction.h"
#include "program/alf/CGenericNode.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CAlfTreeFilter.h"
#include "program/alf/CImportsTuple.h"
#include "program/alf/CExportsTuple.h"
#include "program/alf/CLRefList.h"
#include "program/alf/CFRefList.h"
#include "program/alf/CInitList.h"
#include "program/alf/CInitTuple.h"
#include "program/alf/CDeclList.h"
#include "program/alf/CFuncList.h"
#include "program/alf/CFuncTuple.h"
#include "program/alf/CArgDeclList.h"
#include "graphs/components/CComponentTree.h"
#include <vector>
#include <iostream>
#include <fstream>

using namespace std;

namespace cmd {

void
CCommandInspection::
Validate(const CSession *session)
{
   (void)session;

   // Check if there is a cost lookup table file given
   const CCommandArgument *file_argument = GetArgument(FILE);
   if (file_argument) {
     print_to_file = true;
     filename = file_argument->GetVal()->AsString();
     AssertFileAccessability(filename, "w");
   } else {
     print_to_file = false;
     filename = "";
   }
}

void
CCommandInspection::
Execute(const CSession *session)
{
   CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
   CCallGraph *call_graph = command_parse->GetCallGraph();
   CGenericProgram *ast = command_parse->GetAst();
   alf::CAlfTuple * alf_tuple = dynamic_cast<alf::CAlfTuple *>(ast);
   const CSteensgaardPA *pa = command_parse->GetPointerAnalysis();
   const std::vector<CFlowGraph*> & flow_graphs = command_parse->GetFlowGraphs();
   
   // Create a stream to write result to. If no file name has been
   // given std:cout should be used
   std::streambuf * buf;
   std::ofstream of;
   if(print_to_file) {
     of.open(filename.c_str());
     buf = of.rdbuf();
   } else {
     buf = std::cout.rdbuf();
   }
   std::ostream out(buf);

   if(!print_to_file) out << endl;

   // ---------------------------------
   // Derive and print statistics on the AST
   // ---------------------------------       
   if(alf_tuple) 
     {
       out << "  ALF program statistics: "<< endl;
       // Get the number of imported frefs and lrefs
       out << "     lref imports: " << alf_tuple->GetImports()->GetLRefList()->ElementCount();
       out << "\t\t fref imports: " << alf_tuple->GetImports()->GetFRefList()->ElementCount() << endl;
       // Get the number of exported frefs and lrefs
       out << "     lref exports: " << alf_tuple->GetExports()->GetLRefList()->ElementCount();
       out << "\t\t fref exports: " << alf_tuple->GetExports()->GetFRefList()->ElementCount() << endl;
       // Get the number of global decls and inits
       out << "     global decls: " << alf_tuple->GetDecls()->ElementCount();
       out << "\t\t global inits: " << alf_tuple->GetInits()->ElementCount() << endl;
       // Get the number of functions
       out << "     functions:    " << alf_tuple->GetFuncs()->ElementCount();

       // Create a filter function working on the program
       alf::CAlfTreeFilter filter = alf::CAlfTreeFilter(dynamic_cast<const alf::CGenericNode*>(alf_tuple));
       unsigned nr_of_stmts = 0;
       // Get the number of null stmts
       const alf::CAlfTreeFilter::NodeList null_stmts = filter.GetNodesOfType(alf::CGenericNode::TYPE_NULL_STMT_TUPLE);
       unsigned nr_of_null_stmts = (unsigned)null_stmts.size();
       nr_of_stmts += nr_of_null_stmts;
       // Get the number of store stmts
       const alf::CAlfTreeFilter::NodeList store_stmts = filter.GetNodesOfType(alf::CGenericNode::TYPE_STORE_STMT_TUPLE);
       unsigned nr_of_store_stmts = (unsigned)store_stmts.size();
       nr_of_stmts += nr_of_store_stmts;
       // Get the number of jump stmts
       const alf::CAlfTreeFilter::NodeList jump_stmts = filter.GetNodesOfType(alf::CGenericNode::TYPE_JUMP_STMT_TUPLE);
       unsigned nr_of_jump_stmts = (unsigned)jump_stmts.size();
       nr_of_stmts += nr_of_jump_stmts;
       // Get the number of switch stmts
       const alf::CAlfTreeFilter::NodeList switch_stmts = filter.GetNodesOfType(alf::CGenericNode::TYPE_SWITCH_STMT_TUPLE);
       unsigned nr_of_switch_stmts = (unsigned)switch_stmts.size();
       nr_of_stmts += nr_of_switch_stmts;
       // Get the number of call stmts
       const alf::CAlfTreeFilter::NodeList call_stmts = filter.GetNodesOfType(alf::CGenericNode::TYPE_CALL_STMT_TUPLE);
       unsigned nr_of_call_stmts = (unsigned)call_stmts.size();
       nr_of_stmts += nr_of_call_stmts;
       // Get the number of return stmts
       const alf::CAlfTreeFilter::NodeList return_stmts = filter.GetNodesOfType(alf::CGenericNode::TYPE_RETURN_STMT_TUPLE);
       unsigned nr_of_return_stmts = (unsigned)return_stmts.size();
       nr_of_stmts += nr_of_return_stmts;
       // Get the number of free stmts
       const alf::CAlfTreeFilter::NodeList free_stmts = filter.GetNodesOfType(alf::CGenericNode::TYPE_FREE_STMT_TUPLE);
       unsigned nr_of_free_stmts = (unsigned)free_stmts.size();
       nr_of_stmts += nr_of_free_stmts;
       // Get the number of scope stmts
       const alf::CAlfTreeFilter::NodeList scope_stmts = filter.GetNodesOfType(alf::CGenericNode::TYPE_SCOPE_TUPLE);
       unsigned nr_of_scope_stmts = (unsigned)scope_stmts.size();
       nr_of_stmts += nr_of_scope_stmts;
       // Get the number of operations
       const alf::CAlfTreeFilter::NodeList ops = filter.GetNodesOfType(alf::CGenericNode::TYPE_OP_EXPR_TUPLE);
       unsigned nr_of_ops = (unsigned)ops.size();
       // Get number of local decls
       unsigned nr_of_local_decls = 0;
       const alf::CAlfTreeFilter::NodeList allocs = filter.GetNodesOfType(alf::CGenericNode::TYPE_ALLOC_TUPLE);
       nr_of_local_decls = unsigned(allocs.size() - alf_tuple->GetDecls()->ElementCount());
       // Get all init tuples and see how many of them that are volatile
       unsigned nr_of_volatiles = alf_tuple->GetInits()->GetNrOfVolatileInits();

       // Print statistics
       out << "\t\t stmts:        " << nr_of_stmts << endl;
       out << "     null stmts:   " << nr_of_null_stmts;
       out << "\t\t store stmts:  " << nr_of_store_stmts << endl;
       out << "     jump stmts:   " << nr_of_jump_stmts;
       out << "\t\t switch stmts: " << nr_of_switch_stmts << endl;
       out << "     call stmts:   " << nr_of_call_stmts;
       out << "\t\t return stmts: " << nr_of_return_stmts << endl;
       out << "     free stmts:   " << nr_of_free_stmts;
       out << "\t\t scope stmts:  " << nr_of_scope_stmts << endl;
       out << "     operations:   " << nr_of_ops;
       out << "\t\t local decls:  " << nr_of_local_decls << endl;
       out << "     volatiles:    " << nr_of_volatiles << endl;
     }

   // ---------------------------------
   // Derive and print statistics on the CG
   // ---------------------------------
   if(call_graph) 
     {
       out << "  Call graph statistics: "<< endl;
       out << "     nodes:        " << call_graph->NrOfNodes();
       out << "\t\t edges:        " << call_graph->NrOfEdges();
       out << endl;
     }

   // ---------------------------------
   // Derive and print statistics on the CFG
   // ---------------------------------
   unsigned nr_of_loops=0;
   if(flow_graphs.size() > 0) 
     {
       unsigned nr_of_nodes=0;
       unsigned nr_of_edges=0;
       unsigned nr_of_bbs=0;
       unsigned nr_of_bb_edges=0;
       for(std::vector<CFlowGraph*>::const_iterator cfg = flow_graphs.begin(); 
           cfg != flow_graphs.end(); ++cfg) {
         nr_of_nodes += (*cfg)->NrOfNodes();
         nr_of_edges += (*cfg)->NrOfEdges();
         nr_of_bbs += (*cfg)->GetNrOfBasicBlocks();
         nr_of_bb_edges += (*cfg)->GetNrOfEdgesInbetweenBasicBlocks();
         nr_of_loops += (*cfg)->GetNrOfLoops();
       }

       out << "  Control-flow graph(s) statistics: "<< endl;
       out << "     cfgs:         " << flow_graphs.size();
       out << "\t\t loops:        " << nr_of_loops << endl;
       out << "     nodes:        " << nr_of_nodes;
       out << "\t\t edges:        " << nr_of_edges << endl;
       out << "     bbs:          " << nr_of_bbs;
       out << "\t\t bb edges:     " << nr_of_bb_edges << endl;
       // out << "More info on cfgs to be added...\n";
     }

   // ---------------------------------
   // Derive and print statistics on the scope graph
   // ---------------------------------
   {
     CCallGraphNode *start_node = command_parse->GetStartNode();
     if(start_node) {
       CScopeGraph *scope_graph = new CScopeGraph(new CECFG());
       CreateScopes::ContextSensitive(scope_graph, call_graph, start_node, ast->GetSymTab(), *pa);
       out << "  Scope graph statistics: "<< endl;
       alf::CFuncTuple * func = dynamic_cast<alf::CFuncTuple *>(start_node->Function());
       if(func) {
         out << "     args:         " << func->GetArgs()->ElementCount() 
             << "\t\t start-func:             " << start_node->Function()->Name(); 
       }
       else {
         out << "      start-func:  " << start_node->Function()->Name();
       }
       out << endl;
       out << "     scopes:       " << scope_graph->NrOfScopes();
       out << "\t\t func scopes:            " << scope_graph->NrOfFunctionScopes() << endl;
       out << "     leaf scopes:  " << scope_graph->NrOfLeafScopes();
       out << "\t\t max leaf scope level:   " << scope_graph->RootScope()->GetGlobalMaxNesting() << endl;
       out << "     loop scopes:  " << scope_graph->NrOfLoopScopes();
       out << "\t\t max loop-scope nesting: " << scope_graph->RootScope()->GetGlobalMaxLoopNesting() << endl; 
       // cout << "More info on sg to be added...\n";
     }
     else {
       out << "  No scope graph (statistics) generated due to multiple start functions "<< endl;
     }
   }

   // ---------------------------------
   // Print extra statistics rwo (to be removed)
   // ---------------------------------
   bool print_vecu_stats = false;
   if(print_vecu_stats) {
     CCallGraphNode *start_node = command_parse->GetStartNode();
     if(start_node && alf_tuple) {
       alf::CFuncTuple * func = dynamic_cast<alf::CFuncTuple *>(start_node->Function());
       if(func) {
         // Print imports, args and volatiles
         out << "EXTRA_VECU_STATS (lref imports, fref imports, start-func-args, volatiles, funcs, loops):\t";
         out << alf_tuple->GetImports()->GetLRefList()->ElementCount() << "\t";
         out << alf_tuple->GetImports()->GetFRefList()->ElementCount() << "\t";
         out << func->GetArgs()->ElementCount() << "\t";
         out << alf_tuple->GetInits()->GetNrOfVolatileInits() << "\t"; 
         out << alf_tuple->GetFuncs()->ElementCount() << "\t";
         out << nr_of_loops << endl;
       }
     }
   }

   // ---------------------------------
   // Extra printout of content of cfgs (to be removed)
   // ---------------------------------
   bool print_cfg_component_trees = false;
   if(print_cfg_component_trees) {
      for(std::vector<CFlowGraph*>::const_iterator cfg = flow_graphs.begin(); 
	  cfg != flow_graphs.end(); ++cfg) {
	(*cfg)->ComponentTree()->Print(out);
      }
   }
}

}
