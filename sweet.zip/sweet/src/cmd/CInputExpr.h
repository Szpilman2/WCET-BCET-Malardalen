#ifndef INPUT_EXPR_H_
#define INPUT_EXPR_H_

#include "CInputVal.h"
#include <stdexcept>
#include <string>
#include <cassert>
#include <vector>

namespace cmd {

/** \class CInputExpr This is an expression on either of the forms "name" or
      "name=value" where \a name is a string that we hope matches a keyword
      and value is a value that may integer valued. */
class CInputExpr
{
public:
   /** Constructs an input expression. It will be chopped into the part that is
      assumed to be the keyword and the (optional) part that is assumed to be
      a value. */
   CInputExpr(std::string expr)
   {
      size_t assignment_pos = expr.find('=');
      has_value = assignment_pos != std::string::npos;
      if (has_value) {
         // Split the expression into name and value
         has_value = true;
         std::string val_as_string = expr.substr(assignment_pos + 1);
         if (val_as_string.empty()) {
            throw std::runtime_error("Rhs in assignement "+expr+" is empty which is not expected.");
         }
         expr = expr.substr(0, assignment_pos);
         input_val = CInputVal(val_as_string);
      }
      keyword = expr;
   }

   /** \return The keyword. */
   std::string GetKeyword() const { return keyword; }

   /** \return True if this expression contains a value. */
   bool HasVal() const { return has_value; }

   /** \return A pointer to the value of this expression.
      \pre \a HasVal() returns true. */
   const CInputVal *GetVal() const { assert(has_value); return &input_val; }

private:
   std::string keyword;
   bool has_value;
   CInputVal input_val;
};

/** \class CInputOptionArgument An alias for CInputExpr. Models an argument of
   an option. */
class CInputOptionArgument : public CInputExpr
{
public:
   /** Constructs a new input option's argument.
      \param expr The input argument that we hope will later match an allowed
      parameter. */
   CInputOptionArgument(std::string expr) : CInputExpr(expr) { }
};

/** \class CInputOption Extends CInputExpr with the ability to hold input an
   option's arguments. */
class CInputOption : public CInputExpr
{
public:
   /** Constructs a new input option.
      \param expr The input option that we hope will later match an allowed
      option.
      \param long_name True if the keyword on the command line was in the long
      format rather then short. */
   CInputOption(std::string expr, bool long_name) : CInputExpr(expr), long_name(long_name) { }

   ~CInputOption()
   {
      for (unsigned i=0; i<arguments.size(); ++i) {
         delete arguments[i];
      }
   }

   /** Adds a new input argument to the set of input arguments of this input
      option. */
   void AddArgument(CInputOptionArgument *argument) { arguments.push_back(argument); }

   /** \return a set of input arguments of this input option as a vector. */
   const std::vector <CInputOptionArgument*> &GetArguments() const { return arguments; }

   /** \return True if this input was given as a long name, else false. */
   bool LongName() const { return long_name; }
private:
   std::vector <CInputOptionArgument*> arguments;
   bool long_name;
};
}

#endif
