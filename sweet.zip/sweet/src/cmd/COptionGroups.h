#ifndef OPTION_GROUPS_H_
#define OPTION_GROUPS_H_

#include <vector>
#include <map>
#include <string>

#include "COptionGroup.h"

namespace cmd {

class CInputOptions;
class CInputOptionArgument;
class COption;
class CCommandArgument;
class CCommandVal;
class CCommand;
class CCommands;
class CVal;
class CInputVal;
class COptionParameter;

/** \class  COptionGroups
   Contains a specification of a set of groups of allowed command line options.
   A set of groups is basically just a container with all groups of options.
   Here we also matches the input line's options with the allowed options to
   obtain a command list.
*/
class COptionGroups : public std::vector <COptionGroup>
{
public:

   ~COptionGroups();

   /** Matches the input with the allowed options. If any mismatch is detected
      an exception will be thrown.
      \param input_options The tokenized command line.
      \param commands A list of the commands that matched the input options. */
   void MatchInput(CInputOptions &input_options, CCommands &commands) const;

   /** Checks if a certain option exist.
      \return A pointer to the option
      \pre \a key is a key to an option existing among the allowed options. */
   const COption *FindOption(COption::KEY key) const;

   /** Adds a new option group to this set of option groups. */
   COptionGroups &operator[](COptionGroup &option_group) { push_back(option_group); return *this; }

   /** Check if the available options are consistent. Terminates with an assert
      if not. */
   void CheckConsistency() const;

private:
   CCommandArgument *MatchArgument(const CInputOptionArgument *argument, const COption *option) const;
   CCommandVal *MatchValue(const CVal *legal_value, const CInputVal *input_value, std::string variable) const;
   CCommandVal *MatchKeywordValue(const CVal *legal_value, std::string input_val_text, std::string variable) const;
   CCommandVal *MatchKeywordSetValue(const CVal *legal_val, const CInputVal *input_val, std::string variable) const;
   CCommandArgument *MatchArgumentKeywordValue(const CInputOptionArgument *argument, const COptionParameter *parameter,
                                                      COption *option) const;
   CCommand *CreateDefaultCommand(const COption *option) const;
   CCommandVal *CreateDefaultCommandVal(const CVal *val) const;
   void Flattern(std::map <std::string, const COption*> &option_map1,
                std::map <COption::KEY, const COption*> &option_map2) const;
   void GetAllOptionsShortNames(std::vector<std::string> & short_option_names) const;
   void GetAllOptionsLongNames(std::vector<std::string> & long_option_names) const;
   void AddDefaultCommands(CCommands &commands) const;
   void SortCommands(CCommands &commands) const;
   void CheckForDuplicates(CCommands &commands) const;
   void AddDefaultParameters(CCommands &commands) const;
   void AddDefaultParameters(const COption *option, CCommand *command) const;
   CCommandVal *CreateDefaultCommandVal(CVal *val) const;
   void Chop(std::string text, std::string *head, std::string *tail) const;
   bool CheckForHelpCommand(CCommands &commands) const;
};
}

#endif
