// $Id $

#include "CCommandAE.h"
#include "CCommandVA.h"
#include "CCommandDomain.h"
#include "CCommandParse.h"
#include "CCommandLoadMap.h"
#include "CSession.h"
#include "ae/AlfAbstractExecution.h"
#include "ae/CCollector.h"
#include "graphs/ecfg/CECFG.h"
#include "graphs/scopes/CScopeGraph.h"
#include "graphs/scopes/CreateScopes.h"
#include "program/CGenericProgram.h"
#include "program/alf/CAlfTuple.h"
#include "tools/Timer.h"
#include "globals.h"

#include <vector>
#include <stdexcept>

using namespace std;

namespace cmd {

CCommandVA::
CCommandVA()
  : _va_settings(NULL), _dfa(NULL), _sg(NULL)
{
  // Do nothing
}

CCommandVA::
~CCommandVA()
{
   if (_va_settings) {
      delete _va_settings;
   }
   if(_dfa) {
     delete _dfa;
   }
   if(_sg) {
     delete _sg;
   }
}
 
CCommand *
CCommandVA::
Copy() const
{
   assert(_va_settings==NULL);
   return new CCommandVA(*this);
}

void
CCommandVA::
Validate(const CSession *session)
{
   // Create the settings data structure
   _va_settings = new VASettings();

   // ---------------------------------
   // Handle analysis type
   // ---------------------------------
   {
     const CCommandArgument *analysis_type_argument = GetArgument(ANALYSIS_TYPE);
     switch (analysis_type_argument->GetVal()->AsKey()) {
     case NODE_ORDERING:
       _va_settings->_analysis_type = AlfValueDataFlowAnalysis::NODE_ORDERING;
       break;
     case WORK_LIST:
       _va_settings->_analysis_type = AlfValueDataFlowAnalysis::WORK_LIST;
       break;
     case CHAOTIC:
       _va_settings->_analysis_type = AlfValueDataFlowAnalysis::CHAOTIC;
       break;
     }
   }

   // ---------------------------------
   // Handle fixpoint passes
   // ---------------------------------
   {
     const CCommandArgument *fixpoint_pass_argument = GetArgument(FIXPOINT_PASS);
     switch (fixpoint_pass_argument->GetVal()->AsKey()) {
     case WIDENING_NARROWING:
       _va_settings->_fixpoint_passes.push_back(AlfValueDataFlowAnalysis::WIDENING);
       _va_settings->_fixpoint_passes.push_back(AlfValueDataFlowAnalysis::NARROWING);
       _va_settings->_use_wid_nar = true; 
       break;
     case WIDENING:
       _va_settings->_fixpoint_passes.push_back(AlfValueDataFlowAnalysis::WIDENING);
       _va_settings->_use_wid_nar = true; 
       break;
     case NARROWING:
       _va_settings->_fixpoint_passes.push_back(AlfValueDataFlowAnalysis::NARROWING);
       _va_settings->_use_wid_nar = true; 
       break;
     case NORMAL:
       _va_settings->_fixpoint_passes.push_back(AlfValueDataFlowAnalysis::NORMAL);
       _va_settings->_use_wid_nar = false; 
       break;
     }
   }

   // ---------------------------------
   // Handle widening narrowing points 
   // ---------------------------------
   {
     const CCommandArgument *wid_nar_point_argument = GetArgument(WID_NAR_POINT);
     switch (wid_nar_point_argument->GetVal()->AsKey()) {
       case LAST_STMT_IN_BB:
         _va_settings->_widening_placement = WID_STD_BEFORE_LAST_STMT_IN_BB;
         break;
       case FIRST_STMT_IN_BB:
         _va_settings->_widening_placement = WID_STANDARD;

		 break;
	   case AT_BACK_EDGE:
	     _va_settings->_widening_placement = WID_BACKEDGE; 
         break;
     }
   }

   // ---------------------------------
   // Determine fall through treatment
   // ---------------------------------
   {
      const CCommandArgument* ft_arg = GetArgument(FT);
      if (ft_arg != 0) {
         switch (ft_arg->GetVal()->AsKey())
         {
            case CONTINUE:
               g_ft_continue = true;
               g_ft_warn = false;
               break;
            case DO_NOT_CONTINUE:
               g_ft_continue = false;
               g_ft_warn = false;
               break;
            case DO_NOT_CONTINUE_WARN:
               g_ft_continue = false;
               g_ft_warn = true;
               break;
         };
      }
   }   
   
   // ---------------------------------
   // Handle printing
   // ---------------------------------
   {
     _va_settings->_print_analysis_specification = AlfValueDataFlowAnalysis::NONE;
     const CCommandArgument *print_analysis_argument = GetArgument(PRINT_ANALYSIS_RESULT);
     if(print_analysis_argument) {
       switch (print_analysis_argument->GetVal()->AsKey()) {
       case RESULT:
	 _va_settings->_print_analysis_specification = AlfValueDataFlowAnalysis::RESULT;
	 break;
       case FIX_POINT_PASS:
	 _va_settings->_print_analysis_specification = AlfValueDataFlowAnalysis::FIX_POINT_PASS;
	 break;
       case ITERATION:
	 _va_settings->_print_analysis_specification = AlfValueDataFlowAnalysis::ITERATION;
	 break;
       }
     }
   }

   // ---------------------------------
   // Handle drawing
   // ---------------------------------
   {
     _va_settings->_draw_analysis_specification = AlfValueDataFlowAnalysis::NONE;
     const CCommandArgument *draw_analysis_argument = GetArgument(DRAW_ANALYSIS_RESULT);
     if(draw_analysis_argument) {
       switch (draw_analysis_argument->GetVal()->AsKey()) {
       case RESULT:
	 _va_settings->_draw_analysis_specification = AlfValueDataFlowAnalysis::RESULT;
	 break;
       case FIX_POINT_PASS:
	 _va_settings->_draw_analysis_specification = AlfValueDataFlowAnalysis::FIX_POINT_PASS;
	 break;
       case ITERATION:
	 _va_settings->_draw_analysis_specification = AlfValueDataFlowAnalysis::ITERATION;
	 break;
       }
     }
   }
}

void
CCommandVA::
Execute(const CSession *session)
{
   // We need the program to analyze...
   CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
   CGenericProgram *generic_ast = command_parse->GetAst();
   const alf::CAlfTuple * alf_ast = dynamic_cast<const alf::CAlfTuple*>(generic_ast);

   // We need abstract annotations if they exist
   CALFAbsAnnotStorage * abs_annots = command_parse->GetAnnotStorage();

   // Get the source loader
   CSourceLoader *source_loader = 0;
   if(session->HasCommand(COption::LOAD_MAP)) {
      CCommandLoadMap *load_map_command =
         dynamic_cast<CCommandLoadMap *> (session->GetCommand(COption::LOAD_MAP));
      source_loader = load_map_command->GetSourceLoader();
   }

   // We need the scopegraph
   CCallGraph *call_graph = command_parse->GetCallGraph();
   CCallGraphNode *start_node = command_parse->GetStartNode();
   _sg = new CScopeGraph(new CECFG());
   const CSteensgaardPA *pa = command_parse->GetPointerAnalysis();
   CreateScopes::ContextSensitive(_sg, call_graph, start_node, generic_ast->GetSymTab(), *pa);

   // We also need the domain settings 
   assert(session->HasCommand(COption::ABS_DOMAIN));
   CCommandDomain *command_domain = dynamic_cast<CCommandDomain *> (session->GetCommand(COption::ABS_DOMAIN));
   _va_settings->_domain_settings = command_domain->GetDomainSettings();

   // Do the value analysis 
   _dfa = DoValueDataFlowAnalysis(_sg, alf_ast, abs_annots, source_loader, _va_settings);  
}

}
