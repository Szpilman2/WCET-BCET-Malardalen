/* $Id: $ */

#include "AvailableOptions.h"
#include "COptionGroups.h"
#include "COptionGroup.h"
#include "COption.h"
#include "CCommandOutputFlowFacts.h"
#include "CCommandGenerateAbsAnn.h"
#include "CCommandParse.h"
#include "CCommandCheck.h"
#include "CCommandInspection.h"
#include "CCommandAE.h"
#include "CCommandVA.h"
#include "CCommandDU.h"
#include "CCommandRD.h"
#include "CCommandPDG.h"
#include "CCommandSlice.h"
#include "CCommandDomain.h"
#include "CCommandPrint.h"
#include "CCommandPrintNice.h"
#include "CCommandLoadMap.h"
#include "CCommandCreateTimingForAlfBasicBlocksUsingCostLookupTable.h"
#include "CCommandVersion.h"
#include "CCommandHelp.h"
#include "CCommandGenerateCostLookupTableTemplate.h"
#include "COptionParameter.h"
#include "CCommandExtractFuncCGsAndInfo.h"
#include "CVal.h"
#include "CKeyword.h"
#include "macros2.h"
#include <string>
#include <cassert>
#include <stdexcept>
#include <cstdlib>
#include <memory>

using namespace std;

namespace cmd {

/* Want to add a new option to SWEET?
   - Add a new subclass to CCommand. The stuff to be done should be in the
      Execute() function (surprised?)
   - Add a new symbolic number to this option (COption::KEY)
   - Add a your option specification to the initialization list below
      An option...
         - has a short and a long name
         - has a short description
         - may have a long description
         - may have a value, =
         - may have parameters, []
         - may require other options, []
         - may want other options to precede it, []
         - is considered "default" if it does not need a value and all its
               parameters are optional. The command of a default option will
               be executed automatically if some other option depends on it
               and the user did not specify it explicitly.
      A parameter ...
         - has a key localy unique within the option
         - has a name
         - may have a value, =
         - has a short description
         - may have a long description
         - may be mandatory, !
         - If a parameter is not mandatory then it will be added automatically to the
           corresponding command () during parsing if
            - It is boolean
            - It has a default value (i.e., it's a keyword or keyword set and one alternative is
               marked as default).
      A value ...
         - has a type
         - if it is of "keyword" or "keyword set" type it has a list of keywords
         - may have a name
         - may have a short description
         - may have a long description
      A keyword ...
         - has a name (the keyword:-)
         - has a key locally unique within the option
         - may have a description
         - may be default, *
      For details, please consult the corresponding class!

   The consistency of the option specification is asserted.
   The actual command line will be checked against all information that can
   be extracted from the specification.
   The options can be grouped in different groups, each having its header. This
   is currently not used - all options is put into the same anonymous group.
   */

   unique_ptr <COptionGroups> AvailableOptions()
   {
      unique_ptr <COptionGroups> option_groups(new COptionGroups);
      (*option_groups)

      ///////////////////////////////////////////////////////// 
      ///////////////////////////////////////////////////////// 
      // Inputs
      /////////////////////////////////////////////////////////
      ///////////////////////////////////////////////////////// 
      [COptionGroup("Inputs")

         // ---------------------------------
         // Parsing of inputs
         // ---------------------------------
         [(COption(COption::PARSE, new CCommandParse, "i", "input-files", "Specifies the code to be analyzed.")=
            CVal(CVal::STRING, "<file-name(s)>", "The name of the file(s) to analyze. In case of multiple "
            "files to be linked together (only for alf), these should "
            "be separated by , (comma)."))
            [COptionParameter(CCommandParse::LANG, "lang", "The language of the code.")=CVal(CVal::KEYWORD)
               [*CKeyword(CCommandParse::AUTO, "auto", "Makes assumptions based on the file suffix.")]
               [ CKeyword(CCommandParse::ALF,  "alf", "One or more ALF file(s).")]
               [ CKeyword(CCommandParse::CFG,  "cfg", "File containing set of control-flow graphs. "
               "Useful for trace-based flow hypothesis generation (see -ae rtf).")]
            ]
            [COptionParameter(CCommandParse::FUNC, "func", "The start function for all analyses. By default the "
               "root function is the start function.")=
               CVal(CVal::STRING, "<function-name>")
            ]
            [COptionParameter(CCommandParse::ANNOT, "annot", "Reads a file with abstract annotations. Use the "
               "help 'help topic=annot' option to learn more about the format of the annotation file.")=
               CVal(CVal::STRING, "<file-name>")
            ]
            [COptionParameter(CCommandParse::OUTPANNOT, "outannot", "Reads a file with output annotations specifications. "
               "The resulting output annotations are written to a file named: the file base name of "
               "file-name with the suffix \".out\" appended.")=
               CVal(CVal::STRING, "<file-name>")
            ]
            [COptionParameter(CCommandParse::MERGED_OUTPUT, "merged_output", "Control if the values in the output annotations are merged or not.")=
               CVal(CVal::KEYWORD)
               [ CKeyword(CCommandParse::YES, "yes", "The values in the output annotations are merged.")]
               [ CKeyword(CCommandParse::NO, "no", "The values in the output annotations are not merged, but instead given as "
                  "discrete values separated by 'OR'.")]
            ]
            [COptionParameter(CCommandParse::UNMANGLE, "unmangle", "Unmangle identifiers. "
               "Useful to make linking of several ALF files possible. Removes the ::<number> suffix which melmac appends to all identifiers")
            ]
            [COptionParameter(CCommandParse::RDE, "rde", "Remove duplicate exports. When having functions that are exported from several "
               "ALF files all but one definition of the function are removed. Which definition to keep is unspecified, since it is assumed "
               "that all definitions are identical. Default off.")
            ]
         ]

         // ---------------------------------
         // Static check 
         // ---------------------------------
         [COption(COption::CHECK, new CCommandCheck, "c", "check-statically", "Check the parsed program for consistency.")
            [COption::CDependencies()[COption::PARSE]]
            [COptionParameter(CCommandCheck::SIZE, "size", "Checks if the sizes of expressions "
               "are consistent, and if there are unsupported "
               "constructs in the program.")=
               CVal(CVal::KEYWORD)
               [*CKeyword(CCommandCheck::ON,  "on",   "Turns on this check")]
               [ CKeyword(CCommandCheck::OFF, "off",  "Turns off this check")]
            ]
            [COptionParameter(CCommandCheck::CONNECTED, "connected", "Checks if the call graph "
               "is connected, i.e. if there is an "
               "unumbigous start point for the analysis.")=
               CVal(CVal::KEYWORD)
               [*CKeyword(CCommandCheck::ON,  "on",   "Turns on this check")]
               [ CKeyword(CCommandCheck::OFF, "off",  "Turns off this check")]
            ]
            [COptionParameter(CCommandCheck::EXTERNAL_REFS, "extref", "Checks if there are any "
               "unresolved external references in the program (like calls to external functions or "
               "accesses to external global variables).")=
               CVal(CVal::KEYWORD)
               [*CKeyword(CCommandCheck::ON,  "on",   "Turns on this check")]
               [ CKeyword(CCommandCheck::OFF, "off",  "Turns off this check")]
            ]
            [COptionParameter(CCommandCheck::FCALLS, "fcall", "Checks that (non-function-pointer) function calls are made with "
               "right amount of parameters, that each function has "
               "at least one return statement, that all return statements "
               "has the same amount of parameters, and that calls and returns "
               "are consistent in terms of parameters.")=
               CVal(CVal::KEYWORD)
               [*CKeyword(CCommandCheck::ON,  "on",   "Turns on this check")]
               [ CKeyword(CCommandCheck::OFF, "off",  "Turns off this check")]
            ]
         ]

         // ---------------------------------
         // Map file
         // ---------------------------------
         // Loads a label-to-source-code-map file - or essentially can be used to set a specific name of such a file
         [COption(COption::LOAD_MAP, new CCommandLoadMap, "m", "map-file", "Loads a file mapping from statements "
            "to corresponding C-source code.")
            [COption::CDependencies()[COption::PARSE]]
            [COptionParameter(CCommandLoadMap::FILE_NAME, "file", "Specifies the file name of the map file. If "
               "this parameter is not given, the base name of "
               "the program file with the suffix \".map\" will "
               "be used. In case more than one program file is given to "
               "-i, the corresponding .map files are assumed to be named "
               "as the base names of the program files, with \".map\" appended. "
               "This parameter should then not be given.")=
               CVal(CVal::STRING, "<file-name>", "The name of the map file.")
            ]
            [COptionParameter(CCommandLoadMap::READ_C_SOURCE, "rcs", 
               "Read C sources - Open C files specified in the map file and read C-lines "
               "from them to internal mappings.")
            ]
            [COptionParameter(CCommandLoadMap::CHECK_MAP, "c", "Check map file content. Controls that each"
               " basic block has a corresponding c source reference in the map file.")
            ]
            [COptionParameter(CCommandLoadMap::PAL, "pal", "Print .map file after linking.") 
               = CVal(CVal::STRING, "<file-name>")
            ]
         ]
      ] // end of [COptionGroup("Inputs")


      ///////////////////////////////////////////////////////// 
      /////////////////////////////////////////////////////////
      // Analyses
      //////////////////////////////////////////////////////////
      ///////////////////////////////////////////////////////// 
      [COptionGroup("Analyses")

         // ---------------------------------
         // Set up the data domain
         // ---------------------------------
         [COption(COption::ABS_DOMAIN, new CCommandDomain, "do", "domain", "Configures the domain to be used by SWEET.")
            [COption::CDependencies()[COption::PARSE]] // TODO: why?

            [COptionParameter(CCommandDomain::TYPE, "type", "The domain to be used for integers and offsets in pointers.")=
               CVal(CVal::KEYWORD)
               [*CKeyword(CCommandDomain::INTERVAL,   "int",   "Intervals")]
               [ CKeyword(CCommandDomain::CLP, "clp", "Circular Linear Progressions")]
               //	 [ CKeyword(CCommandDomain::CONGRUENCE, "cong",  "Congruence")]
               //	 [ CKeyword(CCommandDomain::MIXED_INT,  "mixed", "?? Mixed integer")]
            ]

            [COptionParameter(CCommandDomain::FLOATS, "floats",  "How to handle floats.") =
               CVal(CVal::KEYWORD)   	      
               [*CKeyword(CCommandDomain::TOP_FLOATS, "top", "All calculations of floating point values result in TOP (safe).") ]
               [ CKeyword(CCommandDomain::ESTIM_FLOATS, "est", "A best effort analysis that tries to estimate floating-point values "
               "rather than returning TOP, even though the analysis may be unsound "
               "(due to different floating point value representation on the host and on the target)."	) ]	  
            ]   

            [COptionParameter(CCommandDomain::REUSE, "reuse", "Specifies that reuse (i.e. 'copy-on-write') of "
               "internal parts of abstract states should be used. Instead of always making "
               "deep copies of internal objects the states are allowed to share these objects. "
               "The actual copying takes place when a state wants to update "
               "its particular object. Saves memory and execution time for both VA and AE. "
               "If one or more options except 'all' or 'none' is given other one options will be turned off. "
               "Alternatives marked with '*' only concerns the AE.")= 
               CVal(CVal::KEYWORD_SET)
               [*CKeyword(CCommandDomain::ALL,  "all")]
               [ CKeyword(CCommandDomain::NONE, "none")]
               [ CKeyword(CCommandDomain::MEMORY, "m", "Memory")]
               [ CKeyword(CCommandDomain::CALL_STACK, "c", "Call stack")]
               [ CKeyword(CCommandDomain::RECORDER, "r", "Recorders*")]
               [ CKeyword(CCommandDomain::RECORDER_HOLDER,   "h",    "Recorder holders*")]
               // [ CKeyword(CCommandDomain::PATH, "path",  "Path *")]
               //                [ CKeyword(CCommandDomain::PT,   "pt",    "Path tree *")]
               //                [ CKeyword(CCommandDomain::NCR,  "ncr",   "Node count recorder *")]
               //                [ CKeyword(CCommandDomain::ECR,  "ecr",   "Edge count recorder *")]
               //                [ CKeyword(CCommandDomain::ITER, "iter",  "Iteration count recorder *")]
               //                [ CKeyword(CCommandDomain::GV,   "gv",    "Global value recorder *")]
            ]
            [COptionParameter(CCommandDomain::EDO, "edo", "Only read/write at offsets evenly dividable by size of "
               "previously read/written values.")
            ]
            [COptionParameter(CCommandDomain::NO_GLOB_INIT, "noglobinit", "Skips the global init section. "
               "Initial values will be top or "
               "restricted by annotations.")
            ]
         ]

         // ---------------------------------
         // Abstract execution 
         // ---------------------------------
         [COption(COption::AE, new CCommandAE, "ae", "abstract-execution", "Run abstract execution to produce flow facts.")
            [COption::CDependencies()[COption::CHECK][COption::ABS_DOMAIN]]
            [COption::CPrecedences()[COption::LOAD_MAP]] // for the AE debugger
            [COptionParameter(CCommandAE::FFG, "ffg", "The flow fact generators (ffgs) to use. Given "
               "using four dimensions (as a four letter string):  "
               "1. bounds derived: upper (u), lower and upper (l), infeasible (i).  "
               "2. entities kept track of: headers (h), nodes (n), edges (e), call-edges (c), "
               "loop-body-begin-edges (b).  "
               "3. combination of entities: single (s), pairs (p), paths (n).  "
               "4. flow fact context: each iteration (e), all iterations (a), "
               "scope (s), function (f), program (p).")=
               CVal(CVal::KEYWORD_SET)
               [*CKeyword(CCommandAE::UHSS,"uhss", "Upper header bounds in scope context (default on, "
               "but must be given if ffg is used). (u)")]
               [ CKeyword(CCommandAE::LHSS,"lhss","Lower header node bounds in scope context. (l)")]
               [ CKeyword(CCommandAE::UHSF,"uhsf","Upper header node bounds in function context. (u)")]
               [ CKeyword(CCommandAE::LHSF,"lhsf","Lower header node bounds in function context. (l)")]
               [ CKeyword(CCommandAE::UHSP,"uhsp","Upper header node bounds in program context. (u)")]
               [ CKeyword(CCommandAE::LHSP,"lhsp","Lower header node bounds in program context. (l)")]

               [ CKeyword(CCommandAE::UHPF,"uhpf","Upper bounds for header pairs in function context. (u)")]
               [ CKeyword(CCommandAE::LHPF,"lhpf","Lower bounds for header pairs in function context. (l)")]
               [ CKeyword(CCommandAE::UHPP,"uhpp","Upper bounds for header pairs in program context. (u)")]
               [ CKeyword(CCommandAE::LHPP,"lhpp","Lower bounds for header pairs in program context. (l)")]

               [ CKeyword(CCommandAE::UNSS,"unss","Upper bounds for nodes in scope context. (u)")]
               [ CKeyword(CCommandAE::LNSS,"lnss","Lower bounds for nodes in scope context. (l)")]
               [ CKeyword(CCommandAE::UNSF,"unsf","Upper bounds for nodes in function context. (u)")]
               [ CKeyword(CCommandAE::LNSF,"lnsf","Lower bounds for nodes in function context. (l)")]
               [ CKeyword(CCommandAE::UNSP,"unsp","Upper bounds for nodes in program context. (u)")]
               [ CKeyword(CCommandAE::LNSP,"lnsp","Lower bounds for nodes in program context. (l)")]
               [ CKeyword(CCommandAE::INSE,"inse","Nodes never taken for individual iterations of scope. (u)")]
               [ CKeyword(CCommandAE::INSA,"insa","Nodes never taken for all iterations of scope. (u)")]

               [ CKeyword(CCommandAE::UNPS,"unps","Upper bounds for node pairs in scope-context. (u)")]
               [ CKeyword(CCommandAE::LNPS,"lnps","Lower bounds for node pairs in scope context. (l)")]
               [ CKeyword(CCommandAE::UNPF,"unpf","Upper bounds for node pairs in function-context. (u)")]
               [ CKeyword(CCommandAE::LNPF,"lnpf","Lower bounds for node pairs in function context. (l)")]
               [ CKeyword(CCommandAE::UNPP,"unpp","Upper bounds for node pairs in program-context. (u)")]
               [ CKeyword(CCommandAE::LNPP,"lnpp","Lower bounds for node pairs in program context. (l)")]
               [ CKeyword(CCommandAE::INPA,"inpa","Excluding node pairs for all iterations of scope (ie. nodes never executed together for any iteration) (u). If no merging is used also reports on node pairs that must be taken together (ie. each iteration either none or both nodes must be taken).")]
               // Removed due to found_header assert *** [ CKeyword(CCommandAE::INNA,"inna","Infeasible paths of nodes for all iterations of scope")]

               [ CKeyword(CCommandAE::UESS,"uess","Upper bounds for edges in scope context. (u)")]
               [ CKeyword(CCommandAE::LESS,"less","Lower bounds for edges in scope context. (l)")]
               [ CKeyword(CCommandAE::UESF,"uesf","Upper bounds for edges in function context. (u)")]
               [ CKeyword(CCommandAE::LESF,"lesf","Lower bounds for edges in function context. (l)")]
               [ CKeyword(CCommandAE::UESP,"uesp","Upper bounds for edges in program context. (u)")]
               [ CKeyword(CCommandAE::LESP,"lesp","Lower bounds for edges in program context. (l)")]
               [ CKeyword(CCommandAE::UCSF,"ucsf","Upper bounds for call edges in function context. (u)")]
               [ CKeyword(CCommandAE::LCSF,"lcsf","Lower bounds for call edges in function context. (l)")]
               [ CKeyword(CCommandAE::UCSP,"ucsp","Upper bounds for call edges in program context. (u)")]
               [ CKeyword(CCommandAE::LCSP,"lcsp","Lower bounds for call edges in program context. (l)")]
               [ CKeyword(CCommandAE::UBNS,"ubns","Upper bounds for sum of loop body begin edges in scope context (i.e. an upper bound on the number of times the loop body can be taken for each entry of the loop). (u)")]
               [ CKeyword(CCommandAE::LBNS,"lbns","Lower bounds for sum of loop body begin edges in scope context (i.e. bounds on the number of times the loop body can be taken for each entry of the loop). (l)")]
               // [ CKeyword(CCommandAE::IENA,"iepa","Infeasible paths of edges for all iterations of scope")]
               [ CKeyword(CCommandAE::ALL_FFGS, "all","All ffgs should be used, i.e. both (u) and (l) ffgs")] 
               [ CKeyword(CCommandAE::ALL_FFGS_NO_INSE, "allnoinse","All ffgs except inse (since inse may give problems in low-sweet")] 
               [ CKeyword(CCommandAE::UB_FFGS, "ub","Upper bounds ffgs should be used. Includes ffgs marked with (u).")] 
               [ CKeyword(CCommandAE::LB_FFGS, "lb","Lower bounds ffgs should be used. Includes ffgs marked with (l).")] 
            ]
            [COptionParameter(CCommandAE::MERGE, "merge", "The merge points to be used.")=
               CVal(CVal::KEYWORD_SET)
               [*CKeyword(CCommandAE::ALL, "all", "All merge points (fe,fe,le,be,je).")]
               [ CKeyword(CCommandAE::NONE,"none", "No merging should be used.")]
               [ CKeyword(CCommandAE::FE,  "fe", "Each function entry point.")]
               [ CKeyword(CCommandAE::FR,  "fr", "Each function return point.")]
               [ CKeyword(CCommandAE::LE,  "le", "Each loop exit edge.")]
               [ CKeyword(CCommandAE::BE,  "be", "Each back-edge.")]
               [ CKeyword(CCommandAE::JE,  "je", "Each point of joining edges.")]
            ] 
            [COptionParameter(CCommandAE::DF,    "df",   "Execute in a depth first manner rather than breadth first manner.")]
            [COptionParameter(CCommandAE::USM,   "usm",  "Use unordered state merge strategy.")]
            [COptionParameter(CCommandAE::OP,    "op",   "Optimized single path execution.")]
            [COptionParameter(CCommandAE::DEBUG, "debug", "Turns on debugging.")=
               CVal(CVal::KEYWORD)
               [CKeyword(CCommandAE::INTERACTIVE_DEBUGGER, "inter", "Interactive debugger")]
               [CKeyword(CCommandAE::DEBUG_TRACE, "trace", "Prints a trace to the file debug_msgs.txt")]
            ]
            [COptionParameter(CCommandAE::TC, "tc",  "Type counting. Reports for each type its number of occurrences during the execution.") =
               CVal(CVal::KEYWORD_SET)
               [ CKeyword(CCommandAE::ALL_TYPES, "all", "Use all type countings, i.e gn,op,st,sp.")]
               [ CKeyword(CCommandAE::GEN_NODES, "gn", "Generic nodes, i.e. i.e. nodes in ALF syntax tree.")]
               [ CKeyword(CCommandAE::OPS, "op", "Operators, i.e. add, sub, ...")]
               [ CKeyword(CCommandAE::STMTS, "st", "Statements, i.e. store, call, ...")]
               [ CKeyword(CCommandAE::STMT_PAIRS, "sp", "Statement pairs, i.e. <store,store>, <store,call>, ...")]
               [ CKeyword(CCommandAE::SIMPLE_COUNT_PRINTOUT, "scp", "Simple count printout, prints counts as integers on a single line (is actually no counter report, just a printout directive)")] 
            ]
            [COptionParameter(CCommandAE::CSS, "css",  "Check single state, i.e., throw run-time error if more than one "
               "state is generated during AE. Mostly for debugging purposes.")]
            [COptionParameter(CCommandAE::ENE, "ene",  "Extended handling of equal and not equal condition.")]
            [COptionParameter(CCommandAE::FT, "ft",  "How to handle the fall-through state.") =
               CVal(CVal::KEYWORD)   	      
               [*CKeyword(CCommandAE::CONTINUE, "c", "Continue with the fall-through state if it is not bottom (C standard, used by melmac).") ]
               [ CKeyword(CCommandAE::DO_NOT_CONTINUE, "n", "Do not continue with the fall-through state (new ALF standard since late 2011).") ]		  
               [ CKeyword(CCommandAE::DO_NOT_CONTINUE_WARN, "w", "Do not continue with the fall-through state and warn if it is not bottom - this may be due to overestimations.") ]		  
            ]
            [COptionParameter(CCommandAE::VOLA, "vola",  "How to handle volatiles. If volatiles occur in the program and AE is run this flag must be set.") =
               CVal(CVal::KEYWORD)   	      
               [ CKeyword(CCommandAE::IGNORE_VOLATILES, "i", "Ignore volatile keyword in frame initializations. Treat volatile declared frames as normal frames.") ]
               [ CKeyword(CCommandAE::TOP_VOLATILES, "t", "Set all volatile frames to top values. All writes to frame will be ignored.") ]		  
            ]
            [COptionParameter(CCommandAE::ISI, "isi", "Ignore stores to integer addresses. Stores where the address is a concrete "
               "integer value are skipped, and therefore have no effect on the program state. Normally, such addresses are interpreted as TOP addresses, which "
               "results in that the stored value is stored to all locations in all memory frames, after first being LUBed with "
               "the value already stored at each location. This option is useful when analyzing code that contains stores to "
               "absolute memory addresses, for example, when memory-mapped I/O is used. With this option turned on, the analysis "
               "makes the unsafe assumption that these memory locations are disjoint from the memory locations used by "
               "regular variables in the program. Note that loads from such addresses are not skipped and will return TOP values, "
               "but that would happen in the normal case as well.")]
            [COptionParameter(CCommandAE::PU, "pu", "Process undefined functions, which means that calls to undefined functions"
               " will simply not be made. Further, all undefined global variables will initially be set to TOP, but"
               " become updated according to writes made during the AE analysis. Option must be set"
               " if AE should be run on code containing imports to functions that are not provided.")]
            [COptionParameter(CCommandAE::GENERATE_TRACE_FILE, "gtf",  "Generate trace file, i.e., print the names's of the CFG nodes taken during execution. Throws, similar to ccs, "
               "a run-time error if more than one state is generated during AE.")=
               CVal(CVal::STRING, "<file-name>")
            ]
            [COptionParameter(CCommandAE::READ_TRACE_FILE, "rtf", "Read trace from file and runs AE according to trace. A trace file can consist of several traces. A trace is a space-separated list of node names. Each trace ends with a semicolon.")=
               CVal(CVal::STRING, "<file-name>")
            ]
            [COptionParameter(CCommandAE::ALF_AST_NODE_BCET_WCET, "aac", "Generate BCET and WCET estimate using ALF AST construct costs. " 
               "The input file holds the ALF AST construct costs. Requires tc parameter to be set. Only cost for code constructs set by tc will be used in BCET/WCET calc.")=
               CVal(CVal::STRING, "<file-name>")
            ]
            [COptionParameter(CCommandAE::ALF_AST_NODE_BCET_WCET_PATHS, "aacpaths", "If set the aac option will also generate a BCET and WCET path based on the ALF AST construct costs. "
               "The paths will be printed to screen and are lists of basic block names. Can only be used together with aac.")
            ]
            [COptionParameter(CCommandAE::ALF_AST_NODE_BCET_WCET_PROF, "aacprof", "If set the aac option will also generate profiling information based on the ALF AST construct costs. "
               "The profiles show the cost distributions across functions for the BCET and WCET paths, "
               "and are written to files named _ALFCostCalc_BC.txt and _ALFCostCalc_WC.txt, respectively. Can only be used together with aac.")
            ]
            [COptionParameter(CCommandAE::OLD_ALF_AST_NODE_BCET_WCET, "oaac", "Old version of aac. Has same tc requirement.")=
               CVal(CVal::STRING, "<file-name>")
            ]
            [COptionParameter(CCommandAE::BB_COST_BCET_WCET, "bbc", "Generate BCET and WCET estimate using basic block and edges cost table. " 
               "The input file holds the cost lookup table for basic blocks and edges. "
               "Table rows should be on form BBID COST (node with single cost) or BBID COST1 COST2 (node with lower and upper cost) " 
               "or BBID1 BBID2 COST (edge with single cost) or BBID1 BBID2 COST1 COST2 (edge with lower and upper cost). BBID is a "
               "string not starting with a number or a minus. COST is a (potentially negative) integer.")=
               CVal(CVal::STRING, "<file-name>")
            ] 
            [COptionParameter(CCommandAE::BB_COST_BCET_WCET_PATHS, "bbcpaths", "If set the bbc option will also generate a BCET and WCET path based on the BB cost lookup table. "
               " The paths will be printed to screen and are lists of basic block names. Can only be used together with bbc.")
            ]
         ]

         // Create a timing database for ALF basic blocks using cost lookup table
         [COption(COption::TDB_BY_CLT, new CCommandCreateTimingForAlfBasicBlocksUsingCostLookupTable, "td", "timing-database",
            "Create a timing database (tdb) for basic blocks "
            "of ALF program based on cost lookup table (clt) "
            "holding timing costs for ALF code constructs.")
            [COption::CDependencies()[COption::CHECK]]
            [COptionParameter(CCommandCreateTimingForAlfBasicBlocksUsingCostLookupTable::CLT, "i",
               "Specifies the name of the input clt file "
               "to read timing for ALF code constructs from. "
               "If no file name is given default timing "
               "values will be used.")=
               CVal(CVal::STRING, "<clt-file-name>")
            ]
            [COptionParameter(CCommandCreateTimingForAlfBasicBlocksUsingCostLookupTable::TDB, "o",
               "Specifies the name of an output tdb file "
               "to which the result will be written to. "
               "If no file name is given the result will be "
               "written to stdout.")=
               CVal(CVal::STRING, "<tdb-file-name>")
            ]
         ]

         // ---------------------------------
         // Value analysis.  
         // ---------------------------------
         [COption(COption::VA, new CCommandVA, "va", "value-analysis", "Runs value analysis (on nodes in scope graph).")
            [COption::CDependencies()[COption::CHECK][COption::ABS_DOMAIN]]
            [COptionParameter(CCommandVA::ANALYSIS_TYPE, "a", "The analysis processing algorithm to use.")=
               CVal(CVal::KEYWORD)
               [*CKeyword(CCommandVA::NODE_ORDERING,"n", "Use worklist and process in optimal node order.")]
               [ CKeyword(CCommandVA::WORK_LIST,"l", "Use worklist but do not derive/use node ordering.")]
               [ CKeyword(CCommandVA::CHAOTIC,"j", "Use chaotic (Jacobi) fixpoint analysis.")]
            ]
            [COptionParameter(CCommandVA::FIXPOINT_PASS, "fp", "The fixpoint passes to use.")=
               CVal(CVal::KEYWORD)
               [*CKeyword(CCommandVA::WIDENING_NARROWING,"wn", "Widening followed by narrowing.")]
               [ CKeyword(CCommandVA::WIDENING,"w", "Widening only.")]
               [ CKeyword(CCommandVA::NARROWING,"n", "Narrowing only.")]
               [ CKeyword(CCommandVA::NORMAL,"c", "Classic fixpoint analysis (no narrowing or widening).")]
            ]
            [COptionParameter(CCommandVA::WID_NAR_POINT, "wnp", "The widening and narrowing points to use.")=
               CVal(CVal::KEYWORD)
               [*CKeyword(CCommandVA::LAST_STMT_IN_BB,"l", "Do wid and nar before last stmt in loop header.")]
               [ CKeyword(CCommandVA::AT_BACK_EDGE,"b", "Do wid and nar at back edges.")]
               [ CKeyword(CCommandVA::FIRST_STMT_IN_BB,"f", "Do wid and nar before first stmt in loop header.")]
            ]
            [COptionParameter(CCommandVA::FT, "ft",  "How to handle the fall-through state.") =
               CVal(CVal::KEYWORD)   	      
               [*CKeyword(CCommandVA::CONTINUE, "c", "Continue with the fall-through state if it is not bottom (C standard, used by melmac).") ]
               [ CKeyword(CCommandVA::DO_NOT_CONTINUE, "n", "Do not continue with the fall-through state (new ALF standard since late 2011).") ]		  
               [ CKeyword(CCommandVA::DO_NOT_CONTINUE_WARN, "w", "Do not continue with the fall-through state and warn if it is not bottom - this may be due to overestimations.") ]		  
            ]
            [COptionParameter(CCommandVA::PRINT_ANALYSIS_RESULT, "p", "Print value analysis to txt files. Generated files will be"
               " named as _AlfValueAnalysis_<f>_<i>.txt where i is iteration and f is fixpoint pass.")=
               CVal(CVal::KEYWORD)
               [ CKeyword(CCommandVA::RESULT,"r", "Only the final result is printed (least detailed).")]
               [ CKeyword(CCommandVA::FIX_POINT_PASS,"f", "The result after each fixpoint pass is printed.")]
               [ CKeyword(CCommandVA::ITERATION,"i", "The result of each iteration is printed (most detailed).")]
            ]
            [COptionParameter(CCommandVA::DRAW_ANALYSIS_RESULT, "d", "Draw value analysis to dot files. Generated files will be"
               " named as _AlfValueAnalysis_<f>_<i>.dot where i is iteration and f is fixpoint pass.")=
               CVal(CVal::KEYWORD)
               [ CKeyword(CCommandVA::RESULT,"r", "Only the final result is printed (least detailed).")]
               [ CKeyword(CCommandVA::FIX_POINT_PASS,"f", "The result after each fixpoint pass is printed.")]
               [ CKeyword(CCommandVA::ITERATION,"i", "The result of each iteration is printed (most detailed).")]
            ]
            // Maybe add possibility to do narrowing on non-invariant loop variables (-niw)
            // Maybe add possibility to do stepwise widening (-ws)
         ]

         // ---------------------------------
         // Def use (DU) analysis
         // ---------------------------------
         [COption(COption::DU, new CCommandDU, "du", "def-use-analysis", "Derives defines and uses of statements.")
            [COption::CDependencies()[COption::PARSE]]  // we neeed the points-to analysis, the CG and the ALF program
            [COptionParameter(CCommandDU::PRINT_ANALYSIS_RESULT, "p", "Print DU analysis result to txt files. Generated files will be named _ALFDUAnalysis.txt. ")]
         ]

         // ---------------------------------
         // RD analysis.  
         // ---------------------------------
         [COption(COption::RD, new CCommandRD, "rd", "reaching-definitions-analysis", "Runs reaching definitions.")
            [COption::CDependencies()[COption::CHECK][COption::DU]]
            // Add this option when wse support RD analysis on ECFG graph
            // [COptionParameter(CCommandRD::GRAPH, "g", "The graph structure to do the RD analysis upon.")=
            //      CVal(CVal::KEYWORD)
            //      [*CKeyword(CCommandRD::CG,"cg", "Use the cfg structure given by the call graph. Non-context senstive")]
            // [ CKeyword(CCommandRD::ECFG,"ecfg", "Use the graph structure given by the ecfg (underlying the sg).")]
            //   ]
            [COptionParameter(CCommandRD::ANALYSIS_TYPE, "a", "The analysis processing algorithm to use.")=
               CVal(CVal::KEYWORD)
               [*CKeyword(CCommandRD::NODE_ORDERING,"n", "Use worklist and process in optimal node order.")]
               [ CKeyword(CCommandRD::WORK_LIST,"l", "Use worklist but do not derive/use node ordering.")]
               [ CKeyword(CCommandRD::CHAOTIC,"j", "Use chaotic (Jacobi) fixpoint analysis.")]
            ]
            [COptionParameter(CCommandRD::PRINT_ANALYSIS_RESULT, "p", "Print RD analysis to txt files. Generated files will be"
               " named as _ALFRDAnalysis_<i>.txt where i is iteration. ")=
               CVal(CVal::KEYWORD)
               [ CKeyword(CCommandRD::RESULT,"r", "Only the final result is printed.")]
               [ CKeyword(CCommandRD::ITERATION,"i", "The result of each iteration is printed.")]
            ]
            [COptionParameter(CCommandRD::DRAW_ANALYSIS_RESULT, "d", "Draw RD analysis to dot files. Generated files will be"
               " named as _ALFRDAnalysis_<i>.dot where i is iteration. ")=
               CVal(CVal::KEYWORD)
               [ CKeyword(CCommandRD::RESULT,"r", "Only the final result is printed.")]
               [ CKeyword(CCommandRD::ITERATION,"i", "The result of each iteration is printed.")]
            ]
         ]

         // ---------------------------------
         // PDG analysis.  
         // ---------------------------------
         [COption(COption::PDG, new CCommandPDG, "pdg", "program-dependency-graph", "Derives a program dependency graph (PDG)."
            " Also derives other intermediate graphs, such as program control-flow graph (PCFG), program control-dependency graph (PCDG),"
            " program data-dependency graph (PDDG), as well as a def-use analysis (DU). See below for how to draw (-d) and print (-p) the graphs." )
            [COption::CDependencies()[COption::RD]]
         ]

         // ---------------------------------
         // Slicing
         // ---------------------------------
         [COption(COption::SLICE, new CCommandSlice, "sl", "slice", "Derive a slice based on a program dependency graph (PDG).") 
            [COption::CDependencies()[COption::PDG]]
            [COptionParameter(CCommandSlice::ENTITIES, "ent", "The code entity/entities to start the slicing upon. Can not be used together with lab or var. ")=
               CVal(CVal::KEYWORD)
               [ CKeyword(CCommandSlice::CONDS, "c", "Conditions (includes loop exit conds).")]
               [ CKeyword(CCommandSlice::LOOPS, "l", "Loop exit conditions.")]
               [ CKeyword(CCommandSlice::GLOBALS, "g", "Global variables.")]
               [ CKeyword(CCommandSlice::ROOT_FUNC_INPUTS, "i", "Call graph root function input variables.")]
               [ CKeyword(CCommandSlice::ROOT_FUNC_RETURNS, "r", "Call graph root function return stmts.")]	
            ]
            [COptionParameter(CCommandSlice::LABELS, "lab", "Labels of code entities to start the slice upon. A comma separated list of strings. "
               "Can be statement label(s) or function name(s). If function name all statements in the function will be in the start slice. " 
               "Can not be used together with ent or vars.")=
               CVal(CVal::STRING, "<label(s)>")
            ]
            [COptionParameter(CCommandSlice::VARS, "var", "Variables to start the slice upon. If several variables have the same name (due to local and global scoping) only "
               "one of them will be selected. If dir=f all code and data potentially affected by var(s) are derived. "
               "This is made by first deriving all statements which may use the var(s) and then do a forward from these statements. " 
               "If dir=b all code and data potentially affecting var(s) are derived. This is made by first deriving all statements where var(s) may be defined. "
               "We then do a backward slice upon these nodes. Can not be used together with ent or vars. ")=
               CVal(CVal::STRING, "<variables(s)>")
            ]
            [COptionParameter(CCommandSlice::MUL, "mul", "How to slice upon multiple entities. ")=
               CVal(CVal::KEYWORD)
               [*CKeyword(CCommandSlice::TOGETHER, "t", "One single slice together on all entities.")]
               [ CKeyword(CCommandSlice::INDIVIDUAL, "i", "Individual slices on each selected entity.")]
            ] 
            [COptionParameter(CCommandSlice::DIRECTION, "dir", "The slicing direction to use. ")=
               CVal(CVal::KEYWORD)
               [*CKeyword(CCommandSlice::BACKWARD, "b", "Backward, derives all statements and variables which may affect the selected entity.")]
               [ CKeyword(CCommandSlice::FORWARD, "f", "Forward, derives all statements and variables which may be affected by the selected entity.")]
            ] 
            [COptionParameter(CCommandSlice::PRINT, "p", "Print slice result(s) to txt file(s). Generated file(s) will be"
               " named _ALFSlicing_<ent/lab>_<dir>.txt. ")=
               CVal(CVal::KEYWORD_SET)
               [ CKeyword(CCommandSlice::RES_ALL, "all", "Print all (stmts, funcs, global, local, and scoped vars).")] 
               [ CKeyword(CCommandSlice::RES_STMTS, "s", "Print labels of the statements.")] 
               [ CKeyword(CCommandSlice::RES_FUNCS, "f", "Print names of the functions.")] 
               [ CKeyword(CCommandSlice::RES_GLOBALS, "g", "Print the global variables.")] 
               [ CKeyword(CCommandSlice::RES_LOCALS, "l", "Print the local variables (using just their names).")] 
               [ CKeyword(CCommandSlice::RES_SCOPED_LOCALS, "v", "Print the local variables with scope info (using func.var or func.scope.var naming).")] 
            ]
            [COptionParameter(CCommandSlice::INVERT, "inv", "Invert the slice before printing it, i.e., report what parts were removed "
               "from the slice as opposed to what parts remain in the slice. This is the recommended setting when using source code mappings (with --map-file), "
               "unless the provided map files are guaranteed to include mappings for all statements in the source code. Otherwise, if some source code statements "
               "do not have a mapping, it will appear as though they were sliced away since they are not included in the printed slice.")
            ]
            [COptionParameter(CCommandSlice::DRAW, "d", "Draw slice result(s) to dot file(s) as PDG graph. Generated file(s) will be"
               " named _ALFSlicing_<ent/lab/var>_<dir>.dot. ")
            ]
         ]

      ] // end option group

      ///////////////////////////////////////////////////////// 
      ///////////////////////////////////////////////////////
      // Outputs
      ///////////////////////////////////////////////////////
      ///////////////////////////////////////////////////////// 
      [COptionGroup("Outputs")

         // ---------------------------------
         // Flow facts
         // ---------------------------------
         [COption(COption::OUTPUT_FF, new CCommandOutputFlowFacts, "f",
            "flow-facts",
            "Generates flow fact file(s). The generated flow facts depend on the flow fact generation algorithms used in the AE. "
            "Requires that the AE has been run using a fully context-sensitive scope graph.")
            [COption::CDependencies()[COption::CHECK]]
            [COption::CDependencies()[COption::AE]]
            [COptionParameter(CCommandOutputFlowFacts::CS_LENGTH, "csl", "Specifies the largest call string length that should be used "
               "for generated flow information. Value should be either the keyword 'full' or a decimal integer >= 0. "
               "If csl value is not given zero context-sensitivity will be used.")=
               CVal(CVal::STRING)
            ]
            [COptionParameter(CCommandOutputFlowFacts::LANG, "lang", "The format of the produced flow facts.")=
               CVal(CVal::KEYWORD_SET)
               [*CKeyword(CCommandOutputFlowFacts::FF,     "ff", "Flow fact format, see sweet -h topic=ffg.")]
               [ CKeyword(CCommandOutputFlowFacts::SCOPES, "sg", "Scope graph - includes both flow facts and a CFG.")]
               [ CKeyword(CCommandOutputFlowFacts::RAPITA, "rapita", "The RAPITA format.")]
               [ CKeyword(CCommandOutputFlowFacts::AIS,    "ais", "The AIS format.")]
               [ CKeyword(CCommandOutputFlowFacts::TCD,    "tcd", "Produces a dummy tcd-file "
               "(containing only basic blocks, no statements)")]
            ]
            [COptionParameter(CCommandOutputFlowFacts::FILE_NAME, "o", "Specifies the flow fact file base name. "
               "By default base name of the "
               "input file will be used.")=
               CVal(CVal::STRING, "<file-name>", "The output file's base name.")
            ]
            [COptionParameter(CCommandPrint::STDOUT, "co", "The result is printed to the console rather than to a disk file.")]
         ]

         // ---------------------------------
         // Textual print-outs
         // ---------------------------------
         [COption(COption::PRINT, new CCommandPrint, "p", "print-textually", "Print data in a textual format.")
            [COption::CDependencies()[COption::CHECK]]
            [COptionParameter(CCommandPrint::GRAPHS, "g", "The data structures(s) to be printed.")=
               CVal(CVal::KEYWORD_SET)
               [*CKeyword(CCommandPrint::CFG,   "cfg",  "Control flow graph")]
               [ CKeyword(CCommandPrint::CFGD,  "cfgd", "Control flow graph with debug info")]
               [ CKeyword(CCommandPrint::PA,    "pa",   "Pointer analysis")]
               [ CKeyword(CCommandPrint::CG,    "cg",   "Call graph")]
               [ CKeyword(CCommandPrint::SG,    "sg",   "Scope graph")]
               [ CKeyword(CCommandPrint::SYMTAB,"sym",  "Symbol table")]        
               [ CKeyword(CCommandPrint::AST,   "ast",  "Abstract syntax tree of the program")]
               [ CKeyword(CCommandPrint::ASTL,  "astl", "Abstract syntax tree of the program after linkage")]
               [ CKeyword(CCommandPrint::EXPL,  "expl", "Exported symbols after linkage.")]
               [ CKeyword(CCommandPrint::IMPL,  "impl", "Imported symbols after linkage.")]
            ]
            [COptionParameter(CCommandPrint::FILE_NAME, "o", "Specifies the graph file base name."
               "The file name ending will indicate the file content. If not set "
               "content will be printed to stdout.")=
               CVal(CVal::STRING, "<file-name>", "The output file's base name.")
            ]
            [COptionParameter(CCommandPrint::STDOUT, "co", "The result is printed to the console rather than to a disk file.")]
         ]

         // ---------------------------------
         // Dot graphs
         // ---------------------------------
         [COption(COption::NICE_PRINT, new CCommandPrintNice, "d", "dot-print", "Print program graph(s) "
            "to dot file(s).")
            [COption::CDependencies()[COption::CHECK]]
            [COption::CPrecedences()[COption::LOAD_MAP][COption::PDG]]
            [COptionParameter(CCommandPrintNice::GRAPHS, "g", "The graph(s) to be printed.")=
               CVal(CVal::KEYWORD_SET)
               [*CKeyword(CCommandPrintNice::CFG,  "cfg", "Control flow graph")]
               [ CKeyword(CCommandPrintNice::CFG_WITH_C,"cfgc", "Control flow graph, nodes annotated with C-code if "
                  "mappings are available. Depends on optional loaded "
                  "C-code mappings.")]
               [ CKeyword(CCommandPrintNice::CG,   "cg",  "Call graph")]
               [ CKeyword(CCommandPrintNice::RSG,  "rsg", "Reduced scope graph - cfg nodes are basic blocks")]
               [ CKeyword(CCommandPrintNice::FSG,  "fsg", "Full scope graph - cfg nodes are statements")]
               [ CKeyword(CCommandPrintNice::SGH,  "sgh", "Scope graph hierarchy - no cfg nodes are shown.")]
               [ CKeyword(CCommandPrintNice::PDG,   "pdg",  "Program dependency graph (requires -pdg)")]
               [ CKeyword(CCommandPrintNice::PCFG,  "pcfg", "Program control-flow graph (requires -pdg)")]
               [ CKeyword(CCommandPrintNice::PCDG,  "pcdg", "Program control dependency graph (requires -pdg)")]
               [ CKeyword(CCommandPrintNice::PDDG,  "pddg", "Program data dependency graph (requires -pdg)")]
            ]
            [COptionParameter(CCommandPrintNice::FILE_NAME, "file", "Specifies the base name of the file where to print "
               "the graph(s). A string indicating the format of the "
               "file will be appended + a '.dot' suffix. If "
               "not given, the program file base name "
               "will be used.")=
               CVal(CVal::STRING, "<file-name>", "The name of the output file(s).")
            ]
            [COptionParameter(CCommandPrintNice::FUNCTION, "function", "The name of the function where to start the print-out. "
               "This parameter only applies "
               "to the printing of scope graphs.")=
               CVal(CVal::STRING, "<function name>", "The name of the function.")
            ]
            [COptionParameter(CCommandPrintNice::MAX_LEVELS, "max_levels", "The maximum number of levels that will be printed. "
               "This parameter only applies "
               "to the printing of scope graphs.")=
               CVal(CVal::INT, "<max_levels>", "The maximum number of levels.")
            ]
            [COptionParameter(CCommandPrintNice::DAG, "dag", "Prints a scope graph generated in DAG form rather than "
               "as a context sensitive graph. This parameter only applies "
               "to the printing of scope graphs.")
            ]
            [COptionParameter(CCommandPrintNice::USE_TOOL_TIPS, "tt", "The nodes in the graph will be labelled "
               "using integers, and the node names will appear "
               "as tool tips. This will make the graph more dense."
               "Currently only notified by the scope hierarchy.")
            ]
         ]

         // ---------------------------------
         // Annotation template
         // ---------------------------------
         [(COption(COption::GENERATE_ABS_ANN, new CCommandGenerateAbsAnn, "at", "annotation-templates",
            "Tries to generate abstract annotation templates for each imported and "
            "referenced identifiers (i.e., reference to undefined entity). "
            "References not possible to make templates for it will "
            "output error messages to the console. "
            "The annotation value will be set to TOP in case the type is known, "
            "else the value is left to fill in manually. Other uncertenties may "
            "be found as comments in the file. "
            "NOTE! In case of unresolved references, the function may in general "
            "be able to update any existing global variable, and it's the user's "
            "responsibility to use the annotation. "
            "Information will be provided on the source code level if "
            "label-to-C-source mapping is provided (option -m)")=
            CVal(CVal::STRING, "<file-name>", "The name of the generated file."))
            [COption::CDependencies()[COption::CHECK]]
            [COption::CPrecedences()[COption::LOAD_MAP]]
         ]

         // ---------------------------------
         // Cost-lokup table template
         // ---------------------------------
         [(COption(COption::GENERATE_CLT_TEMPLATE, new CCommandGenerateCostLookupTableTemplate, "ct", "cost-lookup-table-template",
            "Generate cost lookup table template. Members of selected types are printed with zero value.")=
            CVal(CVal::STRING, "<file-name>"))
            [COptionParameter(CCommandGenerateCostLookupTableTemplate::TYPES, "types",  "The ALF types to include in the printout. If not given all types will be used.") =
               CVal(CVal::KEYWORD_SET)
               [ CKeyword(CCommandGenerateCostLookupTableTemplate::ALL_TYPES, "all", "All types, i.e pr+gn+op+st+sp.")]
               [ CKeyword(CCommandGenerateCostLookupTableTemplate::PROG_RUN, "pr", "Program run, a basic cost for each program run.")]
               [ CKeyword(CCommandGenerateCostLookupTableTemplate::GEN_NODES, "gn", "Generic nodes, i.e. nodes in ALF syntax tree.")]
               [ CKeyword(CCommandGenerateCostLookupTableTemplate::OPS, "op", "Operators, i.e. add, sub, ...")]
               [ CKeyword(CCommandGenerateCostLookupTableTemplate::STMTS, "st", "Statements, i.e. store, call, ...")]
               [ CKeyword(CCommandGenerateCostLookupTableTemplate::STMT_PAIRS, "sp", "Statement pairs, i.e. <store,store>, <store,call>, ...")]
            ]
         ]

         // ---------------------------------
         // CG content information 
         // ---------------------------------
         [(COption(COption::EXTRACT_FUNCS_INFO, new CCommandExtractFuncCGsAndInfo, "fi", 
            "function-information","Extract call-graphs for selected functions and print info.")=
            CVal(CVal::STRING, "<func-name(s)>", "A comma-separated list of function names. "
            "For each function given, its corresponding call-graph will be derived. The call-graph includes all functions reachable from the given function. "
            "Info will then be derived and printed to different files according to the p parameter with appropriate names, namely: <dir><func>.alf ,<dir><func>.imports, <dir><func>.exports, and "
            "<dir><func>.template.annot. All functions must be reachable from the current root function in the call-graph."))
            [COptionParameter(CCommandExtractFuncCGsAndInfo::PRINT, "p", "The things to be printed. If not given all printouts will be used. ") =
               CVal(CVal::KEYWORD_SET)
               [*CKeyword(CCommandExtractFuncCGsAndInfo::ALL, "all", "All types, i.e. alf+imp+exp+at++info.")]
               [ CKeyword(CCommandExtractFuncCGsAndInfo::ALF, "alf", "ALF program, result is written to <dir><func>.alf")]
               [ CKeyword(CCommandExtractFuncCGsAndInfo::IMPORTS, "imp", "Imports, result is written to <dir><func>.imports")]
               [ CKeyword(CCommandExtractFuncCGsAndInfo::EXPORTS, "exp", "Exports, result is written to <dir><func>.exports")]
               [ CKeyword(CCommandExtractFuncCGsAndInfo::ANNOT_TEMPLATE, "at", "Annot template, result is written to <dir><func>.template.annots")]
               [ CKeyword(CCommandExtractFuncCGsAndInfo::MAP, "map", "Map, result is written to <dir><func>.map. Will only produce result when -m is used. Note: inly implemented for melmac code.")]
               [ CKeyword(CCommandExtractFuncCGsAndInfo::INFO, "info", "Extra info file for statistics on files content.")]
            ]
            [COptionParameter(CCommandExtractFuncCGsAndInfo::DIR, "d", "The (path and) directory to which all files produced by this option will be written. "
               "If not given all files will be stored in the directory in which SWEET is run.")=
               CVal(CVal::STRING, "<directory>")
            ]
            [COption::CDependencies()[COption::CHECK]]
         ]
      ]

      ///////////////////////////////////////////////////////// 
      //////////////////////////////////////////////////////////
      // OTHER
      /////////////////////////////////////////////////////////
      ///////////////////////////////////////////////////////// 

      [COptionGroup("Other")

         // ---------------------------------
         // Detailed information 
         // ---------------------------------
         [COption(COption::INSPECTION, new CCommandInspection, "cs", "code-statistics",
            "Produces various information about the code structure.")
            [COptionParameter(CCommandInspection::FILE, "o", "The (path and) file to which the information will be printed. "
               "If no file name is given the result will be printed to stdout.")=
               CVal(CVal::STRING, "<file-name>")
            ]
            // [COption::CDependencies()[COption::CHECK]]
         ]

         // ---------------------------------
         // Current version and version check
         // ---------------------------------
         [COption(COption::VERSION, new CCommandVersion, "v", "version", "Shows the build version and date.")]

         // ---------------------------------
         // Help messages
         // ---------------------------------
         [COption(COption::HELP, new CCommandHelp, "h", "help", "Shows help text.")
            [COptionParameter(CCommandHelp::TOPIC, "topic", "Help topic, i.e., what to show help text on.")=
               CVal(CVal::KEYWORD)
               [*CKeyword(CCommandHelp::OPTION,   "option",   "Shows help on SWEET's parameters and options")]
               [ CKeyword(CCommandHelp::ANNOT,    "annot",    "Shows help on SWEET's input annotation language")]
               [ CKeyword(CCommandHelp::FFG,  "ffg", 
                  "Shows help on flow fact generation using AE. Also gives an introduction to "
                  "SWEET's (context-sensitive valid-at-entry-of) flow fact format.")]
               [ CKeyword(CCommandHelp::TRACE,  "trace", 
                  "Shows help on flow hypotheses generation using traces.")]
            ]
            [COptionParameter(CCommandHelp::USE_CSI, "s", "Use syntax high lighting on help text.")]
         ]

      ];
      option_groups->CheckConsistency();
      return option_groups;
   }
}
