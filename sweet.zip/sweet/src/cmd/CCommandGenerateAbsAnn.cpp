// $Id $

#include "CCommandGenerateAbsAnn.h"
#include "CCommandParse.h"
#include "CCommandLoadMap.h"
#include "CSession.h"
#include "program/alf/StaticProgramChecking.h"
#include "program/CGenericProgram.h"
#include "program/CGenericFunction.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/AbsAnnotTemplate.h"
#include "graphs/cg/CCallGraph.h"
#include "graphs/cg/CCallGraphNode.h"
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

namespace cmd {

void
CCommandGenerateAbsAnn::
Validate(const CSession *session)
{
   (void)session;
   string file_name = GetVal()->AsString();
   AssertFileAccessability(file_name, "w");
}

void
CCommandGenerateAbsAnn::
Execute(const CSession *session)
{
   string file_name = GetVal()->AsString();
   CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
   CGenericProgram *ast = command_parse->GetAst();

   bool use_old_style_templates = false;
   if(use_old_style_templates) {
     // Get the source loader
     const CSourceLoader *source_loader = NULL;
     if (session->HasCommand(COption::LOAD_MAP)) {
       CCommandLoadMap *load_map_command = dynamic_cast<CCommandLoadMap *> (session->GetCommand(COption::LOAD_MAP));
       source_loader = load_map_command->GetSourceLoader();
     }
     
     // Generate old style annotation templates
     ofstream fs;
     fs.open(file_name.c_str(), ios::out);
     if (fs.is_open()) {
       const vector<CFlowGraph*> flow_graphs = command_parse->GetFlowGraphs();
       const CSteensgaardPA *pa = command_parse->GetPointerAnalysis();
       const CSymTabBase *symtab = ast->GetSymTab();
       StaticAlfErrorCollection undefs;
       CCallGraph *call_graph = command_parse->GetCallGraph();
       vector <CGenericFunction*> functions;
       for (unsigned i=0; i<call_graph->NrOfNodes(); ++i) {
         CCallGraphNode *call_graph_node = call_graph->NodeAt(i);
         functions.push_back(call_graph_node->Function());
       }
       CheckUnresolvedReferences(dynamic_cast<alf::CAlfTuple &>(*ast), functions, symtab, undefs);
       alf::AbstractAnnotationTemplates annots(undefs, pa, symtab, flow_graphs);
       annots.Print(fs, source_loader);
       annots.PrintFailedUndefs(fs, source_loader);
       fs.close();
     }
   }
   else {
     // Generate new style annotation templates
     CCallGraphNode * start_cg_node = command_parse->GetStartNode();
     CGenericFunction * start_func = NULL;
     if(start_cg_node) start_func = start_cg_node->Function();
     command_parse->PrintAnnotationTemplate(dynamic_cast<alf::CAlfTuple *>(ast), file_name, start_func);
   }
}


}
