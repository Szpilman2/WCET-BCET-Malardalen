// $Id $

#ifndef CCOMMAND_GENERATE_COST_LOOKUP_TABLE_TEMPLATE_H_INCLUDED
#define CCOMMAND_GENERATE_COST_LOOKUP_TABLE_TEMPLATE_H_INCLUDED

#include "CCommand.h"

namespace cmd {

class CSession;

/** \class CCommandGenerateCostLookupTableTemplate
   Tries to generate a cost lookup table template. 
*/
class CCommandGenerateCostLookupTableTemplate : public CCommand
{
public:
  
  typedef enum KEY { TYPES, ALL_TYPES, PROG_RUN, GEN_NODES, OPS, STMTS, STMT_PAIRS } KEY;

   /** Throws a runtime exception if the (specified) file can not
      be written to. */
   void Validate(const CSession *session);

   /** Performs the generation. */
   void Execute(const CSession *session);

   CCommand *Copy() const { return new CCommandGenerateCostLookupTableTemplate(*this); }
private:

   std::string _file_name;
   bool _print_prog_run;
   bool _print_gen_nodes;
   bool _print_ops;
   bool _print_stmts;
   bool _print_stmt_pairs;
};

}

#endif
