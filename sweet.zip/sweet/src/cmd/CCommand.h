// $Id $

#ifndef COMMAND_H_INCLUDED
#define COMMAND_H_INCLUDED

#include "CCommandVal.h"
#include "CCommandArgument.h"
#include <string>
#include <vector>
#include <cassert>

class OutputSettings
{
public:
   class Output {
      public:
      int key;
      std::string file_name;
   };

   std::vector <Output> outputs;
};

namespace cmd {

class CSession;
class COption;
class CCommandAE;
class CCommandVA;

/** \class CCommand
   Represents a command. This is the result of a user input option that
   matches an allowed option. A command may have a value and may have
   arguments. \n
   Typically a command wraps the call to some analysis that an option
   aims to perform. But in general a command may be anything that can
   be executed. E.g. packing a couple of settings for another analysis.
   Or do some printing. It may also run several analyses.
*/
class CCommand {
public:
   /** Constructs a new empty command. */
   CCommand() : val(NULL), option(NULL) { }

   virtual ~CCommand();

   CCommand(const CCommand &other);

   /** Performs any validity check that is needed by the command and that is
      not performed during parsing. This can e.g. be checking if a file name
      exists, checking if there are other restrictions on the value of the
      option or on its parameters, checking if there are constraints how to
      combine parameters, checking if there are constraints how to combine
      this command's option with other options, etc.
      Throws an exception if not evereything is correct.
      \param session A pointer to the session. */
   virtual void Validate(const CSession *session) = 0;

   /** Executes the command.
      \param session A pointer to the session. */
   virtual void Execute(const CSession *session) = 0;

   /** Copies an empty new command without.
      \return a pointer to the new command. */
   virtual CCommand *Copy() const = 0;

   /** Adds a new command argument to this command.
      \param argument The argument to add. */
   void AddArgument(CCommandArgument *argument) { command_arguments.push_back(argument); }

   /** Set a command value this command.
      \param new_val The value to set */
   void SetVal(CCommandVal *new_val) { val = new_val; }

   /** Set a pointer to the option that matches this command.
      \param new_option The option to set. */
   void SetOption(const COption *new_option) { option = new_option; }

   /** \return A pointer to the option that has been set in this command.
      \pre \a SetOption() has been called. */
   const COption *GetOption() const { assert(option); return option; }

   /** Check that no parameter occure more than once unless it is a
      multi-keyword parameter. Throws an exeption if voilated. */
   void CheckForDuplicatedArguments() const;

   /** Check if there is a certain argument in this command.
   \param key The key of some possible option parameter to match with some
      argument.
   \return A pointer to the command argument if found or NULL if it does not
      exist.
      Semantics: An argument given by the user or an optional argument with a
      default value and that is not given by the user exists other cases does
      not exist. */
   const CCommandArgument *GetArgument(int key) const;

protected:
   /** \return A pointer to the command value of this command.
      \pre \a SetVal() has been called. */
   const CCommandVal *GetVal() const { assert(val); return val; }

   /** Check that if code is among the key value alternatives given in argument
      then there is no other alternatives. Thows a runtime exception on error.
      \param argument A pointer to an existing argument.
      \param code The code of the value alternative to assert
      \pre \a argument has a value type of 'key set'. */
   void AssertUniqueAlternative(const CCommandArgument *argument, int code) const;

   /** Check that a file is accassible in a certain mode.
      \param file_name The name of the file to check.
      \param mode A pointer to a string specifying the access mode (as of the
      fopen() function). Throws a runtime exception if not accessible. */
   static void AssertFileAccessability(std::string file_name, const char *mode);

   /** Create a base file name using an argument specification if present,
      else create a basename using the input file name.
      \param session A pointer to the session.
      \param argument_key The key of a potential argument.
      \return The generated file base name.
      \pre The caller depends on the parsing command. */
   std::string CreateBaseName(const CSession *session, int argument_key) const;

   std::vector <CCommandArgument*> command_arguments;

private:
   CCommandVal *val;
   const COption *option;
};



/** \class CCommandPrintFile Extends CCommand with the ability to generate
   a file printing list */
class CCommandPrintFile : public CCommand
{
public:
   /** If consol_output_key is not an existing argument, then check for file write permissions and
      adds the file name and key to the option outputs list.
      Throws a runtime exception if the (with specified or generated name) file can not
      be written to. */
   void ValidateFiles(const CSession *session, int file_key, int format_key, std::string appendix, int consol_output_key=-1);

protected:
   OutputSettings output_settings;
};

}
#endif
