// $Id $

#ifndef COMMAND_PARSE_H_INCLUDED
#define COMMAND_PARSE_H_INCLUDED

#include "CCommand.h"
#include "symtab/CSymTabBase.h"
#include "program/alf/AlfLinker.h"
#include <set>
#include <list>

class CGenericProgram;
class CALFAbsAnnotStorage;
class CALFOutAnnotSpecStorage;
class CSteensgaardPA;
class CCallGraph;
class CCallGraphNode;
class CCollector;
class FlowFactTypes;
class AESettings;
class CFlowGraph;
class CScopeGraph;
class CDomainSettings;
class ParseTest;

namespace cmd {

/** \class CCommandParse
   Parses an input file containing the code to analyze.
   In case of multiple input files (i.e. linking) then the name of the
   first file will be set.
   Basic operations on the ast are be performed by Execute(), and the result
   available through the interfaces.
*/
class CCommandParse : public CCommand
{
public:
  typedef enum KEY { LANG, AUTO, ALF, CFG, FUNC, ANNOT, OUTPANNOT, MERGED_OUTPUT, YES, NO, UNMANGLE, RDE } KEY;

   CCommandParse()
	   : remove_dupl_exports(false), ast(NULL), pa(NULL), call_graph(NULL), start_node(NULL),
	   annot_storage(NULL), out_annot_specs_storage(NULL) {}

   ~CCommandParse();

   /** Throws a runtime exception if autodetection of language is specified and
      it is not possible to perform an atutodetection or any of the specified
      files can not be read.
      \post GetFileName() returns a valid file name. */
   void Validate(const CSession *session);

   /** Parse, build ast, symbol table, pointer analysis and associated
      graphs (cg, cfg).
      Throws a runtime exception if parsing fails or if the code structure
      makes the graph building fail.
      \post GetAst(), GetPointerAnalysis(), GetCallGraph() returns valid
         pointers.
      \post GetFlowGraphs() returns a vector with flow graphs of the
         program. */
   void Execute(const CSession *session);

   CCommand *Copy() const { return new CCommandParse(*this); }

   /* Functions to get access to the analysis results. These are available
      when Execute() has finished. */

   /** \return A pointer to the ast. The memory does not belong to the caller. */
   CGenericProgram * GetAst() { return ast; }

   /** \return A reference to the link log */
   const alf::LinkLog& GetLinkLog() const { return link_log; }

   /** \return A pointer the storage of abstract annotations. The memory does
       not belong to the caller. */
   CALFAbsAnnotStorage * GetAnnotStorage() { return annot_storage; }

   /** \return A pointer the storage of output annotation specifications. The memory does
    not belong to the caller. */
   CALFOutAnnotSpecStorage * GetOutAnnotSpecStorage() { return out_annot_specs_storage; }

   /** \return A pointer to the pointer analysis. The memory does not belong to
      the caller. */
   const CSteensgaardPA * GetPointerAnalysis() { return pa; }

   /** \return A pointer to the call graph. The memory does not belong to
      the caller. */
   CCallGraph * GetCallGraph();

   /** \return A pointer to the start function's call graph node if specified, else NULL. */
   CCallGraphNode *GetStartNode();

   /** \return A pointer to all flow graphs of the program that are to be analyzed. The
      flow graphs does not belong to the caller. */
   const std::vector<CFlowGraph*> &GetFlowGraphs() { return flow_graphs; }

   std::string GetProgramFileName() { return input_program_file_name; }

   const std::vector<std::string>& GetProgramFileNames() const {return file_names;}

   int GetProgramLanguage() { return lang; }

   // Functions needed by CCommandExtractFuncCGsAndInfo 
   void GetIdsPossiblyReferencedFromCallGraphNodes(std::set<CSymTabBase::KeyType>& out, std::list<CCallGraphNode *> * cg_nodes) const;
   void PrintASTFiltered(const alf::CAlfTuple * ast, std::set<CSymTabBase::KeyType> & referenced_ids, std::string file_name) const;
   void PrintImportsAsTextFiltered(const alf::CAlfTuple * ast, std::set<CSymTabBase::KeyType> & referenced_ids, std::string file_name) const;
   void PrintExportsAsTextFiltered(const alf::CAlfTuple * ast, std::set<CSymTabBase::KeyType> & referenced_ids, std::string file_name) const;
   void PrintAnnotationTemplate(const alf::CAlfTuple * ast, const CSteensgaardPA *pa, const std::vector<CFlowGraph*> * flow_graphs, 
                                std::set<CSymTabBase::KeyType> & referenced_ids, std::vector<CGenericFunction *> * funcs, std::string file_name) const;
   // Stored here since it is using LRefFRefReferencedIdFilter class
   // which is located in CCommandParse.cpp
   void PrintAnnotationTemplate(const alf::CAlfTuple * ast, std::string file_name, 
                                CGenericFunction * start_function=NULL, std::set<CSymTabBase::KeyType> * referenced_ids=NULL) const;

   // Help functions for statistics printouts
   unsigned int GetNrOfLRefImportsFiltered(const alf::CAlfTuple * ast, std::set<CSymTabBase::KeyType> & referenced_ids) const;
   unsigned int GetNrOfFRefImportsFiltered(const alf::CAlfTuple * ast, std::set<CSymTabBase::KeyType> & referenced_ids) const;
   unsigned int GetNrOfVolatileInitsFiltered(const alf::CAlfTuple * ast, std::set<CSymTabBase::KeyType> & referenced_ids) const;
   unsigned int GetNrOfAddrVolatileInitsFiltered(const alf::CAlfTuple * ast, std::set<CSymTabBase::KeyType> & referenced_ids) const;

   /** Returns all statement labels (actually "lref ids") that occur in the ALF
   file @a alf_file. This is only to be able to check the correctness of the
   corresponding .map file (if one is supplied, that is), i.e., check that all
   labels referenced in the .map file exist in the ALF file. Note that labels
   might be mangled during linking of the program, but this function returns the
   labels as they were in the original ALF file, so that the (unmangled) labels
   occuring in the .map file can be checked against the original labels.

   TODO: It is probably better to save a copy of the entire symbol table for each ALF file;
   in the future we should add support for specifying several annotation files, that are
   then linked together, and there would be similar issues for these files. */
   const std::set<std::string> &GetSavedLabels(const std::string &alf_file) const { return alf_files_to_labels.at(alf_file); }

private:
   // Settings:
   int lang;
   std::vector <std::string> file_names;
   bool has_start_function_name;
   std::string start_function_name;
   std::string annotation_file_name;
   std::string output_annotation_specification_file_name;
   std::string input_program_file_name;
   bool print_linked_ast;
   std::string linked_file_name;
   bool print_cg_ast;
   bool print_exports;
   std::string print_exports_file_name;
   bool print_imports;
   std::string print_imports_file_name;
   std::string cg_ast_file_name;
   bool remove_dupl_exports;
   bool melmac_unmangle;
   bool extract_func_cg_info;
   std::list<std::string> extract_func_names;
   std::string extract_func_names_dir;

   // Result:
   CGenericProgram *ast;
   alf::LinkLog link_log;
   const CSteensgaardPA *pa;
   CCallGraph *call_graph;
   CCallGraphNode *start_node;
   std::vector<CFlowGraph*> flow_graphs;
   CALFAbsAnnotStorage * annot_storage;
   CALFOutAnnotSpecStorage * out_annot_specs_storage;
   /** @see GetSavedLabels() */
   std::map<std::string,std::set<std::string>> alf_files_to_labels;

   void DoTheParsing();

   /** @see GetSavedLabels() */
   void SaveLabels(const alf::CAlfTuple *ast);

   void DoPrinting(const cmd::CSession * session);

   void PrintLinkedAST() const;

   void PrintImportsInAST() const;
   void PrintExportsInAST() const;
   
   void BuildFlowGraphs();

   void ParseAnnotationFile();
   void ParseOutputAnnotationSpecificationFile();

   void CheckForReturnStatementPresence();

   void CheckForNoUndefinedExpressionPresence();

   void PerformPointerAnalysis();

   void BuildCallGraph();

   void ExtractCallGraphToUse();

   // First version uses the interal call graph.
   void GetIdsPossiblyReferencedFromCallGraph(std::set<CSymTabBase::KeyType>& out) const;
   void GetIdsPossiblyReferencedFromCallGraph(std::set<CSymTabBase::KeyType>& out, CCallGraph * cg) const;

   // void ExtractFuncCGsAndInfo();  

   // void DoALFRDAnalysis();

   void HandlePACOption(CCallGraph * cg, std::string file_name) const;
   
   friend class ::ParseTest;
   
};

}

#endif
