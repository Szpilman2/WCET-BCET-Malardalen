// $Id $

#ifndef CCOMMAND_DOMAIN_H_INCLUDED
#define CCOMMAND_DOMAIN_H_INCLUDED

#include "CCommand.h"

class CDomainSettings;

namespace cmd {

class CSession;

/** \class CCommandDomain
   Set up of the domain to be used
*/
class CCommandDomain : public CCommand
{
public:
  typedef enum KEY { TYPE, INTERVAL, CLP,
//     CONGRUENCE, MIXED_INT, 
//     PRODUCT, 
                     FLOATS, TOP_FLOATS, ESTIM_FLOATS, REUSE, ALL, NONE, MEMORY,
                     CALL_STACK, RECORDER, RECORDER_HOLDER, NO_GLOB_INIT, EDO } KEY;

   CCommandDomain() : domain_settings(NULL) { }
   ~CCommandDomain();

   /** Check if the arguments are valid. If re-use specification contains
      contradictions then a runtime exception will be thrown.
      \post GetDomainSettings() returns the settings. */
   void Validate(const CSession *session);

   /** Initializes the domain. */
   void Execute(const CSession *session);

   /** Returns the domain settings in case present, else NULL. */
   const CDomainSettings *GetDomainSettings() { return domain_settings;}

   CCommand *Copy() const;

private:
   CDomainSettings *domain_settings;
};

}



#endif
