#ifndef INPUT_VAL_H_
#define INPUT_VAL_H_

#include <string>
#include <cstring>
#include <cassert>
#include <cstdlib>

namespace cmd {

/** \class CInputVal
   Contains an input expression (as a string) that may be interpreted as an
   integer value. If not it is a string value.
*/
class CInputVal
{
public:
   /** Constructs a temporary input value, whose content needs to be replaced
      by copying in order to become a legal input value. */
   CInputVal() : val_as_text(""), is_int(0) { }

   /** Constructs a proper input value.
      \param val_as_text The value as text. */
   CInputVal(std::string val_as_text) : val_as_text(val_as_text)
   {
      const char *start=val_as_text.c_str();
      char *end;
      int_val = strtol(start, &end, 0);
      is_int = end == start + val_as_text.length();
   }

   /** \return This value as text. This is always valid.*/
   std::string AsText() const { return val_as_text; }

   /** \return This input value as an integer.
      \pre \a IsInt() returns true.*/
   int AsInt() const { assert(is_int); return int_val; }

   /** \return True if this input value can be interpreted as an integer. */
   bool IsInt() const { return is_int; }

private:
   std::string val_as_text;
   int int_val;
   bool is_int;
};
}
#endif
