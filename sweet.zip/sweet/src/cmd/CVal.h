#ifndef VAL_H_
#define VAL_H_

#include "CKeyword.h"
#include <string>
#include <vector>
#include <cassert>

namespace cmd {

/** \class CVal
   Contains a specification of an allowed command line value. A value has
   a type that is either of integer, string or a set of possible keywords.
*/
class CVal {
public:
   typedef enum TYPE {
      INT,
      STRING,
      KEYWORD,
      KEYWORD_SET,
      VOID
   } TYPE;

   /** Constructs a temporary value, whose content needs to be replaced by
      copying in order to become a legal value. */
   CVal() : type(VOID) { }

   /** Constructs a proper value.
      \param type The type of the value.
      \param name The "name" of the value. This can be used as a place holder
         when showing the help message, but is not needed.
      \param short_description An optional description of the value. There is
         no special limit of the text length, but to conform to the standard
         it can be a good idea to pass a text in the range of 20-200 characters.
      \param detailed_description An optional detailed description of the value.
         This is the place for a detailed description of the semantics of this
         value. */
   CVal(TYPE type,
        std::string name="",
        std::string short_description="",
        std::string detailed_description="") :
               type(type),
               name(name),
               short_description(short_description),
               detailed_description(detailed_description),
               has_default_val(false)
               { }
   /** \return The type of this value. */
   TYPE GetType() const { return type; }

   /** \return The name of this value. */
   std::string GetName() const { return name; }

   /** \return The short description of this value. */
   std::string ShortDescription() const { return short_description; }

   /** \return The detailed description of this value, or, if there is none,
      the short one. */
   std::string DetailedDescription() const {
      if (detailed_description.empty()) {
         return short_description;
      } else {
         return detailed_description;
      }
   }

   /** \return The set of keywords of this value as a vector.
      \pre GetType() returns KEYWORD or KEYWORD_SET. */
   const std::vector<CKeyword> &GetKeywordList() const { assert(type==KEYWORD || type==KEYWORD_SET); return keyword_list; }

   /** Looks for a certain keyword among all the keywords.
      \param code The code of the keyword object to find.
      \return The found keyword object.
      \pre GetType() returns KEYWORD or KEYWORD_SET. 
      \pre \a code is the code of some keyword in the set of keywords of this value. */
   CKeyword GetKeyword(int code) const
   {
      assert(type==KEYWORD || type==KEYWORD_SET);
      CKeyword keyword;
      unsigned i;
      for (i=0; i<keyword_list.size(); ++i) {
         if (keyword_list[i].GetCode() == code) {
            keyword = keyword_list[i];
            break;
         }
      }
      assert(i<keyword_list.size());
      return keyword;
   }

   /** \return True if there is a default keyword alternative specified, else false. */
   bool HasDefaultVal() const { return has_default_val; }

   /** Adds a new keyword to the set of keywords of this value.
      \pre GetType() returns KEYWORD
      \pre If IsDefault() is true for the keyword to add then IsDefault() is
      false for all keywords that are already present in this value's set of keywords.*/
   CVal &operator[](CKeyword keyword)
   {
      assert(type==KEYWORD||type==KEYWORD_SET);
      assert(!(has_default_val && keyword.IsDefault()));
      has_default_val = keyword.IsDefault();
      keyword_list.push_back(keyword);
      return *this;
   }
private:
   TYPE type;
   std::string name;
   std::string short_description;
   std::string detailed_description;
   std::vector<CKeyword> keyword_list;
   bool has_default_val;
};
}
#endif
