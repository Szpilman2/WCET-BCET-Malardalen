// $Id $

#include "CCommandParse.h"
#include "absann/CALFAbsAnnot.h"
#include "absann/CALFOutAnnotSpec.h"
#include "globals.h"
#include "graphs/cg/CCallGraph.h"
#include "graphs/cg/CreateCallGraph.h"
#include "graphs/cg/CCallGraphNode.h"
#include "tools/melmac.h"
#include "parsers/alf/CParser.h"
#include "parsers/cfgs/cfgs.h"
#include "program/alf/AlfLinker.h"
#include "program/alf/ASTFilter.h"
#include "program/alf/PostProcessAst.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CAlfTreeFilter.h"
#include "program/alf/CAlfTreeTraversor.h"
#include "program/alf/CImportsTuple.h"
#include "program/alf/CFRefList.h"
#include "program/alf/CFRefTuple.h"
#include "program/alf/CLRefList.h"
#include "program/alf/CLRefTuple.h"
#include "program/alf/CLabelTuple.h"
#include "program/alf/CInitList.h"
#include "program/alf/CInitTuple.h"
#include "program/alf/CAllocTuple.h"
#include "program/alf/CGenericNode.h"
#include "program/alf/CRefTuple.h"
#include "program/alf/CUndefinedExprTuple.h"
#include "program/alf/StaticProgramChecking.h"
#include "program/alf/AbsAnnotTemplate.h"
#include "program_state/LAU.h"
#include "program_state/Endianness.h"
#include "ptranal/CSteensgaardPA.h"
#include "ptranal/CSteensgaardAnalysisBuilder.h"
#include "symtab/CSymTabBase.h"
#include "symtab/CSymTabEntry.h"
#include "cmd/CSession.h"
#include "cmd/CCommandAE.h"
#include "cmd/CCommandPrint.h"
#include "ae/AlfAbstractExecution.h"
#include "macros.h"
#include <stdexcept>
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <list>
#include <iterator>

extern FILE *yyin;

#include "tools/CTextBlock.h"

namespace cmd {

CCommandParse::
~CCommandParse()
{
   delete ast;
   delete annot_storage;
   delete out_annot_specs_storage;
   delete call_graph;
   delete pa;
}

/** Check if the file exists (if it can be opened in read mode), and, in case
   autodetection of language is specified, if we are able to do that. */
void
CCommandParse::
Validate(const CSession *session)
{
   { // The assignment is mandatory, i.e. the name is there
      string file_names_string = GetVal()->AsString();

      size_t scan_start = 0;
      size_t match_pos;
      do {
         match_pos = file_names_string.find(',', scan_start);
         size_t length = match_pos - scan_start;
         string file_name = file_names_string.substr(scan_start, length);
         file_names.push_back(file_name);
         scan_start = match_pos + 1;
         AssertFileAccessability(file_name, "r");
      } while (match_pos != string::npos);
      input_program_file_name = *file_names.begin();
   }

   { // There is a default language setting, i.e. it is always present
      const CCommandArgument *lang_argument = GetArgument(LANG);
      lang = lang_argument->GetVal()->AsKey();
      if (lang == AUTO) {
         string file_name = file_names[0];
         size_t last_dot_pos = file_name.find_last_of('.');
         if (last_dot_pos == string::npos)
            throw runtime_error("I can't guess the language from the file name, because it has no suffix");
         string suffix = file_name.substr(last_dot_pos + 1);
         const COptionParameter *parameter = lang_argument->GetParameter();
         const CVal *val = parameter->GetVal();
         const vector<CKeyword> &keywords = val->GetKeywordList();
         bool found_keyword = false;
         for (unsigned i=0; i<keywords.size(); ++i) {
            CKeyword keyword = keywords[i];
            string valid_keyword_name = keyword.GetName();
            if (suffix == valid_keyword_name) {
               lang = keyword.GetCode();
               found_keyword = true;
               break;
            }
         }
         if (!found_keyword) {
            throw runtime_error("I can't guess the language from the file name's suffix '" + suffix + "'.");
         }
      }
   }

   { // We can only link alf code
      if (file_names.size() > 1) {
         if (lang != ALF)
            throw runtime_error("We can only link alf code.");
      }
   }

   { // Start-function is an optional parameter - we are not able to perform any validity
     // check on it until parsing is done and a symbol table is present.
      const CCommandArgument *func_argument = GetArgument(FUNC);
      has_start_function_name = (func_argument != NULL);
      if (has_start_function_name) {
         start_function_name = func_argument->GetVal()->AsString();
      }
   }

   { // Annotations are optional - requires a value, so it is there?
      const CCommandArgument *annot_argument = GetArgument(ANNOT);
      if (annot_argument) {
         if (lang == ALF) {
            annotation_file_name = annot_argument->GetVal()->AsString();
            AssertFileAccessability(annotation_file_name, "r");
         } else {
            throw runtime_error("Annotation files are currently only implemented for ALF");
         }
      }
   }
   
   bool outputannots = false;
  
   { // Output annotation specifications are optional - requires a value, so it is there?
      const CCommandArgument *outp_annot_argument = GetArgument(OUTPANNOT);
      if (outp_annot_argument) {
         if (lang == ALF) {
            output_annotation_specification_file_name = outp_annot_argument->GetVal()->AsString();
            AssertFileAccessability(output_annotation_specification_file_name, "r");
            outputannots = true;
               // Save as global
            g_output_annotation_specification_file_name = output_annotation_specification_file_name;
         } else {
            throw runtime_error("Output annotation specifications are currently only implemented for ALF");
         }
      }
   }

   { // Merged output annotations are optional - requires a value, so it is there?
     const CCommandArgument *merge_argument = GetArgument(MERGED_OUTPUT);
     if (outputannots) {
        if (merge_argument) {
           int merged = merge_argument->GetVal()->AsKey();
           if (merged == YES) {
              g_merged_outp_annots = true;
           }  
           if (merged == NO) {
              g_merged_outp_annots = false;
           }
        } else {
              // Default
           g_merged_outp_annots = true;
        }
      } else {
         if (merge_argument) {
            throw runtime_error("The merged option is only valid when output annotation specifications are used");
         }
      }
   }

   // {
   //      // Print ast according to call graph is optional. 
   //      const CCommandArgument *pac_argument = GetArgument(PAC);
   //      print_cg_ast = (pac_argument != NULL && lang == ALF);
   //       if(print_cg_ast) {
   //         cg_ast_file_name = pac_argument->GetVal()->AsString();
   //         AssertFileAccessability(cg_ast_file_name, "w");
   //       }
   //    }

   {  // Extract the "remove duplicate exports" argument
      remove_dupl_exports = false;
      const CCommandArgument* rde_argument = GetArgument(RDE);
      if (rde_argument != 0) remove_dupl_exports = true;
   }

   {
     // Extract the "melmac_unmangle" argument
     melmac_unmangle = false;
     const CCommandArgument *unmangle_argument = GetArgument(UNMANGLE);
     if (unmangle_argument != 0) melmac_unmangle = true;
   }

//   { // Extract function call graph info is an optional parameter. The
//     // info to extract is a list of function names to the functions
//     // that we should extract call graph for, and then some info.
//      const CCommandArgument *extract_func_cg_info_argument = GetArgument(EFCGI);
//      extract_func_cg_info = (extract_func_cg_info_argument != NULL && lang == ALF);
//      if(extract_func_cg_info) {

//        // Check if we gave a directory to where the the resulting file name should be stored
//        // has been given. If not they will be storted where SWEET is run
//        const CCommandArgument *extract_func_names_dir_argument = GetArgument(EFCGI_DIR);
//        if(extract_func_names_dir_argument) {
//          extract_func_names_dir = extract_func_names_dir_argument->GetVal()->AsString();
//        }
//        else {
//          extract_func_names_dir = "";
//        }

//        // Extract the list of all functions to extract
//        string func_names_string = extract_func_cg_info_argument->GetVal()->AsString();
//        size_t scan_start = 0;
//        size_t match_pos;
//        do {
//          // Extract next function name from the list
//          match_pos = func_names_string.find(',', scan_start);
//          size_t length = match_pos - scan_start;
//          string func_name = func_names_string.substr(scan_start, length);
//          scan_start = match_pos + 1;

//          // Check that the fname.alf, fname.imports, and fname.exports
//          // can be written to
//          string func_name_alf_file = extract_func_names_dir + func_name + ".alf";
//          AssertFileAccessability(func_name_alf_file, "w");
//          string func_name_imports_file = extract_func_names_dir + func_name + ".imports";
//          AssertFileAccessability(func_name_imports_file, "w");
//          string func_name_exports_file = extract_func_names_dir + func_name + ".exports";
//          AssertFileAccessability(func_name_exports_file, "w");
//          string func_name_annot_file = extract_func_names_dir + func_name + ".template.annot";
//          AssertFileAccessability(func_name_annot_file, "w");

//          // Keep the function name for later
//          extract_func_names.push_back(func_name);
//        } while (match_pos != string::npos);
//      }
//    }

}

void
CCommandParse::
Execute(const CSession *session)
{
  DoTheParsing();
  
  DoPrinting(session);
   
     //   if(print_linked_ast) 
     //       PrintLinkedAST();
     
     //    if(print_imports)
     //      PrintImportsInAST();
     
     //    if(print_exports)
     //      PrintExportsInAST();

   BuildFlowGraphs();

   ast->CreateSymbolTable();

   if (!annotation_file_name.empty())
      ParseAnnotationFile();

   if (!output_annotation_specification_file_name.empty())
      ParseOutputAnnotationSpecificationFile();

   if (lang != CFG) {
     CheckForReturnStatementPresence();
     // CheckForNoUndefinedExpressionPresence();
   }

   PerformPointerAnalysis();

   BuildCallGraph();

   // Check if the ast should be printed according to reduced
   // call-graph. Basically, only the functions reachable from the
   // call graph's root function should be part of the printout.
   // if(print_cg_ast && lang == ALF)
   //   HandlePACOption(call_graph, cg_ast_file_name);

}

CCallGraph *
CCommandParse::
GetCallGraph()
{
   return call_graph;
}

CCallGraphNode *
CCommandParse::
GetStartNode()
{
   return start_node;
}


void CCommandParse::DoPrinting(const cmd::CSession *session)
{
  // Check if we should do any additional printing
  if(session->HasCommand(COption::PRINT)) {

    CCommandPrint *command_print = dynamic_cast<CCommandPrint *> (session->GetCommand(COption::PRINT));
    
    { // Print after file linkage is optional. 
      if(command_print->PrintASTAfterLinkage() && lang == ALF) {
        // Check if wqe should print to std:cout or to file
        ostream *out_stream;
        ofstream fs;
        if (!command_print->HasASTAfterLinkageFileName()) {
          out_stream = &cout;
        } else {

          fs.open(command_print->ASTAfterLinkageFileName().c_str(), ios::out);
          out_stream = &fs;
        }
        CTextBlock text_block;
        ast->AsText(&text_block);
        text_block.Show(*out_stream);
        if (fs.is_open()) {
          fs.close();
        }
      }
    }
    
    { // Print exports after linkage is optional 
      if(command_print->PrintExportsAfterLinkage() && lang == ALF) {
        // Check if we should print to std:cout or to file
        ostream *out_stream;
        ofstream fs;
        if (!command_print->HasExportsAfterLinkageFileName()) {
          out_stream = &cout;
        } else {
          fs.open(command_print->ExportsAfterLinkageFileName().c_str(), ios::out);
          out_stream = &fs;
        }
        // Write the exported symbols to a file
        (dynamic_cast<alf::CAlfTuple *>(ast))->PrintExportsAsText(out_stream);
        if (fs.is_open()) {
          fs.close();
        }
      }
    } 
    
    { if(command_print->PrintImportsAfterLinkage() && lang == ALF) {
      // Check if we should print to std:cout or to file
      ostream *out_stream;
      ofstream fs;
      if (!command_print->HasImportsAfterLinkageFileName()) {
        out_stream = &cout;
      } else {
        fs.open(command_print->ImportsAfterLinkageFileName().c_str(), ios::out);
        out_stream = &fs;
      }
      // Write the exported symbols to a file
      (dynamic_cast<alf::CAlfTuple *>(ast))->PrintImportsAsText(out_stream);
      if (fs.is_open()) {
        fs.close();
      }
      }
    }
  }
}
  

void CCommandParse::DoTheParsing()
{
   switch (lang)
   {
   case ALF:
      {
         vector<alf::CAlfTuple*> alf_asts;
         try
         {
            for (vector<string>::size_type f = 0; f < file_names.size(); ++f)
            {
               unique_ptr<alf::CAlfTuple> alf_ast(alf::CParser::ParseFile(file_names[f]));
               if (alf_ast.get() == 0)
                  throw runtime_error("Error while parsing ALF code.");
               alf::PostProcessParsing(alf_ast.get(), &file_names[f], f == 0, &melmac::Unmangle);
               alf_ast->CreateSymbolTable();
               SaveLabels(alf_ast.get());
               alf_asts.push_back(alf_ast.release());
            }
            alf::AlfLinker::Link(alf_asts, melmac_unmangle, remove_dupl_exports, link_log);
            ast = alf_asts.front();
         }
         catch (...)
         {
            for_each(alf_asts.begin(), alf_asts.end(), Deleter());
            throw;
         }
         return;
      }
   case CFG:
      {
         cfgs_in = fopen(file_names.front().c_str(), "rt");
         int error_code = cfgs_parse(&ast);
         fclose(cfgs_in);
         if (error_code) {
            throw runtime_error("Error while parsing CFG code.");
         }
         return;
      }
   }
}

void CCommandParse::SaveLabels(const alf::CAlfTuple *ast)
{
   auto &l = alf_files_to_labels[ast->GetSourceFileName()];
   assert(l.empty());
   const CSymTabBase *symtab = ast->GetSymTab();
   for (unsigned ki = 0, kn = symtab->KeyRange(); ki < kn; ++ki) {
      if (symtab->Exist(ki)) {
         const CSymTabEntry *entry = symtab->Lookup(ki);
         // save only statement labels, not function labels
         if (entry->IsCode() && !entry->IsFunction()) {
            l.insert(entry->Name());
         }
      }
   }
}

void CCommandParse::PrintLinkedAST() const
{
   // Write the ast of the linked ALF files to a file
   std::filebuf fb;
   fb.open(linked_file_name.c_str(), ios::out);
   ostream out_stream(&fb);
   CTextBlock text_block;
   ast->AsText(&text_block);
   text_block.Show(out_stream);
   fb.close();
}

void CCommandParse::PrintImportsInAST() const
{
  // We want to print ALF specific stuff
  alf::CAlfTuple * alf_tuple = dynamic_cast<alf::CAlfTuple *>(ast);
  assert(alf_tuple);

   // Write the imported symbols in the AST
  if(print_imports_file_name != "") {
    // Write the symbols to a file
    std::filebuf fb;
    fb.open(print_imports_file_name.c_str(), ios::out);
    ostream out_stream(&fb);
    alf_tuple->PrintImportsAsText(&out_stream);
    fb.close();
  }
  else {
    // Write the symbols to std::out
    alf_tuple->PrintImportsAsText(&std::cout);
  }
}

void CCommandParse::PrintExportsInAST() const
{
  // We want to print ALF specific stuff
  alf::CAlfTuple * alf_tuple = dynamic_cast<alf::CAlfTuple *>(ast);
  assert(alf_tuple);

   // Write the imported symbols in the AST
  if(print_exports_file_name != "") {
    // Write the symbols to a file
    std::filebuf fb;
    fb.open(print_exports_file_name.c_str(), ios::out);
    ostream out_stream(&fb);
    alf_tuple->PrintExportsAsText(&out_stream);
    fb.close();
  }
  else {
    // Write the symbols to std::out
    alf_tuple->PrintExportsAsText(&std::cout);
  }
}


void CCommandParse::BuildFlowGraphs()
{
   typedef vector<CGenericFunction*> FuncArray;
   FuncArray functions;
   ast->Functions(functions);
   for (FuncArray::const_iterator it = functions.begin(); it != functions.end(); ++it)
   {
      unique_ptr<CFlowGraph> flow_graph = (*it)->CreateFlowGraph();
      assert(flow_graph.get());
      if (!flow_graph->IsConnected()) {
         throw runtime_error("The flow graph of " + (*it)->PrettifiedName() + " is not connected.");
      }
      flow_graphs.push_back(flow_graph.release());
   }
}

void CCommandParse::ParseAnnotationFile()
{
   CReadALFAbsAnnotsAndCreateALFAbsAnnotStorage annot_algo;
   annot_storage = annot_algo.Run(annotation_file_name, dynamic_cast<alf::CAlfTuple*>(ast));
   if(!annot_storage) {
      throw runtime_error("Error while parsing abstract annotation file.");
   }
}

void CCommandParse::ParseOutputAnnotationSpecificationFile()
{
   CReadALFOutAnnotSpecsAndCreateALFOutAnnots out_annot_specs_algo;
   out_annot_specs_storage = out_annot_specs_algo.Run(output_annotation_specification_file_name, dynamic_cast<alf::CAlfTuple*>(ast));
   if(!out_annot_specs_storage) {
      throw runtime_error("Error while parsing output annotation specification file.");
   }
}
   
void CCommandParse::CheckForReturnStatementPresence()
{
   for (unsigned i=0; i<flow_graphs.size(); ++i) {
      CFlowGraph *flow_graph = flow_graphs[i];
      list<CFlowGraphNode*> exit_nodes;
      flow_graph->GetExitNodes(&exit_nodes);
      if (exit_nodes.size()==1 && (*exit_nodes.begin())->Stmt()->Type() != CGenericStmt::GS_RETURN) {
         throw runtime_error("Function " + flow_graph->Function()->Name() + " has no return statement.");
      }
      if (exit_nodes.size()==0) {
	throw runtime_error("Function " + flow_graph->Function()->Name() + " has no exit nodes (please add a return statement).");
      }
   }
}


void CCommandParse::CheckForNoUndefinedExpressionPresence()
{
  // Extract all generic nodes which are of undefined type in the AST
  alf::CAlfTreeFilter filter = alf::CAlfTreeFilter(dynamic_cast<const alf::CGenericNode*>(ast));
  const alf::CAlfTreeFilter::NodeList expr_nodes = filter.GetNodesOfType(alf::CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE);
  // Loop through all nodes and extract information for error message 
  bool has_undefined_expr = false;
  std::ostringstream outs;
  for(alf::CAlfTreeFilter::NodeList::const_iterator expr_node = expr_nodes.begin(); 
      expr_node != expr_nodes.end(); /* Intentionally empty */) {
    has_undefined_expr = true;
    // Get the statement it belongs to
    alf::CGenericNode* stmt_node = (*expr_node)->GetParent(alf::CGenericNode::TYPE_STMT);
    const alf::AStmt * stmt = dynamic_cast<const alf::AStmt *>(stmt_node);
    assert(stmt);
    // Get the function it belongs to
    alf::CGenericNode* func_node = (*expr_node)->GetParent(alf::CGenericNode::TYPE_FUNC_TUPLE);
    const alf::CFuncTuple * func_tuple = dynamic_cast<const alf::CFuncTuple *>(func_node);
    assert(func_tuple);
    // Get the source file the function belongs to
    const std::string * source_file = func_tuple->GetSourceFile();
    // Add to error message string
    outs << "Undefined expressions are currently not supported! " << endl
        << "Found in statement: " << endl << (*stmt) << endl
        << " function: " << func_tuple->Name() << " and file: " << (*source_file) << endl;
    // Step to next item
    ++expr_node;
    // Skip printing newline for last item
    if(expr_node != expr_nodes.end())
      outs << std::endl;
  }
  // Throw error if undefines was found 
  if(has_undefined_expr) {
    throw runtime_error(outs.str());
  }
}

void CCommandParse::PerformPointerAnalysis()
{
   if(!annot_storage) {
      pa = new CSteensgaardPA(ast->GetSteensgaardAnalysisBuilder(), ast, ast->GetSymTab());
      assert(pa);
   }
   else {
      // Add def uses pairs from annotations to pointer analysis
      set<pair<int,set<int> > > def_addresses_pairs;
      annot_storage->GetDefAddressesPairs(&def_addresses_pairs);
      pa = new CSteensgaardPA(ast->GetSteensgaardAnalysisBuilder(), ast, ast->GetSymTab(), &def_addresses_pairs);
   }
}

void CCommandParse::BuildCallGraph()
{ 
   call_graph = CreateCallGraph(flow_graphs, ast->GetSymTab(), *pa).release();
   if (call_graph->NrOfNodes() == 0) {
      throw runtime_error("The file is empty - nothing to analyze.");
   }
   call_graph->FindRoot();
   assert(call_graph->Root());
   ExtractCallGraphToUse();
}


void
CCommandParse::
ExtractCallGraphToUse()
{  
  //  cout << "CCommandParse::ExtractCallGraphToUse() \n";

  // Check what code to analyze, and cut out a call graph for that part
   list<CCallGraphNode*> entry_nodes;
   call_graph->GetEntryNodes(&entry_nodes);
   if (!start_function_name.empty()) {
      const CSymTabEntry *sym_tab_entry = ast->GetSymTab()->Lookup(start_function_name);
      if (sym_tab_entry == NULL || !sym_tab_entry->IsFunction()) {
         throw runtime_error("The given start function does not exist in this alf program.");
      }
      else
      {
         // We create a new graph containing the nodes reachable from the specified start node.
         // These nodes and the edges connecting them are cut out from the complete graph and
         // inserted into a new one. The remaining graph is destroyed, and only the new one is used.
         CCallGraph *new_call_graph = new CCallGraph();
         CGenericFunction *start_function = sym_tab_entry->GetCodeIdentifier()->GetFunction();
         start_node = call_graph->FindNodeOfFunction(start_function);
         list<CCallGraphNode*> component_to_analyze;
         call_graph->FindFlowComponent(start_node, &component_to_analyze);
         // These edges are those connected the cut out component to the rest (may be empty)
         list <CCallGraphEdgeAnnot*> removed_edges;
         call_graph->CutSubgraph(new_call_graph, &component_to_analyze, &removed_edges);

         for (list <CCallGraphEdgeAnnot*>::iterator edge_it=removed_edges.begin(); edge_it!=removed_edges.end(); ++edge_it) {
            delete *edge_it;
         }
         delete call_graph;

         call_graph = new_call_graph;

         // The list of flow graph may now contain pointers that are no longer valid, due
         // to the possibly deleded call graph nodes, so we need to re-generate the list that
         // we have an interface for.
         flow_graphs.clear();
         for (unsigned i=0; i<call_graph->NrOfNodes(); ++i) {
            CCallGraphNode *call_graph_node = call_graph->NodeAt(i);
            flow_graphs.push_back(call_graph_node->FlowGraph());
         }
      }
   } else {
      list<CCallGraphNode*> entry_nodes;
      call_graph->GetEntryNodes(&entry_nodes);
      if (entry_nodes.size() == 1) {
         start_node = *entry_nodes.begin();
      }
   }
}

// void CCommandParse::DoALFRDAnalysis()
// {
//   // Extract needed data 
//   CAlfTuple * alf_ast = dynamic_cast<CAlfTuple *>(ast);
//   ALFReachingDefinitionsAnalysisBuilder rd_analysis_builder;

//   // Construct the RD analysis graph
//   cout << "Builds RD analysis graph\n";
//   CSymTabBase * symtab = const_cast<CSymTabBase *>(ast->GetSymTab());
//   CSteensgaardPA * _pa = const_cast<CSteensgaardPA *>(pa);
//   ALFReachingDefinitionsAnalysis<CFlowGraphNode> * rd_analysis = 
//     rd_analysis_builder.Build(call_graph, annot_storage, alf_ast, _pa, symtab);

//   // Do the RD analysis
//   cout << "Performs RD analysis\n";
//   std::list<ReachingDefinitionsAnalysis::FIXPOINT_PASS> run_list;
//   run_list.push_back(ReachingDefinitionsAnalysis::NORMAL);
//   rd_analysis->Run(ReachingDefinitionsAnalysis::NODE_ORDERING, &run_list, ReachingDefinitionsAnalysis::FORWARD, NULL,
// 		   ReachingDefinitionsAnalysis::NONE, "", ReachingDefinitionsAnalysis::RESULT);
// }
 

void CCommandParse::HandlePACOption(CCallGraph *cg, std::string file_name) const
{
  // Get identifiers appearing in the given cal graph
  set<CSymTabBase::KeyType> referenced_ids;
  GetIdsPossiblyReferencedFromCallGraph(referenced_ids, cg);
  
  // Print the AST according to the derived identifiers
  PrintASTFiltered(dynamic_cast<alf::CAlfTuple *>(ast), referenced_ids, file_name);
}

// AST filter that only lets through declarations/definitions whose symbol table keys are
// included in some specific set of keys
class ReferencedIdFilter : public alf::ASTFilter
{
public:
  ReferencedIdFilter(const set<CSymTabBase::KeyType>& referenced_ids)
    : referenced_ids(referenced_ids) {}
  
  virtual bool IncludeFRefTuple(const alf::CFRefTuple& fref_tuple) const
  {
    return referenced_ids.find(fref_tuple.GetKey()) != referenced_ids.end();
  }
  
  virtual bool IncludeLRefTuple(const alf::CLRefTuple& lref_tuple) const
  {
    return referenced_ids.find(lref_tuple.GetKey()) != referenced_ids.end();
  }
  
  virtual bool IncludeAllocTuple(const alf::CAllocTuple& alloc_tuple) const
  {
    return referenced_ids.find(alloc_tuple.GetKey()) != referenced_ids.end();
  }
  
  virtual bool IncludeInitTuple(const alf::CInitTuple& init_tuple) const
  {
    return referenced_ids.find(init_tuple.GetRef()->GetKey()) != referenced_ids.end();
  }
  
  virtual bool IncludeFuncTuple(const alf::CFuncTuple& func_tuple) const
  {
    return referenced_ids.find(func_tuple.GetLabel()->GetLRef()->GetKey()) != referenced_ids.end();
  }
  
private:
  const set<CSymTabBase::KeyType>& referenced_ids;
};


void CCommandParse::
PrintASTFiltered(const alf::CAlfTuple * ast, set<CSymTabBase::KeyType> & referenced_ids, std::string file_name) const
{
  // Print the ALF AST using a ReferencedIdFilter to the specified file
  ofstream cg_ast_file(file_name.c_str());
  ReferencedIdFilter rif(referenced_ids);
  ast->PrintFiltered(cg_ast_file, 0, &rif);
}

// Use the internal call graph
void CCommandParse::GetIdsPossiblyReferencedFromCallGraph(set<CSymTabBase::KeyType>& out) const
{
  GetIdsPossiblyReferencedFromCallGraph(out, call_graph);
}
  

void CCommandParse::GetIdsPossiblyReferencedFromCallGraph(set<CSymTabBase::KeyType>& out, CCallGraph * cg) const
{
  std::list<CCallGraphNode *> nodes;
  for (unsigned i=0; i<call_graph->NrOfNodes(); ++i) {
    CCallGraphNode *call_graph_node = call_graph->NodeAt(i);
    nodes.push_back(call_graph_node);
  }
  GetIdsPossiblyReferencedFromCallGraphNodes(out, &nodes);
}

// Derive those ids in the AST that can be referenced from the
// argument call graph
void CCommandParse::GetIdsPossiblyReferencedFromCallGraphNodes(set<CSymTabBase::KeyType>& out,  
                                                               std::list<CCallGraphNode *> * cg_nodes) const
{
   using namespace alf;

   // AST node visitor that collects the symbol table keys of all referenced identifiers
   class ReferencedVarCollector : public CAlfTreeTraversor::INodeVisitor, public AlfNodeVisitor
   {
   public:
      virtual bool onBeginVisit(const CGenericNode* node) 
      {
         node->AcceptVisitor(this);
         return true;
      }
         
      virtual void onEndVisit(const CGenericNode* node) {}

      void GetSymbolTableKeys(set<CSymTabBase::KeyType>& out)
      {
         referenced_ids.swap(out);
      }

   private:

      // A set to keep track of all referenced ids
      set<CSymTabBase::KeyType> referenced_ids;

      // When visiting a fref tuple we insert its key in the set of referenced ids
      virtual void VisitFRefTuple(const CFRefTuple& fref_tuple) 
      {
         referenced_ids.insert(fref_tuple.GetKey());
      }

      // When visiting a lref tuple we insert its key in the set of referenced ids
      virtual void VisitLRefTuple(const CLRefTuple& lref_tuple) 
      {
         referenced_ids.insert(lref_tuple.GetKey());
      }

      virtual void Default(const CGenericNode&) {}
   };

   // Collect all identifiers referenced in the functions of the call graph
   CAlfTreeTraversor traversor;
   ReferencedVarCollector rvc;
   traversor.RegisterNodeVisitor(&rvc);
   for (std::list<CCallGraphNode *>::const_iterator n = cg_nodes->begin(); n != cg_nodes->end(); ++n)
   {
      traversor.BeginTraverse(dynamic_cast<const CGenericNode*>((*n)->Function()));
   }

   // Make the collection complete by adding the pointed-to identifiers of the
   // current collection, the pointed-to identifiers of those identifiers, etc.
   set<CSymTabBase::KeyType> referenced_ids;
   {
      set<CSymTabBase::KeyType> working_set;
      rvc.GetSymbolTableKeys(working_set);
      while (!working_set.empty())
      {
         // Collect the points-to sets of all variables in the working_set
         set<CSymTabBase::KeyType> acc_points_to_sets;
         for (set<CSymTabBase::KeyType>::iterator v = working_set.begin(); v != working_set.end(); ++v)
         {
            const set<CSymTabBase::KeyType>& var_pts = pa->GetPointsToVarsSet(*v);
            const set<CSymTabBase::KeyType>& func_pts = pa->GetPointsToFuncsSet(*v);
            const set<CSymTabBase::KeyType>& lab_pts = pa->GetPointsToLabelsSet(*v);
            acc_points_to_sets.insert(var_pts.begin(), var_pts.end());
            acc_points_to_sets.insert(func_pts.begin(), func_pts.end());
            acc_points_to_sets.insert(lab_pts.begin(), lab_pts.end());
         }
         // Mark the identifiers in the working_set as processed
         referenced_ids.insert(working_set.begin(), working_set.end());
         // Compute a new working_set for the next iteration that contains the identifiers of the
         // accumulated points-to sets that have not yet been processed
         working_set.clear();
         set_difference(acc_points_to_sets.begin(), acc_points_to_sets.end(), 
            referenced_ids.begin(), referenced_ids.end(), inserter(working_set, working_set.end()));
      }
   }

   out.swap(referenced_ids);
}

// void
// CCommandParse::
// ExtractFuncCGsAndInfo()
// {  
//   // Check what code to analyze, and cut out a call graph for that part
//   list<CCallGraphNode*> entry_nodes;
//   call_graph->GetEntryNodes(&entry_nodes);
//   // Check that all function names to extract are present in the ast
//   stringstream errornous_extract_func_names;
//   bool has_errornous_extract_func_names = false;
//   for(std::list<std::string>::iterator extract_func_name = extract_func_names.begin();
//       extract_func_name != extract_func_names.end(); extract_func_name++) {
//     const CSymTabEntry *sym_tab_entry = ast->GetSymTab()->Lookup(*extract_func_name);
//     if(sym_tab_entry == NULL || !sym_tab_entry->IsFunction()) {
//       errornous_extract_func_names << *extract_func_name << " ";
//       has_errornous_extract_func_names = true;
//     }
//   }
//   if(has_errornous_extract_func_names) {
//     string error_message = "The following start function(s) does not exist in this alf program: " +
//       errornous_extract_func_names.str();
//     throw runtime_error(error_message);
//   }
//   else {
//     alf::CAlfTuple * alf_ast = dynamic_cast<alf::CAlfTuple *>(ast);
//     // Create a temporary call graph for each func name
//     for(std::list<std::string>::iterator extract_func_name = extract_func_names.begin();
//         extract_func_name != extract_func_names.end(); extract_func_name++) {

//       // Derive teh nodes in teh call graph that are reachable from
//       // the node corresponding to the given start function.
//       const CSymTabEntry *sym_tab_entry = ast->GetSymTab()->Lookup(*extract_func_name);
//       CGenericFunction *start_function = sym_tab_entry->GetCodeIdentifier()->GetFunction();
//       CCallGraphNode *start_cg_node = call_graph->FindNodeOfFunction(start_function);
//       std::list<CCallGraphNode*> reachable_call_graph_nodes;
//       call_graph->FindFlowComponent(start_cg_node, &reachable_call_graph_nodes);

//       // Derive all the ids of things in the AST that can be
//       // referenced by the temporary call graph
//       set<CSymTabBase::KeyType> referenced_ids;
//       GetIdsPossiblyReferencedFromCallGraphNodes(referenced_ids, &reachable_call_graph_nodes);

//       { // Print reduced AST to file
//         string extract_file_name = extract_func_names_dir + (*extract_func_name) + ".alf";
//         cout << "  Prints reduced AST to: " << extract_file_name << endl;
//         PrintASTFiltered(alf_ast, referenced_ids, extract_file_name);
//       }
      
//       { // Print imports of reduced AST to file
//         string import_file_name = extract_func_names_dir + (*extract_func_name) + ".imports";
//         cout << "  Prints imports for reduced AST to: " << import_file_name << endl;
//         PrintImportsAsTextFiltered(alf_ast, referenced_ids, import_file_name);
//       }

//       { // Print exports of reduced AST to file
//         string export_file_name = extract_func_names_dir + (*extract_func_name) + ".exports";
//         cout << "  Prints exports for reduced AST to: " << export_file_name << endl;
//         PrintExportsAsTextFiltered(alf_ast, referenced_ids, export_file_name);
//       }

//        { // Print annotation template for undefs of reduced AST to file
//          string annot_file_name = extract_func_names_dir + (*extract_func_name) + ".template.annot";
//          cout << "  Prints annot template for reduced AST to: " << annot_file_name << endl;
//          std::vector<CGenericFunction *> reachable_funcs;
//          for(std::list<CCallGraphNode*>::iterator cg_node = reachable_call_graph_nodes.begin();
//              cg_node != reachable_call_graph_nodes.end(); cg_node++) {
//            reachable_funcs.push_back((*cg_node)->Function());
//          }
//          PrintAnnotationTemplate(alf_ast, pa, flow_graphs, referenced_ids, &reachable_funcs, annot_file_name);
//        }
//     }
//   }
// }

// AST filter that only lets through declarations/definitions whose symbol table keys are
// included in some specific set of keys
class LRefFRefReferencedIdFilter : public alf::ASTFilter
{
public:
  LRefFRefReferencedIdFilter(const set<CSymTabBase::KeyType>& referenced_ids)
    : referenced_ids(referenced_ids) {}
  
  virtual bool IncludeFRefTuple(const alf::CFRefTuple& fref_tuple) const
  {
    return referenced_ids.find(fref_tuple.GetKey()) != referenced_ids.end();
  }
  
  virtual bool IncludeLRefTuple(const alf::CLRefTuple& lref_tuple) const
  {
    return referenced_ids.find(lref_tuple.GetKey()) != referenced_ids.end();
  }
  
  virtual bool IncludeAllocTuple(const alf::CAllocTuple& alloc_tuple) const 
  {
    return false;
  }
  
  virtual bool IncludeInitTuple(const alf::CInitTuple& init_tuple) const
  {
    return false;
  }
  
  virtual bool IncludeFuncTuple(const alf::CFuncTuple& func_tuple) const
  {
    return false;
  }

private:
  const set<CSymTabBase::KeyType>& referenced_ids;
};



class InitReferencedIdFilter : public alf::ASTFilter
{
public:
  InitReferencedIdFilter(const set<CSymTabBase::KeyType>& referenced_ids)
    : referenced_ids(referenced_ids) {}
  
  virtual bool IncludeFRefTuple(const alf::CFRefTuple& fref_tuple) const
  {
    return false;
  }
  
  virtual bool IncludeLRefTuple(const alf::CLRefTuple& lref_tuple) const
  {
    return false;
  }
  
  virtual bool IncludeAllocTuple(const alf::CAllocTuple& alloc_tuple) const 
  {
    return false;
  }
  
  virtual bool IncludeInitTuple(const alf::CInitTuple& init_tuple) const
  {
    return referenced_ids.find(init_tuple.GetRef()->GetKey()) != referenced_ids.end();
  }
  
  virtual bool IncludeFuncTuple(const alf::CFuncTuple& func_tuple) const
  {
    return false;
  }

private:
  const set<CSymTabBase::KeyType>& referenced_ids;
};



void CCommandParse::
PrintImportsAsTextFiltered(const alf::CAlfTuple * ast, set<CSymTabBase::KeyType> & referenced_ids, std::string file_name) const
{
  // Print the imports using the derived filter to the specified file
  ofstream is(file_name.c_str());
  LRefFRefReferencedIdFilter filter(referenced_ids);
  ast->PrintImportsAsText(&is, &filter);
}

unsigned int CCommandParse::
GetNrOfLRefImportsFiltered(const alf::CAlfTuple * ast, set<CSymTabBase::KeyType> & referenced_ids) const
{
  LRefFRefReferencedIdFilter filter(referenced_ids);

  // Get the number of imports using the derived filter 
  unsigned int nr_of_lrefs = 0;
  const alf::CLRefList* lrefs = ast->GetImports()->GetLRefList();
  for(alf::CLRefList::const_list_iterator lref = lrefs->ConstIterator(); 
      lref != lrefs->InvalidIterator(); lref++) {
    if(filter.IncludeLRefTuple(**lref)) {
      nr_of_lrefs++;
    }
  }
  return nr_of_lrefs;    
}

unsigned int CCommandParse::
GetNrOfFRefImportsFiltered(const alf::CAlfTuple * ast, set<CSymTabBase::KeyType> & referenced_ids) const
{
  LRefFRefReferencedIdFilter filter(referenced_ids);

  // Get the number of imports using the derived filter 
  unsigned int nr_of_frefs = 0;
  const alf::CFRefList* frefs = ast->GetImports()->GetFRefList();
  for(alf::CFRefList::const_list_iterator fref = frefs->ConstIterator(); 
      fref != frefs->InvalidIterator(); fref++) {
    if(filter.IncludeFRefTuple(**fref)) {
      nr_of_frefs++;
    }
  }
  return nr_of_frefs;    
}

void CCommandParse::
PrintExportsAsTextFiltered(const alf::CAlfTuple * ast, set<CSymTabBase::KeyType> & referenced_ids, std::string file_name) const
{
  // Print the exports using the derived filter to the specified file
  ofstream is(file_name.c_str());
  LRefFRefReferencedIdFilter filter(referenced_ids);
  ast->PrintExportsAsText(&is, &filter);
}

unsigned int CCommandParse::
GetNrOfVolatileInitsFiltered(const alf::CAlfTuple * ast, set<CSymTabBase::KeyType> & referenced_ids) const
{
  // Get the number of volatile inits using the derived filter 
  InitReferencedIdFilter filter(referenced_ids);
  return ast->GetInits()->GetNrOfVolatileInits(&filter);
}


unsigned int CCommandParse::
GetNrOfAddrVolatileInitsFiltered(const alf::CAlfTuple * ast, set<CSymTabBase::KeyType> & referenced_ids) const
{
  // Get the number of volatile inits using the derived filter 
  InitReferencedIdFilter filter(referenced_ids);
  return ast->GetInits()->GetNrOfAddrVolatileInits(&filter);
}


void 
CCommandParse::
PrintAnnotationTemplate(const alf::CAlfTuple * ast, const CSteensgaardPA *pa, 
                        const std::vector<CFlowGraph*> * flow_graphs,
                        std::set<CSymTabBase::KeyType> & referenced_ids, 
                        std::vector<CGenericFunction *> * reached_funcs, 
                        std::string file_name) const
{
  // Extract all the undefined references in reached function into error collection
  const CSymTabBase *symtab_base = ast->GetSymTab();
  StaticAlfErrorCollection undefs;
  CheckUnresolvedReferences(*(const_cast<alf::CAlfTuple *>(ast)), *reached_funcs, symtab_base, undefs);

  // Create a filter for those undefs that we should print
  LRefFRefReferencedIdFilter filter(referenced_ids);

  // Create an annotation template collection
  alf::AbstractAnnotationTemplates annots(undefs, pa, symtab_base, *flow_graphs, &filter);

  // Print the generated template annotations for undefs to file
  ofstream fs(file_name.c_str());
  annots.Print(fs);
  annots.PrintFailedUndefs(fs);
  fs.close();
}

// To print annotation templates in new format
void 
CCommandParse::
PrintAnnotationTemplate(const alf::CAlfTuple * ast, std::string file_name, 
                        CGenericFunction * start_func, std::set<CSymTabBase::KeyType> * referenced_ids) const
{
  ofstream is(file_name.c_str());
  if(referenced_ids) {
    // Print imports with filter 
    LRefFRefReferencedIdFilter filter(*referenced_ids);
    ast->PrintImportsAsAnnotTemplate(&is, &filter);
    // Maybe print start function argument annotations
    if(start_func)
      ast->PrintStartFunctionArgumentsAsAnnotTemplate(start_func, &is);
    // Print volatiles with filter
    ast->PrintVolatilesAsAnnotTemplate(&is, &filter);
  }
  else {
    // Print imports without filter
    ast->PrintImportsAsAnnotTemplate(&is);
    // Maybe print start function argument annotations
    if(start_func)
      ast->PrintStartFunctionArgumentsAsAnnotTemplate(start_func, &is);
    // Print volatiles without filter
    ast->PrintVolatilesAsAnnotTemplate(&is);
  }
  
}

}
