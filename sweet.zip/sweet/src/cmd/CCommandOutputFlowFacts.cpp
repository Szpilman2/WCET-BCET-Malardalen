// $Id $

#include "CCommandOutputFlowFacts.h"
#include "CCommandAE.h"
#include "CCommandParse.h"
#include "CCommandLoadMap.h"
#include "CSession.h"
#include "ae/AlfAbstractExecution.h"
#include "ae/DeriveContextSensitiveValidAtEntryOfFlowFacts.h"
#include "ae/CCollector.h"
#include "program/CGenericFunction.h"
#include "flow_facts/AisIntermediate.h"
#include "flow_facts/RapitaIntermediate.h"
#include "flow_facts/CContextSensitiveValidAtEntryOfFlowFact.h"
// #include "flow_facts/FlowFactToRapita.h"
#include "graphs/scopes/CScopeGraph.h"
#include "graphs/scopes/CScope.h"
#include "tools/melmac.h"
#include "flow_facts/RapitaIntermediate.h"
#include "macros.h"
#include <stdexcept>
#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

namespace cmd {

CCommandOutputFlowFacts::
CCommandOutputFlowFacts()
{
  _generate_rapita_ffs = false;
}

CCommandOutputFlowFacts::
~CCommandOutputFlowFacts()
{
  
}

void
CCommandOutputFlowFacts::
Validate(const CSession *session)
{
   // Check that if the csl parameter has been given it is either the
   // keyword full or an integer >= 0.
   {
     _cs_length = 0;
     const CCommandArgument *cs_length_argument = GetArgument(CS_LENGTH);
     if (cs_length_argument == NULL) {
       // If no cs_length is given as argument we should do a zero
       // context sensitive analysis.
       _cs_length = 0;
     }
     else {
       string s = cs_length_argument->GetVal()->AsString();
       if(s == "full") {
         // We should acctually have the longest path from the root to
         // a leaf scope oin the scope graph. However, since the scope
         // graph not yet has been generated we will use the largest 
         // unsigned integer value. 
         _cs_length = (unsigned int) -1;
       }
       else {
         // We should try to convert the string value to an unsigned integer
         bool is_unsigned_decimal_number = true;
         for(unsigned int i = 0; i < s.size(); i++) {
           char c = s[i];
           if(c < '0' || c > '9') {
             is_unsigned_decimal_number = false;
             break;
           }
         }
         int temp_cs_length = atoi(s.c_str());
         if(temp_cs_length < 0 || !is_unsigned_decimal_number) { 
           throw runtime_error("Value of csl argument should either be keyword 'full' or a decimal integer >= 0.");
         }
         _cs_length = temp_cs_length;
       }
     }
   }

   {
      // This  input may contain various information useful for variaous analyses
      // thus connected to the parse command
      const CCommandArgument *lang_argument = GetArgument(LANG);
      const CCommandVal *lang_val = lang_argument->GetVal();
      vector <int> lang_keys = lang_val->AsKeySet();
      for (unsigned i=0; i<lang_keys.size(); ++i)
      {
         int lang_key = lang_keys[i];
         if(lang_key == RAPITA) {
           _generate_rapita_ffs = true;
         }
      }
   }

   // {
   //       // If Rapita format is required we should check that the mapping file is correct
   //       const CCommandArgument *lang_argument = GetArgument(LANG);
   //       const CCommandVal *lang_val = lang_argument->GetVal();
   //       vector <int> lang_keys = lang_val->AsKeySet();
   //       for (unsigned i=0; i<lang_keys.size(); ++i) {
   //         int lang_key = lang_keys[i];
   //         if(lang_key == RAPITA) {
   //           cout << "RAPITA*****\n";
   //           CCommandLoadMap *command_load_map =  dynamic_cast<CCommandLoadMap*>(session->GetCommand(COption::LOAD_MAP));
   //           if(command_load_map) {
   //             cout << "RAPITA has map\n";
   //             CSourceLoader * sl = command_load_map->GetSourceLoader();
   //             cout << "RAPITA has sl " << (sl != NULL) << "\n";
   //             CCommandParse *command_parse = dynamic_cast<CCommandParse*>(session->GetCommand(COption::PARSE));
   //             const std::vector<CFlowGraph*> & flow_graphs = command_parse->GetFlowGraphs();
   //             cout << "RAPITA nr of cfgs: " << flow_graphs.size() << endl;
   //             RapitaIntermediate ri(&flow_graphs, sl);
   //             bool has_c_cource_info_for_all_rapita_path_nodes = sl->HasCSourceInfoForAllNodes(flow_graphs, true, &ri);
   //             if(!has_c_cource_info_for_all_rapita_path_nodes) {
   //               throw runtime_error("Errornous mapping file(s)");
   //             }
   //           }
   //         }
   //       }
   // }

   ValidateFiles(session, FILE_NAME, LANG, "", STDOUT);
}

void
CCommandOutputFlowFacts::
Execute(const CSession *session)
{
   // Get the scope graph
   CCommandAE *command_ae = dynamic_cast<CCommandAE *> (session->GetCommand(COption::AE));
   CScopeGraph *scope_graph = command_ae->GetScopeGraph();
   CCommandParse *command_parse = dynamic_cast<CCommandParse*> (session->GetCommand(COption::PARSE));

   // Verify input code constraints
   if(scope_graph->HasRecursiveScopes()) {
      throw runtime_error("Error, cannot derive context sensitive valid at entry of flow facts "
            "for code containing recursion.");
   }

   // Get the scope to collectors maps
   const std::vector<std::map<CScope *, CCollector *> *> * sc_maps = command_ae->GetSCMaps();

   // Generate context senstive valid at entry flow flow facts
   std::vector<CContextSensitiveValidAtEntryOfFlowFact *> ffs;
   DeriveContextSensitiveValidAtEntryOfFlowFacts(sc_maps, _cs_length, &ffs);

   // Try to load map file
   CSourceLoader *source_loader = NULL;
   if(session->HasCommand(COption::LOAD_MAP)) {
      CCommandLoadMap *load_map_command =
         dynamic_cast<CCommandLoadMap *> (session->GetCommand(COption::LOAD_MAP));
      source_loader = load_map_command->GetSourceLoader();
   }

   string input_file_name = command_parse->GetProgramFileName();
   for (unsigned i=0; i<output_settings.outputs.size(); ++i) {
      OutputSettings::Output output = output_settings.outputs[i];
      ostream *out_stream;
      ofstream fs;
      if (output.file_name.empty()) {
         out_stream = &cout;
      } else {
         fs.open(output.file_name.c_str(), ios::out);
         out_stream = &fs;
      }
      switch (output.key) {
         case SCOPES: {
            const std::vector<CCollector *> *collectors = command_ae->GetCollectors();
            for (vector<CCollector *>::const_iterator c = collectors->begin(); c != collectors->end(); ++c) {
               (*c)->GenerateFlowFacts();
            }
            scope_graph->PrintFlowFactFile(*out_stream);
            break;
         }
         case FF: {
            PrintCSVAEOFFs(&ffs, *out_stream);
            break;
         }
         case RAPITA: {
            // Extract flow graphs
            const vector<CFlowGraph*> &flow_graphs = command_parse->GetFlowGraphs();

            // Check if ffs are based on traces
            CCommandAE *command_ae = dynamic_cast<CCommandAE *> (session->GetCommand(COption::AE));
            const AESettings *ae_settings = command_ae->GetAESettings();
            bool used_traces = false;
            if(ae_settings->rtf)
              used_traces = true;

            // Create and update Rapita intermediate 
            RapitaIntermediate rapita_intermediate(&flow_graphs, source_loader, used_traces);
            UpdateRapitaIntermediateWithContextSensitiveValidAtEntryOfFlowFacts(&ffs, &rapita_intermediate);

            // Print result to file.rapita
            rapita_intermediate.PrintAsRapitaFlowFacts(*out_stream, source_loader);
            break;
         }

         case TCD: {
            scope_graph->PrintTCD(*out_stream);
            break;
         }
         case AIS: {
            // Check if ffs are based on traces
            CCommandAE *command_ae = dynamic_cast<CCommandAE *> (session->GetCommand(COption::AE));
            const AESettings *ae_settings = command_ae->GetAESettings();
            bool used_traces = false;
            if(ae_settings->rtf)
              used_traces = true;
            // Get the root function name
            std::string root_func_name = scope_graph->Root()->Function()->Name();
            // Generate aiS intermediate from ffs
            AisIntermediate ais_intermediate(root_func_name, used_traces);
            UpdateAisIntermediateWithContextSensitiveValidAtEntryOfFlowFacts(&ffs, &ais_intermediate);
            // Print result to file.ais
            ais_intermediate.PrintAsAisFlowFacts(*out_stream, source_loader);
            break;
         }
      }
      if (fs.is_open()) {
         fs.close();
      }
   }

   for_each(ffs.begin(), ffs.end(), Deleter());
}

void
CCommandOutputFlowFacts::
PrintCSVAEOFFs(std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs, std::ostream &ff_stream)
{
   for(vector<CContextSensitiveValidAtEntryOfFlowFact *>::iterator ff = ffs->begin();
         ff != ffs->end(); ++ff)
   {
      ff_stream << **ff << endl;
   }
}

}
