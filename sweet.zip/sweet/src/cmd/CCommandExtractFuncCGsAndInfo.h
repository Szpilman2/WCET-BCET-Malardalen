#ifndef COMMAND_EXTRACT_FUNC_CGS_AND_INFO_H_INCLUDED
#define COMMAND_EXTRACT_FUNC_CGS_AND_INFO_H_INCLUDED

#include "CCommand.h"
#include "symtab/CSymTabBase.h"
#include <set>
#include <list>

namespace cmd {

// Help command for extracting information for a gigven list of file names.
// Additionally, it also reads in a directory to where the resulting files should 
// be stored.
class CCommandExtractFuncCGsAndInfo : public CCommand
{
public:

  typedef enum KEY { PRINT, ALL, ALF, IMPORTS, EXPORTS, ANNOT_TEMPLATE, MAP, INFO, DIR } KEY;

  CCommandExtractFuncCGsAndInfo() {};
  ~CCommandExtractFuncCGsAndInfo() {};

  void Validate(const CSession *session);
  void Execute(const CSession *session);

  CCommand *Copy() const { return new CCommandExtractFuncCGsAndInfo(*this); }

private:

  // The name of the functions that should be extracted
  std::list<std::string> _extract_func_names;

  // The directory path to where all files will be printed.
  std::string _extract_dir;

  // The type of files that should be extracted
  bool _extract_alf;
  bool _extract_imports;
  bool _extract_exports;
  bool _extract_annot_template;
  bool _extract_map;
  bool _extract_info;
  
};

}

#endif
  
