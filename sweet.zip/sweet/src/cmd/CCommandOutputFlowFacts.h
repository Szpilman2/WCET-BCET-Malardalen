// $Id $

#ifndef CCOMMAND_OUTPUT_FLOW_FACTS_H_INCLUDED
#define CCOMMAND_OUTPUT_FLOW_FACTS_H_INCLUDED

#include "CCommand.h"
#include "flow_facts/CFlowFact.h"

class CContextSensitiveValidAtEntryOfFlowFact;

namespace cmd {

class CSession;

/** \class CCommandOutputFlowFacts
   Outputs flow facts on the desired form(s) to file(s). The information
   collected during abstract execution is first extracted and to the flow
   fact format "context-sensitive valid-at-entry-of". In case needed it is
   then transformed to some other format(s) before printed.
*/
class CCommandOutputFlowFacts : public CCommandPrintFile
{
public:
  CCommandOutputFlowFacts();
   ~CCommandOutputFlowFacts();

   typedef enum KEY { CS_LENGTH, FILE_NAME, STDOUT, LANG, FF, SCOPES, TCD, RAPITA, AIS } KEY;

   /** Checks if a valid file name exist, thows an exception if not. */
   void Validate(const CSession *session);

   /** Print file. */
   void Execute(const CSession *session);

   CCommand *Copy() const { return new CCommandOutputFlowFacts(*this); }

   bool GenerateRapitaFFs() { return _generate_rapita_ffs; }

private:
   void PrintCSVAEOFFs(std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs, std::ostream &ff_stream);
   unsigned int _cs_length;
   bool _generate_rapita_ffs;
};

}

#endif
