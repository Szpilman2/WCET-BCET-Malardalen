// $Id $

#include "cmd/CCommandPDG.h"
#include "cmd/CCommandParse.h"
#include "cmd/CCommandRD.h"
#include "cmd/CCommandDU.h"
#include "cmd/CSession.h"
#include "program/alf/CAlfTuple.h"
#include "dfa/ALFDefsAndUsesAnalysis.h"
#include "alf_slicing/ALFExtendedProgramControlFlowGraph.h"
#include "alf_slicing/ALFExtendedProgramDependencyGraph.h"
#include "alf_slicing/ALFExtendedProgramGraphNode.h"
#include "alf_slicing/ALFSlicing.h"
#include "symtab/CSymTabBase.h"
#include "symtab/CSymTabIdentifier.h"
#include "dfa/DataFlowAnalysis.inl"

#include <map>
#include <set>

using namespace std;

namespace cmd {

CCommandPDG::
CCommandPDG()
  : _pcdg(NULL), _pddg(NULL), _pdg(NULL)
{
  // Do nothing
}

CCommandPDG::
~CCommandPDG()
{
  if(_pcdg) delete _pcdg;
  if(_pddg) delete _pddg;
  if(_pdg) delete _pdg;
}
 
CCommand *
CCommandPDG::
Copy() const
{
   assert(_pcdg==NULL);
   assert(_pddg==NULL);
   assert(_pdg==NULL);
   return new CCommandPDG(*this);
}

void
CCommandPDG::
Validate(const CSession *session)
{
  // Nothing need to be done  
}

void
CCommandPDG::
Execute(const CSession *session)
{
  // We need the symbol table for the ALF ast 
  CCommandParse *command_parse = dynamic_cast<CCommandParse *>(session->GetCommand(COption::PARSE));
  CGenericProgram *generic_ast = command_parse->GetAst();
  const alf::CAlfTuple * c_alf_ast = dynamic_cast<const alf::CAlfTuple *>(generic_ast); 
  alf::CAlfTuple * alf_ast = const_cast<alf::CAlfTuple*>(c_alf_ast);
  CSymTabBase * symtab = const_cast<CSymTabBase *>(alf_ast->GetSymTab());

  // We need the RD analysis
  CCommandRD *command_rd = dynamic_cast<CCommandRD *> (session->GetCommand(COption::RD));
  ALFReachingDefinitionsAnalysis * rd = command_rd->GetRDAnalysis();
  assert(rd->HasMadeRun());

  // We also get the epcfg from the RD analysis
  ALFExtendedProgramControlFlowGraph * epcfg = command_rd->GetPCFG();

  // We need the def use analysis
  CCommandDU *command_du = dynamic_cast<CCommandDU *> (session->GetCommand(COption::DU));
  ALFDefsAndUsesAnalysis * du = command_du->GetDUAnalysis();

  assert(symtab);
  assert(epcfg);
  assert(rd);
  assert(du);

  // -------------------------------------------------------
  // Do PDG analysis 
  // -------------------------------------------------------

  // Next, do the EPDG graph derivation
  ALFExtendedProgramDependencyGraphBuilder epdg_builder;
  _pdg = epdg_builder.Build(epcfg, rd, du, symtab, &_pcdg, &_pddg);

}

} // end namespace cmd
