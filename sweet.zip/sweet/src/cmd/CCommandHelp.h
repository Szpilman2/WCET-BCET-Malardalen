// $Id $

#ifndef CCOMMAND_HELP_H_INCLUDED
#define CCOMMAND_HELP_H_INCLUDED

#include "CCommand.h"

namespace cmd {

class CSession;

/** \class CCommandHelp
   Shows a help message.
*/
class CCommandHelp : public CCommand
{
public:

  typedef enum KEY { HELP, TOPIC, OPTION, ANNOT, FFG, TRACE, USE_CSI } KEY;

  void Validate(const CSession *session) { }

  /** Print the help information in a console. */
  void Execute(const CSession *session);

  CCommand *Copy() const { return new CCommandHelp(*this); }

private:
};

}

#endif
