// $Id $

#include "CCommandCreateTimingForAlfBasicBlocksUsingCostLookupTable.h"
#include "CCommandParse.h"
#include "CSession.h"
#include "tcalc/DeriveTimingForAlfBasicBlocksUsingCostLookupTable.h"
#include <vector>

using namespace std;

namespace cmd {

void
CCommandCreateTimingForAlfBasicBlocksUsingCostLookupTable::
Validate(const CSession *session)
{
  // Check if there is a cost lookup table file given
  const CCommandArgument *clt_argument = GetArgument(CLT);
  if (clt_argument) {
    clt_filename = clt_argument->GetVal()->AsString();
    AssertFileAccessability(clt_filename, "r");
  } else {
    clt_filename = "";
  }

  // Check if there is a timing database file given
  const CCommandArgument *tdb_argument = GetArgument(TDB);
  if (tdb_argument) {
    tdb_filename = tdb_argument->GetVal()->AsString();
    AssertFileAccessability(tdb_filename, "w");
  } else {
    tdb_filename = "";
  }
}
  
void
CCommandCreateTimingForAlfBasicBlocksUsingCostLookupTable::
Execute(const CSession *session)
{
  // Get the flow graphs from the parsing command
  CCommandParse *parse_command = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
  const vector<CFlowGraph*> &flow_graphs = parse_command->GetFlowGraphs();
  
  // Check if we have filenames or not
  if(clt_filename == "" && tdb_filename == "") {
    // Read default time cost lookup table values and timing for bbs to std out
    DeriveTimingForAlfBasicBlocksUsingDefaultCostLookupTable(&flow_graphs);
  }
  else if(clt_filename == "" && tdb_filename != "") {
    // Read default time cost lookup table values and timing for bbs to tdb_filename
    DeriveTimingForAlfBasicBlocksUsingDefaultCostLookupTable(&flow_graphs, tdb_filename);
  }
  else if(clt_filename != "" && tdb_filename == "") {
    // Read time cost lookup table values from file and timing for bbs to std out
    DeriveTimingForAlfBasicBlocksUsingCostLookupTable(&flow_graphs, clt_filename);
  }
  else {
    // Read cost lookup table from second argument file and write result to third argument file
    DeriveTimingForAlfBasicBlocksUsingCostLookupTable(&flow_graphs, clt_filename, tdb_filename);
  }
}

}
