// $Id $
 
#include "cmd/CCommandRD.h"
#include "cmd/CCommandDU.h"
#include "cmd/CCommandParse.h"
#include "cmd/CSession.h"
#include "program/alf/CAlfTuple.h"
#include "graphs/scopes/CScopeGraph.h"
#include "graphs/scopes/CreateScopes.h"
#include "graphs/ecfg/CECFG.h"
#include "rd/ALFReachingDefinitionsAnalysisBuilder.h"
#include "dfa/DataFlowAnalysis.inl"
#include "graphs/tools/Dominance.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/cfg/CFlowGraphEdgeAnnot.h"

#include "dfa/ALFDefsAndUsesAnalysis.h"
#include "program/alf/AStmt.h"
#include "program/alf/CAlfTuple.h"
#include "alf_slicing/ALFExtendedProgramControlFlowGraph.h"
#include "alf_slicing/ALFExtendedProgramDependencyGraph.h"
#include "alf_slicing/ALFExtendedProgramGraphNode.h"

#include <map> 
#include <set>

using namespace std;

namespace cmd {

CCommandRD::
CCommandRD()
  : _rd_settings(NULL), _rd(NULL), _pcfg(NULL), _du(NULL)
{
  // Do nothing
}

CCommandRD::
~CCommandRD()
{
   if(_rd_settings) delete _rd_settings;
   if(_rd) delete _rd;
   if(_du) delete _du;
   if(_pcfg) delete _pcfg;

}
 
CCommand *
CCommandRD::
Copy() const
{
   assert(_rd_settings==NULL);
   assert(_rd==NULL);
   assert(_du==NULL);
   assert(_pcfg==NULL);
   return new CCommandRD(*this);
}

void
CCommandRD::
Validate(const CSession *session)
{
  // Create the settings data structure
  _rd_settings = new RDSettings();
  
  // ---------------------------------
  // Handle analysis type
  // ---------------------------------
  {
    const CCommandArgument *analysis_type_argument = GetArgument(ANALYSIS_TYPE);
    switch (analysis_type_argument->GetVal()->AsKey()) {
    case NODE_ORDERING:
      _rd_settings->_analysis_type = ReachingDefinitionsAnalysis::NODE_ORDERING;
      break;
    case WORK_LIST:
      _rd_settings->_analysis_type = ReachingDefinitionsAnalysis::WORK_LIST;
      break;
    case CHAOTIC:
      _rd_settings->_analysis_type = ReachingDefinitionsAnalysis::CHAOTIC;
      break;
    }
  }
  
  // ---------------------------------
  // Handle printing
  // ---------------------------------
  {
    _rd_settings->_print_specification = ReachingDefinitionsAnalysis::NONE;
    const CCommandArgument *print_argument = GetArgument(PRINT_ANALYSIS_RESULT);
    if(print_argument) {
      switch (print_argument->GetVal()->AsKey()) {
      case RESULT:
	_rd_settings->_print_specification = ReachingDefinitionsAnalysis::RESULT;
	break;
      case ITERATION:
	_rd_settings->_print_specification = ReachingDefinitionsAnalysis::ITERATION;
	break;
      }
    }
  }
  
  // ---------------------------------
  // Handle drawing
  // ---------------------------------
  {
    _rd_settings->_draw_specification = ReachingDefinitionsAnalysis::NONE;
    const CCommandArgument *draw_analysis_argument = GetArgument(DRAW_ANALYSIS_RESULT);
    if(draw_analysis_argument) {
      switch (draw_analysis_argument->GetVal()->AsKey()) {
      case RESULT:
	_rd_settings->_draw_specification = ReachingDefinitionsAnalysis::RESULT;
	break;
      case ITERATION:
	_rd_settings->_draw_specification = ReachingDefinitionsAnalysis::ITERATION;
	break;
      }
    }
  }
}

void
CCommandRD::
Execute(const CSession *session)
{
  // We need the ALF ast (constness removed since it will take a lot
  // of time adding const everywhere in the RD code)
  CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
  CGenericProgram *generic_ast = command_parse->GetAst();
  const alf::CAlfTuple * c_alf_ast = dynamic_cast<const alf::CAlfTuple *>(generic_ast); 
  alf::CAlfTuple * alf_ast = const_cast<alf::CAlfTuple*>(c_alf_ast);

  // We need abstract annotations if they exist
  CALFAbsAnnotStorage * annots = command_parse->GetAnnotStorage();

  // We need the call graph
  CCallGraph *cg = command_parse->GetCallGraph();

  // We need the def use analysis
  CCommandDU *command_du = dynamic_cast<CCommandDU *> (session->GetCommand(COption::DU));
  ALFDefsAndUsesAnalysis * du = command_du->GetDUAnalysis();

  assert(alf_ast);
  assert(cg);
  assert(du);

  // -------------------------------------------------------
  // Do RD analysis 
  // -------------------------------------------------------

  // Create extended control flow graph
  ALFExtendedProgramControlFlowGraphBuilder epcfg_builder;
  _pcfg = epcfg_builder.Build(cg, annots, alf_ast);

  // Create the RD analysis
  ALFReachingDefinitionsAnalysisBuilder rd_analysis_builder;
  _rd = rd_analysis_builder.Build(_pcfg, du);

  // We should only do normal forward analysis
  std::list<ReachingDefinitionsAnalysis::FIXPOINT_PASS> run_list;
  run_list.push_back(ReachingDefinitionsAnalysis::NORMAL);

  // Do the RD analysis according to inputs given by the user
  _rd->Run(_rd_settings->_analysis_type, &run_list, 
	   ReachingDefinitionsAnalysis::FORWARD, NULL,
	   _rd_settings->_print_specification, "", 
	   _rd_settings->_draw_specification, ""); 

  // Set to true if debugging of RD needed 
  if(false)
  {
    cout << "*******************************************\n";
    cout << " RD analysis result:\n";
    _rd->Print();
  }
}

} // end namespace cmd
