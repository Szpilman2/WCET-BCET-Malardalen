Read AvailableOptions.cpp for information on how to add a new input option to SWEET.
