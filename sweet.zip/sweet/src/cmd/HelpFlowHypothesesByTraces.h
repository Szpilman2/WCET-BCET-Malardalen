#ifndef HELPFLOWHYPOTHESESBYTRACES_H_
#define HELPFLOWHYPOTHESESBYTRACES_H_

namespace help_flow_hypotheses_by_traces {

/** Shows help information about sweets options in a formatted way.
*/
void HelpFlowHypothesesByTraces(bool no_csi=false);

}

#endif
