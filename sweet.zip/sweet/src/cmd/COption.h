#ifndef OPTION_H_
#define OPTION_H_

#include "COptionParameter.h"
#include "CCommand.h"
#include <string>
#include <vector>
#include <iostream>

namespace cmd {

class COptionParameter;
class CCommand;
class CVal;

/** \class  COption
   Contains a specification of an allowed command line option.
   An option has a key value, two alternative names (keywords), and
   descriptions of what it means. Optionally an option may require a value.
   An option is also linked to a command which performs its semantics.
*/
class COption {
public:
   typedef enum KEY {
      PARSE,
      CHECK,
      GENERATE_ABS_ANN,
      GENERATE_CLT_TEMPLATE,
      EXTRACT_FUNCS_INFO,
      INSPECTION,
      OUTPUT_FF,
      AE,
      VA,
      DU,
      RD,
      PDG,
      SLICE,
      ABS_DOMAIN,
      PRINT,
      NICE_PRINT,
      LOAD_MAP,
      TDB_BY_CLT,
      TEST,
      VERSION,
      HELP
   } KEY;

/** \class CPrecedences
   Help class to distinguish from other vectors of the same type. */
class CPrecedences : public std::vector <COption::KEY> {
   public:CPrecedences &operator[](COption::KEY preceeded_by) { push_back(preceeded_by); return *this; }
};

/** \class CDependencies
   Help class to distinguish from other vectors of the same type. */
class CDependencies : public std::vector <COption::KEY> {
   public:CDependencies &operator[](COption::KEY depending_on) { push_back(depending_on); return *this; }
};


   /** Constructs an option.
      \param key A key that identifies this option uniquely among all options.
      \param command A pointer to a command object that performs the meaning
         of this option. This option will be the owner of the command.
      \param short_name A string keyword unique among all the options. To be
         matched with the user input. There is no special limit of the text
         length, but to conform to the standard it should contain a single
         letter. The user will need to type a '-' before this name to get a
         match.
      \param long_name A string keyword unique among all the options. To be
         matched with the user input. There is no special limit of the text
         length, but to conform to the standard it should contain more than
         a single letter, and multiple words in this name should be delimited
         with '-'. The user will need to type  "--" before this name to get a
         match.
      \param short_description An description of the option's meaning. There
         is no special limit of the text length, but to conform to the standard
         it can be a good idea to pass a text in the range of 20-200 characters.
      \param detailed_description An optional detailed description of the
         option. This is the place for a detailed description of the
         semantics of this option.
      \post \a NeedVal() returns false.
      \post \a IsDefault() returns false.
      \post \a IsMandatory() returns false. */
   COption(KEY key,
           CCommand *command,
           std::string short_name,
           std::string long_name,
           std::string short_description,
           std::string detailed_description="") :
               key(key),
               command(command),
               short_name(short_name),
               long_name(long_name),
               short_description(short_description),
               detailed_description(detailed_description),
               need_val(false),
               is_visible(true)
               { }

   ~COption() { delete command; }

   COption(const COption &other) { *this = other; command = other.command->Copy(); }

   /** \return The command of this option. The command is nxot owned by
      the caller. */
   CCommand *GetCommand() const { return command; }

   /** \return The key of this option. */
   KEY GetKey() const { return key; }

   /** \return The short name of this option. */
   std::string GetShortName() const { return short_name; }

   /** \return The long name of this option. */
   std::string GetLongName() const { return long_name; }

   /** \return The short description of this option. */
   std::string GetShortDescription() const { return short_description; }

   /** \return The detailed description of this option, or, if there is none,
      the short one.*/
   std::string GetDetailedDescription() const { return detailed_description.empty() ? short_description : detailed_description; }

   /** Checks if this option needs a value to be used.
      \return True if it needs a value, else false. */
   bool NeedVal() const { return need_val; }

   /** Checks if this option should be visible or not to the user.
      \return True if it is visible, else false. */
   bool IsVisible() const { return is_visible; }

   /** Checks if this option default. That is if it can unumbigously set up a
      command without the user specifying anything. I.e. no value assignment
      and no mandatory parameters.
      \return True if it is deafult, else false. */
   bool IsDefault() const
   {
      if (NeedVal()) {
         bool default_val = false;
         const CVal *val = GetVal();
         if (val->GetType() == CVal::KEYWORD || val->GetType() == CVal::KEYWORD_SET) {
            const std::vector<CKeyword> &keyword_list = val->GetKeywordList();
            for (std::vector<CKeyword>::const_iterator kwd_it=keyword_list.begin(); kwd_it!=keyword_list.end(); ++kwd_it) {
               const CKeyword *keyword = &*kwd_it;
               if (keyword->IsDefault()) {
                  default_val = true;
                  break;
               }
            }
         } else {
            // Then default value is impossible
            ;
         }
         if (!default_val) {
            return false;
         }
      }
      for (unsigned i=0; i<parameters.size(); ++i) {
         if (parameters[i].IsMandatory())
            return false;
      }
      return true;
   }

   /** \return A pointer to the value specification of this option.
      \pre \a NeedVal() returns true. */
   const CVal *GetVal() const { return &val; }

   /** \return A pointer to the a vector with the options that should precede
      this option (when present). */
   const std::vector <KEY> &GetPrecedence() const { return precedence; }

   /** \return A pointer to the a vector with the options that this option
      depends on. */
   const std::vector <KEY> &GetDependencies() const { return dependencies; }

   /** \return A pointer to the parameters of this option. */
   const std::vector <COptionParameter> &GetParameters() const { return parameters; }

   /** Adds a new parameter to the set of parameters of this option. */
   COption &operator[](COptionParameter parameter) { parameters.push_back(parameter); return *this; }

   /** Adds a list of precedences, i.e. options that  should be executed
      before this in case they are present. */
   COption &operator[](CPrecedences preceded_by)
   {
      precedence.insert(precedence.end(), preceded_by.begin(), preceded_by.end());
      return *this;
   }

   /** Adds a list of dependencies, i.e. other options that are required by
      this option, e.g. because this option uses the data produced by the
      other. If there is a dependency to an option then it will automatically
      be added to the precedence list. If an option A depends on B and B is
      a "default option", then a coomand for it will be automatically added
      if the user did not specify. */
   COption &operator[](CDependencies depends_on)
   {
      precedence.insert(precedence.end(), depends_on.begin(), depends_on.end());
      dependencies.insert(dependencies.end(), depends_on.begin(), depends_on.end());
      return *this;
   }

   /** Assigns a value specification to this parameter.
      \pre \a NeedVal() returns false. 
      \post \a NeedVal() returns true. */
   COption &operator=(CVal new_value) { assert(!need_val); val = new_value; need_val=true; return *this; }

   /** Indicates that this option is not is_visible to the user.
      \pre \a NeedVal() returns false. 
      \post \a NeedVal() returns true. */
   COption &operator!() { is_visible = false; return *this; }

private:
   KEY key;
   CCommand *command;
   std::string short_name;
   std::string long_name;
   std::string short_description;
   std::string detailed_description;
   std::vector <KEY> precedence;
   std::vector <KEY> dependencies;
   std::vector <COptionParameter> parameters;
   CVal val;
   bool need_val;
   bool is_visible;
};

}

#endif
