// $Id $

#ifndef CCOMMAND_VERSION_H_INCLUDED
#define CCOMMAND_VERSION_H_INCLUDED

#include "CCommand.h"

namespace cmd {

class CSession;

/** \class CCommandVersion Shows the version.
*/
class CCommandVersion : public CCommand
{
public:

  void Validate(const CSession *session) { }

  void Execute(const CSession *session);

  CCommand *Copy() const { return new CCommandVersion(*this); }

private:
};

}

#endif
