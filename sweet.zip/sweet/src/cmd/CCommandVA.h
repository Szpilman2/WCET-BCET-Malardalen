#ifndef CCOMMAND_VA_H_
#define CCOMMAND_VA_H_

#include "CCommand.h"
#include <map>
#include "dfa/AlfValueDataFlowAnalysis.h"
#include "ae/AlfAbstractExecution.h"

class CScopeGraph;

namespace cmd {

class CSession;

class VASettings {
public:
  // Nice access functions
  AlfValueDataFlowAnalysis::ANALYSIS_TYPE GetAnalysisType() const { return _analysis_type; }
  const std::list<AlfValueDataFlowAnalysis::FIXPOINT_PASS> * GetFixpointPasses() const { return &_fixpoint_passes; }
  bool UseWidNar() const { return _use_wid_nar; }

  const CDomainSettings * GetDomainSettings() const { return _domain_settings; }
  WideningPlacement GetWideningPlacement() const {return _widening_placement;}

  // Internal data structures, to be set by CCommandVA
  AlfValueDataFlowAnalysis::ANALYSIS_TYPE _analysis_type;
  std::list<AlfValueDataFlowAnalysis::FIXPOINT_PASS> _fixpoint_passes;
  bool _use_wid_nar;
  WideningPlacement _widening_placement;
  const CDomainSettings * _domain_settings;
  bool c;     // Continue with the fall-through state
  bool w;     // Do not continue with the fall-through state and warn if it is not bottom
  AlfValueDataFlowAnalysis::PRINT_DRAW_SPECIFICATION _print_analysis_specification;
  AlfValueDataFlowAnalysis::PRINT_DRAW_SPECIFICATION _draw_analysis_specification;
};

/** \class CCommandVA
   Performs value analysis on the input program.
*/
class CCommandVA : public CCommand
{
public:

  // To create and delete the value analysis object
  CCommandVA();
  ~CCommandVA();

 typedef enum KEY { ANALYSIS_TYPE, CHAOTIC, WORK_LIST, NODE_ORDERING, FIXPOINT_PASS, NORMAL, WIDENING, NARROWING, 
                    WIDENING_NARROWING, WID_NAR_POINT, FIRST_STMT_IN_BB, LAST_STMT_IN_BB, AT_BACK_EDGE, 
                    FT, CONTINUE, DO_NOT_CONTINUE, DO_NOT_CONTINUE_WARN, PRINT_ANALYSIS_RESULT, DRAW_ANALYSIS_RESULT, RESULT, FIX_POINT_PASS, ITERATION } KEY;

   /** Check if the arguments are valid. If merging specification contains
      contradictions then a runtime exception will be thrown. */
   void Validate(const CSession *session);

   /** Runs the value analysis alogrithm on the current ast, requiring a
      scope graph to be present. Using the result of slicing if present. */
   void Execute(const CSession *session);

   CCommand *Copy() const;

  /** To get the settings */
  const VASettings * GetVASettings() const { return _va_settings; }

  /** \return A pointer to the resulting alf value data flow analysis */
  const AlfValueDataFlowAnalysis * GetDFA() const { return _dfa; };

protected:

   // The settings
   VASettings *_va_settings;
   // The data flow analysis object 
   AlfValueDataFlowAnalysis * _dfa;
   // The scopegraph 
   CScopeGraph * _sg;
};




} // end cmd namespace

#endif
