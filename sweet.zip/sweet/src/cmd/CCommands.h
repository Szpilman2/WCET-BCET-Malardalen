#ifndef COMMANDS_H_
#define COMMANDS_H_

#include "CCommand.h"
#include "COption.h"
#include <vector>

namespace cmd {

/** \class CCommands
   Collects a list of commands as a vector.
*/
class CCommands : public std::vector <CCommand*>
{
public:
   ~CCommands()
   {
   }

   CCommand *GetCommand(COption::KEY key) const
   {
      CCommand *command = NULL;
      for (unsigned i=0; i<size(); ++i) {
         if (key == at(i)->GetOption()->GetKey()) {
            command = at(i)->GetOption()->GetCommand();
            break;
         }
      }
      return command;
   }

   bool HasCommand(COption::KEY key) const { return GetCommand(key) != NULL; }
};

}
#endif
