#include "Help.h"
#include "COptionGroups.h"
#include "COptionGroup.h"
#include "COption.h"
#include "COptionParameter.h"
#include "CVal.h"
#include "CKeyword.h"
#include "AvailableOptions.h"
#include "tools/CTextBlock.h"
#include "version.h"
#include <iostream>
#include <sstream>

using namespace std;

#define PLACEHOLDER  "<X>"

namespace cmd {

static void HighLightOptionKeyword(string text, CTextBlock *text_block, int indent=0)
{
   CTextElement text_element = CTextElement(text, indent);
   text_element.SetBold();
   text_block->push_back(text_element);
}

static void HighLightValue(string text, CTextBlock *text_block, int indent=0)
{
   CTextElement text_element = CTextElement(text, indent);
   text_element.SetBold();
   text_element.SetColor(CTextElement::MAGENTA);
   text_block->push_back(text_element);
}

static void ValueAsText(const CVal *val, CTextBlock *text_block, int indent, int indent_s)
{
   ostringstream s;
   switch (val->GetType()) {
      case CVal::INT:
      case CVal::STRING:
         if (val->ShortDescription() != "") {
            if (val->GetName() == "") {
               text_block->push_back(CTextElement("Meaning: ", indent_s));
	       text_block->push_back(CTextElement(" "+val->ShortDescription(), indent_s, true));
            } else {
               text_block->push_back(CTextElement("Meaning of ", indent_s));
               HighLightValue(val->GetName(), text_block, indent_s);
	       text_block->push_back(CTextElement(": "+val->ShortDescription(), indent_s, true));
            }
         }
         break;
      case CVal::KEYWORD:
      case CVal::KEYWORD_SET:
      {
         string name;
         if (val->GetName() == "") {
            name = PLACEHOLDER;
         } else {
            name = val->GetName();
         }
         HighLightValue(name, text_block, indent);

         if (val->GetType() == CVal::KEYWORD) {
            text_block->push_back(CTextElement(" can be one of: ", indent_s, true));
         } else {
            text_block->push_back(CTextElement(" can be one or more: ", indent_s, true));
         }

         const std::vector<CKeyword> &keywords = val->GetKeywordList();
         for (unsigned i=0; i<keywords.size(); ++i) {
            HighLightValue(keywords[i].GetName(), text_block, indent+2);
            text_block->push_back(CTextElement(" - ", indent+16));
            if (keywords[i].IsDefault()) {
               text_block->push_back(CTextElement("(default) "));
            }
            text_block->push_back(CTextElement(keywords[i].GetDescription(), indent+18, true));
         }
         break;
      }
      case CVal::VOID:
         break;
   }
}

static void ParameterAsText(const COptionParameter *parameter, CTextBlock *text_block)
{
   string s;

   s = parameter->GetName();
   if (parameter->NeedVal()) {
      s += "=";
   }
   HighLightOptionKeyword(s, text_block, 4);

   if (parameter->NeedVal()) {
      string s;
      if (parameter->GetVal()->GetName() == "") {
         s = PLACEHOLDER;
	 s = s + " ";
      } else {
         s = parameter->GetVal()->GetName() + " ";
      }
      HighLightValue(s, text_block, 4);
      text_block->push_back(CTextElement(parameter->GetShortDescription() + " ", 14));
      ValueAsText(parameter->GetVal(), text_block, 4, 14);
      text_block->push_back(CTextElement("", 14, true));
   } else {
      text_block->push_back(CTextElement(parameter->GetShortDescription(), 14, true));
   }
   if (parameter->IsMandatory()) {
      text_block->push_back(CTextElement(" This parameter is mandatory.", 14, true));
   }
}

static void OptionAsText(const COption *option, CTextBlock *text_block)
{
   string s;
   s = "-" + option->GetShortName() + ",--" + option->GetLongName();
   if (option->NeedVal()) {
      s += "=";
   }

   HighLightOptionKeyword(s, text_block, 0);
   if (option->NeedVal()) {
      string s;
      if (option->GetVal()->GetName() == "") {
         s = PLACEHOLDER;
      } else {
         s = option->GetVal()->GetName();
      }
      HighLightValue(s, text_block);
   }
   text_block->push_back(CTextElement("  "+option->GetShortDescription(), 14, true));
   if (option->NeedVal()) {
      ValueAsText(option->GetVal(), text_block, 2, 2);
   }
   const std::vector <COptionParameter> &parameters = option->GetParameters();
   if (parameters.size() > 0) {
      text_block->push_back(CTextElement("Parameters: ", 2, true));
      for (vector <COptionParameter>::const_iterator par_it=parameters.begin(); par_it!=parameters.end(); ++par_it) {
         ParameterAsText(&*par_it, text_block);
      }
   }
   text_block->push_back(CTextElement("", 0, true));
}

static void OptionGroupAsText(const COptionGroup *option_group, CTextBlock *text_block)
{
   text_block->push_back(CTextElement("", 0, true));
   if (option_group->GetLabel() != "") {
      CTextElement text_element = CTextElement(option_group->GetLabel(), 0, true);
      text_element.SetBold();
      text_element.SetColor(CTextElement::GREEN);
      text_block->push_back(text_element);
      string underline;
      for (unsigned i=0; i<option_group->GetLabel().size(); ++i)
         underline += "-";
      text_element = CTextElement(underline, 0, true);
      text_element.SetBold();
      text_element.SetColor(CTextElement::GREEN);
      text_block->push_back(text_element);
   }
   for (COptionGroup::const_iterator group_it=option_group->begin(); group_it!=option_group->end(); ++group_it) {
      const COption *option = &*group_it;
      if (option->IsVisible()) {
         OptionAsText(option, text_block);
      }
   }
}

static void OptionGroupsAsText(unique_ptr <COptionGroups> option_groups, CTextBlock *text_block)
{
   string s = "Options available for SWEET version ";
   s.append(SWEET_VERSION);
   s.append(".");
//   CTextElement text_element = CTextElement("Options available for SWEET version "+SWEET_VERSION+".", 0, true);
   CTextElement text_element = CTextElement(s, 0, true);
   text_element.SetBold();
   text_element.SetColor(CTextElement::BLUE);
   text_block->push_back(text_element);
   for (COptionGroups::const_iterator group_it=option_groups->begin(); group_it!=option_groups->end(); ++group_it) {
      const COptionGroup *option_group = &*group_it;
      OptionGroupAsText(option_group, text_block);
   }
}

void Help(bool hide_properties)
{
   unique_ptr <COptionGroups> available_options = AvailableOptions();
   CTextBlock options_as_text;
   OptionGroupsAsText(move(available_options), &options_as_text);
   options_as_text.Show(std::cout, 80, hide_properties);
}
}
