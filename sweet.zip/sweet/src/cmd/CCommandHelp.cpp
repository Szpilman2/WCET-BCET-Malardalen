// $Id $

#include "CCommandHelp.h"
#include "HelpAnnot.h"
#include "HelpFFGeneration.h"
#include "HelpFlowHypothesesByTraces.h"
#include "Help.h"

namespace cmd {

void
CCommandHelp::
Execute(const CSession *session)
{
   // Turn off or on syntax high-lighting
   bool no_csi = true;
   const CCommandArgument *use_csi_arg = GetArgument(USE_CSI);
   if (use_csi_arg) {
       no_csi = false;
   }

   // Decide what to generate help text upon
   const CCommandArgument *help_topic = GetArgument(TOPIC);
   if(help_topic == NULL) {
     // Print normal help text
     Help(no_csi);
   }
   else {
     switch (help_topic->GetVal()->AsKey()) {
     case OPTION:
       // Print normal help text
       Help(no_csi);
       break;
     case ANNOT:
       // Print annot help text
       help_annot::HelpAnnot(no_csi);
       break;
     case FFG:
       // Print flow fact generation help text
       help_ff_gen::HelpFFGeneration(no_csi);
       break;
     case TRACE:
       // Print flow hypothesis by traces help text
       help_flow_hypotheses_by_traces::HelpFlowHypothesesByTraces(no_csi);
       break;
     }
   }
}

}
