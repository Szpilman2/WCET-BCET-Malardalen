// $Id $

#ifndef CCOMMAND_INSPECTION_H_INCLUDED
#define CCOMMAND_INSPECTION_H_INCLUDED

#include "CCommand.h"

namespace cmd {

class CSession;

/** \class CCommandInspection
   Produces various information about the code structure and dump it into the console
*/
class CCommandInspection : public CCommand
{
public:

   typedef enum KEY { FILE } KEY;

   void Validate(const CSession *session);

   void Execute(const CSession *session);

   CCommand *Copy() const { return new CCommandInspection(*this); }

private:

   std::string filename;
   bool print_to_file;
};

}

#endif
