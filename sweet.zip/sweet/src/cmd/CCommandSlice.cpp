
// Includes
#include "cmd/CCommandSlice.h"
#include "cmd/CCommandParse.h"
#include "cmd/CCommandDU.h"
#include "cmd/CCommandPDG.h"
#include "cmd/CSession.h"
#include "dfa/ALFDefsAndUsesAnalysis.h"
#include "alf_slicing/ALFExtendedProgramDependencyGraph.h"
#include "program/CGenericProgram.h"
#include "program/CGenericFunction.h"
#include "program/alf/CAlfTreeFilter.h"
#include "graphs/tools/CGraph.h"
#include "graphs/tools/CNode.h"
#include "graphs/cg/CCallGraph.h"
#include "graphs/cg/CCallGraphNode.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/cfg/CFlowGraphEdgeAnnot.h"
#include "graphs/components/CComponent.h"
#include "symtab/CSymTabBase.h"
#include "symtab/CSymTabEntry.h"
#include "symtab/CSymTabIdentifier.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CLRefTuple.h"
#include "program/alf/AStmt.h"
#include "program/alf/CGenericNode.h"
#include "tools/CSourceLoader.h"

// Standard includes
#include <map>
#include <set>
#include <list>
#include <sstream>
#include <fstream>
#include <iostream>

using namespace std;

namespace cmd {

CCommandSlice::
CCommandSlice()
{
  _ast = NULL;
  _slicing_algo = NULL;

  _has_entities = false;
  _slice_on_loops = false;
  _slice_on_conds = false;
  _slice_on_globals = false;
  _slice_on_root_func_inputs = false;
  _slice_on_root_func_returns = false;

  _has_labels = false;  

  _has_vars = false;  

  _individual_slices = false;

  _direction = ALFSlicing::BACKWARD;

  _invert = false;

  _print_result = false;
  _print_res_stmts = false;
  _print_res_funcs = false;
  _print_res_globals = false;
  _print_res_locals = false;
  _print_res_scoped_locals = false;

  _draw_result = false;
}

CCommandSlice::
~CCommandSlice()
{
  if(_slicing_algo) delete _slicing_algo;
}
 
CCommand *
CCommandSlice::
Copy() const
{
  assert(_slicing_algo == NULL);	
  return new CCommandSlice(*this);
}

void
CCommandSlice::
Validate(const CSession *session)
{ 
  // ---------------------------------
  // Get code entities to slice upon
  // ---------------------------------
  const CCommandArgument *entities_arg = GetArgument(ENTITIES);
  { 
    // Extract the type of entities we should start slicing from
    if(entities_arg) {
      _has_entities = true;
      switch(entities_arg->GetVal()->AsKey()) {
      case LOOPS:
	_slice_on_loops = true;
	break;
      case CONDS:
	_slice_on_conds = true;
	break;
      case GLOBALS:
	_slice_on_globals = true;
	break;
      case ROOT_FUNC_INPUTS:
	_slice_on_root_func_inputs = true;
	break;
      case ROOT_FUNC_RETURNS:
	_slice_on_root_func_returns = true;
	break;
      default:
	assert(0);
	break;
      }
    }
  }

  // ---------------------------------
  // Get labels of code entities to slice upon
  // ---------------------------------
  const CCommandArgument *labels_arg = GetArgument(LABELS);
  { 
    // Check that we have some starting conditions
    if(labels_arg) {
      _has_labels = true;

      // Extract the labels of entities we should start slice from.
      // since we do not have the symtab yet we can here not check that
      // the labels refer to real code entities. The read in labels are
      // separated by commas.
      std::string labels_string = labels_arg->GetVal()->AsString();
      size_t scan_start = 0;
      size_t match_pos;
      do {
	match_pos = labels_string.find(',', scan_start);
	size_t length = match_pos - scan_start;
	string label = labels_string.substr(scan_start,length);
	_unsorted_labels.push_back(label);
	scan_start = match_pos + 1;
      } while (match_pos != string::npos);
    }
  }

  // ---------------------------------
  // Get variables to slice upon
  // ---------------------------------
  const CCommandArgument *vars_arg = GetArgument(VARS);
  { 
    // Check that we have some starting conditions
    if(vars_arg) {
      _has_vars = true;

      // Extract the labels of entities we should start slice from.
      // since we do not have the symtab yet we can here not check that
      // the labels refer to real code entities. The read in labels are
      // separated by commas.
      std::string vars_string = vars_arg->GetVal()->AsString();
      size_t scan_start = 0;
      size_t match_pos;
      do {
	match_pos = vars_string.find(',', scan_start);
	size_t length = match_pos - scan_start;
	string label = vars_string.substr(scan_start,length);
	_unsorted_vars.push_back(label);
	scan_start = match_pos + 1;
      } while (match_pos != string::npos);
    }
  }

  { // ---------------------------------
    // Check that we have something to start slice upon
    // ---------------------------------
    if((entities_arg && labels_arg) ||
       (entities_arg && vars_arg) ||
       (labels_arg && vars_arg)) {
      throw runtime_error("Only one of ent, lab and var can be used during slicing.");   
    }
    if(!entities_arg && !labels_arg && !vars_arg) {
      throw runtime_error("At least one of ent, lab or var must be used during slicing.");   
    }
  }
  
  { // ---------------------------------
    // Check if we should do individual slices
    // ---------------------------------
    const CCommandArgument *mul_arg = GetArgument(MUL);
    _individual_slices = false;
    if(mul_arg && mul_arg->GetVal()->AsKey() == INDIVIDUAL)
      _individual_slices = true;
  }

  { // ---------------------------------
    // Check if we should do forward slicing 
    // ---------------------------------
    const CCommandArgument *dir_arg = GetArgument(DIRECTION);
    _direction = ALFSlicing::BACKWARD;
    if(dir_arg && dir_arg->GetVal()->AsKey() == FORWARD)
      _direction = ALFSlicing::FORWARD;
  }

  // ---------------------------------
  // Handle printing
  // ---------------------------------
  {
    const CCommandArgument *print_arg = GetArgument(PRINT);
    if(print_arg) {
      _print_result = true;
      std::vector<int> prints = print_arg->GetVal()->AsKeySet();
      // If no argument to p has been given we print everything
      if(prints.size() == 0) {
	_print_res_stmts = true;
	_print_res_funcs = true;
	_print_res_globals = true;
	_print_res_locals = true;
	_print_res_scoped_locals = true;
      }
      else {
	// Check what user has specified to be printed and set
	// booleans accordingly
	for (unsigned i=0; i<prints.size(); ++i) {
	  int print = prints[i];
	  switch (print) {
	  case RES_ALL:
	    _print_res_stmts = true;
	    _print_res_funcs = true;
	    _print_res_globals = true;
	    _print_res_locals = true;
	    _print_res_scoped_locals = true;
	    break;
	  case RES_STMTS:
	    _print_res_stmts = true;
	    break;
	  case RES_FUNCS:
	    _print_res_funcs = true;
	    break;
	  case RES_GLOBALS:
	    _print_res_globals = true;
	    break;
	  case RES_LOCALS:
	    _print_res_locals = true;
	    break;
	  case RES_SCOPED_LOCALS:
	    _print_res_scoped_locals = true;
	    break;
	  default:
	    assert(0);
	    break;
	  }
	}
      }
    }
  }

  if (GetArgument(INVERT))
     _invert = true;

  // ---------------------------------
  // Handle drawing
  // ---------------------------------
  {
    const CCommandArgument *draw_argument = GetArgument(DRAW);
    if(draw_argument) {
      _draw_result = true;
    }
  }
}

void
CCommandSlice::
Execute(const CSession *session)
{
  // We need the ALF ast (constness removed since it will take a lot
  // of time adding const everywhere in the DU code)
  CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
  _ast = dynamic_cast<const alf::CAlfTuple *>(command_parse->GetAst());
  alf::CAlfTuple * alf_ast = const_cast<alf::CAlfTuple*>(_ast);
  CCallGraph * cg = command_parse->GetCallGraph();

  // We need the symbol table (constness removed since it will
  // take a lot of time adding const everywhere in the DU code)
  _symtab =  const_cast<CSymTabBase *>(alf_ast->GetSymTab());

  // We need the def use analysis
  CCommandDU *command_du = dynamic_cast<CCommandDU *> (session->GetCommand(COption::DU));
  ALFDefsAndUsesAnalysis * du = command_du->GetDUAnalysis();

  // We need the PDG 
  CCommandPDG *command_pdg = dynamic_cast<CCommandPDG *> (session->GetCommand(COption::PDG));
  ALFExtendedProgramDependencyGraph * pdg = command_pdg->GetPDG();

  assert(_ast);
  assert(alf_ast);
  assert(cg);
  assert(du);
  assert(pdg);
  assert(_symtab);

  // -------------------------------------------------------
  // Create the slicing algorithm 
  // -------------------------------------------------------

  _slicing_algo = new ALFSlicing(pdg, du);

  // -------------------------------------------------------
  // Derive the statements to slice upon
  // -------------------------------------------------------
  if(_has_labels) {
    // A vector to keep track of non correct labels
    std::vector<std::string> bad_labels;
    // Go through all selected labels and decide what they are
    for(unsigned int i=0; i<_unsorted_labels.size(); i++) {
      std::string label = _unsorted_labels[i];
      const CSymTabEntry * entry = _symtab->Lookup(label);
      if(!entry) {
	bad_labels.push_back(label);
	continue;
      }
      // Check the type of the entry
      if(entry->IsFunction()) {
	// The entry refers to a function. Add all the statements in
	// the function cfg.
	CGenericFunction *gen_func = entry->GetCodeIdentifier()->GetFunction();
	CCallGraphNode *cg_node = cg->FindNodeOfFunction(gen_func);
	CFlowGraph * cfg = cg_node->FlowGraph();
	for(CFlowGraph::node_iterator cfg_node = cfg->NodesBegin();
	    cfg_node != cfg->NodesEnd(); ++cfg_node) {
	  alf::AStmt * stmt = dynamic_cast<alf::AStmt *>((*cfg_node)->Stmt());
	  assert(stmt);
	  _stmts_to_slice_upon.insert(stmt);
	}
      }
      else if(entry->IsCode() && !entry->IsFunction()) {
	// The entry refers to a statement. Add it to the set of things to keep track of.
	const alf::CLRefTuple * lref_tuple = dynamic_cast<const alf::CLRefTuple *>(entry->GetCodeIdentifier());
	assert(lref_tuple);
	alf::AStmt * stmt = dynamic_cast<alf::AStmt *>(lref_tuple->GetParent(CGenericNode::TYPE_STMT));
	assert(stmt);
	_stmts_to_slice_upon.insert(stmt);
      }
      else {
	// The label is neither a statement or a function
	bad_labels.push_back(label);
      }
    }
    // Check if we got any incorrect labels
    if(bad_labels.size() > 0) {
      stringstream ss;
      ss << "The following labels does not refer to a statement nor to a function: ";
      for(unsigned int i = 0; i < bad_labels.size() - 1; ++i) {
	ss << bad_labels[i] << ", ";
      }
      ss << *(bad_labels.rbegin());
      throw runtime_error(ss.str());
    }
  }

  // -------------------------------------------------------
  // Derive the variables to slice upon
  // -------------------------------------------------------
  if(_has_vars) {
    // A vector to keep track of non correct variables
    std::vector<std::string> bad_vars;
    // Go through all selected vars 
    for(unsigned int i=0; i<_unsorted_vars.size(); i++) {
      std::string var = _unsorted_vars[i];
      const CSymTabEntry * entry = _symtab->Lookup(var);
      if(!entry) {
	bad_vars.push_back(var);
	continue;
      }
      else if(entry->IsData()) {
	// The entry refers to a global or a scope local variable
	const CSymTabIdentifier * id = entry->GetIdentifier();
	unsigned int var = id->GetKey();
	_vars_to_slice_upon.insert(var);
      }
      else {
	// The var is not referring to a real variable 
	bad_vars.push_back(var);
      }
    }
    // Check if we got any incorrect vars
    if(bad_vars.size() > 0) {
      stringstream ss;
      ss << "The following variables does not exists: ";
      for(unsigned int i = 0; i < bad_vars.size() - 1; ++i) {
	ss << bad_vars[i] << ", ";
      }
      ss << *(bad_vars.rbegin());
      throw runtime_error(ss.str());
    }
  }

  // -------------------------------------------------------
  // Derive the slice on the statements
  // -------------------------------------------------------
  if(_has_labels) {
    if(_individual_slices) {
      for(std::set<alf::AStmt *>::iterator stmt = _stmts_to_slice_upon.begin();
	  stmt != _stmts_to_slice_upon.end(); ++stmt) {
	// Create a temporary set containing just a single statament
	std::set<alf::AStmt *> start_stmts;
	start_stmts.insert(*stmt);
	SliceOnStmtsAndPrintAndDraw(&start_stmts, (*stmt)->Name());
      }
    }
    else {
      SliceOnStmtsAndPrintAndDraw(&_stmts_to_slice_upon, "stmts");
    }
  } // end has labels

  // -------------------------------------------------------
  // Derive the slice on the vars
  // -------------------------------------------------------
  if(_has_vars) {
    if(_individual_slices) {
      for(std::set<unsigned int>::iterator var = _vars_to_slice_upon.begin();
	  var != _vars_to_slice_upon.end(); ++var) {
	  const CSymTabEntry * entry = _symtab->Lookup(*var);
	  cout << "CCommandSlice::Execute 5.1 var: " << *var << " name: " << entry->Name() << "\n";
	  // Create a temporary set containing just a single variable
	  std::set<unsigned int> start_vars;
	  start_vars.insert(*var);
	  SliceOnVarsAndPrintAndDraw(&start_vars, entry->Name());
      }
    }
    else {
      cout << "CCommandSlice _vars_to_slice_upon: " << _vars_to_slice_upon.size() << endl;
      SliceOnVarsAndPrintAndDraw(&_vars_to_slice_upon, "vars");
    }
  }

  // -------------------------------------------------------
  // Derive the slice on selected entities
  // -------------------------------------------------------
  if(_has_entities) {

    // ---------------------------------
    // Slice on conditionals
    // ---------------------------------
    if(_slice_on_conds) {
      std::list<CFlowGraphNode *> cond_nodes;
      _slicing_algo->GetConditionalNodesOfCG(cg, &cond_nodes);
      if(_individual_slices) {
        for(std::list<CFlowGraphNode *>::iterator cond_node = cond_nodes.begin();
            cond_node != cond_nodes.end(); ++cond_node) {
          alf::AStmt * stmt = dynamic_cast<alf::AStmt *>((*cond_node)->Stmt());
          std::set<alf::AStmt *> start_stmts;
          start_stmts.insert(stmt);
          SliceOnStmtsAndPrintAndDraw(&start_stmts, (*cond_node)->Name());
        }
      }
      else {

          // Add all statements of all cond nodes
        std::set<alf::AStmt *> start_stmts;
        for(std::list<CFlowGraphNode *>::iterator cond_node = cond_nodes.begin();
            cond_node != cond_nodes.end(); ++cond_node) {
          alf::AStmt * stmt = dynamic_cast<alf::AStmt *>((*cond_node)->Stmt());
          start_stmts.insert(stmt);
        }
        SliceOnStmtsAndPrintAndDraw(&start_stmts, "conds");
      }
    }
    
    // ---------------------------------
    // Slice on loops
    // ---------------------------------
    else if(_slice_on_loops) {
        if(_individual_slices) {

          // Loop through all cfgs in the call graph
          for(CCallGraph::node_iterator cg_node = cg->NodesBegin(); cg_node != cg->NodesEnd(); ++cg_node) {
            CFlowGraph * cfg = (*cg_node)->FlowGraph();
            std::string func_name = cfg->Function()->Name();

              // Get and loop through the looping components of the cfg
            std::list<CComponent<CFlowGraphNode> *> loop_comps;
            cfg->GetLoopingComponents(&loop_comps);
            unsigned int index = 1;
            for(std::list<CComponent<CFlowGraphNode> *>::iterator loop_comp = loop_comps.begin();
                loop_comp != loop_comps.end(); ++loop_comp, index++) {
                
                // Get all the loop exit conditions of the component
              std::list<CFlowGraphNode *> loop_exit_nodes;
              _slicing_algo->GetLoopExitNodesOfComponent(*loop_comp, &loop_exit_nodes);

                // Extract the corresponding set of statements
              std::set<alf::AStmt *> start_stmts;
              for(std::list<CFlowGraphNode *>::iterator loop_exit_node = loop_exit_nodes.begin();
                  loop_exit_node != loop_exit_nodes.end(); ++loop_exit_node) {
                alf::AStmt * stmt = dynamic_cast<alf::AStmt *>((*loop_exit_node)->Stmt());
                start_stmts.insert(stmt);
              }

                // Do the slice on the statements
              stringstream ss;
              ss << func_name << "_L" << index;
              SliceOnStmtsAndPrintAndDraw(&start_stmts, ss.str());
            }
          }
        }
      else {
          // Extract all loop exit nodes

        std::list<CFlowGraphNode *> loop_exit_nodes;
        _slicing_algo->GetLoopExitNodesOfCG(cg, &loop_exit_nodes);
          
          // Extract the corresponding set of statements
        std::set<alf::AStmt *> start_stmts;
        for(std::list<CFlowGraphNode *>::iterator loop_exit_node = loop_exit_nodes.begin();
            loop_exit_node != loop_exit_nodes.end(); ++loop_exit_node) {
          alf::AStmt * stmt = dynamic_cast<alf::AStmt *>((*loop_exit_node)->Stmt());
          start_stmts.insert(stmt);
        }
        
          // Do the slice on the statements
        SliceOnStmtsAndPrintAndDraw(&start_stmts, "loops");
      }
    }

    // ---------------------------------
    // Slice on global variable
    // ---------------------------------
    else if(_slice_on_globals) {
      
        // Get all global variables 
      CDeclList * decls = alf_ast->GetDecls();
      if(_individual_slices) {

          // Treat each global var separately
        for(CDeclList::list_iterator alloc = decls->Iterator(); alloc != decls->InvalidIterator(); alloc++) {
          assert((*alloc)->HasKey());
          unsigned int var = (*alloc)->GetKey();
          const CSymTabEntry * entry = _symtab->Lookup(var);
          std::set<unsigned int> start_vars;
          start_vars.insert(var);

            // Do the slice on the global variable
          SliceOnVarsAndPrintAndDraw(&start_vars, entry->Name());
        }
      }
      else {
          // Add all global variables
        std::set<unsigned int> start_vars;
        for(CDeclList::list_iterator alloc = decls->Iterator(); alloc != decls->InvalidIterator(); alloc++) {
          assert((*alloc)->HasKey());
          unsigned int var = (*alloc)->GetKey();
          start_vars.insert(var);

            // Do the slice on the global variables
          SliceOnVarsAndPrintAndDraw(&start_vars, "globals");
        }
      }
    }

    // ---------------------------------
    // Slice on root func input vars
    // ---------------------------------
    else if(_slice_on_root_func_inputs) {
      
        // Get the root function of the call graph
        CCallGraphNode * cg_root_node = cg->Root();
        alf::CFuncTuple * func = dynamic_cast<alf::CFuncTuple *>(cg_root_node->Function());

        // Get its formal arguments
        const CArgDeclList* args = func->GetArgs();
        if(_individual_slices) {
          for(CArgDeclList::const_list_iterator alloc = args->ConstIterator(); alloc != args->InvalidIterator(); alloc++) {
            assert((*alloc)->HasKey());
            unsigned int var = (*alloc)->GetKey();
            const CSymTabEntry * entry = _symtab->Lookup(var);
            std::set<unsigned int> start_vars;
            start_vars.insert(var);

              // Do the slice on the global variable
            SliceOnVarsAndPrintAndDraw(&start_vars, entry->Name());
          }
        }
      else {
          
          // Add all global variable allocations 
        std::set<unsigned int> start_vars;
        for(CArgDeclList::const_list_iterator alloc = args->ConstIterator(); alloc != args->InvalidIterator(); alloc++) {
          assert((*alloc)->HasKey());
          unsigned int var = (*alloc)->GetKey();
          start_vars.insert(var);

            // Do the slice on the global variables
          SliceOnVarsAndPrintAndDraw(&start_vars, "rootinputvars");
        }
      }
    }
      
    // ---------------------------------
    // Slice on root func output vars
    // ---------------------------------
    else if (_slice_on_root_func_returns) {
      // Get the root function of the call graph
      CCallGraphNode * cg_root_node = cg->Root();
      alf::CFuncTuple * func = dynamic_cast<alf::CFuncTuple *>(cg_root_node->Function());
      
        // Get all statements of return type in cg
      std::vector<CGenericStmt*> return_stmts;
      func->GetStmtsInFunctionScopeAndSubordinateScopes(&return_stmts, CGenericNode::TYPE_RETURN_STMT_TUPLE);
      
        // Check if we should do individual slicing or not
        if(_individual_slices) {
            // Do a slicing on each return stmt in isolation
          for(std::vector<CGenericStmt *>::iterator stmt = return_stmts.begin();
              stmt != return_stmts.end(); ++stmt) {
            alf::AStmt * astmt = dynamic_cast<alf::AStmt *>(*stmt);
            std::set<alf::AStmt *> start_stmts;
            start_stmts.insert(astmt);
            SliceOnStmtsAndPrintAndDraw(&start_stmts, (*stmt)->Name());
          }
        }
        else {
            
            // Do a slicing on all return stmts together
          std::set<alf::AStmt *> start_stmts;
          for(std::vector<CGenericStmt *>::iterator stmt = return_stmts.begin();
              stmt != return_stmts.end(); ++stmt) {
            alf::AStmt * astmt = dynamic_cast<alf::AStmt *>(*stmt);
            start_stmts.insert(astmt);
          }

            // Do the slice on the statements
          SliceOnStmtsAndPrintAndDraw(&start_stmts, "returns");
        }
      }
    }
  }

void
CCommandSlice::
SliceOnStmtsAndPrintAndDraw(std::set<alf::AStmt *> * start_stmts, std::string name)
{
  // Create files and streams to print and draw to
  std::ostream * draw_slice_stream=NULL;
  ofstream ds;

  std::ostream * print_slice_stream=NULL;
  ofstream ps;

  if(_draw_result || _print_result) {
    stringstream file_name; 
    file_name << "_ALFSlicing_" << name << "_";
    if(_direction == ALFSlicing::BACKWARD)
      file_name << "backward";
    else
      file_name << "forward";
    if(_draw_result) {
      stringstream ss;
      ss << file_name.str() << ".dot";
      cout << "  Draws slicing result to: " << ss.str() << endl;
      ds.open(ss.str().c_str(), ios::out);
      draw_slice_stream = &ds;
    }
    if(_print_result) {
      stringstream ss;
      ss << file_name.str();
      if (_invert)
        ss << "_inv";
      ss << ".txt";
      cout << "  Prints slicing result to: " << ss.str() << endl;
      ps.open(ss.str().c_str(), ios::out);    
      print_slice_stream = &ps;
    }
  }

  // Do the actual slicing
  SliceOnStmtsAndPrintAndDraw2(start_stmts, draw_slice_stream, print_slice_stream);

  if(ds.is_open()) ds.close();
  if(ps.is_open()) ps.close();
}

void
CCommandSlice::
SliceOnVarsAndPrintAndDraw(std::set<unsigned int> * start_vars, std::string name)
{
  // Create files and streams to print and draw to
  std::ostream * draw_slice_stream=NULL;
  ofstream ds;

  std::ostream * print_slice_stream=NULL;
  ofstream ps;

  if(_draw_result || _print_result) {
    stringstream file_name; 
    file_name << "_ALFSlicing_" << name << "_";
    if(_direction == ALFSlicing::BACKWARD)
      file_name << "backward";
    else
      file_name << "forward";
    if(_draw_result) {
      stringstream ss;
      ss << file_name.str() << ".dot";
      cout << "  Draws slicing result to: " << ss.str() << endl;
      ds.open(ss.str().c_str(), ios::out);    
      draw_slice_stream = &ds;
    }
    if(_print_result) {
      stringstream ss;
      ss << file_name.str() << ".txt";
      cout << "  Prints slicing result to: " << ss.str() << endl;
      ps.open(ss.str().c_str(), ios::out);    
      print_slice_stream = &ps;
    }
  }

  // Do the actual slicing
  SliceOnVarsAndPrintAndDraw2(start_vars, draw_slice_stream, print_slice_stream);

  if(ds.is_open()) ds.close();
  if(ps.is_open()) ps.close();
}

 
void
CCommandSlice::
SliceOnStmtsAndPrintAndDraw2(std::set<alf::AStmt *> * start_stmts, std::ostream * ds, std::ostream * ps) 
{
  // Create temporary sets
  std::set<alf::AStmt *> stmts;
  std::set<CALFAbsAnnot *> annots;
  std::set<alf::CAllocTuple *> allocs; 
  std::set<alf::CInitTuple *> inits;
  std::set<unsigned int> vars;
  
  // Do the slicing and maybe draw the result
  _slicing_algo->GetSliceOfStmts(start_stmts, _direction, &stmts, &annots, &allocs, &inits, &vars, ds);
  
  if(_print_result) {
    PrintResultingSlice(ps, &stmts, &vars);
  }
}

// Start vars holds the variables to start the slice upon. If several
// variables have the same name (due to local and global scoping) only
// one of them will be selected. If dir=f all code and data
// potentially affected by var(s) are derived.  This is made by first
// deriving all statements which may use the var(s) and then do a
// forward from these statements.  If dir=b all code and data
// potentially affecting var(s) are derived. This is made by first
// deriving all statements where var(s) may be defined.  We then do a
// backward slice upon these nodes. Can not be used together with ent
// or vars.

void
CCommandSlice::
SliceOnVarsAndPrintAndDraw2(std::set<unsigned int> * start_vars, std::ostream * ds, std::ostream * ps) 
{
  // Create temporary sets
  std::set<alf::AStmt *> stmts;
  std::set<CALFAbsAnnot *> annots;
  std::set<alf::CAllocTuple *> allocs; 
  std::set<alf::CInitTuple *> inits;
  std::set<unsigned int> vars;

  if(_direction == ALFSlicing::FORWARD) {
    _slicing_algo->GetAffectedByVarsSlice(start_vars, &stmts, &annots, &allocs, &inits, &vars, ds);
  }
  else {
    _slicing_algo->GetAffectingVarsSlice(start_vars, &stmts, &annots, &allocs, &inits, &vars, ds);
  }

  if(_print_result) {
    PrintResultingSlice(ps, &stmts, &vars);
  }
}

void
CCommandSlice::
PrintResultingSlice(std::ostream * ps, std::set<alf::AStmt *> * stmts, std::set<unsigned int> * vars)
{
   // Print statements
   if(_print_res_stmts) {
      (*ps) << "stmts: ";

      // if there are source code mappings available
      if (const CSourceLoader *sl = alf::AStmt::GetSourceLoader()) {
         // determine all source code positions that have at least one
         // corresponding ALF statement remaining in the slice
         std::set<CAlfLabelSource> srcs; // for sorting the source code positions and removing duplicates
         for (auto si = stmts->begin(), sn = stmts->end(); si != sn; ++si) {
            if (const CAlfLabelSource *src = (*si)->GetSourceInfo())
               srcs.insert(*src);
         }

         if (!_invert) {
            // print the source code positions
            for (auto si = srcs.begin(), sn = srcs.end(); si != sn; ++si)
               (*ps) << *si << ' ';
         } else {
            // compute the complement, `inv_srcs', of `srcs'
            std::set<CAlfLabelSource> inv_srcs;
            for (auto si = sl->IterBegin(), sn = sl->IterEnd(); si != sn; ++si)
               inv_srcs.insert(*si->second);
            for (auto si = srcs.begin(), sn = srcs.end(); si != sn; ++si)
               inv_srcs.erase(*si);
            // print the source code positions
            for (auto si = inv_srcs.begin(), sn = inv_srcs.end(); si != sn; ++si)
               (*ps) << *si << ' ';
         }
      } else {
         if (!_invert) {
            for (auto si = stmts->begin(), sn = stmts->end(); si != sn; ++si)
               (*ps) << (*si)->Name() << ' ';
         } else {
            // compute the complement, `inv_stmts', of `stmts'
            CAlfTreeFilter ast_filter(_ast);
            CAlfTreeFilter::NodeList all_stmts = ast_filter.GetNodesOfType(CGenericNode::TYPE_STMT);
            set<const CGenericNode*> inv_stmts(all_stmts.begin(), all_stmts.end());
            for (auto si = stmts->begin(), sn = stmts->end(); si != sn; ++si)
               inv_stmts.erase(*si);
            // print the statements
            for (auto si = inv_stmts.begin(), sn = inv_stmts.end(); si != sn; ++si) {
               assert(dynamic_cast<const alf::AStmt*>(*si));
               string name = ((const alf::AStmt*)*si)->Name();
               // skip function scopes, which don't have a label
               if (!name.empty())
                  (*ps) << name << ' ';
            }
         }
      }
      (*ps) << endl;
   }

   // Print functions
   if(_print_res_funcs) {
      (*ps) << "funcs: ";

      // Collect the functions of the statements
      std::set<alf::CFuncTuple*> funcs;
      for(std::set<alf::AStmt *>::iterator stmt = stmts->begin(); stmt != stmts->end(); ++stmt) {
         CGenericNode * node = (*stmt)->GetParent(CGenericNode::TYPE_FUNC_TUPLE);
         alf::CFuncTuple * func = dynamic_cast<alf::CFuncTuple *>(node);
         funcs.insert(func);
      }

      if (!_invert) {
         // Print all functions
         for(std::set<alf::CFuncTuple *>::iterator func = funcs.begin(); func != funcs.end(); ++func) {
            (*ps) << (*func)->Name() << ' ';
         }
      } else {
         // compute the complement, `inv_funcs', of `funcs'
         std::set<alf::CFuncTuple*> inv_funcs;
         for (unsigned i = 0, n = _symtab->KeyRange(); i < n; ++i) {
            if (_symtab->Exist(i)) {
               const CSymTabEntry *entry = _symtab->Lookup(i);
               if (entry->IsFunction()) {
                  inv_funcs.insert(dynamic_cast<alf::CFuncTuple*>(entry->GetCodeIdentifier()->GetFunction()));
               }
            }
         }
         for (auto fi = funcs.begin(), fn = funcs.end(); fi != fn; ++fi) {
            inv_funcs.erase(*fi);
         }
         // print the functions in `inv_funcs'
         for (auto fi = inv_funcs.begin(), fn = inv_funcs.end(); fi != fn; ++fi) {
            (*ps) << (*fi)->Name() << ' ';
         }
      }
      (*ps) << endl;
   }

   if (!(_print_res_globals || _print_res_locals || _print_res_scoped_locals))
      return;

   // divide the variables into globals and locals
   std::set<unsigned> globals, locals;
   if (!_invert) {
      for (auto vi = vars->begin(), vn = vars->end(); vi != vn; ++vi) {
         const CSymTabEntry *entry = _symtab->Lookup(*vi);
         assert(entry->IsData());
         if (entry->IsGlobal())
            globals.insert(*vi);
         else
            locals.insert(*vi);
      }
   } else {
      // inverted slice: first collect all globals and locals in the program
      for (unsigned i = 0, n = _symtab->KeyRange(); i < n; ++i) {
         if (_symtab->Exist(i)) {
            const CSymTabEntry *entry = _symtab->Lookup(i);
            if (entry->IsData()) {
               if (entry->IsGlobal())
                  globals.insert(i);
               else
                  locals.insert(i);
            }
         }
      }
      // subtract the variables that remain in the slice to get its complement
      for (auto vi = vars->begin(), vn = vars->end(); vi != vn; ++vi) {
         const CSymTabEntry *entry = _symtab->Lookup(*vi);
         assert(entry->IsData());
         if (entry->IsGlobal())
            globals.erase(*vi);
         else
            locals.erase(*vi);
      }
   }

   // Print globals
   if(_print_res_globals) {
      (*ps) << "globals: ";
      for(std::set<unsigned int>::iterator var = globals.begin(); var != globals.end(); ++var) {
         const CSymTabEntry * entry = _symtab->Lookup(*var);
         (*ps) << entry->Name() << ' ';
      }
      (*ps) << endl;
   }

   // Print locals
   if(_print_res_locals) {
      (*ps) << "locals: ";
      for(std::set<unsigned int>::iterator var = locals.begin(); var != locals.end(); ++var) {
         const CSymTabEntry * entry = _symtab->Lookup(*var);
         (*ps) << entry->Name() << ' ';
      }
      (*ps) << endl;
   }

   // Print scoped locals
   if(_print_res_scoped_locals) {
      (*ps) << "scoped locals: ";
      for(std::set<unsigned int>::iterator var = locals.begin(); var != locals.end(); ++var) {
         const CSymTabEntry * entry = _symtab->Lookup(*var);

         // Get the allocation corresponding to the symbol identifier
         const CSymTabIdentifier * id = entry->GetIdentifier();
         assert(id);
         const CAllocTuple * alloc = dynamic_cast<const CAllocTuple *>(id);
         assert(alloc);

         // Get and print the function it belongs to 
         CGenericNode * func_node = alloc->GetParent(CGenericNode::TYPE_FUNC_TUPLE);
         assert(func_node);
         alf::CFuncTuple * func = dynamic_cast<alf::CFuncTuple *>(func_node);
         assert(func);
         (*ps) << func->Name() << '.';

         // Get and print the scope statement it belongs to (if any). 
         CGenericNode * scope_node = alloc->GetParent(CGenericNode::TYPE_SCOPE_TUPLE);
         if(scope_node) {
            alf::CScopeTuple * scope = dynamic_cast<alf::CScopeTuple *>(scope_node);
            assert(scope);
            string scope_name = scope->Name();
            if (!scope_name.empty()) {
               (*ps) << scope_name << '.';
            }
         }

         // Print variable name 
         (*ps) << entry->Name() << ' ';
      }
      (*ps) << endl;
   }

}
 
} // end namespace cmd
