// $Id $

#ifndef CCOMMAND_PRINT_H_INCLUDED
#define CCOMMAND_PRINT_H_INCLUDED

#include "CCommand.h"
#include "graphs/cfg/CFlowGraph.h"
#include "graphs/cg/CCallGraph.h"

namespace cmd {

class CSession;

/** \class CCommandPrint
   Print graphs on simple form
*/
class CCommandPrint : public CCommandPrintFile
{
public:
  typedef enum KEY { GRAPHS, CFG, CFGD, CG, SG, AST, ASTL, EXPL, IMPL, PA, SYMTAB, FILE_NAME, STDOUT } KEY;

   ~CCommandPrint();

   /** Throws a runtime exception if a file is specified and it can not be
      written to. */
   void Validate(const CSession *session);

   /** Prints the specified graphs. */
   void Execute(const CSession *session);

   CCommand *Copy() const;

   /** To get if we should do printouts after linkage. Will be investigated by parse command */
   bool PrintASTAfterLinkage() const { return _astl; } 
   bool HasASTAfterLinkageFileName() const { return _astl_file_name != ""; }
   std::string ASTAfterLinkageFileName() const { return _astl_file_name; }
   bool PrintExportsAfterLinkage() const { return _expl; } 
   bool HasExportsAfterLinkageFileName() const { return _expl_file_name != ""; }
   std::string ExportsAfterLinkageFileName() const { return _expl_file_name; }
   bool PrintImportsAfterLinkage() const { return _impl; } 
   bool HasImportsAfterLinkageFileName() const { return _impl_file_name != ""; }
   std::string ImportsAfterLinkageFileName() const { return _impl_file_name; }

protected:

   /** Help function for printing CFGs */
   void PrintCFGAsBNFGrammar(std::ostream &o, CFlowGraph * cfg, CCallGraph * cg);

   /** internals */
   bool _astl;
   std::string _astl_file_name;
   bool _expl;
   std::string _expl_file_name;
   bool _impl;
   std::string _impl_file_name;
};

}

#endif
