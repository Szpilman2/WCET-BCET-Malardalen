// $Id $

#ifndef CCOMMAND_CREATE_TIMING_FOR_ALF_BASIC_BLOCKS_USING_COST_LOOKUP_TABLE_H_INCLUDED
#define CCOMMAND_CREATE_TIMING_FOR_ALF_BASIC_BLOCKS_USING_COST_LOOKUP_TABLE_H_INCLUDED

#include "CCommand.h"

namespace cmd {

class CSession;

/** \class CCommandCreateTimingForAlfBasicBlocksUsingCostLookupTable
   Creates a timing data base file where ALF basic blocks have been assigned
   timings.
*/
class CCommandCreateTimingForAlfBasicBlocksUsingCostLookupTable : public CCommand
{
public:

  typedef enum KEY { CLT, TDB } KEY;
  
  /** Throws a runtime exception if the file(s) can not
      be read from or written to. */
  void Validate(const CSession *session);
  
  /** Create tdb using clt. */
  void Execute(const CSession *session);
  
  CCommand *Copy() const { return new CCommandCreateTimingForAlfBasicBlocksUsingCostLookupTable(*this); }
  
protected:

  // Holds the name of the files to read in and write to
  std::string clt_filename;
  std::string tdb_filename;
};

}

#endif
