// $Id $

#include "CCommandAE.h"
#include "CCommandDomain.h"
#include "CCommandParse.h"
#include "CCommandLoadMap.h"
#include "CSession.h"
#include "ae/AlfAbstractExecution.h"
#include "ae/CCollector.h"
#include "graphs/ecfg/CECFG.h"
#include "graphs/scopes/CScopeGraph.h"
#include "graphs/scopes/CreateScopes.h"
#include "program/CGenericProgram.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CImportsTuple.h"
#include "program/alf/CFRefList.h"
#include "program/alf/CLRefList.h"
#include "program/alf/CFRefTuple.h"
#include "program/alf/CLRefTuple.h"
#include "tools/Timer.h"
#include "globals.h"
#include <vector>
#include <stdexcept>
#include <sstream>

using namespace std;

namespace cmd {

CCommandAE::
~CCommandAE()
{
   if (ae_settings) {
      delete ae_settings;
   }
   for(unsigned i=0; i<collectors.size(); ++i) {
      delete collectors[i];
   }
   for(unsigned i=0; i<sc_maps.size(); ++i) {
     delete sc_maps[i];
   }
   delete scope_graph;
}

CCommand *
CCommandAE::
Copy() const
{
   assert(ae_settings==NULL);
   return new CCommandAE(*this);
}

void
CCommandAE::
Validate(const CSession *session)
{

   // Create the settings data structure
   ae_settings = new AESettings();

   bool do_merge = false;
   // ---------------------------------
   // Handle merge options
   // ---------------------------------
   {
      // Get the merging options
      const CCommandArgument *merge_argument = GetArgument(MERGE);
      vector <int> merge_modes = merge_argument->GetVal()->AsKeySet();

      // Check that not the alternative "none" and some specific merge are specified together
      AssertUniqueAlternative(merge_argument, NONE);

      // Transfer the merge points to the settings
      for (unsigned i=0; i<merge_modes.size(); ++i) {
         int merge_code = merge_modes[i];
         switch (merge_code)
         {
         case NONE:
            memset(&ae_settings->merge, false, sizeof(ae_settings->merge));
            do_merge = false;
            break;
         case ALL:
            memset(&ae_settings->merge, true, sizeof(ae_settings->merge));
            do_merge = true;
            break;
         case FE:
            ae_settings->merge.fe = true;
            do_merge = true;
            break;
         case FR:
            ae_settings->merge.fr = true;
            do_merge = true;
            break;
         case LE:
            ae_settings->merge.le = true;
            do_merge = true;
            break;
         case BE:
            ae_settings->merge.be = true;
            do_merge = true;
            break;
         case JE:
            ae_settings->merge.je = true;
            do_merge = true;
            break;
         }
      }
   }

   // ---------------------------------
   // Handle flow fact generation option
   // ---------------------------------
   {
      // Set all ffg settings to false
      memset(&ae_settings->ffg, false, sizeof(ae_settings->ffg));
      // Get the list of flow fact generation options
      const CCommandArgument *ffg_argument = GetArgument(FFG);
      vector <int> ffg_modes = ffg_argument->GetVal()->AsKeySet();

      // First, check if the ALL_FFGS, UB_FFGS or LB_FFGS option has been used 
      bool all_ffg_modes_set = false;
      for (unsigned i=0; i<ffg_modes.size(); ++i) {
        cmd::CCommandAE::FFG_KEY ffg_mode = (cmd::CCommandAE::FFG_KEY) ffg_modes[i];
          if(ffg_mode == ALL_FFGS_NO_INSE) {
            memset(&ae_settings->ffg, true, sizeof(ae_settings->ffg)); 
	       ae_settings->SetFFGMode(cmd::CCommandAE::INSE, false);
          all_ffg_modes_set = true;
        }
        if(ffg_mode == ALL_FFGS) {
          memset(&ae_settings->ffg, true, sizeof(ae_settings->ffg)); 
          all_ffg_modes_set = true;
        }
        else if(ffg_mode == LB_FFGS) {
          ae_settings->SetFFGMode(cmd::CCommandAE::LHSS);
          ae_settings->SetFFGMode(cmd::CCommandAE::LHSF);
          ae_settings->SetFFGMode(cmd::CCommandAE::LHSP);
          ae_settings->SetFFGMode(cmd::CCommandAE::LHPF);
          ae_settings->SetFFGMode(cmd::CCommandAE::LHPP);
          ae_settings->SetFFGMode(cmd::CCommandAE::LNSS);
          ae_settings->SetFFGMode(cmd::CCommandAE::LNSF);
          ae_settings->SetFFGMode(cmd::CCommandAE::LNSP);
          ae_settings->SetFFGMode(cmd::CCommandAE::LNPS);
          ae_settings->SetFFGMode(cmd::CCommandAE::LNPF);
          ae_settings->SetFFGMode(cmd::CCommandAE::LNPP);
          ae_settings->SetFFGMode(cmd::CCommandAE::LESS);
          ae_settings->SetFFGMode(cmd::CCommandAE::LESF);
          ae_settings->SetFFGMode(cmd::CCommandAE::LESP);
          ae_settings->SetFFGMode(cmd::CCommandAE::LCSF);
          ae_settings->SetFFGMode(cmd::CCommandAE::LCSP);
          ae_settings->SetFFGMode(cmd::CCommandAE::LBNS);
        }
        else if(ffg_mode == UB_FFGS) {
          ae_settings->SetFFGMode(cmd::CCommandAE::UHSS);
          ae_settings->SetFFGMode(cmd::CCommandAE::UHSF);
          ae_settings->SetFFGMode(cmd::CCommandAE::UHSP);
          ae_settings->SetFFGMode(cmd::CCommandAE::UHPF);
          ae_settings->SetFFGMode(cmd::CCommandAE::UHPP);
          ae_settings->SetFFGMode(cmd::CCommandAE::UNSS);
          ae_settings->SetFFGMode(cmd::CCommandAE::UNSF);
          ae_settings->SetFFGMode(cmd::CCommandAE::UNSP);
          ae_settings->SetFFGMode(cmd::CCommandAE::INSE);
          ae_settings->SetFFGMode(cmd::CCommandAE::INSA);
          ae_settings->SetFFGMode(cmd::CCommandAE::UNPS);
          ae_settings->SetFFGMode(cmd::CCommandAE::UNPF);
          ae_settings->SetFFGMode(cmd::CCommandAE::UNPP);
          if(!do_merge) ae_settings->SetFFGMode(cmd::CCommandAE::INPA);
          ae_settings->SetFFGMode(cmd::CCommandAE::UESS);
          ae_settings->SetFFGMode(cmd::CCommandAE::UESF);
          ae_settings->SetFFGMode(cmd::CCommandAE::UESP);
          ae_settings->SetFFGMode(cmd::CCommandAE::UCSF);
          ae_settings->SetFFGMode(cmd::CCommandAE::UCSP);
          ae_settings->SetFFGMode(cmd::CCommandAE::UBNS);
        }
      }
      
      // Second, check if other ffg options shuld be set
      if(!all_ffg_modes_set) {
        for (unsigned i=0; i<ffg_modes.size(); ++i) {
          cmd::CCommandAE::FFG_KEY ffg_mode = (cmd::CCommandAE::FFG_KEY) ffg_modes[i];
          ae_settings->SetFFGMode(ffg_mode); 
        }
      }
   }

   // ---------------------------------
   // Handle type counting options
   // ---------------------------------
   {
     ae_settings->simple_count_printout_in_tc = false;
     // Set all stuff to false as default
     memset(&ae_settings->tc_arg, false, sizeof(ae_settings->tc_arg));
     
     // Check if type counting should be performed
     if(GetArgument(TC) != NULL) {
       ae_settings->tc = true; 
       // Get the type counting options
       const CCommandArgument *tc_argument = GetArgument(TC);
       vector <int> tc_modes = tc_argument->GetVal()->AsKeySet();
       // Transfer the things to keep track of to the settings
       for (unsigned i=0; i<tc_modes.size(); ++i) {
         int tc_code = tc_modes[i];
         switch (tc_code)
           {
           case ALL_TYPES:
             memset(&ae_settings->tc_arg, true, sizeof(ae_settings->tc_arg));
             break;
           case GEN_NODES:
             ae_settings->tc_arg.gn = true;
             break;
           case OPS:
             ae_settings->tc_arg.op = true;
             break;
           case STMTS:
             ae_settings->tc_arg.st = true;
             break;
           case STMT_PAIRS:
             ae_settings->tc_arg.sp = true;
             break;
           case SIMPLE_COUNT_PRINTOUT:
             ae_settings->simple_count_printout_in_tc = true;
             break;
         }
       }
     }
     else {
       ae_settings->tc = false;
     } 
   }

   // ---------------------------------
   // Handle bcet and wcet estimate generation based on ALF AST node cost lookup table options
   // ---------------------------------
   {
     // Set default values 
     ae_settings->aac_clt_name = "";
     ae_settings->aac = GetArgument(ALF_AST_NODE_BCET_WCET) != NULL;
     // We must use type counting together with aac and aacd
     if(ae_settings->aac && !ae_settings->tc)
       throw runtime_error("It is not possible to use parameter aac without tc.");   
     // If we should read the cost lookup table from a file
     if(ae_settings->aac) {
       const CCommandArgument *aac_argument = GetArgument(ALF_AST_NODE_BCET_WCET);
       ae_settings->aac_clt_name = aac_argument->GetVal()->AsString();
       AssertFileAccessability(ae_settings->aac_clt_name, "r"); 
     }  
   }
   {
     // Check if we should generate BCET and WCET paths
     ae_settings->aacpaths = GetArgument(ALF_AST_NODE_BCET_WCET_PATHS) != NULL;
     if(ae_settings->aacpaths && !ae_settings->aac) {
       throw runtime_error("It is not possible to use parameter aacpaths without aac.");   
     }
   }
   {
     // Check if we should generate BCET and WCET profiles
     ae_settings->aacprof = GetArgument(ALF_AST_NODE_BCET_WCET_PROF) != NULL;
     if(ae_settings->aacprof && !ae_settings->aac) {
       throw runtime_error("It is not possible to use parameter aacprof without aac.");
     }
   }

   // ---------------------------------
   // Handle bcet and wcet estimate generation based on basic block cost lookup table options
   // ---------------------------------
   {
     // Set default values 
     ae_settings->bbc_clt_name = "";
     ae_settings->bbc = GetArgument(BB_COST_BCET_WCET) != NULL;
     if(ae_settings->bbc) {
       const CCommandArgument *bbc_argument = GetArgument(BB_COST_BCET_WCET);
       ae_settings->bbc_clt_name = bbc_argument->GetVal()->AsString();
       AssertFileAccessability(ae_settings->bbc_clt_name, "r"); 
     }  
   }
   {
     // Check if we should generate BCET and WCET paths
     ae_settings->bbcp = GetArgument(BB_COST_BCET_WCET_PATHS) != NULL;
     if(ae_settings->bbcp && !ae_settings->bbc) {
       throw runtime_error("It is not possible to use parameter bbcpaths without bbc.");   
     }
   }
    
   // ---------------------------------
   // Handle bcet and wcet estimate generation based on old version of 
   // ALF AST node cost lookup table options
   // ---------------------------------
   {
     // Set default values 
     ae_settings->oaac_clt_name = "";
     ae_settings->oaac = GetArgument(OLD_ALF_AST_NODE_BCET_WCET) != NULL;
     // We must use type counting together with aac and aacd
     if(ae_settings->oaac && !ae_settings->tc)
       throw runtime_error("It is not possible to use parameter aac without tc.");   
     // If we should read the cost lookup table from a file
     if(ae_settings->oaac) {
       const CCommandArgument *aac_argument = GetArgument(OLD_ALF_AST_NODE_BCET_WCET);
       ae_settings->oaac_clt_name = aac_argument->GetVal()->AsString();
       AssertFileAccessability(ae_settings->oaac_clt_name, "r"); 
     }  
   }

   // ---------------------------------
   // Determine debugging type
   // ---------------------------------
   {
      const CCommandArgument* debug_arg = GetArgument(DEBUG);
      if (debug_arg != 0)
      {
         switch (debug_arg->GetVal()->AsKey())
         {
         case INTERACTIVE_DEBUGGER:
            ae_settings->debug = AESettings::INTERACTIVE;
            break;
         case DEBUG_TRACE:
            ae_settings->debug = AESettings::TRACE;
            break;
         };
      }
   }

   // ---------------------------------
   // Determine fall through treatment
   // ---------------------------------
   {
      const CCommandArgument* ft_arg = GetArgument(FT);
      if (ft_arg != 0) {
         switch (ft_arg->GetVal()->AsKey())
         {
            case CONTINUE:
               g_ft_continue = true;
               g_ft_warn= false;
               break;
            case DO_NOT_CONTINUE:
               g_ft_continue = false;
               g_ft_warn = false;
               break;
            case DO_NOT_CONTINUE_WARN:
               g_ft_continue = false;
               g_ft_warn = true;
               break;
         };
      }
   }

   // ---------------------------------
   // Determine volatile treatment
   // ---------------------------------
   {
     ae_settings->iv = false;
     ae_settings->tv = false;
     const CCommandArgument* vola_arg = GetArgument(VOLA);
     if (vola_arg != 0) {
       switch (vola_arg->GetVal()->AsKey())
       {
          case IGNORE_VOLATILES:
            ae_settings->iv = true;
            break;
          case TOP_VOLATILES:
            ae_settings->tv = true;
            break;
       };
     }
   }

   // ---------------------------------
   // Determine if the correct domain is chosen
   // ---------------------------------
   {
      ae_settings->iv = false;
      ae_settings->tv = false;
      const CCommandArgument* vola_arg = GetArgument(VOLA);
      if (vola_arg != 0) {
         switch (vola_arg->GetVal()->AsKey())
         {
            case IGNORE_VOLATILES:
               ae_settings->iv = true;
               break;
            case TOP_VOLATILES:
               ae_settings->tv = true;
               break;
         };
      }
   }
   
   // ---------------------------------
   // Handle remaining AE settings
   // ---------------------------------
   {
      ae_settings->df = GetArgument(DF) != NULL;
      ae_settings->usm = GetArgument(USM) != NULL;
      ae_settings->op = GetArgument(OP) != NULL;
      ae_settings->css = GetArgument(CSS) != NULL;
      ae_settings->ene = GetArgument(ENE) != NULL;
      ae_settings->pu = GetArgument(PU) != NULL;
      // Some default values (may be overwritten) 
      ae_settings->gtf_name = "";
      ae_settings->rtf_name = "";

      // Derive file name to write trace to (if any)
      ae_settings->gtf = GetArgument(GENERATE_TRACE_FILE) != NULL;
      if(ae_settings->gtf) {
        const CCommandArgument *gtf_argument = GetArgument(GENERATE_TRACE_FILE);
        ae_settings->gtf_name = gtf_argument->GetVal()->AsString();
        AssertFileAccessability(ae_settings->gtf_name, "w"); 
      }

      // Derive file name to read traces from (if any)
      ae_settings->rtf = GetArgument(READ_TRACE_FILE) != NULL;
      if(ae_settings->rtf) {
        const CCommandArgument *rtf_argument = GetArgument(READ_TRACE_FILE);
        ae_settings->rtf_name = rtf_argument->GetVal()->AsString();
        AssertFileAccessability(ae_settings->rtf_name, "r"); 
      }  

      // Check that we do not try to read and write traces simultaneously.
      if(ae_settings->gtf && ae_settings->rtf) {
        throw runtime_error("It is not possible to both read and generate traces during same run of AE.");
      }

      // The global g_ignore_stores_to_int_addr is set here directly, instead of having
      // an "isi" variable in AESettings.
      g_ignore_stores_to_int_addr = GetArgument(ISI) != NULL;
   }

  // std::cerr << "CCommandAE::Validate 6\n";

   // ---------------------------------
   // Do some additional checking
   // ---------------------------------
   {
     CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
     // If the input format is CFG and we are running abstract execution, then a 
     // trace input file must also have been given.
     if(command_parse != NULL) {
       if((command_parse->GetProgramLanguage() == CCommandParse::CFG) && !ae_settings->rtf) {
         throw runtime_error("When running AE upon a CFG an input trace file must be provided (using -x rtf=<file-name>)");
       }
     }
   }

   //   std::cerr << "CCommandAE::Validate end\n";
}

const AESettings *
CCommandAE::
GetAESettings() const
{
   return ae_settings;
}

const FlowFactTypes *
CCommandAE::
GetFlowFactTypes() const
{
   return &ae_settings->ffg;
}

void
CCommandAE::
Execute(const CSession *session)
{
   // The following 3 are our inputs: ast (the program), scope graph (for the flow facts) and domain settings.

   // We need the program to analyze...
   CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
   CGenericProgram *generic_ast = command_parse->GetAst();
   const alf::CAlfTuple * alf_ast = dynamic_cast<const alf::CAlfTuple*>(generic_ast);

   // If we have not specified that undefines should be processed and
   // the program contains undefines a error should be generated.
   if(!ae_settings->pu && !ae_settings->rtf && alf_ast && alf_ast->HasImportedLRefsOrFRefs()) {
      ostringstream msg;
      msg << "AE can't be run on code containing undefines/imports without the process-undefines (pu) option set.";
      auto imports = alf_ast->GetImports();
      auto frefs = imports->GetFRefList();
      auto lrefs = imports->GetLRefList();
      if (frefs->ElementCount() > 0) {
         msg << "\n\nUndefined frefs are:";
         for (auto i = frefs->ConstIterator(), n = frefs->InvalidIterator(); i!=n; ++i) {
            auto coord = (*i)->GetCoord();
            msg << "\n\t" << (*i)->Name() << " (" << *coord.source_file << ':' << coord.line << ':' << coord.col << ')';
         }
      }
      if (lrefs->ElementCount() > 0) {
         msg << "\n\nUndefined lrefs are:";
         for (auto i = lrefs->ConstIterator(), n = lrefs->InvalidIterator(); i!=n; ++i) {
            auto coord = (*i)->GetCoord();
            msg << "\n\t" << (*i)->Name() << " (" << *coord.source_file << ':' << coord.line << ':' << coord.col << ')';
         }
      }
      throw runtime_error(msg.str());
   }

   // If the program contains volatiles one of iv and tv must be set 
   if(alf_ast->HasVolatileInits() && (!ae_settings->tv && !ae_settings->iv)) {
     throw runtime_error("AE can't be run on program containing volatiles without having the vola flag set!");
   }

   // We need annotations if they exist
   CALFAbsAnnotStorage * abs_annots = command_parse->GetAnnotStorage();
   CALFOutAnnotSpecStorage * out_ann_specs = command_parse->GetOutAnnotSpecStorage();

   // Try to load map file
   CSourceLoader *source_loader = 0;
   if(session->HasCommand(COption::LOAD_MAP)) {
      CCommandLoadMap *load_map_command =
         dynamic_cast<CCommandLoadMap *> (session->GetCommand(COption::LOAD_MAP));
      source_loader = load_map_command->GetSourceLoader();
   }

   // We need the scope graph to annotate it with flow facts
   CCallGraph *call_graph = command_parse->GetCallGraph();
   CCallGraphNode *start_node = command_parse->GetStartNode();
   scope_graph = new CScopeGraph(new CECFG());
   const CSteensgaardPA *pa = command_parse->GetPointerAnalysis();
   CreateScopes::ContextSensitive(scope_graph, call_graph, start_node, generic_ast->GetSymTab(), *pa);

   // Currently we process the domain settings separately, so this is not used. But maybe we should use it.
   CCommandDomain *command_domain = dynamic_cast<CCommandDomain *> (session->GetCommand(COption::ABS_DOMAIN));
   ae_settings->domain_settings = command_domain->GetDomainSettings();
  
   // Timer timer;

   // Do the work - the appropriate flow fact containter will be updated with the flow facts.
   AlfAbstractExecution(alf_ast, collectors, sc_maps, abs_annots, out_ann_specs, source_loader, scope_graph, ae_settings);

   // double ae_time = timer.GetTime();
   // cout << "Abstract execution finished in " << (1000 * ae_time) << " milliseconds" << endl;
}

}
