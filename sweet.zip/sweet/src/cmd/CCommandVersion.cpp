// $Id $

#include "CCommandVersion.h"
#include "version.h"
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

namespace cmd {

void
CCommandVersion::Execute(const CSession *session) {
   cout << "This executable was built " << BUILD_DATE << " from SVN revision " << SWEET_VERSION << " (" << SWEET_DATE << ")" << endl;
   }
}
