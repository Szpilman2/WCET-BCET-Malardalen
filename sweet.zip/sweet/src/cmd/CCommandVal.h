#ifndef COMMAND_VAL_H_
#define COMMAND_VAL_H_

#include "CKeyword.h"
#include <string>
#include <vector>
#include <cassert>

namespace cmd {

class CVal;

/** \class CCommandVal
   Contains a the actual value of a command as given on the command line. This
   is the result of a user input value that matches an allowed value.
*/
class CCommandVal
{
public:
   /** Constructs a command value of string type.
      \param val A pointer to an allowed value whose properties matches this
         actual command value.
      \param strval The string value. */
   CCommandVal(const CVal *val,
               std::string strval) :
                  //val(val),
                  strval(strval),
                  has_string(true),
                  has_key(false),
                  has_key_set(false),
                  has_int(false)
               { }

   /** Constructs a command value of keyword type.
      \param val A pointer to an allowed value whose properties matches this
         actual command value.
      \param key The keyword value. */
   CCommandVal(const CVal *val,
               CKeyword key) :
                  //val(val),
                  key(key),
                  has_string(false),
                  has_key(true),
                  has_key_set(false),
                  has_int(false)
               { }

   /** Constructs a command value containing a set of values of keyword type.
      \param val A pointer to an allowed value whose properties matches this
         actual command value.
      \param key_set The set of key values. */
   CCommandVal(const CVal *val,
                  std::vector <int> key_set) :
                  //val(val),
                  key_set(key_set),
                  has_string(false),
                  has_key(false),
                  has_key_set(true),
                  has_int(false)
               { }

   /** Constructs a command value of integer type.
      \param val A pointer to an allowed value whose properties matches this
         actual command value.
      \param intval The integer value. */
   CCommandVal(const CVal *val,
               int intval) :
                  //val(val),
                  intval(intval),
                  has_string(false),
                  has_key(false),
                  has_key_set(false),
                  has_int(true)
               { }

   /** \returns The string value of this actual command value.
      \pre This actual command value was constructed as string value. */
   std::string  AsString() const { assert(has_string); return strval; }

   /** \returns The key value of this actual command value.
      \pre This actual command value was constructed as keyword value. */
   int AsKey() const { assert(has_key); return key.GetCode(); }

   /** \returns The a set of key value sof this actual command value.
      \pre This actual command value was constructed as a set of keywords value. */
   std::vector <int> AsKeySet() const { assert(has_key_set); return key_set; }

   /** \returns The integer value of this actual command value.
      \pre This actual command value was constructed as integer value. */
   int AsInt() const { assert(has_int); return intval; }

private:
   //const CVal *val;
   std::string strval;
   CKeyword key;
   std::vector <int> key_set;
   int intval;
   bool has_string;
   bool has_key;
   bool has_key_set;
   bool has_int;
};
}

#endif
