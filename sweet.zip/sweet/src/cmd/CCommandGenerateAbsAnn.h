// $Id $

#ifndef CCOMMAND_GENERATE_ABS_ANN_H_INCLUDED
#define CCOMMAND_GENERATE_ABS_ANN_H_INCLUDED

#include "CCommand.h"

namespace cmd {

class CSession;

/** \class CCommandGenerateAbsAnn
   Tries to generate abstract annotation templates to undefined (imported)
   names that are referenced in some statement(s).
*/
class CCommandGenerateAbsAnn : public CCommand
{
public:

   /** Throws a runtime exception if the (specified) file can not
      be written to. */
   void Validate(const CSession *session);

   /** Performs the generation. */
   void Execute(const CSession *session);

   CCommand *Copy() const { return new CCommandGenerateAbsAnn(*this); }

private:
};

}

#endif
