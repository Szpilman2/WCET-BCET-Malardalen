#ifndef KEYWORD_H
#define KEYWORD_H

#include <string>

namespace cmd {

/** \class  CKeyword
   Contains a specification of an allowed keyword value.
*/
class CKeyword
{
public:
   /** Constructs a temporary keyword, whose content needs to be replaced by
      copying in order to become a legal keyword. */
   CKeyword() : code(0), is_default(false) { }

   /** Constructs a proper keyword.
      \param code A key to be internally used in internal (C++) references
         to this keyword.
      \param name The actual keyword, to be matched with the user input from
         the command line.
      \param description An optional description to be used when allowed
         options are displayed.
      \post \a IsDefault() returns false. */
   CKeyword(int code, std::string name, std::string description="") :
               code(code),
               name(name),
               description(description),
               is_default(false)
               { }

   /** \return The internal code of this keyword. */
   int GetCode() const { return code; }

   /** \return The actual keyword text. */
   std::string GetName() const { return name; }

   /** \return The description of this keyword. */
   std::string GetDescription() const { return description; }

   /** \return True if this keyword is the default one among the keywords in
      the same value. */
   bool IsDefault() const { return is_default; }

   /** Set the "default" property of this keyword.
      \post \a IsDefault() returns true. */
   CKeyword &operator*() { is_default = true;  return *this; }

private:
   int code;
   std::string name;
   std::string description;
   bool is_default;
};
}
#endif
