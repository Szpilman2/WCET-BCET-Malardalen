#ifndef AVAILABLE_OPTIONS_H_
#define AVAILABLE_OPTIONS_H_

#include <memory>

namespace cmd {

class COptionGroups;

/** \return A pointer to a set of groups of all allowed options. */
std::unique_ptr <COptionGroups> AvailableOptions();
}

#endif
