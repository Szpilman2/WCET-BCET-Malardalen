#include "CCommandExtractFuncCGsAndInfo.h"

#include "cmd/CSession.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CFuncTuple.h"
#include "program/alf/CArgDeclList.h"
#include "cmd/CCommandParse.h"
#include "cmd/CCommandLoadMap.h"
#include "CSession.h"
#include "CCommands.h"
#include "COption.h"
#include "program/CGenericFunction.h"
#include "program/CGenericStmt.h"
#include "program/alf/AStmt.h"
#include "tools/CSourceLoader.h"

#include <stdexcept>
#include <sstream>
#include <vector>

using namespace std;

namespace cmd {

void
CCommandExtractFuncCGsAndInfo::
Validate(const CSession *session)
{
  { 
    // ---------------------------------
    // Derive what to print
    // ---------------------------------
    const CCommandArgument *print_argument = GetArgument(PRINT);
    if(print_argument) {
      // Set default values
      _extract_alf = false;
      _extract_imports = false;
      _extract_exports = false;
      _extract_annot_template = false;
      _extract_map = false;
      _extract_info = false;

      // Transfer the print modes to the settings
      std::vector<int> print_modes = print_argument->GetVal()->AsKeySet();
      for (unsigned i=0; i<print_modes.size(); ++i) {
        int print_code = print_modes[i];
        switch (print_code) {
        case ALL:
          _extract_alf = true;
          _extract_imports = true;
          _extract_exports = true;
          _extract_annot_template = true;
          _extract_map = true;
          _extract_info = true;
          break;
        case ALF:
          _extract_alf = true;
          break;
        case IMPORTS:
          _extract_imports = true;
          break;
        case EXPORTS:
          _extract_exports = true;
          break;
        case ANNOT_TEMPLATE:
          _extract_annot_template = true;
          break;
        case MAP:
          _extract_map = true;
          break;
        case INFO:
          _extract_info = true;
        }
      }
    }
    else {
      // Set default values
      _extract_alf = true;
      _extract_imports = true;
      _extract_exports = true;
      _extract_annot_template = true;
      _extract_map = true;
      _extract_info = true;
    }
  }
  
  { // ---------------------------------
    // Extract directory path (if any)
    // ---------------------------------
    const CCommandArgument *dir_argument = GetArgument(DIR);
    if(dir_argument) 
      _extract_dir = dir_argument->GetVal()->AsString();
    else
      _extract_dir = "";
  }

  { // --------------------------------- 
    // Extract the list of all functions to extract
    // --------------------------------- 
    std::string func_names_string = GetVal()->AsString();
    size_t scan_start = 0;
    size_t match_pos;
    do {
      // Extract next function name from the list
      match_pos = func_names_string.find(',', scan_start);
      size_t length = match_pos - scan_start;
      std::string func_name = func_names_string.substr(scan_start, length);
      scan_start = match_pos + 1;
      
      // Check that the fname.alf, fname.imports, and fname.exports etc.
      // can be written to
      if(_extract_alf) {
        std::string alf_file_name = _extract_dir + func_name + ".alf";
        AssertFileAccessability(alf_file_name, "w");
      }
      if(_extract_imports) {
        std::string imports_file_name = _extract_dir + func_name + ".imports";
        AssertFileAccessability(imports_file_name, "w");
      }
      if(_extract_exports) {
        std::string exports_file_name = _extract_dir + func_name + ".exports";
        AssertFileAccessability(exports_file_name, "w");
      }
      if(_extract_annot_template) {
        std::string annot_template_file_name = _extract_dir + func_name + ".template.annot";
        AssertFileAccessability(annot_template_file_name, "w");
      }
      if(_extract_map) {
        std::string map_file_name = _extract_dir + func_name + ".map";
        AssertFileAccessability(map_file_name, "w");
      }
      if(_extract_info) {
        std::string info_file_name = _extract_dir + func_name + ".info";
        AssertFileAccessability(info_file_name, "w");
      }
      // Keep the function name for later
      _extract_func_names.push_back(func_name);
    } while (match_pos != std::string::npos);
  }
}

void
CCommandExtractFuncCGsAndInfo::
Execute(const CSession *session)
{
  // Get needed stuff from CCommandParse
  CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
  CGenericProgram *prog = command_parse->GetAst();
  alf::CAlfTuple * ast = dynamic_cast<alf::CAlfTuple*>(prog);
  const CSteensgaardPA *pa = command_parse->GetPointerAnalysis();
  CCallGraph * cg = command_parse->GetCallGraph();
  const std::vector<CFlowGraph*> & flow_graphs = command_parse->GetFlowGraphs();

  // Get neded stuff from CCommandLoadMap if it has been provided
  CSourceLoader * sl = NULL;
  if(session->HasCommand(COption::LOAD_MAP)) {
    CCommandLoadMap *command_load_map = dynamic_cast<CCommandLoadMap *> (session->GetCommand(COption::LOAD_MAP));
    sl = command_load_map->GetSourceLoader();
  }

  { // Check that all function names to extract are present in the ast
    std::stringstream errornous_extract_func_names;
    bool has_errornous_extract_func_names = false;
    for(std::list<std::string>::iterator extract_func_name = _extract_func_names.begin();
        extract_func_name != _extract_func_names.end(); extract_func_name++) {
      const CSymTabEntry *sym_tab_entry = ast->GetSymTab()->Lookup(*extract_func_name);
      if(sym_tab_entry == NULL || !sym_tab_entry->IsFunction()) {
        errornous_extract_func_names << *extract_func_name << " ";
        has_errornous_extract_func_names = true;
      }
    }
    if(has_errornous_extract_func_names) {
      std::string error_message = "The following start function(s) does not exist in this alf program: " +
        errornous_extract_func_names.str();
      throw runtime_error(error_message);
    }
  }

  // Go through all the function names to extract info for
  for(std::list<std::string>::iterator extract_func_name = _extract_func_names.begin();
      extract_func_name != _extract_func_names.end(); extract_func_name++) {
    
    // Derive the functions in the call graph that are reachable from
    // the node corresponding to the given start function.
    const CSymTabEntry *sym_tab_entry = ast->GetSymTab()->Lookup(*extract_func_name);
    CGenericFunction *start_function = sym_tab_entry->GetCodeIdentifier()->GetFunction();
    CCallGraphNode *start_cg_node = cg->FindNodeOfFunction(start_function);
    std::list<CCallGraphNode*> reachable_call_graph_nodes;
    cg->FindFlowComponent(start_cg_node, &reachable_call_graph_nodes);

      // Derive all the ids of things in the AST that can be
    // referenced by the temporary call graph
    set<CSymTabBase::KeyType> referenced_ids;
    command_parse->GetIdsPossiblyReferencedFromCallGraphNodes(referenced_ids, &reachable_call_graph_nodes);
      
    if(_extract_alf) { 
      // Print reduced AST to file
      std::string extract_file_name = _extract_dir + (*extract_func_name) + ".alf";
      cout << "  Prints reduced AST to: " << extract_file_name << endl;
      command_parse->PrintASTFiltered(ast, referenced_ids, extract_file_name);
    }
      
    if(_extract_imports) {
      // Print imports of reduced AST to file
      std::string import_file_name = _extract_dir + (*extract_func_name) + ".imports";
      cout << "  Prints imports for reduced AST to: " << import_file_name << endl;
      command_parse->PrintImportsAsTextFiltered(ast, referenced_ids, import_file_name);
    }

    if(_extract_exports) {
      // Print exports of reduced AST to file
      std::string export_file_name = _extract_dir + (*extract_func_name) + ".exports";
      cout << "  Prints exports for reduced AST to: " << export_file_name << endl;
      command_parse->PrintExportsAsTextFiltered(ast, referenced_ids, export_file_name);
    }
    
    if(_extract_annot_template) { 
      // Print annotation template for undefs of reduced AST to file
      std::string annot_file_name = _extract_dir + (*extract_func_name) + ".template.annot";
      cout << "  Prints annot template for reduced AST to: " << annot_file_name << endl;
      bool use_old_style_templates = false;
      if(use_old_style_templates) {
        std::vector<CGenericFunction *> reachable_funcs;
        for(std::list<CCallGraphNode*>::iterator cg_node = reachable_call_graph_nodes.begin();
            cg_node != reachable_call_graph_nodes.end(); cg_node++) {
          reachable_funcs.push_back((*cg_node)->Function());
        }
        command_parse->PrintAnnotationTemplate(ast, pa, &flow_graphs, referenced_ids, 
                                               &reachable_funcs, annot_file_name);
      }
      else {
        command_parse->PrintAnnotationTemplate(ast, annot_file_name, start_function, &referenced_ids);
      }
    }

    if(_extract_map && sl != NULL) { 
      // Print map file for reduced AST 
      std::string map_file_name = _extract_dir + (*extract_func_name) + ".map";
      cout << "  Prints map for reduced AST to: " << map_file_name << endl;
      // Get the labels of all statements in the reachable functions
      std::set<std::string> labels_to_include;
      for(std::list<CCallGraphNode*>::iterator cg_node = reachable_call_graph_nodes.begin();
          cg_node != reachable_call_graph_nodes.end(); cg_node++) {
        // Get the function 
        CGenericFunction * func = (*cg_node)->Function();
        alf::CFuncTuple * func_tuple = dynamic_cast<alf::CFuncTuple *>(func);
        assert(func_tuple);
        
        // Include the label of the function in the set
        std::string func_name = func_tuple->Name();
        labels_to_include.insert(func_name);
        
        // Get all the statements in the function
        std::vector<CGenericStmt*> stmts;
        func_tuple->GetStmtsInFunctionScopeAndSubordinateScopes(&stmts);
        
        // Include the labels of all the statements in the set
        for(std::vector<CGenericStmt*>::iterator stmt = stmts.begin(); stmt != stmts.end(); ++stmt) {
          alf::AStmt * astmt = dynamic_cast<alf::AStmt *>(*stmt);
          assert(astmt);
          std::string stmt_name = astmt->Name();
          labels_to_include.insert(stmt_name);
        }
      }
      
      // Print the map file only including the derived labels
      sl->PrintToFileFiltered(map_file_name, &labels_to_include);
    }

    if(_extract_info) {
      std::string info_file_name = _extract_dir + (*extract_func_name) + ".info";
      cout << "  Prints extra vecu info for reduced AST to: " << info_file_name << endl;
      ofstream out(info_file_name.c_str());
      out << "EXTRA_VECU_STATS (lref imports, fref imports, start-func-args, volatiles, addr volatiles, funcs, loops):\t";
      out << command_parse->GetNrOfLRefImportsFiltered(ast, referenced_ids) << "\t";
      out << command_parse->GetNrOfFRefImportsFiltered(ast, referenced_ids) << "\t";
      alf::CFuncTuple * start_function_as_func_tuple = dynamic_cast<alf::CFuncTuple *>(start_function); 
      if(start_function_as_func_tuple)
        out << start_function_as_func_tuple->GetArgs()->ElementCount() << "\t";
      else 
        out << "0\t";
      out << command_parse->GetNrOfVolatileInitsFiltered(ast, referenced_ids) << "\t"; 
      out << command_parse->GetNrOfAddrVolatileInitsFiltered(ast, referenced_ids) << "\t"; 
      out << reachable_call_graph_nodes.size() << "\t";
      unsigned nr_of_loops = 0;
      for(std::list<CCallGraphNode*>::iterator cg_node = reachable_call_graph_nodes.begin();
          cg_node != reachable_call_graph_nodes.end(); cg_node++) {
        nr_of_loops += (*cg_node)->FlowGraph()->GetNrOfLoops();
      }
      out << nr_of_loops << endl;
    }
  }
}

}
