#ifndef SESSION_H_
#define SESSION_H_

#include "COption.h"
#include <string>
#include <vector>
#include <cassert>

namespace cmd {

class CCommand;
class CCommands;

/** \class CSession
   Processes a SWEET session.
*/
class CSession
{
public:

   ~CSession();

   /** Set a command vector into this session. The vector is owned by the
      caller.
      \param commands A pointer to a set of commands as a vector.
      \pre All elements in \a commands are syntactically valid.
      \pre The elements in \a commands are sorted according to the
         precedence in thier corresponding option specification.*/
   void SetCommands(CCommands *commands);

   /** Ask all commands to validate (e.g. the semantic of its parameters, other
      options existence etc.). The validation order is the same as the dispatch
      order.
      \pre \a SetCommands() has been called. */
   void ValidateCommands() const;

   /** Execute the commands in \a commands sequentially. The dispatch order is
      the order of the commands in the command vector.
      \pre \a SetCommands() has been called. */
   void DispatchCommands() const;

   /** Look up a certain command in the set of commands that it holds
      \param key The option key of the command to look up.
      \return A pointer to the command.
      \pre HasCommand() returns true. */
   CCommand *GetCommand(COption::KEY key) const;

   /** Look up a certain command in the set of commands that it holds
      \param key The option key of the command to look up.
      \return True if found else false.
      \pre \a SetCommands() has been called. */
   bool HasCommand(COption::KEY key) const;

private:
   CCommands *commands;
};
}
#endif
