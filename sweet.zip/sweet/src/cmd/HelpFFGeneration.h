#ifndef HELPFFGENERATION_H_
#define HELPFFGENERATION_H_

namespace help_ff_gen {

/** Shows help information about sweets options in a formatted way.
*/
void HelpFFGeneration(bool no_csi=false);

}

#endif
