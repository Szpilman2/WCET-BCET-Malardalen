// $Id $

#include "CCommandPrintNice.h"
#include "CCommandParse.h"
#include "CCommandLoadMap.h"
#include "CCommandPDG.h"
#include "CCommandRD.h"
#include "CSession.h"
#include "graphs/scopes/CScopeGraph.h"
#include "graphs/scopes/CScope.h"
#include "graphs/scopes/CreateScopes.h"
#include "graphs/scopes/PrintHierarchy.h"
#include "graphs/cfg/CFlowGraph.h"
#include "graphs/ecfg/CECFG.h"
#include "graphs/cg/CCallGraph.h"
#include "program/CGenericProgram.h"
#include "program/cfgs/Function.h"
#include "alf_slicing/ALFExtendedProgramDependencyGraph.h"

#include <iostream>
#include <fstream>
#include <stdexcept>
#include <limits.h>

using namespace std;

namespace cmd {

void
CCommandPrintNice::
Validate(const CSession *session)
{
   ValidateFiles(session, FILE_NAME, GRAPHS, ".dot");

   for (unsigned i=0; i<output_settings.outputs.size(); ++i)
   {
      OutputSettings::Output output = output_settings.outputs[i];
      switch (output.key)
      {
         case CFG_WITH_C:
         {
         if (!session->HasCommand(COption::LOAD_MAP)) {
            throw runtime_error("If you want to annotate the CFG with C code, you also need to provide a mapping file.");
         }
         break;
         }
         case CFG:
         case CG:
         break;
         case RSG:
         case FSG: {
            const CCommandArgument *max_levels_argument = GetArgument(MAX_LEVELS);
            if (max_levels_argument) {
               int max_levels = max_levels_argument->GetVal()->AsInt();
               if (max_levels < 1) {
                  throw runtime_error("The number of maximum levels must be positive.");
               }
            }
         }
         break;
         case PDG:
         case PCFG:
         case PCDG:
         case PDDG:
         {
         if(!session->HasCommand(COption::PDG)) {
            throw runtime_error("If you want to print PDG, PCFG, PCDG or PDDG, the -pdg option must be used.");
         }
         break;
         }
      }
   }
}

CScopeGraph *
CCommandPrintNice::
PrepareScopes(const CSession *session)
{
   CScopeGraph *scope_graph;
   CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
   CCallGraphNode *start_node = command_parse->GetStartNode();
   const CCommandArgument *dag_argument = GetArgument(DAG);
   if (dag_argument)
   {
      scope_graph = CreateScopes::ScopeDAG(start_node);
   }
   else
   {
      CCallGraph *call_graph = command_parse->GetCallGraph();
      scope_graph = new CScopeGraph(new CECFG());
      CGenericProgram *ast = command_parse->GetAst();
      const CSteensgaardPA *pa = command_parse->GetPointerAnalysis();
      CreateScopes::ContextSensitive(scope_graph, call_graph, start_node, ast->GetSymTab(), *pa);
   }
   return scope_graph;
}

void
CCommandPrintNice::
PrintAllCFGs(CCommandParse *command_parse, string file_name, const CSourceLoader *source_loader)
{
   const vector<CFlowGraph*> &flow_graphs = command_parse->GetFlowGraphs();
   ofstream o;
   o.open(file_name.c_str());
   o << "digraph CFG {" << endl;
   o << "size=\"10,8\"" << endl;
   o << "rankdir=\"TB\"" << endl;
   o << "orientation=\"portrait\"" << endl;
   o << "fontsize=10;" << endl;
   for (unsigned j=0; j<flow_graphs.size(); ++j) {
      CFlowGraph *flow_graph = flow_graphs[j];
      flow_graph->PrintAsDot(o, source_loader);
   }
   o << "}" << endl;
   o.close();
}

void
CCommandPrintNice::
Execute(const CSession *session)
{
   CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
   bool use_tool_tips = GetArgument(USE_TOOL_TIPS) != NULL;
   
   string input_file_name = command_parse->GetProgramFileName();
   for (unsigned i=0; i<output_settings.outputs.size(); ++i) {
      OutputSettings::Output output = output_settings.outputs[i];
      switch (output.key) {
         case CFG_WITH_C: {
            CCommandLoadMap *load_map_command = dynamic_cast<CCommandLoadMap *> (session->GetCommand(COption::LOAD_MAP));
            PrintAllCFGs(command_parse, output.file_name, load_map_command->GetSourceLoader());
            break;
         }
         case CFG: {
            PrintAllCFGs(command_parse, output.file_name);
            break;
         }
         case CG: {
            FILE *fp = fopen(output.file_name.c_str(), "w");
            CCallGraph *call_graph = command_parse->GetCallGraph();
            call_graph->PrintGraphically(fp, input_file_name);
            fclose(fp);
            break;
         }
         case RSG:
         case FSG: {
            unique_ptr<CScopeGraph> scope_graph( PrepareScopes(session) );
            FILE *fp = fopen(output.file_name.c_str(), "w");
            
            const CCommandArgument *function_argument = GetArgument(FUNCTION);
            CScope * function_scope;
            if (function_argument) {
               string function_name = function_argument->GetVal()->AsString();
               std::vector<CScope*> function_scopes;
               scope_graph->FunctionScopes(&function_scopes);
               int hit = 0;
               for(std::vector<CScope*>::iterator function_scope_it = function_scopes.begin();
                   function_scope_it != function_scopes.end(); ++function_scope_it) {
                  if (function_name == (*function_scope_it)->Function()->Name()) {
                     hit++;
                     function_scope = *function_scope_it;
                  }
               }
               if (hit == 0) throw runtime_error("The given function is not included in the scope graph.");
               if (hit > 1) throw runtime_error("The given function appears more than once in the scope graph, select another function.");
            } else {
               function_scope = scope_graph->RootScope();
            }
            
            const CCommandArgument *max_levels_argument = GetArgument(MAX_LEVELS);
            int max_levels;
            if (max_levels_argument) {
               max_levels = max_levels_argument->GetVal()->AsInt();
            } else {
               max_levels = INT_MAX; // Means "all levels"
            }
            
            if (output.key == RSG) function_scope->PrintGraphically(fp, input_file_name, scope_graph->RootScope(), max_levels, true);
            if (output.key == FSG) function_scope->PrintGraphically(fp, input_file_name, scope_graph->RootScope(), max_levels, false);
            fclose(fp);
            break;
         }
         case SGH: {
            ofstream fs;
            fs.open(output.file_name.c_str(), ios::out);
            unique_ptr<CScopeGraph> scope_graph( PrepareScopes(session) );
            GenerateScopeTreeHierarchyAsDot(fs, input_file_name, scope_graph.get(), use_tool_tips);
            if (fs.is_open()) {
               fs.close();
            }
            break;
         }
         case PDG: {
            ofstream fs;
            fs.open(output.file_name.c_str(), ios::out);
            CCommandPDG *command_pdg = dynamic_cast<CCommandPDG *> (session->GetCommand(COption::PDG));
            ALFExtendedProgramDependencyGraph * pdg = command_pdg->GetPDG();
            assert(pdg);
            pdg->Draw(fs);
            if (fs.is_open()) {
               fs.close();
            }
            break;
         }
         case PCFG: {
            ofstream fs;
            fs.open(output.file_name.c_str(), ios::out);
            CCommandRD *command_rd = dynamic_cast<CCommandRD *> (session->GetCommand(COption::RD));
            ALFExtendedProgramControlFlowGraph * pcfg = command_rd->GetPCFG();
            assert(pcfg);
            pcfg->Draw(fs);
            if (fs.is_open()) {
               fs.close();
            }
            break;
         }
         case PCDG: {
            ofstream fs;
            fs.open(output.file_name.c_str(), ios::out);
            CCommandPDG *command_pdg = dynamic_cast<CCommandPDG *> (session->GetCommand(COption::PDG));
            ALFExtendedProgramControlDependencyGraph * pcdg = command_pdg->GetPCDG();
            assert(pcdg);
            pcdg->Draw(fs);
            if (fs.is_open()) {
               fs.close();
            }
            break;
         }
         case PDDG: {
            ofstream fs;
            fs.open(output.file_name.c_str(), ios::out);
            CCommandPDG *command_pdg = dynamic_cast<CCommandPDG *> (session->GetCommand(COption::PDG));
            ALFExtendedProgramDataDependencyGraph * pddg = command_pdg->GetPDDG();
            assert(pddg);
            pddg->Draw(fs);
            if (fs.is_open()) {
               fs.close();
            }
            break;
         }
      }
   }
}

}
