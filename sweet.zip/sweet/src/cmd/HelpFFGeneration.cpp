#include "HelpFFGeneration.h"
#include <iostream>
#include <sstream>

using namespace std;

namespace help_ff_gen {

// Help macros to define colors
#define CSI_BLUE     std::string("\033[34m")
#define CSI_CYAN     std::string("\033[36m")
#define CSI_YELLOW   std::string("\033[33m")
#define CSI_GREEN    std::string("\033[32m")
#define CSI_MAGENTA  std::string("\033[35m")
#define CSI_BOLD     std::string("\033[1m")
#define CSI_RESET    std::string("\033[0m")

// Help functions
std::string make_title(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return X;
}

std::string make_command(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return CSI_BOLD + CSI_MAGENTA + X + CSI_RESET;
}

std::string make_ffact(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return CSI_BOLD + X + CSI_RESET;
}

std::string make_term(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return CSI_BOLD + X + CSI_RESET;
}

std::string make_code(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return CSI_BOLD + CSI_CYAN + X + CSI_RESET;
}

// Help macros for avoiding writing whole function calls
#define TITLE(X) make_title(X,no_csi)
#define COMMAND(X) make_command(X,no_csi)
#define FFACT(X) make_ffact(X, no_csi)
#define TERM(X) make_term(X, no_csi)
#define CODE(X) make_code(X, no_csi)

// The function printing the actual help text. Bool decides
// if CSI highlighting should be use or not
void HelpFFGeneration(bool no_csi)
{
cout  
<< endl
<< TITLE("HELP TEXT FOR SWEET'S FLOW FACT GENERATION") << endl
<< TITLE("------------------------------------------") << endl
<< endl
<< "SWEET can produce flow information in several different formats." << endl
<< "Basically, flow information gives safe lower and/or upper bounds" << endl
<< "on how how many times different code entities, such as control-" << endl
<< "flow graph nodes or edges, are executed in different program" << endl
<< "contexts. For programs with many different execution paths, the flow" << endl
<< "information provides lower and/or upper bounds of the collected" << endl
<< "execution behaviour of all these paths." << endl
<< endl
<< "SWEET's value annotations (see " << COMMAND("sweet -h annot") << ") can be used to specify" << endl
<< "constraints on possible input values of a program. The derived bounds" << endl
<< "holds for all possible concrete input value combinations and" << endl
<< "their corresponding program executions. For example, if the" << endl
<< "following code snippet may be run with input value x equal to 0, 1, or" << endl
<< "2, then an upper bound on the number of times node BB0 (the loop" << endl
<< "header node) may be taken is 3 (given by x=0) and a lower bound is 1" << endl
<< "(given by x=2):" << endl
<< endl
<< CODE("  int func(int x) {") << endl
<< CODE("    while(x < 2)  // BB0") << endl
<< CODE("       x++;") << endl
<< CODE("    return x;") << endl
<< CODE("  }") << endl
<< endl
<< "The given bound on BB0's executions is actually a local bound, valid" << endl
<< "each time func is entered. If we, for example, consider BB0's" << endl
<< "executions in a global program context, i.e. a bound on the number " << endl
<< "of times BB0 can be taken during the whole program's execution, it " << endl
<< "might be a value much larger than 3 (if func can be called several " << endl
<< "times during program execution)." << endl
<< endl
<< "SWEET allows flow information to be derived and also to be expressed " << endl
<< "in different contexts. For example loop bounds can be derived and " << endl
<< "given both in a function-local or in a program-global context. Also, " << endl
<< "flow information can be constrained to only hold in certain function " << endl
<< "call-string contexts." << endl
<< endl
<< endl;

cout
<< "The context-sensitive valid-at-entry-of flow fact format" << endl
<< "--------------------------------------------------------" << endl
<< endl
<< "The (new) format for SWEETs flow information is called 'context-sensitive" << endl
<< "valid-at-entry-of flow facts'. Each generated flow fact has the following" << endl
<< "format (see end of document for a BNF grammar):" << endl
<< endl
<< TERM("CALL_STRING : VALID_AT_ENTRY_OF : FOREACH_OR_TOTAL : CONSTRAINT ;") << endl
<< endl
<< "- " << TERM("CALL_STRING") << " is a list of function calls that must have been executed for" << endl
<< "  the flow fact to hold. The calls start with the program start function." << endl
<< "  The call string is represented as a list of " << endl
<< TERM(" ((calling_func, calling_stmt), called_func)") << " tuples." << endl
<< endl
<< "- " << TERM("VALID_AT_ENTRY_OF") << " is a function or a loop in a function. The flow" << endl
<< "  fact holds each time the given function or loop is entered until it is" << endl
<< "  exited. It provides a way to give flow information in a local, semi-" << endl
<< "  local or global context. When referring to functions the " << endl 
<< "  " << TERM("VALID_AT_ENTRY_OF") << " is a function identifier, while referring to loops it " << endl
<< "  is a (func, stmt) tuple." << endl
<< endl
<< "- " << TERM("FOREACH_OR_TOTAL") << " is " << TERM("<>, <i..j>") << " (foreach type) or " << TERM("[]") << " (total type). " << endl
<< "  -- " << TERM("FOREACH <>") << " concerns iterations of loops, and specifies" << endl
<< "     that the flow fact is valid for each individual iteration of the loop" << endl
<< "     specified in " << TERM("VALID_AT_ENTRY_OF") << endl
<< "  -- " << TERM("FOREACH <i..j>") << " concerns iterations of loops, and specifies " << endl
<< "     that that flow fact holds for each individual iteration starting" << endl
<< "     at the i:th and ending at the j:th iteration of the loop. The " << endl
<< "     iteration (i.e. what i and j are compared against) of a loop is " << endl
<< "     assumed to be reset every time the loop is entered and incremented" << endl
<< "      every time the loop header node is taken." << endl
<< "  -- " << TERM("TOTAL []") << " concerns either a function or a loop, and " << endl
<< "     specifies that the flow fact is valid for the sum of executions, from the " << endl
<< "     entry to exit of the " << TERM("VALID_AT_ENTRY_OF") << "." << endl
<< endl
<< "- " << TERM("CONSTRAINT") << " is a linear constraint relating the execution of program" << endl
<< "   entities, such as nodes, (e.g., BB0) or edges, (e.g., BB0->BB1)" << endl
<< "   in the program CFGs to integer constants." << endl
<< endl
<< endl;

cout
<< "Illustrative example on the usage of call-strings and entry-of " << endl
<< "-------------------------------------------------------------- " << endl
<< endl
<< "Consider the following code snippet:" << endl
<< endl
<< CODE("  main() {        // BB0") << endl
<< CODE("    baz(3);       // BB1") << endl
<< CODE("    foo(5);       // BB2") << endl
<< CODE("  }") << endl
<< endl
<< CODE("  foo(int x) {    // BB3") << endl
<< CODE("    bar(x);       // BB4") << endl
<< CODE("    bar(x-1);     // BB5") << endl
<< CODE("  }") << endl
<< endl
<< CODE("  baz(int z) {    // BB6 ") << endl
<< CODE("    for(i=0; i<2; i++)") << endl
<< CODE("      bar(z);     // BB7") << endl
<< CODE("  }") << endl
<< endl
<< CODE("  bar(int y) {    // BB8") << endl
<< CODE("    int i=0;") << endl
<< CODE("    while(i < y)  // BB9") << endl
<< CODE("      i++; ") << endl
<< CODE("  }") << endl
<< endl
<< "We note that bar is called from several places and that the loop" << endl
<< "in bar execute differently depending on the argument bar was" << endl
<< "called with. Assuming that we want to express (and derive) a loop" << endl
<< "bound on the loop in bar we can do this in a number of ways:" << endl
<< endl
<< "- We can have a loop bound which is valid each time bar is entered," << endl
<< "  (i.e. a local loop bound) independently on what function calls made" << endl
<< "  to reach bar. The loop bound is expressed as a constraint on the" << endl
<< "  number of times the loop header node may be executed (note the empty" << endl
<< "  call string) (e.g. given by " << COMMAND("sweet -ae ffg=uhsf csl=0") << "):" << endl
<< FFACT("    : bar : [] : BB9 <= 6 ; ") << endl
<< "  " << endl
<< "- We can have local loop bounds valid for each entry of bar, for each" << endl
<< "  possible call string down to bar (e.g. given by " << COMMAND("sweet -ae ffg=uhsf -f") << "):" << endl
<< FFACT("    ((main,BB1),baz) ((baz,BB7),bar) : bar : [] : BB9 <= 4 ;") << endl
<< FFACT("    ((main,BB2),foo) ((foo,BB4),bar) : bar : [] : BB9 <= 6 ;") << endl
<< FFACT("    ((main,BB2),foo) ((foo,BB5),bar) : bar : [] : BB9 <= 5 ;") << endl
<< "  Note that we differ between the two call-sites in foo to bar. " << endl
<< endl
<< "- We can have a global loop bound, providing a bound on the number " << endl
<< "  of times BB9 may be taken valid for the whole program execution" << endl
<< "  (e.g. given by " << COMMAND("sweet -ae ffg=uhsp csl=0") << "):" << endl
<< FFACT("    : main : [] : BB9 <= 19 ;") << endl
<< "  Note that bar is called twice in baz." << endl
<< endl
<< "- We can have local loop bounds valid for each entry of bar, but separated" << endl
<< "  on each individual one-length call-strings, i.e. we give different local" << endl
<< "  loop bounds for the loop in bar dependant on if the execution reached bar" << endl
<< "  through baz or foo (e.g. given by " << COMMAND("sweet -ae ffg=uhsf csl=1") << "):" << endl
<< TERM("    ((main,BB1),baz) : bar : [] : BB9 <= 4 ;") << endl
<< TERM("    ((main,BB2),foo) : bar : [] : BB9 <= 6 ;") << endl
<< endl
<< endl;

cout
<< "Illustrative example on valid-at-entry-of loop flow facts" << endl
<< "----------------------------------------------------------" << endl
<< endl
<< "The above examples only provided flow facts valid for an entry of a" << endl
<< "particular function. We can also give flow facts valid for each entry" << endl
<< "of a particular loop. The loop is identified by its loop header cfg" << endl
<< "node.  The following code snippet, which holds a loop-nest," << endl
<< "illustrates the idea." << endl
<< endl
<< CODE("  bip(int x) {         // BB0") << endl
<< CODE("    int i = 0;         ") << endl
<< CODE("    while(i < x) {     // BB1") << endl
<< CODE("      int j = i;       // BB2") << endl
<< CODE("      while(j < x) {   // BB3") << endl
<< CODE("        j++;           // BB4") << endl
<< CODE("      }") << endl
<< CODE("      i++;             // BB5") << endl
<< CODE("    }") << endl
<< CODE("  }") << endl
<< endl
<< "- Assuming that we provide an input value annotation of x = 1..10 then " << endl
<< "  an upper bound on the number of times that BB1 (the loop header node) " << endl
<< "  can be taken for each entry of the outer loop is 11, given by x=10 " << endl
<< "  (e.g. given by " << COMMAND("sweet -ae ffg=uhss csl=0") << "):" << endl
<< FFACT("    : (bip,BB1) : [] : BB1 <= 11 ;") << endl
<< endl
<< "- For the inner loop we can provide a local loop bound valid for each " << endl
<< "  entry of the inner loop from the outer loop (given by x=10 at first " << endl
<< "  iteration of outer loop) (e.g. given by " << COMMAND("sweet -ae ffg=uhss csl=0") << "):" << endl
<< FFACT("    : (bip,BB3) : [] : BB3 <= 11 ;") << endl
<< endl
<< "- Using the two flow facts given above in a WCET calculation it would" << endl
<< "  be assumed that BB3 will be taken 10*11=110 times each time the bip" << endl
<< "  function is entered (note that loop iterations bounds are given the" << endl
<< "  header nodes). This is however a pessimistic value, since BB3 can" << endl
<< "  actually only be taken 11+10+9+..+2=65 times each time the outer loop" << endl
<< "  is entered. The latter may result in a tighter WCET estimate and can" << endl
<< "  be expressed as (e.g. given by " << COMMAND("sweet -ae ffg=uhsf csl=0") << "):" << endl
<< FFACT("    : bip : [] : BB3 <= 65 ;") << endl
<< endl
<< endl;

cout 
<< "Illustrative example on foreach flow facts" << endl
<< "------------------------------------------" << endl
<< endl
<< "Compared to the total ([]) specifier used in the above examples, the" << endl
<< "foreach specifiers (<>, <i..j>) allow use to give constraints for " << endl
<< "each individual iteration, or some specific iterations of a loop. " << endl
<< "Consider the following code snippet:" << endl
<< endl
<< CODE("  bup(x) {          // BB0") << endl
<< CODE("    int i = 0;") << endl
<< CODE("    while(x <= 3) { // BB1") << endl
<< CODE("      if(x > 0)     // BB2") << endl
<< CODE("        i++;        // BB3") << endl
<< CODE("      else       ") << endl
<< CODE("        i--;        // BB4 ") << endl
<< CODE("      if(x > 2)     // BB5") << endl
<< CODE("        i++;        // BB6") << endl
<< CODE("      else    ") << endl
<< CODE("        i--;        // BB7") << endl
<< CODE("      if(x <= 2)    // BB8") << endl
<< CODE("        i++;        // BB9") << endl
<< CODE("      else ") << endl
<< CODE("        i--;        // BB10") << endl
<< CODE("      x++;          // BB11") << endl
<< CODE("    }") << endl
<< CODE("  }") << endl
<< endl
<< CODE("  main() {          // BB12") << endl
<< CODE("    bup(2);         // BB13") << endl
<< CODE("    bup(1);         // BB14") << endl
<< CODE("  }") << endl
<< endl
<< "First, we can give a number of different loop bound flow facts " << endl
<< "(e.g. given by " << COMMAND(" sweet -ae ffg=uhsf -f") << "):" << endl
<< FFACT("  ((main,BB13),bup) : bup : [] : BB1 <= 3 ;  ") << endl
<< FFACT("  ((main,BB14),bup) : bup : [] : BB1 <= 4 ;  ") << endl
<< "or (e.g. given by " << COMMAND(" sweet -ae ffg=uhsf csl=0") << "):" << endl
<< FFACT("  : bup : [] : BB1 <= 4 ;") << endl
<< "or (e.g. given by " << COMMAND("sweet -ae ffg=uhsp -f") << "): " << endl
<< FFACT("  : main : [] : BB2 <= 7 ; ") << endl
<< endl
<< "We note that the false branch of the BB2 if-fondition will never " << endl
<< "be taken during any loop iteration (i.e. an infeasible node). This " << endl
<< "may be expressed by (e.g. given by " << COMMAND("sweet -ae ffg=insa csl=0") << "): " << endl
<< FFACT("  : (bup,BB1) : <> : BB4 = 0 ;") << endl
<< endl
<< "We also note that the true branches of the BB5 and BB8 if-conditions," << endl
<< "as well as the two false branches, are exclusive, i.e. they can never" << endl
<< "be taken together during any iteration (even though each node may be" << endl
<< "taken during some iteration) (e.g. given by " << COMMAND("sweet -ae ffg=inpa csl=0") << "):" << endl
<< FFACT("  : (bup,BB1) : <> : BB6 + BB9 < 2 ;") << endl
<< FFACT("  : (bup,BB1) : <> : BB7 + BB10 < 2 ;") << endl
<< endl
<< "We can also derive flow information on longer infeasible paths," << endl
<< "i.e. paths structurally possible, but not possible to execute in" << endl
<< "reality due to possible (input) data values. For example, the" << endl
<< "following specifies that nodes BB2, BB3, BB5, BB6, BB8, and BB9 " << endl
<< "never can be taken together during an loop iteration. This can " << endl
<< "be expressed by (e.g. given by " << COMMAND("sweet -ae ffg=inna csl=0") << "):" << endl
<< FFACT("  : (bup,BB1) : <> : BB2 + BB3 +BB5 + BB6 + BB8 + BB9 <= 5 ;") << endl
<< endl
<< "Looking in even more detail we can note that, for each entry of the loop, " << endl
<< "neither BB6 nor BB10 can be taken during the first loop iteration." << endl
<< "This can be expressed by (e.g. given by " << COMMAND("sweet -ae ffg=inse csl=0") << "):" << endl
<< FFACT("  : (bup,BB1) : <1..1> : BB6 = 0 ;") << endl
<< FFACT("  : (bup,BB1) : <1..1> : BB10 = 0 ;") << endl
<< endl
<< endl;

cout
<< "Abstract Execution (AE), recorder and collectors" << endl
<< "-------------------------------------------------" << endl
<< endl
<< "The flow analysis normally used in SWEET is the abstract execution" << endl
<< "(AE), which is a form of symbolic execution based on an abstract" << endl
<< "interpretation (AI) framework. Rather than using traditional" << endl
<< "fixed-point AI iteration, the AE executes the program in the abstract" << endl
<< "domain, with abstract values for the program variables and abstract" << endl
<< "versions of the operators in the language. For instance, the abstract" << endl
<< "domain can be the domain of intervals: each numeric variable will then" << endl
<< "hold an interval rather than a number, and each assignment will" << endl
<< "calculate a new interval from the current intervals held by the" << endl
<< "variables. As usual in AI, the abstract value held by a variable, at" << endl
<< "some point, represents a set containing the actual concrete values" << endl
<< "that the variable can hold at that point. An abstract state is a" << endl
<< "collection of abstract values for all variables at a point." << endl
<< endl
<< "To be able to generate flow facts the AE extends abstract states with" << endl
<< "recorders. The recorders gather information on how a state has been" << endl
<< "executed in a certain part of the program, e.g., how many times" << endl
<< "different nodes or edges have been taken in a specific loop." << endl
<< "Additionally, the program parts for which flow information should be" << endl
<< "derived (e.g. loops), get so called collectors associated to them. The" << endl
<< "collectors are used to successively accumulate recorded information" << endl
<< "from the states. " << endl
<< endl
<< "The AE is turned on in SWEET using the " << COMMAND("-ae") << " argument. The ffg argument," << endl
<< "specifies what flow fact generators to use, basically allowing SWEET" << endl
<< "to set up needed management for the requested recorders and" << endl
<< "collectors. There are many different type of recorders and collectors," << endl
<< "each resulting in the generation of certain type of flow facts. Thus," << endl
<< "the ffg can be given more than one value if several types of flow" << endl
<< "facts should be generated during the same AE run. The values to the" << endl
<< "ffg argument are specified using four different dimensions, (each" << endl
<< "values is provided as a four letter string):" << endl
<< "  1. bounds derived: upper (" << COMMAND("u") << "), lower and upper (" << COMMAND("l") << "), infeasible (" << COMMAND("i") << ").  " << endl
<< "  2. entities kept track of: headers (" << COMMAND("h") << "), nodes (" << COMMAND("n") << "), edges (" << COMMAND("e") << ")," << endl
<< "     call edges (" << COMMAND("c") << "), loop body begin edges (" << COMMAND("b") << ").  " << endl
<< "  3. combination of entities: single (" << COMMAND("s") << "), pairs (" << COMMAND("p") << "), paths (" << COMMAND("n") << "). " << endl
<< "  4. flow fact context: each iteration (" << COMMAND("e") << "), all iterations (" << COMMAND("a") << "), " << endl
<< "     scope (" << COMMAND("s") << "), function (" << COMMAND("f") << "), program (" << COMMAND("p") << ")."<< endl
<< endl
<< "For example, " << COMMAND("-ae ffg=uhss") << " tells the AE to create recorders and" << endl
<< "collectors deriving local upper header bounds, while " << COMMAND("-ae ffg=lnsp") << endl
<< "tells the AE to derive lower and upper bounds on the number of times" << endl
<< "different nodes may be taken during each execution of the program." << endl
<< endl
<< "SWEET builds it flow analysis on a program representation called scope" << endl
<< "graph. Basically, the nodes and edges in different CFGs are divided" << endl
<< "into scopes, where each scope correspond to a loop, function, or" << endl
<< "recursive call-nest. The current version of the scope-graph is fully" << endl
<< "context-sensitive, i.e., if a function is called from several" << endl
<< "different call-sites, each call will result in a new scope for the" << endl
<< "function. The collectors are associated to scopes, and the flow" << endl
<< "information derived by the collectors are therefore context-sensitive" << endl
<< "as well." << endl
<< endl
<< "The old type of flow facts derived by SWEET where also highly connected" << endl
<< "to scopes, basically specifying that a given flow fact should be valid " << endl
<< "for each entry or iteration of a certain scope. For example:" << endl
<< "    loop_scope : [] : BB_loop_header <= 10 ;" << endl
<< endl
<< endl;

cout
<< "Generation of context-sensitive valid-at-entry-of flow facts" << endl
<< "-------------------------------------------------------------" << endl
<< endl
<< "The generation of the new type of context-sensitive valid-at-entry-of" << endl
<< "flow facts are turned on using the argument. It requires the AE to" << endl
<< "have been run and uses flow information collected by collectors" << endl
<< "associated to the scopes in a (fully context-sensitive) scope" << endl
<< "graph. The context-sensitive flow information is then partitioned and" << endl
<< "merged in respect to the context-sensivity (i.e. the call-string" << endl
<< "length) requested. The " << COMMAND("l=<number>") << " option specifies the call-string" << endl
<< "length to use (without giving the " << COMMAND("l") << " option full context-sensitivity" << endl
<< "will be used)." << endl
<< endl
<< "For example, " << COMMAND("sweet -ae ffg=uhsf csl=0") << " specifies that we should derive" << endl
<< "loop bounds for all loops valid at each entry of the function in which" << endl
<< "they belong, and independently on the function calls used to reach the" << endl
<< "function. " << COMMAND("sweet -ae ffg=uhsf csl=2") << " specifies that we should derive" << endl
<< "the same type of loop bounds but differ between call string of length 2" << endl
<< "Similarly, " << COMMAND("sweet -ae ffg=uhsf -f") << " also specifies that function local" << endl
<< "loop bounds should be derived. However, we will use full-context sensitivity," << endl
<< "that is, we will separate between functions which have different call paths. " << endl
<< "For more examples on the usage of the " << COMMAND("-f") << " option, see above." << endl
<< endl
<< "The " << COMMAND("-f") << " argument can currently not be run on recursive programs." << endl
<< endl
<< endl;

cout 
<< "Specification of merge points " << endl
<< "------------------------------" << endl
<< endl
<< "When using abstract values, conditionals cannot always be decided.  In" << endl
<< "these cases, AE must then execute both branches separately in two" << endl
<< "different abstract states.  This means that AE may have to handle many" << endl
<< "abstract states, representing different possible execution paths," << endl
<< "concurrently. The number of possible abstract states may grow" << endl
<< "exponentially with the length of these paths." << endl
<< endl
<< "In order to curb the growing number of paths, merging of abstract" << endl
<< "states for different paths can take place at certain program points" << endl
<< "(so called merge points). If the states are merged using the least" << endl
<< "upper bound operator on the abstract domain of states, then the result" << endl
<< "is one abstract state safely representing all possible concrete" << endl
<< "states. Thus, a single-path abstract execution, representing the" << endl
<< "execution of the different paths, can continue from the merge point." << endl
<< endl
<< "SWEET allow the user to specify the placement of merge points using" << endl
<< "the " << COMMAND("-ae merge=<mergepoint>") << " argument. In principle, using a lot of" << endl
<< "merging (most often) lead to quicker termination of the AE, but might" << endl
<< "lead to less precise flow analysis results. Thus, if SWEET has problem" << endl
<< "finishing its flow analysis within given time limits one or more " << endl
<< "merge points should preferably be used." << endl
<< endl
<< "The possible values to the " << COMMAND("merge") << " argument are:" << endl
<< "   " << COMMAND("none") << " - (default) No merging should be used." << endl
<< "   " << COMMAND("all") << "  - Use all merge points (fe,fe,le,be,je)." << endl
<< "   " << COMMAND("fe") << "   - Each function entry point." << endl
<< "   " << COMMAND("fr") << "   - Each function return point." << endl
<< "   " << COMMAND("le") << "   - Each loop exit edge." << endl
<< "   " << COMMAND("be") << "   - Each back-edge." << endl
<< "   " << COMMAND("je") << "   - Each point of joining edges." << endl
<< endl
<< "Given that one or more merge points values have been specified, SWEET" << endl
<< "first identifies the corresponding merge points in the program and" << endl
<< "secondly constructs an ordering between these merge points. The" << endl
<< "processing of states in the AE are then set to follow this order," << endl
<< "basically forcing a state to wait for all other states which sooner or" << endl
<< "later will reach the same merge node at which the state is located." << endl
<< "Thus, the ordering allow SWEET to maximize the amount of state merging" << endl
<< "and minimize the number of parallel executing states." << endl
<< endl
<< "Merging is in most cases only interesting to use when SWEET are run " << endl
<< "with some input value annotations." << endl
<< endl
<< endl;

cout
<< "BNF grammar for context-sensitive valid-at-entry-of flow facts" << endl
<< "---------------------------------------------------------------" << endl
<< endl
<< "ff_file ->" << endl
<< "  | ff_list" << endl
<< endl
<< "ff_list ->" << endl
<< "  | ff_list ff" << endl
<< "  | ff" << endl
<< endl
<< "ff ->" << endl
<< "  | call_string : valid_at_entry_of : foreach_or_total : constraint ;" << endl
<< endl
<< "call_string ->" << endl
<< "  | call_string call " << endl
<< "  | call" << endl
<< "  |" << endl  
<< endl
<< "call ->" << endl
<< "  | ( ( func , stmt ) , func )" << endl
<< endl
<< "valid_at_entry_of ->" << endl
<< "  | func" << endl
<< "  | ( func , stmt )" << endl
<< endl
<< "foreach_or_total ->" << endl
<< "  | [ ]" << endl     
<< "  | < >              %% Only to be used with ( func, stmt ) " << endl
<< "  | < int .. int >   %% Only to be used with ( func, stmt ) " << endl
<< "                     %% First int should be >= 1 and <= second int." << endl
<< endl
<< "constraint ->" << endl
<< "  | expr < expr " << endl
<< "  | expr <= expr" << endl
<< "  | expr == expr" << endl
<< "  | expr > expr" << endl
<< "  | expr >= expr" << endl
<< endl
<< "expr ->" << endl
<< "  | int" << endl
<< "  | mul_expr + expr" << endl
<< "  | mul_expr - expr" << endl
<< endl
<< "mul_expr ->" << endl
<< "  | int * count_var " << endl
<< "  | count_var " << endl
<< endl
<< "count_var ->" << endl
<< "  | stmt" << endl
<< "  | stmt->stmt" << endl
<< endl
<< "int ->" << endl
<< "  | 'integer'" << endl
<< endl
<< "func ->" << endl
<< "  | 'identifier'" << endl
<< endl
<< "stmt ->" << endl
<< "  | 'identifier'" << endl
<< endl;

} // end function

} // end nsamspace cmd

