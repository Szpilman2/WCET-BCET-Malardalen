#ifndef OPTION_GROUP_H_
#define OPTION_GROUP_H_

#include <string>
#include <vector>

#include "COption.h"

namespace cmd {

/** \class  COptionGroup
   Contains a specification of a set of allowed command line options.
   A group is basically just a container with all options, and an additional
   label.
*/
class COptionGroup : public std::vector <COption>
{
public:
   /** Constructs a new option group.
      \param label A text describing this option group. */
   COptionGroup(std::string label) : label(label) {}

   /** \return The label of this option group. */
   std::string GetLabel() const { return label; }

   /** Adds a new option to this option group. */
   COptionGroup &operator[](COption option) { push_back(option); return *this; }

private:
   std::string label;
};
}

#endif
