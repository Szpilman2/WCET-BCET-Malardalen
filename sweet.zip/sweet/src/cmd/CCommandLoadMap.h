// $Id $

#ifndef CCOMMAND_LOAD_MAP_H_INCLUDED
#define CCOMMAND_LOAD_MAP_H_INCLUDED

#include "CCommand.h"

class CSourceLoader;

namespace cmd {

class CSession;

/** \class CCommandLoadMap
   Loads a file mapping from labels to C-source code.
*/
class CCommandLoadMap : public CCommand
{
public:
  typedef enum KEY { FILE_NAME, READ_C_SOURCE, CHECK_MAP, PAL, CHECK_MAP_FOR_RAPITA_FF } KEY;

   CCommandLoadMap() : read_c_source(false), source_loader(NULL) { }
   ~CCommandLoadMap();

   void Validate(const CSession *session);

   /** Throws a runtime exception if a file with an explicitly
      specified name can not be opened for reading (while open error
      on a generated name is ignored).
      Throws a runtime exception if any file refered in an existing
      map file can not be opened for reading or if the map file is
      malformed.
      \post The mapping information is loaded into memory if existing.
   */
   void Execute(const CSession *session);

   CSourceLoader *GetSourceLoader() const { return source_loader; }

   CCommand *Copy() const;

private:
   std::vector<std::string> file_names;
   bool print_linked_maps;
   std::string linked_file_name;
   bool read_c_source;
   CSourceLoader *source_loader;

   /** Form a .map file name from the name @a alf_file, by extracting the base name of
      @a alf_file and appending ".map" */
   static std::string ToMapFile(const std::string& alf_file);
};

}

#endif
