// $Id $

#include "CCommandGenerateCostLookupTableTemplate.h"
#include "tcalc/CAlfCostLookupTable.h"
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

namespace cmd {

void
CCommandGenerateCostLookupTableTemplate::
Validate(const CSession *session)
{
  // ---------------------------------
  // Check that we have a file to write to
  // ---------------------------------
  assert(session == session);
  _file_name = GetVal()->AsString();
  AssertFileAccessability(_file_name, "w");

  // ---------------------------------
  // Handle type printing options
  // ---------------------------------
  {
    // Check if type counting should be performed
    if(GetArgument(TYPES) != NULL) {

      // Se default value
      _print_prog_run = false;
      _print_gen_nodes = false;
      _print_ops = false;
      _print_stmts = false;
      _print_stmt_pairs = false;

       // Get the type counting options
       const CCommandArgument *types_argument = GetArgument(TYPES);
       vector <int> types_modes = types_argument->GetVal()->AsKeySet();
       // Transfer the things to keep track of to the settings
       for (unsigned i=0; i<types_modes.size(); ++i) {
         int types_code = types_modes[i];
         switch (types_code)
           {
           case ALL_TYPES:
             _print_gen_nodes = true;
             _print_ops = true;
             _print_stmts = true;
             _print_stmt_pairs = true;
	     _print_prog_run = true;
             break;
	   case PROG_RUN:
	     _print_prog_run = true;
	     break;
           case GEN_NODES:
             _print_gen_nodes = true;
             break;
           case OPS:
             _print_ops = true;
             break;
           case STMTS:
             _print_stmts = true;
             break;
           case STMT_PAIRS:
             _print_stmt_pairs = true;
             break;
         }
       }
     }
     else {
       _print_prog_run = true;
       _print_gen_nodes = true;
       _print_ops = true;
       _print_stmts = true;
       _print_stmt_pairs = true;
     } 
  }
}

void
CCommandGenerateCostLookupTableTemplate::
Execute(const CSession *session)
{
  alf::CAlfCostLookupTable::PrintAsTemplate(_file_name, _print_prog_run, 
					    _print_gen_nodes, _print_ops, 
                                            _print_stmts, _print_stmt_pairs);
}

}
