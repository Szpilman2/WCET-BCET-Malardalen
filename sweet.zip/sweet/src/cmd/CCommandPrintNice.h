// $Id $

#ifndef CCOMMAND_PRINT_NICE_H_INCLUDED
#define CCOMMAND_PRINT_NICE_H_INCLUDED

#include "CCommand.h"
#include <string>

class CSourceLoader;
class CScopeGraph;
class CSourceLoader;

namespace cmd {

class CCommandParse;
class CSession;

/** \class CCommandPrintNice
   Print graphs as dot files
*/
class CCommandPrintNice : public CCommandPrintFile
{
public:
  typedef enum KEY { GRAPHS, FILE_NAME, CFG_WITH_C, CFG, CG, RSG, FSG, SGH, DAG, USE_TOOL_TIPS, 
		     PDG, PCFG, PCDG, PDDG, FUNCTION, MAX_LEVELS } KEY;

   /** Throws a runtime exception if the (specified or generated) file can not
      be written to. */
   void Validate(const CSession *session);

   /** Prints the specified graphs. */
   void Execute(const CSession *session);

   CCommand *Copy() const { return new CCommandPrintNice(*this); }

private:
   CScopeGraph *PrepareScopes(const CSession *session);
   void PrintAllCFGs(CCommandParse *command_parse, std::string file_name, const CSourceLoader *source_loader=NULL);
};

}

#endif
