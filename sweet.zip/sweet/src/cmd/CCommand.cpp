// $Id $

#include "CCommand.h"
#include "CCommandParse.h"
#include "CSession.h"
#include <stdexcept>
#include <iostream>
#include <sstream>
#include <cassert>
#include <string>
#include <cstring>
#include <cstdio>

using namespace std;

namespace cmd {


/* CCommand  - Functions of the interface
   ---------------------------------------*/

CCommand::
~CCommand()
{
   for (unsigned i=0; i<command_arguments.size(); ++i) {
      delete command_arguments[i];
   }
   if (val) {
      delete val;
   }
}

CCommand::
CCommand(const CCommand &other)
{
   for (unsigned i=0; i<other.command_arguments.size(); ++i) {
      command_arguments.push_back(new CCommandArgument(*other.command_arguments[i]));
   }
   if (other.val) {
      val = new CCommandVal(*other.val);
   } else {
      val = NULL;
   }
}


void
CCommand::
CheckForDuplicatedArguments() const
{
   for (unsigned i=0; i<command_arguments.size(); ++i) {
      for (unsigned j=0; j<command_arguments.size(); ++j) {
         if (i != j) {
            const COptionParameter *parameter1 = command_arguments[i]->GetParameter();
            const COptionParameter *parameter2 = command_arguments[j]->GetParameter();
            if (parameter1->GetParameterKey() == parameter2->GetParameterKey()) {
               if (parameter1->NeedVal()) {
                  if (parameter1->GetVal()->GetType() == CVal::KEYWORD_SET) {
                     // In case of a set of keywords assignment we allow duplicates
                  } else {
                     throw runtime_error("Argument is duplicated - ambigous: " + parameter1->GetName());
                  }
               } else {
                  // Then we don't care - it is not ambigous
               }
            }
         }
      }
   }
}

void
CCommand::
AssertUniqueAlternative(const CCommandArgument *argument, int code) const
{
   vector <int> alternatives = argument->GetVal()->AsKeySet();
   bool unique_found = false;
   bool other_found = false;
   int other = 0;
   for (unsigned i=0; i<alternatives.size(); ++i) {
      int alt = alternatives[i];
      if (alt == code) {
         unique_found = true;
      } else {
         other_found = true;
         other = alt;
      }
   }
   if (unique_found && other_found) {
      // Contradiction
      string unique_keyword_name = argument->GetParameter()->GetVal()->GetKeyword(code).GetName();
      string other_keyword_name = argument->GetParameter()->GetVal()->GetKeyword(other).GetName();
      string parameter_name = argument->GetParameter()->GetName();
      throw runtime_error("Both '" + other_keyword_name + "' and '" + unique_keyword_name +
                          "' are specified in argument " + parameter_name + ".");
   }
}

const CCommandArgument *
CCommand::
GetArgument(int key) const
{
   const CCommandArgument *matched_command_argument = NULL;
   for (unsigned i=0; i<command_arguments.size(); ++i) {
      const CCommandArgument *command_argument = command_arguments[i];
      if (command_argument->GetParameter()->GetParameterKey() == key) {
         matched_command_argument = command_argument;
         break;
      }
   }
   return matched_command_argument;
}

void
CCommand::
AssertFileAccessability(string file_name, const char *mode)
{
   FILE *fileptr = fopen(file_name.c_str(), mode);
   if (fileptr) {
      fclose(fileptr);
      // If in write mode, a file might have been created; remove it
      if (strchr(mode, 'w') != 0)
         remove(file_name.c_str());
   } else {
      throw runtime_error("Could not open the file named " + file_name);
   }
}

string
CCommand::
CreateBaseName(const CSession *session, int argument_key) const
{ 
   CCommandParse *command_parse = dynamic_cast<CCommandParse*> (session->GetCommand(COption::PARSE));
   assert(command_parse);
   string input_program_file_name = command_parse->GetProgramFileName();
   string base_name;
   const CCommandArgument *file_argument = GetArgument(argument_key);
   if (file_argument) {
      base_name = file_argument->GetVal()->AsString();
   } else {
      assert(!input_program_file_name.empty());
      base_name = input_program_file_name;
      size_t dot_pos = base_name.find_last_of('.');
      if (dot_pos != string::npos) {
         base_name = base_name.substr(0, dot_pos);
      }
   }
   return base_name;
}

/* CCommandPrintFile - extends CCommand with the
   ability to generate a file printing list
   -------------------------------------------*/

void
CCommandPrintFile::
ValidateFiles(const CSession *session, int file_key, int format_key, string appendix, int consol_output_key)
{
   string base_name = CreateBaseName(session, file_key);

   { // Create the list of output files
      const CCommandArgument *format_argument = GetArgument(format_key);
      const CCommandArgument *consol_output_argument = GetArgument(consol_output_key);
      vector <int> format_alternatives = format_argument->GetVal()->AsKeySet();
      for (unsigned i=0; i<format_alternatives.size(); ++i) {
         OutputSettings::Output output;
         output.key = format_alternatives[i];
         if (consol_output_argument == NULL) {
            output.file_name = base_name;
            // Add a suffix to the base name if there are more than one output formats specified or if
            // no output file name was specified
            if (format_alternatives.size() > 1 || GetArgument(file_key) == 0)
            {
               CKeyword keyword = format_argument->GetParameter()->GetVal()->GetKeyword(format_alternatives[i]);
               output.file_name.append(string(".") + keyword.GetName());
            }
            output.file_name.append(appendix);
            AssertFileAccessability(output.file_name, "w");
         } else {
            // Leave the name empty (we don't need to check stdout
         }
         output_settings.outputs.push_back(output);
      }
   }
}
} // end namespace cmd
