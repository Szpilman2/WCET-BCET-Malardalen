// $Id $

#include "CCommandLoadMap.h"
#include "CCommandOutputFlowFacts.h"
#include "CCommandParse.h"
#include "CSession.h"
#include "program/alf/AStmt.h"
#include "tools/CSourceLoader.h"
#include "flow_facts/RapitaIntermediate.h"
#include "macros.h"
#include <stdexcept>
#include <algorithm>
#include <fstream>
#include <iterator>
#include <functional>

using namespace std;

namespace cmd {

CCommandLoadMap::
~CCommandLoadMap()
{
   if (source_loader) {
      delete source_loader;
   }
}

CCommand *
CCommandLoadMap::
Copy() const
{
   assert(source_loader==NULL);
   return new CCommandLoadMap(*this);
}

void
CCommandLoadMap::
Validate(const CSession *session)
{
   read_c_source = GetArgument(READ_C_SOURCE) != 0;

   // Get name(s) of the map file(s) to read
   const CCommandArgument *file_argument = GetArgument(FILE_NAME);
   CCommandParse *command_parse = &dynamic_cast<CCommandParse&>(*session->GetCommand(COption::PARSE));
   const vector<string>& alf_file_names = command_parse->GetProgramFileNames();
   if (file_argument != 0) { // If the file argument was given
      if (alf_file_names.size() > 1)
         throw runtime_error("When more than one ALF files are given as input, the file option should be empty");
      file_names.push_back(file_argument->GetVal()->AsString());
      // When an explicit file name is given, make sure the file actually exists
      AssertFileAccessability(file_names.back(), "r");
   } else { // Otherwise, deduce the file names from the names of the .alf files
      file_names.reserve(alf_file_names.size());
      for (auto f = begin(alf_file_names), f_end = end(alf_file_names); f != f_end; ++f) {
         // Append `file_name' to the list only if the file exists
         auto file_name = ToMapFile(*f);
         FILE *file_ptr = fopen(file_name.c_str(), "r");
         if (file_ptr) {
            fclose(file_ptr);
            file_names.push_back(move(file_name));
         } else {
            // Otherwise, append "" to the list, so that `alf_file_names' and `file_names' are kept "parallel"
            file_names.push_back(string());
         }
      }
   }

   {  // Print after file linkage is optional. It will only be made when
      // several ALF files have been linked together.
      const CCommandArgument *pal_argument = GetArgument(PAL);
      print_linked_maps = (pal_argument != NULL);
      if (print_linked_maps)
      {
         linked_file_name = pal_argument->GetVal()->AsString();
         AssertFileAccessability(linked_file_name, "w");
      }
   }
}

void CCommandLoadMap::Execute(const CSession *session)
{
   CCommandParse *command_parse = &dynamic_cast<CCommandParse&>(*session->GetCommand(COption::PARSE));
   vector<CSourceLoader*> source_loaders;
   try
   {
      // Create source loaders
      const vector<string>& alf_file_names = command_parse->GetProgramFileNames();
      for (vector<string>::size_type f = 0; f < file_names.size(); ++f) {
         // An empty file name means that there exists no corresponding .map file for alf_file_names[f]
         if (!file_names[f].empty()) {
            source_loaders.push_back(new CSourceLoader(file_names[f], alf_file_names[f],
                                                       command_parse->GetSavedLabels(alf_file_names[f])));
         }
      }

      // Link the source loaders together
      CSourceLoader::Link(source_loaders, command_parse->GetLinkLog());
      source_loader = source_loaders.front();

      if (print_linked_maps)
         source_loader->PrintToFile(linked_file_name);
      if (command_parse->GetProgramLanguage() == CCommandParse::ALF)
         alf::AStmt::SetSourceLoader(source_loader);
   }
   catch (...)
   {
      for_each(source_loaders.begin(), source_loaders.end(), Deleter());
      throw;
   }

   // Perform check that all alf basic blocks has c_source info
   bool do_map_check = (GetArgument(CHECK_MAP) != 0);
   if(do_map_check) { 
     const std::vector<CFlowGraph*> & flow_graphs = command_parse->GetFlowGraphs();
     bool has_c_cource_info_for_all_nodes = source_loader->HasCSourceInfoForAllNodes(flow_graphs);
     if(!has_c_cource_info_for_all_nodes) {
       throw runtime_error("Incomplete mapping file(s)");
     }
   }   

   // bool do_map_check_for_rapita_ff = (GetArgument(CHECK_MAP_FOR_RAPITA_FF) != 0);
   bool do_map_check_for_rapita_ff = false;
   if(do_map_check_for_rapita_ff) {
     // Check if we should generate rapita flow fact file
     if(session->HasCommand(COption::OUTPUT_FF)) {
       CCommandOutputFlowFacts *command_output_flow_facts = &dynamic_cast<CCommandOutputFlowFacts&>(*session->GetCommand(COption::OUTPUT_FF));
       bool generate_rapita_ffs = command_output_flow_facts->GenerateRapitaFFs();
       if(generate_rapita_ffs) { 
         const std::vector<CFlowGraph*> & flow_graphs = command_parse->GetFlowGraphs();
         RapitaIntermediate ri(&flow_graphs, source_loader); 
         bool has_c_cource_info_for_all_nodes = source_loader->HasCSourceInfoForAllNodes(flow_graphs, true, &ri);
         if(!has_c_cource_info_for_all_nodes) {
           throw runtime_error("Incomplete mapping file(s) for Rapita flow fact generation");
         }   
       }
     }
   }
}

std::string CCommandLoadMap::ToMapFile(const std::string& alf_file)
{
   string::size_type suff_sep_pos = alf_file.find_last_of('.');
   string::size_type dir_sep_pos = alf_file.find_last_of("/\\");
   if (dir_sep_pos != string::npos && suff_sep_pos < dir_sep_pos)
      return alf_file + ".map";
   else
      return alf_file.substr(0, suff_sep_pos) + ".map";
}

}
