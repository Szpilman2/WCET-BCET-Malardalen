// $Id $

#include "CCommandCheck.h"
#include "CCommandParse.h"
#include "CSession.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/StaticProgramChecking.h"
#include "program/CGenericFunction.h"
#include <stdexcept>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>

using namespace std;

namespace cmd {

void
CCommandCheck::
Execute(const CSession *session)
{
   bool found_errors = false;
   string error_message;

   found_errors |= Size(session, error_message);
   found_errors |= UnresolvedRefs(session, error_message);
   found_errors |= StartingPoint(session, error_message);
   found_errors |= FunctionCalls(session, error_message);
   found_errors |= TypeAnalysis(session, error_message);

   if (found_errors)
      throw runtime_error(error_message);
}

// Private parts -----------------------------------------------

bool CCommandCheck::Size(const CSession *session, string& error_message) const
{  
   const CCommandArgument *size_check_argument = GetArgument(SIZE);
   if (size_check_argument->GetVal()->AsKey() != ON)
      return false;

   CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
   CCallGraph *call_graph = command_parse->GetCallGraph();
   CGenericProgram * ast = command_parse->GetAst();

   bool found_errors = false;
   // Why is this check done as part of the "size" check? /Linus K.
   if (call_graph->ContainRecursiveFunctions()) {
      error_message += "The program contains recursive functions. We don't support that at present.";
      found_errors = true;
   }
   if (command_parse->GetProgramLanguage() == CCommandParse::ALF) {
      StaticAlfErrorCollection ast_errors;
      PerformSizeCheck(*dynamic_cast<alf::CAlfTuple*>(ast), ast_errors);
      if (ast_errors.size() > 0)
      {
         ostringstream s;
         s << "Alf static check found problems:\n" << ast_errors << endl;
         error_message += s.str();
         found_errors = true;
      }
   }
   return found_errors;
}

bool CCommandCheck::UnresolvedRefs(const CSession *session, std::string& error_message) const
{
   const CCommandArgument *external_refs_check_argument = GetArgument(EXTERNAL_REFS);
   if (external_refs_check_argument->GetVal()->AsKey() != ON)
      return false;

   CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
   CCallGraph *call_graph = command_parse->GetCallGraph();
   CGenericProgram * ast = command_parse->GetAst();
   list<CCallGraphNode*> entry_nodes;
   call_graph->GetEntryNodes(&entry_nodes);

   // We should only check for unresolved references when we have language
   // file as input. For example, this check should not be done on
   // CFG inputs.
   if (command_parse->GetProgramLanguage() != CCommandParse::ALF)
      return false;

   bool found_errors = false;

   // Check that ast does not contain any unresolved references
   vector <CGenericFunction*> functions;
   if (entry_nodes.size() > 1) {
      ast->Functions(functions);
   } else if (command_parse->GetStartNode()) {
      list <CCallGraphNode*> subgraph;
      call_graph->FindFlowComponent(command_parse->GetStartNode(), &subgraph);
      for (list <CCallGraphNode*>::iterator cg_node_it=subgraph.begin();
         cg_node_it!=subgraph.end(); ++cg_node_it) {
            CCallGraphNode *call_graph_node = *cg_node_it;
            functions.push_back(call_graph_node->Function());
      }
   }
   StaticAlfErrorCollection undefs;
   CheckUnresolvedReferences(dynamic_cast<alf::CAlfTuple&>(*ast), functions, ast->GetSymTab(), undefs);
   if (undefs.size() > 0)
   {
      ostringstream s;
      s << endl << "The following global variables were referenced but not defined:" << endl << undefs << endl;
      error_message += s.str();
      found_errors = true;
   }
   return found_errors;
}

bool CCommandCheck::StartingPoint(const CSession *session, std::string& error_message) const
{ 
   const CCommandArgument *connected_cg_check_argument = GetArgument(CONNECTED);
   if (connected_cg_check_argument->GetVal()->AsKey() != ON)
      return false;

   bool found_errors = false;
   CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
   CCallGraph *call_graph = command_parse->GetCallGraph();
   list<CCallGraphNode*> entry_nodes;
   call_graph->GetEntryNodes(&entry_nodes);
   if (entry_nodes.size() > 1) {
      ostringstream name_list;
      for (list<CCallGraphNode*>::iterator cgn_it=entry_nodes.begin(); cgn_it!=entry_nodes.end(); ++cgn_it) {
         CCallGraphNode *call_graph_node = *cgn_it;
         CGenericFunction *function = call_graph_node->Function();
         string name = function->Name();
         name_list << name << endl;
      }
      error_message += "\nThis code contains more than one starting points for analysis, please "
         "provide one (using -i=... func=<name>). \nAvailable start functions are:\n" + name_list.str();
      found_errors = true;
   }
   return found_errors;
}

bool CCommandCheck::FunctionCalls(const CSession *session, std::string& error_message) const
{       
   const CCommandArgument *fcalls_check_argument = GetArgument(FCALLS);
   if (fcalls_check_argument->GetVal()->AsKey() != ON)
      return false;

   CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
   if (command_parse->GetProgramLanguage() != CCommandParse::ALF)
      return false;

   bool found_errors = false;
   alf::CAlfTuple* ast = (alf::CAlfTuple*)command_parse->GetAst();
   StaticAlfErrorCollection ast_errors;
   PerformFuncCallCheck(*ast, ast_errors);
   if (ast_errors.size() > 0) {
      ostringstream s;
      s << "Alf static check found problems:\n" << ast_errors << endl;
      error_message += s.str();
      found_errors = true;
   }
   return found_errors;
}

bool CCommandCheck::TypeAnalysis(const CSession* session, std::string& error_message) const
{
return false;
}

}
