#ifndef COMMAND_ARGUMENT_H_
#define COMMAND_ARGUMENT_H_

#include "COptionParameter.h"
#include "CKeyword.h"
#include "CCommandVal.h"
#include <cassert>

namespace cmd {

/** \class CCommandArgument
   Represents a syntactically valid argument of a command. This is the result
   of a user input argument that matches an allowed parameter.
   A command argument may have a command value.
*/
class CCommandArgument
{
public:
   /** Constructs a command argument that has no value. This represents a
      boolean setting whose inverted value is the default.
      \param parameter A pointer to the corrsponding allowed option's
         parameter. */
   CCommandArgument(const COptionParameter *parameter) :
                     parameter(parameter),
                     command_val(NULL)
                     { }

   /** Constructs a command argument that has a value. This represents setting
      whose value is of a type requested by the corresponding option's
      parameter type.
      \param parameter A pointer to the corrsponding allowed option's
         parameter.
      \param command_val The commands actual value. */
   CCommandArgument(const COptionParameter *parameter, CCommandVal *command_val) :
                     parameter(parameter),
                     command_val(command_val)
                     { }

   ~CCommandArgument() { if (command_val) delete command_val; }

   CCommandArgument(const CCommandArgument &other)
   {
      if (other.command_val) {
         command_val = new CCommandVal(*other.command_val);
      } else {
         command_val = NULL;
      }
   }

   /** \return A pointer to the corresponding option parameter to this command
      argument. */
   const COptionParameter *GetParameter() const { return parameter; }

   /** \return A pointer to the value of this argument.
      \pre This command object was constructed as a value-argument. */
   const CCommandVal *GetVal() const { assert(command_val); return command_val; }

private:
   const COptionParameter *parameter;
   CCommandVal *command_val;
};
}

#endif
