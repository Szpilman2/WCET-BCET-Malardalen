#include "HelpAnnot.h"
#include <iostream>
#include <sstream>

using namespace std;

namespace help_annot {

// Help macros to define colors
#define CSI_BLUE     std::string("\033[34m")
#define CSI_GREEN    std::string("\033[32m")
#define CSI_MAGENTA  std::string("\033[35m")
#define CSI_BOLD     std::string("\033[1m")
#define CSI_RESET    std::string("\033[0m")

// Help functions
std::string make_title(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return X;
}

std::string make_opt(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return CSI_BOLD + X + CSI_RESET;
}

std::string make_arg(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return CSI_BOLD + CSI_MAGENTA + X + CSI_RESET;
}

std::string make_nterm(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return CSI_BOLD + CSI_MAGENTA + X + CSI_RESET;
}

std::string make_term(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return CSI_BOLD + X + CSI_RESET;
}

std::string make_rule(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return CSI_BOLD + CSI_MAGENTA + X + CSI_RESET;
}

// Help macros for avoiding writing whole function calls
#define TITLE(X) make_title(X,no_csi)
#define OPT(X) make_opt(X,no_csi)
#define ARG(X) make_arg(X, no_csi)
#define NTERM(X) make_nterm(X, no_csi)
#define TERM(X) make_term(X, no_csi)
#define RULE(X) make_rule(X, no_csi)

// The function printing the actual help text. Bool decides
// if CSI highlighting should be use or not
void HelpAnnot(bool no_csi)
{
cout 
<< endl
<< TITLE("HELP TEXT FOR SWEET'S VALUE ANNOTATIONS") << endl
<< TITLE("---------------------------------------") << endl
<< endl
<< "Annotations in SWEET provide a way to assign abstract values to variables (represented " << endl
<< "by addresses) at certain program points (represented by labels). The annotations are stored " << endl
<< "in a text file and given as input to SWEET using the " << OPT("annot=") << NTERM("<file-name>") 
<< " argument of the " << OPT("-i") << " option." << endl
<< "The syntax of each line in the file is: " << NTERM("<pos> <upd> <var> <val>") << RULE(" [ ") << TERM("|| ") << NTERM("<var> <val>") << RULE(" ]* ") << TERM(";") << " where" << endl
<< "  " << NTERM("<pos>") << " is where to place the assignment(s). It can be one of:" << endl
<< "   - Before a given program statement holding a certain label " << endl
<< "     " << TERM("STMT_ENTRY") << " " << NTERM("<func> <lrefid> <loffs>") << endl
<< "     Note: If <loffs> is = 0, it can be omitted. " << endl
<< "   - After a given program statement holding a certain label" << endl
<< "     " << TERM("STMT_EXIT") << " " << NTERM("<func> <lrefid> <loffs>") << endl
<< "     the program statement can not be a scope, call or return statement. " << endl
<< "     Note: If <loffs> is = 0, it can be omitted. " << endl
<< "   - After the entry statement of a function:" << endl
<< "     " << TERM("FUNC_ENTRY") << " " << NTERM("<func>") << endl
<< "     the assignments will be made after the function declarations and initializations." << endl
<< "   - Before the first function in the program is called. " << endl
<< "     " << TERM("PROG_ENTRY") << endl
<< "     The assignments will be made after the global declarations and initializations. " << endl
<< "   - A global, always valid, volatile value assignment. " << endl
<< "     " << TERM("VOLATILE") << endl
<< "     The value stored will never change." << endl 
<< "   - A global, always valid, assignment made instead of calls to the given function. " << endl
<< "     " << TERM("WHEN_CALLED") << " " << NTERM("<func>") << endl 
<< "     No call will be made (only the given variable assignments)" << endl
<< "  " << NTERM("<upd>") << " is how to update the analysis variable(s) with the annotation value(s). It can be one of:" << endl
<< "   - Completely replace the variable's current analysis value(s) with the annotation value(s). " << endl
<< "     " << TERM("ASSIGN") << endl
<< "   - Take the intersection of the variable's current analysis value(s) and the annotation value(s)." << endl
<< "     " << TERM("GLB") << endl
<< "     Can not be used together with " << TERM("VOLATILE") << " or " << TERM("WHEN_CALLED") << endl
<< "   - Take the union of the variable's current analysis value(s) and the annotation value(s)." << endl
<< "     " << TERM("LUB") << endl
<< "     Can not be used together with " << TERM("VOLATILE") << " or " << TERM("WHEN_CALLED") << endl
<< "  " << NTERM("<var>") << " is the variable (i.e. the frame) to be updated. It can be one of: " << endl
<< "   - The value should be stored at the start of the frame (i.e. offset = 0). The value" << endl
<< "     stored has the same size as the whole frame." << endl
<< "     " << NTERM("<frefid>") << endl
<< "   - The value should be stored at a given offset from the start of the frame. The size " << endl
<< "     of the stored value has a certain size." << endl
<< "     " << NTERM("<frefid> <foffs> <size> ") << endl
<< "   - The store of a value is repeated a given number of times. With a frefid f, offset o, " << endl
<< "     size s, and repeat r, then the value is stored at: <f,o>, <f,o+s>, ..., <f,o+(n-1)s>" << endl
<< "     " << NTERM("<frefid> <foffs> <size> <repeat>") << endl
<< "   - The store of a value in the return value of a function. " << endl
<< "     " << TERM("RET_VAL") << NTERM(" <foffs> <size> ") << endl
<< "     Can only used together with " << TERM("WHEN_CALLED") << endl
<< "   " << NTERM("<val>") << " is the value to be stored. It can be either of:" << endl
<< "   - An integer value:" << endl
<< "     " << TERM("INT") << RULE(" [ ") << NTERM("<ilow>") << RULE(" | ") << NTERM("<ilow> <iupp>") << RULE(" | ") << NTERM("<ilow> <iupp> <icmul>") << RULE(" ]") << endl
<< "     an integer value could either be a <low> <upp> pair or just a signed integer value. The value icmul is the multiplier of a congruence." << endl
<< "   - A float interval:" << endl
<< "     " << TERM("FLOAT") << RULE(" [ ") << NTERM("<flow>") << RULE(" | ") << NTERM("<flow> <fupp>") << RULE(" ]") << endl
<< "     an float value could either be a <low> <upp> pair or just a signed float value." << endl
<< "   - One or several data pointer values: " << endl
<< "     " << TERM("ADDR") << RULE(" [ [ ") << NTERM("<frefid>") << RULE(" | ") << NTERM("<frefid> <foffs>") << RULE(" ]+ ]") << endl
<< "     each fval could be either a <frefid> <foffs> pair, or just a <frefid> (i.e. foffs=0)" << endl
<< "   - One or several label pointer values: " << endl 
<< "     " << TERM("LABEL") << RULE(" [ [ ") << NTERM("<lrefid>") << RULE(" | ") << NTERM("<lrefid> <loffs>") << RULE(" ]+ ]") << endl
<< "     each lval could be either a <lrefid> <loffs> pair, or just a <lrefid> (i.e. loffs=0)" << endl
<< "   - A TOP value of a certain subtype" << endl 
<< "     " << TERM("TOP_INT") << RULE(" | ") << TERM("TOP_FLOAT") << RULE(" | ") << TERM("TOP_ADDR") << RULE(" | ") << TERM("TOP_LABEL") << endl
<< endl
<< "Explanation of the fields:" << endl
<< NTERM("<func>") << " - The ALF name of the function where to put the annotation statement. A string." << endl
<< NTERM("<lrefid>") << " - A label identifier. To form a complete label it must be associated with an " << endl
<< "  offset. The resulting label must be present in the program. A string. " << endl
<< NTERM("<loffs>") << " - A label offset. Used together with a lrefid to form a label. An unsigned " << endl
<< "  integer." << endl
<< NTERM("<frefid>") << " - A frame identifier (i.e. a variable). Identifies the frame that should be " << endl
<< "  updated by the assignment. When used in pointer values <frefid> identifies the frame " << endl
<< "  pointed to. A string. " << endl
<< NTERM("<foffs>") << " - The offset from the frames start address where the value should be stored." << endl
<< "  The offset is counted in bits. For an atomic data type the offset is 0, while for" << endl
<< "  an array or a struct <foffs> gives the offset (in bits) to the field to write to." << endl
<< "  When used in pointer values <foffs> gives the relative offset from the start address" << endl
<< "  of <frefid> which should be pointed to, i.e. the address at <frefid> + <offs>." << endl
<< "  An unsigned integer." << endl
<< NTERM("<size>") << " - The size of the value that should be stored. Counted in bits. An unsigned " << endl
<< "  integer." << endl
<< NTERM("<repeat>") << " - the number of times the given value storage should be repeated at consequtive " << endl
<< "  addresses in the same frame. An unsigned integer >= 1." << endl
<< NTERM("<ilow>") << " - The lower limit in an integer interval value. A signed integer value <= <iupp>." << endl
<< NTERM("<iupp>") << " - The upper limit in an integer interval value. A signed integer value >= <ilow>." << endl
<< NTERM("<icmul>") << " - The multiplier of a congruence. The resulting domain is: <ilow> + <icmul>Z.  " << endl
<< NTERM("<flow>") << " - The lower limit in a float interval value. A signed float value <= <fupp>." << endl
<< NTERM("<fupp>") << " - The upper limit in a float interval value. A signed float value >= <flow>." << endl
<< endl
<< "Each annotation should end with a semicolon. " << endl
<< endl
<< "The || notation is used for making a parallel store of abstract values. At least " << endl
<< "one <upd> <var> <val> tuple must be given. It is allowed for two parallel assignments" << endl
<< "to update the same frame, the values to be stored must however not overlap in the " << endl
<< "frame. It is not allowed to refer to the same program point by several annotations." << endl
<< "It is not allowed to assign values outside a frame.  " << endl
<< endl
<< "Comments may be given in the annotation file using C or C++ style comments. Integer values" << endl
<< "are given using C syntax, i.e., decimal values start with an integer > 0 or a '-', " << endl
<< "hexadecimal values starts with 0x or OX, and octal values start with a 0. Floating " << endl
<< "values are also given using C syntax, i.e. 5, 1.25, 2.457E2, or -3.7E-4." << endl
<< endl
<< "Floats in annotations are currently assumed to be of 32 or 64 bits size. If the float is" << endl
<< "given another size an error will be generated. This ius because we do not know how many " << endl 
<< "bits the exponent and fraction of the float should occupy. We currently assume IEEE 754-2008" << endl
<< "floats, i.e. 32-bits floats are assumed to have 8 bits exp and 23 bits frac, while 64-bits" << endl
<< "floats are assumed to have 11 bits exp and 52 bits frac." << endl 
<< endl
<< "When using a frefid that exists in several ALF scopes, the normal scoping rules of " << endl
<< "ALF will be used to find the right frame to update. I.e. first the local scopes on " << endl
<< "the current function scope will be searched (if any), then the function scope, and " << endl
<< "finally the global scope. If no such frefid can be found an error will be generated." << endl
<< endl
<< "A PROG_ENTRY annotation will take effect after all global initializations have been made, " << endl
<< "but before the first statement has been taken. Thus, PROG_ENTRY annotations can only refer " << endl
<< "to global frame identifiers. When having an FUNC_ENTRY annotation on the first function in " << endl
<< "the program, the PROG_ENTRY annotation will be processed before the FUNC_ENTRY annotation. " << endl
<< "Similarly, when having a STMT_ENTRY annotation on the first statement in the program the " << endl
<< "PROG_ENTRY annotation will be processed before the STMT_ENTRY annotation. " << endl
<< endl
<< "When having both an FUNC_ENTRY annotation and a STMT_ENTRY annotation on the first " << endl
<< "statement in the same function the FUNC_ENTRY annotation will be processed before the " << endl
<< "STMT_ENTRY annotation. " << endl
<< endl
<< "When an STMT_EXIT annotation refers to a statement which is the predecessor to a statement " << endl
<< "which have a STMT_ENTRY annotation, the STMT_EXIT annotation will be processed before the" << endl
<< "given STMT_ENTRY annotation." << endl
<< endl
<< "A VOLATILE annotation is only applicable to global frefs. In ALF, a volatile fref holds" << endl 
<< "data whose contents may change at any time in a way not under the control of the program." << endl
<< "A fref (or parts of a fref) assigned an abstract value using the VOLATILE keyword will " << endl
<< "always hold the given value. Thus, normal assignments or other type of value annotations to" << endl
<< "volatile variables will have no effect. This also holds for a variable declared volatile in" << endl
<< "ALF, for which only the VOLATILE annotation can be used to assign it an (abstract) value." << endl 
<< "The annotation should provide a safe upper bounds on what values the fref may hold during" << endl
<< "all possible executions of the program." << endl
<< endl
<< "A WHEN_CALLED annotation will be applied whenever a call to the given function should be" << endl
<< "made, (either using normal function calls or using function pointers). The function call" << endl
<< "will then not be made (and thus no flow facts will be generated for the function). " << endl
<< "Instead, the execution will continue at the statement following the call statement, but" << endl
<< "with variables updated according to the given value assignments. The annotation should" << endl
<< "be valid for all possible calls to the function within the analyzed program for all " << endl
<< "possible executions of the program." << endl 
<< endl
<< "In ALF sizes of imported variables are unknown. The same holds for the sizes of return values" << endl
<< "of imported functions. This means that when assigning a value to an imported fref or assigning" << endl
<< "a return value to an imported function, an offset and a size must always be provided." << endl
<< endl
<< TITLE("ANNOTATION EXAMPLES") << endl
<< TITLE("-------------------") << endl
<< endl
<< "STMT_ENTRY main BB0 ASSIGN x INT -1 5;                                       // Annot 1" << endl
<< "STMT_EXIT foo BB72 5 ASSIGN x INT 3 4 || y INT 2;                              // Annot 2" << endl
<< "FUNC_ENTRY bar ASSIGN s 0 32 INT 1 67 || s 32 16 INT -12 14 || s 48 32 ADDR x; // Annot 3" << endl
<< "PROG_ENTRY ASSIGN g ADDR d 0 d 32 d 64 d 96 d 128;                             // Annot 4" << endl
<< "PROG_ENTRY ASSIGN w 0 8 20 INT -1;                                             // Annot 5" << endl
<< "FUNC_ENTRY baz ASSIGN f 32 64 FLOAT -1.23 2.457E2;                             // Annot 6" << endl
<< "STMT_EXIT main BB12 ASSIGN z INT 0 6 2 || v INT -2 8 3;                      // Annot 7" << endl
<< "FUNC_ENTRY ko ASSIGN p TOP_ADDR;                                               // Annot 8" << endl
<< "FUNC_ENTRY mu ASSIGN fp LABEL main 0 ko 0 mu 0;                                // Annot 9" << endl
<< "STMT_ENTRY bu BB7 0 GLB w INT 1 100;                                           // Annot 10" << endl
<< "STMT_EXIT bu BB7 0 LUB w INT 0 70;                                             // Annot 11" << endl
<< "VOLATILE ASSIGN k INT 66 68;                                                   // Annot 12" << endl
<< "VOLATILE ASSIGN u 0 8 INT 5 || k 9 16 INT 4;                                   // Annot 13" << endl
<< "WHEN_CALLED foo ASSIGN g INT 6 7 || RET_VAL 0 32 TOP_INT;                      // Annot 14" << endl
<< endl
<< "Explanations:" << endl
<< "- 1 adds an annotation before the statement labelled <BB0,0> in function main which " << endl
<< "  assigns integer interval [-1..5] to variable x. " << endl
<< "- 2 adds an annotation after the statement labelled <BB72,5> in function foo which " << endl
<< "  assigns integer interval [3..4] to variable x and value 2 to variable y. " << endl
<< "- 3 adds an annotation after entry of function bar which updates a larger aggregate data " << endl
<< "  structure s with several values. It assigns the integer interval [1..67] to the first 32 bits " << endl
<< "  of s, interval [-12..14] to the following 16 bits of s, and a pointer value " << endl
<< "  holding the addresses of variable x to the following 32 bits." << endl
<< "- 4 adds an annotation at the global program scope which assigns a set of pointer values " << endl
<< "  to global variable g all pointing at different parts of a larger global aggregate data " << endl
<< "  structure d. Note: if the offset is not given (ADDR d) it is interpreted as ADDR d 0." << endl
<< "- 5 adds an annotation at the global program scope which assigns -1 to each of the first " << endl
<< "  20 bytes of a global data structure w.   " << endl
<< "- 6 adds an annotation at the entry of function baz which assigns a 64 bit interval float " << endl
<< "  value -1.23 to 2.457 * 10^2 to bits 32 to 96 of variable f." << endl
<< "- 7 adds an annotation after the statement labelled <BB12,0> in function main which " << endl
<< "  assigns integer interval 0..6 and conguerence 0 + 2Z, (whose intersection is the values " << endl
<< "  0,2,4,6), to z. Similarly, v is assigned the integer interval [-2..9] and the congruence -2 + 3Z, " << endl
<< "  (whose intersection is the values -2,1,4,7). Note: congruences are not currently supported by SWEET." << endl
<< "- 8 adds an annotation after entry of function ko which assigns the data pointer p to hold " << endl
<< "  a TOP pointer value (i.e., all possible data addresses)." << endl
<< "- 9 adds an annotation after entry of function mu which assigns the function pointer fp to " << endl
<< "  hold the start addresses of functions main, ko and my respectively. Note: support for this " << endl
<< "  type of annotation is not yet supported by SWEET." << endl
<< "- 10 adds an annotation before the statement labelled <BB7,0> in function bu which specifies " << endl
<< "  that w should be given the intersection of its current analysis value and the [1..100] " << endl
<< "  interval. If, for example, the current analysis value is [50..200] the resulting value will " << endl
<< "  be [50..100]. " << endl
<< "- 11 adds an annotation before the statement labelled <BB7,0> in function bu which specifies " << endl
<< "  that w should be given the union of its current analysis value and the 0..70 interval. If, " << endl
<< "  for example, the current analysis value is [50..100] the resulting value will be [0..100]. " << endl
<< "- 12 sets the k variable imp to always hold the [66..68] interval." << endl
<< "- 13 sets the first 8 bits of u to always hold 5 and the following 8 bits to always hold 4." << endl
<< "- 14 sets every call to function foo to store [6..7] in global variable g. It also sets the " << endl
<< "  first 32 bit of the function's return value to a 32 bit integer TOP value. " << endl
<< endl
<< "BNF GRAMMAR" << endl
<< "-----------" << endl
<< endl
<< "absann_file -> " << endl
<< "     absann_list" << endl
<< endl
<< "absann_list  -> " << endl
<< "     absann_list absann" << endl
<< "   | " << endl
<< endl
<< "absann -> " << endl
<< "     position update var_vals_list ;" << endl
<< endl
<< "position -> " << endl
<< "     STMT_ENTRY func lrefid loffs" << endl
<< "   | STMT_ENTRY func lrefid" << endl
<< "   | STMT_EXIT func lrefid loffs" << endl
<< "   | STMT_EXIT func lrefid" << endl
<< "   | FUNC_ENTRY func" << endl
<< "   | PROG_ENTRY" << endl
<< "   | VOLATILE" << endl
<< "   | WHEN_CALLED func" << endl
<< endl
<< "update -> " << endl
<< "     ASSIGN" << endl
<< "   | GLB    (not for VOLATILE_ASSIGN or WHEN_CALLED)" << endl
<< "   | LUB    (not for VOLATILE_ASSIGN or WHEN_CALLED)" << endl
<< endl
<< "var_vals_list -> " << endl
<< "     var_vals" << endl
<< "   | var_vals_list '||' var_vals" << endl
<< endl
<< "var_vals -> " << endl
<< "    var vals" << endl
<< endl
<< "var -> " << endl
<< "    fid " << endl
<< "  | fid offs size" << endl
<< "  | fid offs size repeat" << endl
<< endl
<< "fid -> " << endl
<< "    frefid " << endl 
<< "  | RET_VAL                   (only for WHEN_CALLED)" << endl
<< endl
<< "var -> " << endl
<< "    frefid " << endl
<< "val ->" << endl
<< "    INT ilow " << endl
<< "  | INT ilow iupp" << endl
<< "  | INT ilow iupp icmul" << endl
<< "  | FLOAT ilow" << endl
<< "  | FLOAT flow" << endl
<< "  | FLOAT ilow iupp" << endl
<< "  | FLOAT flow iupp" << endl
<< "  | FLOAT ilow fupp" << endl
<< "  | FLOAT flow fupp" << endl
<< "  | ADDR frefid_foffs_list" << endl
<< "  | LABEL lrefid_loffs_list" << endl
<< "  | TOP_INT" << endl
<< "  | TOP_FLOAT" << endl
<< "  | TOP_ADDR" << endl
<< "  | TOP_LABEL" << endl
<< endl
<< "frefid_foffs_list ->" << endl
<< "    frefid " << endl
<< "  | frefid foffs" << endl
<< "  | frefid foffs foffs" << endl
<< "  | frefid_foffs_list frefid" << endl
<< "  | frefid_foffs_list frefid foffs" << endl
<< "  | frefid_foffs_list frefid foffs foffs" << endl
<< endl
<< "lrefid_loffs_list ->" << endl
<< "    lrefid" << endl
<< "  | lrefid loffs" << endl
<< "  | lrefid_offset_list lrefid" << endl
<< "  | lrefid_offset_list lrefid loffs" << endl
<< endl
<< "func -> " << endl
<< "    <string>" << endl
<< endl
<< "lrefid ->" << endl
<< "    <string>" << endl
<< endl
<< "loffs ->" << endl
<< "    <unsigned_int>" << endl
<< endl
<< "frefid ->" << endl
<< "    <string>" << endl
<< endl
<< "foffs ->" << endl
<< "    <unsigned_int>" << endl
<< endl
<< "size ->" << endl
<< "    <unsigned_int>" << endl
<< endl
<< "repeat ->" << endl
<< "    <unsigned_int>" << endl
<< endl
<< "ilow ->" << endl
<< "    <signed_int>" << endl
<< endl
<< "iupp ->" << endl
<< "    <signed_int>" << endl
<< endl
<< "icmul ->" << endl
<< "    <unsigned_int>" << endl
<< endl
<< "flow ->" << endl
<< "    <float>" << endl
<< endl
<< "fupp ->" << endl
<< "    <float>" << endl
<< endl;
}

} // end namespace cmd" << endl
