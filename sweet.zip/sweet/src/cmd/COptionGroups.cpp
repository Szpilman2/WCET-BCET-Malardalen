
#include "COptionGroups.h"
#include "CCommand.h"
#include "CCommands.h"
#include "CInputOptions.h"
#include "CInputExpr.h"
#include "tools/CTextBlock.h"
#include "graphs/tools/CGraph.h"
#include "graphs/tools/CGraph.inl"
#include "graphs/tools/CNode.inl"
#include <stdexcept>
#include <map>
#include <vector>
#include <sstream>
#include <fstream>
#include <iostream>

namespace cmd {

using namespace std;

COptionGroups::
~COptionGroups()
{
}

void
COptionGroups::
CheckConsistency() const
{
   for (unsigned i=0; i<size(); ++i) {
      const COptionGroup *group = &at(i);
      for (unsigned j=0; j<group->size(); ++j) {
         const COption *option = &group->at(j);
         // Check for default value
         if (option->IsDefault() && option->NeedVal()) {
            // Then there must be a default value present
            bool default_found = false;
            if (option->GetVal()->GetType() == CVal::KEYWORD) {
               const vector<CKeyword> &keywords = option->GetVal()->GetKeywordList();
               for (unsigned k=0; k<keywords.size(); ++k) {
                  if (keywords[k].IsDefault()) {
                     default_found = true;
                     break;
                  }
               }
            }
            assert(default_found);
         }
         // Set a back-link
         option->GetCommand()->SetOption(option);
      }
   }
}

void
COptionGroups::
MatchInput(CInputOptions &input_options, CCommands &commands) const
{
  map <string, const COption*> available_options;
   map <COption::KEY, const COption*> unused;
   Flattern(available_options, unused);
 
   for (unsigned i=0; i<input_options.size(); ++i) {
      CInputOption *input_option = input_options[i];
      map <string, const COption*>::iterator opt_it = available_options.find(input_option->GetKeyword());
      if (opt_it != available_options.end()) {
         // OK, the used keyword for an option existed
         // Check for value assignment
         const COption *option_specification = opt_it->second;

         // Check to avoid long and short name confusion
         if ((input_option->LongName() && input_option->GetKeyword() != option_specification->GetLongName()) ||
              (!input_option->LongName() && input_option->GetKeyword() != option_specification->GetShortName())) {
            throw runtime_error("Option '" + input_option->GetKeyword() + "' mismatch between long and short option notation.");
         }
         CCommand *command = option_specification->GetCommand();
         if (option_specification->NeedVal()) {
            if (input_option->HasVal()) {
               // OK, this option specified that a value should be given, and it was
               const CVal *val_specification = option_specification->GetVal();
               CCommandVal *actual_val = MatchValue(val_specification, input_option->GetVal(), input_option->GetKeyword());
               command->SetVal(actual_val);
            } else {
               throw runtime_error("Option '" + input_option->GetKeyword() + "' needs a value.");
            }
         } else if (input_option->HasVal()) {
            throw runtime_error("Option '" + input_option->GetKeyword() + "' should not be assigned a value.");
         }
 
	 // Check for parameters
         const vector <CInputOptionArgument*> &input_option_arguments = input_option->GetArguments();
         for (unsigned j=0; j<input_option_arguments.size(); ++j) {
            command->AddArgument(MatchArgument(input_option_arguments[j], option_specification));
         }
         commands.push_back(command);
      } else {
	std::vector<std::string> opt_short_names;
	GetAllOptionsShortNames(opt_short_names);
	stringstream ss;
	for(std::vector<std::string>::iterator name = opt_short_names.begin();
	    name != opt_short_names.end(); ++name) {
	  ss << (*name) << " ";
	}
	throw runtime_error("Unknown option '" + input_option->GetKeyword() + "'.\nAvailable options are: " + ss.str());
      }
   }
    bool is_help_command = CheckForHelpCommand(commands);
   if (!is_help_command) {
      AddDefaultCommands(commands);
      CheckForDuplicates(commands);
      AddDefaultParameters(commands);
      SortCommands(commands);
   }
 
 }

const COption *
COptionGroups::
FindOption(COption::KEY key) const
{
   map <string, const COption*> unused;
   map <COption::KEY, const COption*> available_options;
   Flattern(unused, available_options);
   map <COption::KEY, const COption*>::iterator opt_it = available_options.find(key);
   assert(opt_it != available_options.end());
   return opt_it->second;
}

/** Try to match an input argument with some allowed parameter in an allowed
   option. Throws an exception if the argument does not match any allowed
   parameter.
   \param argument The input argument that we aim to match.
   \param option The allowed option whose parameters we will scan.
   \return A new actual command argument. */
CCommandArgument *
COptionGroups::
MatchArgument(const CInputOptionArgument *argument, const COption *option_specification) const
{
  // int cnt = 0;

  bool argument_matched = false;
   const vector <COptionParameter> &parameter_specification = option_specification->GetParameters();
   CCommandArgument *command_argument=NULL;


   for (unsigned i=0; i<parameter_specification.size(); ++i) {

      const COptionParameter *parameter = &parameter_specification[i];
            
      
      if (parameter->GetName() == argument->GetKeyword()) {
         // OK the input name of the argument matches one of the allowed parameters
         if (parameter->NeedVal()) {
            if (argument->HasVal()) {
               // OK, a value assignment is required and it exists in the input 
 		CCommandVal *actual_val = MatchValue(parameter->GetVal(), argument->GetVal(), argument->GetKeyword());
               command_argument = new CCommandArgument(parameter, actual_val);
            } else {
               throw runtime_error("Argument '"+argument->GetKeyword()+"' to option '"+
                                   option_specification->GetShortName()+"' needs a value");
            }
         } else {
            if (!argument->HasVal()) {
               // OK, value assignment is not required and it does not exists in the input
               command_argument = new CCommandArgument(parameter);
            } else {
               throw runtime_error("Argument '"+argument->GetKeyword()+"' to option '"+
                                   option_specification->GetShortName()+"' should not be given a value");
            }
         }
         argument_matched = true;
         break;
      }
   }


  if (!argument_matched) {
     stringstream ss;
     for (unsigned i=0; i<parameter_specification.size(); ++i) {
       const COptionParameter *parameter = &parameter_specification[i];
       ss << parameter->GetName() << " ";
     }
     throw runtime_error("Unknown argument '"+ argument->GetKeyword()+"' to option '"+
			 option_specification->GetShortName() + "'.\nAvailable arguments are: " + ss.str());
   }
   return command_argument;
}

/** Try to match an input value with a legal keyword value. Throws an exception
   if the value does not match any legal keword.
   \param legal_val The legal value.
   \param input_val The input value that we hope matches the legal value.
   \param variable The name of the variable (keyword) to be assigned the
      value. Used for generating an error text.
   \return A command value containing the actual input value. */
CCommandVal *
COptionGroups::
MatchKeywordValue(const CVal *legal_val, string input_val_text, string variable) const
{
   CCommandVal *actual_val;
   const vector <CKeyword> &keywords = legal_val->GetKeywordList();
   bool found_keyword = false;
   for (unsigned i=0; i<keywords.size(); ++i) {
      CKeyword valid_keyword = keywords[i];
      if (input_val_text == valid_keyword.GetName()) {
         actual_val = new CCommandVal(legal_val, valid_keyword);
         found_keyword = true;
         break;
      }
   }
   if (!found_keyword) {
     stringstream ss;
     for(unsigned i=0; i<keywords.size(); ++i) {
       CKeyword valid_keyword = keywords[i];
       ss << valid_keyword.GetName() << " ";
     }
     throw runtime_error("Key value '" + input_val_text + "' of argument '" + variable + 
			 "' does not match any of the valid keywords.\nValid keywords are: " + ss.str());
   }
   return actual_val;
}

/** Chops a text into a head and tail delimited by a comma.
   \param text The text to chop.
   \param head A pointer to a location updated with the head of the text, i.e.
      the part before the first comma or the entire text if there is no comma.
   \param tail A pointer to a location updated with the tail of the text, i.e.
      the part after the first comma, or the empty string if there is no comma. */
void
COptionGroups::
Chop(string text, string *head, string *tail) const
{
   string::size_type delimiter_pos = text.find_first_of(',');
   *head = text.substr(0, delimiter_pos);
   if (delimiter_pos >= text.size()) {
      *tail = "";
   } else {
      *tail = text.substr(delimiter_pos + 1);
   }
}

/** Try to match a set of input values with a set of legal keyword values.
   Throws an exception if any of the values does not match a legal keword.
   \param legal_val The legal value.
   \param input_val The input value that we hope matches the legal value.
   \param variable The name of the variable (keyword) to be assigned the
      value. Used for generating an error text.
   \return A command value containing the actual input value. */
CCommandVal *
COptionGroups::
MatchKeywordSetValue(const CVal *legal_val, const CInputVal *input_val, string variable) const
{
   vector <int> key_set;
   string input_val_text = input_val->AsText();
   string prefix;
   do {
      string input_val_text_copy = input_val_text;
      Chop(input_val_text_copy, &prefix, &input_val_text);

      CCommandVal *sub_val = MatchKeywordValue(legal_val, prefix, variable);
      key_set.push_back(sub_val->AsKey());
      delete sub_val;
   } while (!input_val_text.empty());
   
   return new CCommandVal(legal_val, key_set);;
}

/** Try to match an input value with a legal value. Throws an exception if the
   value does not match.
   \param legal_val The legal value.
   \param input_val The input value that we hope matches the legal value.
   \param variable The name of the variable (keyword) to be assigned the
      value. Used for generating an error text.
   \return A command value containing the actual input value. */
CCommandVal *
COptionGroups::
MatchValue(const CVal *legal_val, const CInputVal *input_val, string variable) const
{
   CCommandVal *actual_val;
   if (legal_val->GetType() == CVal::INT) {
      if (input_val->IsInt()) {
         actual_val = new CCommandVal(legal_val, input_val->AsInt());
      } else {
         throw runtime_error("Value of '"+variable+"' should be of integer type.");
      }
   } else if (legal_val->GetType() == CVal::KEYWORD_SET) {
      actual_val = MatchKeywordSetValue(legal_val, input_val, variable);
   } else if (legal_val->GetType() == CVal::KEYWORD) {
      actual_val = MatchKeywordValue(legal_val, input_val->AsText(), variable);
   } else { // Then legal_val->GetType() == CVal::STRING
      // No check needed - any text empty matches a string
      actual_val = new CCommandVal(legal_val, input_val->AsText());
   }
   return actual_val;
}

/** Make a map from option name to option disregarding what groups they are in.
   \param option_map An ampty map where the result will be stored. */
void
COptionGroups::
Flattern(map <string, const COption*> &option_map1, map <COption::KEY, const COption*> &option_map2) const
{
   for (unsigned i=0; i<size(); ++i) {
      const COptionGroup *group = &at(i);
      for (unsigned j=0; j<group->size(); ++j) {
         const COption *option = &group->at(j);
         assert(option_map1.find(option->GetLongName()) == option_map1.end());
         assert(option_map1.find(option->GetShortName()) == option_map1.end());
         option_map1[option->GetLongName()] = option;
         option_map1[option->GetShortName()] = option;
         assert(option_map2.find(option->GetKey()) == option_map2.end());
         option_map2[option->GetKey()] = option;
      }
   }
}

/** To get all short names of options in a vector */
void 
COptionGroups::
GetAllOptionsShortNames(std::vector<std::string> & short_option_names) const
{
  for (unsigned i=0; i<size(); ++i) {
    const COptionGroup *group = &at(i);
    for (unsigned j=0; j<group->size(); ++j) {
      const COption *option = &group->at(j);
      short_option_names.push_back(option->GetShortName());
    }
  }
}

/** To get all long names of options in a vector */
void 
COptionGroups::
GetAllOptionsLongNames(std::vector<std::string> & long_option_names) const
{
  for (unsigned i=0; i<size(); ++i) {
    const COptionGroup *group = &at(i);
    for (unsigned j=0; j<group->size(); ++j) {
      const COption *option = &group->at(j);
      long_option_names.push_back(option->GetLongName());
    }
  }
}

/** Adds commands for all options that should be added by default if refered in
   some other commands precedence list.
   \param commands The commands container where to possibly add new commands.
*/
void
COptionGroups::
AddDefaultCommands(CCommands &commands) const
{
   // Hmm I realize now that this could have been done in a better way - 
   // repeating this until fixpoint is not very efficient. On the other side
   // there is absolutely no requirements on processing this so I don't want
   // to waste my time on doing it in a better way.
   bool added;
   do {
      added = false;
      // Collect requirements from all options
      set <const COption*> required_options;
      for (unsigned i=0; i<commands.size(); ++i) {
         const COption *current_option = commands[i]->GetOption();
         const vector <COption::KEY> &dependent_on = current_option->GetDependencies();
         for (unsigned j=0; j<dependent_on.size(); ++j) {
            required_options.insert(FindOption(dependent_on[j]));
         }
      }

      // Filter out those requirements that are satisfied by the users specification
      for (unsigned i=0; i<commands.size(); ++i) {
         set <const COption*>::iterator optit = required_options.find(commands[i]->GetOption());
         if (optit != required_options.end()) {
            // Remove it from the required otpions because it is already given by the user
            required_options.erase(optit);
         }
      }

      // Check if it is default. If it is, then we should add it, else it is input error
      for (set <const COption*>::iterator optit=required_options.begin(); optit!=required_options.end(); ++optit) {
         const COption *required_option = *optit;
         if (required_option->IsDefault()) {
            commands.push_back(CreateDefaultCommand(required_option));
            added = true;
         } else {
            throw runtime_error("'" + required_option->GetShortName()+"' is needed.");
         }
      }
   } while (added);
}

/** For a certain command: if it has a default parameters values: set these
   values.
   \param option The option to look for parameters in..
   \param command The command to possibly add arguments to.
   \pre \a command represents the option \a option.
*/
void
COptionGroups::
AddDefaultParameters(const COption *option, CCommand *command) const
{
   const vector <COptionParameter> &parameters = option->GetParameters();
   for (unsigned i=0; i<parameters.size(); ++i) {
      const COptionParameter *parameter = &parameters[i];
      if (parameter->NeedVal() && command->GetArgument(parameter->GetParameterKey())==NULL) {
         const CVal *val = parameter->GetVal();
         if (val->GetType() == CVal::KEYWORD || val->GetType() == CVal::KEYWORD_SET) {
            CCommandVal *command_val = CreateDefaultCommandVal(val);
            if (command_val) {
               CCommandArgument *argument = new CCommandArgument(parameter, command_val);
               command->AddArgument(argument);
            }
         }
      }
   }
}

/** Create a command based on a default allowed option.
   \param option The allowed option.
   \return A pointer to the new command. The memory is not owned by the caller. */
CCommand *
COptionGroups::
CreateDefaultCommand(const COption *option) const
{
   CCommand *command = option->GetCommand();
   if (option->NeedVal()) {
      CCommandVal *command_val = CreateDefaultCommandVal(option->GetVal());
      command->SetVal(command_val);
   }
   AddDefaultParameters(option, command);
   return command;
}

/** Create a command value based on the default value of an allowed value.
   \param val The allowed value.
   \pre \a val->GetType() returns KEYWORD or KEYWORD_SET
   \return The new command value or NULL if there is no default value. */
CCommandVal *
COptionGroups::
CreateDefaultCommandVal(const CVal *val) const
{
   CCommandVal *command_val=NULL;
   const vector<CKeyword> &keywords = val->GetKeywordList();
   for (unsigned i=0; i<keywords.size();++i) {
      if (keywords[i].IsDefault()) {
         if (val->GetType() == CVal::KEYWORD) {
            command_val = new CCommandVal(val, keywords[i]);
         } else {
            vector <int> command_key_set;
            command_key_set.push_back(keywords[i].GetCode());
            command_val = new CCommandVal(val, command_key_set);
         }
         break;
      }
   }
   return command_val;
}

/** Sorts the commands in order to fulfill the precedence.
   \param commands The commands to be sorted.
   \pre The precedence graph contains no cycles.
*/
class ComNode : public CNode<ComNode> {
   public:
   ComNode(CCommand *command):command(command){}
   CCommand *command;
};
void
COptionGroups::
SortCommands(CCommands &commands) const
{
   CGraph <ComNode> g;
   ComNode *n;

   // Create a graph with nodes wrapping all commands and a mapping from
   // commands to nodes
   map <CCommand*, ComNode*> command_to_node;
   for (unsigned i=0; i<commands.size(); ++i) {
      n = new ComNode(commands[i]);
      g.AddNode(n);
      command_to_node[commands[i]] = n;
   }

   // Add edges according to precedence: edges from a command to the ones
   // that shall preceed it
   for (unsigned i=0; i<commands.size(); ++i) {
      const vector <COption::KEY> &preceeded_by = commands[i]->GetOption()->GetPrecedence();
      for (unsigned j=0; j<preceeded_by.size(); ++j) {
         if (commands.HasCommand(preceeded_by[j])) {
            CCommand *command_to_preceed = commands.GetCommand(preceeded_by[j]);
            ComNode *current_node = command_to_node[commands[i]];
            ComNode *node_to_preceed = command_to_node[command_to_preceed];
            g.AddEdge(current_node, node_to_preceed);
         }
      }
   }

   // Successively remove the nodes that have no out-edges (i.e. that do not
   // have any other commands that shall preceed it) and put them last in a
   // new vector that will be the order after precedence
   CCommands new_commands;
   unsigned start_of_sequence = 0;
   bool found;
   do {
      // Note that we must pick them an remove them in different passes
      // else we might pick nodes that lost their outedges because we
      // removed its successor in the same pass.
      found = false;
      for (unsigned i=0; i<(unsigned)g.NrOfNodes(); ++i) {
         if (g.NodeAt(i) && g.NodeAt(i)->SuccSize() == 0) {
            new_commands.push_back(g.NodeAt(i)->command);
            found = true;
         }
      }
      for (unsigned i=start_of_sequence; i<new_commands.size(); ++i) {
         n = command_to_node[new_commands.at(i)];
         g.RemoveNode(n);
         delete n;
      }
      start_of_sequence = (unsigned)new_commands.size();
      g.CompressGraph();
   } while (found);

   // The graph is empty iff there are no cycles.
   assert(g.NrOfNodes() == 0);

   // Move the nodes back to the original vector.
   commands.clear();
   for (unsigned i=0; i<new_commands.size(); ++i) {
      commands.push_back(new_commands[i]);
   }
   new_commands.clear();
}

/** For each command representing an option that has a default parameter value:
   set that value. */
void
COptionGroups::
AddDefaultParameters(CCommands &commands) const
{
   for (unsigned i=0; i<commands.size(); ++i) {
      AddDefaultParameters(commands[i]->GetOption(), commands[i]);
   }
}

/** Check if there is a help command in the list. If it is and the user accidently
   typed also other options, then the rest of the options are removed.
   \param commands The commands to be checked.
   \return True if there was a help command.
*/
bool
COptionGroups::
CheckForHelpCommand(CCommands &commands) const
{
   // Chech if help command (if help we don't want other commands
   CCommand *help_command = NULL;
   for (unsigned i=0; i<commands.size(); ++i) {
      const COption *current_option = commands[i]->GetOption();
      if (current_option->GetKey() == COption::HELP) {
         help_command = commands[i];
         break;
      }
   }
   if (help_command) {
      commands.clear();
      commands.push_back(help_command);
   }
   return help_command != NULL;
}

/** Check that no option occure more than once and if options contains
      multiple parameters. Throws an exeption if voilated.
   \param commands The commands to be checked.
*/
void
COptionGroups::
CheckForDuplicates(CCommands &commands) const
{
   for (unsigned i=0; i<commands.size(); ++i) {
      const COption *option1 = commands[i]->GetOption();
      for (unsigned j=0; j<commands.size(); ++j) {
         if (i!=j) {
            const COption *option2 = commands[j]->GetOption();
            if (option1->GetKey() == option2->GetKey()) {
               throw runtime_error("Option '"+option1->GetShortName()+"' given more than once.");
            }
         }
      }
      commands[i]->CheckForDuplicatedArguments();
   }
}
}
