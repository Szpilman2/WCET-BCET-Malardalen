#ifndef CCOMMAND_AE_H_INCLUDED
#define CCOMMAND_AE_H_INCLUDED

#include "CCommand.h"
#include <map>

class CCollector;
class FlowFactTypes;
class AESettings;
class CScopeGraph;
class CScope;

namespace cmd {

class CSession;

/** \class CCommandAE
   Performs abstract execution on the input program.
*/
class CCommandAE : public CCommand
{
public:
  typedef enum KEY { DF, USM, OP, DEBUG, MERGE, GENERATE_TRACE_FILE, READ_TRACE_FILE, 
                     ALF_AST_NODE_BCET_WCET, ALF_AST_NODE_BCET_WCET_PATHS, ALF_AST_NODE_BCET_WCET_PROF,
                     ALF_AST_NODE_BCET_WCET_DEFAULT, OLD_ALF_AST_NODE_BCET_WCET, 
                     BB_COST_BCET_WCET, BB_COST_BCET_WCET_PATHS,
                     TC, ALL_TYPES, GEN_NODES, OPS, STMTS, STMT_PAIRS, SIMPLE_COUNT_PRINTOUT,
                     CSS, ENE, FT, CONTINUE, DO_NOT_CONTINUE, DO_NOT_CONTINUE_WARN, VOLA, IGNORE_VOLATILES, TOP_VOLATILES, 
                     ISI, PU, 
                     NONE, ALL, FE, FR, LE, BE, JE, FFG, INTERACTIVE_DEBUGGER, DEBUG_TRACE} KEY;
  typedef enum FFG_KEY {UHSS, LHSS, UHSF, LHSF, UHSP, LHSP, UHPF, LHPF, UHPP, LHPP, UNSS, LNSS, UNSF, LNSF,
                        UNSP, LNSP, INSE, INSA, UNPS, LNPS, UNPF, LNPF, UNPP, LNPP,
                        INPA, INNA, UESS, LESS, UESF, LESF, UESP, LESP, UCSF, LCSF, UCSP, LCSP,
                        UBSS, LBSS, UBSF, LBSF, UBSP, LBSP, UBNS, LBNS, ALL_FFGS, UB_FFGS, LB_FFGS, ALL_FFGS_NO_INSE } FFG_KEY;

   CCommandAE() : ae_settings(NULL), scope_graph(NULL) { }

   ~CCommandAE();

   /** Check if the arguments are valid. If merging specification contains
      contradictions then a runtime exception will be thrown. */
   void Validate(const CSession *session);

   /** Runs the abstract execution alogrithm on the current ast, requireing a
      scope graph to be present. Using the result of slicing if present.
      \post The flow facts has been added to the scope graph. */
   void Execute(const CSession *session);

   CCommand *Copy() const;

   /** \return A pointer to a vector containing all information collected in the
      last pass when AE was run. */
   const std::vector<CCollector *> *GetCollectors() const { return &collectors; };
   
   /** \return A pointer to a vector containing mappings from scopes (contexts) to
      collected information. */
   const std::vector<std::map<CScope *, CCollector *> *> *GetSCMaps() const { return &sc_maps; };

   /** \return A pointer to a set of flow fact types that are specified for this run of AE. */
   const FlowFactTypes *GetFlowFactTypes() const;

   /** \return A pointer to a set of al settings specified for this run of AE. */
   const AESettings *GetAESettings() const;

   /** Returns a pointer to a scope graph or NULL if it has not yet been
      produced. */
   CScopeGraph *GetScopeGraph() { return scope_graph; }

private:
   std::vector<CCollector *> collectors;
   std::vector<std::map<CScope *, CCollector *> *> sc_maps;
   AESettings *ae_settings;
   CScopeGraph *scope_graph;
};

}

#endif
