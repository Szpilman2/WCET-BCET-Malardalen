#ifndef HELP_H_
#define HELP_H_

namespace cmd {

/** Shows help information about sweets options in a formatted way.
   \param hide_properties Controls if the predifined syntax highlight should be hidden or not
*/
void Help(bool hide_properties=false);

}

#endif
