// $Id $

#include "CSession.h"
#include "CCommandDU.h"
#include "CCommandParse.h"
#include "program/alf/CAlfTuple.h"
#include "graphs/cg/CCallGraph.h"
#include "graphs/cg/CCallGraphNode.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/cfg/CFlowGraphEdgeAnnot.h"

#include "dfa/ALFDefsAndUsesAnalysis.h"
#include "program/alf/AStmt.h"
#include "program/alf/CAlfTuple.h"

#include <map>
#include <set>
#include <iostream>
#include <fstream>


#define DU_FILE_NAME "_ALFDUAnalysis.txt"

using namespace std;

namespace cmd {

CCommandDU::
CCommandDU()
  : _print_analysis_result(false), _output_file_name(""), _du(NULL)
{
  // Do nothing
}

CCommandDU::
~CCommandDU()
{
   if(_du) delete _du;
}
 
CCommand *
CCommandDU::
Copy() const
{
  assert(_du == NULL);
  return new CCommandDU(*this);
}

void
CCommandDU::
Validate(const CSession *session)
{
  // Check if we should print the DU analysis result
  const CCommandArgument *print_argument = GetArgument(PRINT_ANALYSIS_RESULT);
  if(print_argument) {
    _print_analysis_result = true;
    _output_file_name = DU_FILE_NAME;
    AssertFileAccessability(_output_file_name, "w");
  }
}

void
CCommandDU::
Execute(const CSession *session)
{
  // We need the ALF ast (constness removed since it will take a lot
  // of time adding const everywhere in the DU code)
  CCommandParse *command_parse = dynamic_cast<CCommandParse *> (session->GetCommand(COption::PARSE));
  CGenericProgram *generic_ast = command_parse->GetAst();
  const alf::CAlfTuple * c_alf_ast = dynamic_cast<const alf::CAlfTuple *>(generic_ast); 
  alf::CAlfTuple * alf_ast = const_cast<alf::CAlfTuple*>(c_alf_ast);

  // We need abstract annotations if they exist
  CALFAbsAnnotStorage * annots = command_parse->GetAnnotStorage();

  // We need the pointer analysis (constness removed since it will
  // take a lot of time adding const everywhere in the DU code)
  CSteensgaardPA *pa = const_cast<CSteensgaardPA *>(command_parse->GetPointerAnalysis());

  // We need the symbol table (constness removed since it will
  // take a lot of time adding const everywhere in the DU code)
  CSymTabBase * symtab =  const_cast<CSymTabBase *>(alf_ast->GetSymTab());

  // We need the call graph
  CCallGraph *cg = command_parse->GetCallGraph();

  assert(alf_ast);
  assert(cg);
  assert(pa);
  assert(symtab);

  // -------------------------------------------------------
  // Create DU analysis (useful for other analyses)
  // -------------------------------------------------------

  // Create defs and uses analysis
  _du = new ALFDefsAndUsesAnalysis(pa, symtab, annots, alf_ast->GetInits());
  
  // -------------------------------------------------------
  // Print DU analysis (if wanted)
  // -------------------------------------------------------

  // Set to true if debugging of DU needed 
  if(_print_analysis_result)
  {
    cout << "<<<< prints DU analysis result to file: " << _output_file_name << endl; 
    // Open the file stream
    ofstream fs;
    fs.open(_output_file_name.c_str(), ios::out);

    // Loop through all the cfgs in the cg
    for(CCallGraph::node_iterator cg_node = cg->NodesBegin(); cg_node != cg->NodesEnd(); ++cg_node) {
      // Get the corresponding flow graph
      CFlowGraph * cfg = (*cg_node)->FlowGraph();
      // Loop through all the cfg nodes
      for(CFlowGraph::node_iterator cfg_node = cfg->NodesBegin(); cfg_node != cfg->NodesEnd(); ++cfg_node) {
	alf::AStmt * astmt = dynamic_cast<alf::AStmt *>((*cfg_node)->Stmt());
	std::set<unsigned int> defs;
	std::set<unsigned int> uses;
	_du->GetDefsAndUsesOfStmt(astmt, &defs, &uses);
	fs << "stmt: " << astmt->Name() << " defs:";
	for(std::set<unsigned int>::iterator d = defs.begin(); d != defs.end(); ++d) {
	  fs << " " << symtab->Lookup(*d)->GetIdentifier()->Name() << " " << *d;
	}
	fs << " uses:";
	for(std::set<unsigned int>::iterator u = uses.begin(); u != uses.end(); ++u) {
	  fs << " " << symtab->Lookup(*u)->GetIdentifier()->Name() << " " << *u;
	}
	fs << endl;
      }
    }

    // Close the file stream
    if (fs.is_open()) {
         fs.close();
    }
  }
}

} // end namespace cmd
