#ifndef CCOMMAND_RD_H_
#define CCOMMAND_RD_H_

#include "CCommand.h"
#include <map>
#include "rd/ReachingDefinitionsAnalysis.h"
#include "rd/ALFReachingDefinitionsAnalysis.h"
#include "dfa/ALFDefsAndUsesAnalysis.h"
#include "alf_slicing/ALFExtendedProgramControlFlowGraph.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/ecfg/CECFGNode.h"

// -------------------------------------------------------
// Code for setting up reaching definitions (RD) analysis on a ALF
// code. Can either be run on an CG or an ECFG. Resulting RD analysis
// data structure can be used as input to other analyses.
// -------------------------------------------------------

namespace cmd {

class CSession;

class RDSettings {
public:
  // Nice access functions

  // We can run CHAOTIC, WORK_LIST, NODE_ORDERING 
  ReachingDefinitionsAnalysis::ANALYSIS_TYPE GetAnalysisType() const { return _analysis_type; }
  // Can be NONE, ITERATION, FIX_POINT_PASS, RESULT
  ReachingDefinitionsAnalysis::PRINT_DRAW_SPECIFICATION GetPrintSpecification() const { return _print_specification; }
  ReachingDefinitionsAnalysis::PRINT_DRAW_SPECIFICATION GetDrawSpecification() const { return _draw_specification; }

  // Internal data structures, to be set by CCommandRD
  ReachingDefinitionsAnalysis::ANALYSIS_TYPE _analysis_type;
  ReachingDefinitionsAnalysis::PRINT_DRAW_SPECIFICATION _print_specification;
  ReachingDefinitionsAnalysis::PRINT_DRAW_SPECIFICATION _draw_specification;
};

/** \class CCommandRD
   Performs reaching definitions analysis on the input program.
*/
class CCommandRD : public CCommand
{
public:

  // To create and delete the value analysis object
  CCommandRD();
  ~CCommandRD();

  // An enum holding all values that can be set by the user
  typedef enum KEY { GRAPH, CG, ECFG,
		     ANALYSIS_TYPE, NODE_ORDERING, CHAOTIC, WORK_LIST, 
                     PRINT_ANALYSIS_RESULT, DRAW_ANALYSIS_RESULT, 
		     RESULT, ITERATION } KEY;

  // Check if the arguments are valid. 
  void Validate(const CSession *session);

  // Runs the RD analysis alogrithm on the current cg or ecfg. 
  void Execute(const CSession *session);

  // To copy the commando 
  CCommand *Copy() const;

  // To get the internal settings 
  const RDSettings * GetRDSettings() const { return _rd_settings; }

  // Returns a pointer to the resulting RD analysis result. 
  ALFReachingDefinitionsAnalysis * GetRDAnalysis() const { return _rd; }

  // To get the extended program control flow graph which the RD analysis was based upon
  ALFExtendedProgramControlFlowGraph * GetPCFG() const { return _pcfg; }

protected:

   // The settings
   RDSettings *_rd_settings;

   // The RD analysis objects 
   ALFReachingDefinitionsAnalysis * _rd;
   ALFExtendedProgramControlFlowGraph * _pcfg;
   ALFDefsAndUsesAnalysis * _du;

};




} // end cmd namespace

#endif
