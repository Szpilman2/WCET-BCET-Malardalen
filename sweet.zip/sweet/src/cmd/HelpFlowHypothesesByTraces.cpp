#include "HelpFlowHypothesesByTraces.h"
#include <iostream>
#include <sstream>

using namespace std;

namespace help_flow_hypotheses_by_traces {

// Help macros to define colors
#define CSI_BLUE     std::string("\033[34m")
#define CSI_GREEN    std::string("\033[32m")
#define CSI_MAGENTA  std::string("\033[35m")
#define CSI_BOLD     std::string("\033[1m")
#define CSI_RESET    std::string("\033[0m")

// Help functions
std::string make_title(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return X;
}

std::string make_opt(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return CSI_BOLD + X + CSI_RESET;
}

std::string make_arg(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return CSI_BOLD + CSI_MAGENTA + X + CSI_RESET;
}

std::string make_nterm(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return CSI_BOLD + CSI_MAGENTA + X + CSI_RESET;
}

std::string make_term(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return CSI_BOLD + X + CSI_RESET;
}

std::string make_rule(std::string X, bool no_csi)
{
  if(no_csi) return X;
  else return CSI_BOLD + CSI_MAGENTA + X + CSI_RESET;
}

// Help macros for avoiding writing whole function calls
#define TITLE(X) make_title(X,no_csi)
#define OPT(X) make_opt(X,no_csi)
#define ARG(X) make_arg(X, no_csi)
#define NTERM(X) make_nterm(X, no_csi)
#define TERM(X) make_term(X, no_csi)
#define RULE(X) make_rule(X, no_csi)

// The function printing the actual help text. Bool decides
// if CSI highlighting should be use or not
void HelpFlowHypothesesByTraces(bool no_csi)
{
cout 
<< endl
<< TITLE("HELP TEXT FOR SWEET'S TRACE-BASED FLOW HYPOTHESIS GENERATION") << endl
<< TITLE("------------------------------------------------------------") << endl
<< endl
<< "SWEET allow derivation of flow hypothesis using traces." << endl
<< "When running the AE in trace mode two inputs need to given to SWEET:" << endl
<< "1. A file holding a set of traces. Each trace is a list of nodes ending by" << endl
<< "a semi-colon. Each trace must be a path of nodes possible in the CFGs." << endl 
<< "2. A file holding a set of CFGs. Each CFG should be a connected graph with" << endl
<< "a dedicated start node, a set of nodes, and a set of edges connecting the" << endl
<< "nodes. Each CFG can also hold a set of call edges going from a node in the" << endl
<< "CFG to a named CFG." << endl  
<< endl
<< "SWEET will collect all the traces into a set of flow hypothesis. The format" << endl  
<< "of these hypotheses are exatly the same as the flow facts. However, flow" << endl
<< "hypothesis are different from flow facts since they are not guaranteed to" << endl
<< "be guaranteed lower and upper bounds on the program's possible executions." << endl
<< "Instead, the flow hypothesis are only valid for the given traces, holding" << endl
<< "the lower and upper bounds encountered for the traces." << endl
<< endl
<< TITLE("ILLUSTRATING EXAMPLE") << endl
<< TITLE("--------------------") << endl
<< endl 
<< "The following example code snippet: " << endl
<< "  int foo(int j) {   // BB0" << endl
<< "     while(j < 5) {  // BB1" << endl
<< "        if(j < 3)    // BB2" << endl   
<< "           j++;      // BB3" << endl   
<< "        else                " << endl
<< "           j=j+2;    // BB4" << endl   
<< "        j++;         // BB5" << endl
<< "     }                     " << endl
<< "     return j;       // BB6" << endl
<< "  }                       " << endl      
<< endl
<< "Corresponds the following CFG: " << endl
<< "  begin CFG " << endl
<< "    name foo ;" << endl
<< "    startnode BB0 ;" << endl
<< "    nodes BB0 BB1 BB2 BB3 BB4 BB5 BB6 ;" << endl
<< "    edges BB0->BB1 BB1->BB2 BB2->BB3 BB2->BB4" << endl
<< "          BB3->BB5 BB4->BB5 BB5->BB1 BB1->BB6 ;" << endl
<< "    calls ;" << endl
<< "  end CFG" << endl
<< endl
<< "Assuming that we have the following three traces: " << endl
<< "  BB0 BB1 BB2 BB3 BB5 BB1 BB2 BB3 BB5 BB1 BB2 BB4 BB5 BB1 BB6 ;" << endl
<< "  BB0 BB1 BB2 BB3 BB5 BB1 BB2 BB4 BB5 BB1 BB6 ; " << endl
<< "  BB0 BB1 BB2 BB4 BB5 BB1 BB6 ; " << endl
<< endl
<< "SWEET can, for example, generate the following flow hypotheses:" << endl
<< "  : foo : [] : BB1 >= 2 ;       %% Lower bound for BB1 loop header" << endl
<< "  : foo : [] : BB1 <= 4 ;       %% Upper bound for BB1 loop header" << endl
<< "  : foo : [] : BB2 <= 3 ;       %% Upper bound for BB2 node" << endl
<< "  : foo : [] : BB5->BB1 <= 3 ;  %% Upper bounds for loop back-edge" << endl
<< endl
<< TITLE("FLOW HYPOTHESES GENERATION") << endl
<< TITLE("--------------------------") << endl
<< endl
<< "The basic input options to use are: " << endl
<< "sweet -i=<f.cfg> lang=cfg -x rtf=<f.trace> -f" << endl
<< "where f.cfg and f.trace are the name of the files holding" << endl
<< "the cfg graphs and traces respectively. " << endl 
<< endl
<< "The flow hypothesis generation work similar to the AE by recorders" << endl
<< "and collectors. This means that every flow fact generator which " << endl
<< "could be given using -x ffg=... could also be used to generate " << endl
<< "flow hypotheses. Similar to flow facts, the flow hypotheses can be" << endl
<< "exported in various formats. For example, if all type of flow " << endl
<< "hypotheses should be generated use: " << endl
<< "sweet -i=<f.cfg> lang=cfg -x rtf=<f.trace> ffg=all" << endl
<< "For details of SWEET's flow fact generation: sweet -h topic=ffg" << endl
<< endl
<< "To assist in the flow hypothesis generation SWEET also supports: " << endl
<< "- printouts of CFGs from ALF programs: -i=<f.alf> -p" << endl
<< "- trace generation from an AE run on ALF programs: -x gtf=<f.trace>" << endl 
<< "  (requires that SWEET runs in single path mode) " << endl
<< "- running AE on ALF program by a trace: -i=<f.alf> -x rtf=<f.trace>" << endl
<< endl 
<< TITLE("BNF GRAMMAR TRACE FILE") << endl
<< TITLE("----------------------") << endl
<< endl
<< "tracefile -> " << endl
<< "   | trace_list" << endl 
<< endl
<< "trace_list -> " << endl
<< "   | trace_list trace" << endl 
<< "   | trace" << endl
<< endl
<< "trace -> " << endl
<< "   | node_list ';'" << endl
<< endl
<< "node_list -> " << endl
<< "   | node_list nodeid " << endl
<< "   | nodeid " << endl
<< endl
<< "nodeid -> " << endl
<< "   | <string>" << endl 
<< endl
<< TITLE("BNF GRAMMAR CFG FILE") << endl
<< TITLE("--------------------") << endl
<< endl
<< "cfgfile -> " << endl
<< "    | cfg_list" << endl 
<< endl
<< "cfg_list -> " << endl
<< "   | cfg_list cfg" << endl 
<< "   | cfg" << endl
<< endl 
<< "cfg -> " << endl
<< "   | 'begin CFG' cfgname startnode nodes edges calls 'end CFG'" << endl
<< endl
<< "cfgname -> " << endl
<< "   | 'name' funcname ';'" << endl 
<< endl
<< "startnode -> " << endl
<< "   | 'startnode' nodeid ';'" << endl 
<< endl
<< "nodes -> " << endl
<< "   | 'nodes' node_list ';'" << endl
<< endl
<< "node_list -> " << endl
<< "   | node_list nodeid " << endl
<< "   | nodeid " << endl
<< endl
<< "edges -> " << endl
<< "   | 'edges' edge_list ';'" << endl
<< endl
<< "edge_list -> " << endl
<< "   | edge_list edge" << endl 
<< "   | edge " << endl
<< "   | " << endl
<< endl
<< "edge -> " << endl
<< "   | nodeid '->' nodeid " << endl
<< endl
<< "calls -> " << endl
<< "   | 'calls' call_list ';'" << endl
<< endl
<< "call_list -> " << endl 
<< "   | call_list call " << endl
<< "   | call " << endl
<< endl
<< "call -> " << endl
<< "   | nodeid '->' funcname" << endl 
<< endl
<< "funcname -> " << endl
<< "   | <string>" << endl 
<< endl
<< "nodeid -> " << endl
<< "   | <string>" << endl;
}

} // end namespace help trace" << endl

 

