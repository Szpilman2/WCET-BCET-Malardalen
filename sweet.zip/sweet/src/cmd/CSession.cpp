#include "CSession.h"
#include "CCommands.h"
#include "COption.h"
#include <stdexcept>
#include <sstream>

using namespace std;

namespace cmd {

CSession::
~CSession()
{
}

void
CSession::
SetCommands(CCommands *new_commands)
{
   commands = new_commands;
}

CCommand *
CSession::
GetCommand(COption::KEY key) const
{
   assert(HasCommand(key));
   return commands->GetCommand(key);
}

bool
CSession::
HasCommand(COption::KEY key) const
{
   return commands->HasCommand(key);
}

void
CSession::
ValidateCommands() const
{
   for (unsigned i=0; i<commands->size(); ++i) {
      (*commands)[i]->Validate(this);
   }
}

void
CSession::
DispatchCommands() const
{
   for (unsigned i=0; i<commands->size(); ++i) {
      CCommand * command = (*commands)[i];
      cout << "Executing command '" << command->GetOption()->GetLongName() << "'.\n";
      try {
         command->Execute(this);
      }
      catch(exception const& e)
      {
         stringstream ss;
         ss << "Error during execution of command '" << command->GetOption()->GetLongName() << "': " << e.what();
         throw runtime_error(ss.str());
      }
   }
}

}
