#ifndef HELPANNOT_H_
#define HELPANNOT_H_

namespace help_annot {

/** Shows help information about sweets options in a formatted way.
*/
void HelpAnnot(bool no_csi=false);

}

#endif
