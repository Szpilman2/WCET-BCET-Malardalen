#ifndef INPUT_OPTIONS_H_
#define INPUT_OPTIONS_H_

#include <vector>

namespace cmd {

class CInputOption;

/** \class CInputOptions
   Contains a set of input options.
*/
class CInputOptions : public std::vector <CInputOption*>
{
public:
   /** Constructs a set of input options based on a command line argument
      as it appears in the parameter list to main(). */
   CInputOptions(int nr_of_args, char **args);

   ~CInputOptions();
};
}

#endif
