// $Id $

#include "Call.h"
#include "FunctionId.h"
#include <string>
#include <vector>

using namespace std;

namespace cfgs {

Call::~Call(void)
{
   delete called_function;
}

Call::Call(string call_node, const FunctionId *called_function) :
   call_node(call_node),
   called_function(called_function)
{
}

string Call::CallingNode(void) const
{
   return call_node;
}

}
