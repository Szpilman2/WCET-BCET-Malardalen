// $Id $

#ifndef CFGS_CALL_H_INCLUDED
#define CFGS_CALL_H_INCLUDED

#include <string>
#include <vector>

namespace cfgs {

class FunctionId;

/// \class
///   Represents one call in a "function call" in a cfg in a "cfgs program".
class Call
{
public:
   /// Constructs one call. The parameters should be well known from the grammar.
   /// \pre \a call_node and \a returns_to_node are present in the list of nodes 
   ///   of the same cfg as where this call is located.
   /// \pre The names of the \a FunctionId in \a called_functions are namse of 
   ///   cfgs in the same "cfgs program" as where this call is present.
   /// \param call_node The node where the call takes place
   /// \param called_function The called function.
   Call(std::string call_node, const FunctionId *called_function);
   ~Call(void);

   /// \return The function that may be called.
   const FunctionId *CalledFunction() const { return called_function; }

   /// \return The calling node.
   std::string CallingNode(void) const;

private:
   std::string call_node;
   const FunctionId *called_function;
};

}

#endif


