// $Id $

#include "Stmt.h"
#include "FunctionId.h"
#include "Function.h"
#include "symtab/CSymTabBase.h"

using namespace std;

namespace cfgs {

Stmt::
Stmt(std::string name, unsigned key) :
   CGenericStmt(CGenericStmt::GS_UNKNOWN),
   name(name),
   key(key)
{}




StmtCall::
StmtCall(std::string stmt_name, unsigned key, const std::vector<const FunctionId*> *called_functions) :
   CGenericStmt(CGenericStmt::GS_CALL),
   name(stmt_name),
   key(key),
   called_functions(called_functions)
{}

StmtCall::
~StmtCall()
{
   for (vector<const FunctionId*>::const_iterator func_it=called_functions->begin(); func_it!=called_functions->end(); ++func_it)
   {
      const FunctionId *func_id = *func_it;
      delete func_id;
   }
}

void
StmtCall::
CalledFunctions(list<CGenericFunction*> *functions, const CSymTabBase *symtab, const CSteensgaardPA &pa) const
{
   for (vector<const FunctionId*>::const_iterator func_it=called_functions->begin(); func_it!=called_functions->end(); ++func_it)
   {
      const FunctionId *func_id = *func_it;
      const CSymTabEntry *entry = symtab->Lookup(func_id->GetKey());
      const FunctionIdDecl *func_decl_id = dynamic_cast<const FunctionIdDecl*>(entry->GetCodeIdentifier());
      functions->push_back(func_decl_id->GetFunction());
   }
}

}
