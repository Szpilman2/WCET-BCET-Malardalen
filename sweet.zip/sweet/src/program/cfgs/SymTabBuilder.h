// $Id $

#ifndef CFGS_SYM_TAB_BUILDER_H_INCLUDED
#define CFGS_SYM_TAB_BUILDER_H_INCLUDED

#include "symtab/CSymTabBuilderBase.h"

#include <vector>

class CGenericFunction;

namespace cfgs {

/// \class
/// Builds a symbol table for a "cfgs program". The table only contains
/// function names (i.e. cfg names).
class SymTabBuilder : public CSymTabBuilderBase
{
public:
   SymTabBuilder(std::vector<CGenericFunction*> &functions, CSymTabBase *symtab);
};

}

#endif
