   // $Id $

#include "SymTabBuilder.h"
#include "Call.h"
#include "FunctionId.h"
#include "Function.h"
#include "program/CGenericFunction.h"
#include <stdexcept>

using namespace std;

namespace cfgs {

SymTabBuilder::
SymTabBuilder(vector<CGenericFunction*> &functions, CSymTabBase *symtab)
{
   // Add all function definitions (i.e. the id:s of all existing flow graphs) to the symbol table
   for (vector<CGenericFunction*>::iterator func_it=functions.begin(); func_it!=functions.end(); ++func_it)
   {
      Function *function = dynamic_cast<Function*>(*func_it);
      FunctionIdDecl *func_id = function->GetIdentifier();
      CSymTabEntry::TYPE type = (CSymTabEntry::TYPE)(CSymTabEntry::CODE|CSymTabEntry::FUNCTION);
      CSymTabBuilderBase::AddSym(symtab, func_id, type);
   }

   // Patch the referencing identifiers (i.e. those in the calls) with the key in the symbol table
   for (vector<CGenericFunction*>::iterator func_it=functions.begin(); func_it!=functions.end(); ++func_it)
   {
      Function *function = dynamic_cast<Function*>(*func_it);
      vector<Call*> *calls = function->GetCalls();
      for (vector<Call*>::iterator call_it=calls->begin(); call_it!=calls->end(); ++call_it)
      {
         Call *cfg_call = *call_it;
         const FunctionId *func_id = cfg_call->CalledFunction();
         const CSymTabEntry *entry = symtab->Lookup(func_id->Name());
         if (entry == NULL)
         {
            throw runtime_error("Function (i.e. CFG name) \""+func_id->Name()+"\" is called, but does not exist.");
         }
         CSymTabBuilderBase::SetKey(func_id, entry->GetIdentifier()->GetKey());
      }
   }
}

}
