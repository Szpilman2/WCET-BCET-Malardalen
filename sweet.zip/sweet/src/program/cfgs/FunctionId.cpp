// $Id $

#include "FunctionId.h"
#include "Function.h"

namespace cfgs {

FunctionIdDecl::
FunctionIdDecl(std::string name, Function *function) :
   name(name),
   function(function)
{ }

CGenericFunction *
FunctionIdDecl::
GetFunction() const
{
   return function;
}

}
