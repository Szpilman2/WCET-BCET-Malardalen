// $Id $

#include "Program.h"
#include "Function.h"
#include "SymTabBuilder.h"
#include "ptranal/CSteensgaardAnalysisBuilder.h"

using namespace std;

namespace cfgs {

Program::
~Program()
{
   for (vector<Function*>::iterator func_it=function_list->begin(); func_it!=function_list->end(); ++func_it)
   {
      Function *function=*func_it;
      delete function;
   }
}

Program::
Program(vector<Function*> *function_list) :
   CGenericProgram(),
   function_list(function_list)
   { }

const CSymTabBase *
Program::
GetSymTab() const
{
   CSymTabBase *symtab = new CSymTabBase();
   vector<CGenericFunction*> functions;
   Functions(functions);
   SymTabBuilder(functions, symtab);
   return symtab;
}

void
Program::
Functions(vector<CGenericFunction*> &functions) const
{
   functions.insert(functions.end(), function_list->begin(), function_list->end());
}

// Dummy class to be able to implement the interface
class SteensgaardAnalysisBuilderCfg : public CSteensgaardAnalysisBuilder
{
public:
void GetVarsLabelsAndFuncs(const CGenericProgram *ast, const CSymTabBase *symtab, std::set<unsigned> &vars,
                           std::set<unsigned> &labels, lambda_t &lambda_funcs, std::set<unsigned> &temp_vars,
                           unsigned &key_size) {};
void TraverseCode(const CGenericProgram *ast, CSteensgaardPA *spa, lambda_t &lambda_funcs) {};
};

std::unique_ptr <CSteensgaardAnalysisBuilder>
Program::
GetSteensgaardAnalysisBuilder()
{
   return  std::unique_ptr <CSteensgaardAnalysisBuilder>(new SteensgaardAnalysisBuilderCfg());
}

}
