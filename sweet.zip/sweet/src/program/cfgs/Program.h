// $Id $

#ifndef CFGS_PROGRAM_H_INCLUDED
#define CFGS_PROGRAM_H_INCLUDED

#include "program/CGenericProgram.h"
#include <vector>
#include <memory>

namespace cfgs {

class Function;

/// \class
///   Represents an entire program parsed from the "cfgs" format.
///   Such a program simply consists of a set of control flow graphs (here represnted as
///   Functions)
class Program : public CGenericProgram
{
public:
   /// Construct a new \a Program. A \a program consists of a list of functions.
   Program(std::vector<Function*> *function_list);

   ~Program();

   /// Fulfill the \a CGenericProgram interface. Adds all functions to the vector.
   void Functions(std::vector<CGenericFunction*> &functions) const;

   /// Fulfill the \a CGenericProgram interface. We actually use the symbol table
   /// we generate (for function/cfg names). That is when the call statement is
   /// asked for called functions.
   const CSymTabBase * GetSymTab() const;

   /// These are dummies to fulfill the \a CGenericProgram interface.
   void AsText(CTextBlock *text_block, int indentation=0) const { }
   void CreateSymbolTable() { }

   /// This is actually too a dummy to fulfill the \a CGenericProgram interface,
   /// but needs to be little more sofisticated to be able to return an empty pointer
   /// analysis.
   std::unique_ptr <CSteensgaardAnalysisBuilder> GetSteensgaardAnalysisBuilder();

private:
   std::vector<Function*> *function_list;
};

}

#endif

