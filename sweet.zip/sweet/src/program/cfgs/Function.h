// $Id $

#ifndef CFGS_FUNCTION_H_INCLUDED
#define CFGS_FUNCTION_H_INCLUDED

#include "program/CGenericFunction.h"
#include <string>
#include <vector>
#include <utility>

namespace cfgs {

class FunctionId;
class FunctionIdDecl;
class Call;

/// \class
///   Represents one cfg.
class Function  : public CGenericFunction
{
public:
   /// Constructs a new \a Function. The parameters should be well known from the
   /// specification of one cfg in the grammar.
   /// \param func_id The identifier of this function (i.e. the name of the cfg that
   ///      this function represents)
   /// \param start_node The start node of the cfg
   /// \param nodes The nodes of the cfg
   /// \param edges The edges of the cfg
   /// \param calls The calls specification of the cfg
   Function(FunctionId *func_id, std::string start_node, std::vector<std::string> *nodes,
            std::vector<std::pair<std::string,std::string>*> *edges, std::vector<Call*> *calls);

   ~Function();

   /// Fulfill the \a CGenericFunction interface. Returns a new flow graph.
   std::unique_ptr<CFlowGraph> CreateFlowGraph() const;

   /// Fulfill the \a CGenericFunction interface. Returns the name of this function (cfg) as found in the file.
   std::string Name() const;

   /// Fulfill the \a CGenericFunction interface. Returns the name of this function (cfg) as found in the file.
   std::string PrettifiedName() const { return Name(); }

   /// These Extends the CGenericFunction:

   /// Returns the calls specification as found in the parsed file.
   std::vector<Call*> *GetCalls() { return calls; }

   /// Returns the identifier object representing this function
   FunctionIdDecl *GetIdentifier() { return func_id_decl; }

   /// These are dummies to fulfill the \a CGenericFunction interface.
   unsigned Key() const { return 0; }
   void AsText(CTextBlock *text_block, int indentation) const { }
   void Stmts(std::vector<CGenericStmt*> *stmts) const { }

private:
   FunctionIdDecl *func_id_decl;
   std::string start_node;
   std::vector<std::string> *nodes;
   std::vector<std::pair<std::string,std::string>*> *edges;
   std::vector<Call*> *calls;
   static int sequence_number;
};

}

#endif

