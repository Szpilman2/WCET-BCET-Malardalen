// $Id $

#include "Function.h"
#include "FunctionId.h"
#include "Stmt.h"
#include "Call.h"
#include "graphs/cfg/CFlowGraph.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/cfg/CFlowGraphEdgeAnnot.h"
#include <sstream>
#include <stdexcept>

using namespace std;

namespace cfgs {

int Function::sequence_number;

Function::
Function(FunctionId *func_id, string start_node, vector<string> *nodes,
         vector<pair<string,string>*> *edges, vector<Call*> *calls) :
   CGenericFunction(),
   start_node(start_node),
   nodes(nodes),
   edges(edges),
   calls(calls)
{
   func_id_decl = new FunctionIdDecl(func_id->Name(), this);
   delete func_id;
}

Function::
~Function()
{
   delete func_id_decl;
   delete nodes;
   for (vector<pair<string, string>*>::iterator edge_it=edges->begin(); edge_it!=edges->end(); edge_it++)
   {
      pair<string, string>*edge = *edge_it;
      delete edge;
   }
   delete edges;
   for (vector<Call*>::iterator call_it=calls->begin(); call_it!=calls->end(); ++call_it)
   {
      Call *cfg_call = *call_it;
      delete cfg_call;
   }
   delete calls;
}

string
Function::
Name() const
{
   return func_id_decl->Name();
}

std::unique_ptr<CFlowGraph>
Function::
CreateFlowGraph() const
{
   unique_ptr<CFlowGraph> flow_graph(new CFlowGraph(const_cast<Function*>(this)));

   // Join all targets concerning the same call sites (in case of functions pointers
   // there may be an overestimation yielding in more than one function being called
   // by the same call site).
   map<string, vector<const FunctionId *> > possible_calls;
   for (vector<Call*>::iterator call_it=calls->begin(); call_it!=calls->end(); ++call_it)
   {
      Call *cfg_call = *call_it;
      string calling_node_id = cfg_call->CallingNode();
      possible_calls[calling_node_id].push_back(cfg_call->CalledFunction());
   }

   // We need this to translate the edge specifications id:s to nodes in the flowgraph
   map<string, CFlowGraphNode*> id_to_node;

   // Add nodes. Each node needs a statement. We distinguish between call statements and other
   for (vector<string>::iterator node_it=nodes->begin(); node_it!=nodes->end(); ++node_it)
   {
      string node_id = *node_it;
      if (id_to_node.find(node_id) == id_to_node.end())
      {
         // Don't add multiple copies: Note: the call-nodes are already there
         CGenericStmt *stmt;
         if (possible_calls.find(node_id) != possible_calls.end())
         {
            stmt = new StmtCall(node_id, sequence_number++, new const vector<const FunctionId *>(possible_calls[node_id]));
         }
         else
         {
            stmt = new Stmt(node_id, sequence_number++);
         }
         CFlowGraphNode *node = new CFlowGraphNode(stmt, flow_graph.get());
         id_to_node[node_id] = node;
         flow_graph->AddNode(node);
      }
   }

   // Check that the call specification is correct.
   for (map<string, vector<const FunctionId *> >::iterator call_it=possible_calls.begin(); call_it!=possible_calls.end(); ++call_it)
   {
      string calling_node_id = call_it->first;
      if (id_to_node[calling_node_id] == NULL)
      {
         throw runtime_error("A call from node \""+calling_node_id+"\" is specified, but there is no such node in the node list.");
      }
   }


   // Add the edges.
   for (vector<pair<string,string>*>::iterator edge_it=edges->begin(); edge_it!=edges->end(); edge_it++)
   {
      pair<string, string>*edge = *edge_it;
      CFlowGraphNode *from = id_to_node[edge->first];
      if (from==NULL)
      {
         string node_name = edge->first;
         throw runtime_error("Source node \""+node_name+"\" of an edge does not exist.");
      }
      CFlowGraphNode *to = id_to_node[edge->second];
      if (to==NULL)
      {
         string node_name = edge->second;
         throw runtime_error("Source node \""+node_name+"\" of an edge does not exist.");
      }      
      flow_graph->AddEdge(from, to, new CFlowGraphEdgeAnnot());
   }

   CFlowGraphNode *entry = id_to_node[start_node];
   if (entry==NULL)
   {
      throw runtime_error("Start node \""+start_node+"\" does not exist.");
   }
   flow_graph->SetEntry(entry);
   flow_graph->FindRoot();
   return flow_graph;
}

}
