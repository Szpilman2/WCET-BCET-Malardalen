// $Id $

#ifndef CFGS_FUNCTION_ID_H_INCLUDED
#define CFGS_FUNCTION_ID_H_INCLUDED

#include "symtab/CSymTabIdentifier.h"
#include <string>

namespace cfgs {

class Function;

/// \class
///   Represents a function reference identifier
class FunctionId : public CSymTabIdentifier
{
public:
   FunctionId(std::string name) : name(name) { }

   std::string Name() const { return name; }
   std::string PrettifiedName() const { return name; }
   void AcceptVisitor(SymTabIdentifierVisitor * visitor) const { }

private:
   std::string name;
};

/// \class
///   Represents a function declaration identifier
class FunctionIdDecl : public CSymTabIdentifierCode
{
public:
   FunctionIdDecl(std::string name, Function *function);

   CGenericFunction *GetFunction() const;
   std::string Name() const { return name; }
   std::string PrettifiedName() const { return name; }
   void AcceptVisitor(SymTabIdentifierVisitor * visitor) const { }

private:
   std::string name;
   Function *function;
};

}

#endif
