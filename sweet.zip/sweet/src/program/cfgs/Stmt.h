// $Id $

#ifndef CFGS_STMT_H_INCLUDED
#define CFGS_STMT_H_INCLUDED

#include "program/CGenericStmt.h"
#include <string>
#include <vector>

class CSymTabBase;
class CSteensgaardPA;
class CAliasGraph;

namespace cfgs {

class FunctionId;

/// \class
///   Represents a statement with no semantic. Is therefor useful as a
///   place holder in contexts where statements are expected but no
///   special semantics are desired. Basically the methods are just
///   dummies to implement the \a CGenericStmt interface. (Possibly
///   \a Key and \a Name might be meaningful to use).
class Stmt: public CGenericStmt
{
public:
   Stmt(std::string name, unsigned key);

   CGenericStmt *Duplicate() { return new Stmt(name, key); }

   unsigned Key() const { return key;}

   std::string Name() const { return name; }

   std::string PrettifiedName() const { return Name(); }

   void Uses(CAliasGraph *alias_graph, std::set<int> *uses) { }
   void Updates(CAliasGraph *alias_graph, std::set<int> *updated_vars) { }
   void Variables(CAliasGraph *alias_graph, std::set<int> *vars) { }
   bool IsCond() const {return false;}
   bool IsLoopCond() { return false; }
   void AsText(CTextBlock *text_block, int indentation) const { }
   void PrintAsDot(std::ostream &o) const { }

private:
   std:: string name;
   unsigned key;
};

/// \class
///   Like \a Stmt this is basically a dummy place holder. However, this
///   is also a place holder for an interprocedure connection - an implicit
///   edge between two cfgs.
class StmtCall: public CGenericStmtCall
{
public:
   /// Constructs a new StmtCall
   /// \param stmt_name The name of this statement.
   /// \param key The key of this statement.
   /// \param called_functions A list of the functions called by this statement.
   ///      For ordinary function calls this list contains a single statement.
   ///      However, if this statement represents a call using a function pointer
   ///      and the "cfgs program" is produced by an analysis that could not
   ///      exactely define which cfg that was called, but instead a set of
   ///      possible candidates, then the list may contain more than one function reference.
   StmtCall(std::string stmt_name, unsigned key, const std::vector<const FunctionId*> *called_functions);
   ~StmtCall();

   /// Fulfill the \a CGenericStmtCall interface.
   /// Adds the called functions to a list of functions.
   void CalledFunctions(std::list<CGenericFunction*> *functions, const CSymTabBase *symtab, const CSteensgaardPA &pa) const;

   CGenericStmt *Duplicate() { return new StmtCall(name, key, called_functions); }
   unsigned Key() const { return key;}
   std::string Name() const { return name; }
   std::string PrettifiedName() const { return Name(); }

   /// These are dummies to fulfill the \a CGenericStmtCall interface.
   void Uses(CAliasGraph *alias_graph, std::set<int> *uses) { }
   void Updates(CAliasGraph *alias_graph, std::set<int> *updated_vars) { }
   void Variables(CAliasGraph *alias_graph, std::set<int> *vars) { }
   bool IsCond() const {return false;}
   bool IsLoopCond() { return false; }
   void AsText(CTextBlock *text_block, int indentation) const { }
   void PrintAsDot(std::ostream &o) const { }

private:
   std::string name;
   unsigned key;
   const std::vector<const FunctionId*> *called_functions;
};

}

#endif

