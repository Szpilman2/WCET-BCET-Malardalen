// $Id $

#ifndef ALF_CGENERICLIST_H
#define ALF_CGENERICLIST_H

#include "CListNode.h"
#include "AlfNodeVisitor.h"

namespace alf
{   
   class CGenericList : public CListNode<CGenericNode>
   {
   public:
      CGenericList(const COORD& coord, const std::vector<CGenericNode*>& p_list=std::vector<CGenericNode*>(), bool print_brackets=true, bool print_elements_with_endl=true);
      virtual ~CGenericList();
      
      virtual CGenericList* Copy() const;
      
      /**
       * Accept visit from an AlfNodeVisitor
       */
      virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitGenericList(*this);}

      /**
       * Gets the type of the node.
       * @return  The type of the node so that it can be identified quickly.
       */
      virtual TYPE GetNodeType() const { return TYPE_GENERIC_LIST; } 
      
      /** 
       * Checks if the node has a certain type. Should be overwritten by subclasses.
       * @return  true or false.
       */
      virtual bool IsType(TYPE t) const {return t == TYPE_GENERIC_LIST || CListNode<CGenericNode>::IsType(t); }
      
   protected:
      virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   };
   
}

#endif
