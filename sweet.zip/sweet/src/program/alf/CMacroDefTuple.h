// $Id $

#ifndef ALF_CMACRODEFTUPLE_H
#define ALF_CMACRODEFTUPLE_H

#include "CGenericNode.h"
#include "AlfNodeVisitor.h"

namespace alf
{
class CString;
class CMacroFormalArgList;

/**
 * Represents a macro definition in the ALF grammar:
 * DEF -> { def { DEF_ID FORMAL_ARG∗ } DEFINABLE }
 */
class CMacroDefTuple : public CGenericNode
{
   friend class CAlfTreeExpandingHelper;
   
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_MACRO_DEF_TUPLE
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord         The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param def_id        The name/identifier.
    * @param arguments     The arguments that will replace the identifiers in the template structure.
    * @param definable     The template structure of the macro definition.
    */
   CMacroDefTuple(COORD coord, CString* def_id, CMacroFormalArgList* arguments, CGenericNode* definable);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CMacroDefTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   virtual CMacroDefTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitMacroDefTuple(*this);}

   /**
    * @return The macro definition's id.
    */
   std::string GetId() const;

   /**
    * @return The arguments that will replace the identifiers in the template structure.
    */
   const CMacroFormalArgList* GetArgumentIdentifiers() const;

   /**
   * @return The template structure of the macro definition.
   */
   const CGenericNode* GetDefinable() const;

   /**
    * @return  The type code identifying a float val
    */
   virtual TYPE GetNodeType() const { return TYPE_MACRO_DEF_TUPLE; }

   /** 
    * Checks if the number has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_MACRO_DEF_TUPLE || CGenericNode::IsType(t); }


protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CMacroDefTuple(const CMacroDefTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CMacroDefTuple& operator=(const CMacroDefTuple&);


   CString* def_id;
   CMacroFormalArgList* arguments;
   CGenericNode* definable;
};

}

#endif
