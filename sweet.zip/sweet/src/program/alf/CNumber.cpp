// $Id $
#include "CNumber.h"
#include "CSize.h"
#include "CIntNumValTuple.h"
#include "CString.h"
#include "CMacroCallTuple.h"
#include "CMacroFormalArg.h"
#include <sstream>

using namespace std;
using namespace alf;


CNumber::
CNumber(CString* p_number)
:  origin_number_string(p_number),
   is_negative(false)
{
  is_negative = p_number->Get()[0] == '-';
}

CNumber::
~CNumber()
{
   delete origin_number_string;
}

bool
CNumber::
IsNegative() const
{
   return is_negative;
}

CString*
CNumber::
GetValueAsString() const
{
   return origin_number_string;
}

void
CNumber::
Print(ostream& stream, int indent) const
{
   CString* str = GetValueAsString();
   if (str->HasMacroCall())
      str->GetMacroCall()->Print(stream, indent);
   else if (str->HasMacroFormalArg())
      str->GetMacroFormalArg()->Print(stream, indent);
   else  
   {
      if (IsNegative())
      {
         string signed_val = str->GetSourceRep();
         stream << "{ minus " << (signed_val.c_str() + 1) << " }";
      }
      else
         stream << str->GetSourceRep();
   }
}

////////////////////////////////////////////////

CFloatNumber::
CFloatNumber(CString* number)
:  CNumber(number)
{
   istringstream iss(number->Get());
   iss >> float_number_value;
}

CFloatNumber::
~CFloatNumber()
{
}

CFloatNumber*
CFloatNumber::
Copy() const
{
   return new CFloatNumber(*this);
}

long double
CFloatNumber::
GetValueAsFloat() const
{
   return float_number_value;
}

CFloatNumber::
CFloatNumber(const CFloatNumber& obj)
:  CNumber(obj.origin_number_string->Copy()),
   float_number_value(obj.float_number_value)
{
}

CFloatNumber&
CFloatNumber::
operator=(const CFloatNumber&)
{
   return *this;
}

CIntegerNumber::
CIntegerNumber(CString* number, CIntNumValTuple::INT_TYPE p_type)
:  CNumber(number)
{
   int base;
   switch (p_type) 
   {
   case CIntNumValTuple::HEX:
     base = 16;
     break;
   case CIntNumValTuple::DEC_SIGNED:
     base = 10;
     break;
   case CIntNumValTuple::DEC_UNSIGNED:
     base = 10;
     break;
   default: // CIntNumValTuple::BIN
     base = 2;
     break;
   }
   big_value = mpz_class(number->Get(), base);
   if (big_value.fits_sint_p())
   {
      fits_in_int = true;
      small_value = (int)big_value.get_si(); // gmp might return a long long, but it fits in a signed int
   }
   else
   {
      fits_in_int = false;
      small_value = 0xDEADF00D;
   }
}


CIntegerNumber::
~CIntegerNumber()
{

}

CIntegerNumber*
CIntegerNumber::
Copy() const
{
  return new CIntegerNumber(*this);
}

CIntegerNumber::
CIntegerNumber(const CIntegerNumber& obj)
   :  CNumber(obj.origin_number_string->Copy()),
      big_value(obj.big_value), fits_in_int(obj.fits_in_int),
      small_value(obj.small_value)
{

}

CIntegerNumber&
CIntegerNumber::
operator=(const CIntegerNumber&)
{
   return *this;
}

bool
CIntegerNumber::
IsEqual(CIntegerNumber * other_int)
{
  if(other_int == this)
    return true;
  else
    return GetValueAsBignum() == other_int->GetValueAsBignum();
}
