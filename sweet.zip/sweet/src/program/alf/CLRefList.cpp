// $Id $

#include "CLRefList.h"
#include "CLRefTuple.h"
#include "CListNode.inl"
#include <set>

using namespace std;

namespace alf
{

CLRefList::
CLRefList(const COORD& coord,
          const vector<CLRefTuple*>& p_list)
:  CGenericNode(coord),
   CListNode<CLRefTuple>(coord, "lrefs", p_list)
{
}

CLRefList::
~CLRefList()
{
}

CLRefList*
CLRefList::
Copy() const
{
   return new CLRefList(*this);
}

void
CLRefList::
LinkWithFilter(CLRefList &other, const CLRefList &filter, std::string (*Unmangle)(std::string))
{
   Link(other);

   std::set<string> existing_identifiers;
   for (vector<CLRefTuple*>::const_iterator fit=filter.list.begin(); fit!=filter.list.end(); ++fit)
      existing_identifiers.insert(Unmangle((*fit)->Name()));

   for (vector<CLRefTuple*>::iterator it=list.begin(); it!=list.end();) {
      CLRefTuple *lref_tuple = *it;
      bool match = existing_identifiers.find(Unmangle(lref_tuple->Name())) != existing_identifiers.end();
      if (match) {
         delete lref_tuple;
         it = list.erase(it);
      } else {
         ++it;
      }
   }
}

void CLRefList::RemoveNamedLRefs(const std::set<std::string>& names)
{
	if (names.size() == 0)
		return;
   for (vector<CLRefTuple*>::iterator it=list.begin(); it!=list.end();) {
      CLRefTuple *lref_tuple = *it;
      bool match = names.find(lref_tuple->Name()) != names.end();
      if (match) {
         delete lref_tuple;
         it = list.erase(it);
      } else {
         ++it;
      }
   }
}

CGenericNode*
CLRefList::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   const std::vector<CLRefTuple*> expandedList = ExpandList(helper);
   return new CLRefList(GetCoord(), expandedList);
}

template class CListNode<CLRefTuple>;

}
