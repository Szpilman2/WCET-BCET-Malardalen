/* $Id: ANumVal.cpp 950 2009-09-01 10:52:28Z jjn08 $ */

#include "ANumVal.h"
#include "CSize.h"

using namespace alf;

ANumVal::
ANumVal(COORD coord, CSize *size)
:  CGenericNode(coord),
   AExpr(coord, size),
   AConst(coord)
{
}

ANumVal::
~ANumVal(void)
{
}

ANumVal::
ANumVal(const ANumVal& obj)
:  CGenericNode(obj.coord),
   AExpr(obj.coord, (CSize*)obj.size->Copy()),
   AConst(obj.coord)
{
}

ANumVal&
ANumVal::
operator=(const ANumVal& obj)
{
   return *this;
}

