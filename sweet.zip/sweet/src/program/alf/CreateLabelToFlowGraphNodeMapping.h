// $Id $

#ifndef CREATE_LABEL_TO_FLOW_GRAPH_NODE_MAPPING_H_
#define CREATE_LABEL_TO_FLOW_GRAPH_NODE_MAPPING_H_

#include <vector>
#include <memory>

class CFlowGraph;
class CSymTabBase;
class CFlowGraphNode;
template <typename T> class CSymTab;

namespace alf {

   class CLabelTuple;

   /** Creates a symbol table where labels are annotated with the corresponding flow graph node.
      The effect is that the resulting symbol table can be used as a mapping \<label, flow-graph-node>
      where the label is represented with its lref's key.\n
      E.g. node = annotated_symtab->GetAnnot(label->GetLRef()->GetKey());\n
      Complexity: O(nr-of-flow-graph-nodes)\n
      Complexity of lookup: O(1)
   */
   std::unique_ptr<CSymTab<const CFlowGraphNode*> > CreateLabelToFlowGraphNodeMapping(const CSymTabBase *symtab_base,
         const std::vector<CFlowGraph*> & flow_graphs);

   /** Creates a symbol table where labels are annotated with the corresponding flow graph node.
      Also, function labels are annoated with the root of the flow graph of the corresponding
      function.
      The effect is that the resulting symbol table can be used as a mapping \<label, flow-graph-node>
      where the label is represented with its lref's key.\n
      E.g. node = annotated_symtab->GetAnnot(label->GetLRef()->GetKey());\n
      Complexity: O(nr-of-flow-graph-nodes)\n
      Complexity of lookup: O(1)
   */
   std::unique_ptr<CSymTab<const CFlowGraphNode*> > CreateLabelToFlowGraphNodeMapping(const CSymTabBase *symtab_base,
      std::vector<std::pair<CFlowGraph *, const CLabelTuple *> > & fgs_and_fls);
}
#endif
