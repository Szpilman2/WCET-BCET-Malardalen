// $Id $

#ifndef ALF_SWITCHSTMTTUPLE_H
#define ALF_SWITCHSTMTTUPLE_H

#include "AStmt.h"
#include "AlfNodeVisitor.h"
#include <vector>

namespace alf
{
class CLabelTuple;
class AExpr;
class ATarget;
class CTargetList;

/**
 * A node representing a switch statement.
 * It corresponds to the following rule in the ALF-grammar:
 * STMT -> { switch NUM_EXPR TARGET+ } 
 *
 *
 * In general you will use this rule in the following way:
 * {switch NUM_EXPR 
 *    {target INT_NUM_VAL[0] LABEL_EXPR[0] }
 *    ...
 *    {target INT_NUM_VAL[n-1] LABEL_EXPR[n-1] } 
 * } 
 * NUM_EXPR is evaluated, and then compared to each constant INT_NUM_VAL[i] in order. 
 *' If the computed value is equal to the j:th constant INT_NUM_VAL[j], then execution 
 * continues at the label given by evaluating the label expression LABEL_EXPR[j] . If 
 * no constant matches, then execution falls through: however, a switch may have an 
 * optional default case that then unconditionally causes a jump to the result of 
 * evaluating a LABEL_EXPR. A switch with one LABEL EXPR is basically a conditional 
 * branch.
 *
 *
 */
class CSwitchStmtTuple : public AStmt
{
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_JUMP_STMT_TUPLE.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param num_expr   Expression that should be evaluated and tested against each 'target's numeric expressions.
    * @param targets    Possible targets that it is possible to jump to.
    * @param stmt_label An optional label that is attached to the statement.
    */
   CSwitchStmtTuple(COORD coord, AExpr* num_expr, CTargetList* targets, CLabelTuple* stmt_label=NULL);
   
   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CSwitchStmtTuple();
   
   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to 
    *          deallocate the memory.
    */
   virtual CSwitchStmtTuple* Copy() const;
   
   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitSwitchStmtTuple(*this);}

   /**
    * @return The possible targets that it is possible to jump to.
    */
   const CTargetList* GetTargets() const;
   
   /**
    * @return The expression that should be evaluated and tested against each 'target's numeric expressions
    *         inorder to know which target to select.
    */
   const AExpr *GetNumExpr() const;

   /** @return Pointer to a constant string giving the name of the statement
               type, e.g., "store" or "switch" */
   virtual const char * StatementTypeName() const {return "switch";}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual CGenericNode::TYPE GetNodeType() const { return CGenericNode::TYPE_SWITCH_STMT_TUPLE; } 

   /** 
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(CGenericNode::TYPE t) const {return t == CGenericNode::TYPE_SWITCH_STMT_TUPLE || AStmt::IsType(t); }

   CSwitchStmtTuple* Duplicate() { return Copy(); }
   void Uses(CAliasGraph *alias_graph, std::set<int> *uses) { }
   void Updates(CAliasGraph *alias_graph, std::set<int> *updated_vars) { }
   void Variables(CAliasGraph *alias_graph, std::set<int> *vars) { }
   void AsText(CTextBlock *text_block, int indentation) const { }
   void PrintAsDot(std::ostream &o) const { OnPrint(o, 0); }

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CSwitchStmtTuple(const CSwitchStmtTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CSwitchStmtTuple& operator=(const CSwitchStmtTuple&);

   /**
    * Possible targets.
    */
   CTargetList* targets;
   
   /**
    * The value to use when selecting a target.
    */
   AExpr *num_expr;

};

}

#endif

