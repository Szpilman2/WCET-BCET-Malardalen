/* $Id: CConstRepeatTuple.cpp 950 2009-09-01 10:52:28Z jjn08 $ */

#include "CConstRepeatTuple.h"
#include "AConst.h"
#include "CString.h"

using namespace std;

namespace alf
{

CConstRepeatTuple::
CConstRepeatTuple(COORD coord, AConst* p_const_node, CString* p_repeats)
:  CGenericNode(coord),
   AVal(coord),
   repeats(p_repeats),
   const_node(p_const_node)
{
   SetParent(const_node);
   SetParent(repeats);
}

CConstRepeatTuple::
~CConstRepeatTuple()
{
   delete const_node;
   delete repeats;
}

CConstRepeatTuple::
CConstRepeatTuple(const CConstRepeatTuple& obj)
:  CGenericNode(obj.coord),
   AVal(obj.coord),
   repeats(obj.repeats->Copy()),
   const_node(dynamic_cast<AConst*>(obj.const_node->Copy()))
{
   SetParent(const_node);
   SetParent(repeats);
}

CConstRepeatTuple*
CConstRepeatTuple::
Copy() const
{
   return new CConstRepeatTuple(*this);
}

CConstRepeatTuple&
CConstRepeatTuple::
operator=(const CConstRepeatTuple& obj)
{
   return *this;
}

void
CConstRepeatTuple::
OnPrint(ostream& stream, int indent) const
{
   PrintIndent(stream, indent);
   stream << "{ const_repeat ";
   const_node->Print(stream);
   stream << " ";
   repeats->Print(stream);
   stream << " }";
}

const 
AConst*
CConstRepeatTuple::
GetConst() const
{
   return const_node;
}

unsigned
CConstRepeatTuple::
GetRepeats() const
{
   return repeats->Convert<unsigned>();
}
   
CGenericNode* 
CConstRepeatTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CConstRepeatTuple(GetCoord(),
                                dynamic_cast<AConst*> (const_node->Expand(helper)),
                                dynamic_cast<CString*> (repeats->Expand(helper)));
}   

}
