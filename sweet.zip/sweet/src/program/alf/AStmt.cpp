/* $Id: AStmt.cpp 7883 2018-03-15 14:46:53Z lkg02 $ */

#include "AStmt.h"
#include "CString.h"
#include "CSize.h"
#include "CLabelTuple.h"
#include "CLRefTuple.h"
#include "tools/CSourceLoader.h"

using namespace alf;
using namespace std;

AStmt::
AStmt(COORD p_coord, CGenericStmt::GS_TYPE stmt_type, CLabelTuple *p_label)
:  CGenericStmt(stmt_type), CGenericNode(p_coord),
   label(p_label),
   has_internal_generated_label(false)
{
}

AStmt::
AStmt(COORD p_coord, CGenericStmt::GS_TYPE stmt_type, CMacroFormalArg* p_macro_formal_arg, CLabelTuple* p_label)
:  CGenericStmt(stmt_type), 
   CGenericNode(p_coord, p_macro_formal_arg),
   label(p_label),
   has_internal_generated_label(false)
{
}

AStmt::
AStmt(COORD p_coord, CGenericStmt::GS_TYPE stmt_type, CMacroCallTuple* p_macro_call, CLabelTuple* p_label)
:  CGenericStmt(stmt_type), 
   CGenericNode(p_coord, p_macro_call),
   label(p_label),
   has_internal_generated_label(false)
{
}

AStmt::
~AStmt()
{
   if (label)
      delete label;
}

/*AStmt::AStmt(const AStmt& obj)
: CGenericNode(obj.coord, obj.type)
{
   label = obj.label->Copy();
}
*/
AStmt&
AStmt::
operator=(const AStmt& obj)
{
   return *this;
}

unsigned 
AStmt::
Key() const
{
  assert(GetLabel()->GetLRef()->HasKey());
  return GetLabel()->GetLRef()->GetKey();
}

CLabelTuple *
AStmt::
GetLabel() const
{
   return label;
}

inline std::string 
AStmt::
Name() const { 
  if (label)
    return label->GetLRef()->Name();
  else 
    return "";
}

std::string 
AStmt::
PrettifiedName() const { 
  if (label)
    return label->GetLRef()->PrettifiedName();
  else
    return "";
} 

const CAlfLabelSource *AStmt::GetSourceInfo() const {
   if (label && source_loader)
      return source_loader->GetSourceOfLabel( label->GetLRef()->Name() );
   return 0;
}

std::string AStmt::TryGetSourceString(const char delim[]) const {
   if (const CAlfLabelSource *srcinfo = GetSourceInfo()) {
      if (delim) return srcinfo->ToString(delim);
      else       return srcinfo->ToString();
   }
   return Name();
}

CLabelTuple*
AStmt::
ExpandLabel(CAlfTreeExpandingHelper* helper) const
{
   return dynamic_cast<CLabelTuple*>(label->Expand(helper));
}

void
AStmt::
GenerateLabel()
{
   static unsigned new_number;
   std::ostringstream s;
   s << "gen_label_" << new_number++;
   CSize *size_num_val = new CSize(coord, new CString(coord, "64"));
   CSize *size_lref = new CSize(coord, new CString(coord, "64"));
   CSize *size_label = new CSize(coord, new CString(coord, "64"));
   CString *the_label = new CString(coord, s.str());
   CLRefTuple* lref = new CLRefTuple(coord, size_lref, the_label);
   CString *int_value = new CString(coord, "0");
   CIntNumValTuple* offset = new CIntNumValTuple(coord, CIntNumValTuple::DEC_UNSIGNED, size_num_val, int_value);
   label = new CLabelTuple(coord, size_label, lref, offset);
   SetParent(label);
   has_internal_generated_label = true;
}

const CSourceLoader *AStmt::source_loader = 0;
