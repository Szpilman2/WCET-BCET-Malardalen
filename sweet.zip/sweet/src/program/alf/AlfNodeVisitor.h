#ifndef ALFNODEVISITOR_H_INCLUDED
#define ALFNODEVISITOR_H_INCLUDED

namespace alf
{

class CGenericNode;
class CAddrTuple;
class CAlfTuple;
class CAllocTuple;
class CArgDeclList;
class CCallStmtTuple;
class CCharStringTuple;
class CCompAddrTuple;
class CCompLabelTuple;
class CConstList;
class CConstRepeatTuple;
class CDeclList;
class CDefaultTuple;
class CDynAllocTuple;
class CExportsTuple;
class CExprList;
class CFRefList;
class CFRefTuple;
class CFloatListTuple;
class CFloatValTuple;
class CFreeStmtTuple;
class CFuncList;
class CFuncTuple;
class CGenericList;
class CImportsTuple;
class CInitList;
class CInitTuple;
class CIntListTuple;
class CIntNumValTuple;
class CJumpStmtTuple;
class CLRefList;
class CLRefTuple;
class CLabelTuple;
class CLauTuple;
class CLoadExprTuple;
class CMacroCallTuple;
class CMacroDefList;
class CMacroDefTuple;
class CMacroFormalArg;
class CMacroFormalArgList;
class CNullStmtTuple;
class COpNumExprTuple;
class CRefTuple;
class CReturnStmtTuple;
class CScopeTuple;
class CSize;
class CSizeList;
class CStmtList;
class CStoreStmtTuple;
class CString;
class CSwitchStmtTuple;
class CTargetList;
class CTargetTuple;
class CUndefinedExprTuple;
class CUnknownConst;
class CUnknownExpr;
class CUnknownStmt;
class CUnknownVal;

/** Implements the visitor pattern. The default implementations of all functions
    just call the function Default, which is the only function required to be
    implemented by a subclass. To visit a node n with visitor v, call
    n.AcceptVisitor(v). (Note that each node in the ALF tree has an 
    AcceptVisitor(AlfNodeVisitor *) method).*/
class AlfNodeVisitor
{
public:
   virtual void VisitAddrTuple(const CAddrTuple & node);
   virtual void VisitAlfTuple(const CAlfTuple & node);
   virtual void VisitAllocTuple(const CAllocTuple & node);
   virtual void VisitArgDeclList(const CArgDeclList & node);
   virtual void VisitCallStmtTuple(const CCallStmtTuple & node);
   virtual void VisitCharStringTuple(const CCharStringTuple & node);
   virtual void VisitCompAddrTuple(const CCompAddrTuple & node);
   virtual void VisitCompLabelTuple(const CCompLabelTuple & node);
   virtual void VisitConstList(const CConstList & node);
   virtual void VisitConstRepeatTuple(const CConstRepeatTuple & node);
   virtual void VisitDeclList(const CDeclList & node);
   virtual void VisitDefaultTuple(const CDefaultTuple & node);
   virtual void VisitDynAllocTuple(const CDynAllocTuple & node);
   virtual void VisitExportsTuple(const CExportsTuple & node);
   virtual void VisitExprList(const CExprList & node);
   virtual void VisitFRefList(const CFRefList & node);
   virtual void VisitFRefTuple(const CFRefTuple & node);
   virtual void VisitFloatListTuple(const CFloatListTuple & node);
   virtual void VisitFloatValTuple(const CFloatValTuple & node);
   virtual void VisitFreeStmtTuple(const CFreeStmtTuple & node);
   virtual void VisitFuncList(const CFuncList & node);
   virtual void VisitFuncTuple(const CFuncTuple & node);
   virtual void VisitGenericList(const CGenericList & node);
   virtual void VisitImportsTuple(const CImportsTuple & node);
   virtual void VisitInitList(const CInitList & node);
   virtual void VisitInitTuple(const CInitTuple & node);
   virtual void VisitIntListTuple(const CIntListTuple & node);
   virtual void VisitIntNumValTuple(const CIntNumValTuple & node);
   virtual void VisitJumpStmtTuple(const CJumpStmtTuple & node);
   virtual void VisitLRefList(const CLRefList & node);
   virtual void VisitLRefTuple(const CLRefTuple & node);
   virtual void VisitLabelTuple(const CLabelTuple & node);
   virtual void VisitLauTuple(const CLauTuple & node);
   virtual void VisitLoadExprTuple(const CLoadExprTuple & node);
   virtual void VisitMacroCallTuple(const CMacroCallTuple & node);
   virtual void VisitMacroDefList(const CMacroDefList & node);
   virtual void VisitMacroDefTuple(const CMacroDefTuple & node);
   virtual void VisitMacroFormalArg(const CMacroFormalArg & node);
   virtual void VisitMacroFormalArgList(const CMacroFormalArgList & node);
   virtual void VisitNullStmtTuple(const CNullStmtTuple & node);
   virtual void VisitOpNumExprTuple(const COpNumExprTuple & node);
   virtual void VisitRefTuple(const CRefTuple & node);
   virtual void VisitReturnStmtTuple(const CReturnStmtTuple & node);
   virtual void VisitScopeTuple(const CScopeTuple & node);
   virtual void VisitSize(const CSize & node);
   virtual void VisitSizeList(const CSizeList & node);
   virtual void VisitStmtList(const CStmtList & node);
   virtual void VisitStoreStmtTuple(const CStoreStmtTuple & node);
   virtual void VisitString(const CString & node);
   virtual void VisitSwitchStmtTuple(const CSwitchStmtTuple & node);
   virtual void VisitTargetList(const CTargetList & node);
   virtual void VisitTargetTuple(const CTargetTuple & node);
   virtual void VisitUndefinedExprTuple(const CUndefinedExprTuple & node);
   virtual void VisitUnknownConst(const CUnknownConst & node);
   virtual void VisitUnknownExpr(const CUnknownExpr & node);
   virtual void VisitUnknownStmt(const CUnknownStmt & node);
   virtual void VisitUnknownVal(const CUnknownVal & node);

private:
   /** The only function required by a subclass to implement */
   virtual void Default(const CGenericNode & node) = 0;
};

}

#endif   // #ifndef ALFNODEVISITOR_H_INCLUDED
