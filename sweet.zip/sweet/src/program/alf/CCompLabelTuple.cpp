/* $Id: CCompLabelTuple.cpp 5947 2013-12-03 20:44:28Z lkg02 $ */

#include "CCompLabelTuple.h"
#include "CSize.h"
#include <typeinfo>

using namespace alf;
using namespace std;

CCompLabelTuple::
CCompLabelTuple(COORD coord, CSize* size, AExpr* lref, AExpr* num)
:  CGenericNode(coord),
   AExpr(coord, size),
   lref_expr(lref),
   num_expr(num)
{
   SetParent(lref_expr);
   SetParent(num_expr);
}

CCompLabelTuple::
~CCompLabelTuple()
{
   delete lref_expr;
   delete num_expr;
}

CCompLabelTuple::CCompLabelTuple(const CCompLabelTuple& obj)
:  CGenericNode(obj.coord),
   AExpr(obj.coord, (CSize*)obj.size->Copy()),
   lref_expr(dynamic_cast<AExpr*>(obj.lref_expr->Copy())),
   num_expr(dynamic_cast<AExpr*>(obj.num_expr->Copy()))
{
   SetParent(lref_expr);
   SetParent(num_expr);
}

CCompLabelTuple*
CCompLabelTuple::
Copy() const
{
   return new CCompLabelTuple(*this);
}

CCompLabelTuple&
CCompLabelTuple::
operator=(const CCompLabelTuple& obj)
{
   return *this;
}

void
CCompLabelTuple::
OnPrint(ostream& stream, int indent) const
{
   stream << Indent(indent) << "{ label ";
   size->PrintWithEndl(stream, 0);
   ++indent;
   lref_expr->PrintWithEndl(stream, indent);
   num_expr->PrintWithEndl(stream, indent);
   --indent;
   stream << Indent(indent) << "}";
}

const AExpr *
CCompLabelTuple::
GetLRefExpr() const 
{
   return lref_expr;
}

const AExpr *
CCompLabelTuple::
GetNumExpr() const
{
   return num_expr;
}

CGenericNode* 
CCompLabelTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CCompLabelTuple(GetCoord(),
                        dynamic_cast<CSize*> (GetSize()->Expand(helper)),
                        dynamic_cast<AExpr*> (lref_expr->Expand(helper)),
                        dynamic_cast<AExpr*> (num_expr->Expand(helper)));
}

