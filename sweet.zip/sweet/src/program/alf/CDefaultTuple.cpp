/* $Id: CDefaultTuple.cpp 5947 2013-12-03 20:44:28Z lkg02 $ */

#include "CDefaultTuple.h"
#include "AExpr.h"

using namespace std;
using namespace alf;

CDefaultTuple::
CDefaultTuple(COORD coord, AExpr *p_label_expr)
: ATarget(coord, p_label_expr)
{
}

CDefaultTuple::
~CDefaultTuple()
{
}

CDefaultTuple::CDefaultTuple(const CDefaultTuple& obj)
: ATarget(obj.coord, dynamic_cast<AExpr*>(obj.label_expr->Copy()))
{
}

CDefaultTuple*
CDefaultTuple::
Copy() const
{
   return new CDefaultTuple(*this);
}

CDefaultTuple&
CDefaultTuple::
operator=(const CDefaultTuple& obj)
{
   return *this;
}

void
CDefaultTuple::
OnPrint(ostream& stream, int indent) const
{
   PrintIndent(stream, indent);
   stream << "{ default" << endl;
   label_expr->PrintWithEndl(stream, indent+1);
   PrintIndent(stream, indent);
   stream << "}";
}

CGenericNode* 
CDefaultTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CDefaultTuple(GetCoord(), dynamic_cast<AExpr*> (label_expr->Expand(helper)));
}

