// $Id $

#ifndef ALF_NULLSTMTTUPLE_H
#define ALF_NULLSTMTTUPLE_H

#include "AStmt.h"
#include "AlfNodeVisitor.h"

namespace alf
{
class CLabelTuple;
/**
 * A node representing an empty statement in the ALF-program.
 * It corresponds to the following rule in the ALF-grammar:
 * STMT -> { null }
 */
class CNullStmtTuple : public AStmt
{
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_NULL_STMT_TUPLE.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord      The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param stmt_label An optional label that is attached to the statement.
    */
   CNullStmtTuple(COORD coord, CLabelTuple* stmt_label=NULL);
   
   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CNullStmtTuple();
   
   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to 
    *          deallocate the memory.
    */
   virtual CNullStmtTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitNullStmtTuple(*this);}

   /** 
    * @return Pointer to a constant string giving the name of the statement
    *         type, e.g., "store" or "switch"
    */
   virtual const char * StatementTypeName() const {return "null";}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual CGenericNode::TYPE GetNodeType() const { return CGenericNode::TYPE_NULL_STMT_TUPLE;} 

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(CGenericNode::TYPE t) const {return t == CGenericNode::TYPE_NULL_STMT_TUPLE || AStmt::IsType(t); }

   /**
    * Set the "skip print" property of this null statement. The effect of
    * this property is that the print operation of this statement will be
    * ignored.
    */
   void SkipPrint() { skip_print = true; }

   CNullStmtTuple* Duplicate() { return Copy(); }
   void Uses(CAliasGraph *alias_graph, std::set<int> *uses) { }
   void Updates(CAliasGraph *alias_graph, std::set<int> *updated_vars) { }
   void Variables(CAliasGraph *alias_graph, std::set<int> *vars) { }
   void AsText(CTextBlock *text_block, int indentation) const { }
   void PrintAsDot(std::ostream &o) const { OnPrint(o, 0); }

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CNullStmtTuple(const CNullStmtTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CNullStmtTuple& operator=(const CNullStmtTuple&);

   bool skip_print;
};

}

#endif

