// $Id $

#ifndef ALF_CCONSTREPEATTUPLE_H
#define ALF_CCONSTREPEATTUPLE_H

#include "AVal.h"
#include "AlfNodeVisitor.h"

namespace alf
{
class AConst;
class CString;

 /**
 * Represents a constant that repeats a number of times which corresponds to the VAL rule in the ALF grammar:
 * VAL -> { const_repeat CONST REPEATS }
 *
 * @see AVal, AConst
 */
class CConstRepeatTuple : public AVal
{
public:
  /**
    * Constructor, creates a list node from a vector of frame references.
    * It sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_CONST_LIST.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord       The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param const_node  A vector of constants.
    * @param repeats     A std::string representing a number.
    */
   CConstRepeatTuple(COORD coord, AConst* const_node, CString* repeats);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CConstRepeatTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   virtual CConstRepeatTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitConstRepeatTuple(*this);}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_CONSTREPEAT_TUPLE; }

   /** 
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_CONSTREPEAT_TUPLE || AVal::IsType(t); }

   const AConst* GetConst() const;
   unsigned GetRepeats() const;

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CConstRepeatTuple(const CConstRepeatTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CConstRepeatTuple& operator=(const CConstRepeatTuple&);

   CString* repeats;
   AConst* const_node;
};

}

#endif

