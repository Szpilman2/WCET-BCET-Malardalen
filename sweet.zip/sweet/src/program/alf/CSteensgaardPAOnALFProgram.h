// $Id $

#ifndef CSTEENSGAARD_PA_ON_ALF_PROGRAM_H_
#define CSTEENSGAARD_PA_ON_ALF_PROGRAM_H_

#include "ptranal/CSteensgaardAnalysisBuilder.h"

namespace alf {

class CFuncList;
class CInitList;
class CScopeTuple;
class AStmt;
class CStoreStmtTuple;
class CCallStmtTuple;
class CReturnStmtTuple;
class AExpr;
class AVal;
class CAddrTuple;
class CLRefTuple;
class AConst;

/** \class CSteensgaardPAOnALFProgram
 *  A helper class to the Steensgard pointer analysis. This class deals with all the
 *  details that is specific for an ALF program representation. Essentially this is where
 *  to find assignment statements, and the details of such statements.
 */
class CSteensgaardPAOnALFProgram : public CSteensgaardAnalysisBuilder
{
public:
   CSteensgaardPAOnALFProgram();
   ~CSteensgaardPAOnALFProgram();

   /** Add all identifiters in the alf ast to vars and all functions to lambda_funcs and
      set key_size to a unique global key that is higher than any already used key.
      \param ast A pointer to an alf abstract syntax tree.
      \param symtab A pointer to a symbol table. This contains all symbols used in the program.
      \param vars A reference to a set of identifiers. The keys of all variables
         found in symtab will be inserted into vars.
      \param labels A reference to a set of identifiers. The keys of all stmt labels 
         found in symtab, except func labels, will be inserted into vars.
      \param lambda_funcs A reference to a lambda_t map. This will be updated with mappings
         for all functions found in \a ast to pairs of \< formal-set, retval-set\>
       \param temp_vars A reference to a set of temporary identifiers added due to arguments in 
         functions. 
      \param key_size A counter which keeps track of the next key to give created temp variables.
   */
   void GetVarsLabelsAndFuncs(const CGenericProgram *ast, const CSymTabBase *symtab, std::set<unsigned> &vars,
                              std::set<unsigned> &labels, lambda_t &lambda_funcs, std::set<unsigned> &temp_vars, 
                              unsigned &key_size);

   /** Traverses an ast to find all assignments in the program. \a spa will be called
      with the appropriate function for each assignment found during the traversal.
      \param ast A pointer to an alf abstract syntax tree.
      \param spa A pointer to a steensgaard algorithm object that is alreday initialized so
         that it knows abaout all functions and variables in the ast.
      \param lambda_funcs undocumented
   */
   void TraverseCode(const CGenericProgram *ast, CSteensgaardPA *spa, lambda_t &lambda_funcs);

private:
   // Code to create lambda expression from ALF function
   // declarations. Will also update internal map between functions
   // keys and their input and output keys. Will also add new temp vars
   // to the vars set.
   void CreateLambdaExprsFromALFFuncs(const alf::CFuncList * funcs,
                  unsigned &next_global_key, lambda_t &lambda_funcs, std::set<unsigned> &vars);

   // Update PA according to either global ALF static initializations
   // or to local ALF dynamic initializations
   void UpdatePAWithALFGlobalInits(const alf::CInitList * init_list, CSteensgaardPA *spa);
   void UpdatePAWithALFInits(const alf::CInitList * init_list, CSteensgaardPA *spa);

   // Update PA will different ALF statements
   void UpdatePAWithALFScope(const alf::CScopeTuple* scope, lambda_t &lambda_funcs, CSteensgaardPA *spa);
   void UpdatePAWithALFStmt(const alf::AStmt * stmt, lambda_t &lambda_funcs, CSteensgaardPA *spa);
   void UpdatePAWithALFStoreStmt(const alf::CStoreStmtTuple * store_stmt, CSteensgaardPA *spa);
   void UpdatePAWithALFCallStmt(const alf::CCallStmtTuple * call_stmt, CSteensgaardPA *spa);
   void UpdatePAWithALFReturnStmt(const alf::CReturnStmtTuple * return_stmt, lambda_t &lambda_funcs, CSteensgaardPA *spa);

   // Update PA according to ALF expr. The dest argument is the var
   // that the expression should be bound to.
   void UpdatePAWithALFExpr(unsigned dest, const alf::AExpr * c, CSteensgaardPA *spa);

   // Update the PA with the constant part of an expression. The dest
   // argument is the var that the constant should be bound to.
   void UpdatePAWithALFAssignOfVar(unsigned dest, const alf::AVal *value_to_store, CSteensgaardPA *spa);
   void UpdatePAWithAssignOfAddr(unsigned gkey_of_fref_written_to, const alf::CAddrTuple * addr_to_store, CSteensgaardPA *spa);
   void UpdatePAWithAssignOfLRef(unsigned gkey_of_fref_written_to, const alf::CLRefTuple * lref_to_store, CSteensgaardPA *spa);
   void UpdatePAWithALFAssignOfConst(unsigned gkey_of_fref_written_to, const alf::AConst *const_to_store, CSteensgaardPA *spa);
};
}
#endif
