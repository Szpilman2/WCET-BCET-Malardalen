// $Id $

#include "CFreeStmtTuple.h"
#include "AExpr.h"
#include "CLabelTuple.h"

using namespace alf;
using namespace std;

CFreeStmtTuple::
CFreeStmtTuple(COORD coord, AExpr *p_fref_expr, CLabelTuple *lbl)
:  CGenericStmt(GS_FREE),
   AStmt(coord, CGenericStmt::GS_FREE, lbl),
   fref_expr(p_fref_expr)
{
   SetParent(fref_expr);
}

CFreeStmtTuple::
~CFreeStmtTuple()
{
   delete fref_expr;
}

CFreeStmtTuple::CFreeStmtTuple(const CFreeStmtTuple& obj)
:  CGenericStmt(GS_FREE),
   AStmt(obj.coord, obj.Type(), obj.GetLabel()->Copy()),
   fref_expr(dynamic_cast<AExpr*>(obj.fref_expr->Copy()))
{
   SetParent(fref_expr);
}

CFreeStmtTuple*
CFreeStmtTuple::
Copy() const
{
   return new CFreeStmtTuple(*this);
}

CFreeStmtTuple&
CFreeStmtTuple::
operator=(const CFreeStmtTuple& obj)
{
   return *this;
}

void
CFreeStmtTuple::
OnPrint(ostream& stream, int indent) const
{
   if (!HasInternalGeneratedLabel())
   {
      GetLabel()->Print(stream, indent);
      stream << endl;
   }

   PrintIndent(stream, indent);
   stream << "{ free " << fref_expr << " }";
}

const AExpr*
CFreeStmtTuple::
GetFrefExpr() const
{
   return fref_expr;
}

CGenericNode* 
CFreeStmtTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CFreeStmtTuple(GetCoord(),
                             dynamic_cast<AExpr*>(fref_expr->Expand(helper)),
                             ExpandLabel(helper));
}

