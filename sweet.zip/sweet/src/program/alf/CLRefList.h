// $Id $

#ifndef ALF_CLREFLIST_H
#define ALF_CLREFLIST_H

#include "CListNode.h"
#include "AlfNodeVisitor.h"

namespace alf
{
class CLRefTuple;

/**
 * A node containing a list of label references.
 * This class inherits from CListNode, and corresponds to the following rule in the ALF grammar:
 * LREFS -> { lrefs LREF*}
 *
 * @see CLRefTuple
 */
class CLRefList : public CListNode<CLRefTuple>
{
public:
   /**
    * Constructor, creates a list node from a vector of label references.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_LREF_LIST.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param list  A vector of label references
    */
   CLRefList(const COORD& coord, const std::vector<CLRefTuple*>& list=std::vector<CLRefTuple*>());
   
   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CLRefList();
   
   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to 
    *          deallocate the memory.
    */
   CLRefList* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitLRefList(*this);}

   /**
    * @return  The type code identifying a lref list
    */
   virtual TYPE GetNodeType() const { return TYPE_LREF_LIST; }

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_LREF_LIST || CListNode<CLRefTuple>::IsType(t); }

   /**
    * Moves the elements from another lref list to this filtering out matching lrefs in \a filter.
    * @param other The other lref list.
    * @param filter The lref list containing filer lref tuples
    * @param Unmangle Function to unmangle identifiers
    * @post The elements that was previously in other is now in this. Other is empty. An lref tulpe
    *    that is in @a filter is not in this lref list.
    */
   void LinkWithFilter(CLRefList &other, const CLRefList &filter, std::string (*Unmangle)(std::string));

   /**
    * Removes from this list any lrefs whose names are found in @a names
    */
   void RemoveNamedLRefs(const std::set<std::string>& names);

protected:
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
};

}

#endif

