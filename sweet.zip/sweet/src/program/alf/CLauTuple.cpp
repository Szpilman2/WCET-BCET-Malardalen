// $Id $


#include "CLauTuple.h"
#include "CSize.h"
#include "CAlfTreeExpandingHelper.h"

using namespace alf;
using namespace std;

CLauTuple::
CLauTuple(COORD coord, CSize* p_size)
:  CGenericNode(coord),
   size(p_size)
{
   SetParent(size);
}

CLauTuple::
~CLauTuple()
{
   delete size;
}

CLauTuple::
CLauTuple(const CLauTuple& obj)
:  CGenericNode(obj.coord),
   size(obj.size->Copy())
{
   SetParent(size);
}

CLauTuple*
CLauTuple::
Copy() const
{
   return new CLauTuple(*this);
}

bool CLauTuple::IsEqual(const CLauTuple* other) const
{
   return GetSize()->IsEqual(other->GetSize());
}

CLauTuple&
CLauTuple::
operator=(const CLauTuple& obj)
{
   return *this;
}

void
CLauTuple::
OnPrint(ostream& stream, int indent) const
{
   PrintIndent(stream, indent);
   stream << "{ least_addr_unit ";
   size->Print(stream, 0);
   stream << " }";
}

CSize*
CLauTuple::
GetSize() const
{
   return size;
}

CGenericNode* 
CLauTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CLauTuple(GetCoord(),
                        static_cast<CSize*>(size->Expand(helper)));
}

