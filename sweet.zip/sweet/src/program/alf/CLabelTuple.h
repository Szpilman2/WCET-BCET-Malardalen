// $Id $

#ifndef ALF_CLABELTUPLE_H
#define ALF_CLABELTUPLE_H

#include "AExpr.h"
#include "CLRefTuple.h"
#include "CIntNumValTuple.h"
#include "AConst.h"
#include "AlfNodeVisitor.h"

namespace alf
{
class CSize;

/**
 * A node representing a label that can be attached to a statement or function.
 * It corresponds to the following rule in the ALF grammar:
 * LABEL -> { label SIZE LREF OFFSET }
 *
 * @see CSize, CIntNumValTuple, AExpr, AConst
 */
class CLabelTuple : public AExpr, public AConst
{
public:
  /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_LABEL_TUPLE
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param size    The size of the label reference.
    * @param lref    A label reference representing the origin of the label.
    * @param offset  The offset from 'lref' that this label actually represents.
    */
  CLabelTuple(COORD coord, CSize* size, CLRefTuple* lref, CIntNumValTuple* offset);


  /**
   * Constructor, initializes the node as an macrocall.
   * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_LABEL_TUPLE
   * The class is responsible to deallocate all the arguments.
   *
   * @param coord            The line and column numbers the in the parsed file where the rule creating this node was found.
   * @param macro_call_tuple The macrocall node.
   */
  CLabelTuple(COORD coord, CMacroCallTuple* macro_call_tuple);

  /**
   * Constructor, initializes the node as an macro formal-argument-identifier string.
   * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_LABEL_TUPLE
   * The class is responsible to deallocate all the arguments.
   *
   * @param coord             The line and column numbers the in the parsed file where the rule creating this node was found.
   * @param macro_formal_arg  The macro formal-argument-identifier.
   */
  CLabelTuple(COORD coord, CMacroFormalArg* macro_formal_arg);

  /**
    * Deallocates all the memory that the node is using.
    */
  virtual ~CLabelTuple();

  /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
  virtual CLabelTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitLabelTuple(*this);}

  /**
   * @return The label reference representing the origin of the label.
   */
  CLRefTuple* GetLRef() const;

  /**
   * @return The offset from the origin (so you can determine the actual labelrepresents).
   */
  CIntNumValTuple* GetOffset() const;

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_LABEL_TUPLE; }

  /** 
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
  virtual bool IsType(TYPE t) const {return t == TYPE_LABEL_TUPLE || AExpr::IsType(t) || AConst::IsType(t);};

  /**
    * Determine if two labels are equal, that is if they have the same
    * lref and the same offset. We should NOT use operator== since it
    * is reserved for pointer comparison.  
    * @return true or false.
    */
  bool IsEqual(const CLabelTuple*) const;

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
  /**
   * Copy constructor, performs a deep copy of the incoming node.
   */
  CLabelTuple(const CLabelTuple&);

  /**
   * Assignment operator which is overloaded so no mistakes is made.
   * @return  A reference to this node.
   */
  CLabelTuple& operator=(const CLabelTuple&);

  /**
   * The label origin.
   */
  CLRefTuple *lref;

  /**
   *  The offset from the origin.
   */
  CIntNumValTuple *offset;

public:
struct Comparer
{
  bool operator()(const CLabelTuple* t1, const CLabelTuple* t2) const
  {
    return t1->IsEqual(t2);
  }
};
};

}

#endif

