// $Id $

#ifndef ALF_CSCOPETUPLE_H
#define ALF_CSCOPETUPLE_H

#include "CGenericNode.h"
#include "AStmt.h"
#include "AlfNodeVisitor.h"

namespace alf
{
class CInitList;
class CDeclList;
class CStmtList;
class CLabelTuple;

/**
 * A node representing a scope.
 * It corresponds to the following rule in the ALF-grammar:
 * GS_SCOPE -> { scope DECLS INITS STMTS }
 *
 * A scope is a block which can contain locally defined variables (frames), and code. ALF has static scoping. ALF offers the
 * possibility to initialize frames, which are dynamically allocated in a scope, through an init declaration: if a faithful modelling
 * of the program flow is required then this mechanism should be avoided, since in reality some code will have to execute in
 * order to initialize the data.
 *
 * @see CDeclList, CInintList, CStmtList, CLabelTuple, AStmt
 */
class CScopeTuple : public AStmt, public CGenericScopeStmt
{
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_SCOPE_TUPLE.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord      The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param decls      List of declarations of locally defined variables.
    * @param inits      List of initializations of the locally defined variables.
    * @param stmts      List of statements.
    * @param stmt_label An optional label that is attached to the statement.
    */
   CScopeTuple(COORD coord, CDeclList* decls, CInitList* inits, CStmtList* stmts, CLabelTuple* stmt_label=NULL);

   /**
    * Constructor, initializes the node as an macrocall.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_SCOPE_TUPLE
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord            The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param macro_call_tuple The macrocall node.
    */
   CScopeTuple(COORD coord, CMacroCallTuple* macro_call_tuple);

   /**
    * Constructor, initializes the node as an macro formal-argument-identifier string.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_SCOPE_TUPLE
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord               The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param macro_formal_arg    The macro formal-argument-identifier.
    */
   CScopeTuple(COORD coord, CMacroFormalArg* macro_formal_arg);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CScopeTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   virtual CScopeTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitScopeTuple(*this);}

   /**
    * @return The scope's list of declarations of locally defined variables.
    */
   CDeclList* GetDecls() const;

   /**
    * @return The scope's list of initializations of the locally defined variables.
    */
   CInitList* GetInits() const;

   /**
    * @return The scope's list of statements.
    */
   CStmtList* GetStmts() const;

   /**
    * @return Collect statements in currect scope only.
    */
   void GetStmtsInScope(std::vector<CGenericStmt*> *stmts) const;

   /**
    * @return Collect statements in currect scope and of a certain type only.
    */
   void GetStmtsInScope(std::vector<CGenericStmt*> *stmts, CGenericNode::TYPE stmt_type) const;

   /**
    * @return Collect statements in currect and subordinate scopes.
    */
   void GetStmtsInScopeAndSubordinateScopes(std::vector<CGenericStmt*> *stmts) const;

   /**
    * @return Collect statements in currect scope and subordinate scopes of a certain type only.
    */
   void GetStmtsInScopeAndSubordinateScopes(std::vector<CGenericStmt*> *stmts, CGenericNode::TYPE stmt_type) const;

   /** 
    * @return Pointer to a constant string giving the name of the statement
    *         type, e.g., "store" or "switch"
    */
   virtual const char * StatementTypeName() const {return "scope";}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual CGenericNode::TYPE GetNodeType() const { return CGenericNode::TYPE_SCOPE_TUPLE; } 

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(CGenericNode::TYPE t) const {return t == CGenericNode::TYPE_SCOPE_TUPLE || AStmt::IsType(t); }

   CScopeTuple* Duplicate() { return Copy(); }
   std::string Label() const { return ""; }
   void Uses(CAliasGraph *alias_graph, std::set<int> *uses) { }
   void Updates(CAliasGraph *alias_graph, std::set<int> *updated_vars) { }
   void Variables(CAliasGraph *alias_graph, std::set<int> *vars) { }
   void AsText(CTextBlock *text_block, int indentation) const { }
   void PrintAsDot(std::ostream& o) const { }

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CScopeTuple(const CScopeTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CScopeTuple& operator=(const CScopeTuple&);

   /**
    * Local variables declarations.
    */
   CDeclList* decls;

   /**
    * Initializations of local variables.
    */
   CInitList* inits;

   /**
    * Statements.
    */
   CStmtList* stmts;
};

}

#endif

