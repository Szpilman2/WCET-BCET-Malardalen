#include "CListNode.inl"
#include "CAllocTuple.h"

template class alf::CListNode<alf::CAllocTuple>;
