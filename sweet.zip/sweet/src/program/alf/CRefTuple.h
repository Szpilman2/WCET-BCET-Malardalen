// $Id $

#ifndef ALF_CREFTUPLE_H
#define ALF_CREFTUPLE_H

#include "CGenericNode.h"
#include "AlfNodeVisitor.h"
#include "symtab/CSymTabIdentifier.h"
#include "CString.h"

namespace alf
{
class CIntNumValTuple;
class CString;

/**
 * Represents a reference used by the INIT rule during initialization of data.
 * It corresponds to the following rule in the ALF-grammar:
 * REF -> { ref FREF_ID OFFSET }
 *
 * The initialization is made of data located from the address corresponding to the frameref named FREF_ID + offset and up.
 *
 * @see CIntNumValTuple, CGenericNode
 */
class CRefTuple : public CGenericNode, public CSymTabIdentifier
{
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_REF_TUPLE.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param id      A string equal to a frame reference's id somewhere in the ALF-program, the origin from where
                     the reference is calculated.
    * @param offset  A offset from the origin where the actual reference starts.
    */
   CRefTuple(COORD coord, CString* id, CIntNumValTuple* offset);

   /**
    * Constructor, initializes the node as an macrocall.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_REF_TUPLE
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord            The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param macro_call_tuple The macrocall node.
    */
   CRefTuple(COORD coord, CMacroCallTuple* macro_call_tuple);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CRefTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   virtual CRefTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitRefTuple(*this);}

   /**
    * @return The std::string equal to a frame reference's id somewhere in the ALF-program, the origin from where the reference is calculated.
    */
   const CString* GetFrefId() const;

   /**
    * @return The offset from the origin where the actual reference starts.
    */
   const CIntNumValTuple* GetOffset() const;

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual CGenericNode::TYPE GetNodeType() const { return CGenericNode::TYPE_REF_TUPLE; }

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(CGenericNode::TYPE t) const {return t == CGenericNode::TYPE_REF_TUPLE || CGenericNode::IsType(t); }

   std::string Name() const { return GetFrefId()->Get(); }
   std::string PrettifiedName() const { return GetFrefId()->Get(); }

   /**
    * Accept a visit from a SymTabIdentifierVisitor
    */
   virtual void AcceptVisitor(SymTabIdentifierVisitor * visitor) const {visitor->VisitRefTuple(*this);}

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CRefTuple(const CRefTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CRefTuple& operator=(const CRefTuple&);

   /**
    * The origin (frame reference name).
    */
   CString* id;

   /**
    * The offset from origin.
    */
   CIntNumValTuple *offset;
};

}

#endif


