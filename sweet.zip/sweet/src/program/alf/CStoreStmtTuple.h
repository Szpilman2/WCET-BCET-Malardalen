// $Id $

#ifndef ALF_STORESTMTTUPLE_H
#define ALF_STORESTMTTUPLE_H

#include "AStmt.h"
#include "AlfNodeVisitor.h"
#include <vector>

namespace alf
{
class CLabelTuple;
class AExpr;
class CExprList;

/**
 * A node that lets you store one or more values into the specified address(es).
 * It corresponds to the following rule in the ALF-grammar:
 * STMT -> { store ADDRESS_EXPR+ with EXPR+ }
 *
 * Concurrent assignment: evaluate the address expressions in ADDRESS EXPR+ into a[1], ... , a[N], in left-to-right order.
 * Then evaluate the expressions in EXPR+ into e[1], ... , e[N] (same order), and concurrently store each e[I] at address a[I].
 *
 * @see AExpr, CLabelTuple, AStmt
 */
class CStoreStmtTuple : public AStmt
{
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_STORE_STMT_TUPLE.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord      The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param addr_exprs Address expressions to store the values into.
    * @param exprs      Expressions that should be evaluated into values.
    * @param stmt_label An optional label that is attached to the statement.
    */
   CStoreStmtTuple(COORD coord, CExprList* addr_exprs, CExprList* exprs, CLabelTuple* stmt_label=NULL);
   
   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CStoreStmtTuple();
   
   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to 
    *          deallocate the memory.
    */
   virtual CStoreStmtTuple* Copy() const;
   
   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitStoreStmtTuple(*this);}

   /**
    * @return The address expressions that the values should be stored into.
    */
   const CExprList* GetAddrExprs() const;
   
   /**
    * @return The expressions that should be evaluated into values.
    */
   const CExprList* GetExprs() const;

   /** @return Pointer to a constant string giving the name of the statement
               type, e.g., "store" or "switch" */
   virtual const char * StatementTypeName() const {return "store";}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual CGenericNode::TYPE GetNodeType() const { return CGenericNode::TYPE_STORE_STMT_TUPLE; } 

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(CGenericNode::TYPE t) const {return t == CGenericNode::TYPE_STORE_STMT_TUPLE || AStmt::IsType(t); }

   CStoreStmtTuple* Duplicate() { return Copy(); }
   void Uses(CAliasGraph *alias_graph, std::set<int> *uses) { }
   void Updates(CAliasGraph *alias_graph, std::set<int> *updated_vars) { }
   void Variables(CAliasGraph *alias_graph, std::set<int> *vars) { }
   void AsText(CTextBlock *text_block, int indentation) const { }
   void PrintAsDot(std::ostream &o) const { OnPrint(o, 0); }

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CStoreStmtTuple(const CStoreStmtTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CStoreStmtTuple& operator=(const CStoreStmtTuple&);

   /**
    * The address targets.
    */
   CExprList* addr_exprs;
   
   /**
    * The values.
    */
   CExprList* exprs;

};

}

#endif

