// $Id $
#include "CString.h"
#include "CAlfTreeExpandingHelper.h"
#include <cassert>

using namespace std;

namespace alf
{

CString::
CString(COORD coord, const string& p_str)
:  CGenericNode(coord),
   str(ResolveString(p_str)),
   src_rep(p_str)
{

}

CString::
CString(COORD coord, CMacroCallTuple* macro_call_tuple)
:  CGenericNode(coord, macro_call_tuple)
{
}

CString::
CString(COORD coord, CMacroFormalArg* macro_formal_arg)
:  CGenericNode(coord, macro_formal_arg)
{
}


CString::
~CString()
{
}

CString*
CString::
Copy() const
{
   return new CString(*this);
}

void
CString::
OnPrint(ostream& o, int indent) const
{
   o << str;
}

CString::
CString(const CString& obj)
:  CGenericNode(obj.coord),
   str(obj.str),
   src_rep(obj.src_rep)
{

}

CString&
CString::
operator=(const CString& obj)
{
   return *this;
}

const string &
CString::
Get() const
{
   return str;
}

const string &
CString::
GetSourceRep() const
{
   return src_rep;
}

void
CString::Set(const std::string& new_string)
{
   str = ResolveString(new_string);
   src_rep = new_string;
}

bool
CString::
operator ==(const CString& other) const
{
   return (str == other.str);
}
   
CGenericNode* 
CString::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CString(GetCoord(), str);
}

std::string
CString::ResolveString(const std::string& str)
{
   string resolved; resolved.reserve(str.length());
   string::size_type i = 0, n = str.length();
   if (str[i] == '"') {
      assert(str[n-1] == '"');
      ++i; --n;
   }
   for (; i != n; ++i)
   {
      if (str[i] != '\\')
         resolved.push_back(str[i]);
      else
      {
         // Special handling of characters following the escape character '\'
         // Based on http://msdn.microsoft.com/en-us/library/h21280bw(v=vs.110).aspx
         ++i;
         switch (str[i]) {
         case 'a': resolved.push_back('\a'); break;
         case 'b': resolved.push_back('\b'); break;
         case 'f': resolved.push_back('\f'); break;
         case 'n': resolved.push_back('\n'); break;
         case 'r': resolved.push_back('\r'); break;
         case 't': resolved.push_back('\t'); break;
         case 'v': resolved.push_back('\v'); break;
         case 'x':
            {
               ++i;
               int sum = 0;
               for (const string::size_type m = min(i + 2, n); i != m && isxdigit(str[i]); ++i) {
                  sum <<= 4;
                  int term;
                  if (isdigit(str[i])) term = str[i] - '0';
                  else if (islower(str[i])) term = 10 + str[i] - 'a';
                  else term = 10 + str[i] - 'A';
                  sum += term;
               }
               resolved.push_back((string::value_type)sum);
               --i; // incremented again before next iteration
               break;
            }
         default:
            if (isdigit(str[i]) && str[i] - '0' < 8) {
               int sum = 0;
               for (const string::size_type m = min(i + 3, n); i != m && isdigit(str[i]) && str[i] - '0' < 8; ++i) {
                  sum <<= 3;
                  sum += str[i] - '0';
               }
               resolved.push_back((string::value_type)sum);
               --i; // incremented again before next iteration
            }
            else resolved.push_back(str[i]);
            break;
         }
      }
   }
   return resolved;
}

}
