#include "CCharStringTuple.h"
#include "AConst.h"
#include "CString.h"
#include <sstream>
#include <cassert>

using namespace alf;
using namespace std;

CCharStringTuple::
CCharStringTuple(COORD coord, CString* p_char_string)
:  CGenericNode(coord),
   AVal(coord),
   char_string(p_char_string)
{
}

CCharStringTuple::
CCharStringTuple(const CCharStringTuple& obj)
:  CGenericNode(obj.coord),
   AVal(obj.coord),
   char_string(obj.char_string->Copy())
{
}

CCharStringTuple::
~CCharStringTuple()
{
   delete char_string;
}


CCharStringTuple*
CCharStringTuple::
Copy() const
{
   return new CCharStringTuple(*this);
}

CCharStringTuple&
CCharStringTuple::
operator=(const CCharStringTuple& obj)
{
   return *this;
}

void
CCharStringTuple::
OnPrint(ostream& stream, int indent) const
{
   PrintIndent(stream, indent);
   stream << "{ char_string " << char_string->GetSourceRep() << " }";
}

const CString*
CCharStringTuple::
GetString() const
{
   return char_string;
}

CGenericNode* 
CCharStringTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CCharStringTuple(GetCoord(), 
                               dynamic_cast<CString*> (char_string->Expand(helper)));
}

