// $Id $

#include "CLabelTuple.h"
#include "CSize.h"
#include <typeinfo>
#include <ostream>
#include "program/alf/CNumber.h"
#include "program/alf/CIntNumValTuple.h"
#include "program/alf/CString.h"

using namespace alf;
using namespace std;

CLabelTuple::
CLabelTuple(COORD coord, CSize* size, CLRefTuple* p_lref, CIntNumValTuple* p_offset)
:  CGenericNode(coord),
   AExpr(coord, size),
   AConst(coord),
   lref(p_lref),
   offset(p_offset)
{
   SetParent(lref);
   SetParent(offset);
}

CLabelTuple::
CLabelTuple(COORD coord, CMacroCallTuple* macro_call_tuple)
:  CGenericNode(coord, macro_call_tuple),
   AExpr(coord, NULL),
   AConst(coord),
   lref(NULL),
   offset(NULL)
{
}

CLabelTuple::
CLabelTuple(COORD coord, CMacroFormalArg* macro_formal_arg)
:  CGenericNode(coord, macro_formal_arg),
   AExpr(coord, NULL),
   AConst(coord),
   lref(NULL),
   offset(NULL)
{
}

CLabelTuple::CLabelTuple(const CLabelTuple& obj)
:  CGenericNode(obj),
   AExpr(obj.coord, ((obj.size != NULL) ? (CSize*)obj.size->Copy() : NULL)),
   AConst(obj.coord),
   lref((obj.lref != NULL) ? (CLRefTuple*)obj.lref->Copy() : NULL),
   offset((obj.offset != NULL) ? (CIntNumValTuple*)obj.offset->Copy() : NULL)
{
   if (lref)
      SetParent(lref);
   if (offset)
      SetParent(offset);
}

CLabelTuple::
~CLabelTuple()
{
   if (lref)
      delete lref;
   if (offset)
      delete offset;
}

CLabelTuple*
CLabelTuple::
Copy() const
{
   return new CLabelTuple(*this);
}

CLabelTuple&
CLabelTuple::
operator=(const CLabelTuple& obj)
{
   return *this;
}

void
CLabelTuple::
OnPrint(ostream& stream, int indent) const
{
   PrintIndent(stream, indent);
   stream << "{ label ";
   size->Print(stream, 0);
   stream << " ";
   lref->Print(stream, 0);
   stream << " ";
   offset->Print(stream, 0);
   stream << " }";
}

CLRefTuple *
CLabelTuple::
GetLRef() const
{
   return lref;
}

CIntNumValTuple *
CLabelTuple::
GetOffset() const
{
   return offset;
}

bool
CLabelTuple::
IsEqual(const CLabelTuple* other_label) const
{
  if(other_label == this)
    return true;
  else {
    return (lref->IsEqual(other_label->lref) && offset->IsEqual(other_label->offset));
  }
}

CGenericNode* 
CLabelTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CLabelTuple(GetCoord(), 
                         dynamic_cast<CSize*>(GetSize()->Expand(helper)),
                         dynamic_cast<CLRefTuple*>(lref->Expand(helper)),
                         dynamic_cast<CIntNumValTuple*>(offset->Expand(helper)));
}
