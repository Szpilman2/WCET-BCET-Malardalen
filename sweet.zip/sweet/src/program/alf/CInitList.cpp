// $Id $

#include "CInitList.h"
#include "CInitTuple.h"
#include "ASTFilter.h"
#include "program/alf/AVal.h"
#include "CListNode.inl"
#include <iostream>
#include <cassert>

using namespace std;
using namespace alf;

CInitList::
CInitList(const COORD& coord, const std::vector<CInitTuple*>& p_list)
:  CGenericNode(coord),
   CListNode<CInitTuple>(coord, "inits", p_list)
{
}

CInitList::
~CInitList()
{
}

CInitList*
CInitList::
Copy() const
{
  return new CInitList(*this);
}

void CInitList::PrintFiltered(std::ostream& o, int indentation, ASTFilter* filter) const
{
   PrintIndent(o, indentation);
   o << "{ inits" << endl;
   for (const_list_iterator i = ConstIterator(); i != InvalidIterator(); ++i)
   {
      if (filter->IncludeInitTuple(**i))
         (*i)->PrintWithEndl(o, indentation + 1);
   }
   o << Indent(indentation) << '}';
}

CGenericNode* 
CInitList::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   const std::vector<CInitTuple*> expandedList = ExpandList(helper);
   return new CInitList(GetCoord(), expandedList);
}

template class alf::CListNode<CInitTuple>;

unsigned int
CInitList::
GetNrOfVolatileInits(ASTFilter *filter) const
{
  unsigned int nr_of_volatiles = 0;
  for (const_list_iterator i = ConstIterator(); i != InvalidIterator(); ++i)
   {
     const alf::CInitTuple * init_tuple = (*i);
     if(init_tuple->GetInitOption() == alf::CInitTuple::VOLATILE) {
       if(!filter || filter->IncludeInitTuple(*init_tuple))
         nr_of_volatiles++;
     }
   }   
  return nr_of_volatiles;
}


unsigned int
CInitList::
GetNrOfAddrVolatileInits(ASTFilter *filter) const
{
  unsigned int nr_of_addr_volatiles = 0;
  for (const_list_iterator i = ConstIterator(); i != InvalidIterator(); ++i)
   {
     const alf::CInitTuple * init_tuple = (*i);
     if(init_tuple->GetInitOption() == alf::CInitTuple::VOLATILE) {
       if(!filter || filter->IncludeInitTuple(*init_tuple)) {
         const AVal * val = init_tuple->GetVal();
         if(val->IsType(CGenericNode::TYPE_ADDR_EXPR_TUPLE)) {
           nr_of_addr_volatiles++;
         }
       }
     }
   }   
  return nr_of_addr_volatiles;
}
