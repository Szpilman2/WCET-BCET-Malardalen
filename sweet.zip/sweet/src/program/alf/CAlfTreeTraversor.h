// $Id $

#ifndef ALF_CALFTREETRAVERSOR_H
#define ALF_CALFTREETRAVERSOR_H

#include "CGenericNode.h"
#include <map>
#include <vector>

namespace alf
{
class CAlfTuple;
class AStmt;
class CFuncTuple;
class CScopeTuple;
class CSwitchStmtTuple;
class CFuncList;
class CLauTuple;
class CExportsTuple;
class CImportsTuple;
class CFRefList;
class CLRefList;
class CFRefTuple;
class CLRefTuple;
class CDeclList;
class CAllocTuple;
class CInitList;
class CInitTuple;
class CRefTuple;
class AVal;
class CArgDeclList;
class CNullStmtTuple;
class CCallStmtTuple;
class CFreeStmtTuple;
class CStoreStmtTuple;
class CSwitchStmtTuple;
class CJumpStmtTuple;
class CReturnStmtTuple;
class CLabelTuple;
class CMacroDefList;
class CMacroDefTuple;
class CMacroFormalArgList;
class CMacroFormalArg;
class CMacroCallTuple;
class CSize;
class CStmtList;
class AExpr;
class CCompAddrTuple;
class CCompLabelTuple;
class CLoadExprTuple;
class COpNumExprTuple;
class CUndefinedExprTuple;
class CUndefinedExprTuple;
class CUnknownExpr;
class CConstRepeatTuple;
class CIntNumValTuple;
class CFloatValTuple;
class CAddrTuple;
class CDynAllocTuple;
class CSizeList;
class CExprList;
class CTargetList;
class CTargetTuple;
class CDefaultTuple;
class ATarget;
class CCharStringTuple;
class CConstList;
class CFloatListTuple;
class CIntListTuple;
class CUnknownVal;
class CUnknownConst;
class CString;

class CAlfTreeTraversor
{
public:
   /** An interface that defines the callback methods that the CAlfTreeTraversor will call for each node it visits in the tree.
    */
   class INodeVisitor
   {
   public:
      virtual ~INodeVisitor() {};
      
      /** Called by the the traversor when it visits a node and before that node's children has been visited.
       * @return true if the traversor should continue and visit the node's children, false to continue to next sibling.
       */
      virtual bool onBeginVisit(const CGenericNode* node) = 0;
      
      /** Called by the the traversor when it visits a node and after that node's children has been visited.
       */
      virtual void onEndVisit(const CGenericNode* node) = 0;
   };
   
   typedef std::vector<INodeVisitor*> RegisteredNodeVisitorsList;
   typedef std::map<INodeVisitor*, bool> EnabledVisitorMap;
   typedef std::map<const CGenericNode*, INodeVisitor*> EnableVisitorAfterNodeMap;

   CAlfTreeTraversor();
   virtual ~CAlfTreeTraversor();
   
   /** Register for callbacks for each node that will be called when
       the tree is traversed through the Traverse methods.
    */
   void RegisterNodeVisitor(INodeVisitor* visitor);

   /** Traverses trees with either of CAlfTuple, CFuncTuple, AStmt or AExpr as start node.
   */
   void BeginTraverse(const CGenericNode* node);

protected:
   template <typename NodeType> void ALFTREETRAVERSOR_VISIT_NODE(const NodeType * node);
   virtual void Traverse(const CAlfTuple* alftree);
   virtual void Traverse(const CFuncTuple* function);
   virtual void Traverse(const AStmt* statement);
   virtual void Traverse(const CScopeTuple* scope);
   virtual void Traverse(const CFuncList* functions);
   virtual void Traverse(const CExportsTuple* exports);
   virtual void Traverse(const CImportsTuple* imports);
   virtual void Traverse(const CFRefList* frefs);
   virtual void Traverse(const CLRefList* lrefs);
   virtual void Traverse(const CLRefTuple* lref);
   virtual void Traverse(const CFRefTuple* fref);
   virtual void Traverse(const CDeclList* decls);
   virtual void Traverse(const CAllocTuple* alloc);
   virtual void Traverse(const CInitList* inits);
   virtual void Traverse(const CInitTuple* init);
   virtual void Traverse(const CRefTuple* ref);
   virtual void Traverse(const AVal* val);
   virtual void Traverse(const CArgDeclList* args);
   virtual void Traverse(const CNullStmtTuple* stmt);
   virtual void Traverse(const CCallStmtTuple* stmt);
   virtual void Traverse(const CFreeStmtTuple* stmt);
   virtual void Traverse(const CStoreStmtTuple* stmt);
   virtual void Traverse(const CSwitchStmtTuple* stmt);
   virtual void Traverse(const CJumpStmtTuple* stmt);
   virtual void Traverse(const CReturnStmtTuple* stmt);
   virtual void Traverse(const CLabelTuple* label);
   virtual void Traverse(const CMacroDefList* macrodefs);
   virtual void Traverse(const CMacroDefTuple* macrodef);
   virtual void Traverse(const CMacroFormalArgList* formalargs);
   virtual void Traverse(const CMacroFormalArg* formalarg);
   virtual void Traverse(const CMacroCallTuple* macrocall);
   virtual void Traverse(const CLauTuple* lau);
   virtual void Traverse(const CSize* size);
   virtual void Traverse(const CStmtList* stmts);
   virtual void Traverse(const AExpr* expr);
   virtual void Traverse(const CCompAddrTuple* expr);
   virtual void Traverse(const CCompLabelTuple* expr);
   virtual void Traverse(const CLoadExprTuple* expr);
   virtual void Traverse(const COpNumExprTuple* expr);
   virtual void Traverse(const CUndefinedExprTuple* expr);
   virtual void Traverse(const CUnknownExpr* expr);
   virtual void Traverse(const CConstRepeatTuple* constrepeat);
   virtual void Traverse(const CCharStringTuple *stringtuple);
   virtual void Traverse(const CConstList* const_list);
   virtual void Traverse(const CFloatListTuple* float_list);
   virtual void Traverse(const CIntListTuple* int_list);
   virtual void Traverse(const CUnknownConst* constval);
   virtual void Traverse(const CUnknownVal* numval);
   virtual void Traverse(const CIntNumValTuple* numval);   
   virtual void Traverse(const CDynAllocTuple* numval);  
   virtual void Traverse(const CSizeList* sizes);
   virtual void Traverse(const CExprList* exprs);
   virtual void Traverse(const CAddrTuple* addr);
   virtual void Traverse(const CTargetList* targets);
   virtual void Traverse(const ATarget* target);
   virtual void Traverse(const CTargetTuple* target);
   virtual void Traverse(const CDefaultTuple* target);
   virtual void Traverse(const CFloatValTuple* floatval);
   virtual void Traverse(const CString* floatval);

   bool BeginVisit(const CGenericNode* node);
   void EndVisit(const CGenericNode* node);
   void BeginAndEndVisit(const CGenericNode* node);
   
private:
   EnabledVisitorMap enabled_visitor_map;
   EnableVisitorAfterNodeMap enable_visitor_after_node_map;
   RegisteredNodeVisitorsList node_visitors;
};

}

#endif
