// $Id $

#include "CSizeList.h"
#include "CSize.h"
#include "CListNode.inl"

using namespace alf;

CSizeList::
CSizeList(const COORD& coord, const std::vector<CSize*>& p_list)
:  CGenericNode(coord),
   CListNode<CSize>(coord, p_list, false, false)
{
}

CSizeList::
~CSizeList()
{
}

CSizeList*
CSizeList::
Copy() const
{
   return new CSizeList(*this);
}

CGenericNode* 
CSizeList::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   const std::vector<CSize*> expandedList = ExpandList(helper);
   return new CSizeList(GetCoord(), expandedList);
}

template class alf::CListNode<CSize>;
