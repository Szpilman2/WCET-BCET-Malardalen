/* $Id: CAlfTuple.cpp 7573 2016-01-30 18:08:45Z lkg02 $ */

#include "CAlfTuple.h"
#include "CAlfTreeFilter.h"
#include "CLauTuple.h"
#include "CFRefList.h"
#include "CLRefList.h"
#include "CFRefTuple.h"
#include "CRefTuple.h"
#include "CLRefTuple.h"
#include "CException.h"
#include "CExportsTuple.h"
#include "CImportsTuple.h"
#include "CAllocTuple.h"
#include "CDeclList.h"
#include "CString.h"
#include "CInitList.h"
#include "CFuncList.h"
#include "CInitTuple.h"
#include "CFuncTuple.h"
#include "CMacroDefTuple.h"
#include "CMacroDefList.h"
#include "CNumber.h"
#include "CSymTabBuilder.h"
#include "CSteensgaardPAOnALFProgram.h"
#include "CAlfTreeExpandingHelper.h"
#include "tools/CTextBlock.h"
#include "graphs/cg/CCallGraph.h"
#include "graphs/cg/CCallGraphNode.h"
#include "program/CGenericFunction.h"
#include "program/alf/CArgDeclList.h"
#include <sstream>
#include <set>

using namespace std;
namespace alf
{

CAlfTuple::
CAlfTuple(  const COORD& coord,
            CMacroDefList* p_defs,
            CLauTuple* p_lau,
            std::string p_endian,
            CExportsTuple* p_exports,
            CImportsTuple* p_imports,
            CDeclList* p_decls,
            CInitList* p_inits,
            CFuncList* p_funcs)
:  CGenericNode(coord),
   defs(p_defs),
   lau(p_lau),
   endian(p_endian),
   exports(p_exports),
   imports(p_imports),
   decls(p_decls),
   inits(p_inits),
   funcs(p_funcs),
   _symtab(NULL)
{
   SetParent(defs);
   SetParent(lau);
   SetParent(exports);
   SetParent(imports);
   SetParent(decls);
   SetParent(inits);
   SetParent(funcs);
}

CAlfTuple::
~CAlfTuple()
{
   delete defs;
   delete lau;
   delete exports;
   delete imports;
   delete decls;
   delete inits;
   delete funcs;
   if (_symtab)
      delete _symtab;
}

CAlfTuple::
CAlfTuple(const CAlfTuple& obj)
:  CGenericNode(obj.coord),
   defs(obj.defs->Copy()),
   lau(obj.lau->Copy()),
   endian(obj.endian),
   exports(obj.exports->Copy()),
   imports(obj.imports->Copy()),
   decls(obj.decls->Copy()),
   inits(obj.inits->Copy()),
   funcs(obj.funcs->Copy()),
   _symtab(NULL)
{
   SetParent(defs);
   SetParent(lau);
   SetParent(exports);
   SetParent(imports);
   SetParent(decls);
   SetParent(inits);
   SetParent(funcs);
}

CAlfTuple*
CAlfTuple::
Copy() const
{
   return new CAlfTuple(*this);
}

CAlfTuple&
CAlfTuple::
operator=(const CAlfTuple& obj)
{
   return *this;
}

void
CAlfTuple::
OnPrint(ostream& stream, int indent) const
{
   PrintIndent(stream, indent);
   stream << "{ alf" << endl;

   defs->Print(stream, indent+1);
   stream << endl;

   lau->Print(stream, indent+1);
   stream << endl;

   PrintIndent(stream, indent+1);
   stream << endian << endl;

   exports->Print(stream, indent+1);
   stream << endl;

   imports->Print(stream, indent+1);
   stream << endl;

   decls->Print(stream, indent+1);
   stream << endl;

   inits->Print(stream, indent+1);
   stream << endl;

   funcs->Print(stream, indent+1);
   stream << endl;

   PrintIndent(stream, indent);
   stream << "}" << endl;
}



void
CAlfTuple::
AsText(CTextBlock *text_block, int indentation) const
{
   ostringstream oss;
   Print(oss);
   text_block->push_back(CTextElement(oss.str()));
}

void CAlfTuple::PrintFiltered(ostream& o, int indentation, ASTFilter* filter) const
{
   o << Indent(indentation) << "{ alf" << endl;
 
   defs->PrintWithEndl(o, indentation+1);

   lau->PrintWithEndl(o, indentation+1);

   o << Indent(indentation+1) << endian << endl;

   exports->PrintFiltered(o, indentation+1, filter);
   o << endl;

   imports->PrintFiltered(o, indentation+1, filter);
   o << endl;

   decls->PrintFiltered(o, indentation+1, filter);
   o << endl;

   inits->PrintFiltered(o, indentation+1, filter);
   o << endl;

   funcs->PrintFiltered(o, indentation+1, filter);
   o << endl;

   o << Indent(indentation) << "}" << endl;
}


const CMacroDefList*
CAlfTuple::
GetDefs() const
{
   return defs;
}

const CLauTuple*
CAlfTuple::
GetLau() const
{
   return lau;
}

const string
CAlfTuple::
GetEndian() const
{
   return endian;
}

const CExportsTuple*
CAlfTuple::
GetExports() const
{
   return exports;
}

CExportsTuple* CAlfTuple::GetExports()
{
   return exports;
}

bool CAlfTuple::HasExportedLRefsOrFRefs() const
{
  return (exports->GetFRefList()->ElementCount() > 0 ||
          exports->GetLRefList()->ElementCount() > 0);
}

const CImportsTuple*
CAlfTuple::
GetImports() const
{
   return imports;
}

CImportsTuple* CAlfTuple::GetImports()
{
   return imports;
}

bool CAlfTuple::HasImportedLRefsOrFRefs() const
{
  return (imports->GetFRefList()->ElementCount() > 0 ||
          imports->GetLRefList()->ElementCount() > 0);
}

const CDeclList*
CAlfTuple::
GetDecls() const
{
   return decls;
}

CDeclList* CAlfTuple::GetDecls()
{
   return decls;
}

const CInitList*
CAlfTuple::
GetInits() const
{
   return inits;
}

bool
CAlfTuple::
HasVolatileInits() const
{
  bool has_volatiles = false;
  const alf::CInitList * inits = GetInits();
  for (CInitList::const_list_iterator i = inits->ConstIterator(); i != inits->InvalidIterator(); ++i) {
    if((*i)->GetInitOption() == CInitTuple::VOLATILE) {
      has_volatiles = true;
      break;
    }
  }
  return has_volatiles;
}


CInitList* CAlfTuple::GetInits()
{
   return inits;
}

const CFuncList*
CAlfTuple::
GetFuncs() const
{
   return funcs;
}

CFuncList* CAlfTuple::GetFuncs()
{
   return funcs;
}

unique_ptr <CSteensgaardAnalysisBuilder>
CAlfTuple::
GetSteensgaardAnalysisBuilder()
{
   return  unique_ptr <CSteensgaardAnalysisBuilder>(new CSteensgaardPAOnALFProgram());
}

void
CAlfTuple::
Functions(vector<CGenericFunction*> & functions) const
{
   functions.insert(functions.end(), funcs->ConstIterator(), funcs->InvalidIterator());
}

const CSymTabBase *
CAlfTuple::
GetSymTab() const
{
   if (_symtab == NULL) throw CException("Internal error: Symbol table requested before it was built.");
   return _symtab;
}

const CAlfTuple*
CAlfTuple::
Expand() const
{
   CAlfTreeExpandingHelper* helper = new CAlfTreeExpandingHelper(this);
   CAlfTuple* newTree = static_cast<CAlfTuple*>(CGenericNode::Expand(helper));
   delete helper;
   return newTree;
}
   
void
CAlfTuple::
CreateSymbolTable()
{
   DestroySymbolTable();
   CSymTabBuilder sym_tab_builder = CSymTabBuilder(this);
   _symtab = sym_tab_builder.GetSymTab();
}

void CAlfTuple::DestroySymbolTable()
{
   delete _symtab;
   _symtab = 0;

   // Clear the keys from all nodes in the tree (using really beautiful code :) )
   CAlfTreeFilter filter = CAlfTreeFilter(this);
   CAlfTreeFilter::NodeList all_nodes = filter.GetAllNodes();
   for (CAlfTreeFilter::NodeList::iterator n = all_nodes.begin(); n != all_nodes.end(); ++n)
   {
      CSymTabIdentifier* as_sti;
      if ((as_sti = dynamic_cast<CSymTabIdentifier*>(const_cast<CGenericNode*>(*n))) != 0)
         as_sti->RemoveKey();
   }
}

// Collects all global variables and functions (static as well as external).
// Globals variables are always present in decls
// Global functions are all functions in the list of functions.
static void CollectGlobals(set <string> &globals, CAlfTuple &alf_tuple)
{
   const CDeclList &decls = *alf_tuple.GetDecls();
   const CFuncList &funcs = *alf_tuple.GetFuncs();
   for (CDeclList::const_list_iterator alloc_it = decls.ConstIterator(); alloc_it != decls.InvalidIterator(); ++alloc_it)
      globals.insert((*alloc_it)->Name());

   for (CFuncList::const_list_iterator func_it = funcs.ConstIterator(); func_it != funcs.InvalidIterator(); ++func_it) {
      globals.insert((*func_it)->Name());
   }
}

static void CollectExternals(set <string> &externals, const CExportsTuple &exports)
{
   const CFRefList &frefs = *exports.GetFRefList();
   const CLRefList &lrefs = *exports.GetLRefList();
   for (CFRefList::const_list_iterator fref_it = frefs.ConstIterator(); fref_it != frefs.InvalidIterator(); ++fref_it)
      externals.insert((*fref_it)->Name());
   for (CLRefList::const_list_iterator lref_it = lrefs.ConstIterator(); lref_it != lrefs.InvalidIterator(); ++lref_it)
      externals.insert((*lref_it)->Name());
}

static void ComputeStatics(vector <string> &statics, set <string> &globals, set <string> &externals)
{
   for (set <string>::iterator id_it=globals.begin(); id_it!=globals.end(); ++id_it) {
      if (externals.find(*id_it) == externals.end())
         statics.push_back(*id_it);
   }
}

static void ComputeClashes(set <string> &clashes, vector <string> &statics, set <string> &ex)
{
   for (vector <string>::iterator sit=statics.begin(); sit!=statics.end(); ++sit)
   {
      string clash_id = *sit;
      if (ex.find(clash_id) != ex.end())
      {
         clashes.insert(clash_id);
      }
   }
}

static void MangleClashes(CAlfTuple &alf_tuple, set <string> &clashes)
{
   static unsigned unique_number;
   if (clashes.size() > 0) {
      map <string, unsigned> mangle_numbers;
      for (set <string>::iterator clash_it=clashes.begin(); clash_it!=clashes.end(); ++clash_it) {
         mangle_numbers[*clash_it] = ++unique_number;
      }
      CAlfTreeFilter all_names = CAlfTreeFilter(&alf_tuple);
      CAlfTreeFilter::NodeList string_list = all_names.GetNodesOfType(CGenericNode::TYPE_STRING);
      for (CAlfTreeFilter::NodeList::iterator it = string_list.begin(); it != string_list.end(); ++it) {
         const CString *dstr = dynamic_cast<const CString*>(*it);
         string name = dstr->Get();
         if (clashes.find(name) != clashes.end()) {
            CString *str = const_cast<CString*>(dstr);
            stringstream s;
            s << "$" << mangle_numbers[name] << "_";
            str->Mangle(s.str());
         }
      }
   }
}

/** For any static variable found in an alf tuple that has the same name as a string in a list,
   mangle it.
   \param alf_tuple An alf tree.
   \param this_globals A set of all globals in \a alf_tuple, as strings.
   \param forbidden A set of strings that the statics in \a alf_tuple are not allowed to have.
*/
static void ResoveConflicts(CAlfTuple &alf_tuple, set <string> &this_globals, set <string> &forbidden)
{
   set <string> clashes;
   set <string> externals;
   vector <string> statics;
   const CExportsTuple &exports = *alf_tuple.GetExports();

   // Collect external global names
   CollectExternals(externals, exports);

   // Compute static names (global within in file, not exported)
   ComputeStatics(statics, this_globals, externals);

   // Compute the names that clashes between a static in one file and any global in the other file
   ComputeClashes(clashes, statics, forbidden);

   MangleClashes(alf_tuple, clashes);
}

void
CAlfTuple::
Link(CAlfTuple &other, std::string (*Unmangle)(std::string))
{
   CAlfTuple &first_ast = *this;
   CAlfTuple &second_ast = other;
//    Mangle the names of statics that clash with globals in the other alf tree
//    s1<->g2
//    g1<->s2
   set <string> first_globals;
   set <string> second_globals;

   // Collect all globals names
   CollectGlobals(first_globals, first_ast);
   CollectGlobals(second_globals, second_ast);

   ResoveConflicts(*this, first_globals, second_globals);
   ResoveConflicts(other, second_globals, first_globals);

   // Link together the different parts of this alf tree with the
   // corresponding part of the other alf tree.
   // The import section need to filter out the imports that was
   // resolved by the linking.
   exports->Link(*other.exports, Unmangle);
   imports->LinkWithFilter(*other.imports, *exports, Unmangle);
   decls->Link(*other.decls);
   inits->Link(*other.inits);
   funcs->Link(*other.funcs);
}

void CAlfTuple::Merge(CAlfTuple& other)
{
   GetExports()->Merge(*other.GetExports());
   GetImports()->Merge(*other.GetImports());
   GetDecls()->Merge(*other.GetDecls());
   GetInits()->Merge(*other.GetInits());
   GetFuncs()->Merge(*other.GetFuncs());
}

void CAlfTuple::RemoveNamedFunctions(const std::set<std::string>& funcs)
{
  GetExports()->GetLRefList()->RemoveNamedLRefs(funcs);
   GetFuncs()->RemoveNamedFunctions(funcs);
}

void CAlfTuple::PrintImportsAsText(std::ostream * s, ASTFilter* filter) const 
{
  const CImportsTuple* imports = GetImports();
  unsigned nr_of_imported_frefs = 0;
  unsigned nr_of_imported_lrefs = 0;
  {
    (*s) << "Imported data (frefs)" << endl;
    (*s) << "---------------------" << endl; 
    const CFRefList* frefs = imports->GetFRefList();
    for(CFRefList::const_list_iterator fref = frefs->ConstIterator(); 
        fref != frefs->InvalidIterator(); fref++) {
      // The fref should be printed if we have no filter, or if we
      // have a filter and the fref is included in it
      if(!filter || filter->IncludeFRefTuple(**fref)) {
        nr_of_imported_frefs++; 
        (*s) << (*fref)->Name() << endl;
      }
    }
    (*s) << endl;
  }

  {
    (*s) << "Imported functions (lrefs)" << endl;
    (*s) << "--------------------------" << endl; 
    const CLRefList* lrefs = imports->GetLRefList();
    for(CLRefList::const_list_iterator lref = lrefs->ConstIterator(); 
        lref != lrefs->InvalidIterator(); lref++) {
      // The lref should be printed if we have no filter, or if we
      // have a filter and the fref is included in it
      if(!filter || filter->IncludeLRefTuple(**lref)) {
        nr_of_imported_lrefs++; 
        (*s) << (*lref)->Name() << endl;
      }
    }
    (*s) << endl;
  }

  (*s) << "Summary: ";
  (*s) << nr_of_imported_frefs << "\t" << nr_of_imported_lrefs << endl;
}      
    
void CAlfTuple::PrintExportsAsText(std::ostream * s, ASTFilter* filter) const
{
  const CExportsTuple* exports = GetExports();
  unsigned nr_of_exported_frefs = 0;
  unsigned nr_of_exported_lrefs = 0;

  {
    (*s) << "Exported frefs" << endl;
    (*s) << "--------------" << endl;  
    const CFRefList* frefs = exports->GetFRefList();
    for(CFRefList::const_list_iterator fref = frefs->ConstIterator(); 
        fref != frefs->InvalidIterator(); fref++) {
      // The fref should be printed if we have no filter, or if we
      // have a filter and the fref is included in it
      if(!filter || filter->IncludeFRefTuple(**fref)) {
        nr_of_exported_frefs++; 
        (*s) << (*fref)->Name() << endl;
      }
    }
    (*s) << endl;
  }

  {
    (*s) << "Exported lrefs" << endl; 
    (*s) << "--------------" << endl;  
    const CLRefList* lrefs = exports->GetLRefList();
    for(CLRefList::const_list_iterator lref = lrefs->ConstIterator(); 
        lref != lrefs->InvalidIterator(); lref++) {
      // The lref should be printed if we have no filter, or if we
      // have a filter and the fref is included in it
      if(!filter || filter->IncludeLRefTuple(**lref)) {
        nr_of_exported_lrefs++; 
        (*s) << (*lref)->Name() << endl;
      }
    }
    (*s) << endl;
  }
  (*s) << "Summary: ";
  (*s) << nr_of_exported_frefs << "\t" << nr_of_exported_lrefs << endl;
}      
    
void CAlfTuple::PrintImportsAsAnnotTemplate(std::ostream * s, ASTFilter* filter) const 
{
  const CImportsTuple* imports = GetImports();
  { // ---------------------------------
    // Print imported frefs as annots
    // ---------------------------------
    bool print_fref_annots = false;
    { // Check if annots and text should be printed
      const CFRefList* frefs = imports->GetFRefList();
      for(CFRefList::const_list_iterator fref = frefs->ConstIterator(); 
          fref != frefs->InvalidIterator(); fref++) {
        // The fref should be printed if we have no filter, or if we
        // have a filter and the fref is included in it
        if(!filter || filter->IncludeFRefTuple(**fref)) {
          print_fref_annots = true;
          break;
        }
      }
    }
 
    if(print_fref_annots) 
      {
        (*s) << "/* --------------------------------------------------------- */" << endl; 
        (*s) << "/* Annotation templates for imported data (frefs)            */" << endl;
        (*s) << "/* --------------------------------------------------------- */" << endl << endl; 
        
        (*s) << "/* Given annotations should provide a safe upper bounds on what" << endl
             << "   value a data, or specific fields of a data, may hold.       " << endl
             << "   The annotations should be valid for any execution of the    " << endl
             << "   program (for all its possible input value combinations).    " << endl 
             << "   Please run: sweet -h topic=annot  for annotation syntax   */" << endl << endl; 
        
        const CFRefList* frefs = imports->GetFRefList();
        unsigned int nr_of_fref_templates = 0;
        for(CFRefList::const_list_iterator fref = frefs->ConstIterator(); 
            fref != frefs->InvalidIterator(); fref++) {
          // The fref should be printed if we have no filter, or if we
          // have a filter and the fref is included in it
          if(!filter || filter->IncludeFRefTuple(**fref)) {
            nr_of_fref_templates++; 
            (*s) << "VOLATILE ASSIGN " << (*fref)->Name() << " <type> <val> ;" << endl << endl;
          }
        }
      }
  }

  { // ---------------------------------
    // Print imported lrefs as annots
    // ---------------------------------
    bool print_lref_annots = false;
    { // Check if annots and text should be printed
      const CLRefList* lrefs = imports->GetLRefList();
      for(CLRefList::const_list_iterator lref = lrefs->ConstIterator(); 
          lref != lrefs->InvalidIterator(); lref++) {
        // The lref should be printed if we have no filter, or if we
        // have a filter and the fref is included in it
        if(!filter || filter->IncludeLRefTuple(**lref)) {
          print_lref_annots = true;
          break;
        }
      }
    }
    
    if(print_lref_annots) 
      {
        (*s) << "/* ----------------------------------------------------------- */" << endl; 
        (*s) << "/* Annotation templates for imported functions (lrefs)         */" << endl;
        (*s) << "/* ----------------------------------------------------------- */" << endl << endl; 
        
        (*s) << "/* The annotations should provide a safe upper bound on the      " << endl 
             << "   possible return values (if such exists) after a call to the   " << endl
             << "   given function. Also, it should provide bounds on what values " << endl 
             << "   values global data might have after a call to the function.   " << endl
             << "   Assignments of local/global data by dereferencing the input   " << endl
             << "   argument to the function can currently not be handled.        " << endl
             << "   Please run: sweet -h topic=annot  for annotation syntax     */" << endl << endl; 
        
        const CLRefList* lrefs = imports->GetLRefList();
        unsigned int nr_of_lref_templates = 0;
        for(CLRefList::const_list_iterator lref = lrefs->ConstIterator(); 
            lref != lrefs->InvalidIterator(); lref++) {
          // The lref should be printed if we have no filter, or if we
          // have a filter and the fref is included in it
          if(!filter || filter->IncludeLRefTuple(**lref)) {
            nr_of_lref_templates++;
            (*s) << "WHEN_CALLED " << (*lref)->Name() << " ASSIGN <var> <type> <val> || ... || RET_VAL <type> <val> ;" << endl << endl;
          }
        }
      }
  }
}

// These functions will provide annotation templates if we start the
// flow analysis from a function that takes input arguments
void CAlfTuple::PrintStartFunctionArgumentsAsAnnotTemplate(const CGenericFunction * func, std::ostream * s) const
{
  const CFuncTuple * func_tuple = dynamic_cast<const CFuncTuple *>(func);
  PrintStartFunctionArgumentsAsAnnotTemplate(func_tuple, s);
}

void CAlfTuple::PrintStartFunctionArgumentsAsAnnotTemplate(const CFuncTuple * func, std::ostream * s) const
{
  // Skip printing unneccessary annotation info
  if(func->GetArgs()->ElementCount() == 0)
    return;

  (*s) << "/* ------------------------------------------------------- */" << endl; 
  (*s) << "/* Annotation template for start function with arguments   */" << endl;
  (*s) << "/* ------------------------------------------------------- */" << endl << endl; 

  (*s) << "/* The annotation should provide a safe upper bound on the   " << endl 
       << "   possible argument values which the start function of the  " << endl
       << "   analysis might be run with. Please run:                   " << endl
       << "   sweet -h topic=annot    for annotation syntax           */" << endl << endl; 

  // Print the start of the func entry annotation
  std::string func_name = func->Name();
  (*s) << "FUNC_ENTRY " << func_name << " ASSIGN ";

  // Loop through all formal arguments
  const CArgDeclList * form_args = func->GetArgs();
  for (CArgDeclList::const_list_iterator farg = form_args->ConstIterator();
       farg != form_args->InvalidIterator(); /* intentionally empty */) 
    {
      // Extract the frame identifier and write it to annotation template 
      std::string fref_id = (*farg)->Name();
      (*s) << fref_id << " ";
      // Size frame_size = (*farg)->GetFrameSize()->GetSizeInBits();
      // (*s) << " 0 " << frame_size << " ";
      (*s) << "<type> <val> ";
      farg++;
      if(farg != form_args->InvalidIterator())
        (*s) << "|| ";
      else 
        (*s) << "; ";
    }
}
  
  
void CAlfTuple::PrintVolatilesAsAnnotTemplate(std::ostream * s, ASTFilter* filter) const
{

  bool print_volatile_annots = false;
  { // Check if we have volatile inits
    const alf::CInitList * inits = GetInits();
    for (CInitList::const_list_iterator i = inits->ConstIterator(); i != inits->InvalidIterator(); ++i) {
      if((*i)->GetInitOption() == CInitTuple::VOLATILE) {
        print_volatile_annots = true;
        break;
      }
    }
  }
  
  if(print_volatile_annots) 
    {
        (*s) << "/* -------------------------------------------------------  */" << endl; 
        (*s) << "/* Annotation template for volatile data (frefs)            */" << endl;
        (*s) << "/* -------------------------------------------------------- */" << endl << endl; 
        
        (*s) << "/* The annotation should provide a safe upper bound on the    " << endl 
             << "   possible values that might be held by this volatile        " << endl
             << "   when read during all possible executions of the program.   " << endl
             << "   Please run: sweet -h topic=annot   for annotation syntax */" << endl << endl; 

      // Run through the list of initializations and create annotation
      // templates for all inits which are volatile
      const alf::CInitList * inits = GetInits();
      for (CInitList::const_list_iterator i = inits->ConstIterator(); i != inits->InvalidIterator(); ++i) {

        // Skip all non-volatile inits
        if((*i)->GetInitOption() != CInitTuple::VOLATILE)
          continue;

        // Check if we should not include the init tuple due to filter
        if(filter && !filter->IncludeInitTuple(**i))
          continue;

        // Get the variable id and offset
        const CRefTuple * ref_tuple = (*i)->GetRef();
        std::string var_name = ref_tuple->Name();
        alf::CIntegerNumber * offset = ref_tuple->GetOffset()->GetNumber();
        // if (offset->FitsInInt())
        //  offset->GetValueAsInt();
        // else
        //  offset->GetValueAsBignum();
        (*s) << "VOLATILE ASSIGN " << var_name << " ";
        (*s) << offset << " ";
        (*s) << "<size> <type> <value> ; " << endl;
      }
    }
}
 
void CAlfTuple::PrintImportsAndVolatilesAsAnnotTemplate(std::ostream * s, ASTFilter* filter) const
{
  PrintImportsAsAnnotTemplate(s, filter);
  PrintVolatilesAsAnnotTemplate(s, filter);
}
    


CGenericNode* 
CAlfTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CAlfTuple(GetCoord(),
                        new CMacroDefList(defs->GetCoord()),
                        static_cast<CLauTuple*>(lau->Expand(helper)),
                        endian,
                        dynamic_cast<CExportsTuple*>(exports->Expand(helper)),
                        dynamic_cast<CImportsTuple*>(imports->Expand(helper)),
                        dynamic_cast<CDeclList*>(decls->Expand(helper)),
                        dynamic_cast<CInitList*>(inits->Expand(helper)),
                        dynamic_cast<CFuncList*>(funcs->Expand(helper)));
}
}
