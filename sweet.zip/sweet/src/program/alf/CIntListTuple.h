// $Id $

#ifndef ALF_CINTLISTTUPLE_H
#define ALF_CINTLISTTUPLE_H

#include "CListNode.h"
#include "AVal.h"
#include "CIntNumValTuple.h"
#include "AlfNodeVisitor.h"
#include <map>

namespace alf
{
class CSize;
class CString;

/**
 * Represents a list of integer numbers of the VAL rule in the ALF grammar:
 * VAL -> { udec_list SIZE UNSIGNED_STRING }
 *      | { dec_list  SIZE SIGNED_STRING   }
 *
 * @see CSize, CIntNumValTuple, CListNode, AVal
 */
class CIntListTuple : public CListNode<CIntNumValTuple>, public AVal
{
public:
  /**
    * Constructor, creates a list node from a vector of frame references.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_INT_LIST.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord        The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param element_type Type of integer.
    * @param size         The size of the integer.
    * @param list         A vector of pairs constisting of integer values and a bool determining if the value should be treated as negative.
    */
   CIntListTuple(const COORD& coord, CIntNumValTuple::INT_TYPE element_type, CSize* size, const std::vector<CString*>& list);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CIntListTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   CIntListTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitIntListTuple(*this);}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_INT_LIST; }

   /** 
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_INT_LIST || CListNode<CIntNumValTuple>::IsType(t) || AVal::IsType(t); }

protected:
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;

   /** @copydoc CListNode<CIntNumValTuple>::OnPrint */
   virtual void OnPrint(std::ostream& o, int indent) const;

private:
   CIntListTuple(const COORD& coord, std::string element_type_name, CSize* size, const std::vector<CIntNumValTuple*>& p_list);
};

}
#endif

