#ifndef ASTFILTER_H_INCLUDED
#define ASTFILTER_H_INCLUDED

namespace alf
{

class CFRefTuple;
class CLRefTuple;
class CAllocTuple;
class CInitTuple;
class CFuncTuple;

class ASTFilter
{
public:
   virtual bool IncludeFRefTuple(const CFRefTuple& fref_tuple) const = 0;

   virtual bool IncludeLRefTuple(const CLRefTuple& lref_tuple) const = 0;

   virtual bool IncludeAllocTuple(const CAllocTuple& alloc_tuple) const = 0;

   virtual bool IncludeInitTuple(const CInitTuple& init_tuple) const = 0;

   virtual bool IncludeFuncTuple(const CFuncTuple& func_tuple) const = 0;
};

}

#endif   // #ifndef ASTFILTER_H_INCLUDED
