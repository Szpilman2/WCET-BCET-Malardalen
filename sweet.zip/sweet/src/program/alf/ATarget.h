// $Id $

#ifndef ALF_ATARGET_H
#define ALF_ATARGET_H

#include "CGenericNode.h"

namespace alf
{
class AExpr;

/**
 * Abstract super class of all nodes that can be considered targets
 * to jump to in a switch statement.
 * Inherits from CGenericNode and represents the following rules in the ALF grammar:
 * TARGET -> { target INT_NUM_VAL LABEL_EXPR }
 *        |  { default LABEL_EXPR }
 *
 * @see CTargetTuple, CDefaultTuple, CSwitchTuple, CGenericNode.
 */
class ATarget : public CGenericNode
{
public:
   /**
   * Constructor, initializes all members from the parameters given.
   * Also sets this node as parent to the incoming nodes, and passes 'node_type' to CGenericNode.
   * The class is responsible to deallocate all the arguments.
   *
   * @param coord       The line and column numbers the in the parsed file where the rule creating this node was found.
   * @param label_expr  A label expression equal the label of the statement to jump to.
   */
   ATarget(COORD coord, AExpr *label_expr);

   /**
   * Deallocates all the memory that the node is using.
   */
   virtual ~ATarget();

   /**
   * @return The label expression node equal to the label of the statement to jump to.
   */
   const AExpr* GetLabelExpr() const;

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_TARGET || CGenericNode::IsType(t); }

protected:
   /**
   * The label expression node.
   */
   AExpr *label_expr;

private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   ATarget(const ATarget&);
   
   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   ATarget& operator=(const ATarget&);
};

}

#endif

