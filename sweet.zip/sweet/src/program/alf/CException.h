// $Id $

#ifndef ALF_CEXCEPTION_H_
#define ALF_CEXCEPTION_H_

#include <exception>
#include <string>

namespace alf
{

/**
 * Represents an exception that can be thrown from ALF-classes.
 */
class CException : public std::exception
{
public:
   /**
    * Create an empty exception, the what() method will print "ALF exception".
    */
   CException();
   
   /**
    * Create an exception, the what() method will print "ALF exception:" concatinated with 'description'.
    */
   CException(std::string description);
   
   /**
    * Deallocates all the memory that the class is using.
    */
   virtual ~CException() throw ();
   
   /**
    * @return The description of the exception.
    */
   virtual const char* what() const throw();
private:

   /**
    * The description of the exception.
    */
   std::string description;
};

}

#endif

