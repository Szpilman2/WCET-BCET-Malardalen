// $Id $

#ifndef ALF_CTARGETLIST_H
#define ALF_CTARGETLIST_H

#include "CListNode.h"

namespace alf
{
   class ATarget;
   
   class CTargetList : public CListNode<ATarget>
   {
   public:
      CTargetList(const COORD& coord, const std::vector<ATarget*>& p_list=std::vector<ATarget*>());
      virtual ~CTargetList();
      
      virtual CTargetList* Copy() const;
     
      /**
       * Accept visit from an AlfNodeVisitor
       */
      virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitTargetList(*this);}

      /**
       * Gets the type of the node.
       * @return  The type of the node so that it can be identified quickly.
       */
      virtual TYPE GetNodeType() const { return TYPE_TARGET_LIST; } 
      
      /** 
       * Checks if the node has a certain type. Should be overwritten by subclasses.
       * @return  true or false.
       */
      virtual bool IsType(TYPE t) const {return t == TYPE_TARGET_LIST || CListNode<ATarget>::IsType(t); }
   protected:
      virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
      
   };
   
}

#endif
