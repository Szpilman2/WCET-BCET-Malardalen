// $Id $

#ifndef ALF_DEFAULTTUPLE_H
#define ALF_DEFAULTTUPLE_H

#include "ATarget.h"
#include "AlfNodeVisitor.h"

namespace alf
{

/**
* Represents a defult jump target in the alf grammar:
*  TARGET -> { default LABEL_EXPR }
*
* @see AExpr, ATarget
*/
class CDefaultTuple : public ATarget
{
public:
  /**
   * Constructor, creates a list node from a vector of frame references.
   * Sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_TYPE_DEFAULT_TUPLE.
   * The class is responsible to deallocate all the arguments.
   *
   * @param coord      The line and column numbers the in the parsed file where the rule creating this node was found.
   * @param label_expr A label expression equal to a label attached to a statement somewhere, that is the jump target.
   */
  CDefaultTuple(COORD coord, AExpr* label_expr);
  
  /**
   * Deallocates all the memory that the node is using.
   */
  virtual ~CDefaultTuple();
  
  /**
   * Performs a deep copy of the node.
   * @returns A completely new set of nodes. The caller is responsible to
   *          deallocate the memory.
   */
  virtual CDefaultTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitDefaultTuple(*this);}

 /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_DEFAULT_TUPLE; }
  
  /** 
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_DEFAULT_TUPLE || ATarget::IsType(t); }

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
  /**
   * Copy constructor, performs a deep copy of the incoming node.
   */
  CDefaultTuple(const CDefaultTuple&);
  
  /**
   * Assignment operator which is overloaded so no mistakes is made.
   * @return  A reference to this node.
   */
  CDefaultTuple& operator=(const CDefaultTuple&);
  
};

}

#endif

