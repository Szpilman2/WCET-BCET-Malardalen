// $Id $

#ifndef ALF_CALFTUPLE_H
#define ALF_CALFTUPLE_H

#include "CGenericNode.h"
#include "AlfNodeVisitor.h"
#include "program/CGenericProgram.h"
#include "graphs/cg/CCallGraph.h"
#include "program/alf/ASTFilter.h"

class CSymTabBase;
namespace alf
{
template <class T> class CListNode;
class CLauTuple;
class CExportsTuple;
class CImportsTuple;
class CAllocTuple;
class CInitList;
class CDeclList;
class CFuncList;
class CMacroDefList;
class ASTFilter;

/**
 * The root node of an ALF program.
 * It represents the following rule in the ALF grammar:
 * ALF -> { alf DEFS LAU ENDIAN EXPORTS IMPORTS DECLS INITS FUNCS }
 *
 * @see CLauTuple, CExportsTuple, CImportsTuple, CDeclList, CInitList,
 *      CFuncList, CMacroDefList, CGenericNode.
 */

class CAlfTuple : public CGenericNode, public CGenericProgram
{
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_ALF_TUPLE.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param defs    Node containing macro definitions.
    * @param lau     Node that specifies the least addressable unit size.
    * @param endian  Specifies endianness: 'little_endian' or 'big_endian'.
    * @param exports Node containing declarations of exported symbols.
    * @param imports Node containing declarations of imported symbols.
    * @param decls   Node containing allocation of static data areas.
    * @param inits   Node containing initializations of static data areas.
    * @param funcs   Node containing function declarations.
    */
   CAlfTuple(  const COORD& coord,
               CMacroDefList* defs,
               CLauTuple* lau,
               std::string endian,
               CExportsTuple* exports,
               CImportsTuple* imports,
               CDeclList* decls,
               CInitList* inits,
               CFuncList* funcs);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CAlfTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   virtual CAlfTuple* Copy() const;
   
   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitAlfTuple(*this);}

   /**
    * Expands all the macro definitions in all the childnodes.
    * @returns A completely new set of nodes without any macro definitions. 
    *          The caller is responsible to deallocate the memory.
    */
   const CAlfTuple* Expand() const;

   /** 
    * Generates a symbol table for the program, which can then be retrieved by
    * calling GetSymtab(). If a symbol table has already been created for the program,
    * it is first destroyed.
    */
   virtual void CreateSymbolTable();

   /**
    * Destroys the symbol table of the program, in case one has been created for the program
    */
   void DestroySymbolTable();

   /**
    * Returns the copy as a genereic node.
    */
   // CGenericNode * CopyAsGenericNode() const { return Copy(); };

   const std::string& GetSourceFileName() const {return *coord.source_file;}

   /**
    * @return The node containing macro definitions.
    */
   const CMacroDefList* GetDefs() const;

   /**
    * @return The node that specifies the least addressable unit size.
    */
   const CLauTuple* GetLau() const;

   /**
    * @return A std::string that defines the endianness, either "little_endian" and "big_endian" is returned.
    */
   const std::string GetEndian() const;

   /**
    * @return The node containing declarations of exported symbols.
    */
   const CExportsTuple* GetExports() const;

   /**
    * @return The node containing declarations of exported symbols.
    */
   CExportsTuple* GetExports();

   /**
    * @return true of the tuple contains exported lrefs or frefs
    */
   bool HasExportedLRefsOrFRefs() const;

   /**
    * @return The node containing declarations of imported symbols.
    */
   const CImportsTuple* GetImports() const;

   /**
    * @return The node containing declarations of imported symbols.
    */
   CImportsTuple* GetImports();

   /**
    * @return true of the tuple contains imported/undefined lrefs or frefs
    */
   bool HasImportedLRefsOrFRefs() const;

   /**
    * @return The node containing allocation of static data areas.
    */
   const CDeclList* GetDecls() const;

   /**
    * @return The node containing allocation of static data areas.
    */
   CDeclList* GetDecls();

   /**
    * @return The node containing initializations of static data areas.
    */
   const CInitList* GetInits() const;

   /**
    * @return The node containing initializations of static data areas.
    */
   CInitList* GetInits();

   /** 
    * @return true of the program contain volatile decalred data areas 
    */
   bool HasVolatileInits() const;

   /**
    * @return The node containing function declarations.
    */
   const CFuncList* GetFuncs() const;

   /**
    * @return The node containing function declarations.
    */
   CFuncList* GetFuncs();

   /** Returns a pointer to a new empty CSteensgaardPAOnALFProgram.
   */
   std::unique_ptr <CSteensgaardAnalysisBuilder> GetSteensgaardAnalysisBuilder();

   /**
    * Adds pointers to all ALF functions of this ALF program at the end of the
    * list pointed to by \a functions. The function objects are owned by
    * this ALF program, not by the caller.
    */
   void Functions(std::vector<CGenericFunction*> & functions) const;

   void AsText(CTextBlock *text_block, int indentation) const;

   /** 
    * Prints, but print only the functions in the cg. Useful when we
    * only want to print the functions that are called according to
    * call-graph. For example useful if the call graph has been reduced 
    * to a single connected graph, e.g. by ExtractCallGraphToUse()
    */
   void AsTextOnlyFuncsInCG(CTextBlock *text_block, int indentation, CCallGraph *cg) const;

   /**
    * Print a "filtered" version of the ALF program to @a o, which means that only declarations/definitions
    * (of frames, lrefs, functions, etc.) are included that are specified by @a filter
    */
   void PrintFiltered(std::ostream& o, int indentation, ASTFilter* filter) const;

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual CGenericNode::TYPE GetNodeType() const { return CGenericNode::TYPE_ALF_TUPLE; }

   /**
    * Checks if \a t is either the type of this node or the type of any of its superclasses in the alf tree.
    * @return true if the requested type matches this node type or any super class' else false.
    */
   virtual bool IsType(CGenericNode::TYPE t) const {return t == CGenericNode::TYPE_ALF_TUPLE || CGenericNode::IsType(t); }

   /**
    * Returns whether a symbol table exists for this program or not
    */
   bool HasSymbolTable() const {return _symtab != 0;}

   /**
    * Returns a pointer to a symbol table.
    * All identifiers in the program contain keys to be used to lookup the
    * declaration of the same identifier that is associated with the key in
    * the symbol table.
    * In ALF the node types fref, lref, label, and alloc are the ones
    * considered identifiers.
    * A "declaration" of a variable is considered to occur in a decls section
    * and, for globals, it might also be in the import section.
    * A code object "declaration" is represented by lrefs in the funcs and
    * import sections and in the lref of the optional label of statements.
   */
   const CSymTabBase * GetSymTab() const;

   /**
    * Links this alf tree with another.
    * @param other The other alf tree.
    * @param Unmangle Function to unmangle identifiers.
    * @pre The variable names are already "linked" i.e. names that are globally visible in one
    *    of the trees but is not exported does not clash with any global name in the other.
    *    Names at the global scope that are identical in both trees are assumed to be the same.
    *    NOTE! that alf generated by programs that mangles names need to be carefully prepared
    *    in order to fulfil this pre condition.
    * @post Any node that originally existed in other and that has been moved to this, does no
    *    longer exist in the other.
    */
   void Link(CAlfTuple &other, std::string (*Unmangle)(std::string));

   /**
    * Moves all imports, exports, decls, inits, and functions from @a other to this program. No checks
    * are made that the resulting program is correct.
    */
   void Merge(CAlfTuple& other);

   /**
    * Remove all functions whose names are found in @a funcs
    * @post The definition of the functions have been removed from the tree, including
    *       their entries in the exports section, if there are any
    */
   void RemoveNamedFunctions(const std::set<std::string>& funcs);

   /** 
    * To get a simple printout of the symbols imported and
    * exported. The printouts can be filtered, i.e. only those frefs
    * and lrefs included in the filter will then be printed.
    */
   void PrintImportsAsText(std::ostream * s, ASTFilter * filter = NULL) const;
   void PrintExportsAsText(std::ostream * s, ASTFilter * filter = NULL) const;

   /** 
    * To get annotation templates for imported data and functions. The 
    * printouts can be filtered, i.e. only those frefs and lrefs included 
    * in the filter will then be printed.
    */
   void PrintImportsAsAnnotTemplate(std::ostream * s, ASTFilter* filter=NULL) const;

   /** 
    * To get annotation templates for volatile declared data. The
    * printouts can be filtered, i.e. only those frefs included in the
    * filter will then be printed.
    */
   void PrintVolatilesAsAnnotTemplate(std::ostream * s, ASTFilter* filter=NULL) const;

   /** 
    * To get annotation templates for imported data and functions and
    * for volatiles. Calls the two above functions.
    */
   void PrintImportsAndVolatilesAsAnnotTemplate(std::ostream * s, ASTFilter* filter=NULL) const;

   /* To get annotation template for start function arguments. If no arguments exists
    * no annotation template will be generated 
    */
   void PrintStartFunctionArgumentsAsAnnotTemplate(const CGenericFunction * func, std::ostream * s) const;
   void PrintStartFunctionArgumentsAsAnnotTemplate(const CFuncTuple * func, std::ostream * s) const;

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CAlfTuple(const CAlfTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CAlfTuple& operator=(const CAlfTuple&);

   /**
   * Pointer to a node containing macro definitions.
   */
  CMacroDefList* defs;

   /**
    * Pointer to a node that specifies the least addressable unit size.
    */
   CLauTuple* lau;

   /**
    * String that defines endianness. Allowed values are "little_endian" and "big_endian"
    */
   std::string endian;

   /**
    * Pointer to a node containing declarations of exported symbols.
    */
   CExportsTuple* exports;

   /**
    * Pointer to a node containing declarations of imported symbols.
    */
   CImportsTuple* imports;

   /**
    * Pointer to a node containing allocation of static data areas.
    */
   CDeclList* decls;

   /**
    * Pointer to a node containing initializations of static data areas.
    */
   CInitList* inits;

   /**
    * Pointer to a node containing function declarations.
    */
   CFuncList* funcs;

   /**
    * A pointer to a symbol table, or NULL if there is no symbol table.
    */
   CSymTabBase *_symtab;
};

}

#endif

