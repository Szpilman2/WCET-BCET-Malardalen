// $Id $

#include "CJumpStmtTuple.h"
#include "CLabelTuple.h"
#include "AExpr.h"
#include "CString.h"
#include <cassert>

using namespace std;

namespace alf
{

CJumpStmtTuple::
CJumpStmtTuple(COORD coord, AExpr *p_label_expr, CString* p_leaving_n, CLabelTuple *lbl)
  :  CGenericStmt(CGenericStmt::GS_JUMP),
     AStmt(coord, CGenericStmt::GS_JUMP, lbl),
   label_expr(p_label_expr),
   leaving_n(p_leaving_n)
{
  assert(p_label_expr);
  assert(p_leaving_n);
  SetParent(label_expr);
  SetParent(leaving_n);
}

CJumpStmtTuple::
~CJumpStmtTuple()
{
   delete label_expr;
   delete leaving_n;
}

CJumpStmtTuple::CJumpStmtTuple(const CJumpStmtTuple& obj)
  : CGenericStmt(CGenericStmt::GS_JUMP),
    AStmt(obj.coord, CGenericStmt::GS_JUMP),
    label_expr(obj.label_expr ? dynamic_cast<AExpr*>(obj.label_expr->Copy()) : NULL),
    leaving_n(obj.leaving_n ? obj.leaving_n->Copy() : NULL)
{
  assert(obj.label_expr);
  assert(obj.leaving_n);
  SetParent(label_expr);
  SetParent(leaving_n);
}

CJumpStmtTuple*
CJumpStmtTuple::
Copy() const
{
   return new CJumpStmtTuple(*this);
}

CJumpStmtTuple&
CJumpStmtTuple::
operator=(const CJumpStmtTuple& obj)
{
   return *this;
}

void
CJumpStmtTuple::
OnPrint(ostream& stream, int indent) const
{
   if (!HasInternalGeneratedLabel()) {
      GetLabel()->PrintWithEndl(stream,indent);
   }
 
   PrintIndent(stream, indent);
   stream << "{ jump" << endl;
   ++indent;
   label_expr->PrintWithEndl(stream, indent);
   PrintIndent(stream, indent);
   stream << "leaving ";
   leaving_n->PrintWithEndl(stream, indent);
   --indent;
   PrintIndent(stream, indent); 
   stream << "}";
}

const AExpr*
CJumpStmtTuple::
GetLabelExpr() const
{
   return label_expr;
}

const CString*
CJumpStmtTuple::
GetLeavingN() const
{
   return leaving_n;
}
   
CGenericNode* 
CJumpStmtTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CJumpStmtTuple(GetCoord(), 
                             dynamic_cast<AExpr*> (label_expr->Expand(helper)),
                             dynamic_cast<CString*>(leaving_n->Expand(helper)),
                             ExpandLabel(helper));
}
   
}
