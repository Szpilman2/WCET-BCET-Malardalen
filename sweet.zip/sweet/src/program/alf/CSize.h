// $Id $

#ifndef ALF_CSIZE_H
#define ALF_CSIZE_H

#include "CGenericNode.h"
#include "AlfNodeVisitor.h"
#include "program_state/Size.h" 

namespace alf
{
class CString;

/**
 * A node specifying size (in bits) of a memory block.
 * It corresponds to the following rule in the ALF grammar:
 *
 * SIZE -> UNSIGNED_STRING
 *       | inf
 *
 * (inf means an infinite size.)
 */

class CSize : public CGenericNode
{
public:
   /**
    * Constructor to be used if size is infinite.
    * Sets the CGenericNode::TYPE to TYPE_SIZE_TUPLE, the IsInfinity() method will return true.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    */
   CSize(COORD coord);
   
   /**
    * Constructor to be used when the size value is numeric.
    * Sets the CGenericNode::TYPE to TYPE_SIZE_TUPLE, the IsInfinity() method will return false.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param value   A numeric value of a memory block's size as a std::string representation.
    */
   CSize(COORD coord, CString* value);
   
   /**
   * Constructor to be used when the size value is numeric.
   * Sets the CGenericNode::TYPE to TYPE_SIZE_TUPLE, the IsInfinity() method will return false.
   * The class is responsible to deallocate all the arguments.
   *
   * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
   * @param value   A numeric value of a memory block's size.
   */
   CSize(COORD coord, unsigned int value);

   /**
    * Constructor, initializes the node as an macrocall.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_SIZE_TUPLE
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord            The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param macro_call_tuple The macrocall node.
    */
   CSize(COORD coord, CMacroCallTuple* macro_call_tuple);

   /**
    * Constructor, initializes the node as an macro formal-argument-identifier string.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_SIZE_TUPLE
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord               The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param macro_formal_arg    The macro formal-argument-identifier string.
    */
   CSize(COORD coord, CMacroFormalArg* macro_formal_arg);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CSize();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   virtual CSize* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitSize(*this);}

   /**
    * Compare this node to the node @p other
    * @return true if they are equal, false otherwise
    */
   bool IsEqual(const CSize * other) const;

   /**
    * Checks if the size is infinite or not.
    * @return  True if size is infinite (created with no numeric value) otherwise false.
    */
   bool IsInfinity() const;

   /**
    * @return  The size.
    */
   Size GetSizeInBits() const;

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_SIZE; } 

  /** 
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_SIZE || CGenericNode::IsType(t); }

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CSize(const CSize&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CSize& operator=(const CSize&);

   /**
    * The size of the memory block.
    */
   Size value;

   /**
    * A flag telling if the size is infinite or not.
    */
   //bool is_inf;
};

std::ostream& operator << (std::ostream &o, CSize& a);

}

#endif

