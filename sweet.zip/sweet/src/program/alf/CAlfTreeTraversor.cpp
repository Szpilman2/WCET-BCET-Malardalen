#include "CAlfTreeTraversor.h"
#include "alf.h"
#include <typeinfo>

using namespace std;
namespace alf
{

CAlfTreeTraversor::
CAlfTreeTraversor()
{
}


CAlfTreeTraversor::
~CAlfTreeTraversor()
{
}

void
CAlfTreeTraversor::
RegisterNodeVisitor(INodeVisitor* visitor)
{
   node_visitors.push_back(visitor);
   enabled_visitor_map[visitor] = true;
}

bool
CAlfTreeTraversor::
BeginVisit(const CGenericNode* node)
{
   if (!node)
      return false;

   bool visitChildren = false;

   for (RegisteredNodeVisitorsList::iterator it = node_visitors.begin();
        it != node_visitors.end();
        it++)
   {
      INodeVisitor* visitor = *it;
      bool isEnabled = enabled_visitor_map[visitor];

      if (isEnabled)
      {
         if (!visitor->onBeginVisit(node))
         {
            enabled_visitor_map[visitor] = false;
            enable_visitor_after_node_map[node] = visitor;
         }
         else
         {
            visitChildren = true;
         }
      }
   }

   return visitChildren;
}

void
CAlfTreeTraversor::
EndVisit(const CGenericNode* node)
{
   if (!node)
      return;

   EnableVisitorAfterNodeMap::iterator it = enable_visitor_after_node_map.find(node);
   if (it != enable_visitor_after_node_map.end() && it->first == node)
   {
      enabled_visitor_map[it->second] = true;
      enable_visitor_after_node_map.erase(it);
   }

   for (RegisteredNodeVisitorsList::iterator it = node_visitors.begin();
        it != node_visitors.end();
        it++)
   {
      INodeVisitor* visitor = *it;
      bool isEnabled = enabled_visitor_map[visitor];

      if (isEnabled)
         visitor->onEndVisit(node);
   }
}

void
CAlfTreeTraversor::
BeginAndEndVisit(const CGenericNode* node)
{
   if (!node)
      return;

   for (RegisteredNodeVisitorsList::iterator it = node_visitors.begin();
        it != node_visitors.end();
        it++)
   {
      INodeVisitor* visitor = *it;
      visitor->onBeginVisit(node);
      visitor->onEndVisit(node);
   }
}

void
CAlfTreeTraversor::
BeginTraverse(const CGenericNode* node)
{
   if (node->IsType(CGenericNode::TYPE_STMT)) {
      ALFTREETRAVERSOR_VISIT_NODE(static_cast<const AStmt*>(node));
   } else if (node->IsType(CGenericNode::TYPE_EXPR)) {
      ALFTREETRAVERSOR_VISIT_NODE(dynamic_cast<const AExpr*>(node));
   } else if (node->IsType(CGenericNode::TYPE_EXPORTS_TUPLE)) {
      ALFTREETRAVERSOR_VISIT_NODE(static_cast<const CExportsTuple*>(node));
   } else if (node->IsType(CGenericNode::TYPE_DECL_LIST)) {
      ALFTREETRAVERSOR_VISIT_NODE(dynamic_cast<const CDeclList*>(node));
   } else if (node->IsType(CGenericNode::TYPE_FUNC_TUPLE)) {
      ALFTREETRAVERSOR_VISIT_NODE(static_cast<const CFuncTuple*>(node));
   } else if (node->IsType(CGenericNode::TYPE_FUNC_LIST)) {
      ALFTREETRAVERSOR_VISIT_NODE(dynamic_cast<const CFuncList*>(node));
   } else if (node->IsType(CGenericNode::TYPE_ALF_TUPLE)) {
      ALFTREETRAVERSOR_VISIT_NODE(static_cast<const CAlfTuple*>(node));
   } else {
      throw CException("Node type "+string(typeid(*node).name())+" can not start a tree traversal");
   }
}

template <typename NodeType> void CAlfTreeTraversor::ALFTREETRAVERSOR_VISIT_NODE(const NodeType * node)
{
   if (node != NULL)
   {
	   if (node->HasMacroCall())
      {
         const CMacroCallTuple* mc = node->GetMacroCall();
         if (BeginVisit(mc))
            Traverse(mc);
         EndVisit(mc);
      }
	   else if (node->HasMacroFormalArg())
      {
         const CMacroFormalArg* mfa = node->GetMacroFormalArg();
         if (BeginVisit(mfa))
            Traverse(mfa);
         EndVisit(mfa);
      }
	   else
      {
         if (BeginVisit(node))
            Traverse(node);
         EndVisit(node);
      }
   }
}

void
CAlfTreeTraversor::
Traverse(const CAlfTuple* alftree)
{
   ALFTREETRAVERSOR_VISIT_NODE(alftree->GetDefs());
   ALFTREETRAVERSOR_VISIT_NODE(alftree->GetLau());
   ALFTREETRAVERSOR_VISIT_NODE(alftree->GetImports());
   ALFTREETRAVERSOR_VISIT_NODE(alftree->GetExports());
   ALFTREETRAVERSOR_VISIT_NODE(alftree->GetDecls());
   ALFTREETRAVERSOR_VISIT_NODE(alftree->GetInits());
   ALFTREETRAVERSOR_VISIT_NODE(alftree->GetFuncs());
}

void
CAlfTreeTraversor::
Traverse(const CMacroDefList* macrodefs)
{
   for (CMacroDefList::const_list_iterator it = macrodefs->ConstIterator();
        it != macrodefs->InvalidIterator();
        it++)
   {
      const CMacroDefTuple* node = *it;
      ALFTREETRAVERSOR_VISIT_NODE(node);
   }
}

void
CAlfTreeTraversor::
Traverse(const CMacroDefTuple* macrodef)
{
   ALFTREETRAVERSOR_VISIT_NODE(macrodef->GetArgumentIdentifiers());
   switch (macrodef->GetDefinable()->GetNodeType())
   {
      case CGenericNode::TYPE_ALLOC_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE((CAllocTuple*)macrodef->GetDefinable());
         break;
      case CGenericNode::TYPE_STRING:
         ALFTREETRAVERSOR_VISIT_NODE((CString*)macrodef->GetDefinable());
         break;
      default:
      {
         stringstream ss;
         const CGenericNode *definable = macrodef->GetDefinable();
         ss << "Unknown definable type " << typeid(*definable).name() << " in CAlfTreeTraversor::Traverse(const CMacroDefTuple* macrodef)!";
         throw CException(ss.str());
      }
   }
}

void
CAlfTreeTraversor::
Traverse(const CMacroFormalArgList* formalargs)
{
   for (CMacroFormalArgList::const_list_iterator it = formalargs->ConstIterator();
        it != formalargs->InvalidIterator();
        it++)
   {
      const CMacroFormalArg* node = *it;
      ALFTREETRAVERSOR_VISIT_NODE(node);
   }
}

void
CAlfTreeTraversor::
Traverse(const CMacroFormalArg* formalarg)
{
   // Noting to do here!
}

void
CAlfTreeTraversor::
Traverse(const CMacroCallTuple* macrocall)
{
   // Noting to do here!
}

void
CAlfTreeTraversor::
Traverse(const CLauTuple* lau)
{
   // Noting to do here!
}

void
CAlfTreeTraversor::
Traverse(const CImportsTuple* imports)
{
   ALFTREETRAVERSOR_VISIT_NODE(imports->GetFRefList());
   ALFTREETRAVERSOR_VISIT_NODE(imports->GetLRefList());
}

void
CAlfTreeTraversor::
Traverse(const CExportsTuple* exports)
{
   ALFTREETRAVERSOR_VISIT_NODE(exports->GetFRefList());
   ALFTREETRAVERSOR_VISIT_NODE(exports->GetLRefList());

}

void
CAlfTreeTraversor::
Traverse(const CFRefList* frefs)
{
   for (CFRefList::const_list_iterator it = frefs->ConstIterator();
        it != frefs->InvalidIterator();
        it++)
   {
      const CFRefTuple* node = *it;
      ALFTREETRAVERSOR_VISIT_NODE(node);
   }
}

void
CAlfTreeTraversor::
Traverse(const CLRefList* lrefs)
{
   for (CLRefList::const_list_iterator it = lrefs->ConstIterator();
        it != lrefs->InvalidIterator();
        it++)
   {
      const CLRefTuple* node = *it;
      ALFTREETRAVERSOR_VISIT_NODE(node);
   }
}


void
CAlfTreeTraversor::
Traverse(const CFRefTuple* fref)
{
   ALFTREETRAVERSOR_VISIT_NODE(fref->GetSize());
   ALFTREETRAVERSOR_VISIT_NODE(fref->GetString());
}

void
CAlfTreeTraversor::
Traverse(const CLRefTuple* lref)
{
   ALFTREETRAVERSOR_VISIT_NODE(lref->GetSize());
   ALFTREETRAVERSOR_VISIT_NODE(lref->GetString());
}

void
CAlfTreeTraversor::
Traverse(const CSize* size)
{
   // Nothing to do here!
}

void
CAlfTreeTraversor::
Traverse(const CFuncList* functions)
{
   for (CFuncList::const_list_iterator it = functions->ConstIterator();
        it != functions->InvalidIterator();
        it++)
   {
      const CFuncTuple* node = *it;
      ALFTREETRAVERSOR_VISIT_NODE(node);
   }
}

void
CAlfTreeTraversor::
Traverse(const CFuncTuple* function)
{
   ALFTREETRAVERSOR_VISIT_NODE(function->GetLabel());
   ALFTREETRAVERSOR_VISIT_NODE(function->GetArgs());
   ALFTREETRAVERSOR_VISIT_NODE(function->GetScope());
}

void
CAlfTreeTraversor::
Traverse(const CArgDeclList* args)
{
   for (CArgDeclList::const_list_iterator it = args->ConstIterator();
        it != args->InvalidIterator();
        it++)
   {
      const CAllocTuple* node = *it;
      ALFTREETRAVERSOR_VISIT_NODE(node);
   }
}

void
CAlfTreeTraversor::
Traverse(const CScopeTuple* scope)
{
   ALFTREETRAVERSOR_VISIT_NODE(scope->GetLabel());
   ALFTREETRAVERSOR_VISIT_NODE(scope->GetDecls());
   ALFTREETRAVERSOR_VISIT_NODE(scope->GetInits());
   ALFTREETRAVERSOR_VISIT_NODE(scope->GetStmts());
}

void
CAlfTreeTraversor::
Traverse(const CStmtList* stmts)
{
   for (CStmtList::const_list_iterator it = stmts->ConstIterator();
        it != stmts->InvalidIterator();
        it++)
   {
      const AStmt* node = *it;
      ALFTREETRAVERSOR_VISIT_NODE(node);
   }
}

void
CAlfTreeTraversor::
Traverse(const CDeclList* decls)
{
   for (CDeclList::const_list_iterator it = decls->ConstIterator();
        it != decls->InvalidIterator();
        it++)
   {
      const CAllocTuple* node = *it;
      ALFTREETRAVERSOR_VISIT_NODE(node);
   }
}

void
CAlfTreeTraversor::
Traverse(const CAllocTuple* alloc)
{
   ALFTREETRAVERSOR_VISIT_NODE(alloc->GetBitstringSize());
   ALFTREETRAVERSOR_VISIT_NODE(alloc->GetFrameSize());
   ALFTREETRAVERSOR_VISIT_NODE(alloc->GetFrefId());
}

void
CAlfTreeTraversor::
Traverse(const CInitList* inits)
{
   for (CInitList::const_list_iterator it = inits->ConstIterator();
        it != inits->InvalidIterator();
        it++)
   {
      const CInitTuple* node = *it;
      ALFTREETRAVERSOR_VISIT_NODE(node);
   }
}

void
CAlfTreeTraversor::
Traverse(const CInitTuple* init)
{
   ALFTREETRAVERSOR_VISIT_NODE(init->GetRef());
   ALFTREETRAVERSOR_VISIT_NODE(init->GetVal());
}

void
CAlfTreeTraversor::
Traverse(const CRefTuple* ref)
{
   //ALFTREETRAVERSOR_VISIT_NODE(ref->GetFrefId());
   ALFTREETRAVERSOR_VISIT_NODE(ref->GetOffset());
   ALFTREETRAVERSOR_VISIT_NODE(ref->GetFrefId());
}

void
CAlfTreeTraversor::
Traverse(const AVal* val)
{
   switch (val->GetNodeType())
   {
      case CGenericNode::TYPE_CONSTREPEAT_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CConstRepeatTuple const*>(val));
         break;
      case CGenericNode::TYPE_CHARSTRING_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CCharStringTuple const*>(val));
         break;
      case CGenericNode::TYPE_CONST_LIST:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CConstList const*>(val));
         break;
      case CGenericNode::TYPE_FLOAT_LIST:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CFloatListTuple const*>(val));
         break;
      case CGenericNode::TYPE_INT_LIST:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CIntListTuple const*>(val));
         break;
      case CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CUndefinedExprTuple const*>(val));
         break;
      case CGenericNode::TYPE_LREF_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CLRefTuple const*>(val));
         break;
      case CGenericNode::TYPE_ADDR_EXPR_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CAddrTuple const*>(val));
         break;
      case CGenericNode::TYPE_FREF_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CFRefTuple const*>(val));
         break;
      case CGenericNode::TYPE_LABEL_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CLabelTuple const*>(val));
         break;
      case CGenericNode::TYPE_FLOATVAL_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CFloatValTuple const*>(val));
         break;
      case CGenericNode::TYPE_INTVAL_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CIntNumValTuple const*>(val));
         break;
      case CGenericNode::TYPE_UNKNOWN_VAL:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CUnknownVal const*>(val));
         break;
      case CGenericNode::TYPE_UNKNOWN_CONST:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CUnknownConst const*>(val));
         break;
      default:
         throw CException("Not implemented CAlfTreeTraversor::Traverse(const AVal* val) " + string(typeid(*val).name()));
   }
}

// CString???

void
CAlfTreeTraversor::
Traverse(const CConstRepeatTuple* constrepeat)
{
   ALFTREETRAVERSOR_VISIT_NODE(constrepeat->GetConst());
   //ALFTREETRAVERSOR_VISIT_NODE(constrepeat->GetRepeats());
}

void
CAlfTreeTraversor::
Traverse(const CCharStringTuple* stringtuple)
{
   // No children
}

void
CAlfTreeTraversor::
Traverse(const CConstList* const_list)
{
   for (CConstList::const_list_iterator it = const_list->ConstIterator();
        it != const_list->InvalidIterator();
        it++)
   {
      const AConst* c= *it;
      ALFTREETRAVERSOR_VISIT_NODE(c);
   }
}

void
CAlfTreeTraversor::
Traverse(const CFloatListTuple* float_list)
{
   for (CFloatListTuple::const_list_iterator it = float_list->ConstIterator();
        it != float_list->InvalidIterator();
        it++)
   {
      const AConst* c= *it;
      ALFTREETRAVERSOR_VISIT_NODE(c);
   }
}

void
CAlfTreeTraversor::
Traverse(const CIntListTuple* int_list)
{
   for (CIntListTuple::const_list_iterator it = int_list->ConstIterator();
        it != int_list->InvalidIterator();
        it++)
   {
      const AConst* c= *it;
      ALFTREETRAVERSOR_VISIT_NODE(c);
   }
}

void
CAlfTreeTraversor::
Traverse(const CUnknownConst* constval)
{
}

void
CAlfTreeTraversor::
Traverse(const CUnknownVal* numval)
{
}

void
CAlfTreeTraversor::
Traverse(const CIntNumValTuple* numval)
{
   ALFTREETRAVERSOR_VISIT_NODE(numval->GetSize());
}

void
CAlfTreeTraversor::
Traverse(const CDynAllocTuple* dyn_alloc)
{
   ALFTREETRAVERSOR_VISIT_NODE(dyn_alloc->GetSize());
   ALFTREETRAVERSOR_VISIT_NODE(dyn_alloc->GetFref());
   ALFTREETRAVERSOR_VISIT_NODE(dyn_alloc->GetNumExpr());
}

void
CAlfTreeTraversor::
Traverse(const CFloatValTuple* floatval)
{
//    ALFTREETRAVERSOR_VISIT_NODE(floatval->GetFracSize());
//    ALFTREETRAVERSOR_VISIT_NODE(floatval->GetExpSize());
}

void
CAlfTreeTraversor::
Traverse(const AStmt* statement)
{
   Traverse((CLabelTuple*)statement->GetLabel());
   switch (statement->GetNodeType())
   {
      case CGenericNode::TYPE_CALL_STMT_TUPLE:
         Traverse((CCallStmtTuple*)statement);
         break;
      case CGenericNode::TYPE_FREE_STMT_TUPLE:
         Traverse((CFreeStmtTuple*)statement);
         break;
      case CGenericNode::TYPE_JUMP_STMT_TUPLE:
         Traverse((CJumpStmtTuple*)statement);
         break;
      case CGenericNode::TYPE_NULL_STMT_TUPLE:
         Traverse((CNullStmtTuple*)statement);
         break;
      case CGenericNode::TYPE_RETURN_STMT_TUPLE:
         Traverse((CReturnStmtTuple*)statement);
         break;
      case CGenericNode::TYPE_SCOPE_TUPLE:
         Traverse((CScopeTuple*)statement);
         break;
      case CGenericNode::TYPE_STORE_STMT_TUPLE:
         Traverse((CStoreStmtTuple*)statement);
         break;
      case CGenericNode::TYPE_SWITCH_STMT_TUPLE:
         Traverse((CSwitchStmtTuple*)statement);
         break;
      default:
         throw CException("Unknown statement nodetype in CAlfTreeTraversor::Traverse(const AStmt* statement)!");
   };
}

void
CAlfTreeTraversor::
Traverse(const CNullStmtTuple* stmt)
{
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetLabel());
}

void
CAlfTreeTraversor::
Traverse(const CCallStmtTuple* stmt)
{
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetLabelExpr());
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetExprs());
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetAddrExprs());
}

void
CAlfTreeTraversor::
Traverse(const CFreeStmtTuple* stmt)
{
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetLabel());
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetFrefExpr());
}

void
CAlfTreeTraversor::
Traverse(const CStoreStmtTuple* stmt)
{
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetLabel());
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetAddrExprs());
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetExprs());
}

void
CAlfTreeTraversor::
Traverse(const CSwitchStmtTuple* stmt)
{
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetLabel());
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetNumExpr());
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetTargets());
}

void
CAlfTreeTraversor::
Traverse(const CJumpStmtTuple* stmt)
{
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetLabel());
   //ALFTREETRAVERSOR_VISIT_NODE(stmt->GetLeavingN()());
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetLabelExpr());
}

void
CAlfTreeTraversor::
Traverse(const CReturnStmtTuple* stmt)
{
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetLabel());
   ALFTREETRAVERSOR_VISIT_NODE(stmt->GetExprs());
}

void
CAlfTreeTraversor::
Traverse(const CLabelTuple* label)
{
   ALFTREETRAVERSOR_VISIT_NODE(label->GetLRef());
   ALFTREETRAVERSOR_VISIT_NODE(label->GetSize());
}

void
CAlfTreeTraversor::
Traverse(const AExpr* expr)
{
   switch (expr->GetNodeType())
   {
      case CGenericNode::TYPE_COMPADDR_EXPR_TUPLE:
         Traverse((CCompAddrTuple*)expr);
         break;
      case CGenericNode::TYPE_COMPLABEL_EXPR_TUPLE:
         Traverse((CCompLabelTuple*)expr);
         break;
      case CGenericNode::TYPE_LOAD_EXPR_TUPLE:
         Traverse((CLoadExprTuple*)expr);
         break;
      case CGenericNode::TYPE_OP_EXPR_TUPLE:
         Traverse((COpNumExprTuple*)expr);
         break;
      case CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE:
         Traverse((CUndefinedExprTuple*)expr);
         break;
      case CGenericNode::TYPE_ADDR_EXPR_TUPLE:
         Traverse((CAddrTuple*)expr);
         break;
      case CGenericNode::TYPE_UNKNOWN_EXPR:
         Traverse((CUnknownExpr*)expr);
         break;
      case CGenericNode::TYPE_INTVAL_TUPLE:
         Traverse((CIntNumValTuple*)expr);
         break;
      case CGenericNode::TYPE_FLOATVAL_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE((CFloatValTuple*)expr);
         break;
      case CGenericNode::TYPE_LABEL_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE((CLabelTuple*)expr);
         break;
      case CGenericNode::TYPE_LREF_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE(static_cast<CLRefTuple const*>(expr));
         break;
      case CGenericNode::TYPE_FREF_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE((CFRefTuple*)expr);
         break;
      case CGenericNode::TYPE_DYNALLOC_EXPR_TUPLE:
         ALFTREETRAVERSOR_VISIT_NODE((CDynAllocTuple*)expr);
         break;
      default:
         throw CException("Unknown expression nodetype in CAlfTreeTraversor::Traverse(const AExpr* expr)!");
   }
}

void
CAlfTreeTraversor::
Traverse(const CCompAddrTuple* expr)
{
   ALFTREETRAVERSOR_VISIT_NODE(expr->GetSize());
   ALFTREETRAVERSOR_VISIT_NODE(expr->GetFRefExpr());
   ALFTREETRAVERSOR_VISIT_NODE(expr->GetNumExpr());
}

void
CAlfTreeTraversor::
Traverse(const CCompLabelTuple* expr)
{
   ALFTREETRAVERSOR_VISIT_NODE(expr->GetSize());
   ALFTREETRAVERSOR_VISIT_NODE(expr->GetLRefExpr());
   ALFTREETRAVERSOR_VISIT_NODE(expr->GetNumExpr());
}

void
CAlfTreeTraversor::
Traverse(const CLoadExprTuple* expr)
{
   ALFTREETRAVERSOR_VISIT_NODE(expr->GetSize());
   ALFTREETRAVERSOR_VISIT_NODE(expr->GetAddrExpr());
}

void
CAlfTreeTraversor::
Traverse(const CAddrTuple* addr)
{
   ALFTREETRAVERSOR_VISIT_NODE(addr->GetSize());
   ALFTREETRAVERSOR_VISIT_NODE(addr->GetFref());
   ALFTREETRAVERSOR_VISIT_NODE(addr->GetOffset());
}

void
CAlfTreeTraversor::
Traverse(const COpNumExprTuple* expr)
{
   // Using only traverse since the lists doesn't inherit from CGenericNode
   ALFTREETRAVERSOR_VISIT_NODE(expr->GetSizes());
   ALFTREETRAVERSOR_VISIT_NODE(expr->GetNumExprs());
}

void
CAlfTreeTraversor::
Traverse(const CSizeList* sizes)
{
   for (CSizeList::const_list_iterator it = sizes->ConstIterator();
        it != sizes->InvalidIterator();
        it++)
   {
      const CSize* size = *it;
      ALFTREETRAVERSOR_VISIT_NODE(size);
   }
}

void
CAlfTreeTraversor::
Traverse(const CExprList* exprs)
{
   for (CExprList::const_list_iterator it = exprs->ConstIterator();
        it != exprs->InvalidIterator();
        it++)
   {
      const AExpr* expr = *it;
      ALFTREETRAVERSOR_VISIT_NODE(expr);
   }
}

void
CAlfTreeTraversor::
Traverse(const CUndefinedExprTuple* expr)
{
   ALFTREETRAVERSOR_VISIT_NODE(expr->GetSize());
}

void
CAlfTreeTraversor::
Traverse(const CUnknownExpr* expr)
{
   throw CException("Not implemented CAlfTreeTraversor::Traverse(const CUnknownExpr* expr)!");
}

void
CAlfTreeTraversor::
Traverse(const CTargetList* targets)
{
   for (CTargetList::const_list_iterator it = targets->ConstIterator();
        it != targets->InvalidIterator();
        it++)
   {
      const ATarget* target = *it;
      ALFTREETRAVERSOR_VISIT_NODE(target);
   }
}
   
void
CAlfTreeTraversor::
Traverse(const ATarget* target)
{
   switch (target->GetNodeType())   
   {
      case CGenericNode::TYPE_TARGET_TUPLE:
         Traverse((CTargetTuple*)target);
         break;
      case CGenericNode::TYPE_DEFAULT_TUPLE:
         Traverse((CDefaultTuple*)target);
         break;
      default:
         throw CException("Not implemented CAlfTreeTraversor::Traverse(const ATarget* target)");
   }
}
   
void
CAlfTreeTraversor::
Traverse(const CTargetTuple* target)
{
   ALFTREETRAVERSOR_VISIT_NODE(target->GetIntNumVal());
   ALFTREETRAVERSOR_VISIT_NODE(target->GetLabelExpr());
}

void
CAlfTreeTraversor::
Traverse(const CDefaultTuple* target)
{
   ALFTREETRAVERSOR_VISIT_NODE(target->GetLabelExpr());
}
   
void
CAlfTreeTraversor::
Traverse(const CString* str)
{
   
}
   
}
