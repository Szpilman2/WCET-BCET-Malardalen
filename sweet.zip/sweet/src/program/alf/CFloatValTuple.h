// $Id $

#ifndef ALF_CFLOATVALTUPLE_H
#define ALF_CFLOATVALTUPLE_H

#include "ANumVal.h"
#include "AlfNodeVisitor.h"

namespace alf
{
class CSize;
class CFloatNumber;
class CString;

/**
 * A floating-point number value.
 *
 * The two sizes are for floating-point exponent and fraction, respectively.
 * For IEEE single precision 32-bit floating point numbers the values of these
 * are 8 and 23, respectively, and for double precision 64-bit they are 11 and
 * 52. Since there is also a sign bit, the total size is exp + frac + 1 where
 * exp and frac are the two specified sizes.
 *
 * It represents the following rule in the ALF-grammar:
 * NUM_VAL -> { float_val SIZE SIZE FLOAT_VAL }
 *
 * @see CSize, ANumVal
 */
class CFloatValTuple : public ANumVal
{
public:
  /**
    * Constructor, creates a list node from a vector of frame references.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_FLOATVAL_TUPLE.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord        The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param exp_size     The size of the exponent.
    * @param frac_size    The size of the fraction.
    * @param value        The value contained in a string.
    */
   CFloatValTuple(COORD coord, CSize* exp_size, CSize* frac_size, CString* value);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CFloatValTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   virtual CFloatValTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitFloatValTuple(*this);}

   /**
    * @return The parsed value as a float number.
    */
   CFloatNumber* GetFloatValue();

   /**
    * @return The parsed value as a float number.
    */
   const CFloatNumber * GetFloatValue() const;

   /**
    * @return The size of the exponent.
    */
   CSize* GetExpSize() const;

   /**
    * @return The size of the fraction.
    */
   CSize* GetFracSize() const;

   /**
    * @return  The type code identifying a float val
    */
   virtual TYPE GetNodeType() const { return TYPE_FLOATVAL_TUPLE; }

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CFloatValTuple(const CFloatValTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CFloatValTuple& operator=(const CFloatValTuple&);

   /**
    * The exponent size.
    */
   CSize* exp_size;

   /**
    * The fraction size;
    */
   CSize* frac_size;

   /**
    * The value parsed into a number.
    */
   CFloatNumber* float_val;
};

}

#endif

