// $Id $

#ifndef ALF_CMACROFORMALARGLIST_H
#define ALF_CMACROFORMALARGLIST_H

#include "CListNode.h"
#include "AlfNodeVisitor.h"
#include <cassert>

namespace alf
{
class CMacroFormalArg;

/**
 * A node containing a list of formal arguments.
 * It doesn't correspond to any rule in the ALF grammar, it is just used as a helper class.
 * @see CMacroFormalArg, CListNode
 */
class CMacroFormalArgList : public CListNode<CMacroFormalArg>
{
public:
  /**
   * Constructor, creates a list node from a vector of strings.
   * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_MACRO_FORMAL_ARG_LIST.
   * The class is responsible to deallocate all the arguments.
   *
   * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
   * @param list    A vector of macro-formal-arguments.
   */
  CMacroFormalArgList(const COORD& coord, const std::vector<CMacroFormalArg*>& list=std::vector<CMacroFormalArg*>());
  
  /**
   * Deallocates all the memory that the node is using.
   */
  virtual ~CMacroFormalArgList();
  
  /**
   * Performs a deep copy of the node.
   * @returns A completely new set of nodes. The caller is responsible to
   *          deallocate the memory.
   */
  virtual CMacroFormalArgList* Copy() { assert(0); return NULL; };

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitMacroFormalArgList(*this);}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_MACRO_FORMAL_ARG_LIST;} 

  /** 
    * Checks if the number has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_MACRO_FORMAL_ARG_LIST || CListNode<CMacroFormalArg>::IsType(t); }

   virtual CMacroFormalArgList* Copy() const;
   
   bool GetIndex(std::string id, unsigned* index) const;
};

}

#endif

