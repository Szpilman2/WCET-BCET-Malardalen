/* $Id: CCompAddrTuple.cpp 5947 2013-12-03 20:44:28Z lkg02 $ */

#include "CCompAddrTuple.h"
#include "CAddrTuple.h"
#include "CFRefTuple.h"
#include "CIntNumValTuple.h"
#include "CSize.h"
#include <typeinfo>

using namespace alf;
using namespace std;

CCompAddrTuple::
CCompAddrTuple(COORD coord, CSize* size, AExpr* fref, AExpr* num)
:  CGenericNode(coord),
   AExpr(coord, size),
   fref_expr(fref),
   num_expr(num)
{
   SetParent(fref_expr);
   SetParent(num_expr);
}

CCompAddrTuple::
~CCompAddrTuple()
{
   delete fref_expr;
   delete num_expr;
}

CCompAddrTuple::
CCompAddrTuple(const CCompAddrTuple& obj)
:  CGenericNode(obj.coord),
   AExpr(obj.coord, (CSize*)obj.size->Copy()),
   fref_expr(dynamic_cast<AExpr*>(obj.fref_expr->Copy())),
   num_expr(dynamic_cast<AExpr*>(obj.num_expr->Copy()))
{
   SetParent(fref_expr);
   SetParent(num_expr);
}

CCompAddrTuple*
CCompAddrTuple::
Copy() const
{
   return new CCompAddrTuple(*this);
}

CCompAddrTuple&
CCompAddrTuple::
operator=(const CCompAddrTuple& obj)
{
   return *this;
}

void
CCompAddrTuple::
OnPrint(ostream& stream, int indent) const
{
   stream << Indent(indent) << "{ addr ";
   size->PrintWithEndl(stream, 0);
   ++indent;
   fref_expr->PrintWithEndl(stream, indent);
   num_expr->PrintWithEndl(stream, indent);
   --indent;
   stream << Indent(indent) << "}";
}

const AExpr *
CCompAddrTuple::
GetFRefExpr() const
{
   return fref_expr;
}

const AExpr *
CCompAddrTuple::
GetNumExpr() const
{
   return num_expr;
}

CGenericNode* 
CCompAddrTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
    CGenericNode* expanded_fref_expr = fref_expr->Expand(helper);
    CGenericNode* expanded_num_expr = num_expr->Expand(helper);
    CSize* expanded_size = dynamic_cast<CSize*> (GetSize()->Expand(helper));
    
    // The parser may have thougt that this was a computed label, but the expanded nodes
    // can be used in a static label, so create that instead.
    if (expanded_fref_expr->IsType(CGenericNode::TYPE_FREF_TUPLE) && 
        expanded_num_expr->IsType(CGenericNode::TYPE_INTVAL_TUPLE))
        return new CAddrTuple(GetCoord(),
                              expanded_size,
                              dynamic_cast<CFRefTuple*>(expanded_fref_expr),
                              dynamic_cast<CIntNumValTuple*>(expanded_num_expr));
    else
        return new CCompAddrTuple(GetCoord(),
                             expanded_size,
                             dynamic_cast<AExpr*> (expanded_fref_expr),
                             dynamic_cast<AExpr*> (expanded_num_expr));
}
