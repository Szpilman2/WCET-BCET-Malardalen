/* $Id: ATarget.cpp 950 2009-09-01 10:52:28Z jjn08 $ */

#include "ATarget.h"
#include "AExpr.h"

using namespace alf;

ATarget::
ATarget(COORD coord, AExpr *p_label_expr)
:  CGenericNode(coord),
   label_expr(p_label_expr)
{
   SetParent(label_expr);
}

ATarget::
~ATarget()
{
   delete label_expr;
}

ATarget::ATarget(const ATarget& obj)
:  CGenericNode(obj.coord),
   label_expr(dynamic_cast<AExpr*>(obj.label_expr->Copy()))
{
   SetParent(label_expr);
}

ATarget&
ATarget::
operator=(const ATarget& obj)
{
   return *this;
}

const AExpr *
ATarget::
GetLabelExpr()
const
{
   return label_expr;
}

