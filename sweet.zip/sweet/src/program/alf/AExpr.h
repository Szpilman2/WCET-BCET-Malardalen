// $Id $

#ifndef ALF_AEXPR_H
#define ALF_AEXPR_H

#include "CGenericNode.h"
#include "program_state/Size.h"

namespace alf
{ 
class CSize;

/**
 * Abstract super class of all nodes that can be considered expressions.
 * It represents the following rules in the ALF grammar:
 * 
 * EXPR -> LREF_EXPR | LABEL_EXPR | FREF_EXPR | ADDR_EXPR | NUM_EXPR
 *
 * Since the ALF grammar has some ambiguities, we decided to not make any difference
 * between different types of expressions, and the rule currently looks like this:
 * EXPR ->    LREF
 *          | LABEL
 *          | { load SIZE EXPR }
 *          | { undefined SIZE }
 *          | FREF
 *          | { dyn_alloc SIZE FREF EXPR }
 *          | { addr SIZE EXPR EXPR}
 *          | NUM_VAL
 *          | { OP SIZE* EXPR* }
 *
 * The nodes will have to make sure they get a valid type of EXPR as input which the
 * parser doesn't care about.
 *
 * The class doesn't overload the CGenericNode::Copy method because of multiple inheritance
 * conflicts. Using that method is still fine, you just have to explicitly cast to AExpr.
 *
 * @see CLoadExprTuple, CUndefinedExprTuple, CLabelTuple, CCompLabelTuple, CFRefTuple, 
        CDynAllocTuple, CAddrTuple, CCompAddrTuple, ANumVal, COpNumExprTuple, CGenericNode.
 */
class AExpr : public virtual CGenericNode
{
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming size node.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord     The line and column numbers in the parsed file where the rule creating this node was found.
    * @param size      All expressions have a size.
    */
   AExpr(COORD coord, CSize *size);
   
   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~AExpr();

   /**
    * @return The size node. Note that COpNumExprTuple may not have a 
    *         size node and NULL is then returned.
    */
   CSize * GetSize() const;

   /**
     * Return the size of the result when evaluating this expression. In contrast to @a GetSize(), 
     * it returns the size for all types of expressions, including COpNumExprTuple (where it is overloaded).
     */
   virtual Size GetSizeOfEvaluatedExpr() const;

   /**
    * Checks if \a t is either the type of this node or the type of any of its superclasses in the alf tree.
    * @return true if the requested type matches this node type or any super class' else false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_EXPR || CGenericNode::IsType(t); }

protected:
   /**
    * All expressions have a size.
    * (Except COpNumExprTuple that has a possibly empty list of sizes.)
    */
   CSize* size;
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   AExpr(const AExpr&);
   
   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   AExpr& operator=(const AExpr&);
};

}

#endif

