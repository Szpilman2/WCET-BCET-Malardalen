// $Id $

#include "CSize.h"
#include "CString.h"
#include "CAlfTreeExpandingHelper.h"
#include <sstream>

using namespace std;
namespace alf
{

CSize::
CSize(COORD coord)
:  CGenericNode(coord),
   value(Size::Infinity())
{
}

CSize::
CSize(COORD coord, unsigned int p_value)
:  CGenericNode(coord),
   value(p_value)
{
}

CSize::
CSize(COORD coord, CString* p_value)
:  CGenericNode(coord)
{
   // Convert string representation to an actual number.
   stringstream ss;
   ss << p_value->Get();
   ss >> value;
   
   delete p_value;
}

CSize::
CSize(COORD coord, CMacroFormalArg* macro_formal_arg)
:  CGenericNode(coord, macro_formal_arg)
{

}

CSize::
CSize(COORD coord, CMacroCallTuple* macro_call_tuple)
:  CGenericNode(coord, macro_call_tuple)
{

}

CSize::
~CSize()
{
}

CSize::
CSize(const CSize& obj)
:  CGenericNode(obj.coord),
   value(obj.value)
{
}

CSize*
CSize::
Copy() const
{
   return new CSize(*this);
}

CSize&
CSize::
operator=(const CSize& obj)
{
   return *this;
}

void
CSize::
OnPrint(ostream& stream, int indent) const
{
   PrintIndent(stream, indent);

   if (IsInfinity())
      stream << "inf";
   else
      stream << value;
}

bool CSize::IsEqual(const CSize * other) const
{
   return (this->IsInfinity() && other->IsInfinity()) || this->GetSizeInBits() == other->GetSizeInBits();
}

bool
CSize::
IsInfinity() const
{
   return value.IsInfinity();
}

Size
CSize::
GetSizeInBits() const
{
   return value;
}

// -------------------------------------------------------
// Alternative printing function
// -------------------------------------------------------
ostream &operator << (ostream &o, CSize &a)
{
   a.Print(o, 0);
   return o;
}
   
CGenericNode* 
CSize::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   if (IsInfinity())
      return new CSize(GetCoord());
   else
      return new CSize(GetCoord(), (unsigned)value.AsBaseIntType());
}

}
