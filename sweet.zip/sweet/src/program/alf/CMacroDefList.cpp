// $Id $

#include "CMacroDefTuple.h"
#include "CMacroDefList.h"
#include "CListNode.inl"

using namespace std;
namespace alf
{

CMacroDefList::
CMacroDefList(const COORD& coord, const vector<CMacroDefTuple*>& p_list)
:  CGenericNode(coord),
   CListNode<CMacroDefTuple>(coord, "macro_defs", p_list)
{
}

CMacroDefList::
~CMacroDefList()
{
}

CMacroDefList*
CMacroDefList::
Copy() const
{
   return new CMacroDefList(*this);
}

template class CListNode<CMacroDefTuple>;

}
