// $Id $

#ifndef ALF_CCONSTLIST_H
#define ALF_CCONSTLIST_H

#include "CListNode.h"
#include "AVal.h"
#include "AlfNodeVisitor.h"

namespace alf
{
class AConst;

/**
 * Represents a list of constants of the VAL rule in the ALF grammar:
 * VAL -> { const_list CONST+ }
 *
 * @see AVal, AConst
 */
class CConstList : public CListNode<AConst>, public AVal
{
public:
   /**
    * Constructor, creates a list node from a vector of frame references.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_CONST_LIST.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param list  A vector of constants.
    */
   CConstList(COORD coord, const std::vector<AConst*>& list);
   
   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CConstList();
   
   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to 
    *          deallocate the memory.
    */
   CConstList* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitConstList(*this);}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_CONST_LIST; }

   /** 
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_CONST_LIST || CListNode<AConst>::IsType(t) || AVal::IsType(t); }
protected:
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
};

}
#endif

