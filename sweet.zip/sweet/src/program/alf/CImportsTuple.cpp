/* $Id: CImportsTuple.cpp 5947 2013-12-03 20:44:28Z lkg02 $ */

#include "CImportsTuple.h"
#include "CExportsTuple.h"
#include "CLRefList.h"
#include "CFRefList.h"
#include "CFRefTuple.h"
#include "CLRefTuple.h"
#include "ASTFilter.h"

using namespace alf;
using namespace std;

CImportsTuple::
CImportsTuple(COORD coord, CFRefList* p_frefs, CLRefList* p_lrefs)
:  CGenericNode(coord),
   frefs(p_frefs),
   lrefs(p_lrefs)
{
   SetParent(frefs);
   SetParent(lrefs);
}

CImportsTuple::
~CImportsTuple()
{
   delete lrefs;
   delete frefs;
}

CImportsTuple::
CImportsTuple(const CImportsTuple& obj)
:  CGenericNode(obj.coord),
   frefs(obj.frefs->Copy()),
   lrefs(obj.lrefs->Copy())
{
   SetParent(frefs);
   SetParent(lrefs);
}

CImportsTuple*
CImportsTuple::
Copy() const
{
   return new CImportsTuple(*this);
}

CImportsTuple&
CImportsTuple::
operator=(const CImportsTuple& obj)
{
   return *this;
}

void
CImportsTuple::
OnPrint(ostream& stream, int indent) const
{
   PrintIndent(stream, indent);
   stream << "{ imports" << endl;

   frefs->PrintWithEndl(stream, indent+1);
   lrefs->PrintWithEndl(stream, indent+1);

   PrintIndent(stream, indent);
   stream << "}";
}


const CFRefList*
CImportsTuple::
GetFRefList() const
{
   return frefs;
}

CFRefList* CImportsTuple::GetFRefList()
{
   return frefs;
}

const CLRefList*
CImportsTuple::
GetLRefList() const
{
   return lrefs;
}

CLRefList* CImportsTuple::GetLRefList()
{
   return lrefs;
}

void
CImportsTuple::
LinkWithFilter(CImportsTuple &other, const CExportsTuple &exports_tuple, std::string (*Unmangle)(std::string))
{
   frefs->LinkWithFilter(*other.frefs, *exports_tuple.GetFRefList(), Unmangle);
   lrefs->LinkWithFilter(*other.lrefs, *exports_tuple.GetLRefList(), Unmangle);
}

void CImportsTuple::Merge(CImportsTuple& other)
{
   GetFRefList()->Merge(*other.GetFRefList());
   GetLRefList()->Merge(*other.GetLRefList());
}

void CImportsTuple::PrintFiltered(std::ostream& o, int indentation, ASTFilter* filter) const
{
   o << Indent(indentation) << "{ imports" << endl;

   // frefs
   {
      o << Indent(indentation + 1) << "{ frefs" << endl;
      for (CFRefList::const_list_iterator f = frefs->ConstIterator(); f != frefs->InvalidIterator(); ++f)
      {
         if (filter->IncludeFRefTuple(**f))
            (*f)->PrintWithEndl(o, indentation + 2);
      }
      o << Indent(indentation + 1) << '}' << endl;
   }

   // lrefs
   {
      o << Indent(indentation + 1) << "{ lrefs" << endl;
      for (CLRefList::const_list_iterator l = lrefs->ConstIterator(); l != lrefs->InvalidIterator(); ++l)
      {
         if (filter->IncludeLRefTuple(**l))
            (*l)->PrintWithEndl(o, indentation + 2);
      }
      o << Indent(indentation + 1) << '}' << endl;
   }

   o << Indent(indentation) << '}';
}

CGenericNode* 
CImportsTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CImportsTuple(GetCoord(),
                            dynamic_cast<CFRefList*>(frefs->Expand(helper)),
                            dynamic_cast<CLRefList*>(lrefs->Expand(helper)));
}

