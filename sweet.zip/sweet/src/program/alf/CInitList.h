// $Id $

#ifndef ALF_CINITLIST_H
#define ALF_CINITLIST_H

#include "CListNode.h"
#include "AlfNodeVisitor.h"

namespace alf
{
class CInitTuple;
class ASTFilter;

/**
 * A node containing a list of static data area initiations.
 * This class inherits from CListNode, and corresponds to the following rule in the ALF grammar:
 * INITS -> { inits INIT*}
 *
 * @see CInitTuple
 */

class CInitList : public CListNode<CInitTuple>
{
public:
   /**
    * Constructor, creates a list node from a vector of frame references.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_INIT_LIST
    * The class is responsible to deallocate all the arguments.
    
    * @param coord The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param list  A vector of initiations (of static data areas)
    */
   CInitList(const COORD& coord, const std::vector<CInitTuple*>& list=std::vector<CInitTuple*>());
   
   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CInitList();
   
   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to 
    *          deallocate the memory.
    */
   virtual CInitList* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitInitList(*this);}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_INIT_LIST; }

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_INIT_LIST || CListNode<CInitTuple>::IsType(t); }

   /**
    * Prints to @a o the declarations of this list for which filter->IncludeInitTuple() returns @c true
    */
   void PrintFiltered(std::ostream& o, int indentation, ASTFilter* filter) const;

   /**
    * To get the number of volatile items in the list. Can be filtered.
    */
   unsigned int GetNrOfVolatileInits(ASTFilter *filter = NULL) const;
   unsigned int GetNrOfAddrVolatileInits(ASTFilter *filter = NULL) const;

protected:
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
};

}

#endif

