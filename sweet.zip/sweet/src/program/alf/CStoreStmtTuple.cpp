// $Id $

#include "CStoreStmtTuple.h"
#include "CLabelTuple.h"
#include "AExpr.h"
#include "CExprList.h"

using namespace alf;
using namespace std;

CStoreStmtTuple::
CStoreStmtTuple(COORD coord, CExprList* p_addr_exprs, CExprList* p_exprs, CLabelTuple *lbl)
:  CGenericStmt(CGenericStmt::GS_STORE),
   AStmt(coord, CGenericStmt::GS_STORE, lbl),
   addr_exprs(p_addr_exprs),
   exprs(p_exprs)
{
   SetParent(addr_exprs);
   SetParent(exprs);
}

CStoreStmtTuple::
~CStoreStmtTuple()
{
   delete addr_exprs;
   delete exprs;
}

CStoreStmtTuple::
CStoreStmtTuple(const CStoreStmtTuple& obj)
:  CGenericStmt(GS_STORE),
   AStmt(obj.coord, obj.Type(), obj.GetLabel()->Copy()),
   addr_exprs(obj.addr_exprs->Copy()),
   exprs(obj.exprs->Copy())
{
   SetParent(addr_exprs);
   SetParent(exprs);
}

CStoreStmtTuple*
CStoreStmtTuple::
Copy() const
{
   return new CStoreStmtTuple(*this);
}

CStoreStmtTuple&
CStoreStmtTuple::
operator=(const CStoreStmtTuple& obj)
{
   return *this;
}

void
CStoreStmtTuple::
OnPrint(ostream& stream, int indent) const
{
   if (!HasInternalGeneratedLabel())
   {
     GetLabel()->Print(stream, indent);
     stream << endl;
   }

   PrintIndent(stream, indent);
   stream << "{ store" << endl;
   
   addr_exprs->PrintWithEndl(stream, indent+1);
   
   PrintIndent(stream, indent+1);
   stream << "with" << endl;
   
   exprs->PrintWithEndl(stream, indent+1);

   PrintIndent(stream, indent);
   stream << "}";
}

const CExprList*
CStoreStmtTuple::
GetAddrExprs() const
{
   return addr_exprs;
}

const CExprList*
CStoreStmtTuple::
GetExprs() const
{
   return exprs;
}

CGenericNode* 
CStoreStmtTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CStoreStmtTuple(GetCoord(), 
                        dynamic_cast<CExprList*> (addr_exprs->Expand(helper)),
                        dynamic_cast<CExprList*> (exprs->Expand(helper)),
                        ExpandLabel(helper));
}

