/*
 *  CAlfTreeFilter.cpp
 *  alfx
 *
 *  Created by Jesper Jonsson on 2009-02-21.
 *  Copyright 2009 Morning Lemon. All rights reserved.
 *
 */

#include "CAlfTreeFilter.h"

using namespace std;
namespace alf
{
   CAlfTreeFilter::
   CAlfTreeFilter(const CGenericNode* node, CAlfTreeTraversor* traversor)
   {
      CAlfTreeTraversor *private_traversor = NULL;
      if (traversor == NULL)
         private_traversor = traversor = new CAlfTreeTraversor;
      traversor->RegisterNodeVisitor(this);
      traversor->BeginTraverse(node);
      if (private_traversor)
         delete private_traversor;
   }
   
   CAlfTreeFilter::
   ~CAlfTreeFilter()
   {
   }
      
   bool 
   CAlfTreeFilter::
   onBeginVisit(const CGenericNode* node)
   {
      // loop through all members (except the last) of the enum CGenericNode::TYPE and
      // add `node' to the correct lists depending on its types
      for (int i = 0; i < CGenericNode::TYPE::TYPE_NR_OF_TYPES; ++i) {
         CGenericNode::TYPE type = (CGenericNode::TYPE)i;
         if (node->IsType(type))
            filtered_nodes[type].push_back(node);
      }
      all_nodes.push_back(node);
      return true;
   }
   
   const CAlfTreeFilter::NodeList
   CAlfTreeFilter::
   GetNodesOfType(CGenericNode::TYPE node_type)
   {
      return filtered_nodes[node_type];
   }

   const CAlfTreeFilter::NodeList
   CAlfTreeFilter::
   GetAllNodes()
   {
     return all_nodes;
   }

}
