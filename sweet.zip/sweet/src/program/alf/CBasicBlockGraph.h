// $Id $

#ifndef ALF_CBASICBLOCKGRAPH_H_
#define ALF_CBASICBLOCKGRAPH_H_

#include "graphs/tools/CGraph.h"
#include "CBasicBlockGraphNode.h"

class CFlowGraph;

namespace alf
{

/** This class describes the flow of basicblocks in
    an CFlowGraph, that is an ALF-function.
*/
class CBasicBlockGraph : public CGraph<CBasicBlockGraphNode>
{
public:
   friend class CBasicBlockGraphCreator;

   /** Create the graph from 'flow_graph'.

       @param flow_graph The CFlowGraph to create the basicblock graph from.
                         The caller is still responsible to dealloc 'flow_graph'
                         when this method returns.
   */
   CBasicBlockGraph(CFlowGraph* flow_graph);

   virtual ~CBasicBlockGraph();

   /** Print the graph with the graphviz dot-syntax to 'stream'.
    */
   void PrintAsDot(std::ostream &o);

   /** Print the graph to a pdf-file located at path 'file_path'.
       If there already is a file with that name at 'file_path' it
       will be overwritten. The resulting pdf-file will contain
       the graph created by graphviz. This function will also leave
       a dot-file named 'file_path'.dot which the graph originates
       from.

       @param filepath The path to the pdf-file that graphviz
                        will write to.

       @return The success of the operation which is a zero value, otherwise
               something went wrong. If the value is negative then
               an error occured while opening/creating the dot-file.
               Otherwise the exit status of graphviz's dot command is returned.
    */
   int PrintToPdf(std::string filepath);
};

}

#endif
