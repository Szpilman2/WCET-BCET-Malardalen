// $Id $

#ifndef ALF_CFREFTUPLE_H
#define ALF_CFREFTUPLE_H

#include "AExpr.h"
#include "AConst.h"
#include "AlfNodeVisitor.h"
#include "symtab/CSymTabIdentifier.h"

namespace alf
{
class CSize;
class CMacroCallTuple;
class CString;

/**
 * Represents a frame reference in the ALF grammar:
 * FREF -> { fref SIZE FREF_ID }
 */

class CFRefTuple : public AExpr, public AConst, public CSymTabIdentifier
{
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_FREF_TUPLE
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param size    The size of the frame.
    * @param id      The frame's id.
    */
   CFRefTuple(COORD coord, CSize* size, CString* id);

   /**
    * Constructor, initializes the node as an macrocall.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_FREF_TUPLE
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord            The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param macro_call_tuple The macrocall node.
    */
   CFRefTuple(COORD coord, CMacroCallTuple* macro_call_tuple);

   /**
    * Constructor, initializes the node as an macro formal-argument-identifier string.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_FREF_TUPLE
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord            The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param macro_formal_arg The macro formal-argument-identifier.
    */
   CFRefTuple(COORD coord, CMacroFormalArg* macro_formal_arg);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CFRefTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   virtual CFRefTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitFRefTuple(*this);}

   /**
    * @return The frame's string object.
    */
   const CString *GetString() const { return id; }

   /**
    * @return The frame's id.
    */
   std::string GetId() const;

   std::string Name() const;
   std::string PrettifiedName() const { return GetId(); }


   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual CGenericNode::TYPE GetNodeType() const { return CGenericNode::TYPE_FREF_TUPLE; }

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(CGenericNode::TYPE t) const {return t == CGenericNode::TYPE_FREF_TUPLE || AExpr::IsType(t) || AConst::IsType(t); }

   /**
    * Accept a visit from a SymTabIdentifierVisitor
    */
   virtual void AcceptVisitor(SymTabIdentifierVisitor * visitor) const {visitor->VisitFRefTuple(*this);}

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CFRefTuple(const CFRefTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CFRefTuple& operator=(const CFRefTuple&);

   /**
    * The frame's id.
    */
   CString* id;
};

}

#endif

