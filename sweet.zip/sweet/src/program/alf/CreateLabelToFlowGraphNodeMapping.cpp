// $Id $
#include "CreateLabelToFlowGraphNodeMapping.h"
#include "alf.h"
#include "AStmt.h"
#include "CLabelTuple.h"
#include "../../symtab/CSymTab.h"
#include "../../graphs/cfg/CFlowGraph.h"
#include "../../graphs/cfg/CFlowGraphNode.h"

using namespace std;

namespace alf {
   /* Check every flow graph node: if it has a label then that label should be present in the basic symbol table. */
   unique_ptr<CSymTab<const CFlowGraphNode*> > CreateLabelToFlowGraphNodeMapping(const CSymTabBase *symtab_base,
      const vector<CFlowGraph*> & flow_graphs)
   {
      unique_ptr<CSymTab<const CFlowGraphNode*> > symtab(new  CSymTab<const CFlowGraphNode*>(symtab_base));
      for (vector<CFlowGraph*>::const_iterator flow_graph_it=flow_graphs.begin();
         flow_graph_it!=flow_graphs.end();
         ++flow_graph_it)
      {
         const CFlowGraph *flow_graph = *flow_graph_it;
         for (int i=flow_graph->NrOfNodes()-1; i>=0; --i) {
            const CFlowGraphNode *node = flow_graph->NodeAt(i);
            AStmt *stmt = dynamic_cast<AStmt*>(node->Stmt());
            assert(stmt);
            const CLabelTuple *label_tuple = stmt->GetLabel();
            if (label_tuple) {
               const CLRefTuple *lref = label_tuple->GetLRef();
               unsigned key = lref->GetKey();
               symtab->SetAnnot(key, node);
            }
         }
      }
      return symtab;
   }


   unique_ptr<CSymTab<const CFlowGraphNode*> >
   CreateLabelToFlowGraphNodeMapping(const CSymTabBase *symtab_base,
                                     vector<pair<CFlowGraph *, const CLabelTuple *> > & fgs_and_fls)
   {
      unique_ptr<CSymTab<const CFlowGraphNode*> > symtab(new  CSymTab<const CFlowGraphNode*>(symtab_base));
      for (vector<pair<CFlowGraph *, const CLabelTuple *> >::iterator flow_graph_it=fgs_and_fls.begin();
         flow_graph_it!=fgs_and_fls.end();
         ++flow_graph_it)
      {
         CFlowGraph *flow_graph = flow_graph_it->first;
         for (int i=flow_graph->NrOfNodes()-1; i>=0; --i) {
            const CFlowGraphNode *node = flow_graph->NodeAt(i);
            AStmt *stmt = dynamic_cast<AStmt*>(node->Stmt());
            assert(stmt);
            const CLabelTuple *label_tuple = stmt->GetLabel();
            if (label_tuple) {
               const CLRefTuple *lref = label_tuple->GetLRef();
               unsigned key = lref->GetKey();
               symtab->SetAnnot(key, node);
            }
         }

         const CLabelTuple * func_label = flow_graph_it->second;
         symtab->SetAnnot(func_label->GetLRef()->GetKey(), flow_graph->GetEntry());
      }
      return symtab;
   }
}
