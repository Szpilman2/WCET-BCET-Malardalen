
/* $Id: CAddrTuple.cpp 950 2009-09-01 10:52:28Z jjn08 $ */

#include "CAddrTuple.h"
#include "CFRefTuple.h"
#include "CIntNumValTuple.h"
#include "CSize.h"

using namespace std;
namespace alf 
{
CAddrTuple::
CAddrTuple(const COORD& coord, CSize* size, CFRefTuple* p_fref, CIntNumValTuple* p_offset)
:  CGenericNode(coord),
   AExpr(coord, size),
   AConst(coord),
   fref(p_fref),
   offset(p_offset)
{
   SetParent(fref);
   SetParent(offset);
}

CAddrTuple::
~CAddrTuple()
{
   delete fref;
   delete offset;
}

CAddrTuple::CAddrTuple(const CAddrTuple& obj)
:  CGenericNode(obj.coord),
   AExpr(obj.coord, (CSize*)obj.size->Copy()),
   AConst(obj.coord),
   fref((CFRefTuple*)obj.fref->Copy()),
   offset((CIntNumValTuple*)obj.offset->Copy())
{
   SetParent(fref);
   SetParent(offset);
}

CAddrTuple*
CAddrTuple::
Copy() const
{
   return new CAddrTuple(*this);
}

CAddrTuple&
CAddrTuple::
operator=(const CAddrTuple& obj)
{
   return *this;
}

void
CAddrTuple::
OnPrint(std::ostream& stream, int indent) const
{
   PrintIndent(stream, indent);
   stream << "{ addr ";
   size->Print(stream, 0); 
   stream << " ";
   fref->Print(stream, 0);
   stream << " ";
   offset->Print(stream, 0);
   stream << " }";
}

const CFRefTuple *
CAddrTuple::
GetFref() const
{
   return fref;
}

const CIntNumValTuple *
CAddrTuple::
GetOffset() const
{
   return offset;
}
   
CGenericNode* 
CAddrTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CAddrTuple(GetCoord(), 
                         dynamic_cast<CSize*>(GetSize()->Expand(helper)),
                         dynamic_cast<CFRefTuple*>(fref->Expand(helper)),
                         dynamic_cast<CIntNumValTuple*>(offset->Expand(helper)));
}
   
}

