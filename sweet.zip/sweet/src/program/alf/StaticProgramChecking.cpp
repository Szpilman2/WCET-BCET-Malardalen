#include "StaticProgramChecking.h"
#include "CAlfTreeTraversor.h"
#include "alf.h"
#include "AlfNodeVisitor.h"
#include "program_state/Size.h"
#include "program_state/LAU.h"
#include "symtab/CSymTabBase.h"
#include "program/alf/CCallStmtTuple.h"
#include "program/alf/CFuncTuple.h"
#include "program/alf/CExprList.h"
#include "program/alf/CArgDeclList.h"
#include "program/alf/CAllocTuple.h"
#include "program/alf/AExpr.h"
#include "program_state/Size.h"
#include "tools/StrStream.h"
#include <sstream>
#include <ciso646>
#include <algorithm>


using namespace std;
using namespace alf;

/** A visitor superclass with some convenient default implementations */
template <typename Subclass>
class StaticProgramCheckVisitor : public CAlfTreeTraversor::INodeVisitor
{
public:
   StaticProgramCheckVisitor(StaticAlfErrorCollection * reported_errors)
      : _reported_errors(reported_errors) {}

   virtual bool onBeginVisit(const CGenericNode * node) = 0;
   virtual void onEndVisit(const CGenericNode * node) = 0;

protected:
   /// Check if @a node is of type @a NodeType. If it is, dynamically cast it to a @a NodeType, cast the this pointer to
   /// @a Subclass, and call the appropriate Visit function.
   template <typename NodeType> bool TryToVisitAs(const CGenericNode * node)
   {
      if (dynamic_cast<const NodeType *>(node) != 0)
      {
         static_cast<Subclass *>(this)->Visit(dynamic_cast<const NodeType *>(node));
         return true;
      }
      else
         return false;
   }

   /// Add an error to the list of errors that should be reported
   /// @param message A suggestive error message to the user
   /// @param line The line of the Alf program where the error occurred
   /// @param ast_node The AST node corresponding to the erroneous part of the program
   void ReportError(const string & message, int line, const CGenericNode * ast_node)
   {
      _reported_errors->insert(StaticAlfError(message, (unsigned int) line, ast_node));
   }

  void ReportError(const string & message, int line1, const CGenericNode * ast_node1, 
                   int line2, const CGenericNode * ast_node2)
   {
     _reported_errors->insert(StaticAlfError(message, (unsigned int) line1, ast_node1, (unsigned int) line2, ast_node2));
   }

private:
   StaticAlfErrorCollection * _reported_errors;
};

ostream & operator <<(std::ostream & os, const StaticAlfErrorCollection & static_alf_error)
{
   for (map<string, list<StaticAlfError> >::const_iterator errlist_it=
        static_alf_error.collection.begin(); errlist_it!= static_alf_error.collection.end(); ++errlist_it)
   {
      const list<StaticAlfError> *sub_list = &errlist_it->second;
      if (sub_list->size() > 0)
      {
         list<StaticAlfError>::const_iterator err_it = sub_list->begin();
         const StaticAlfError *first_error = &*err_it;
         if (sub_list->size() == 1)
         {
            os << *first_error << endl;
         }
         else
         {
            os << "In file " << *err_it->GetNode()->GetSourceFile();
            os << ", on lines: " << err_it->Line();
            for (++err_it; err_it!=sub_list->end(); ++err_it)
               os << ", " << err_it->Line();
            os << endl;
            first_error->GetNode()->Print(os);
            os << endl << first_error->Message() << endl;
         }
      }
   }
   return os;
}

/** A visitor that checks that the sizes of expressions in the Alf program are correct */
class SizeChecker : public StaticProgramCheckVisitor<SizeChecker>
{
private:
   struct ExpectedSize
   {
      static ExpectedSize Constant(const Size & size)
      {
         ExpectedSize exp_size;
         exp_size.type = CONSTANT;
         exp_size.constant = size;
         return exp_size;
      }

      static ExpectedSize OneSizeOper(unsigned index)
      {
         ExpectedSize exp_size;
         exp_size.type = ONE_SIZE_OPER;
         exp_size.size_oper_inds.push_back(index);
         return exp_size;
      }

      static ExpectedSize TwoSizeOpersFloat(unsigned index0, unsigned index1)
      {
         ExpectedSize exp_size;
         exp_size.type = TWO_SIZE_OPERS_FLOAT;
         exp_size.size_oper_inds.push_back(index0);
         exp_size.size_oper_inds.push_back(index1);
         return exp_size;
      }

      enum {CONSTANT, ONE_SIZE_OPER, TWO_SIZE_OPERS_FLOAT} type;
      Size constant;
      std::vector<unsigned> size_oper_inds;
   };

   /** Help struct to check the sizes of initialization values */
   struct InitValSizeChecker;

   typedef std::vector<ExpectedSize> ExpectedSizes;

public:
   SizeChecker(const CSymTabBase * symbol_table, StaticAlfErrorCollection * reported_errors)
      : StaticProgramCheckVisitor<SizeChecker>(reported_errors),
        symbol_table(symbol_table),
        big_endian(false) {}

   virtual bool onBeginVisit(const CGenericNode * node);
   virtual void onEndVisit(const CGenericNode * node);

   void Visit(const CAlfTuple * alf_tuple);
   void Visit(const CAllocTuple * alloc_tuple);
   void Visit(const CInitTuple * init_tuple);
   void Visit(const CStoreStmtTuple * switch_stmt);
   void Visit(const CSwitchStmtTuple * switch_stmt);
   void Visit(const CFRefTuple * fref_tuple);
   void Visit(const CAddrTuple * addr);
   void Visit(const CCompAddrTuple * addr);
   void Visit(const CLRefTuple * lref_tuple);
   void Visit(const CLabelTuple * label);
   void Visit(const CCompLabelTuple * label);
   void Visit(const AConst * constant);
   void Visit(const COpNumExprTuple * op);
   void VisitOp(const COpNumExprTuple * op, unsigned nr_expected_size_opers,
                const ExpectedSizes & expected_sizes);
   /** @return true if the size could be determined, false otherwise
       @post If true is returned, @a size will hold the size that the expression will have when it is evaluated */
   bool DetermineSizeOfExpression(const AExpr * expr, Size & size) const;
   /** Turn the syntax tree node @a size_node into a Size value */
   inline Size SizeNodeToSize(const CSize * size_node) const
      {return size_node->IsInfinity()? Size::Infinity() : Size(size_node->GetSizeInBits());}

private:
   const CSymTabBase * symbol_table;
   bool big_endian;
};

/** Visitor that checks for problems related to identifiers */
class IDConsistency : public StaticProgramCheckVisitor<IDConsistency>, public AlfNodeVisitor
{
public:  
   /** Create a identifier consistency checker
       @param  symbol_table      Symbol table for the ALF AST. The caller is responsible for it.
       @param  reported_errors   Vector where to put errors that are found */
   IDConsistency(const CSymTabBase * symbol_table, StaticAlfErrorCollection * reported_errors)
      : StaticProgramCheckVisitor<IDConsistency>(reported_errors),
      symbol_table(symbol_table) {}

   /** Create a identifier consistency checker
       @param  functions         Functions
       @param  symbol_table      Symbol table for the ALF AST. The caller is responsible for it.
       @param  reported_errors   Vector where to put errors that are found */
   IDConsistency(std::set<const alf::CGenericNode*>* functions, const CSymTabBase * symbol_table, 
      StaticAlfErrorCollection * reported_errors)
      : StaticProgramCheckVisitor<IDConsistency>(reported_errors),
      functions(functions), symbol_table(symbol_table) {}

   bool onBeginVisit(const CGenericNode* node);

   void onEndVisit(const CGenericNode* node) {}

   /** Checks that the identifier of @a fref is not an external (imported) identifier. If it is,
       an error is added to the list of errors. */
   void VisitFRefTuple(const CFRefTuple& fref);

   /** Checks that the identifier of @a lref is not an external (imported) identifier. If it is,
       an error is added to the list of errors. */
   void VisitLRefTuple(const CLRefTuple& lref);

private:
   set<const alf::CGenericNode*>* functions;

   /** Symbol table for the ALF AST */
   const CSymTabBase * symbol_table;

   void Default(const CGenericNode&) {}
};

/** Visitor that checks that all direct function calls goes to either
    a declared function or an imported lref */
class FuncCallConsistency : public StaticProgramCheckVisitor<FuncCallConsistency>
{
public:  
   /** Create a identifier consistency checker
       @param  reported_errors   Vector where to put errors that are found */
   FuncCallConsistency(StaticAlfErrorCollection * reported_errors)
      : StaticProgramCheckVisitor<FuncCallConsistency>(reported_errors)
   {}

  bool onBeginVisit(const CGenericNode *);
  void onEndVisit(const CGenericNode * node) {};

   /** Checks that direct calls goes to either some other function or an imported lref */
   void Visit(const CCallStmtTuple * call_tuple); 
   /** Checks that function name is not also existing as imported lref */
   void Visit(const CFuncTuple * func_tuple);
};

/** Checks for components of ALF that should be supported but haven't yet been implemented, or
    deprecated things */
class Unsupported : public StaticProgramCheckVisitor<Unsupported>, public AlfNodeVisitor
{
public:
   Unsupported(StaticAlfErrorCollection * reported_errors)
      : StaticProgramCheckVisitor<Unsupported>(reported_errors) {}

   virtual bool onBeginVisit(const CGenericNode * node)
   {
      node->AcceptVisitor(this);
      return true;
   }

   virtual void onEndVisit(const CGenericNode * node) {}

   virtual void VisitScopeTuple(const CScopeTuple & scope);

   virtual void VisitJumpStmtTuple(const CJumpStmtTuple & jump_stmt);

private:
   virtual void Default(const CGenericNode&) {}
};

// StaticAlfError members - - - - - - - - - - - -

StaticAlfError::StaticAlfError(const std::string & message, unsigned int line, const alf::CGenericNode * ast_node)
  : _message(message), _line(line), _ast_node(ast_node), _has_two_lines_and_ast_nodes(false), _line2(-1), _ast_node2(NULL)
{

}

StaticAlfError::StaticAlfError(const std::string & message, unsigned int line1, const alf::CGenericNode * ast_node1,
                               unsigned int line2, const alf::CGenericNode * ast_node2)
  : _message(message), _line(line1), _ast_node(ast_node1), _has_two_lines_and_ast_nodes(true), _line2(line2), _ast_node2(ast_node2)
{

}

std::ostream & StaticAlfError::Print(std::ostream & os) const
{
  os << "In file " << *_ast_node->GetSourceFile() << ", on line " << _line << ":" << endl;
  _ast_node->Print(os);
  if(_has_two_lines_and_ast_nodes) {
    os << endl;
    os << "and on line: "<< _line2 << ":" << endl; 
    _ast_node2->Print(os);
  }
  os << endl << _message;
  return os;
}

// Implementation of the public interface
void PerformSizeCheck(alf::CAlfTuple & program, StaticAlfErrorCollection & reported_errors)
{
   // Do the checking of program sizes
   CAlfTreeTraversor traversor;
   unique_ptr<SizeChecker> size_checker(new SizeChecker(program.GetSymTab(), &reported_errors));
   traversor.RegisterNodeVisitor(size_checker.get());
   unique_ptr<Unsupported> not_yet_implemented(new Unsupported(&reported_errors));
   traversor.RegisterNodeVisitor(not_yet_implemented.get());  
   traversor.BeginTraverse(&program);

  // Check that no identifier occurs more than once in imports and exports 
  // CheckNoImportExportDuplicates(program, reported_errors);  
} 

void PerformFuncCallCheck(alf::CAlfTuple & program, StaticAlfErrorCollection & reported_errors)
{
  // Do the checking of function call consistency
  CAlfTreeTraversor traversor;
  unique_ptr<FuncCallConsistency> func_call_checker(new FuncCallConsistency(&reported_errors));
  traversor.RegisterNodeVisitor(func_call_checker.get());
  traversor.BeginTraverse(&program); 
}
   

void PerformParsedProgramCheck(alf::CAlfTuple & program, StaticAlfErrorCollection & reported_errors)
{
   CAlfTreeTraversor traversor;
   unique_ptr<FuncCallConsistency> func_call_checker(new FuncCallConsistency(&reported_errors));
   traversor.RegisterNodeVisitor(func_call_checker.get());
   traversor.BeginTraverse(&program); 
}  

void CheckUnresolvedReferences(alf::CAlfTuple & program, vector<CGenericFunction*> &functions, const CSymTabBase * symbol_table, 
                               StaticAlfErrorCollection & reported_errors)
{
   set<const CGenericNode*> functions_;
   for (vector<CGenericFunction*>::iterator f = functions.begin(); f != functions.end(); ++f)
      functions_.insert(dynamic_cast<CGenericNode*>(*f));
   CAlfTreeTraversor traversor;
   unique_ptr<IDConsistency> id_consistency(new IDConsistency(&functions_, symbol_table, &reported_errors));
   traversor.RegisterNodeVisitor(id_consistency.get());
   traversor.BeginTraverse(&program); 
}


// Help function for sorting references based on their id
template <typename RefTuple>
bool ref_sort(const RefTuple* ref1, const RefTuple* ref2) { return ref1->GetId() < ref2->GetId(); }

// Help function for sorting a list of references and also check for duplicates
template <typename RefTuple, typename RefList>
void SortAndCheckForDuplicates(std::vector<RefTuple *> & sorted_refs, const RefList * refs, 
                               std::string t, StaticAlfErrorCollection & reported_errors)
{
  // Create a sorted list of imported lrefs
  for(typename RefList::const_list_iterator ref = refs->ConstIterator(); ref != refs->InvalidIterator(); ++ref) {
    sorted_refs.push_back(*ref);
  }
  // Check that no lref occurs twice
  if(sorted_refs.size() > 1) {
    std::sort(sorted_refs.begin(), sorted_refs.end(), ref_sort<RefTuple>);    
    typename RefList::list_iterator i1 = sorted_refs.begin();
    typename RefList::list_iterator i2 = i1;
    i2++;
    for(; i2 != sorted_refs.end(); i1++, i2++) {
      if((*i1)->GetId() == (*i2)->GetId()) {
        stringstream message;
        message << "Identifier " << (*i1)->GetId() << " occurs several times in " << t << ". ";
        unsigned int line = (*i1)->GetLine();
        reported_errors.insert(StaticAlfError(message.str(), line, (*i1)));
      }
    }
  }
}

// Help function for checking if there are references with the same id in two sorted vectors 
template <typename RefTuple1, typename RefTuple2> 
void CheckForDuplicates(const std::vector<RefTuple1 *> * sorted_v1, const std::vector<RefTuple2 *> * sorted_v2,
                        std::string t1, std::string t2, StaticAlfErrorCollection & reported_errors)
{
  typename std::vector<RefTuple1 *>::const_iterator i1 = sorted_v1->begin();
  typename std::vector<RefTuple2 *>::const_iterator i2 = sorted_v2->begin();
  while(i1 != sorted_v1->end() && i2 != sorted_v2->end()) {
    if((*i1)->GetId() == (*i2)->GetId()) {
      stringstream message;
      message << "Identifier " << (*i1)->GetId() << " occurs both in " << t1 << " and in " << t2 << ".";  
      unsigned int line = (*i1)->GetLine();
      reported_errors.insert(StaticAlfError(message.str(), line, (*i1)));
    }
    if((*i1)->GetId() < (*i2)->GetId())
      i1++;
    else 
      i2++;
  }
}

// Function that goes through all the exports and imports and checks
// that no identifier occurs more than once.
void CheckNoImportExportDuplicates(alf::CAlfTuple & program, StaticAlfErrorCollection & reported_errors)
{
  const CImportsTuple* imports = program.GetImports();
  const CExportsTuple* exports = program.GetExports();

  // Extract a sorted list of imported lrefs and check that no identifier occurs twice
  std::vector<CLRefTuple *> sorted_imported_lrefs;
  const CLRefList* imported_lrefs = imports->GetLRefList();
  SortAndCheckForDuplicates<CLRefTuple, CLRefList>(sorted_imported_lrefs, imported_lrefs, "imported lrefs", reported_errors);

  // Extract a sorted list of imported frefs and check that no identifier occurs twice
  std::vector<CFRefTuple *> sorted_imported_frefs;
  const CFRefList* imported_frefs = imports->GetFRefList();
  SortAndCheckForDuplicates<CFRefTuple, CFRefList>(sorted_imported_frefs, imported_frefs, "imported frefs", reported_errors);

  // Extract a sorted list of exported lrefs and check that no identifier occurs twice
  std::vector<CLRefTuple *> sorted_exported_lrefs;
  const CLRefList* exported_lrefs = exports->GetLRefList();
  SortAndCheckForDuplicates<CLRefTuple, CLRefList>(sorted_exported_lrefs, exported_lrefs, "exported lrefs", reported_errors);

  // Extract a sorted list of exported frefs and check that no identifier occurs twice
  std::vector<CFRefTuple *> sorted_exported_frefs;
  const CFRefList* exported_frefs = exports->GetFRefList();
  SortAndCheckForDuplicates<CFRefTuple, CFRefList>(sorted_exported_frefs, exported_frefs, "exported frefs", reported_errors);
 
  // Check that no identifier occurs in both lists 
  CheckForDuplicates<CLRefTuple, CFRefTuple>(&sorted_imported_lrefs, &sorted_imported_frefs, "imported lrefs", "imported frefs", reported_errors);  
  CheckForDuplicates<CLRefTuple, CLRefTuple>(&sorted_imported_lrefs, &sorted_exported_lrefs, "imported lrefs", "exported lrefs", reported_errors);  
  CheckForDuplicates<CLRefTuple, CFRefTuple>(&sorted_imported_lrefs, &sorted_exported_frefs, "imported lrefs", "exported frefs", reported_errors);  
  CheckForDuplicates<CFRefTuple, CLRefTuple>(&sorted_imported_frefs, &sorted_exported_lrefs, "imported frefs", "exported lrefs", reported_errors);  
  CheckForDuplicates<CFRefTuple, CFRefTuple>(&sorted_imported_frefs, &sorted_exported_frefs, "imported frefs", "exported frefs", reported_errors);  
  CheckForDuplicates<CLRefTuple, CFRefTuple>(&sorted_exported_lrefs, &sorted_exported_frefs, "exported lrefs", "exported frefs", reported_errors);  
}



// Public members of SizeChecker - - - - - - - - - - - - - - - ->

bool SizeChecker::onBeginVisit(const CGenericNode * node)
{
   TryToVisitAs<CAlfTuple>(node);
   return true;
}

void SizeChecker::onEndVisit(const CGenericNode * node)
{
   // Find out what type the node has and run the right Visit function

   // Try some cases which exclude other cases
   if (TryToVisitAs<CAllocTuple>(node) ||
       TryToVisitAs<CInitTuple>(node) ||
       TryToVisitAs<CStoreStmtTuple>(node) ||
       TryToVisitAs<CSwitchStmtTuple>(node) ||
       TryToVisitAs<COpNumExprTuple>(node))
   {
      return;
   }

   // The disjunction causes the series of Try calls to be terminated with
   // the first call returning true
   TryToVisitAs<CFRefTuple>(node) ||
      TryToVisitAs<CAddrTuple>(node) ||
      TryToVisitAs<CCompAddrTuple>(node) ||
      TryToVisitAs<CLRefTuple>(node) ||
      TryToVisitAs<CLabelTuple>(node) ||
      TryToVisitAs<CCompLabelTuple>(node);

   TryToVisitAs<AConst>(node);
}

void SizeChecker::Visit(const CAlfTuple * alf_tuple)
{
   big_endian = alf_tuple->GetEndian() == "big_endian";
   if (!big_endian)
   {
      if (alf_tuple->GetEndian() != "little_endian")
      {
         stringstream s;
         s << "Syntax error in endianness declaration: \""
           << alf_tuple->GetEndian() << "\". Or has the syntax been changed?";
         throw logic_error(s.str());
      }
   }
}

void SizeChecker::Visit(const CAllocTuple * alloc_tuple)
{
   if (alloc_tuple->GetFrameSize()->GetSizeInBits() == 0)
   {
      ReportError("Cannot create a frame of size 0", 
                  alloc_tuple->GetLine(), alloc_tuple);
   }

   if (big_endian && alloc_tuple->GetFrameSize()->GetSizeInBits() == Size::Infinity())
   {
      ReportError("Infinite sized frames cannot be combined with big endianness", 
                  alloc_tuple->GetLine(), alloc_tuple);
   }
}

/** Returns the size of the constant @p const_ */
Size GetSizeOfConst(const AConst& const_)
{
   return dynamic_cast<const AExpr&>(const_).GetSizeOfEvaluatedExpr();
}

/** Returns whether @p a is a multiple of @p b or not */
template <typename Int>
inline bool IsMultipleOf(const Int& a, const Int& b)
{
   Int _0(0);
   if (b == _0)
      return (a == _0);
   return a / b * b == a;
}

struct SizeChecker::InitValSizeChecker : public AlfNodeVisitor
{
   Size headroom; // amount of available space in the frame (in bits)
   SizeChecker& size_checker;

   InitValSizeChecker(Size headroom, SizeChecker& size_checker)
      : headroom(headroom), size_checker(size_checker) {}

   virtual void Default(const CGenericNode & node) {
      // it should be a simple constant
      if (const AConst *as_const = dynamic_cast<const AConst*>(&node)) {
         if (GetSizeOfConst(*as_const) > headroom) {
            size_checker.ReportError("Constant does not fit in frame", node.GetLine(), &node);
         }
      }
   }
   
   virtual void VisitConstRepeatTuple(const CConstRepeatTuple & node) 
   {
      Size size_of_const = GetSizeOfConst(*node.GetConst());
      Size lau = LAU::LAU();
      if (!IsMultipleOf(size_of_const, lau))
         size_checker.ReportError("The size of a constant in a const_repeat must be a multiple of the LAU", node.GetLine(), &node);
      if (node.GetRepeats() * size_of_const > headroom)
         size_checker.ReportError("Repeated constant does not fit in frame", node.GetLine(), &node);
   }

   template <typename ListElem>
   void VisitListNode(const CListNode<ListElem>& node) const
   {
      // Check all the constants in the list so that their sizes are multiples of the LAU
      Size lau = LAU::LAU();
      Size tot_size = 0;
      for (typename CListNode<ListElem>::const_list_iterator const_i = node.ConstIterator(), const_n = node.InvalidIterator();
         const_i != const_n; ++const_i)
      {
         Size size_of_const_i = GetSizeOfConst(**const_i);
         if (!IsMultipleOf(size_of_const_i, lau))
            size_checker.ReportError("Constant must have size that is a multiple of the LAU", (*const_i)->GetLine(), &node);
         tot_size += size_of_const_i;
      }
      if (tot_size > headroom)
         size_checker.ReportError("List of constants does not fit in frame", node.GetLine(), &node);
   }

   virtual void VisitConstList(const CConstList & node) { VisitListNode(node); }
   
   virtual void VisitIntListTuple(const CIntListTuple& node) { VisitListNode(node); }

   virtual void VisitFloatListTuple(const CFloatListTuple& node) { VisitListNode(node); }

   virtual void VisitCharStringTuple(const CCharStringTuple& node) {
      // the size of a character string is 8 times the number of characters,
      // plus 8 bits for the terminating null character
      if (8 * (node.GetString()->Get().length() + 1) > headroom) {
         size_checker.ReportError("String does not fit in frame", node.GetLine(), &node);
      }
   }
};

void SizeChecker::Visit(const CInitTuple * init_tuple)
{
   const CRefTuple * ref_tuple = init_tuple->GetRef();
   const CSymTabIdentifier * sym_tab_id = symbol_table->Lookup(ref_tuple->GetKey())->GetIdentifier();
   const CAllocTuple * alloc_tuple = dynamic_cast<const CAllocTuple*>(sym_tab_id);
   assert(alloc_tuple != nullptr);
   if (ref_tuple->GetOffset()->GetSizeOfEvaluatedExpr() !=
       alloc_tuple->GetBitstringSize()->GetSizeInBits())
   {
      stringstream message;
      message << "Size of offset in ref must be equal to the bitstring size of the fref "
                 "that was declared in the alloc (" << alloc_tuple->GetBitstringSize()
              << "bits, line " << alloc_tuple->GetLine() << ")";
      ReportError(message.str(), ref_tuple->GetOffset()->GetSize()->GetLine(), init_tuple);
   }
   Size frame_size = alloc_tuple->GetFrameSize()->GetSizeInBits();
   assert(ref_tuple->GetOffset()->GetNumber()->FitsInInt());
   Size offset = LAU::LAUToBits(ref_tuple->GetOffset()->GetNumber()->GetValueAsInt());
   Size headroom = frame_size - offset;
   InitValSizeChecker init_val_size_checker(headroom, *this);
   init_tuple->GetVal()->AcceptVisitor(&init_val_size_checker);
}

void SizeChecker::Visit(const CStoreStmtTuple * store_stmt)
{
   // Check that #addresses == #expressions
   std::size_t no_of_addr = store_stmt->GetAddrExprs()->ElementCount();
   std::size_t no_of_expr = store_stmt->GetExprs()->ElementCount();
   if (no_of_addr != no_of_expr)
   {
      stringstream message;
      message  << "The number of addresses is "<<no_of_addr
      << " while the number of expressions in the store statement is "<<no_of_expr
      << "; they should be equal";
      ReportError(message.str(), store_stmt->GetLine(), store_stmt);
   }
}

void SizeChecker::Visit(const CSwitchStmtTuple * switch_stmt)
{
   Size expr_size;
   if (DetermineSizeOfExpression(switch_stmt->GetNumExpr(), expr_size) == false)
      return;
   const CTargetList * target_list = switch_stmt->GetTargets();
   for (CTargetList::const_list_iterator t = target_list->ConstIterator(); t != target_list->InvalidIterator(); ++t)
   {
      if ((*t)->IsType(CGenericNode::TYPE_TARGET_TUPLE))
      {
         const CTargetTuple * target_tuple = &dynamic_cast<const CTargetTuple &>(**t);
         Size const_size;
         DetermineSizeOfExpression(target_tuple->GetIntNumVal(), const_size);
         if (const_size != expr_size)
         {
            stringstream message;
            message  << "Size of constant is "<<const_size<<" while size of expression in switch statement is "<<expr_size
                     << "; they should be equal";
            ReportError(message.str(), target_tuple->GetIntNumVal()->GetSize()->GetLine(), switch_stmt);
         }
      }
   }
}

void SizeChecker::Visit(const CFRefTuple * fref_tuple)
{
   // Look the fref id up in the symbol table
   string name = fref_tuple->GetId();
   const CSymTabEntry* entry = symbol_table->Lookup(name);

   // Check that the id names a frame
   if (!entry->IsData())
   {
      ReportError("\"" + name + "\" does not name a frame", fref_tuple->GetLine(), fref_tuple);
      return;
   }
   
   // Check that the declared fref size is the same as the size used in the fref expression
   const CAllocTuple* alloc = dynamic_cast<const CAllocTuple*>(entry->GetIdentifier());
   if (alloc == 0) return;    // Hm, not sure how to handle this
   Size exp_size = alloc->GetBitstringSize()->GetSizeInBits();
   if (fref_tuple->GetSizeOfEvaluatedExpr() != exp_size )
      ReportError((StrStream() << "The frame reference should have size " << exp_size <<
         ", as specified in the allocation of \"" << name << "\" at " << alloc->GetCoord()).Str(),
         fref_tuple->GetLine(), fref_tuple);
}

void SizeChecker::Visit(const CAddrTuple * addr)
{
   const CFRefTuple * fref = addr->GetFref();
   const CIntNumValTuple * offset = addr->GetOffset();
   if (fref->GetSizeOfEvaluatedExpr() != offset->GetSizeOfEvaluatedExpr())
   {
      ReportError("Sizes of fref and offset do not match", addr->GetLine(), addr);
   }
   else if (addr->GetSizeOfEvaluatedExpr() != fref->GetSizeOfEvaluatedExpr())
   {
      ReportError("Size of address does not match sizes of fref and offset", addr->GetLine(), addr);
   }
}

void SizeChecker::Visit(const CCompAddrTuple * addr)
{
   const AExpr * fref = addr->GetFRefExpr();
   const AExpr * offset = addr->GetNumExpr();
   if (fref->GetSizeOfEvaluatedExpr() != offset->GetSizeOfEvaluatedExpr())
   {
      ReportError("Sizes of fref and offset expressions do not match", addr->GetLine(), addr);
   }
   else if (addr->GetSizeOfEvaluatedExpr() != fref->GetSizeOfEvaluatedExpr())
   {
      ReportError("Size of address does not match sizes of fref and offset expressions", addr->GetLine(), addr);
   }
}

void SizeChecker::Visit(const CLRefTuple * lref_tuple)
{
   // Look the lref id up in the symbol table
   string name = lref_tuple->GetId();
   const CSymTabEntry* entry = symbol_table->Lookup(name);
   
   // Check that the id names a code label
   if (!entry->IsCode())
   {
      ReportError("\"" + name + "\" is not a code label.", lref_tuple->GetLine(), lref_tuple);
      return;
   }

   // Check that the declared lref size is the same as the size used in the lref expression
   const CLRefTuple* def = dynamic_cast<const CLRefTuple*>(entry->GetCodeIdentifier());
   if (def == 0) return;   // Hm, not sure how to handle this
   Size exp_size = def->GetSizeOfEvaluatedExpr();
   if (lref_tuple->GetSizeOfEvaluatedExpr() != exp_size)
      ReportError((StrStream() << "The label reference should have size " << exp_size <<
         ", as specified in the definition of \"" << name << "\" at " << def->GetCoord()).Str(),
         lref_tuple->GetLine(), lref_tuple);
}

void SizeChecker::Visit(const CLabelTuple * label)
{
   const CLRefTuple * lref = label->GetLRef();
   const CIntNumValTuple * offset = label->GetOffset();
   if (lref->GetSizeOfEvaluatedExpr() != offset->GetSizeOfEvaluatedExpr())
   {
      ReportError("Sizes of lref and offset do not match", label->GetLine(), label);
   }
   else if (label->GetSizeOfEvaluatedExpr() != label->GetSizeOfEvaluatedExpr())
   {
      ReportError("Size of label does not match sizes of lref and offset", label->GetLine(), label);
   }
}

void SizeChecker::Visit(const CCompLabelTuple * label)
{
   const AExpr * lref = label->GetLRefExpr();
   const AExpr * offset = label->GetNumExpr();
   if (lref->GetSizeOfEvaluatedExpr() != offset->GetSizeOfEvaluatedExpr())
   {
      ReportError("Sizes of lref and offset expressions do not match", label->GetLine(), label);
   }
   else if (label->GetSizeOfEvaluatedExpr() != lref->GetSizeOfEvaluatedExpr())
   {
      ReportError("Size of label does not match sizes of lref and offset expressions", label->GetLine(), label);
   }
}

void SizeChecker::Visit(const AConst * constant)
{
   try
   {
      const AExpr * expr = &dynamic_cast<const AExpr &>(*constant);
      if (expr->GetSizeOfEvaluatedExpr() == 0)
      {
         ReportError("Values must have a size larger than 0", expr->GetSize()->GetLine(), constant);
      }
   }
   catch (std::bad_cast &) {return;}
}

void SizeChecker::Visit(const COpNumExprTuple * op)
{
   //const CSizeList * size_list = op->GetSizes();

   switch (op->GetOperator())
   {
   // OP_INT (and pointer arithmetics) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   case COpNumExprTuple::OP_TYPE_NEG:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_ADD:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::Constant(1));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_C_ADD:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::Constant(1));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_SUB:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::Constant(1));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_C_SUB:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::Constant(1));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_U_MUL:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_S_MUL:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_U_DIV:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_S_DIV:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_U_MOD:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_S_MOD:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(1));
         VisitOp(op, 2, exp_sizes);
         break;
      }

      // OP_BIT - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   case COpNumExprTuple::OP_TYPE_L_SHIFT:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_R_SHIFT:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_R_SHIFT_A:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_S_EXT:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 2, exp_sizes);
         if (op->GetSizes()->ElementCount() == 2)
         {
            if (SizeNodeToSize(op->GetSizes()->ElementAt(1)) <
                SizeNodeToSize(op->GetSizes()->ElementAt(0)))
            {
               ReportError("Second size operand must be larger than or equal to the "
                           "first size operand", op->GetSizes()->ElementAt(1)->GetLine(), op);
            }
         }
         break;
      }
   case COpNumExprTuple::OP_TYPE_NOT:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_AND:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_OR:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_XOR:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   // OP_FLOAT - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   case COpNumExprTuple::OP_TYPE_F_NEG:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_ADD:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_SUB:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_MUL:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_DIV:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_TO_F:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 2));
         VisitOp(op, 4, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_TO_U:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         VisitOp(op, 3, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_TO_S:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         VisitOp(op, 3, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_U_TO_F:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(2));
         VisitOp(op, 3, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_S_TO_F:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(2));
         VisitOp(op, 3, exp_sizes);
         break;
      }

   // OP_CMP - - - - - - - - - - - - - - - - - - - - - - - - - - -
   case COpNumExprTuple::OP_TYPE_EQ:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_NEQ:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_U_LT:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_U_GE:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_U_GT:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_U_LE:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_S_LT:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_S_GE:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_S_GT:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_S_LE:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_EQ:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_NE:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_LT:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_GE:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_GT:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         VisitOp(op, 2, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_LE:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         exp_sizes.push_back(ExpectedSize::TwoSizeOpersFloat(0, 1));
         VisitOp(op, 2, exp_sizes);
         break;
      }

   // OP_MATH - - - - - - - - - - - - - -
   case COpNumExprTuple::OP_TYPE_IF:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::Constant(1));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   case COpNumExprTuple::OP_TYPE_B2N:
      {
         // TODO: Should it be a size argument here? There is no such in the Alf spec.
         break;
      }
   case COpNumExprTuple::OP_TYPE_EXP2:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::Constant(Size::Infinity()));
         VisitOp(op, 0, exp_sizes);
         break;
      }

   // OP_BITSTR - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   case COpNumExprTuple::OP_TYPE_SELECT:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         VisitOp(op, 3, exp_sizes);
         if (op->GetSizes()->ElementCount() == 3)
         {
            if (SizeNodeToSize(op->GetSizes()->ElementAt(1)) >
                SizeNodeToSize(op->GetSizes()->ElementAt(2)))
            {
               ReportError("The second bit index in the select must be larger than or equal "
                           "to first bit index", op->GetSizes()->ElementAt(2)->GetLine(), op);
            }
         }
         break;
      }
   case COpNumExprTuple::OP_TYPE_CONC:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::OneSizeOper(0));
         exp_sizes.push_back(ExpectedSize::OneSizeOper(1));
         VisitOp(op, 2, exp_sizes);
         if (op->GetSizes()->ElementCount() == 2)
         {
            if (SizeNodeToSize(op->GetSizes()->ElementAt(1)) == Size::Infinity())
            {
               ReportError("(See second size operand.) The second operand to conc must be of finite size.",
                           op->GetSizes()->ElementAt(1)->GetLine(), op);
            }
         }    
         break;
      }
   case COpNumExprTuple::OP_TYPE_REPEAT:
      {
         ExpectedSizes exp_sizes;
         exp_sizes.push_back(ExpectedSize::Constant(1));
         VisitOp(op, 1, exp_sizes);
         break;
      }
   }
}

void SizeChecker::VisitOp(const COpNumExprTuple * op, unsigned nr_expected_size_opers,
                          const ExpectedSizes & expected_sizes)
{
   // Some strings for making nicers outputs of indices
   const char * index_strings[] =
   {
      "first",
      "second",
      "third",
      "fourth"
   };

   // Check that the number of operands is correct
   if (op->GetNumExprs()->ElementCount() != expected_sizes.size())
   {
      stringstream message;
      message << "Wrong number of operands. Should be " << expected_sizes.size()
              << " for " << op->GetName() << ".";
      ReportError(message.str(), op->GetLine(), op);
   }

   // Check that the number of size operands is correct
   if (op->GetSizes()->ElementCount() != nr_expected_size_opers)
   {
      stringstream message;
      message  << "Wrong number of size operands. Should be " << nr_expected_size_opers
         << " for " << op->GetName() << ".";
      ReportError(message.str(), op->GetLine(), op);   
   }

   // Now iterate through the list of expected_sizes and check all the operands that they
   // have correct sizes. If there are too few operands, the loop will be when they run out,
   // but those operands that do exist will still be checked.
   std::vector<ExpectedSize>::const_iterator s;
   CExprList::const_list_iterator e;
   unsigned n;
   for (s = expected_sizes.begin(), e = op->GetNumExprs()->ConstIterator(), n = 0;
        s != expected_sizes.end() && e != op->GetNumExprs()->InvalidIterator();
        ++s, ++e, ++n)
   {
      // Check the size of the operand based on the type of expected size
      switch (s->type)
      {
      // A constant size operand is expected
      case ExpectedSize::CONSTANT:
         {
            Size exprs_size;
            if (DetermineSizeOfExpression(*e, exprs_size))
            {
               if (exprs_size != s->constant)
               {
                  stringstream message;
                  message  << "Wrong size on " << index_strings[n] << " operand (" << exprs_size
                           << " bits, line " << (*e)->GetLine() << "). This operand should always be "
                           << s->constant << " bits for " << op->GetName() << ".";
                  ReportError(message.str(), op->GetLine(), op);
               }
            }
            break;
         }
      // The expected size is given by a size operand
      case ExpectedSize::ONE_SIZE_OPER:
         {
            // Check that the operand expression has the size specified by the referenced size
            // operand (if the size operand exists, that is)
            if (op->GetSizes()->ElementCount() > s->size_oper_inds.front())
            {
               Size exprs_size;
               if (DetermineSizeOfExpression(*e, exprs_size))
               {
                  const CSize * size_oper = op->GetSizes()->ElementAt(s->size_oper_inds.front());
                  Size expct_size = SizeNodeToSize(size_oper);
                  if (exprs_size != expct_size)
                  {
                     stringstream message;
                     message  << "Wrong size on " << index_strings[n] << " operand (" << exprs_size
                              << " bits, line " << (*e)->GetLine() << "). This operand should be "
                              << expct_size << " bits according to the " << index_strings[s->size_oper_inds.front()]
                              << " size operand (line " << size_oper->GetLine() << ").";
                     ReportError(message.str(), op->GetLine(), op);
                  }
               }
            }
            break;
         }
      // The expected size is given by two size operands, which together specify the size as their
      // sum plus 1 (which is the size of the sign bit)
      case ExpectedSize::TWO_SIZE_OPERS_FLOAT:
         {
            // Check that the operand's size is equal to 1 + the sum of those specified by the
            // two referenced size operands
            if (op->GetSizes()->ElementCount() > s->size_oper_inds.back())
            {
               Size exprs_size;
               if (DetermineSizeOfExpression(*e, exprs_size))
               {
                  const CSize * size_oper1 = op->GetSizes()->ElementAt(s->size_oper_inds.front());
                  const CSize * size_oper2 = op->GetSizes()->ElementAt(s->size_oper_inds.back());
                  Size expct_size1 = SizeNodeToSize(size_oper1);
                  Size expct_size2 = SizeNodeToSize(size_oper2);
                  Size total_expct_size = 1 + expct_size1 + expct_size2;
                  if (exprs_size != total_expct_size)
                  {
                     stringstream message;
                     unsigned int line1 = size_oper1->GetLine();
                     unsigned int line2 = size_oper2->GetLine();
                     message  << "Wrong size on " << index_strings[n] << " operand (" << exprs_size
                              << " bits, line " << (*e)->GetLine() << "). This operand should be 1 + "
                              << expct_size1 << " + " << expct_size2 << " = " << total_expct_size
                              << " bits according to the " << index_strings[s->size_oper_inds.front()]
                              << " and " << index_strings[s->size_oper_inds.back()]
                              << " size operands (lines " << line1
                              << " and " << line2 << ", respectively).";
                     ReportError(message.str(), op->GetLine(), op);                     
                  }
               }
            }
            break;
         }
      }
   }
}

bool SizeChecker::DetermineSizeOfExpression(const AExpr * expr, Size & size) const
{
   if (expr->GetSize() != NULL)
   {
      size = SizeNodeToSize(expr->GetSize());
      return true;
   }
   else if (typeid(*expr) != typeid(COpNumExprTuple))
   {
      return false;
   }

   // Else we have a COpNumExprTuple

   const COpNumExprTuple * op_expr = dynamic_cast<const COpNumExprTuple *>(expr);
   switch (op_expr->GetOperator())
   {
   // These are operators where the size of the result is determined by the first size operand
   case COpNumExprTuple::OP_TYPE_NEG:
   case COpNumExprTuple::OP_TYPE_ADD:
   case COpNumExprTuple::OP_TYPE_SUB:
   case COpNumExprTuple::OP_TYPE_U_DIV:
   case COpNumExprTuple::OP_TYPE_S_DIV:
   case COpNumExprTuple::OP_TYPE_U_MOD:
   case COpNumExprTuple::OP_TYPE_S_MOD:
   case COpNumExprTuple::OP_TYPE_L_SHIFT:
   case COpNumExprTuple::OP_TYPE_R_SHIFT:
   case COpNumExprTuple::OP_TYPE_R_SHIFT_A:
   case COpNumExprTuple::OP_TYPE_NOT:
   case COpNumExprTuple::OP_TYPE_AND:
   case COpNumExprTuple::OP_TYPE_OR:
   case COpNumExprTuple::OP_TYPE_XOR:
   case COpNumExprTuple::OP_TYPE_IF:
   case COpNumExprTuple::OP_TYPE_REPEAT:
      if (op_expr->GetSizes()->ElementCount() >= 1)
      {
         size = SizeNodeToSize(op_expr->GetSizes()->ElementAt(0));
         return true;
      }
      else
         return false;
      break;
   // Operators where the result has the size 1
   case COpNumExprTuple::OP_TYPE_C_ADD:
   case COpNumExprTuple::OP_TYPE_C_SUB:
   // Boolean operators
   case COpNumExprTuple::OP_TYPE_EQ:
   case COpNumExprTuple::OP_TYPE_NEQ:
   case COpNumExprTuple::OP_TYPE_U_LT:
   case COpNumExprTuple::OP_TYPE_U_GE:
   case COpNumExprTuple::OP_TYPE_U_GT:
   case COpNumExprTuple::OP_TYPE_U_LE:
   case COpNumExprTuple::OP_TYPE_S_LT:
   case COpNumExprTuple::OP_TYPE_S_GE:
   case COpNumExprTuple::OP_TYPE_S_GT:
   case COpNumExprTuple::OP_TYPE_S_LE:
   case COpNumExprTuple::OP_TYPE_F_EQ:
   case COpNumExprTuple::OP_TYPE_F_NE:
   case COpNumExprTuple::OP_TYPE_F_LT:
   case COpNumExprTuple::OP_TYPE_F_GE:
   case COpNumExprTuple::OP_TYPE_F_GT:
   case COpNumExprTuple::OP_TYPE_F_LE:
      size = 1;
      return true;
      break;
   // Operators where the size is equal to the sum of the first two size operands
   case COpNumExprTuple::OP_TYPE_U_MUL:
   case COpNumExprTuple::OP_TYPE_S_MUL:
   case COpNumExprTuple::OP_TYPE_CONC:
      if (op_expr->GetSizes()->ElementCount() >= 2)
      {
         size = SizeNodeToSize(op_expr->GetSizes()->ElementAt(0)) + SizeNodeToSize(op_expr->GetSizes()->ElementAt(1));
         return true;
      }
      else
         return false;
      break;
   // Operators where the size of the result is determined by the second size operand
   case COpNumExprTuple::OP_TYPE_S_EXT:
      if (op_expr->GetSizes()->ElementCount() >= 2)
      {
         size = SizeNodeToSize(op_expr->GetSizes()->ElementAt(1));
         return true;
      }
      else
         return false;
      break;
   // Operators where the size of the result is determined by the third size operand
   case COpNumExprTuple::OP_TYPE_F_TO_U:
   case COpNumExprTuple::OP_TYPE_F_TO_S:
      if (op_expr->GetSizes()->ElementCount() >= 3)
      {
         size = SizeNodeToSize(op_expr->GetSizes()->ElementAt(2));
         return true;
      }
      else
         return false;
      break;
   // Operators whose result sizes are 1 + the sum of the first two size operands
   case COpNumExprTuple::OP_TYPE_F_NEG:
   case COpNumExprTuple::OP_TYPE_F_ADD:
   case COpNumExprTuple::OP_TYPE_F_SUB:
   case COpNumExprTuple::OP_TYPE_F_MUL:
   case COpNumExprTuple::OP_TYPE_F_DIV:
   case COpNumExprTuple::OP_TYPE_U_TO_F:
   case COpNumExprTuple::OP_TYPE_S_TO_F:
      if (op_expr->GetSizes()->ElementCount() >= 2)
      {
         size = 1 + SizeNodeToSize(op_expr->GetSizes()->ElementAt(0))
              + SizeNodeToSize(op_expr->GetSizes()->ElementAt(1));
         return true;
      }
      else return false;
      break;
   // Operator whose result has a size given by 1 + the sum of the second and fourth
   // size operands
   case COpNumExprTuple::OP_TYPE_F_TO_F:
      if (op_expr->GetSizes()->ElementCount() >= 4)
      {
         size = 1 + SizeNodeToSize(op_expr->GetSizes()->ElementAt(1))
              + SizeNodeToSize(op_expr->GetSizes()->ElementAt(3));
         return true;
      }
      else return false;
   // Operators whose result has infinite size
   case COpNumExprTuple::OP_TYPE_B2N:
   case COpNumExprTuple::OP_TYPE_EXP2:
      size = Size::Infinity();
      return true;
      break;
   case COpNumExprTuple::OP_TYPE_SELECT:
      if (op_expr->GetSizes()->ElementCount() >= 3)
      {
         size = SizeNodeToSize(op_expr->GetSizes()->ElementAt(2)) - SizeNodeToSize(op_expr->GetSizes()->ElementAt(1)) + Size(1);
         return true;
      }
      else
         return false;
      break;
   }
   return false;
}

// Public members of IDConsistency - - - - - - - - - - - - - - - - - - - ->>

bool IDConsistency::onBeginVisit(const CGenericNode* node)
{
   if (node->IsType(CGenericNode::TYPE_FUNC_TUPLE))
   {
      if (functions->find(node) == functions->end())
         return false;
      else
         functions->erase(node);
   }
   node->AcceptVisitor(this);
   return true;
}

void IDConsistency::VisitFRefTuple(const CFRefTuple& fref)
{
   const CSymTabEntry * entry = symbol_table->Lookup(fref.GetKey());
   if (entry->IsExtern() && entry->GetIdentifier() != &fref)
   {
      stringstream message;
      message << "Reference to the imported fref " << entry->Name();
      ReportError(message.str(), fref.GetLine(), &fref);
   }
}

void IDConsistency::VisitLRefTuple(const CLRefTuple& lref)
{
   const CSymTabEntry * entry = symbol_table->Lookup(lref.GetKey());
   if (entry->IsExtern() && entry->GetIdentifier() != &lref)
   {
      stringstream message;
      message << "Reference to the imported lref " << entry->Name();
      ReportError(message.str(), lref.GetLine(), &lref);
   }
}

// Public members of FuncCallConsistency |- - - - - - - - - - - - - - - - - - - ->
bool FuncCallConsistency::onBeginVisit(const CGenericNode * node)
{
   TryToVisitAs<CFuncTuple>(node);
   TryToVisitAs<CCallStmtTuple>(node);
   return true;
}

// Check that no function exists both in imports and in func decls
void FuncCallConsistency::Visit(const CFuncTuple *func_tuple)
{
  // Extract the name of the function
  std::string func_id = func_tuple->Name();
  // Get the alf tuple the call tuple belongs to 
  CAlfTuple * alf_tuple = dynamic_cast<CAlfTuple *>(func_tuple->GetParent(CGenericNode::TYPE_ALF_TUPLE));
  assert(alf_tuple);
  // Extract the name of each imported lref 
  const CImportsTuple* imports = alf_tuple->GetImports();
  assert(imports);
  const CLRefList* lrefs = imports->GetLRefList();
  assert(lrefs);
  for(CLRefList::const_list_iterator lref = lrefs->ConstIterator(); lref != lrefs->InvalidIterator(); ++lref) {
    std::string lref_id = (*lref)->GetId();
    // Check if the function name is equal to the id of the imported lref 
    if(func_id == lref_id) {
      const CLabelTuple* label = func_tuple->GetLabel();
      assert(label);
      stringstream message;
      message << "Declared function: " << func_id << " also exists as imported lref";
      ReportError(message.str(), label->GetLine(), func_tuple);
    }
  }

  {
    // Check that there exists at least one return statement from the
    // function, and that the number of return values returned by a
    // function is the same at all return statements
    CAlfTreeFilter filter = CAlfTreeFilter(func_tuple);
    CAlfTreeFilter::NodeList return_stmts = filter.GetNodesOfType(CGenericNode::TYPE_RETURN_STMT_TUPLE);
    const CLabelTuple * func_label = func_tuple->GetLabel();
    if(return_stmts.size() == 0) {
      stringstream message;
      message << "Function " << func_id << " has no return statement";
      ReportError(message.str(), func_tuple->GetLine(), func_label);
    }
    else if(return_stmts.size() > 1) {
      CAlfTreeFilter::NodeList::iterator return_stmt_it = return_stmts.begin();
      const CReturnStmtTuple * first_return_stmt = dynamic_cast<const CReturnStmtTuple *>(*return_stmt_it);
      size_t first_nr_of_return_values = first_return_stmt->GetExprs()->ElementCount();
      for(return_stmt_it++; return_stmt_it != return_stmts.end(); return_stmt_it++) {
        const CReturnStmtTuple * other_return_stmt = dynamic_cast<const CReturnStmtTuple *>(*return_stmt_it);
        size_t other_nr_of_return_values = other_return_stmt->GetExprs()->ElementCount();
        // Check that the number of values returned are the same
        if(first_nr_of_return_values != other_nr_of_return_values) {
          stringstream message;
          message << "Function " << func_id << " has return statements with different amount of return values (" 
                  << first_nr_of_return_values << " and " << other_nr_of_return_values << ")";
          ReportError(message.str(), first_return_stmt->GetLine(), first_return_stmt, other_return_stmt->GetLine(), other_return_stmt);

        }
        // Check that the sizes of the corresponding return values are the same
        // else if(first_nr_of_return_values > 0) {
        //  alf::CExprList::const_list_iterator f_ret = first_return_stmt->GetExprs()->ConstIterator();
        //  alf::CExprList::const_list_iterator o_ret = other_return_stmt->GetExprs()->ConstIterator();
        //  unsigned int ret_index = 1;
        //  for( ; f_ret != first_return_stmt->GetExprs()->InvalidIterator() ; f_ret++, o_ret++, ret_index++) {
        //    if((*f_ret)->GetSizeOfEvaluatedExpr() != (*o_ret)->GetSizeOfEvaluatedExpr()) {
        //      stringstream message;
        //      message << "Function " << func_id << " has return statements with different sizes of return values (" 
        //              << "return value index " << ret_index << ")";
        //      ReportError(message.str(), other_return_stmt->GetLine(), other_return_stmt);
        //    }
        //  }
        // 
      }
    }
  }
}

// Check that function calls goes to existing functions
void FuncCallConsistency::Visit(const CCallStmtTuple *call_tuple)
{
  // Try to derive the name of the called function 
  const AExpr* label_expr = call_tuple->GetLabelExpr();
  if(label_expr->IsType(CGenericNode::TYPE_LABEL_TUPLE)) {

    // Derive the name and the key of the called function
    const CLabelTuple * label_tuple = dynamic_cast<const CLabelTuple *>(label_expr);
    CLRefTuple * called_lref = label_tuple->GetLRef();
    assert(called_lref);
    std::string called_func_name = called_lref->GetId();
    int called_func_key = called_lref->GetKey();
    
    // Get the alf tuple the call tuple belongs to
    CAlfTuple * alf_tuple = dynamic_cast<CAlfTuple *>(call_tuple->GetParent(CGenericNode::TYPE_ALF_TUPLE));
    assert(alf_tuple);

    // Check if the called func exists in the imports section
    bool func_exists_in_imports = false;
    int import_key = -1;
    {
      const CImportsTuple* imports = alf_tuple->GetImports();
      assert(imports);
      const CLRefList* lrefs = imports->GetLRefList();
      assert(lrefs);
      for(CLRefList::const_list_iterator lref = lrefs->ConstIterator(); lref != lrefs->InvalidIterator(); ++lref) {
        std::string lref_id = (*lref)->GetId();
        if(lref_id == called_func_name) {
          func_exists_in_imports = true;
          import_key = (*lref)->GetKey();
          break;
        }
      }
    }

    // Check if the function name is among the list of functions 
    bool func_exists_in_funcs = false;
    CFuncTuple * called_func = NULL;
    int func_key = -1;
    {
      const CFuncList* funcs = alf_tuple->GetFuncs();
      for(CFuncList::const_list_iterator func = funcs->ConstIterator(); func != funcs->InvalidIterator(); ++func) {
        std::string func_id = (*func)->Name();
        if(func_id == called_func_name) {
          called_func = (*func); 
          func_exists_in_funcs = true;
          const CLabelTuple* func_label = (*func)->GetLabel();
          CLRefTuple * func_lref = func_label->GetLRef();
          func_key = func_lref->GetKey();
          break;
        }
      }
    }

    // Check for errors
    if(!(func_exists_in_imports || func_exists_in_funcs)) {
      stringstream message;
      message << "Called function: " << called_func_name << " does not exists in imports nor in list of functions";
      ReportError(message.str(), label_expr->GetLine(), call_tuple);
    }
    if(func_exists_in_imports && func_exists_in_funcs) {
     stringstream message;
      message << "Called function: " << called_func_name << " exists both in imports and in list of functions";
      ReportError(message.str(), label_expr->GetLine(), call_tuple);
    } 
    if(func_exists_in_imports && import_key != called_func_key) {
      stringstream message;
      message << "Called function: " << called_func_name << " exists in imports, but have different keys";
      ReportError(message.str(), label_expr->GetLine(), call_tuple);
    }
    if(func_exists_in_funcs && func_key != called_func_key) {
      stringstream message;
      message << "Called function: " << called_func_name << " exists in func list, but have different keys";
      ReportError(message.str(), label_expr->GetLine(), call_tuple);
    }

    if(func_exists_in_funcs) { 

      // Check that the caller and the callee has the same number of
      // arguments and argument sizes
      
      // Get the number of arguments for the call stmt
      size_t nr_of_call_stmt_args = call_tuple->GetExprs()->ElementCount();
      // Get the number of arguments for the function
      size_t nr_of_func_args = called_func->GetArgs()->ElementCount();
      // Check that the number of arguments are equal
      if(nr_of_call_stmt_args != nr_of_func_args) {
        stringstream message;
        message << "Call to function: " << called_func_name << " with the wrong number of arguments (should be " << nr_of_func_args << ")";
        ReportError(message.str(), call_tuple->GetLine(), call_tuple);
      }
      else if(nr_of_call_stmt_args > 0) {
        // Check that the size of the calling arguments and the size
        // of the function arguments are equal
        alf::CArgDeclList::const_list_iterator f_arg = called_func->GetArgs()->ConstIterator();
        alf::CExprList::const_list_iterator c_arg = call_tuple->GetExprs()->ConstIterator();
        unsigned int arg_index = 1;
        while(f_arg != called_func->GetArgs()->InvalidIterator()) {
          if((*f_arg)->GetFrameSize()->GetSizeInBits() != (*c_arg)->GetSizeOfEvaluatedExpr()) {
            stringstream message;
            message << "Call to function: " << called_func_name 
                    << " with the wrong size of argument " << arg_index;
            ReportError(message.str(), call_tuple->GetLine(), call_tuple);
          }
          f_arg++;
          c_arg++;
          arg_index++;
        }
      }

      {
        // Check that the caller and the caller has the same number of
        // return values and return sizes
        CAlfTreeFilter filter = CAlfTreeFilter(called_func);
        CAlfTreeFilter::NodeList return_stmts = filter.GetNodesOfType(CGenericNode::TYPE_RETURN_STMT_TUPLE);

        // If there exists no return statement the error will be
        // reported by FuncCallConsistency::Visit(func_tuple)
        if(return_stmts.size() > 0) {
          // Check that the called function's and the callees return values. We only do this for
          // one of the return statements since they should all have the same shape (if not, it will
          // be detected by FuncCallConsistency::Visit(func_tuple)
          size_t nr_of_call_stmt_return_values = call_tuple->GetAddrExprs()->ElementCount();
          const CReturnStmtTuple * return_stmt = dynamic_cast<const CReturnStmtTuple *>(*(return_stmts.begin()));
          size_t nr_of_func_return_values = return_stmt->GetExprs()->ElementCount();

          // Check that the number of return values are correct
          if(nr_of_call_stmt_return_values != nr_of_func_return_values) {
            stringstream message;
            message << "Call to function: " << called_func_name 
                    << " with the wrong number of return values (should be " << nr_of_func_return_values << ")";
            ReportError(message.str(), call_tuple->GetLine(), call_tuple);
          }
          // Check that the sizes of the return values are the same
          // else if(nr_of_call_stmt_return_values > 0) {
          //  alf::CExprList::const_list_iterator f_ret = return_stmt->GetExprs()->ConstIterator();
          //  alf::CExprList::const_list_iterator c_ret = call_tuple->GetAddrExprs()->ConstIterator();
          //  unsigned int ret_index = 1;
          //  while(f_ret != return_stmt->GetExprs()->InvalidIterator()) {
          //    if((*f_ret)->GetSizeOfEvaluatedExpr() != (*c_ret)->GetSizeOfEvaluatedExpr()) {
          //      stringstream message;
          //      message << "Call to function: " << called_func_name 
          //              << " with the wrong size of return value " << ret_index;
          //      ReportError(message.str(), call_tuple->GetLine(), call_tuple);
          //    }
          //    f_ret++;
          //    c_ret++;
          //    ret_index++;
          //  }
          // }
        }
      }
    }
  }
}


// Public members of Unsupported |- - - - - - - - - - - - - - - - - - - ->

void Unsupported::VisitJumpStmtTuple(const CJumpStmtTuple & jump_stmt)
{
   const AExpr * label_expr = jump_stmt.GetLabelExpr();
   if (!label_expr->IsType(CGenericNode::TYPE_LABEL_TUPLE))
   {
      stringstream message;
      message << "Only jumps to static labels are supported at present";
      ReportError(message.str(), label_expr->GetLine(), &jump_stmt);
   }
}

void Unsupported::VisitScopeTuple(const CScopeTuple & scope)
{
   const CInitList * inits = scope.GetInits();
   if (inits->ElementCount() != 0)
   {
      stringstream message;
      message << "Initialization sections in scopes are not supported; "
                  "this should be removed from ALF";
      ReportError(message.str(), inits->GetLine(), inits);
   }
}
