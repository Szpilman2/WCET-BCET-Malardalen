/* $Id: AExpr.cpp 950 2009-09-01 10:52:28Z jjn08 $ */

#include "AExpr.h"
#include "CSize.h"

using namespace alf;
using namespace std;
using namespace std;

AExpr::
AExpr(COORD p_coord, CSize *p_size)
:  CGenericNode(p_coord),
   size(p_size)
{
   if (size)
      SetParent(size);
}

AExpr::
~AExpr()
{
   if (size)
      delete size;
}

CSize*
AExpr::
GetSize() const
{
   return size;
}

Size AExpr::GetSizeOfEvaluatedExpr() const 
{
   return GetSize()->GetSizeInBits();
}

AExpr::AExpr(const AExpr& obj)
:  CGenericNode(obj.coord),
   size((CSize*)obj.size->Copy())
{
   SetParent(size);
}

AExpr&
AExpr::
operator=(const AExpr& obj)
{
   return *this;
}

