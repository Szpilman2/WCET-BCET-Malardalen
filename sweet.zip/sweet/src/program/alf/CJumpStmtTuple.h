// $Id $

#ifndef ALF_JUMPSTMTTUPLE_H
#define ALF_JUMPSTMTTUPLE_H

#include "AStmt.h"
#include "AlfNodeVisitor.h"

namespace alf
{
class CLabelTuple;
class AExpr;
class CString;

/**
 * A node representing a jump to a label somewhere in the ALF-program.
 * It corresponds to the following rule in the ALF-grammar:
 * STMT -> { jump LABEL_EXPR }
 *
 * Should evaluate LABEL_EXPR and jump unconditionally to the resulting address.
 * This statement is strictly speaking superfluous, since it can be emulated
 * using switch, but is included for convenience.
 *
 * @see AExpr, CLabelTuple, AStmt
 */
class CJumpStmtTuple : public AStmt
{
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_JUMP_STMT_TUPLE.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord      The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param label_expr The label expressions representing the target label.
    * @param leaving_n  A nonnegative integer constant that specifies how many scope nesting levels the jump may exit from the current scope.
    * @param stmt_label An optional label that is attached to the statement.
    */
   CJumpStmtTuple(COORD coord, AExpr *label_expr, CString* leaving_n, CLabelTuple *stmt_label=NULL);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CJumpStmtTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   virtual CJumpStmtTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitJumpStmtTuple(*this);}

   /**
    * @return The label expressions representing the target label.
    */
   const AExpr* GetLabelExpr() const;

   const CString* GetLeavingN() const;

   /** 
    * @return Pointer to a constant string giving the name of the statement
    *         type, e.g., "store" or "switch"
    */
   virtual const char * StatementTypeName() const {return "jump";}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual CGenericNode::TYPE GetNodeType() const { return CGenericNode::TYPE_JUMP_STMT_TUPLE; }

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(CGenericNode::TYPE t) const {return t == CGenericNode::TYPE_JUMP_STMT_TUPLE || AStmt::IsType(t); }

   CJumpStmtTuple* Duplicate() { return Copy(); }
   void Uses(CAliasGraph *alias_graph, std::set<int> *uses) { }
   void Updates(CAliasGraph *alias_graph, std::set<int> *updated_vars) { }
   void Variables(CAliasGraph *alias_graph, std::set<int> *vars) { }
   void AsText(CTextBlock *text_block, int indentation) const { }
   void PrintAsDot(std::ostream &o) const { OnPrint(o, 0); }

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CJumpStmtTuple(const CJumpStmtTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CJumpStmtTuple& operator=(const CJumpStmtTuple&);

   /**
    * The target label.
    */
   AExpr *label_expr;

   CString* leaving_n;
};

}

#endif

