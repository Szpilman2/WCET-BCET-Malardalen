// $Id $

#ifndef ALF_CALLOCTUPLE_H
#define ALF_CALLOCTUPLE_H

#include "CGenericNode.h"
#include "AlfNodeVisitor.h"
#include "symtab/CSymTabIdentifier.h"

namespace alf
{
class CSize;
class CString;

/**
 * A node representing an allocation of a static data area of a frame of a certain SIZE (in bits).
 * With FREF_ID as the symbolic part of its frameref (at most one alloc per FREF_ID is allowed in DECLS).
 * The first SIZE is the size of the bitstring representation of the corresponding frameref.
 *
 * It represents the following rule in the ALF grammar:
 * ALLOC -> { alloc SIZE FREF_ID SIZE }
 *
 * @see CSize, CGenericNode.
 */

class CAllocTuple : public CGenericNode, public CSymTabIdentifier
{
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_ALLOC_TUPLE
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param size1   The size of the bitstring representation of the framereference.
    * @param fref_id The identifier of the frame.
    * @param size2   The size to alloc.
    */
   CAllocTuple(COORD coord, CSize* size1, CString* fref_id, CSize* size2);

   /**
    * Constructor, initializes the node as an macrocall.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_ALLOC_TUPLE
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord      The line and column numbers in the parsed file where the rule creating this node was found.
    * @param macro_call_tuple The macrocall node.
    */
   CAllocTuple(COORD coord, CMacroCallTuple* macro_call_tuple);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CAllocTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   virtual CAllocTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitAllocTuple(*this);}

   /**
    * @return The size of the bitstring representation of the frame.
    */
   const CSize* GetBitstringSize() const;

   /**
    * @return The identifier of the allocated frame.
    */
   const CString * GetFrefId() const;

   /**
    * Returns the size of the frame in bits, NOT lau.
    */
   const CSize* GetFrameSize() const;

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual CGenericNode::TYPE GetNodeType() const { return CGenericNode::TYPE_ALLOC_TUPLE; }

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(CGenericNode::TYPE t) const {return t == TYPE_ALLOC_TUPLE || CGenericNode::IsType(t); }

   std::string Name() const;
   std::string PrettifiedName() const;

   /**
    * Accept a visit from a SymTabIdentifierVisitor
    */
   virtual void AcceptVisitor(SymTabIdentifierVisitor * visitor) const {visitor->VisitAllocTuple(*this);}

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CAllocTuple(const CAllocTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CAllocTuple& operator=(const CAllocTuple&);

   /**
    * The size of the bitstring representation of the corresponding frame.
    * (That's what the ALF specification says, don't ask me what it means...)
    */
   CSize* bitstring_size;
   /**
    * The id of the allocated frame.
    */
   CString* fref_id;
   /**
    * The size of the frame to be allocated (in bits this time, NOT lau).
    */
   CSize* frame_size;
};

}

#endif
