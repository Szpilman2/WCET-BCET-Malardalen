#ifndef STATICPROGRAMCHECKING_H_INCLUDED
#define STATICPROGRAMCHECKING_H_INCLUDED

#include <vector>
#include <string>
#include <set>
#include <map>
#include <list>
#include <iostream>
#include <cassert>

namespace alf
{
class CAlfTuple;
class CGenericNode;
}
class CSymTabBase;
class CGenericFunction;

// -------------------------------------------------------.
// A class that holds the errors encountered when statically checking ALF program code
// -------------------------------------------------------
class StaticAlfError
{
public:
   // An error consist of a message, a line in which the error occurred, and a node in the ALF ast 
   StaticAlfError(const std::string & message, unsigned int line, const alf::CGenericNode * ast_node);
   // If the error involves one message, but two ALF lines and two ALF ast:s
   StaticAlfError(const std::string & message, unsigned int line1, const alf::CGenericNode * ast_node1,
                  unsigned int line2, const alf::CGenericNode * ast_node2);
   std::ostream & Print(std::ostream & os = std::cerr) const;
   std::string Message() const { return _message; }
   const alf::CGenericNode *GetNode() const { return _ast_node; }
   int Line() const { return _line; }

private:
   std::string _message;
   unsigned int _line;
   const alf::CGenericNode * _ast_node;
   bool _has_two_lines_and_ast_nodes;
   unsigned int _line2;
   const alf::CGenericNode * _ast_node2;
};

// For printing a certain statical error
inline std::ostream & operator <<(std::ostream & os, const StaticAlfError & static_alf_error)
   {return static_alf_error.Print(os);}

// -------------------------------------------------------
// A collection of errors found during static check of ALF program
// -------------------------------------------------------
class StaticAlfErrorCollection
{
public:
   // To print the set of errors
   friend std::ostream & operator <<(std::ostream & os, const StaticAlfErrorCollection & static_alf_error);

   // To get all errors referring to a certain node type
   template <typename NodeType> void AsNodes(std::list <NodeType*> &nodes)
   {
      for (std::map<std::string, std::list<StaticAlfError> >::iterator it=collection.begin(); it!=collection.end(); ++it)
      {
         std::list<StaticAlfError> *error_list = &it->second;
         for (std::list<StaticAlfError>::iterator node_it=error_list->begin(); node_it!=error_list->end(); ++node_it)
         {
            const NodeType *node = dynamic_cast<const NodeType *>(node_it->GetNode());
            if (node)
            {
               nodes.push_back(node);
            }
         }
      }
   }

   // To get the number of errors held by the collection
   unsigned size() { return (unsigned)collection.size(); }

   // To add an error to the collection
   void insert(StaticAlfError error) { collection[error.Message()].push_back(error); }

private:
   std::map<std::string, std::list<StaticAlfError> > collection;
};

// -------------------------------------------------------
// Functions giving the type of checks that can be performed
// -------------------------------------------------------
void PerformSizeCheck(alf::CAlfTuple & program, StaticAlfErrorCollection & reported_errors);
void PerformFuncCallCheck(alf::CAlfTuple & program, StaticAlfErrorCollection & reported_errors);
// void PerformParsedProgramCheck(alf::CAlfTuple & program, StaticAlfErrorCollection & reported_errors);
void CheckUnresolvedReferences(alf::CAlfTuple & program, std::vector<CGenericFunction*> &functions, 
                               const CSymTabBase * symbol_table, StaticAlfErrorCollection & reported_errors);
void CheckNoImportExportDuplicates(alf::CAlfTuple & program, StaticAlfErrorCollection & reported_errors);

#endif   // STATICPROGRAMCHECKING_H_INCLUDED

