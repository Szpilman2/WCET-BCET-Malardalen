// $Id $

#ifndef ALF_CFUNCTUPLE_H
#define ALF_CFUNCTUPLE_H

#include "CGenericNode.h"
#include "AlfNodeVisitor.h"
#include "program/CGenericFunction.h"
#include <string>
#include <vector>
#include "program_state/Size.h"

class CGenericStmt;

namespace alf
{
class CArgDeclList;
class CScopeTuple;
class CLabelTuple;

/**
 * A node representing a function.
 * Each function has a label = name, defined through the FREF_ID.
 * Frames allocated in ARG_DECLS hold actual arguments, after
 * evaluation (call by value). The arguments are provided in a
 * call statement.
 *
 * It corresponds to the following rule in the ALF-grammar:
 * FUNC -> { func LABEL ARG_DECLS GS_SCOPE }
 *
 * @see CArgDeclList, CScopeTuple, CGenericNode
 */
class CFuncTuple : public CGenericNode, public CGenericFunction
{
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_FUNC_TUPLE
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param label   The label (or name) representing the function (to be used when jumping to/calling the function).
    * @param args    The actual arguments, after evaluation (call by value).
    * @param scope   A scope, with statements that should be executed.
    */
   CFuncTuple(COORD coord, CLabelTuple* label, CArgDeclList* args, CScopeTuple* scope);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CFuncTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   virtual CFuncTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitFuncTuple(*this);}

   /**
    * @return The label (or name) representing the function (to be used when jumping to/calling the function).
    */
   const CLabelTuple* GetLabel() const;

   /**
    * @return The name of the function, that is the label's lref's id.
    */
   std::string Name() const;

   /**
    * @return The unmangled name of the function.
    */
   std::string PrettifiedName() const;

   unsigned Key() const;
   void AsText(CTextBlock *text_block, int indentation) const { (void)text_block; (void)indentation; }

   /** @return A pointer to a new flow graph representing the intraprocedural flow of this ALF function.
                The memory belongs to the caller.
    */
   std::unique_ptr<CFlowGraph> CreateFlowGraph() const;

   /** Get all statements of the function. Note that some statements may be scope statements
       containing a set of statements by themselves. The statement objects are owned by ALF, not
       by the caller.
    */
   void Stmts(std::vector<CGenericStmt*> *stmts) const { GetStmtsInFunctionScope(stmts); };
   void GetStmtsInFunctionScope(std::vector<CGenericStmt*> *stmts) const;

   /** Get all statements of the function of a certain statement type. The statement objects
       are owned by ALF, not by the caller.
    */
   void GetStmtsInFunctionScope(std::vector<CGenericStmt*> *stmts, CGenericNode::TYPE stmt_type) const;

   /** Get all statements of the function scope or of underlying scopes. The scope statements
       which may include other statements will be returned as well.
       The statement objects are owned by ALF, not by the caller.
    */
   void GetStmtsInFunctionScopeAndSubordinateScopes(std::vector<CGenericStmt*> *stmts) const;

   /** Get all statements of the function scope or of underlying scopes of a certain statement type.
       The statement objects are owned by ALF, not by the caller.
    */
   void GetStmtsInFunctionScopeAndSubordinateScopes(std::vector<CGenericStmt*> *stmts, CGenericNode::TYPE stmt_type) const;

   /**
    * @return The formals, after evaluation (call by value).
    */
   const CArgDeclList* GetArgs() const;

   /**
    * @return The scope, with statements that should be executed.
    */
   const CScopeTuple* GetScope() const;

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_FUNC_TUPLE; }

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_FUNC_TUPLE || CGenericNode::IsType(t); }

   /**
    * To get the number of return values that the function has
    */
   unsigned int NrOfReturnValues() const;

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CFuncTuple(const CFuncTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CFuncTuple& operator=(const CFuncTuple&);

   /**
    * The function's name.
    */
   CLabelTuple* label;

   /**
    * The function's arguments.
    */
   CArgDeclList* args;

   /**
    * The function's scope (statements).
    */
   CScopeTuple* scope;

   std::string name;
};

}

#endif

