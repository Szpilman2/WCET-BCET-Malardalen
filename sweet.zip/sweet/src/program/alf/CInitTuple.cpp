// $Id $

#include "CInitTuple.h"
#include "CRefTuple.h"
#include "AVal.h"
#include <iostream>
#include <cassert>

using namespace alf;
using namespace std;

CInitTuple::
CInitTuple(COORD coord, CRefTuple* p_ref, AVal* p_val, InitOption p_init_option)
:  CGenericNode(coord),
   ref(p_ref),
   val(p_val),
   init_option(p_init_option)
{
   SetParent(ref);
   SetParent(val);
}

CInitTuple::
CInitTuple(COORD coord, CMacroCallTuple* macro_call_tuple)
:  CGenericNode(coord, macro_call_tuple),
   ref(NULL),
   val(NULL)
{
}

CInitTuple::
~CInitTuple()
{
   if (ref)
      delete ref;
   if (val)
      delete val;
}

CInitTuple::
CInitTuple(const CInitTuple& obj)
:  CGenericNode(obj.coord),
   ref(obj.ref->Copy()),
   val(dynamic_cast<AVal*>(obj.val->Copy())),
   init_option(obj.init_option)
{
   SetParent(ref);
   SetParent(val);
}

CInitTuple*
CInitTuple::
Copy() const
{
  std::cout << "CInitTuple::Copy() begin original:\n";
  PrintWithEndl(std::cout, 0);
  CInitTuple * it =  new CInitTuple(*this);
  std::cout << "CInitTuple::Copy() end Copy became:\n";
  it->PrintWithEndl(std::cout, 0);
  assert(it != this);
  return it;
}

CInitTuple&
CInitTuple::
operator=(const CInitTuple& obj)
{
   return *this;
}

void
CInitTuple::
OnPrint(ostream& stream, int indent) const
{
   PrintIndent(stream, indent);
   stream << "{ init ";
   ref->PrintWithEndl(stream, 0);
   ++indent;
   val->PrintWithEndl(stream, indent);
   switch (init_option)
   {
      case VOLATILE:
         PrintIndent(stream, indent);
         stream << "volatile\n";
         break;
      case READ_ONLY:
         PrintIndent(stream, indent);
         stream << "read_only\n";
         break;
      case NONE:
         break;
   }
   --indent;
   PrintIndent(stream, indent);
   stream << "}";
}


const CRefTuple*
CInitTuple::
GetRef() const
{
   return ref;
}

const AVal*
CInitTuple::
GetVal() const
{
   return val;
}

CInitTuple::InitOption
CInitTuple::
GetInitOption() const
{
   return init_option;
}

CGenericNode* 
CInitTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CInitTuple(GetCoord(), 
                         static_cast<CRefTuple*>(ref->Expand(helper)),
                         dynamic_cast<AVal*>(val->Expand(helper)),
                         init_option);
}

