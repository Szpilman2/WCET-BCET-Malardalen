

#ifndef ALF_CALFTREEFILTER_H
#define ALF_CALFTREEFILTER_H

#include "CGenericNode.h"
#include "CAlfTreeTraversor.h"
#include <map>
#include <vector>

namespace alf
{
   /** @class CAlfTreeFilter
    * Collects all nodes in an ALF tree and provides them as flat list
    * filtered or unfiltered.
    */
   class CAlfTreeFilter : public CAlfTreeTraversor::INodeVisitor
   {
   public:
      typedef std::vector<const CGenericNode*> NodeList;
      
      /** Collects all nodes in a tree.
       * @param node The root node of the tree to collect nodes from. The type is
       *    either of CAlfTuple, CFuncTuple, AStmt or AExpr.
       * @param traversor Traversor
       */
      CAlfTreeFilter(const CGenericNode* node, CAlfTreeTraversor* traversor=NULL);
      virtual ~CAlfTreeFilter();
      
      virtual bool onBeginVisit(const CGenericNode* node);
      virtual void onEndVisit(const CGenericNode* node) {}

      /** 
       * @return The previously collected nodes as a node list.
       */
      const NodeList GetAllNodes();

      /** Filters out a subset of the previously collected nodes.
       * @param node_type The type of nodes to be collected.
       * @return The filtered nodes as a node list.
       */
      const NodeList GetNodesOfType(CGenericNode::TYPE node_type);

   private:
      typedef std::map<CGenericNode::TYPE, NodeList> NodeTypeFilterMap;
      
      NodeTypeFilterMap filtered_nodes;
      NodeList all_nodes; // TODO: shouldn't this always be the same as filtered_nodes[CGenericNode::TYPE_GENERIC_NODE]?
   };
}

#endif
