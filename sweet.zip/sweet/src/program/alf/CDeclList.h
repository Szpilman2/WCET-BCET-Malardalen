// $Id $

#ifndef ALF_CDECLLIST_H
#define ALF_CDECLLIST_H

#include "CListNode.h"
#include "AlfNodeVisitor.h"

namespace alf
{
class CAllocTuple;
class ASTFilter;

/**
 * A node containing a list of allocations.
 * It represents the following rule in the ALF grammar:
 * DECLS -> { decls ALLOC* }
 *
 * @see CAllocTuple, CListNode
 */
class CDeclList : public CListNode<CAllocTuple>
{
public:
   /**
    * Constructor, creates a list node from a vector of allocations.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_DECL_LIST
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param list  A vector of allocations
    */
   CDeclList(const COORD& coord, const std::vector<CAllocTuple*>& list=std::vector<CAllocTuple*>());
   
   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CDeclList();   
   
   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to 
    *          deallocate the memory.
    */
   virtual CDeclList* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitDeclList(*this);}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_DECL_LIST; }


   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_DECL_LIST || CListNode<CAllocTuple>::IsType(t); }

   /**
    * Prints to @a o the declarations of this list for which filter->IncludeAllocTuple() returns @c true
    */
   void PrintFiltered(std::ostream& o, int indentation, ASTFilter* filter) const;

protected:
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
};
   
}

#endif

