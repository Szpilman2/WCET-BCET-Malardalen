// $Id $

#ifndef ALF_CFUNCLIST_H
#define ALF_CFUNCLIST_H

#include "CListNode.h"
#include "AlfNodeVisitor.h"
#include <ostream>

namespace alf
{
class CFuncTuple;
class ASTFilter;

/**
 * A node containing a list of function declarations.
 * This class inherits from CListNode, and corresponds to the following rule in the ALF grammar:
 * FUNCS -> { funcs FUNC*}
 *
 * @see CFuncTuple
 */
class CFuncList : public CListNode<CFuncTuple>
{
public:
   /**
    * Constructor, creates a list node from a vector of function declarations.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_FUNC_LIST
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param list  A vector of function declarations.
    */
    CFuncList(const COORD& coord, const std::vector<CFuncTuple*>& list=std::vector<CFuncTuple*>());
    
    /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CFuncList();
   
   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to 
    *          deallocate the memory.
    */
   virtual CFuncList* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitFuncList(*this);}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_FUNC_LIST; }

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_FUNC_LIST || CListNode<CFuncTuple>::IsType(t); }

   /**
    * Prints the functions of this list for which filter->IncludeFuncTuple() returns @c true to @a o
    */
   void PrintFiltered(std::ostream& o, int indentation, ASTFilter* filter) const;

   /**
    * Remove all functions in the list whose names are found in @a names
    */
   void RemoveNamedFunctions(const std::set<std::string>& names);

protected:
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
};

}

#endif

