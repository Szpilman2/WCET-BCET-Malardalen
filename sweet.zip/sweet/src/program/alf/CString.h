// $Id $

#ifndef ALF_CSTRING_H
#define ALF_CSTRING_H

#include "CGenericNode.h"
#include "AlfNodeVisitor.h"
#include "CException.h"
#include <sstream>

namespace alf
{

class CString: public alf::CGenericNode
{
public:
   /**
    * @param coord Source file coordinates for the node
    * @param str   String data with escape sequences unexpanded and possible enclosing quotes still present
    */
   CString(COORD coord, const std::string& str);

   /**
    * Constructor, initializes the node as an macrocall.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_STRING
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord            The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param macro_call_tuple The macrocall node.
    */
   CString(COORD coord, CMacroCallTuple* macro_call_tuple);

   /**
    * Constructor, initializes the node as an macro formal-argument-identifier string.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_STRING
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord               The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param macro_formal_arg    The macro formal-argument-identifier.
    */
   CString(COORD coord, CMacroFormalArg* macro_formal_arg);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CString();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   virtual CString* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitString(*this);}

   /**
    * Returns the string, with escape sequences expanded
    */
   const std::string &Get() const;

   /**
    * Returns the string as it appeared in the source file
    */
   const std::string &GetSourceRep() const;

   /**
    * Updates the string data
    * @param str String data with escape sequences unexpanded and possible enclosing quotes still present
    */
   void Set(const std::string& new_string);

   template <typename T>
   T Convert() const throw (CException);

   /**
    * Determine if the contents of both strings are equal.
    */
   bool operator==(const CString& str) const;

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_STRING; } 

   /** 
    * Checks if the number has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_STRING || CGenericNode::IsType(t); }

   /**
    * Updates the string.
    * @param prefix A string to prefix the current string with.
    */
   void Mangle(std::string prefix) { str = prefix + str; }

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:

   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CString(const CString&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CString& operator=(const CString&);

   /**
    * Expands escaped sequences in @a str, and, if present, removes enclosing quotes
    * @pre @a str is syntactically correct (typically ensured by the lexical analysis).
    */
   static std::string ResolveString(const std::string& str);

   std::string str, src_rep;
};

template <typename T>
inline
T
CString::
Convert() const throw (CException)
{
   std::stringstream ss;
   ss << str;

   T val;
   if (!(ss >> val))
      throw CException("Couldn't convert std::string to given type!");

   return val;
}

}

#endif
