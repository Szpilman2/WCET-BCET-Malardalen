// $Id $

#include "CIntNumValTuple.h"
#include "CSize.h"
#include "CNumber.h"
#include "CString.h"

using namespace std;
namespace alf
{

CIntNumValTuple::
CIntNumValTuple(COORD coord, INT_TYPE p_num_val_type, CSize* size, CString* p_number)
:  CGenericNode(coord),
   ANumVal(coord, size),
   number(NULL),
   num_val_type(p_num_val_type)
{
   if (size->GetSizeInBits() <= sizeof(long long)*8) // TODO: why is this necessary?
      number = new CIntegerNumber(p_number, p_num_val_type);
   else
   {
      assert("No support yet for sizes bigger than sizeof(long long)*8" == 0);
   }
   SetParent(p_number);
}

CIntNumValTuple::
CIntNumValTuple(COORD coord, CSize* size, CString* p_number)
:  CGenericNode(coord),
   ANumVal(coord, size),
   number(NULL),
   num_val_type(DEC_SIGNED)
{
   number = new CIntegerNumber(p_number, DEC_SIGNED);
   SetParent(p_number);
}

CIntNumValTuple::
CIntNumValTuple(COORD coord, CMacroCallTuple* macro_call_tuple)
:  CGenericNode(coord, macro_call_tuple),
   ANumVal(coord, NULL),
   number(NULL)
{

}

CIntNumValTuple::
CIntNumValTuple(COORD coord, CMacroFormalArg* macro_formal_arg)
:  CGenericNode(coord, macro_formal_arg),
   ANumVal(coord, NULL),
   number(NULL)
{

}

CIntNumValTuple::
CIntNumValTuple(const CIntNumValTuple& obj)
:  CGenericNode(obj.coord),
//   AExpr(obj.coord, obj.size, obj.type),
   ANumVal(obj.coord, obj.size->Copy()),
   number(obj.number->Copy()),
   num_val_type(obj.num_val_type)
{
}

CIntNumValTuple::
~CIntNumValTuple()
{
   if (number)
      delete number;
}

CIntNumValTuple*
CIntNumValTuple::
Copy() const
{
   return new CIntNumValTuple(*this);
}

CIntNumValTuple&
CIntNumValTuple::
operator=(const CIntNumValTuple& obj)
{
   return *this;
}

void
CIntNumValTuple::
OnPrint(ostream& stream, int indent) const
{
   PrintIndent(stream, indent);
   stream << "{ ";
   switch (num_val_type)
   {
      case HEX:
         stream << "hex_val ";
         break;
      case DEC_SIGNED:
         stream << "dec_signed ";
         break;
      case DEC_UNSIGNED:
         stream << "dec_unsigned ";
         break;
      case BIN:
         stream << "bin_val ";
         break;
   }
   CSize * size = GetSize();
   size->Print(stream, 0);
   stream << " ";
   number->Print(stream, 0);
   stream << " }";
}

CIntegerNumber*
CIntNumValTuple::
GetNumber()
const
{
   return number;
}

CIntNumValTuple::INT_TYPE
CIntNumValTuple::
GetNumberType()
{
   return num_val_type;
}

bool
CIntNumValTuple::
IsEqual(const CIntNumValTuple* other_val)
{
  if(other_val == this) {
    return true;
  }
  else {
    return (number->IsEqual(other_val->number) && 
	    size->GetSizeInBits() == other_val->size->GetSizeInBits());
  }

}
   
CGenericNode* 
CIntNumValTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CIntNumValTuple(GetCoord(), 
                              num_val_type, 
                              static_cast<CSize*>(size->Expand(helper)),
                              static_cast<CString*>(number->GetValueAsString()->Expand(helper)));
}
   
}
