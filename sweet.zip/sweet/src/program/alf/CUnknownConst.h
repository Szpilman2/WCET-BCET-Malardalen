// $Id $

#ifndef ALF_CUNKNOWNCONST_H
#define ALF_CUNKNOWNCONST_H

#include "AConst.h"
#include "AlfNodeVisitor.h"

namespace alf
{

class CUnknownConst: public AConst
{
public:
  /**
   * Constructor, initializes the node as an macrocall.
   * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_UNKNOWN_CONST
   * The class is responsible to deallocate all the arguments.
   *
   * @param coord            The line and column numbers the in the parsed file where the rule creating this node was found.
   * @param macro_call_tuple The macrocall node.
   */
  CUnknownConst(COORD coord, CMacroCallTuple* macro_call_tuple);
  
  /**
   * Constructor, initializes the node as an macro formal-argument-identifier string.
   * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_UNKNOWN_CONST
   * The class is responsible to deallocate all the arguments.
   *
   * @param coord             The line and column numbers the in the parsed file where the rule creating this node was found.
   * @param macro_formal_arg  The macro formal-argument-identifier.
   */
  CUnknownConst(COORD coord, CMacroFormalArg* macro_formal_arg);
  
  /**
   * Deallocates all the memory that the node is using.
   *
   */
  virtual ~CUnknownConst();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
  virtual CUnknownConst* Copy() const;
  
   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitUnknownConst(*this);}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_UNKNOWN_CONST; } 

  /** 
   * Checks if the number has a certain type. Should be overwritten by subclasses.
   * @return  true or false.
   */
  virtual bool IsType(TYPE t) const {return t == TYPE_UNKNOWN_CONST || AConst::IsType(t); }
  
protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   
  /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
  CUnknownConst(const CUnknownConst&);
  
  /**
   * Assignment operator which is overloaded so no mistakes is made.
   * @return  A reference to this node.
   */
  CUnknownConst& operator=(const CUnknownConst&);
};

}

#endif

