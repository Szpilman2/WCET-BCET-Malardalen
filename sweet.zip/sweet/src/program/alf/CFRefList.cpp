// $Id $

#include "CFRefList.h"
#include "CFRefTuple.h"
#include "CListNode.inl"
#include <set>
 
using namespace std;
using namespace alf;

CFRefList::
CFRefList(const COORD& coord,
          const vector<CFRefTuple*>& p_list)
:  CGenericNode(coord),
   CListNode<CFRefTuple>(coord, "frefs", p_list)
{
}

CFRefList::
~CFRefList()
{
}

CFRefList*
CFRefList::
Copy() const
{
   return new CFRefList(*this);
}

void
CFRefList::
LinkWithFilter(CFRefList &other, const CFRefList &filter, string (*Unmangle)(string))
{
   Link(other);

   set<string> existing_identifiers;
   for (vector<CFRefTuple*>::const_iterator fit=filter.list.begin(); fit!=filter.list.end(); ++fit)
      existing_identifiers.insert(Unmangle((*fit)->Name()));

   for (vector<CFRefTuple*>::iterator it=list.begin(); it!=list.end();) {
      CFRefTuple *fref_tuple = *it;
      bool match = existing_identifiers.find(Unmangle(fref_tuple->Name())) != existing_identifiers.end();
      if (match) {
         delete fref_tuple;
         it = list.erase(it);
      } else {
         ++it;
      }
   }
}

void CFRefList::RemoveNamedFRefs(const std::set<std::string>& names)
{
	if (names.size() == 0)
		return;
   for (vector<CFRefTuple*>::iterator it=list.begin(); it!=list.end();) {
      CFRefTuple *fref_tuple = *it;
      bool match = names.find(fref_tuple->Name()) != names.end();
      if (match) {
         delete fref_tuple;
         it = list.erase(it);
      } else {
         ++it;
      }
   }
}

CGenericNode*
CFRefList::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   const std::vector<CFRefTuple*> expandedList = ExpandList(helper);
   return new CFRefList(GetCoord(), expandedList);
}

template class alf::CListNode<CFRefTuple>;
