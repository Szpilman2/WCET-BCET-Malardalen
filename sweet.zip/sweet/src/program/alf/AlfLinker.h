// Author: Linus Kaellberg, linus.kallberg@mdh.se

#ifndef ALFLINKER_H_INCLUDED
#define ALFLINKER_H_INCLUDED

#include <vector>
#include <string>
#include <map>
#include <algorithm>
#include <set>

class AlfLinkTest;

namespace alf
{
class CAlfTuple;
class CString;
class LinkLog;

class AlfLinker
{
   friend class ::AlfLinkTest;

public:
   /** Link the programs in @a linked_alf_tuples. After the call, @a linked_alf_tuples will contain only
      the resulting linked program. @a Unmangle should point to a function
      that restores mangled identifiers. */
   static void Link(std::vector<CAlfTuple*>& linked_alf_tuples, bool melmac_patch, 
      bool remove_dupl_exports, LinkLog& link_log);

private:
   class IdDatabase;

   /** An entry in an identifier database (the class IdDatabase), holding information about a particular identifier in a
      program. It holds a list of pointers to all nodes (of type CString) of the AST that need to be updated 
      in case the identifier is renamed. All members are private because they should only be
      referenced from the friend class AlfLinker::IdDatabase. */
   class IdDatabaseEntry
   {
      friend class AlfLinker::IdDatabase;
      friend class ::AlfLinkTest;

   private:
      std::vector<CString*> string_nodes;

      /** Add a CString node to the list of nodes */
      void AddStringNode(CString* string_node) {string_nodes.push_back(string_node);}

      /** Reset all string nodes in the list to store the string @a new_string */
      void ResetStringNodes(const std::string& new_string);

      /** Swaps the contents of this entry with @a other in an efficient way */
      void Swap(IdDatabaseEntry& other) {string_nodes.swap(other.string_nodes);}
   };

   /** Identifier database, that holds a mapping from identifier names to lists of
      AST nodes. The AST nodes associated with an identifier are those that need
      to be updated if the identifier changes name. This makes renaming identifiers
      efficient. */
   class IdDatabase : public std::map<std::string, IdDatabaseEntry>
   {
   public:
      /** Add the AST node @a string_node to the list associated with @a identifier */
      void Insert(const std::string& identifier, CString* string_node)
         {operator [](identifier).AddStringNode(string_node);}

      /** Rename the identifier @a old_id to @a new_id, which means the CString objects associated
         with @a old_id are all reset to @a new_id, and the database entry is replaced by
         a new entry that maps the @a new_id to the list of updated nodes. */
      void RenameId(const std::string& old_id, const std::string& new_id);
   };

   /** Help structure that wraps an ALF program undergoing linking and holds additional information
      about the program that are useful during the linking process. */
   class LinkedAlfProgram
   {
      friend class ::AlfLinkTest;

   public:
      LinkedAlfProgram() : ast(0) {}

      ~LinkedAlfProgram();

      /** Initialize this instance with the program @a ast. The instance takes over ownership of the 
         AST. @a Unmangle should point to a function that restores mangled identifiers. */
      void Initialize(CAlfTuple& ast);

      /** Get access to the AST */
      const CAlfTuple* AccessAST() const {return ast;}

      /** Retrieve the AST stored in this instance. This means that the instance gives up ownership to
         the AST and all additional information about the AST is cleared. */
      CAlfTuple* GetAST();

      /** Apply the melmac patch that unmangles (removes the ::<number> suffix that melmac adds to all identifiers)
         all exported and imported identifiers. Renamed identifiers are recorded in @a link_log. */
      void ApplyMelmacPatch(LinkLog& link_log);

      /** Checks that no identifier is exported by more than one program in
         @a linked_programs. Throws a runtime_error if this condition is not met. */
      static void ControlCorrectnessOfExports(const std::vector<LinkedAlfProgram>& linked_programs);

      /** Add to @a local_frefs_out the names of all local frefs in this program, which means frefs
         that are local to the scope of some function */
      void GetLocalFRefs(std::set<std::string>& local_frefs_out) const;

      /** Add to @a exported_frefs_out the names of all frefs exported from this ALF program */
      void GetExportedFRefs(std::set<std::string>& exported_frefs_out) const;

      /** Add to @a exported_lrefs_out the names of all lrefs exported from this ALF program */
      void GetExportedLRefs(std::set<std::string>& exported_lrefs_out) const;

      /** Add to @a imported_frefs_out the names of all frefs imported by this program */
      void GetImportedFRefs(std::set<std::string>& imported_frefs_out) const;

      /** Add to @a imported_lrefs_out the names of all lrefs imported by this program */
      void GetImportedLRefs(std::set<std::string>& imported_lrefs_out) const;

      /** For each program in @a linked_programs, remove exported function definitions whose names
         clash with exported functions in any other program in @a linked_programs. This means that
         the node in the exports section as well as the subtree for the function definition are removed
         from the AST. This is only done if a special option is given to sweet, because it is
         an error to have multiple definitions of the same function. */
      static void RemoveDuplicateExports(std::vector<LinkedAlfProgram>& linked_programs);

      /** Rename all private identifiers of this program (i.e., global identifiers that are not exported
         and not imported) that clash with the global identifiers in @a global_frefs and @a global_lrefs.
         If some identifier needs to be renamed, the new name should not clash with any identifier
         in @a local_frefs either. Unique identifiers (including renamed ones) are added to the two sets for
         global identifiers so they can be used in other calls to the same function on other LinkedAlfProgram objects.
         @a mangling_number is used to create suffixes for mangled names. As a suggestion, this number should be different
         for each LinkedAlfProgram. */
      void RenameClashingPrivateIds(std::set<std::string>& global_frefs, std::set<std::string>& global_lrefs,
         const std::set<std::string>& local_frefs, int mangling_number, LinkLog& link_log);

      /** Run through the imports section of this program and remove the imported frefs whose names are
         present in @a frefs, and the imported lrefs whose names are found in @a lrefs. Note that the 
         actual AST nodes are removed. */
      void RemoveNamedImports(const std::set<std::string>& frefs, const std::set<std::string>& lrefs);

      /** Add all imports, exports, decls, inits, and functions from @a linked_in to this program,
         and remove them from @a linked_in. All name resolution is assumed to have already been
         taken care of. */
      void Merge(LinkedAlfProgram& linked_in);

   private:
      CAlfTuple* ast;
      IdDatabase exported_frefs, imported_frefs, private_frefs;
      IdDatabase exported_lrefs, imported_lrefs, private_lrefs;

      // The names of all local frefs
      std::set<std::string> local_frefs;

      /** Part of initialization, where the AST is traversed and the IdDatabase's are built up */
      void CollectIds();

      /** Rename all private ids (i.e., identifiers that are globally defined in this program but are not
         exported) so they don't collide with any identifier in @a collision_space. In case any identifier
         is renamed, the new name should not clash with any name in @a additional_coll_space either. If it
         does, it must be remangled until it doesn't collide with any identifier from @a collision_space or
         @a additional_coll_space. The function pointer @a add_rename_func is either 0 or can be used
         to record in the @a link_log that an identifier has been renamed. */
      void RenameClashingPrivateIdsImpl(IdDatabase& private_ids, std::set<std::string>& collision_space, 
         const std::set<std::string>& additional_coll_space, int mangling_number, LinkLog& link_log, 
         void (LinkLog::*add_rename_func)(const std::string&, const std::string&, const std::string&) = 0);

      /** Mangle @a id until it is no longer included in @a id_set. @a mangling_number is used to create a name suffix.
         @return @c true if @a id was changed (it needed mangling), otherwise @c false */
      static bool MangleId(std::string& id, const std::set<std::string>& id_set, int mangling_number);
   };

   /** Perform the part of the linking process where identifiers are renamed */
   static void PerformIdentifierRenaming(std::vector<LinkedAlfProgram>& linked_programs,
      std::set<std::string>& exported_frefs, std::set<std::string>& exported_lrefs,
      bool melmac_patch, bool remove_dupl_exports, LinkLog& link_log);

   /** Perform the part of the linking process where the ASTs are restructured. This invalidates
      all symbol table information and IdDatabases. */
   static void PerformASTRestructurings(std::vector<LinkedAlfProgram>& linked_programs,
      const std::set<std::string>& exported_frefs, const std::set<std::string>& exported_lrefs,
      bool remove_dupl_exports);

   /** Checks that the programs in @a linked_programs can be linked together. Throws a runtime_error
      in case they cannot. */
   static void ControlCorrectness(const std::vector<LinkedAlfProgram>& linked_programs, bool remove_dupl_exports);

   /** Checks that all programs in @a linked_programs have the same LAU, and throws a
      runtime_error if not */
   static void ControlCorrectnessOfLAU(const std::vector<LinkedAlfProgram>& linked_programs);

   /** Checks that all programs in @a linked_programs have the same endianness, and throws a runtime_error if not */
   static void ControlCorrectnessOfEndianness(const std::vector<LinkedAlfProgram>& linked_programs);
};


/** Class used for logging manipulation of programs */
class LinkLog
{
public:
    
   /** Maps identifiers to their new names */
   class Renames : private std::map<std::string, std::string>
   {
   public:
      
      // default constructor
      Renames();
      
      typedef std::map<std::string, std::string> BaseContainer;

      using BaseContainer::iterator;

      using BaseContainer::const_iterator;

      bool GetRename(std::string& id) const
      {
         const_iterator found_id = find(id);
         if (found_id == end())
            return false;
         id = found_id->second;
         return true;
      }

      using BaseContainer::operator [];

      using BaseContainer::begin;

      using BaseContainer::end;

      bool operator ==(const Renames& other) const
         {return static_cast<const BaseContainer&>(*this) == other;}
   };

   /** Add information to the log about the renaming of @a id_before to @a id_after in the program
      whose file name is @a alf_file_name */
   void AddGlobalLRefRename(const std::string& alf_file_name, const std::string& id_before,
      const std::string& id_after);

   /** Returns all renamings of the Alf program whose file name is @a alf_file_name */
   const Renames& GetLRefRenames(const std::string& alf_file_name) const 
   {
      FileToRenames::const_iterator found_renames = file_to_renamed_lrefs.find(alf_file_name);
      if (found_renames == file_to_renamed_lrefs.end())
         return empty_renames;
      return found_renames->second;
   }

   bool operator ==(const LinkLog& other) const {return file_to_renamed_lrefs == other.file_to_renamed_lrefs;}

   bool operator !=(const LinkLog& other) const {return !(*this == other);}

private:
   typedef std::map<std::string, Renames> FileToRenames;

   static const Renames empty_renames;

   FileToRenames file_to_renamed_lrefs;
};

}

#endif   // #ifndef ALFLINKER_H_INCLUDED
