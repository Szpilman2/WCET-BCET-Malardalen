// $Id $

#include "CReturnStmtTuple.h"
#include "CLabelTuple.h"
#include "AExpr.h"
#include "CExprList.h"
#include "internal.h"

using namespace alf;
using namespace std;

CReturnStmtTuple::
CReturnStmtTuple(COORD coord, CExprList* p_exprs, CLabelTuple *lbl)
:  CGenericStmt(GS_RETURN),
   AStmt(coord, CGenericStmt::GS_RETURN, lbl),
   CGenericStmtReturn(),
   exprs(p_exprs)
{
   SetParent(exprs);
}

CReturnStmtTuple::
~CReturnStmtTuple()
{
   delete exprs;
}

CReturnStmtTuple::CReturnStmtTuple(const CReturnStmtTuple& obj)
:  CGenericStmt(GS_RETURN),
   AStmt(obj.coord, obj.Type(), obj.GetLabel()->Copy()),
   CGenericStmtReturn(),
   exprs(obj.exprs ? obj.exprs->Copy() : NULL)
{
   SetParent(exprs);
}

CReturnStmtTuple*
CReturnStmtTuple::
Copy() const
{
   return new CReturnStmtTuple(*this);
}

CReturnStmtTuple&
CReturnStmtTuple::
operator=(const CReturnStmtTuple& obj)
{
   return *this;
}
int washere;
void
CReturnStmtTuple::
OnPrint(ostream& stream, int indent) const
{
   if (!HasInternalGeneratedLabel())
   {
      GetLabel()->Print(stream, indent);
      stream << endl;
   }

   PrintIndent(stream, indent);
   stream << "{ return";

   if (exprs && exprs->ElementCount() > 0)
   {
      stream << endl;
      exprs->PrintWithEndl(stream, indent+1);
      PrintIndent(stream, indent);
   }
   else stream << ' ';
   stream << "}";
}

const CExprList*
CReturnStmtTuple::
GetExprs() const
{
   return exprs;
}

CGenericNode* 
CReturnStmtTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CReturnStmtTuple(GetCoord(), 
                               dynamic_cast<CExprList*>(exprs->Expand(helper)),
                               ExpandLabel(helper));
}

