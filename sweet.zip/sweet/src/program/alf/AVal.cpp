/* $Id: AVal.cpp 5947 2013-12-03 20:44:28Z lkg02 $ */

#include "AVal.h"

using namespace alf;
using namespace std;

AVal::
AVal(COORD coord)
   :  CGenericNode(coord)
{
}

AVal::
~AVal()
{
}

AVal::AVal(const AVal& obj)
  :  CGenericNode(obj.coord)
{
}

AVal&
AVal::
operator=(const AVal& obj)
{
   return *this;
}
