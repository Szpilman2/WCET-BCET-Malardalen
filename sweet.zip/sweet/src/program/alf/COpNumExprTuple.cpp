// $Id $

#include "COpNumExprTuple.h"
#include "CListNode.h"
#include "CSize.h"
#include "CSizeList.h"
#include "CExprList.h"
#include "internal.h"
#include <string>
#include <cassert>


using namespace std;
namespace alf
{

COpNumExprTuple::
COpNumExprTuple(COORD coord, OP_TYPE type)
:  CGenericNode(coord),
   AExpr(coord, NULL),
   op_type(type),
   sizes(new CSizeList(coord)),
   num_exprs(new CExprList(coord))
{

}

COpNumExprTuple::
COpNumExprTuple(COORD coord, OP_TYPE type, CSizeList* p_sizes)
:  CGenericNode(coord),
   AExpr(coord, NULL),
   op_type(type),
   sizes(p_sizes),
   num_exprs(new CExprList(coord))
{
   SetParent(sizes);
}

COpNumExprTuple::
COpNumExprTuple(COORD coord, OP_TYPE type, CExprList* p_num_exprs)
:  CGenericNode(coord),
   AExpr(coord, NULL),
   op_type(type),
   sizes(new CSizeList(coord)),
   num_exprs(p_num_exprs)
{  
   SetParent(num_exprs);
}

COpNumExprTuple::
COpNumExprTuple(COORD coord, OP_TYPE type, CSizeList* p_sizes, CExprList* p_num_exprs)
:  CGenericNode(coord),
   AExpr(coord, NULL),
   op_type(type),
   sizes(p_sizes),
   num_exprs(p_num_exprs)
{
   SetParent(sizes);
   SetParent(num_exprs);
}

COpNumExprTuple::
~COpNumExprTuple(void)
{
   if (sizes)
      delete sizes;
   
   if (num_exprs)
      delete num_exprs;
}

COpNumExprTuple*
COpNumExprTuple::
Copy() const
{
   return new COpNumExprTuple(*this);
}

bool COpNumExprTuple::IsBooleanOperator(OP_TYPE op)
{
   return
      op == OP_TYPE_EQ ||
      op == OP_TYPE_NEQ ||
      op == OP_TYPE_U_LT ||
      op == OP_TYPE_U_GE ||
      op == OP_TYPE_U_GT ||
      op == OP_TYPE_U_LE ||
      op == OP_TYPE_S_LT ||
      op == OP_TYPE_S_GE ||
      op == OP_TYPE_S_GT ||
      op == OP_TYPE_S_LE ||
      op == OP_TYPE_F_EQ ||
      op == OP_TYPE_F_NE ||
      op == OP_TYPE_F_LT ||
      op == OP_TYPE_F_GE ||
      op == OP_TYPE_F_GT ||
      op == OP_TYPE_F_LE;
}

COpNumExprTuple::OP_TYPE COpNumExprTuple::OppositeOp(OP_TYPE op)
{
   if (op == OP_TYPE_EQ)   return OP_TYPE_NEQ;
   if (op == OP_TYPE_NEQ)  return OP_TYPE_EQ;
   if (op == OP_TYPE_U_LT) return OP_TYPE_U_GE;
   if (op == OP_TYPE_U_GE) return OP_TYPE_U_LT;
   if (op == OP_TYPE_U_GT) return OP_TYPE_U_LE;
   if (op == OP_TYPE_U_LE) return OP_TYPE_U_GT;
   if (op == OP_TYPE_S_LT) return OP_TYPE_S_GE;
   if (op == OP_TYPE_S_GE) return OP_TYPE_S_LT;
   if (op == OP_TYPE_S_GT) return OP_TYPE_S_LE;
   if (op == OP_TYPE_S_LE) return OP_TYPE_S_GT;
   if (op == OP_TYPE_F_EQ) return OP_TYPE_F_NE;
   if (op == OP_TYPE_F_NE) return OP_TYPE_F_EQ;
   if (op == OP_TYPE_F_LT) return OP_TYPE_F_GE;
   if (op == OP_TYPE_F_GE) return OP_TYPE_F_LT;
   if (op == OP_TYPE_F_GT) return OP_TYPE_F_LE;
   if (op == OP_TYPE_F_LE) return OP_TYPE_F_GT;
   
   assert("This function is only defined for boolean operators" == NULL);
   return OP_TYPE_F_GT; // Just to avoid a warning
}

void
COpNumExprTuple::
OnPrint(ostream& stream, int indent) const
{
   // Print operator name
   PrintIndent(stream, indent);
   stream << "{ " << GetReadableName() << endl;

   // Print list of sizes
   if (sizes)
      sizes->PrintWithEndl(stream, indent + 1);

   // Print expressions
   if (num_exprs)
      num_exprs->PrintWithEndl(stream, indent + 1);

   PrintIndent(stream, indent);
   stream << "}";
}

const CSizeList *
COpNumExprTuple::
GetSizes() const
{
   return sizes;
}

const CExprList *
COpNumExprTuple::
GetNumExprs() const
{
   return num_exprs;
}

Size COpNumExprTuple::GetSizeOfEvaluatedExpr() const
{
   switch (GetOperator()) 
   {   
   // These are operators where the size of the result is determined by the first size operand
   case COpNumExprTuple::OP_TYPE_NEG:
   case COpNumExprTuple::OP_TYPE_ADD:
   case COpNumExprTuple::OP_TYPE_SUB:
   case COpNumExprTuple::OP_TYPE_U_DIV:
   case COpNumExprTuple::OP_TYPE_S_DIV:
   case COpNumExprTuple::OP_TYPE_U_MOD:
   case COpNumExprTuple::OP_TYPE_S_MOD:
   case COpNumExprTuple::OP_TYPE_L_SHIFT:
   case COpNumExprTuple::OP_TYPE_R_SHIFT:
   case COpNumExprTuple::OP_TYPE_R_SHIFT_A:
   case COpNumExprTuple::OP_TYPE_NOT:
   case COpNumExprTuple::OP_TYPE_AND:
   case COpNumExprTuple::OP_TYPE_OR:
   case COpNumExprTuple::OP_TYPE_XOR:
   case COpNumExprTuple::OP_TYPE_IF:
   case COpNumExprTuple::OP_TYPE_REPEAT:
      return GetSizes()->ElementAt(0)->GetSizeInBits();
      break;
   // Operators where the result has the size 1
   case COpNumExprTuple::OP_TYPE_C_ADD: 
   case COpNumExprTuple::OP_TYPE_C_SUB:
   // Boolean operators
   case COpNumExprTuple::OP_TYPE_EQ:
   case COpNumExprTuple::OP_TYPE_NEQ:
   case COpNumExprTuple::OP_TYPE_U_LT:
   case COpNumExprTuple::OP_TYPE_U_GE:
   case COpNumExprTuple::OP_TYPE_U_GT:
   case COpNumExprTuple::OP_TYPE_U_LE:
   case COpNumExprTuple::OP_TYPE_S_LT:
   case COpNumExprTuple::OP_TYPE_S_GE:
   case COpNumExprTuple::OP_TYPE_S_GT:
   case COpNumExprTuple::OP_TYPE_S_LE:
   case COpNumExprTuple::OP_TYPE_F_EQ:
   case COpNumExprTuple::OP_TYPE_F_NE:
   case COpNumExprTuple::OP_TYPE_F_LT:
   case COpNumExprTuple::OP_TYPE_F_GE:
   case COpNumExprTuple::OP_TYPE_F_GT:
   case COpNumExprTuple::OP_TYPE_F_LE:
      return 1;
      break;
   // Operators where the size is equal to the sum of the first two size operands
   case COpNumExprTuple::OP_TYPE_U_MUL:
   case COpNumExprTuple::OP_TYPE_S_MUL:
   case COpNumExprTuple::OP_TYPE_CONC:
      return GetSizes()->ElementAt(0)->GetSizeInBits() + GetSizes()->ElementAt(1)->GetSizeInBits();
      break;
   // Operators where the size of the result is determined by the second size operand
   case COpNumExprTuple::OP_TYPE_S_EXT:
      return GetSizes()->ElementAt(1)->GetSizeInBits();
      break;
   // Operators whose results are them sum of the first two size arguments + 1
   case COpNumExprTuple::OP_TYPE_F_NEG:
   case COpNumExprTuple::OP_TYPE_F_ADD:
   case COpNumExprTuple::OP_TYPE_F_SUB:
   case COpNumExprTuple::OP_TYPE_F_MUL:
   case COpNumExprTuple::OP_TYPE_F_DIV:
   case COpNumExprTuple::OP_TYPE_U_TO_F:
   case COpNumExprTuple::OP_TYPE_S_TO_F:
      return GetSizes()->ElementAt(0)->GetSizeInBits() + GetSizes()->ElementAt(1)->GetSizeInBits() + 1;
      break;
   case COpNumExprTuple::OP_TYPE_F_TO_F:
      return GetSizes()->ElementAt(1)->GetSizeInBits() + GetSizes()->ElementAt(3)->GetSizeInBits() + 1;
      break;
   // Operators where the size of the result is determined by the third size operand
   case COpNumExprTuple::OP_TYPE_F_TO_U:
   case COpNumExprTuple::OP_TYPE_F_TO_S:
      return GetSizes()->ElementAt(2)->GetSizeInBits();
      break;
   // Operators whose result has infinite size
   case COpNumExprTuple::OP_TYPE_B2N:
   case COpNumExprTuple::OP_TYPE_EXP2:
      return Size::Infinity();
      break;
   case COpNumExprTuple::OP_TYPE_SELECT:
      return GetSizes()->ElementAt(2)->GetSizeInBits() - GetSizes()->ElementAt(1)->GetSizeInBits() + 1;
      break;
   default:
      assert("Oops!" == 0);
      return 0;
      break;
   }
}

COpNumExprTuple::
COpNumExprTuple(const COpNumExprTuple& obj)
:  CGenericNode(obj.coord),
   AExpr(obj.coord, NULL),
   sizes(obj.sizes ? obj.sizes->Copy() : NULL),
   num_exprs(obj.num_exprs ? obj.num_exprs->Copy() : NULL)
{   
   if (sizes)
      SetParent(sizes);
   
   if (num_exprs)
      SetParent(num_exprs);
}

COpNumExprTuple&
COpNumExprTuple::
operator=(const COpNumExprTuple&)
{
   return *this;
}

COpNumExprTuple::OP_TYPE
COpNumExprTuple::
GetOperator() const
{
   return op_type;
}

string
COpNumExprTuple::
GetName() const
{
   return GetName(op_type);
}
   
std::string COpNumExprTuple::GetName(OP_TYPE oper)
{
   switch (oper) {
      case OP_TYPE_NEG:
         return "OP_TYPE_NEG";
      case OP_TYPE_ADD:
         return "OP_TYPE_ADD";
      case OP_TYPE_C_ADD:
         return "OP_TYPE_C_ADD";
      case OP_TYPE_SUB:
         return "OP_TYPE_SUB";
      case OP_TYPE_C_SUB:
         return "OP_TYPE_C_SUB";
      case OP_TYPE_U_MUL:
         return "OP_TYPE_U_MUL";
      case OP_TYPE_S_MUL:
         return "OP_TYPE_S_MUL";
      case OP_TYPE_U_DIV:
         return "OP_TYPE_U_DIV";
      case OP_TYPE_S_DIV:
         return "OP_TYPE_S_DIV";
      case OP_TYPE_U_MOD:
         return "OP_TYPE_U_MOD";
      case OP_TYPE_S_MOD:
         return "OP_TYPE_S_MOD";
      case OP_TYPE_L_SHIFT:
         return "OP_TYPE_L_SHIFT";
      case OP_TYPE_R_SHIFT:
         return "OP_TYPE_R_SHIFT";
      case OP_TYPE_R_SHIFT_A:
         return "OP_TYPE_R_SHIFT_A";
      case OP_TYPE_S_EXT:
         return "OP_TYPE_S_EXT";
      case OP_TYPE_NOT:
         return "OP_TYPE_NOT";
      case OP_TYPE_AND:
         return "OP_TYPE_AND";
      case OP_TYPE_OR:
         return "OP_TYPE_OR";
      case OP_TYPE_XOR:
         return "OP_TYPE_XOR";
      case OP_TYPE_F_NEG:
         return "OP_TYPE_F_NEG";
      case OP_TYPE_F_ADD:
         return "OP_TYPE_F_ADD";
      case OP_TYPE_F_SUB:
         return "OP_TYPE_F_SUB";
      case OP_TYPE_F_MUL:
         return "OP_TYPE_F_MUL";
      case OP_TYPE_F_DIV:
         return "OP_TYPE_F_DIV";
      case OP_TYPE_F_TO_F:
         return "OP_TYPE_F_TO_F";
      case OP_TYPE_F_TO_U:
         return "OP_TYPE_F_TO_U";
      case OP_TYPE_F_TO_S:
         return "OP_TYPE_F_TO_S";
      case OP_TYPE_U_TO_F:
         return "OP_TYPE_U_TO_F";
      case OP_TYPE_S_TO_F:
         return "OP_TYPE_S_TO_F";
      case OP_TYPE_EQ:
         return "OP_TYPE_EQ";
      case OP_TYPE_NEQ:
         return "OP_TYPE_NEQ";
      case OP_TYPE_U_LT:
         return "OP_TYPE_U_LT";
      case OP_TYPE_U_GE:
         return "OP_TYPE_U_GE";
      case OP_TYPE_U_GT:
         return "OP_TYPE_U_GT";
      case OP_TYPE_U_LE:
         return "OP_TYPE_U_LE";
      case OP_TYPE_S_LT:
         return "OP_TYPE_S_LT";
      case OP_TYPE_S_GE:
         return "OP_TYPE_S_GE";
      case OP_TYPE_S_GT:
         return "OP_TYPE_S_GT";
      case OP_TYPE_S_LE:
         return "OP_TYPE_S_LE";
      case OP_TYPE_F_LT:
         return "OP_TYPE_F_LT";
      case OP_TYPE_F_GE:
         return "OP_TYPE_F_GE";
      case OP_TYPE_F_EQ:
         return "OP_TYPE_F_EQ";
      case OP_TYPE_F_NE:
         return "OP_TYPE_F_NE";
      case OP_TYPE_F_GT:
         return "OP_TYPE_F_GT";
      case OP_TYPE_F_LE:
         return "OP_TYPE_F_LE";
      case OP_TYPE_IF:
         return "OP_TYPE_IF";
      case OP_TYPE_B2N:
         return "OP_TYPE_B2N";
      case OP_TYPE_EXP2:
         return "OP_TYPE_EXP2";
      case OP_TYPE_SELECT:
         return "OP_TYPE_SELECT";
      case OP_TYPE_CONC:
         return "OP_TYPE_CONC";
      case OP_TYPE_REPEAT:
         return "OP_TYPE_REPEAT";
      default:
         return "";
   }
}

const char * COpNumExprTuple::GetReadableName() const
{
   return GetReadableName(op_type);
}

const char * COpNumExprTuple::GetReadableName(OP_TYPE oper)
{
   switch (oper) 
   {
      case OP_TYPE_NEG:
         return "neg";
      case OP_TYPE_ADD:
         return "add";
      case OP_TYPE_C_ADD:
         return "c_add";
      case OP_TYPE_SUB:
         return "sub";
      case OP_TYPE_C_SUB:
         return "c_sub";
      case OP_TYPE_U_MUL:
         return "u_mul";
      case OP_TYPE_S_MUL:
         return "s_mul";
      case OP_TYPE_U_DIV:
         return "u_div";
      case OP_TYPE_S_DIV:
         return "s_div";
      case OP_TYPE_U_MOD:
         return "u_mod";
      case OP_TYPE_S_MOD:
         return "s_mod";
      case OP_TYPE_L_SHIFT:
         return "l_shift";
      case OP_TYPE_R_SHIFT:
         return "r_shift";
      case OP_TYPE_R_SHIFT_A:
         return "r_shift_a";
      case OP_TYPE_S_EXT:
         return "s_ext";
      case OP_TYPE_NOT:
         return "not";
      case OP_TYPE_AND:
         return "and";
      case OP_TYPE_OR:
         return "or";
      case OP_TYPE_XOR:
         return "xor";
      case OP_TYPE_F_NEG:
         return "f_neg";
      case OP_TYPE_F_ADD:
         return "f_add";
      case OP_TYPE_F_SUB:
         return "f_sub";
      case OP_TYPE_F_MUL:
         return "f_mul";
      case OP_TYPE_F_DIV:
         return "f_div";
      case OP_TYPE_F_TO_F:
         return "f_to_f";
      case OP_TYPE_F_TO_U:
         return "f_to_u";
      case OP_TYPE_F_TO_S:
         return "f_to_s";
      case OP_TYPE_U_TO_F:
         return "u_to_f";
      case OP_TYPE_S_TO_F:
         return "s_to_f";
      case OP_TYPE_EQ:
         return "eq";
      case OP_TYPE_NEQ:
         return "neq";
      case OP_TYPE_U_LT:
         return "u_lt";
      case OP_TYPE_U_GE:
         return "u_ge";
      case OP_TYPE_U_GT:
         return "u_gt";
      case OP_TYPE_U_LE:
         return "u_le";
      case OP_TYPE_S_LT:
         return "s_lt";
      case OP_TYPE_S_GE:
         return "s_ge";
      case OP_TYPE_S_GT:
         return "s_gt";
      case OP_TYPE_S_LE:
         return "s_le";
      case OP_TYPE_F_LT:
         return "f_lt";
      case OP_TYPE_F_GE:
         return "f_ge";
      case OP_TYPE_F_EQ:
         return "f_eq";
      case OP_TYPE_F_NE:
         return "f_ne";
      case OP_TYPE_F_GT:
         return "f_gt";
      case OP_TYPE_F_LE:
         return "f_le";
      case OP_TYPE_IF:
         return "if";
      case OP_TYPE_B2N:
         return "b2n";
      case OP_TYPE_EXP2:
         return "exp2";
      case OP_TYPE_SELECT:
         return "select";
      case OP_TYPE_CONC:
         return "conc";
      case OP_TYPE_REPEAT:
         return "repeat";
      default:
         return "";
   }
}

CGenericNode* 
COpNumExprTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   CSizeList* expanded_sizes = sizes != NULL ? dynamic_cast<CSizeList*>(sizes->Expand(helper)) : NULL;
   CExprList* expanded_exprs = num_exprs != NULL ? dynamic_cast<CExprList*>(num_exprs->Expand(helper)) : NULL;
   
   return new COpNumExprTuple(GetCoord(), 
                              GetOperator(),
                              expanded_sizes,
                              expanded_exprs);
}
}
