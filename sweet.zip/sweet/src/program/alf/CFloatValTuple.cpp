// $Id $

#include "CFloatValTuple.h"
#include "CNumber.h"
#include "CSize.h"
#include "CString.h"
#include "float.h"

using namespace alf;
using namespace std;

CFloatValTuple::
CFloatValTuple(COORD coord, CSize* p_exp_size, CSize* p_frac_size, CString* value)
:  CGenericNode(coord),
   ANumVal(coord, new CSize(coord, static_cast<unsigned>((p_exp_size->GetSizeInBits()+p_frac_size->GetSizeInBits()+1).AsBaseIntType()))), //+1 is the sign bit... should it be there?
   exp_size(p_exp_size),
   frac_size(p_frac_size)
{
   int exp_interval = LDBL_MAX_EXP - LDBL_MIN_EXP;
   int temp = 0;
   unsigned int exp_max_bitsize = 0;

   //this loop simply counts hom many bits is needed to express the number of values in the interval
   //between lowest and highest possible exponent.
   while (temp < exp_interval) {
      exp_max_bitsize++;
      temp = exp_max_bitsize*2;
   }
   //check to see that the value fits within a C++ long double
   if (p_exp_size->GetSizeInBits() <= exp_max_bitsize) {
      if (p_frac_size->GetSizeInBits() <= LDBL_MANT_DIG) {
         float_val = new CFloatNumber(value);
      }
   }
   else //ropa p� bignum-konstruktorn...
      throw CException("CFloatValTuple::CFloatValTuple Fix bignum float with gmp in CNumber!");
   SetParent(exp_size);
   SetParent(frac_size);
}

CFloatValTuple::
~CFloatValTuple()
{
   delete exp_size;
   delete frac_size;
   delete float_val;
}

CFloatValTuple::
CFloatValTuple(const CFloatValTuple& obj)
:  CGenericNode(obj.coord),
   ANumVal(obj.coord, obj.size),
   exp_size(obj.exp_size->Copy()),
   frac_size(obj.frac_size->Copy())
{
   if (obj.float_val)
      obj.float_val->Copy();
   SetParent(exp_size);
   SetParent(frac_size);
}

CFloatValTuple*
CFloatValTuple::
Copy() const
{
   return new CFloatValTuple(*this);
}

CFloatValTuple&
CFloatValTuple::
operator=(const CFloatValTuple& obj)
{
   return *this;
}

void
CFloatValTuple::
OnPrint(ostream& stream, int indent) const
{
   PrintIndent(stream, indent);
   stream << "{ float_val " << *exp_size << " " << *frac_size << " " << float_val->GetValueAsString()->Get() << " }";
}

CFloatNumber*
CFloatValTuple::
GetFloatValue()
{
   return float_val;
}

const CFloatNumber * CFloatValTuple::GetFloatValue() const {return float_val;}

CSize*
CFloatValTuple::
GetExpSize() const
{
   return exp_size;
}

CSize*
CFloatValTuple::
GetFracSize() const
{
   return frac_size;
}

CGenericNode* 
CFloatValTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CFloatValTuple(GetCoord(),
                            dynamic_cast<CSize*>(exp_size->Expand(helper)),
                            dynamic_cast<CSize*>(frac_size->Expand(helper)),
                            dynamic_cast<CString*>(float_val->GetValueAsString()->Expand(helper)));
}
