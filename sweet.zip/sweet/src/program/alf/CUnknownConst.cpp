// $Id $
#include "CUnknownConst.h"
#include "CException.h"
#include "CMacroCallTuple.h"
#include "CMacroFormalArg.h"

using namespace std;

namespace alf
{

CUnknownConst::
CUnknownConst(COORD coord, CMacroCallTuple* macro_call_tuple)
:  CGenericNode(coord, macro_call_tuple),
   AConst(coord)
{

}

CUnknownConst::
CUnknownConst(COORD coord, CMacroFormalArg* macro_formal_arg)
:  CGenericNode(coord, macro_formal_arg),
   AConst(coord)
{

}

CUnknownConst::
~CUnknownConst()
{

}

CUnknownConst*
CUnknownConst::
Copy() const
{
   return new CUnknownConst(*this);
}

void
CUnknownConst::
OnPrint(ostream& o, int indent) const
{
   if (HasMacroCall())
      GetMacroCall()->Print(o, indent);
   else if (HasMacroFormalArg())
      GetMacroFormalArg()->Print(o, indent);
   else
      throw CException("CUnknownConst::Print can only handle macrocall and macroformalarg nodes.");
}

CUnknownConst::
CUnknownConst(const CUnknownConst& obj)
:  CGenericNode(obj),
   AConst(obj.coord)
{

}

CUnknownConst&
CUnknownConst::
operator=(const CUnknownConst&)
{
   return *this;
}
   
   CGenericNode* 
   CUnknownConst::
   OnExpand(CAlfTreeExpandingHelper* helper) const
   {
      throw new CException("CUndefinedExprTuple::OnExpand not implemented!");
   }

}
