// $Id $

#ifndef ALF_RETURNSTMTTUPLE_H
#define ALF_RETURNSTMTTUPLE_H

#include "AStmt.h"
#include "AlfNodeVisitor.h"
#include "program/CGenericStmt.h"
#include <vector>

namespace alf
{
class CLabelTuple;
class AExpr;
class CExprList;

/**
 * A node representing a return statement in the ALF-program.
 * It corresponds to the following rule in the ALF-grammar:
 * STMT -> { return EXPR_LIST }
 *
 * Values and control are returned using a return statement, which takes a list
 * of expressions to be evaluated, in left-to-right order, when the statement is
 * reached by the execution. All return statements in a function must have equally
 * long lists and the length of these must also equal the length of the
 * ADDR_EXPR lists in the calls to the function.
 *
 * @see AExpr, CLabelTuple, AStmt
 */
class CReturnStmtTuple : public AStmt, public CGenericStmtReturn
{
public:
   /**
    * Constructor representing a return with one or more, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_RETURN_STMT_TUPLE.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord      The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param exprs      The expressions to return to caller.
    * @param stmt_label An optional label that is attached to the statement.
    */
   CReturnStmtTuple(COORD coord, CExprList* exprs, CLabelTuple *stmt_label=NULL);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CReturnStmtTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   virtual CReturnStmtTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitReturnStmtTuple(*this);}

   /**
    * @return A possibly empty list of expressions specifying the return values from the function of this statement.
    */
   const CExprList* GetExprs() const;

   /** 
    * @return Pointer to a constant string giving the name of the statement
    *         type, e.g., "store" or "switch"
    */
   virtual const char * StatementTypeName() const {return "return";}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual CGenericNode::TYPE GetNodeType() const { return CGenericNode::TYPE_RETURN_STMT_TUPLE; }

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(CGenericNode::TYPE t) const {return t == CGenericNode::TYPE_RETURN_STMT_TUPLE || AStmt::IsType(t); }

   CReturnStmtTuple* Duplicate() { return Copy(); }
   void Uses(CAliasGraph *alias_graph, std::set<int> *uses) { }
   void Updates(CAliasGraph *alias_graph, std::set<int> *updated_vars) { }
   void Variables(CAliasGraph *alias_graph, std::set<int> *vars) { }
   void AsText(CTextBlock *text_block, int indentation) const { }
   void PrintAsDot(std::ostream &o) const { OnPrint(o, 0); }

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CReturnStmtTuple(const CReturnStmtTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CReturnStmtTuple& operator=(const CReturnStmtTuple&);

   /**
    * The expressions to return to caller.
    */
   CExprList* exprs;
};

}

#endif

