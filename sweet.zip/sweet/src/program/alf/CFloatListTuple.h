// $Id $

#ifndef ALF_CFLOATLISTTUPLE_H
#define ALF_CFLOATLISTTUPLE_H

#include "CListNode.h"
#include "AVal.h"
#include "CFloatValTuple.h"
#include "AlfNodeVisitor.h"
#include <map>

namespace alf
{
class CSize;
class CString;

/**
 * Represents a list of float numbers of the VAL rule in the ALF grammar:
 * VAL -> { float_list SIZE SIZE FLOAT_VAL+ }
 *
 * @see CSize, CFloatValTuple, CListNode, AVal
 */
class CFloatListTuple : public CListNode<CFloatValTuple>, public AVal
{
public:
  /**
    * Constructor, creates a list node from a vector of frame references.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_FLOAT_LIST.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord     The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param exp_size  The size of the exponent for each element in 'list'.
    * @param frac_size The size of the fraction for each element in 'list'.
    * @param list      A vector of float numbers.
    */
   CFloatListTuple(const COORD& coord, CSize* exp_size, CSize* frac_size, const std::vector<CString*>& list);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CFloatListTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   CFloatListTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitFloatListTuple(*this);}

   /**
    * @return The size of the exponent for each element in the list.
    */
   const CSize* GetExpSize() const;

   /**
    * @return The size of the fraction for each element in the list.
    */
   const CSize* GetFracSize() const;

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_FLOAT_LIST; }


   /** 
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_FLOAT_LIST || CListNode<CFloatValTuple>::IsType(t) || AVal::IsType(t); }
   
protected:
   /** @copydoc CListNode<CFloatValTuple>::OnPrint */
   virtual void OnPrint(std::ostream& o, int indent) const;

private:
   CFloatListTuple(const COORD& p_coord, CSize* p_exp_size, CSize* p_frac_size, const std::vector<CFloatValTuple*>& p_list);
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
};

}
#endif
