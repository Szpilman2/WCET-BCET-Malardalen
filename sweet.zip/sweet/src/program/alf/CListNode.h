// $Id $

#ifndef ALF_CLISTNODE_H
#define ALF_CLISTNODE_H

#include "CGenericNode.h"
#include "CSize.h"
#include "internal.h"
#include "CException.h"
#include <vector>
#include <string>
#include <typeinfo>

namespace alf 
{

/**
 * A template super class for nodes containing a list of a certain node.
 */

template <class T>
class CListNode : public virtual CGenericNode
{
public:
   typedef typename std::vector<T*>::const_iterator list_iterator;
   typedef typename std::vector<T*>::const_iterator const_list_iterator;
   
   /**
    * Constructor that creates an empty list with 'name' as the heading.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param name    The lists 'tag', what should be printed when Print is called.
    */
   CListNode(const COORD& coord, const std::string name);
   
   /**
    * Constructor that creates a list containing the elements in 'elems' with 'name' as the heading.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param name    The lists 'tag', what should be printed when Print is called.
    * @param elems   A vector of nodes that the list should contain.
    */
   CListNode(const COORD& coord, const std::string name, const std::vector<T*>& elems);
   
   /**
    * Constructor that creates a list containing the elements in 'elems' without a heading name.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param elems                     A vector of nodes that the list should contain.
    * @param print_brackets            Should enclose the list with '{' and '}' when printing or not.
    * @param print_elements_with_endl  Should print endl after each element when printing or not.
    */
   CListNode(const COORD& coord, const std::vector<T*>& elems, bool print_brackets=true, bool print_elements_with_endl=true);
   
   /**
    * Create a list containing the elements in 'elems' with 'name' and 'size' as the heading.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param name    The lists 'tag', what should be printed when Print is called.
    * @param size    The size of the elements in the list
    * @param elems   A vector of nodes that the list should contain.
    */
   CListNode(const COORD& coord, const std::string name, CSize* size, const std::vector<T*>& elems);
   
   /**
    * Create a list containing the elements in 'elems' with 'name' and 'sizes' as the heading.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param name    The lists 'tag', what should be printed when Print is called.
    * @param sizes   A list with sizes where the whole list describes the size of one element in the list.
    * @param elems   A vector of nodes that the list should contain.
    */
   CListNode(const COORD& coord, const std::string name, std::vector<CSize*> sizes, const std::vector<T*>& elems);
   
   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CListNode();
      
   /**
    * Gets the count of elements in the list.
    */
   std::size_t ElementCount() const;
   
   /**
    * Gets an iterator to the beginning of the list.
    */
   list_iterator Iterator();

   /**
    * Gets a const_iterator to the beginning of the list.
    */
   const_list_iterator ConstIterator() const;
   
   /**
    * Gets an invalid iterator that you can test the
    * iterator returned from Iterator() to figure out
    * when you have reached the end of the list.
    */
   const_list_iterator InvalidIterator() const;

   /**
    * Erases one element from the list. 
    * @param it An iterator to the element to remove.
    * @return An iterator the the next element after the removed one.
    * NOTE! This function is here because of an ugly hack. It should 
    * normally not be used.
    */
   list_iterator Erase(list_iterator it) const;

   /**
    * Gets an invalid const_iterator that you can test the
    * iterator returned from Iterator() to figure out
    * when you have reached the end of the list.
    */
   //const_list_iterator InvalidConstIterator() const;
   
   const T* ElementAt(size_t index) const;
   
   /**
    * Get the CSize nodes.
    * @return  If one or more CSize nodes was given to the constructor then it is returned, otherwise an empty vector.
    */
   std::vector<CSize*> GetSizeNodes() const;

   /**
    * @return  The type of this node. This will never be called.
    */
   virtual TYPE GetNodeType() const { return TYPE_LIST_NODE;}

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_LIST_NODE || CGenericNode::IsType(t); }

   /**
    * Moves the elements from another list to this.
    * @param other The other list.
    * @post The elements that was previously in other is now in this. Other is empty
    */
   void Link(CListNode<T> &other);

   /**
    * Move all elements moved from @a other to this list. No checks are made that the 
    * resulting program is correct.
    */
   void Merge(CListNode<T>& other) {Link(other);}

protected:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CListNode(const CListNode&);

   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   /**
    * @return All elements in the list, expanded.
    */
   std::vector<T*> ExpandList(CAlfTreeExpandingHelper* helper) const;
   
   /**
    * A list of nodes.
    */
   std::vector<T*> list;
   /**
    * Eventual sizes of the list elements.
    */
   std::vector<CSize*> size_nodes;
   /**
    * Heading of the list, will be used when Print is called.
    */
   std::string name;
   
   /**
    * Print '{' and '}' or not...
    */
   bool print_brackets;
   
   /**
    * Print endl after each element or not.
    */
   bool print_elements_with_endl;

private:
   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CListNode& operator=(const CListNode&);
};
   
}

#endif

