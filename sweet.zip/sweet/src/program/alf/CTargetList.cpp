// $Id $
#include "CTargetList.h"
#include "CTargetTuple.h"
#include "CListNode.inl"

using namespace alf;

CTargetList::
CTargetList(const COORD& coord, const std::vector<ATarget*>& p_list)
:  CGenericNode(coord),
   CListNode<ATarget>(coord, p_list, false, true)
{
}

CTargetList::
~CTargetList()
{
}

CTargetList*
CTargetList::
Copy() const
{
   return new CTargetList(*this);
}

CGenericNode* 
CTargetList::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   const std::vector<ATarget*> expandedList = ExpandList(helper);
   return new CTargetList(GetCoord(), expandedList);
}

template class alf::CListNode<ATarget>;
