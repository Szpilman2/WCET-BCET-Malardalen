// $Id $

#ifndef ALF_CADDRTUPLE_H
#define ALF_CADDRTUPLE_H

#include "AExpr.h"
#include "AConst.h"
#include "AlfNodeVisitor.h"

namespace alf
{
class CSize;
class CFRefTuple;
class CIntNumValTuple;

/**
 * Represents the address node in then ADDR_EXPR rule which is the following rule in the ALF grammar :
 * ADDR_EXPR -> { addr SIZE FREF NUM_EXPR }
 *
 * @see AExpr, CSize, AExpr, AConst
 */
class CAddrTuple : public AExpr, public AConst
{
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_ADDR_TUPLE.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord    The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param size     The size of the address.
    * @param fref     The frame reference from where the address begins.
    * @param offset   The offset from the frame reference that the address is equal to.
    */
   CAddrTuple(const COORD& coord, CSize* size, CFRefTuple* fref, CIntNumValTuple* offset);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CAddrTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to 
    *          deallocate the memory.
    */
   virtual CAddrTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitAddrTuple(*this);}

   /**
    * @return The frame reference from where the address begins.
    */
   const CFRefTuple *GetFref() const;

   /**
    * @return The offset from the frame reference that the address is equal to.
    */
   const CIntNumValTuple *GetOffset() const;

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_ADDR_EXPR_TUPLE; }

  /** 
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_ADDR_EXPR_TUPLE || AExpr::IsType(t) || AConst::IsType(t); }

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CAddrTuple(const CAddrTuple&);
   
   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CAddrTuple& operator=(const CAddrTuple&);

   /**
    * The frame reference.
    */
   CFRefTuple *fref;

   /**
    * The offset from the frame reference.
    */
   CIntNumValTuple *offset;
};

}

#endif

