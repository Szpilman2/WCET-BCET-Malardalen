// $Id $

#include "CStmtList.h"
#include "AStmt.h"
#include "CLabelTuple.h"
#include "CListNode.inl"

using namespace alf;

CStmtList::
CStmtList(const COORD& coord, const std::vector<AStmt*>& p_list, bool p_print_brackets_and_head)
:  CGenericNode(coord),
   CListNode<AStmt>(coord, p_print_brackets_and_head ? "stmts" : "", p_list)
{
   print_brackets = p_print_brackets_and_head;
}

CStmtList::
~CStmtList()
{
}

CStmtList*
CStmtList::
Copy() const
{
   return new CStmtList(*this);
}

CGenericNode* 
CStmtList::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   std::vector<AStmt*> expandedList;
   CLabelTuple* current_label = NULL;
   for (std::vector<AStmt*>::const_iterator it = list.begin();
        it != list.end();
        it++)
   {
      AStmt* element = *it;
      assert(element != NULL);
      CGenericNode* node = element->Expand(helper);
      assert(node != NULL);
      
      if (node->IsType(CGenericNode::TYPE_STMT))
      {
         AStmt* current_stmt = dynamic_cast<AStmt*> (node);
         current_stmt->label = current_label;
         current_stmt->SetParent(current_label);
         expandedList.push_back(current_stmt);
         current_label = NULL;
      }
      else if (node->IsType(CGenericNode::TYPE_LABEL_TUPLE))
      {
         if (current_label == NULL)
            current_label = dynamic_cast<CLabelTuple*> (node);
         else
            throw CException("Grammar error, a statement was expected after a label!");
      }
      // A macrocall expanded to more than one stmt.
      else if (node->IsType(CGenericNode::TYPE_STMT_LIST))
      {
         CStmtList* stmtList = dynamic_cast<CStmtList*>(node);
         stmtList->Explode(expandedList, current_label);
         
         if (expandedList.back()->IsType(CGenericNode::TYPE_LABEL_TUPLE))
            current_label = dynamic_cast<CLabelTuple*>(expandedList.back());
         else
            current_label = NULL;
      }
      else
         throw CException("Unsupported expanded type from one of CStmtList's elements?!");
   }
   
   if (current_label != NULL)
      throw CException("Grammar error, a statement was expected after a label!");
   
   return new CStmtList(GetCoord(), expandedList, print_brackets);
}

void
CStmtList::
Explode(std::vector<AStmt*>& stmts, CLabelTuple* first_stmt_label)
{
   for (CStmtList::list_iterator it = list.begin();
        it != list.end();
        it++)
   {
      stmts.push_back(*it);
      
      if (first_stmt_label != NULL)
      {
         stmts.back()->label = first_stmt_label;
         stmts.back()->SetParent(first_stmt_label);
         first_stmt_label = NULL;
      }
   }
   
   list.clear();
   delete this;
}

CGenericNode*
CStmtList::
Explode()
{
   if (list.size() != 1)
      throw CException("CStmtList::Explode can only be called when the list contains one element!");
      
   CGenericNode* node = list[0];
   list.clear();
   delete this;
   return node;
}

void
CStmtList::
PatchWithStatement(AStmt *stmt)
{
   list.insert(list.begin(), stmt);
   SetParent(stmt);
}

template class alf::CListNode<AStmt>;
