/* $Id: CDynAllocTuple.cpp 950 2009-09-01 10:52:28Z jjn08 $ */

#include "CDynAllocTuple.h"
#include "CSize.h"
#include "CFRefTuple.h"
#include <typeinfo>

using namespace alf;
using namespace std;

CDynAllocTuple::
CDynAllocTuple(COORD coord,
               CSize* size,
               CFRefTuple* p_fref,
               AExpr* p_num_expr)
:  CGenericNode(coord),
   AExpr(coord, size),
   fref(p_fref),
   num_expr(p_num_expr)
{
   SetParent(fref);
   SetParent(num_expr);
}

CDynAllocTuple::
~CDynAllocTuple()
{
   delete fref;
   delete num_expr;
}

CDynAllocTuple::CDynAllocTuple(const CDynAllocTuple& obj)
:  CGenericNode(obj.coord),
   AExpr(obj.coord, (CSize*)obj.size->Copy()),
   fref((CFRefTuple *)obj.fref->Copy()),
   num_expr(dynamic_cast<AExpr*>(obj.num_expr->Copy()))
{
   SetParent(fref);
   SetParent(num_expr);
}

CDynAllocTuple*
CDynAllocTuple::
Copy() const
{
   return new CDynAllocTuple(*this);
}

CDynAllocTuple&
CDynAllocTuple::
operator=(const CDynAllocTuple& obj)
{
   return *this;
}

void
CDynAllocTuple::
OnPrint(ostream& stream, int indent) const
{
   PrintIndent(stream, indent);
   stream << "{ dyn_alloc " << size << fref << num_expr << " }";
}

const 
CFRefTuple* 
CDynAllocTuple::
GetFref() const
{
  return fref;
}

const 
AExpr* 
CDynAllocTuple::
GetNumExpr() const
{
  return num_expr;
}

CGenericNode* 
CDynAllocTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   return new CDynAllocTuple(GetCoord(),
                             dynamic_cast<CSize*> (GetSize()->Expand(helper)),
                             dynamic_cast<CFRefTuple*> (fref->Expand(helper)),
                             dynamic_cast<AExpr*> (num_expr->Expand(helper)));
}


