#include "AConst.h"

using namespace alf;

AConst::
AConst(COORD p_coord)
:  CGenericNode(p_coord),
   AVal(coord)
{
}

AConst::
~AConst()
{
}

AConst::AConst(const AConst& obj)
:  CGenericNode(obj.coord),
   AVal(obj.coord)
{
}

AConst&
AConst::
operator=(const AConst& obj)
{
   return *this;
}

