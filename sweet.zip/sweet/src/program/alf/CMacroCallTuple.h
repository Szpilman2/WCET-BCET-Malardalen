// $Id $

#ifndef ALF_CMACROCALLTUPLE_H
#define ALF_CMACROCALLTUPLE_H

#include "CGenericNode.h"
#include "AlfNodeVisitor.h"
#include <cassert>

namespace alf
{
class CString;
class CGenericList;
   
class CMacroCallTuple : public CGenericNode
{
public:
   CMacroCallTuple(COORD coord, CString* def_id, CGenericList* arguments);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CMacroCallTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to
    *          deallocate the memory.
    */
   virtual CMacroCallTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitMacroCallTuple(*this);}

   /**
    * Get the definition name.
    */
   const CString* GetDefinitionName() const;
   
   /**
    * Get the argument list.
    */
   const CGenericList* GetArguments() const;
   
   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_MACRO_CALL_TUPLE;} 

   /** 
    * Checks if the number has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_MACRO_CALL_TUPLE || CGenericNode::IsType(t); }

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CMacroCallTuple(const CMacroCallTuple& macro_call_tuple);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CMacroCallTuple& operator=(const CMacroCallTuple&) { return *this; }
   
   CString* def_id;
   
   CGenericList* arguments;
};

}

#endif

