#include "PostProcessAst.h"
#include "CGenericNode.h"
#include "CAlfTuple.h"
#include "CSize.h"
#include "CFRefList.h"
#include "CLRefList.h"
#include "CFRefTuple.h"
#include "CLRefTuple.h"
#include "CExportsTuple.h"
#include "CImportsTuple.h"
#include "program_state/LAU.h"
#include "program_state/Endianness.h"
#include "CLauTuple.h"
#include "CLabelTuple.h"
#include "globals.h"
#include "CAlfTreeTraversor.h"
#include <typeinfo>
#include <iostream>
#include <stdexcept>

using namespace std;
namespace alf
{

   /**
     * @class AssignSourceFileToAllNodes
     *  Assigns a string, assumed to be a source file name, to all nodes in an AST.
     */
   class AssignSourceFileToAllNodes : public CAlfTreeTraversor::INodeVisitor
   {
   public:
      /**
        * Constructs a new AssignSourceFileToAllNodes which will immediately do what
        * the name suggests.
        * @param ast The ast to assign the name to.
        * @param source_file_name A pointer to the name to assign. All nodes in the tree
        *   will save this pointer.
        */
      AssignSourceFileToAllNodes(const CGenericNode* ast, std::string *source_file_name);
      bool onBeginVisit(const CGenericNode* node);
      void onEndVisit(const CGenericNode* node) {}

   private:
      std::string *source_file_name;
   };

   AssignSourceFileToAllNodes::
   AssignSourceFileToAllNodes(const CGenericNode* ast, std::string *source_file_name) : source_file_name(source_file_name)
   {
      CAlfTreeTraversor traversor;
      traversor.RegisterNodeVisitor(this);
      traversor.BeginTraverse(ast);
   }

   bool
   AssignSourceFileToAllNodes::
   onBeginVisit(const CGenericNode* node)
   {
      const_cast<CGenericNode*>(node)->SetSourceFile(source_file_name);
      return true;
   }

   template <typename T_RefList>
   static void AddNames(set <string> &exported_ids, const T_RefList *ref_list, string (*Unmangle)(string))
   {
      for (size_t i=0; i<ref_list->ElementCount(); ++i) {
         string id_to_keep = Unmangle(ref_list->ElementAt(i)->Name());
         exported_ids.insert(id_to_keep);
      }
   }

   // Patch: If an imported id also occurs as an exported id we remove
   // it from the imports. The reason why it occurs is that the C code
   // might look like ... extern int a; ... int a; which then will
   // generate both an import and an export for a.
   template <typename T_RefList, typename T_RefTuple>
   static void FilterOutImports(const set <string> &exported_ids, const T_RefList *ref_list, string (*Unmangle)(string))
   {
      for (typename T_RefList::list_iterator it=ref_list->ConstIterator(); it!=ref_list->InvalidIterator(); ) {
         T_RefTuple *ref = *it;
         bool match = exported_ids.find(Unmangle(ref->Name())) != exported_ids.end();
         if (match) {
            delete ref;
            it = ref_list->Erase(it);
         } else {
            ++it;
         }
      }
   }

   static void FilterOutImports(CAlfTuple* ast, string (*Unmangle)(string))
   {
      set <string> exported_ids;
      const CExportsTuple *exports = ast->GetExports();
      AddNames<CFRefList>(exported_ids, exports->GetFRefList(), Unmangle);
      AddNames<CLRefList>(exported_ids, exports->GetLRefList(), Unmangle);

      const CImportsTuple *imports = ast->GetImports();
      FilterOutImports<CFRefList, CFRefTuple>(exported_ids, imports->GetFRefList(), Unmangle);
      FilterOutImports<CLRefList, CLRefTuple>(exported_ids, imports->GetLRefList(), Unmangle);
   }

   void PostProcessParsing(CAlfTuple* ast, std::string *source_file_name, bool is_first_file, string (*Unmangle)(string))
   {
      { // Set lau
         LAU::SetLAU(ast->GetLau()->GetSize()->GetSizeInBits().AsBaseIntType());
      }

      { // Set and check endianess
         if (ast->GetEndian() != "little_endian" && ast->GetEndian() != "big_endian")
         {
            throw runtime_error("Improper endian specification "+ast->GetEndian()+".");
         }
         if (is_first_file)
         {
            g_endianness = ast->GetEndian() == "little_endian"? Endianness::Little() : Endianness::Big();
         }
         else
         {
            Endianness endianness = ast->GetEndian() == "little_endian"? Endianness::Little() : Endianness::Big();
            if (g_endianness != endianness)
            {
               throw runtime_error("Can't link files with different endianess.");
            }
         }
      }

      { // Assign source file name - in case of linking the source reference is a part of the identifiers.
         AssignSourceFileToAllNodes(ast, source_file_name);
      }

      { // Filter out redundant imports. TODO! This should not really be needed since ther should be none
        // and in case they are there it shouldn't really matter.
        // However, we do this to not confuse some of the analyzes (i.e. the pointer analysis too much).
        FilterOutImports(ast, Unmangle);
      }
   }
}
