/*
 *  CAlfTreeExpandingHelper.cpp
 *  alfx
 *
 *  Created by Jesper Jonsson on 2009-04-18.
 *  Copyright 2009 Morning Lemon. All rights reserved.
 *
 */

#include "CAlfTreeExpandingHelper.h"
#include "CAlfTuple.h"
#include "CString.h"
#include "CMacroCallTuple.h"
#include "CMacroDefTuple.h"
#include "CMacroDefList.h"
#include "CAlfTreeTraversor.h"
#include "CMacroFormalArgList.h"
#include "CGenericList.h"
#include "CSize.h"
#include "CMacroFormalArg.h"
#include "CUnknownExpr.h"
#include "CLabelTuple.h"
#include "AStmt.h"
#include "CStmtList.h"
#include <sstream>

using namespace std;
namespace alf 
{
   CAlfTreeExpandingHelper::
   CAlfTreeExpandingHelper(const CAlfTuple* p_alf_tuple)
   :  alf_tuple(p_alf_tuple)
   {
      
   }
   
   const CMacroDefTuple* 
   CAlfTreeExpandingHelper::
   FindDefinition(const CString* definition_name, size_t argument_count)
   {
      const CMacroDefTuple* node = NULL;
      stringstream ss;
      ss << definition_name->Get() << "_" << argument_count;
      ss.flush();
      
      // Is the definition already cached?
      NameDefMap::iterator foundIt = found_defs.find(ss.str());
      if (foundIt != found_defs.end())
      {
         node = foundIt->second;
      }
      else
      {
         // Look up the definition by name, it should also match the 'argument_count'.
         const CMacroDefList* defs = alf_tuple->GetDefs();
         for (CMacroDefList::list_iterator it = defs->ConstIterator();
              it != defs->InvalidIterator();
              it++)
         {
            const CMacroDefTuple* def_tuple = *it;
            if (def_tuple->GetId() == definition_name->Get() && def_tuple->GetArgumentIdentifiers()->ElementCount() == argument_count)
            {
               found_defs[ss.str()] = def_tuple;
               node = def_tuple;
               break;
            }
         }
      }
      
      return node;
   }

   void
   CAlfTreeExpandingHelper::
   ValidateArgumentCount(const CMacroDefTuple* def, const CMacroCallTuple* macrocall)
   {  
      size_t def_arg_count = def->GetArgumentIdentifiers()->ElementCount();
      size_t mc_arg_count = macrocall->GetArguments()->ElementCount();
      if (def_arg_count != mc_arg_count)
      {
         stringstream ss;
         ss << "Argument count mismatch, macrodefinition '" << def->GetId() << "' was declared with ";
         ss << def_arg_count << " but was called with " << mc_arg_count;
         ss << " (Macrocall at  " << macrocall->GetCoord() << ", MacroDefinition at " << def->GetCoord() << ")";
         throw CException(ss.str());
      }
   }
   
   CGenericNode* 
   CAlfTreeExpandingHelper::
   Expand(const CGenericNode* node)
   {
      if (node->HasMacroCall() || node->GetNodeType() == CGenericNode::TYPE_MACRO_CALL_TUPLE)
         return ExpandMacrocall(node);
      else if (node->HasMacroFormalArg() || node->GetNodeType() == CGenericNode::TYPE_MACRO_FORMAL_ARG)
         return ExpandMacroFormalArg(node);
      else
      {
         stringstream ss;
         ss << "Given node '" << node->GetNodeTypeAsString() << "' isn't either a macrocall or a macroformalarg! (Node at " << node->GetCoord() << ")";
         throw CException(ss.str());
      }
   }
   
   CGenericNode* 
   CAlfTreeExpandingHelper::
   ExpandMacrocall(const CGenericNode* node)
   {
      // Convert to macrocall
      const CMacroCallTuple* macrocall = NULL;
      if (node->GetNodeType() == CGenericNode::TYPE_MACRO_CALL_TUPLE)
         macrocall = static_cast<const CMacroCallTuple*>(node);
      else
         macrocall = node->GetMacroCall();
      
      
      // Find a definition by name and argument count.
      const CMacroDefTuple* definition = FindDefinition(macrocall->GetDefinitionName(), macrocall->GetArguments()->ElementCount());
      if (definition == NULL)
      {
         stringstream ss;
         ss << "Couldn't find macrodefinition '" << macrocall->GetDefinitionName()->Get() << "' with " << macrocall->GetArguments()->ElementCount() << " argument(s). (Node at " << node->GetCoord() << ")";
         throw CException(ss.str());
      }
      else
      {
         // Detect macrocall recursion.
         /*for (NodeList::iterator it = macrodef_stack.begin();
              it != macrodef_stack.end();
              it++)
         {
            const CGenericNode* previous_def = *it;
            if (previous_def == definition)
            {
               stringstream ss;
               ss << "Detected recursion, macrocall to '" << definition->GetId() << "' with " << definition->GetArgumentIdentifiers()->ElementCount() << " arg(s) will end up in a stacksmash!";
               ss << " (Macrocall at line: " << macrocall->GetLine() << ", MacroDefinition at line: " << definition->GetLine() << ").";
               throw CException(ss.str());
            }
         }*/
         
         // Collect all the arguments that the macrocall was called with.
         MacroArgsMap argsNameValueMap;
         for (size_t i = 0; i < macrocall->GetArguments()->ElementCount(); i++)
         {
            string argName = definition->GetArgumentIdentifiers()->ElementAt(i)->GetIdentifier();
            const CGenericNode* val = macrocall->GetArguments()->ElementAt(i);
            
            argsNameValueMap[argName] = val;
         }
         
         // Push all the collected formalargs of the current macrocall to the stack of macrocall arguments.
         MacrodefArgsMap::iterator it = macro_args.find(definition);
         if (it == macro_args.end())
         {
            MacroArgsList list;
            list.push_back(argsNameValueMap);
            macro_args[definition] = list;
         }
         else
            it->second.push_back(argsNameValueMap);
         
         BeginExpand(definition);
         CGenericNode* definable = definition->definable;
         CGenericNode* new_node = ExpandAndConvert(definable, node->GetNodeType());
         EndExpand();
         
         // The macrocall has not been expanded, pop the macrocall arguments since they should not be needed anymore.
         macro_args[definition].pop_back();
         
         // Validate the expanded node's type and the unexpanded node's type.
         // If the types doesn't match, it could still be right since the parser couldn't decide
         // what type of node it should have created. This happens when a macrocall or formalarg
         // is placed in the code where an abstract class is excpected, e.g. an AExpr.
         if (!new_node->IsType(node->GetNodeType()) && !ValidateInvalidType(new_node, node))
         {
            stringstream ss;
            ss << "Expanded definable of macrodefinition '" << definition->GetId() << "' (" << definition->GetArgumentIdentifiers()->ElementCount() << " args) has different type than the target type ";
            ss << new_node->GetNodeTypeAsString() << " != " << node->GetNodeTypeAsString();
            ss << " (Node at " << node->GetCoord() << ", MacroDefinition at " << definition->GetCoord() << ")";
            throw CException(ss.str());
         }
         else
            return new_node;
      }    
   }
   
   bool
   CAlfTreeExpandingHelper::
   ValidateInvalidType(const CGenericNode* new_node, const CGenericNode* node)
   {
      // Was it an unknown val node? Then it can be expanded to TYPE_VAL.
      if (node->IsType(CGenericNode::TYPE_UNKNOWN_VAL) && 
          new_node->IsType(CGenericNode::TYPE_VAL))
      {
         return true;
      }
      // Was node an actual macrocall? Just pass it along and let the parents check for the right type.
      // This only happens when you pass a macrocall as an formalarg.
      else if (node->IsType(CGenericNode::TYPE_MACRO_CALL_TUPLE))
      {
         return true;
      }
      // Was it an unknown expr node? Then check which types the parser says is ok that the node can expand to.
      else if (node->IsType(CGenericNode::TYPE_UNKNOWN_EXPR))
      {
         const CUnknownExpr* unknown_expr = dynamic_cast<const CUnknownExpr*> (node);
         return unknown_expr->IsValidExpandedType(new_node->GetNodeType());
      }
      // This is a hack to make macrocall and macroformalarg nodes that expand 
      // to labels (that are contained within CUnknownStmt nodes) don't throw an
      // error. The stmt should not be holding a label, if so the grammar is invalid.
      // See CStmtList::Expand and CUnknownStmt::OnExpanded.
      else if (node->IsType(CGenericNode::TYPE_UNKNOWN_STMT) && 
               new_node->IsType(CGenericNode::TYPE_LABEL_TUPLE) &&
               dynamic_cast<const AStmt*>(node)->GetLabel() == NULL)
      {
         return true;
      }
      // Let a macrocall that is supposed to expand to a single stmt also expand to a list of stmts. 
      // See CStmtList::Expand for futher knowledge.
      else if (node->IsType(CGenericNode::TYPE_UNKNOWN_STMT) && 
               new_node->IsType(CGenericNode::TYPE_STMT_LIST))
      {
         return true;
      }
      // An unknown statement that expand to an actual statement is valid.
      else if (node->IsType(CGenericNode::TYPE_UNKNOWN_STMT) && 
               !new_node->IsType(CGenericNode::TYPE_UNKNOWN_STMT) && 
               new_node->IsType(CGenericNode::TYPE_STMT))
      {
         return true;
      }
      else
      {
         return false;
      }
   }
   
   CGenericNode*
   CAlfTreeExpandingHelper::
   ExpandMacroFormalArg(const CGenericNode* node)
   {
      if (macrocall_stack.size() <= 0)
      {
         stringstream ss;
         ss << "Trying to expand a macroformalarg without a macrocall?! (Node at " << node->GetCoord() << ")";
         throw CException(ss.str());   
      }
      
      if (macrodef_stack.size() <= 0)
      {
         stringstream ss;
         ss << "Trying to expand a macroformalarg without a macrodefinition?! (Node at " << node->GetCoord() << ")";
         throw CException(ss.str());   
      }
      
      // Convert to the actual formalarg.
      const CMacroFormalArg* formal_arg = NULL;
      if (node->GetNodeType() == CGenericNode::TYPE_MACRO_FORMAL_ARG)
         formal_arg = static_cast<const CMacroFormalArg*>(node);
      else
         formal_arg = node->GetMacroFormalArg();
      
      // Find the argument that should be replaced with the formalarg.
      const CMacroDefTuple* definition = dynamic_cast<const CMacroDefTuple*>(node->GetParent(CGenericNode::TYPE_MACRO_DEF_TUPLE));
      if (definition == NULL)
      {
         stringstream ss;
         ss << "Couldn't find the parent macrodefinition for node at " << node->GetCoord() << "?!";
         throw CException(ss.str());
      }
         
      MacrodefArgsMap::iterator it = macro_args.find(definition);
      if (it == macro_args.end())
         throw CException("Couldn't find the parent macrodefinion in the macro_args map?!");
         
      MacroArgsMap arg_vals = it->second.back();
      if (arg_vals.find(formal_arg->GetIdentifier()) == arg_vals.end())
      {
         stringstream ss;
         ss << "Couldn't find formalarg '" << formal_arg->GetIdentifier() << "' in macrodefinition '" << definition->GetId() << "' ";
         ss << "(FormalArg at " << formal_arg->GetCoord() << ", MacroDefinition at " << definition->GetCoord() << ")";
         throw CException(ss.str());   
      }
      else
      {
         const CGenericNode* arg_val = arg_vals[formal_arg->GetIdentifier()];
         return ExpandAndConvert(arg_val, node->GetNodeType());
      }
   }
   
   
   CGenericNode*
   CAlfTreeExpandingHelper::
   ExpandAndConvert(const CGenericNode* node, CGenericNode::TYPE target_type)
   {
      CGenericNode* expanded_node = node->Expand(this);
      assert(expanded_node != NULL);
      
      // Nodes may expand to the wrong type but is still 
      // compatible, fix that.
      if (target_type == CGenericNode::TYPE_SIZE)
      {
         if (expanded_node->IsType(CGenericNode::TYPE_STRING))
         {
            expanded_node = new CSize(expanded_node->GetCoord(), 
                           static_cast<CString*>(expanded_node));
         }
      }
      else if (target_type == CGenericNode::TYPE_SCOPE_TUPLE)
      {
         if (expanded_node->IsType(CGenericNode::TYPE_STMT_LIST))
         {
            CStmtList* list = dynamic_cast<CStmtList*>(expanded_node);
            if (list->ElementCount() == 1 && 
                list->ElementAt(0)->IsType(CGenericNode::TYPE_SCOPE_TUPLE))
            {
               expanded_node = list->Explode();
            }
         }
      }
      
      return expanded_node;
   }
   
   int 
   CAlfTreeExpandingHelper::
   GetLine()
   {
      if (macrocall_stack.size() > 0)
         return macrocall_stack.back()->GetLine();
      else
         return node_stack.back()->GetLine();
   }
   
   void
   CAlfTreeExpandingHelper::
   BeginExpand(const CGenericNode* node)
   {
      node_stack.push_back(node);
      if (node->HasMacroCall())
         macrocall_stack.push_back(node->GetMacroCall());
      else if (node->GetNodeType() == CGenericNode::TYPE_MACRO_CALL_TUPLE)
         macrocall_stack.push_back(node);
      else if (node->GetNodeType() == CGenericNode::TYPE_MACRO_DEF_TUPLE)
         macrodef_stack.push_back(node);
   }
   
   void
   CAlfTreeExpandingHelper::
   EndExpand()
   {
      const CGenericNode* current_node = node_stack.back();
      node_stack.pop_back();
      
      if (current_node->HasMacroCall() || current_node->GetNodeType() == CGenericNode::TYPE_MACRO_CALL_TUPLE)
         macrocall_stack.pop_back();
      else if (current_node->GetNodeType() == CGenericNode::TYPE_MACRO_DEF_TUPLE)
         macrodef_stack.pop_back();
   }
   
   class CReplacementsFinder : public CAlfTreeTraversor::INodeVisitor
   {
   private:
      bool onBeginVisit(const CGenericNode* node)
      {
         return true;
      }
      
      void onEndVisit(const CGenericNode* node)
      {
      }
   };
}
