// $Id $

#include "CFloatListTuple.h"
#include "CSize.h"
#include "CNumber.h"
#include "CString.h"
#include "internal.h"
#include "CListNode.inl"

using namespace alf;
using namespace std;

static inline
const std::vector<CFloatValTuple*>
TransformElements(const COORD& coord, CSize* frac_size, CSize* exp_size, const vector<CString*>& list)
{
   vector<CFloatValTuple*> transformedList;

   for (vector<CString*>::const_iterator it = list.begin();
        it != list.end();
        it++)
   {
      transformedList.push_back(new CFloatValTuple(coord, frac_size->Copy(), exp_size->Copy(), *it));
   }

   return transformedList;
}

CFloatListTuple::
CFloatListTuple(const COORD& p_coord, CSize* p_exp_size, CSize* p_frac_size, const vector<CString*>& p_list)
:  CGenericNode(p_coord),
   CListNode<CFloatValTuple>(p_coord, 
                             "float_list", 
                             TransformToVector<CSize>(2, p_exp_size, p_frac_size), 
                             TransformElements(p_coord, p_exp_size, p_frac_size, p_list)),
   AVal(p_coord)
{
   
}

CFloatListTuple::
CFloatListTuple(const COORD& p_coord, CSize* p_exp_size, CSize* p_frac_size, const vector<CFloatValTuple*>& p_list)
:  CGenericNode(p_coord),
   CListNode<CFloatValTuple>(p_coord, 
                             "float_list", 
                             TransformToVector<CSize>(2, p_exp_size, p_frac_size), 
                             p_list),
   AVal(p_coord)
{
   
}

CFloatListTuple::
~CFloatListTuple()
{
}

CFloatListTuple*
CFloatListTuple::
Copy() const
{
   return new CFloatListTuple(*this);
}

const CSize*
CFloatListTuple::
GetExpSize() const
{
   return size_nodes[1];
}


const CSize*
CFloatListTuple::
GetFracSize() const
{
   return size_nodes[0];
}

CGenericNode* 
CFloatListTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   const std::vector<CFloatValTuple*> expandedList = ExpandList(helper);
   return new CFloatListTuple(GetCoord(),
                              dynamic_cast<CSize*> (GetFracSize()->Expand(helper)),
                              dynamic_cast<CSize*> (GetExpSize()->Expand(helper)),
                              expandedList);
}

void
CFloatListTuple::
OnPrint(std::ostream& stream, int indent) const
{
   stream << Indent(indent) << "{ " << name << '\n';
   ++indent;
   stream << Indent(indent);
   for (std::vector<CSize*>::const_iterator it = size_nodes.begin(), it_end = size_nodes.end(); it != it_end; ++it) {
      (*it)->Print(stream, 0);
      stream << ' ';
   }
   stream << '\n';
   for (const_list_iterator it = ConstIterator(), it_end = InvalidIterator(); it != it_end; ++it) {
      stream << Indent(indent);
      (*it)->GetFloatValue()->Print(stream, indent);
      stream << '\n';
   }
   --indent;
   stream << Indent(indent) << '}';
   stream.flush();
}

template class alf::CListNode<CFloatValTuple>;
