/* $Id: CArgDeclList.cpp 1688 2010-01-25 20:14:04Z lkg02 $ */

#include "CArgDeclList.h"
#include "CAllocTuple.h"

using namespace alf;

CArgDeclList::
CArgDeclList(const COORD& coord, const std::vector<CAllocTuple*>& p_list)
:  CGenericNode(coord),
   CListNode<CAllocTuple>(coord, "arg_decls", p_list)
{
   
}

CArgDeclList::
~CArgDeclList()
{
}

CArgDeclList*
CArgDeclList::
Copy() const
{
   return new CArgDeclList(*this);
}

CGenericNode* 
CArgDeclList::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   const std::vector<CAllocTuple*> expandedList = ExpandList(helper);
   return new CArgDeclList(GetCoord(), expandedList);
}
