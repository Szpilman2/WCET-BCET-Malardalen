// $Id $

#ifndef ALF_CGENERICNODE_H
#define ALF_CGENERICNODE_H

#include <iostream>
#include <vector>
#include <set>

namespace alf
{
class CMacroCallTuple;
class CMacroFormalArg;
class CAlfTreeExpandingHelper;
class AlfNodeVisitor;

//TODO: Move to separate file.
typedef struct
{
   std::string *source_file;
   int line;
   int col;

   void Print(std::ostream& o) const { o << "(" << line << ", " << col << ")"; }
} COORD;

inline std::ostream& operator<< (std::ostream& out, const COORD& c)
{
   c.Print(out);
   return out;
}

inline int compare(const COORD &a, const COORD &b) {
   int cmp = a.source_file->compare(*b.source_file);
   if (cmp != 0) return cmp;
   cmp = a.line - b.line;
   if (cmp != 0) return cmp;
   return a.col - b.col;
}

/**
 * Abstract base class of all nodes in the ALF parse tree.
 * Common properties for all nodes are that they have a link to their parent,
 * and are associated with a type that corresponds to a rule in the ALF grammar.
 * The parent and type are set automatically when a node is created.
 * All nodes can be copied and printed to a stream.
 * The easiest way to print a node is to use the << operator.
 */

class CGenericNode
{
public:
   /**
    * Enumeration type that lists all different types of node, including 
    * both leaf nodes and intermediate nodes in the class tree.
    */
   enum TYPE
   {
     TYPE_GENERIC_NODE,
     TYPE_GENERIC_LIST,
     TYPE_LIST_NODE, 
     TYPE_DECL_LIST,
     TYPE_LAU_TUPLE, 
     TYPE_EXPORTS_TUPLE, 
     TYPE_IMPORTS_TUPLE, 
     TYPE_FREF_LIST, 
     TYPE_LREF_LIST, 
     TYPE_EXPR_LIST, 
     TYPE_FREF_TUPLE, 
     TYPE_LREF_TUPLE, 
     TYPE_INIT_LIST, 
     TYPE_FUNC_LIST, 
     TYPE_INIT_TUPLE, 
     TYPE_SCOPE_TUPLE,
     TYPE_REF_TUPLE, 
     TYPE_ALLOC_TUPLE,  
     TYPE_ARGDECL_LIST, 
     TYPE_STMT_LIST, 
     TYPE_FREE_STMT_TUPLE, 
     TYPE_NULL_STMT_TUPLE, 
     TYPE_STORE_STMT_TUPLE, 
     TYPE_JUMP_STMT_TUPLE, 
     TYPE_RETURN_STMT_TUPLE, 
     TYPE_CALL_STMT_TUPLE, 
     TYPE_SWITCH_STMT_TUPLE, 
     TYPE_TARGET_TUPLE,
     TYPE_TARGET_LIST,
     TYPE_DEFAULT_TUPLE, 
     TYPE_DYNALLOC_EXPR_TUPLE, 
     TYPE_UNDEFINED_EXPR_TUPLE, 
     TYPE_LOAD_EXPR_TUPLE, 
     TYPE_COMPLABEL_EXPR_TUPLE, 
     TYPE_LABEL_TUPLE, 
     TYPE_COMPADDR_EXPR_TUPLE, 
     TYPE_ADDR_EXPR_TUPLE, 
     TYPE_OP_EXPR_TUPLE, 
     TYPE_FLOATVAL_TUPLE,
     TYPE_INTVAL_TUPLE, 
     TYPE_CHARSTRING_TUPLE, 
     TYPE_CONSTREPEAT_TUPLE, 
     TYPE_FLOAT_LIST, 
     TYPE_INT_LIST, 
     TYPE_CONST_LIST, 
     TYPE_SIZE, 
     TYPE_SIZE_LIST, 
     TYPE_MACRO_CALL_TUPLE, 
     TYPE_MACRO_FORMAL_ARG, 
     TYPE_MACRO_FORMAL_ARG_LIST, 
     TYPE_MACRO_DEF_TUPLE, 
     TYPE_MACRO_DEF_LIST, 
     TYPE_STRING,  
     TYPE_UNKNOWN_VAL, 
     TYPE_UNKNOWN_STMT, 
     TYPE_UNKNOWN_CONST, 
     TYPE_UNKNOWN_EXPR,
     TYPE_ALF_TUPLE, 
     TYPE_FUNC_TUPLE, 
     // Type codes of abstract classes:
     TYPE_CONST,
     TYPE_EXPR, 
     TYPE_NUM_VAL, 
     TYPE_STMT, 
     TYPE_TARGET, 
     TYPE_VAL,
     // Type codes of ALF abstract assignments
     TYPE_ALF_ABS_STORE_STMT,
     TYPE_ALF_ABS_INIT_TUPLE,
     
     // If more types are added, please update 

     TYPE_NR_OF_TYPES // <- NOTE! meta-member that gives the # of members of this enum; MUST lie at the end!
   };

   /**
    * Constructor
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    */
   CGenericNode(COORD coord);

   /**
    * Construct a node of 'type' that holds a macrocall.
    * @param coord            The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param macro_call_tuple The macrocall tuple
    */
   CGenericNode(COORD coord, CMacroCallTuple* macro_call_tuple);

   /**
    * Construct a node of 'type' that holds a macro formal-argument-identifier string.
    * @param coord            The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param macro_formal_arg The macro formal-argument-identifier.
    */
   CGenericNode(COORD coord, CMacroFormalArg* macro_formal_arg);

   virtual ~CGenericNode();

   /**
    * Makes a deep copy of the node.
    * @return  A pointer to a copy of the node. The pointer has the same type as the node calling the function
    * and can be downcasted to this type if needed.
    */
   virtual CGenericNode* Copy() const = 0;
   
   /**
    * Accept visit from an AlfNodeVisitor. Should be implemented by all "leaf" subclasses, with a call
    * visitor->VisitT(*this); where T is the name of the class with the "C" prefix omitted.
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const = 0;

   /**
    * Expand the node so that all macrocalls is substituted with the actual nodes.
    * @return  A pointer to a new node without any macrocalls. The caller is
    * responsible to deallocate the returned node.
    */
   CGenericNode* Expand(CAlfTreeExpandingHelper* helper) const;

   /**
    * Prints information about the node using the ALF syntax.
    * @param o       The stream to output the text to
    * @param indent  The number of tabs that should preceed the text (a tab is defined as three spaces)
    */
   void Print(std::ostream& o, int indent) const;
   void Print(std::ostream& o) const {Print(o, 0);};
   void Print(void) const {Print(std::cout);};
   /**
    * Prints information about the node using the ALF syntax and adds a linebreak.
    * @param o       The stream to output the text to
    * @param indent  The number of tabs that should preceed the text (a tab is defined as three spaces)
    */
   void PrintWithEndl(std::ostream& o, int indent = 0) const;
   /**
    * Prints information about the node using the ALF syntax, and switches linebreaks to BR tags.
    * @param o       The stream to output the text to
    * @param indent  The number of tabs that should preceed the text (a tab is defined as three spaces)
    */
   void PrintAsHTML(std::ostream& o, int indent) const;
   
   /**
    * Gets the line number where the node was created.
    * @return  The number of the line in the parsed file where the rule creating this node was found.
    */
   int GetLine() const;
   
   /**
    * Gets the column number where the node was created.
    * @return  The number of the column in the parsed file where the rule creating this node was found.
    */
   int GetColumn() const;

   const COORD& GetCoord() const;

   /**
    * Assigns a source file name to this node.
    * @param source_file The name of the source file.
    */
   void SetSourceFile(std::string *source_file) { coord.source_file = source_file; }

   /**
    * @return The previously assigned source file name of this node.
    * @pre SetSourceFile() has been called.
    */
   const std::string *GetSourceFile() const { return coord.source_file; }

   /**
    * Gets the parent node in the parse tree.
    * @return  A pointer to the above node in the parse tree, the owner of the current node.
    */
   CGenericNode* GetParent() const;

   /**
   * Search the parents of the parse tree for the first node that is of type 'type'.
   * @return  A pointer to the found node, otherwise NULL.
   */
   CGenericNode* GetParent(TYPE type) const;

   /**
   * To get the direct children in the parse tree of the given node. 
   * @return  A pointer to a set of generic nodes. 
   */
   std::set<CGenericNode *> * GetChildren(void);

   unsigned GetUid() { return uid; }

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const = 0;

   /** 
    * For printing the type of a node with an informative name.
    * @return  The node type as a string.
    */
   std::string GetNodeTypeAsString() const;
   /** To get the type as a string **/
   static std::string GetTypeAsString(TYPE t);

   /**
    * Checks if \a t is either the type of this node or the type of any of its superclasses in the alf tree.
    * (This function is a special case since it is the root in the class hierarchy)
    * @return true if the requested type matches this node type or any super class' else false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_GENERIC_NODE; }

   /** To get the number of types **/
   static unsigned int NrOfTYPEs() { return (unsigned int)TYPE_NR_OF_TYPES; } 
   
   bool HasMacroCall() const { return (macro_call_node != NULL); }
   bool HasMacroFormalArg() const { return (macro_formal_arg_node != NULL); }
   const CMacroCallTuple* GetMacroCall() const { return macro_call_node; }
   const CMacroFormalArg* GetMacroFormalArg() const { return macro_formal_arg_node; }

protected:

   CGenericNode(const CGenericNode&);
   
   /**
    * Prints out a number of tabs to a stream.
    * @param o       The stream to print to
    * @param indent  The number of tabs to print out (a tab is defined as three spaces)
    */
   static void PrintIndent(std::ostream& o, int indent);
   
   /**
    * Parameterized output stream manipulator that outputs an indentation space
    */
   class Indent
   {
   public:
      Indent(int level) : level(level) {}

      std::ostream& Print(std::ostream& o) const
      {
         PrintIndent(o, level);
         return o;
      }

   private:
      int level;
   };

   /**
    * Called by Print methods if node doesn't contain a macrocall or macroformalarg.
    */
   virtual void OnPrint(std::ostream& o, int indent) const = 0;
   
   /**
    * Called by Expand method if node doesn't contain a macrocall or macroformalarg.
    */
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const { return NULL; }
   
   /**
    * Called by Expand method after the node has been expanded.
    */
   virtual void OnAfterExpand(CAlfTreeExpandingHelper* helper, CGenericNode* expanded_node) const { }

   /**
    * Sets the current node to be the parent of another node.
    * @param child   A node that can be considered a child of this node.
    *                If a node has other nodes as members, they will automatically be set as children of that node.
    */
   void SetParent(CGenericNode* child);
   /**
    * Sets the current node to be the parent of a list of other nodes.
    * @param childList  A vector of nodes that should have the current node set as their parent.
    *                   This function should be used when a node has a vector of other nodes as a member.
    */
   template <class T> std::vector<T*> SetParents(std::vector<T*> childList);

   /**
    * The line and column numbers the in the parsed file where the rule creating this node was found.
    */
   COORD coord;
   static unsigned guid;
   unsigned uid;

   /**
    * The node above this node in the parse tree. Will be updated by
    * the SetParent function.
    */
   CGenericNode* parent;

   /**
    * The nodes below in the parse tree. Will be updated by the
    * SetParent() function.
    */
   std::set<CGenericNode *> children;

private:
   CMacroFormalArg* macro_formal_arg_node;
   CMacroCallTuple* macro_call_node;

   friend std::ostream& operator <<(std::ostream& o, const CGenericNode& node);
   friend std::ostream& operator <<(std::ostream& o, const Indent& indent);
};

inline std::ostream& operator << (std::ostream &o, const CGenericNode& node) {node.Print(o); return o;}

inline std::ostream& operator <<(std::ostream& o, const CGenericNode::Indent& indent) {return indent.Print(o);}

template <class T>
std::vector<T*>
CGenericNode::
SetParents(std::vector<T*> childList)
{
   for (typename std::vector<T*>::iterator it = childList.begin();
      it != childList.end();
      it++)
   {
      if (*it)
         (*it)->parent = this;
   }
   
   return childList;
}

}

#endif

