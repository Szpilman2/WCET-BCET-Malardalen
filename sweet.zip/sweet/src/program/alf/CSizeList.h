// $Id $

#ifndef ALF_CSIZELIST_H
#define ALF_CSIZELIST_H

#include "CListNode.h"
#include "AlfNodeVisitor.h"

namespace alf
{
class CSize;

class CSizeList : public CListNode<CSize>
{
public:
   CSizeList(const COORD& coord, const std::vector<CSize*>& p_list=std::vector<CSize*>());
   virtual ~CSizeList();

   virtual CSizeList* Copy() const;
   
   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitSizeList(*this);}

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_SIZE_LIST; } 

  /** 
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_SIZE_LIST || CListNode<CSize>::IsType(t); }
protected:
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
};
   
}

#endif

