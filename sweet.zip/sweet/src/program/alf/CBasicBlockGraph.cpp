#include "CBasicBlockGraph.h"
#include "graphs/cfg/CFlowGraph.h"
#include "CException.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/tools/CGraph.inl"
#include "CBasicBlockGraphNode.h"
#include "CGenericNode.h"
#include <sstream>
#include <fstream>
#include <typeinfo>
#include <cstdlib>

using namespace std;
using namespace alf;

template class CGraph<CBasicBlockGraphNode>;

namespace alf
{
   class CBasicBlockGraphCreator
   {
   public:
      /** Starts the graph creation algorithm.

          Each node will represent one or more connected statements
          from the CFlowGraph which creates the basic block.

          The basic outline of the algorithm is:

          1. Go through all the nodes in an CFlowGraph.
            1.1  If the node is already visited, just add an edge and return. The edge should start from
                 the current basic block and end at the basic block where the node is contained in.
            1.2. If a node has more than one successor or predecessor create a new basic block and add an
                 edge between both basic blocks. Set the new basic block as the current one.
            1.3. Add the CFlowGraph's statement to the current basic block.
            1.4  Set the current basic block as visited.
      */
      CBasicBlockGraphCreator(CFlowGraphNode* p_flow_node, CBasicBlockGraph* p_graph)
      :  graph(p_graph)
      {
         Traverse(p_flow_node, NULL, true);
      }

   private:
      void
      Traverse(CFlowGraphNode* flow_node, CBasicBlockGraphNode* current_block_node, bool shouldCreateNewBlock)
      {
         if (IsVisited(flow_node))
         {
            CBasicBlockGraphNode* block_node = GetOrCreateBasicBlock(flow_node, NULL, false);
            graph->AddEdge(current_block_node, block_node);
            return;
         }

         CBasicBlockGraphNode* block_node = GetOrCreateBasicBlock(flow_node, current_block_node, shouldCreateNewBlock);
         SetVisited(flow_node);
         current_block_node = block_node;
         shouldCreateNewBlock = flow_node->SuccSize() > 1;

         for (CFlowGraphNode::succ_iterator it = flow_node->SuccBegin();
              it != flow_node->SuccEnd();
              it++)
         {
            Traverse(it->node, current_block_node, shouldCreateNewBlock);
         }
      }

      void
      SetVisited(CFlowGraphNode* flow_node)
      {
         visited_flow_nodes.push_back(flow_node);
      }

      bool
      IsVisited(CFlowGraphNode* flow_node)
      {
         for (vector<CFlowGraphNode*>::iterator it = visited_flow_nodes.begin();
              it != visited_flow_nodes.end();
              it++)
         {
            if (*it == flow_node)
               return true;
         }

         return false;
      }

      CBasicBlockGraphNode*
      GetOrCreateBasicBlock(CFlowGraphNode* flow_node, CBasicBlockGraphNode* current_block_node, bool shouldCreateNewBlock)
      {
         map<CFlowGraphNode*, CBasicBlockGraphNode*>::iterator block_node_it =
            flow_node_to_block_node.find(flow_node);

         if (shouldCreateNewBlock || block_node_it == flow_node_to_block_node.end())
         {
            if (!shouldCreateNewBlock && flow_node->PredSize() < 2 && current_block_node)
            {
               InsertFlowNode(flow_node, current_block_node);
               return current_block_node;
            }
            else
            {
               CBasicBlockGraphNode* block_node = new CBasicBlockGraphNode;
               InsertFlowNode(flow_node, block_node);
               graph->AddNode(block_node);

               if (current_block_node)
                  graph->AddEdge(current_block_node, block_node);

               return block_node;
            }
         }
         else
            return block_node_it->second;
      }
      void
      InsertFlowNode(CFlowGraphNode* flow_node, CBasicBlockGraphNode* block_node)
      {
         CGenericNode *generic_node = dynamic_cast<CGenericNode*>(flow_node->Stmt());
         block_node->Insert(generic_node, flow_node->Id());
         flow_node_to_block_node[flow_node] = block_node;
      }

      CBasicBlockGraph* graph;
      vector<CFlowGraphNode*> visited_flow_nodes;
      map<CFlowGraphNode*, CBasicBlockGraphNode*> flow_node_to_block_node;
   };
}

CBasicBlockGraph::
CBasicBlockGraph(CFlowGraph* flow_graph)
{
   if (!flow_graph->FindRoot())
      throw CException("Coudn't find root in graph 'flow_graph'");
   else
   {
      CFlowGraphNode* flowNode = flow_graph->GetEntry();
      CBasicBlockGraphCreator(flowNode, this);
   }
}

CBasicBlockGraph::
~CBasicBlockGraph()
{

}

void
CBasicBlockGraph::
PrintAsDot(ostream &o)
{
   o << "digraph G {" << endl;
   //o << "node [shape=plaintext];" << endl;

   for (node_iterator it = NodesBegin();
        it != NodesEnd();
        it++)
   {
      CBasicBlockGraphNode* node = *it;
      node->PrintAsDot(o);
   }

   PrintWithNodeNumbers(o);

   o << "}" << endl;
}

int
CBasicBlockGraph::
PrintToPdf(std::string file_path)
{
   stringstream ss_dot_file;
   ss_dot_file << file_path << ".dot";

   ofstream pdf_file;
   stringstream ss_command;

   pdf_file.open(ss_dot_file.str().c_str());
   if (pdf_file.is_open())
   {
      PrintAsDot(pdf_file);
      pdf_file.close();

      ss_command << "dot -Tpdf -o" << file_path << " " << ss_dot_file.str();
   }

   return system(ss_command.str().c_str());
}
