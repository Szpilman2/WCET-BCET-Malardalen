// $Id $

#ifndef ALF_AConst_H
#define ALF_AConst_H

#include <iostream>
#include "AVal.h"

namespace alf
{

/**
 * The super class of all nodes that can be considered constants.
 * Constants is also considered to be values.
 * It represents the following rules in the ALF grammar:
 * 
 * CONST -> LREF | ADDR | FREF | LABEL | NUM_VAL | { undefined SIZE }
 *
 * The class doesn't overload the CGenericNode::Copy method because of multiple inheritance
 * conflicts. Using that method is still fine, you just have to explicitly cast to AConst.
 *
 * @see CLRefTuple, CAddrTuple, CFRefTuple, CLabelTuple, ANumVal, CUndefinedExprTuple, AVal.
 */

class AConst : public AVal
{
public:
   /**
    * Constructor, passes all parameters to super classes.
    *
    * @param coord      The line and column numbers in the parsed file where the rule creating this node was found.
    */
   AConst(COORD coord);
   
   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~AConst();

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_CONST || AVal::IsType(t); }

private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   AConst(const AConst&);
   
   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   AConst& operator=(const AConst&);
};

}

#endif

