// $Id $

#ifndef ALF_CEXPORTSTUPLE_H
#define ALF_CEXPORTSTUPLE_H

#include "CGenericNode.h"
#include "AlfNodeVisitor.h"

namespace alf
{
class CFRefList;
class CLRefList;
class ASTFilter;

/**
 * A node containing declarations of exported symbols.
 * It represents the following rule in the ALF grammar:
 * EXPORTS -> { exports FREFS LREFS }
 *
 * @see CFRefList, CLRefList, CGenericNode
 */

class CExportsTuple : public CGenericNode
{
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_EXPORTS_TUPLE
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord   The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param frefs   A list of frame references.
    * @param lrefs   A list of label references.
    */
   CExportsTuple(COORD coord, CFRefList* frefs, CLRefList* lrefs);

   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CExportsTuple();

   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to 
    *          deallocate the memory.
    */
   virtual CExportsTuple* Copy() const;

   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitExportsTuple(*this);}

   /**
    * @return The node containing a list of frame references.
    */
   const CFRefList* GetFRefList() const;

   /**
    * @return The node containing a list of frame references.
    */
   CFRefList* GetFRefList();

   /**
    * @return The node containing a list of label references.
    */
   const CLRefList* GetLRefList() const;

   /**
    * @return The node containing a list of label references.
    */
   CLRefList* GetLRefList();

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_EXPORTS_TUPLE; }

   /**
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_EXPORTS_TUPLE || CGenericNode::IsType(t); }

   /**
    * Moves the elements from another exports tuple to this.
    * @param other The other exports tuple.
    * @param Unmangle Function to unmangle identifiers.
    * @post The elements that was previously in other is now in this. Other is empty.
    */
   void Link(CExportsTuple &other, std::string (*Unmangle)(std::string));

   /**
    * Moves all exported elements from @a other to this list. No checks are made that
    * the resulting program is correct.
    */
   void Merge(CExportsTuple& other);

   /**
    * Prints to @a o the exported components for which filter->IncludeFRefTuple() or
    * filter->IncludeLRefTuple(), depending on the type of component, returns @c true
    */
   void PrintFiltered(std::ostream& o, int indentation, ASTFilter* filter) const;

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CExportsTuple(const CExportsTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CExportsTuple& operator=(const CExportsTuple&);

   /**
    * A list of frame references.
    */
   CFRefList* frefs;

   /**
    * A list of label references.
    */
   CLRefList* lrefs;
};

}

#endif

