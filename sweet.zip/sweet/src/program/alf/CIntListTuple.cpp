// $Id $

#include "CIntListTuple.h"
#include "CSize.h"
#include "CNumber.h"
#include "CListNode.inl"

using namespace alf;
using namespace std;

static inline string GetListName(CIntNumValTuple::INT_TYPE element_type)
{
   switch (element_type)
   {
      case CIntNumValTuple::BIN:
         return "bin_list";
      case CIntNumValTuple::HEX:
         return "hex_list";
      case CIntNumValTuple::DEC_SIGNED:
         return "dec_list";
      case CIntNumValTuple::DEC_UNSIGNED:
         return "udec_list";
   }

   return "";
}

static inline
const std::vector<CIntNumValTuple*>
TransformElements(const COORD& coord, CIntNumValTuple::INT_TYPE element_type, CSize* size, const vector<CString*>& list)
{
   vector<CIntNumValTuple*> transformedList;

   for (vector<CString*>::const_iterator it = list.begin();
        it != list.end();
        it++)
   {
      transformedList.push_back(new CIntNumValTuple(coord, element_type, size->Copy(), *it));
   }

   return transformedList;
}

CIntListTuple::
CIntListTuple(const COORD& coord, CIntNumValTuple::INT_TYPE element_type, CSize* size, const vector<CString*>& p_list)
:  CGenericNode(coord),
   CListNode<CIntNumValTuple>(coord, GetListName(element_type), size, TransformElements(coord, element_type, size, p_list)),
   AVal(coord)
{
}

CIntListTuple::
CIntListTuple(const COORD& coord, string element_type_name, CSize* size, const vector<CIntNumValTuple*>& p_list)
:  CGenericNode(coord),
CListNode<CIntNumValTuple>(coord, element_type_name, size, p_list),
AVal(coord)
{
}

CIntListTuple::
~CIntListTuple()
{
}

CIntListTuple*
CIntListTuple::
Copy() const
{
   return new CIntListTuple(*this);
}

CGenericNode* 
CIntListTuple::
OnExpand(CAlfTreeExpandingHelper* helper) const
{
   const std::vector<CIntNumValTuple*> expandedList = ExpandList(helper);
   return new CIntListTuple(GetCoord(), name, GetSizeNodes()[0], expandedList);
}

void
CIntListTuple::
OnPrint(std::ostream& stream, int indent) const
{
   stream << Indent(indent) << "{ " << name << '\n';
   ++indent;
   stream << Indent(indent);
   for (std::vector<CSize*>::const_iterator it = size_nodes.begin(), it_end = size_nodes.end(); it != it_end; ++it) {
      (*it)->Print(stream, 0);
      stream << ' ';
   }
   stream << '\n';
   for (const_list_iterator it = ConstIterator(), it_end = InvalidIterator(); it != it_end; ++it) {
      stream << Indent(indent);
      (*it)->GetNumber()->Print(stream, indent);
      stream << '\n';
   }
   --indent;
   stream << Indent(indent) << '}';
   stream.flush();
}

template class alf::CListNode<CIntNumValTuple>;
