// $Id $

#ifndef ALF_CLoadExprTuple_H
#define ALF_CLoadExprTuple_H

#include "AExpr.h"
#include "AlfNodeVisitor.h"

namespace alf
{
/**
 * A node representing a loading of a value at the address given by ADDR_EXPR.
 * It corresponds to the following rule in the ALF-grammar:
 * EXPR -> { load SIZE ADDR_EXPR }
 * 
 * @see CSize, AExpr
 */
class CSize;

class CLoadExprTuple : public AExpr
{
public:
   /**
    * Constructor, initializes all members from the parameters given.
    * Also sets this node as parent to the incoming nodes, and sets the CGenericNode::TYPE to TYPE_LOAD_EXPR_TUPLE.
    * The class is responsible to deallocate all the arguments.
    *
    * @param coord      The line and column numbers the in the parsed file where the rule creating this node was found.
    * @param size       The size of the loaded value.
    * @param addr_expr  An address expression describing the addres to load from.
    */
   CLoadExprTuple(COORD coord, CSize *size, AExpr *addr_expr);
   
   /**
    * Deallocates all the memory that the node is using.
    */
   virtual ~CLoadExprTuple();
   
   /**
    * Performs a deep copy of the node.
    * @returns A completely new set of nodes. The caller is responsible to 
    *          deallocate the memory.
    */
   virtual CLoadExprTuple* Copy() const;
   
   /**
    * Accept visit from an AlfNodeVisitor
    */
   virtual void AcceptVisitor(AlfNodeVisitor * visitor) const {visitor->VisitLoadExprTuple(*this);}

   /**
    * @return The address expression describing the addres to load from.
    */
   const AExpr * GetAddrExpr() const;

   /**
    * Gets the type of the node.
    * @return  The type of the node so that it can be identified quickly.
    */
   virtual TYPE GetNodeType() const { return TYPE_LOAD_EXPR_TUPLE;} 

   /** 
    * Checks if the node has a certain type. Should be overwritten by subclasses.
    * @return  true or false.
    */
   virtual bool IsType(TYPE t) const {return t == TYPE_LOAD_EXPR_TUPLE || AExpr::IsType(t); }

protected:
   /**
    * Prints the node as described in the ALF grammar.
    */
   virtual void OnPrint(std::ostream& o, int indent) const;
   
   virtual CGenericNode* OnExpand(CAlfTreeExpandingHelper* helper) const;
   
private:
   /**
    * Copy constructor, performs a deep copy of the incoming node.
    */
   CLoadExprTuple(const CLoadExprTuple&);

   /**
    * Assignment operator which is overloaded so no mistakes is made.
    * @return  A reference to this node.
    */
   CLoadExprTuple& operator=(const CLoadExprTuple&);

   /**
    * The address expression.
    */
   AExpr *addr_expr;
};

}

#endif

