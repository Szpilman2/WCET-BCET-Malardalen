// $Id $

#ifndef MACROS2_H
#define MACROS2_H

#include <cassert>

//// -------------------------------------------------------
//// Definition of types:
////   32-bit signed integer:   int32_t
////   32-bit unsigned integer: uint32_t
////   etc...
//// Many lower and upper range values will be represented as
//// 64bit integers, making sure that all integer values always
//// can fit in the limits of 64 bit integer intervals.
//// -------------------------------------------------------
//typedef signed char      int8_t;
//typedef signed short     int16_t;
//// typedef signed int      int32_t;
//typedef signed long long int64_t;
//
//typedef unsigned char      uint8_t;
//typedef unsigned short     uint16_t;
//// typedef unsigned int       uint32_t;
//typedef unsigned long long uint64_t;

// int types defined for C99. Not standard for C++ yet. Works however in GCC.
// if it fails, define the file cstdint with the above typedefs.

// when porting to c++0x change to #include <cstdint>
#include <stdint.h>

typedef long double float80_t;

typedef unsigned long ulong;
typedef long long llong;
typedef unsigned long long ullong;

// -------------------------------------------------------
// Definitions of min and max values for values and number
// of bits used.
// -------------------------------------------------------

// TODO: Consider using #include <climits> and use the standard limit names if the value ranges are supposed to reflect the current build-platform value ranges.
#define MIN_SIGNED_CHAR (-128)
#define MAX_SIGNED_CHAR (127)
#define MIN_SIGNED_SHORT (-32768)
#define MAX_SIGNED_SHORT (32767)
#define MIN_SIGNED_INT (-2147483647 - 1)
#define MAX_SIGNED_INT (2147483647)

#define MIN_UNSIGNED_CHAR (0)
#define MAX_UNSIGNED_CHAR (255)
#define MIN_UNSIGNED_SHORT (0)
#define MAX_UNSIGNED_SHORT (65535)
#define MIN_UNSIGNED_INT (0)
#define MAX_UNSIGNED_INT (4294967295U)

#define MIN_FLOAT (-3.4028223466E+38)
#define MAX_FLOAT (3.4028223466E+38)
#define MIN_DOUBLE (-1.7976931348623158E+308)
#define MAX_DOUBLE (1.7976931348623158E+308)

#define BITS_CHAR 8
#define BITS_SHORT 16
#define BITS_INT 32
#define BITS_FLOAT 32
#define BITS_POINTER 32
#define BITS_ADDRESS 32

#define BYTES_CHAR 1
#define BYTES_SHORT 2
#define BYTES_INT 4
#define BYTES_FLOAT 4
#define BYTES_POINTER 4
#define BYTES_ADDRESS 4

#define REG_SIZE_IN_BITS 32
#define SYMBOL_SIZE_IN_BITS 32
#define OFFSET_SIZE_IN_BITS 32

#define BITS_IN_BYTE 8

// -------------------------------------------------------
// Other useful macros
// -------------------------------------------------------
#ifndef FORALL
#define FORALL(i,L) for ((i) = (L).begin(); (i) != (L).end(); ++(i))
#endif

#ifndef PRINTLIST
#define PRINTLIST(the_class,the_list) { \
list<the_class> & print_list = the_list; \
list<the_class>::iterator the_iterator; \
 \
        if (print_list.size() > 0) { \
    std::cout << "Print the_list" << std::endl; \
    for (the_iterator = print_list.begin(); the_iterator != print_list.end(); ++the_iterator) \
      std::cout << *the_iterator << " " << std::endl; \
      } \
    } \
  }
#endif

// TODO: consider removing all uses of DYN_CAST. It is not a good way of handling bad casts.
#ifndef DYN_CAST
#define DYN_CAST(expr,new_expr,new_type,ref_or_star) try {        \
                new_expr = dynamic_cast<new_type ref_or_star> (expr);        \
                }        \
        catch (exception &bad_cast) {        \
                std::cerr << __FILE__ << ":" << __LINE__ << ":error in dynamic_cast" << std::endl; \
    exit(EXIT_FAILURE);         \
                } \
  assert(new_expr);
#endif

#endif // macros2_h
