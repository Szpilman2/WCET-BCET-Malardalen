#ifndef LAU_H_INCL
#define LAU_H_INCL

#include <cassert>
#include <cstring>

/** Functions for managing the current Least Addressable Unit (LAU) setting. */
namespace LAU
{
   /** Get the current LAU */
   unsigned long long LAU();

   /** Set the LAU */
   void SetLAU(unsigned long long lau);

   /** Convert @p bits, which represents a size in bits, to the same size given in
      the current LAU. @p IntType is the integer representation to use.
      @pre @p bits is a multiple of the LAU. */
   template <typename IntType>
   IntType BitsToLAU(const IntType & bits)
   {
      IntType lau = bits / static_cast<IntType>(LAU());
      assert(lau * static_cast<IntType>(LAU()) == bits);
      return lau;
   }

   /** Convert @p bits, which represents a size in bits, to the same size given in
      the current LAU, rounded up to the nearest integer. @p IntType is
      the integer representation to use. */
   template <typename IntType> IntType BitsToLAURoundUp(const IntType & bits)
   {
      return (bits + (static_cast<IntType>(LAU()) - IntType(1))) / static_cast<IntType>(LAU());
   }

   /** Convert @p bits, which represents a size in bits, to the same size given in
      the current LAU, rounded down to the nearest integer. @p IntType is
      the integer representation to use. */
   template <typename IntType>
   IntType BitsToLAURoundDown(const IntType & bits)
   {
      return bits / static_cast<IntType>(LAU());
   }

   /** Convert @p lau, which represents a size in the current LAU, to the same size
      given in bits. @p IntType is the integer representation to use. */
   template <typename IntType>
   IntType LAUToBits(const IntType & lau)
   {
      return lau * (IntType) LAU();
   }

}

#endif // ifndef LAU_H_INCL
