#ifndef FRAME_H_INCLUDED
#define FRAME_H_INCLUDED

#include "DataPatch.h"
#include "program_state/Size.h"
#include "program_state/LAU.h"
#include <memory>
#include <iostream>
#include <map>
#include <list>
#include <string>

class Value;

/** A list of data patches, used for representing frames. The list is sorted on increasing
   offset in the frame, which means the first patch is stored at offset 0. */
typedef std::list<DataPatch> PatchList;

class Frame
{
public:
   /** Create a new data frame of size @a size_in_bits. Note that when using big-endian, it's not valid
       to write infinite sized values to the frame. This is because with big-endian, the most significant
       bit is written to the lowest bit address, and infinite sized values have no most significant bit.
       This also makes it impossible to even create infinite sized frames when using big-endian, because
       when such a frame is created, an infinite sized initial value is written to it, which for the
       aforementioned reason doesn't work.
       @pre (big-endian is used) => size_in_bits != Size::Infinity() */
   Frame(const Size & size_in_bits, const std::string & annot = "");

   /** Create a new @c Frame from the set of patches @a data_patches. The @c SizeInBits() is
       automatically derived from the sum of the sizes of the @a data_patches.
       @note The returned pointer should be deleted by the caller */
   Frame(std::unique_ptr<PatchList> data_patches, const std::string & annot = "");

   /** Make a deep copy of @a other */
   Frame(const Frame & other)
   : _size_in_bits(other.SizeInBits()), _data_patches(other._data_patches), _annot(other._annot)
   {}

   Frame* Copy() const { return new Frame(*this); }

   bool IsEqual(const Frame * other) const { return *this == *other; }

   void SetAnnot(const std::string& annot) { _annot = annot; }

   Size SizeInBits() const {return _size_in_bits;}

   /** Return the frame size in LAU
       @pre The frame size in bits is a multiple of the current LAU */
   Size SizeInLAU() const {return LAU::BitsToLAU(SizeInBits());}

   /** Sets the part of the frame given by bit indices [start_bit, end_bit)
       as volatile, which means that it is set to an uninitialized value, and
       subsequent writes to it are ignored */
   void SetAsVolatile(unsigned long long start_bit, EIntULL end_bit);

   /** Copy the patches of of this frame into @a patch_list */
   void Patches(PatchList & patch_list) const;

   bool operator ==(const Frame & other) const;

   const std::string & GetAnnot() const {return _annot;}

   /** Returns whether all patches store top values.
      @remark Some patches may become top values if fused, but these are not
      detected by this function. */
   bool AllPatchesTop() const;

   /** Write the entire value 'value' to this data frame at offset 'offset_in_lau'.
      @pre The written value fits in the frame at the specified offset
      @note The value gets copied */
   void Write(const Value * value, unsigned long long offset_in_lau, bool ignore_volatile) {
      WriteSingle(value, LAU::LAUToBits(offset_in_lau), false, ignore_volatile);
   }

   /** Write the entire value 'value' to this data frame at bit offset 'offset_in_bits'
      @pre The written value fits in the frame at the specified offset
      @note The value gets copied */
   void WriteToBitOffset(const Value * value, unsigned long long offset_in_bits, bool ignore_volatile) {
      WriteSingle(value, offset_in_bits, false, ignore_volatile);
   }

   /** For each offset (in LAU), compute the LUB of the value stored at that offset and 'value', and store the
      result at the same offset
      @pre value->SizeInBits() <= (*frame)->SizeInBits() */
   void WriteAndLUBWithAll(const Value * value, bool ignore_volatile);

   /** Read a value of size 'nr_of_bits' from offset 'offset_in_lau'
      @pre The read does not protrude outside the frame
      @note The returned value is owned by the caller */
   Value * Read(Size nr_of_bits, unsigned long long offset_in_lau = 0) const;

   /** Read values from all offsets (in LAU) of this frame, and LUB the read values together
      @pre nr_of_bits <= (*frame)->SizeInBits() */
   Value* ReadAllLUBed(Size nr_of_bits) const;

   /** @pre end_bit <= (*frame)->SizeInBits() */
   Value * ReadRange(unsigned long long start_bit, EIntULL end_bit) const;

   Frame * LUB(const Frame * other) const;

   /** @returns A pointer to the result, or 0 if the result is bottom */
   Frame * GLB(const Frame * other) const;

   Frame* Widening(const Frame* other) const;

   /** @returns A pointer to the result, or 0 if the result is bottom */
   Frame* Narrowing(const Frame* other) const;

   /** Prints this data element to the stream @a o in text format */
   std::ostream & Print(std::ostream & o = std::cout) const;

private:
   /** Maps frame bit offsets to data patches */
   typedef std::map<unsigned long long, DataPatch> PatchStore;

   /** An extended data patch. Holds information about a data patch, plus which
       bit offset it has in the frame. */
   typedef std::pair<PatchStore::key_type, PatchStore::mapped_type> ExtDataPatch;

   /** The total size in bits of this frame */
   Size _size_in_bits;

   /** The data patches of this frame */
   PatchStore _data_patches;

   /** Adds the possibility to annotate a frame with an arbitrary string */
   std::string _annot;

   /** Writes 'value' to the frame at 'offset_in_bits'. 'vola' determines
       whether the written part should become volatile; volatile values are
       not overwritten, except if 'ignore_volatile' is true.
       @note The object pointed to by 'value' is copied */
   void WriteSingle(const Value *value, unsigned long long offset_in_bits,
                    bool vola, bool ignore_volatile);

   /** Writes over the volatile patch p with @a written
      @returns True if no more patches need to be traversed, false otherwise
      @see WriteSingle() */
   bool WriteOverVolatilePatch(PatchStore::iterator& p, ExtDataPatch& written, bool ignore_volatile);

   /** Writes over the non-volatile patch p with @a written
      @returns True if no more patches need to be traversed, false otherwise
      @see WriteSingle() */
   bool WriteOverNonVolatilePatch(PatchStore::iterator& p, ExtDataPatch& written);

   /** Read the range of bits [start_bit, end_bit), i.e., not including the end_bit */
   void ReadRangeOfPatches(unsigned long long start_bit, EIntULL end_bit,
                           PatchList & patches) const;

   /** Clip @a clipped_patch against @a patch_clipped_against. This means that @a clipped_patch
      is split into 0, 1, or 2 smaller patches, depending on whether its extents are fully
      included in @a patch_clipped_against, it protrudes outside @a patch_clipped_against on one side,
      or it protrudes outside @a patch_clipped_against on both sides, respectively.
      @return A pair of booleans giving whether a left and/or a right subpatch resulted in the clipping.
              This is used to determine if @a left_result and @a right_result hold any meaningful values
              after the call. */
   static std::pair<bool, bool> ClipPatchAgainstPatch(ExtDataPatch& clipped_patch,
                                                      const ExtDataPatch& patch_clipped_against,
                                                      ExtDataPatch& left_result, 
                                                      ExtDataPatch& right_result);

   template <typename BinOp> Frame* PerformBinary(const Frame* other, const BinOp& op) const;
};

inline std::ostream & operator <<(std::ostream & os, const Frame & data) {return data.Print(os);}

#endif   // FRAME_H_INCLUDED
