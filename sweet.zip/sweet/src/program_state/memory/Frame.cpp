#include "Frame.h"
#include "DataPatch.h"
#include "program_state/value/Value.h"
#include "program_state/value/ReadValue.h"
#include "program_state/value/ValueDomain.h"
#include "program_state/Endianness.h"
#include "program_state/LAU.h"
#include "program_state/Size.h"
#include "tools/integer_utilities.h"
#include "tools/IndentingOStream.h"
#include "tools/RangeIterator.h"
#include "tools/TextTable.h"
#include "globals.h"
#include "macros.h"
#include <ciso646>
#include <stdexcept>
#include <algorithm>
#include <sstream>
#include <functional>
#include <cmath>

using namespace std;

Frame::Frame(const Size & size_in_bits, const string & annot) 
: _size_in_bits(size_in_bits), _annot(annot)
{
   assert(size_in_bits > 0 || "Cannot create a frame of size 0" == NULL);
   assert(g_endianness == Endianness::Big()? size_in_bits < Size::Infinity() : true ||
          "Cannot create infinite sized frames when using big-endian" == 0);
   DataPatch initial_dp( domain->CreateUninitializedValue(size_in_bits) );
   _data_patches[0] = move(initial_dp);
}

Frame::Frame(std::unique_ptr<PatchList> data_patches, const string & annot)
: _annot(annot)
{
   RangeIterator<PatchList> p(*data_patches);
   // insert first patch
   unsigned long long offset = 0;
   Size size_in_bits = p->SizeInBits();
   PatchStore::iterator prev = _data_patches.insert(make_pair(offset, move(*p))).first;
   // insert remaining patches
   for (++p; p; ++p)
   {
      offset = size_in_bits.AsBaseIntType();
      size_in_bits += p->SizeInBits();
      // if prev can't "devour" the patch p, insert p as a new patch
      if (!prev->second.TryToMergeWithoutLoss(*p))
         prev = _data_patches.insert(prev, make_pair(offset, move(*p)));
   }
   _size_in_bits = size_in_bits;
   assert(g_endianness == Endianness::Big()? size_in_bits < Size::Infinity() : true ||
          "Cannot create infinite sized frames when using big-endian" == 0);
}

void Frame::SetAsVolatile(unsigned long long start_bit, EIntULL end_bit)
{
   unique_ptr<Value> uninitialized(domain->CreateUninitializedValue(end_bit - start_bit));
   WriteSingle(uninitialized.get(), start_bit, true, false);
}

void Frame::Patches(PatchList & patch_list) const
{
   for (PatchStore::const_iterator p = _data_patches.begin(), pn = _data_patches.end(); p != pn; ++p)
      patch_list.push_back( p->second );
}

bool Frame::operator ==(const Frame & other) const
{
   // If both have the same address they must be equal
   if (this == &other)
      return true;

   // Make sure that the two frames are of the same size
   if (SizeInBits() != other.SizeInBits())
      return false;

   if (this->GetAnnot() != other.GetAnnot())
      return false;

   // Make sure that the two frame are subdivided into an equal number of patches
   if (this->_data_patches.size() != other._data_patches.size())
      return false;

   // Loop through all the patches and check if they are all equal. If two patches are not equal,
   // the two frames are considered to not be equal.
   return equal(this->_data_patches.begin(), this->_data_patches.end(), other._data_patches.begin());
}

bool Frame::AllPatchesTop() const
{
   // TODO: if this function returns true, wouldn't there always be only one patch?
   for (PatchStore::const_iterator p = _data_patches.begin(), pn = _data_patches.end(); p != pn; ++p)
      if (!(p->second.value->IsTop())) 
         return false;
   return true;
}

void Frame::WriteAndLUBWithAll(const Value * value, bool ignore_volatile)
{
   assert(!value->IsBottom());

   const Size framesize = SizeInBits(), valsize = value->SizeInBits();

   if (valsize > framesize) {
      ostringstream msg_str;
      msg_str << "Trying to write outside frame \"" << GetAnnot() << "\". "
         "The frame is " << framesize << " bits, while the value being written is " <<
         valsize << " bits.";
      throw runtime_error(msg_str.str());
   }

   // If the value to be stored is top or the frame is of infinite size, create
   // a top value of the same size as the frame and store it at offset zero
   if (value->IsTop() || framesize.IsInfinity()) {
      unique_ptr<Value> lub_value(domain->CreateTopValue(framesize));
      Write(lub_value.get(), 0, ignore_volatile);
      return;
   }   

   // Else, loop through all possible offsets and write and LUB the values 
   for (unsigned o = 0; LAU::LAUToBits(o) + valsize <= framesize; ++o) {
      // Read a value of the argument value's size from the frame,
      // LUB the read value and the argument and store back into the frame
      unique_ptr<Value> read( Read(valsize, o) );
      unique_ptr<Value> lub( read->LUB(value) );
      Write(lub.get(), o, ignore_volatile);
   }
}

Value * Frame::Read(Size nr_of_bits, unsigned long long offset_in_lau) const
{
   return ReadRange(LAU::LAUToBits(offset_in_lau), LAU::LAUToBits(offset_in_lau) + nr_of_bits);
}

Value* Frame::ReadAllLUBed(Size nr_of_bits) const
{
   Size framesize = this->SizeInBits();
   if (nr_of_bits > framesize) {
      ostringstream msg_str;
      msg_str << "Trying to read outside frame \"" << GetAnnot() << "\". "
         "The frame is " << framesize << " bits, while " << nr_of_bits << " bits are "
         "being read.";
      throw runtime_error(msg_str.str());
   }
   unique_ptr<Value> result(domain->CreateBottomValue(nr_of_bits));
   for (unsigned long long o = 0; LAU::LAUToBits(o) + nr_of_bits <= framesize; ++o)
   {
      result.reset(result->LUB(Read(nr_of_bits, o)));
      if (result->IsTop())
         break;
   }
   return result.release();
}

Value * Frame::ReadRange(unsigned long long start_bit, EIntULL end_bit) const
{
   unique_ptr<PatchList> patches(new PatchList);
   ReadRangeOfPatches(start_bit, end_bit, *patches.get());
   if (patches->size() > 1 ||
       patches->front().SizeInBits() != patches->front().value->SizeInBits())
   {
      Frame * data_frame = new Frame(move(patches));
      return ReadValue::Create(data_frame);
   } else {
      Value *value = patches->front().value;
      patches->front().value = nullptr;
      return value;
   }
}

Frame * Frame::LUB(const Frame * other) const
{
   assert(this->SizeInBits() == other->SizeInBits());

   // Test some straightforward cases first
   if (this == other)
      return Copy();
   if(AllPatchesTop())
      return Copy();
   if(other->AllPatchesTop())
      return other->Copy();

   // Compute a LUB:ed frame
   Frame* lub_frame = PerformBinary(other, mem_fn(&Value::LUB));

   if (this->GetAnnot() == other->GetAnnot())
      lub_frame->SetAnnot(GetAnnot());
   else if (!this->GetAnnot().empty() && !other->GetAnnot().empty())
      lub_frame->SetAnnot(string("\"") + this->GetAnnot() + "\" LUB \"" + other->GetAnnot() + "\"");
   return lub_frame;
}

Frame * Frame::GLB(const Frame * other) const
{
   assert(this->SizeInBits() == other->SizeInBits());

   // Test some straightforward cases first
   if (this == other)
      return Copy();
   if(AllPatchesTop())
      return other->Copy();
   if(other->AllPatchesTop())
      return Copy();

   Frame* glb_frame = PerformBinary(other, mem_fn(&Value::GLB));
   if (!glb_frame) // check for bottom
      return 0;
   
   if (this->GetAnnot() == other->GetAnnot())
      glb_frame->SetAnnot(GetAnnot());
   else if (!this->GetAnnot().empty() && !other->GetAnnot().empty())
      glb_frame->SetAnnot(string("\"") + this->GetAnnot() + "\" GLB \"" + other->GetAnnot() + "\"");
   return glb_frame;
}

Frame* Frame::Widening(const Frame* other) const
{
   return PerformBinary(other, mem_fn(&Value::Widening));
}

Frame* Frame::Narrowing(const Frame* other) const
{
   return PerformBinary(other, mem_fn(&Value::Narrowing));
}

ostream &
Frame::
Print(ostream & o) const
{
   if (_data_patches.size() == 1) {
      const DataPatch& patch = _data_patches.begin()->second;
      if (patch.bit_range0 == 0 && patch.bit_range1 == patch.value->SizeInBits())
         o << *patch.value;
      else
         o << "bits [" << patch.bit_range0 << ".." << patch.bit_range1
           << ") of " << *patch.value;
      if (patch.vola)
         o << " (volatile)";
      o << " (" << patch.SizeInBits() << " bits)";
      return o;
   } else {
      TextTable table;
      PatchStore::const_iterator last = --_data_patches.end();
      streamsize wd = (streamsize)log10(double(last->first)) + 1;
      for (PatchStore::const_iterator pi = _data_patches.begin(),
           pn = _data_patches.end(); pi != pn; ++pi)
      {
         const DataPatch& patch = pi->second;
         table << '[';
         streamsize prev = table.GetStream().width(wd); table << pi->first; table.GetStream().width(prev);
         table << ']';
         table.NextColumn();
         if (patch.bit_range0 == 0 && patch.bit_range1 == patch.value->SizeInBits())
            table << *patch.value;
         else
            table << "bits [" << patch.bit_range0 << ".." << patch.bit_range1
              << ") of " << *patch.value;
         if (patch.vola)
            table << " (volatile)";
         table.NextColumn();
         table << '(' << patch.SizeInBits() << " bits)";
         table.NextRow();
      }
      return o << table;
   }
}

// Private members starts here - - - - - - - - - - - - - - - - - - - - - -

void Frame::WriteSingle(const Value *value, unsigned long long offset_in_bits,
                        bool vola, bool ignore_volatile)
{
   Size valsize = value->SizeInBits();
   // Make sure the write doesn't extend outside the frame
   if (offset_in_bits + valsize > SizeInBits()) {
      ostringstream msg_str;
      msg_str << "Trying to write outside frame \"" << GetAnnot() << "\". "
         "The frame is " << SizeInBits() << " bits, while the bit range written to is [" 
         << offset_in_bits << ".." << offset_in_bits + valsize << ").";
      throw runtime_error(msg_str.str());
   }

   // build a list of patches to be written to the frame
   vector<ExtDataPatch> written;
   if (!value->AsReadValue())
      // common case: only a single patch should be written
      written.push_back( ExtDataPatch(offset_in_bits, DataPatch(value->Copy(), vola)) );
   else {
      // to avoid ending up with a hierarchical patch list, we extract the patches contained
      // in ReadValue objects and add them directly to the list
      const Frame *f = ((const ReadValue*)value)->Data();
      written.reserve(f->_data_patches.size());
      Size offs = offset_in_bits;
      for (RangeIterator<const PatchStore> p(f->_data_patches); p; ++p) {
         written.push_back( ExtDataPatch(offs.AsBaseIntType(), p->second) );
         written.back().second.vola = vola;
         offs += p->second.SizeInBits();
      }
   }

   // write each of the patches in 'written' to the frame
   for (RangeIterator<vector<ExtDataPatch> > w(written); w; ++w) {
      // Iterate through all patches overlapping the written patch and adjust (or remove) them
      PatchStore::iterator p = --_data_patches.upper_bound(w->first);
      for (bool done = false; !done; )
      {
         // Check if the end of the overlap has been reached
         if (p == _data_patches.end())
         {
            if (!_data_patches.empty())  _data_patches.insert(--PatchStore::iterator(p), move(*w)); // insert with hint
            else  _data_patches.insert(move(*w));
            done = true;
         }
         // Process the current patch (p is updated inside the WriteOver* functions)
         else if (p->second.IsVolatile())
            done |= WriteOverVolatilePatch(p, *w, ignore_volatile);
         else
            done |= WriteOverNonVolatilePatch(p, *w);
      }
   }

   // Now run through all updated patches in the patch list, including the one lying directly before
   // the first updated patch, and try to merge adjacent patches without losing precision. This is done
   // to make a more compact representation of several adjacent patches that hold the same information.
   PatchStore::iterator p = --_data_patches.upper_bound(offset_in_bits);
   if (p != _data_patches.begin())
      --p;

   // Iterate over the updated range of bits
   while (p->first < offset_in_bits + valsize && p != --_data_patches.end())
   {
      // p1 is the next patch in the list. Try to merge it with p.
      PatchStore::iterator p1 = p; ++p1;
      if (p->second.TryToMergeWithoutLoss(p1->second))
         _data_patches.erase(p1);
      else
         ++p;
   }
}

bool Frame::WriteOverVolatilePatch(PatchStore::iterator& p, ExtDataPatch& written, bool ignore_volatile)
{
   if (!ignore_volatile)
   {
      ExtDataPatch current(p->first, DataPatch(nullptr, p->second.bit_range0, p->second.bit_range1, p->second.vola)); // same as *p but with a nullptr

      PatchStore::iterator hint = p; // hint for insertions
      if (hint != _data_patches.begin())  --hint;
      ++p;

      // Clip the written patch against the current patch
      ExtDataPatch left, right;
      pair<bool, bool> clip_results = ClipPatchAgainstPatch(written, current, left, right);

      // If a left part resulted, insert it
      if (clip_results.first)
         _data_patches.insert(hint, move(left));

      // If a right part resulted, set it as a new written patch
      if (clip_results.second)
      {
         written = move(right);
         return false;
      }
      else
         return true;
   }
   else  // ignore_volatile == true
   {
      ExtDataPatch current = move(*p);
      _data_patches.erase(p++);
      PatchStore::iterator hint = p; // hint for insertions
      if (hint != _data_patches.begin() && !_data_patches.empty())
         --hint;

      // Create a patch for the overlapping part. It should store the data of the
      // written patch but be marked volatile.
      unsigned long long rel_overlap_start = (written.first < current.first)? current.first - written.first : 0;
      EIntULL rel_overlap_end = min(current.first + current.second.SizeInBits() - written.first, written.second.SizeInBits());
      pair<EIntULL, EIntULL> range = g_endianness.Select<EIntULL>(rel_overlap_start, rel_overlap_end,
                                                                  written.second.bit_range0,
                                                                  written.second.bit_range1);
      ExtDataPatch overlap(written.first + rel_overlap_start,
         DataPatch(written.second.value->Copy(), range.first.AsBaseIntType(), range.second, true));

      // Clip the written patch against the current patch
      ExtDataPatch old_written(written.first, DataPatch(nullptr, written.second.bit_range0, written.second.bit_range1, written.second.vola)); // same as written but with a nullptr
      ExtDataPatch writ_left, writ_right;
      pair<bool, bool> clipres_writ = ClipPatchAgainstPatch(written, current, writ_left, writ_right);

      // Clip the current patch against the written patch
      ExtDataPatch curr_left, curr_right;
      pair<bool, bool> clipres_curr = ClipPatchAgainstPatch(current, old_written, curr_left, curr_right);

      // If a left part resulted when clipping the written patch, insert it
      if (clipres_writ.first)
      {
         assert(!clipres_curr.first);
         hint = _data_patches.insert(hint, move(writ_left));
      }
      // If a left part resulted when clipping the current patch, insert it
      else if (clipres_curr.first)
      {
         assert(!clipres_writ.first);
         hint = _data_patches.insert(hint, move(curr_left));
      }

      hint = _data_patches.insert(hint, move(overlap));

      // If a right part resulted when clipping the written patch,
      // set it as a new written patch
      if (clipres_writ.second)
      {
         assert(!clipres_curr.second);
         written = move(writ_right);
         return false;
      }
      else
      {
         // If a right part resulted when clipping the current patch, insert it
         if (clipres_curr.second)
            _data_patches.insert(hint, move(curr_right));
         return true;
      }
   }
}

bool Frame::WriteOverNonVolatilePatch(PatchStore::iterator& p, ExtDataPatch& written)
{
   ExtDataPatch current = move(*p);
   _data_patches.erase(p++);
   PatchStore::iterator hint = p; // hint for insertions
   if (hint != _data_patches.begin() && !_data_patches.empty())
      --hint;

   // Clip the current patch against the written patch
   ExtDataPatch left, right;
   pair<bool, bool> clip_results = ClipPatchAgainstPatch(current, written, left, right);

   // If a left part resulted, insert it
   if (clip_results.first)
      hint = _data_patches.insert(hint, move(left));

   // If a right part resulted, insert the written patch before
   // it and set finished = true
   if (clip_results.second)
   {
      hint = _data_patches.insert(hint, move(written));
      _data_patches.insert(hint, move(right));
      return true;
   }

   return false;
}

void Frame::ReadRangeOfPatches(unsigned long long start_bit, EIntULL end_bit, PatchList & patches) const
{
   Size framesize = this->SizeInBits();
   if (end_bit > framesize) {
      ostringstream msg_str;
      msg_str << "Trying to read outside frame \"" << GetAnnot() << "\". "
         "The frame is " << framesize << " bits, while the bit range being read is [" 
         << start_bit << ".." << end_bit << ").";
      throw runtime_error(msg_str.str());
   }

   // Run through all patches overlapping the range [start_bit..end_bit)
   for (PatchStore::const_iterator p = --_data_patches.upper_bound(start_bit), pn = _data_patches.end(); 
      p != pn && p->first < end_bit; ++p)
   {
      DataPatch copied_patch;
      copied_patch.value = p->second.value->Copy();
      EIntULL l = max<EIntLL>(0, (EIntLL) start_bit - (EIntLL) p->first);
      EIntULL u = min<EIntLL>(p->second.SizeInBits(), (EIntLL) end_bit - (EIntLL) p->first);
      pair<EIntULL, EIntULL> bit_range = g_endianness.Select(l, u, EIntULL(p->second.bit_range0), p->second.bit_range1);
      copied_patch.bit_range0 = bit_range.first.AsBaseIntType();
      copied_patch.bit_range1 = bit_range.second;
      copied_patch.vola = false;
      patches.push_back(move(copied_patch));
   }
}

std::pair<bool, bool> Frame::
ClipPatchAgainstPatch(ExtDataPatch& clipped_patch,
                      const ExtDataPatch& patch_clipped_against,
                      ExtDataPatch& left_result, 
                      ExtDataPatch& right_result)
{
   // Compute the "global" bit ranges of the two patches, that is, their bit ranges
   // with their bit offsets in the frame added
   unsigned long long clipped_r0, cl_against_r0;
   EIntULL clipped_r1, cl_against_r1;
   clipped_r0 = clipped_patch.first;
   clipped_r1 = clipped_r0 + clipped_patch.second.SizeInBits();
   cl_against_r0 = patch_clipped_against.first;
   cl_against_r1 = cl_against_r0 + patch_clipped_against.second.SizeInBits();

   // Move the value in the clipped patch to a separate variable
   unique_ptr<Value> value(clipped_patch.second.value);
   clipped_patch.second.value = nullptr;

   pair<bool, bool> result(false, false);

   // Check if the clipped patch extends outside the clipped-against patch
   // on the left side
   if (clipped_r0 < cl_against_r0)
   {
      result.first = true;
      unsigned long long overhang = cl_against_r0 - clipped_r0;
      pair<EIntULL, EIntULL> oh_br = g_endianness.Select<EIntULL>
         (0, overhang, clipped_patch.second.bit_range0, 
          clipped_patch.second.bit_range1);
      left_result.second.value = value.release();
      left_result.second.bit_range0 = oh_br.first.AsBaseIntType();
      left_result.second.bit_range1 = oh_br.second;
      left_result.second.vola = clipped_patch.second.vola;
      left_result.first = clipped_patch.first;
   }

   // Check if the clipped patch extends outside the clipped-against patch
   // on the right side
   if (cl_against_r1 < clipped_r1)
   {
      result.second = true;
      unsigned long long overhang_start = cl_against_r1.AsBaseIntType() - clipped_r0;
      pair<EIntULL, EIntULL> oh_br = g_endianness.Select<EIntULL>
         (overhang_start, clipped_patch.second.SizeInBits(),
          clipped_patch.second.bit_range0, clipped_patch.second.bit_range1);
      if (result.first)
         right_result.second.value = left_result.second.value->Copy();
      else
         right_result.second.value = value.release();
      right_result.second.bit_range0 = oh_br.first.AsBaseIntType();
      right_result.second.bit_range1 = oh_br.second;
      right_result.second.vola = clipped_patch.second.vola;
      right_result.first = cl_against_r1.AsBaseIntType();
   }
   return result;
}

template <typename BinOp> Frame* Frame::PerformBinary(const Frame* other, const BinOp& op) const
{
   // Run through the patch lists of the two frames and perform the operation on the patches pairwise.
   // If two patches do not match in size, the larger of the two is split into two
   // smaller patches and processed over two iterations. The bit ranges for the next iteration are
   // saved on a "stack" (which is never larger than 1).
   DataPatch patch0, patch1;
   pair<unsigned long long,Size> stack0(0,0), stack1(0,0); // pair::second == 0 means empty stack
   unique_ptr<PatchList> new_patch_list(new PatchList);
   PatchList patches0, patches1;
   this->Patches(patches0);  other->Patches(patches1);
   for (auto p0 = patches0.begin(), p1 = patches1.begin(); 
        (p0 != patches0.end() || stack0.second != 0) &&
        (p1 != patches1.end() || stack1.second != 0); )
   {
      // Get the two patches (patch0 and patch1) that should be processed in this iteration
      // Check the patch0 stack
      if (stack0.second != 0) {
         // Use the same patch0 but with the saved bit ranges
         patch0.bit_range0 = stack0.first;
         patch0.bit_range1 = stack0.second;
         stack0.second = 0; // "pop" from the stack
      } else {
         // Empty stack - get the next patch in the list
         patch0 = move(*p0);
         ++p0;
      }
      // Check the patch1 stack
      if (stack1.second != 0) {
         // Use the same patch1 but with the saved bit ranges
         patch1.bit_range0 = stack1.first;
         patch1.bit_range1 = stack1.second;
         stack1.second = 0; // "pop" from the stack
      } else {
         // Empty stack - get the next patch in the list
         patch1 = move(*p1);
         ++p1;
      }

      // If the two patches differ in sizes, the larger of the two must be split into
      // two smaller patches
      if (patch0.SizeInBits() > patch1.SizeInBits()) {
         Size br0, br1;

         // "Push" the bit ranges to be used for patch0 in the next iteration
         br0 = patch0.bit_range0;
         br1 = patch0.bit_range1;
         g_endianness.Select2(patch1.SizeInBits(), patch0.SizeInBits(), br0, br1);
         stack0 = make_pair(br0.AsBaseIntType(), br1);

         // Adjust the bit ranges to be used for patch0 in this iteration
         br0 = patch0.bit_range0;
         br1 = patch0.bit_range1;
         g_endianness.Select2(Size(0), patch1.SizeInBits(), br0, br1);
         patch0.bit_range0 = br0.AsBaseIntType();
         patch0.bit_range1 = br1;
      } else if (patch1.SizeInBits() > patch0.SizeInBits()) {
         Size br0, br1;

         // "Push" the bit ranges to be used for patch1 in the next iteration
         br0 = patch1.bit_range0;
         br1 = patch1.bit_range1;
         g_endianness.Select2(patch0.SizeInBits(), patch1.SizeInBits(), br0, br1);
         stack1 = make_pair(br0.AsBaseIntType(), br1);

         // Adjust the bit ranges to be used for patch1 in this iteration
         br0 = patch1.bit_range0;
         br1 = patch1.bit_range1;
         g_endianness.Select2(Size(0), patch0.SizeInBits(), br0, br1);
         patch1.bit_range0 = br0.AsBaseIntType();
         patch1.bit_range1 = br1;
      }

      // Now perform the operation

      // Cut out the referenced bits from the two patch values, perform the operation on the resulting values,
      // and then create a new patch representing that value
      unique_ptr<Value> a( patch0.GetClippedValue() );
      unique_ptr<Value> b( patch1.GetClippedValue() );
      unique_ptr<Value> result(op(a.get(), b.get()));
      if (result->IsBottom())
         return 0;
      else
      {
         // Create a patch with range [0..patch0.SizeInBits()] (note
         // that patch1-SizeInBits() == patch0.SizeInBits())
         new_patch_list->push_back(DataPatch(result.release(), 0, patch0.SizeInBits()));
      }
   }

   return new Frame(move(new_patch_list), GetAnnot());
}
