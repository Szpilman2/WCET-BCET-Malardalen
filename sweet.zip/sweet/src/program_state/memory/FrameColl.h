#ifndef FRAMECOLL_H_INCLUDED
#define FRAMECOLL_H_INCLUDED

#include "Frame.h"
#include "program_state/Size.h"
#include "program_state/value/SymbolOffsetPair.h"
#include "tools/cheap_copy.h"
#include <vector>
#include <memory>
#include <queue>
#include <functional>
#include <limits>

class Value;

class FrameColl : private std::vector<cheap_copy<Frame>>
{
   typedef std::vector<cheap_copy<Frame>> Base;

public:
   typedef unsigned FrameId;

   typedef Base::const_iterator const_iterator;

   static void SetReuse(bool on) { reuse = on; }

   FrameColl() {}

   FrameColl(const FrameColl & other);

   FrameColl* Copy() const { return new FrameColl(*this); }

   bool IsEqual(const FrameColl * other) const {
      return *this == *other;
   }

   Size SizeInBits() const;

   Size SizeInBits(unsigned frame_id) const;

   unsigned NrOfFrames() const {return (unsigned)size();}

   const_iterator begin() const { return Base::begin(); }

   const_iterator end() const { return Base::end(); }

   bool operator ==(const FrameColl & other) const;

   FrameId AllocFrame(const Size & size_in_bits, const std::string & annot = "");

   /** Deallocate the frame in @a fc given by @a frame_id. If it is already deallocated, 
      nothing happens. */
   void DeallocFrame(unsigned frame_id);

   void SetAsVolatile(SopIterator & sops, const Size & nr_of_bits);

   bool HasFrame(unsigned frame_id) const { return frame_id < size() && at(frame_id); }

   /** Returns the frame identified by @a frame_id, or 0 if no such frame exist */
   cheap_copy<Frame> GetFrame(FrameId frame_id) const {return HasFrame(frame_id)? at(frame_id) : cheap_copy<Frame>();}

   const std::string & GetFrameAnnot(FrameId frame_id) const;

   /** @note Returns bottom if 'frame_id' does not refer to an existing frame, or
      'offset_in_lau' and/or 'nr_of_bits' point outside the frame */ 
   Value * Read(unsigned frame_id, unsigned long long offset_in_lau, const Size & nr_of_bits) const;

   /** @post 'unsuccessful' indicates whether at least one concrete read was unsuccessful
      @note Returns bottom if no concrete reads were successful */
   Value * ReadLUBed(SopIterator& sops, const Size & nr_of_bits, bool & unsuccessful) const;

   /** @note Returns bottom if there are no frames allocated or all frames are smaller
      than 'nr_of_bits', in which case no valid reads are possible */
   Value * ReadAllLUBed(const Size& nr_of_bits) const;

   void Write(unsigned frame_id, unsigned long long offset_in_lau,
              const Value * value, bool ignore_volatile, bool & successful);

   /** @post 'successful' indicates whether at least one concrete write was successful
      @post 'unsuccessful' indicates whether at least one concrete write was unsuccessful */
   void WriteAndLUB(const Value * value, SopIterator & sops, bool ignore_volatile,
                    bool & successful, bool & unsuccessful);

   /** For all frames in the collection 'fc', store at each offset (in LAU) the LUB of 'value' and the value already
       stored at that offset
       @post 'successful' indicates whether at least one concrete write was successful */
   void WriteAndLUBWithAll(const Value * value, bool ignore_volatile, bool & successful);

   FrameColl * LUB(const FrameColl * other) const;

   /** @returns A pointer to the result, or 0 if the result is bottom */
   FrameColl * GLB(const FrameColl * other) const;

   FrameColl* Widening(const FrameColl* other) const;

   /** @returns A pointer to the result, or 0 if the result is bottom */
   FrameColl* Narrowing(const FrameColl* other) const;

   std::ostream & Print(std::ostream & os) const;

private:
   typedef std::priority_queue<size_type, std::vector<size_type>, std::greater<size_type> > FreeSlotsQueue;

   static bool reuse;

   FreeSlotsQueue free_slots;

   template <typename Op> FrameColl* PerformBinary(const Op& op, const FrameColl* other) const;
};

inline std::ostream & operator <<(std::ostream & os, const FrameColl & fc) {return fc.Print(os);}

#endif   // FRAMECOLL_H_INCLUDED
