#include "DataPatch.h"
#include "program_state/value/Value.h"
#include "program_state/value/BottomValue.h"
#include "program_state/value/Bitstring.h"
#include "program_state/value/ValueDomain.h"
#include "program_state/Endianness.h"
#include "globals.h"
#include <memory>

DataPatch::DataPatch(Value *value, const unsigned long long & br_low,
                     const EIntULL & br_high, bool vola)
: value(value), bit_range0(br_low), bit_range1(br_high), vola(vola)
{}

DataPatch::DataPatch(Value *value, bool vola)
: value(value), bit_range0(0), bit_range1(value->SizeInBits()), vola(vola)
{}

DataPatch::~DataPatch() { delete value; }

DataPatch &DataPatch::operator =(const DataPatch &other) {
   delete value;
   value = other.value->Copy();
   bit_range0 = other.bit_range0;
   bit_range1 = other.bit_range1;
   vola = other.vola;
   return *this;
}

DataPatch &DataPatch::operator =(DataPatch &&other) {
   delete value;
   value = other.value;
   other.value = nullptr;
   bit_range0 = other.bit_range0;
   bit_range1 = other.bit_range1;
   vola = other.vola;
   return *this;
}

bool DataPatch::operator ==(const DataPatch & other) const
{
   return this->bit_range0 == other.bit_range0 &&
          this->bit_range1 == other.bit_range1 &&
          this->vola == other.vola && 
          this->value->IsEqual(other.value);
}

Value *DataPatch::GetClippedValue() const
{
   struct : ValueVisitor
   {
      const DataPatch* this_patch;
      std::unique_ptr<Value> clipped;

      virtual void VisitValue(const Value& value)
      {
         // if the entire value is represented, just return a copy
         if (this_patch->bit_range0 == 0 && this_patch->bit_range1 == value.SizeInBits())
            clipped.reset( value.Copy() );
         // otherwise, we don't know how to handle it
         else clipped.reset( domain->CreateTopValue(this_patch->bit_range1 - this_patch->bit_range0) );
      }

      virtual void VisitBottomValue(const BottomValue& value)
      {
         // for bottom values, we rely on the select operation
         clipped.reset( value.Select(this_patch->bit_range0, this_patch->bit_range1 - 1) );
      }

      virtual void VisitBitstring(const Bitstring& value)
      {
         // for bitstring values, we rely on the select operation
         clipped.reset( value.Select(this_patch->bit_range0, this_patch->bit_range1 - 1) );
      }
   } clipper;
   clipper.this_patch = this;
   value->AcceptVisitor(&clipper);
   return clipper.clipped.release();
}

bool DataPatch::TryToMergeWithoutLoss(const DataPatch& other)
{
   if (vola != other.vola)
      return false;

   // Patches that represent adjacent parts of the same concrete value can be merged trivially (and safely)
   // without losing precision.  For concrete integer values, the same holds even if the bit ranges don't
   // match, but this is not the case for, e.g., symbolic pointers.  Also, it is typically preferable for,
   // e.g., debugging purposes to not do excessive merging.
   if (value->IsSingleElem() && other.value->IsSingleElem() && value->SizeInBits() == other.value->SizeInBits()) {
      if (g_endianness == Endianness::Little()) {
         // with little endian, the patch at the lower offset must represent a *less* significant part of the value
         if (bit_range1 == other.bit_range0 && value->IsSetEqual(other.value)) {
            bit_range1 = other.bit_range1;
            return true;
         }
      } else {
         // with big endian, the patch at the lower offset must represent a *more* significant part of the value
         if (bit_range0 == other.bit_range1 && value->IsSetEqual(other.value)) {
            bit_range0 = other.bit_range0;
            return true;
         }
      }
   }

   // top values can always be merged without losing precision
   if (value->IsTop() && other.value->IsTop()) {
      delete value;
      value = domain->CreateTopValue(SizeInBits() + other.SizeInBits());
      this->bit_range0 = 0;
      this->bit_range1 = value->SizeInBits();
      return true;
   }

   return false;
}
