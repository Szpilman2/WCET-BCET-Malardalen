#ifndef MEMORY_H_INCLUDED
#define MEMORY_H_INCLUDED

#include <memory>
#include <cassert>
#include <iostream>
#include <stdint.h>

class Memory;
class Value;
class FrameColl;
template <typename T> class EInt;
typedef EInt<unsigned long long> Size;

class Memory
{
public:
   virtual ~Memory() {};
  
   /** Make a deep copy of this memory
       @note The caller is responsible for deleting the returned pointer */
   virtual Memory* Copy() const = 0;

   virtual bool IsEqual(const Memory * other) const = 0;

   /** Does @p addr point to a single location in this memory (i.e.\ a read 
      does not return a LUB of values from several locations)? The value
      stored in that location may be an abstract one, or the location
      might not even exist, but the function returns true as long as the
      location is known. This depends on the combination of the Value subclass
      of @p addr and the Memory subclass of this memory. */
   virtual bool AddrSingleLoc(const Value* addr) const = 0;

   virtual Value * AllocFrame(const Size & size_of_frame_in_bits,
                               const Size & size_of_ref_in_bits,
                               const std::string & annot = "") = 0;

   virtual void DeallocFrame(const Value * base_ptr) = 0;

   /** Load a value of size @p size_in_bits at @p address from this memory
      @note The returned value should be deleted by the caller */
   virtual Value * Load(const Value *address, const Size & size_in_bits) const = 0;

   /** Load a value of size @p size_in_bits at @p address from this memory.
      After the call, @p successful_loads tells whether at least one part of @p address was valid, 
      and @p unsuccessful_loads tells whether at least one part of @p address was
      invalid (i.e. did not point at a valid memory location).
      @note The returned value should be deleted by the caller */
   virtual Value * Load(const Value * address, const Size & nr_of_bits,
      bool& successful_loads, bool& unsuccessful_loads) const = 0;

   /** Store @p value to this memory at @p address. @p ignore_volatile determines whether
      the "volatile" property should be ignored or not. */
   virtual void Store(const Value * address, const Value * value, bool ignore_volatile) = 0;

   /** Store @p value to this memory at @p address. @p ignore_volatile determines whether
      the "volatile" property should be ignored or not. After the call, @p successful_stores
      tells whether at least one part of @p address was valid (i.e. at least one memory location
      was updated), and @p unsuccessful_stores tells whether at least one part of @p address was
      invalid (i.e. did not point at a valid memory location). */
   virtual void Store(const Value * address, const Value * value, bool ignore_volatile,
      bool& successful_stores, bool& unsuccessful_stores) = 0;

   virtual void SetAsVolatile(const Value * address, const Size & size_in_bits) = 0;

   virtual Memory* LUB(const Memory* other) const = 0;

   /** @returns A pointer to the result, or 0 if the result is bottom */
   virtual Memory* GLB(const Memory* other) const = 0;

   virtual Memory* Widening(const Memory* other) const = 0;

   /** @returns A pointer to the result, or 0 if the result is bottom */
   virtual Memory* Narrowing(const Memory* other) const = 0;

   virtual std::ostream & Print(std::ostream & os = std::cout) const = 0;
};

inline std::ostream &operator << (std::ostream &os, const Memory & mem) {return mem.Print(os);}

#endif // #ifndef MEMORY_H_INCLUDED
