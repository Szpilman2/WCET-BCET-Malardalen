#ifndef SYMBMEMORY_H_INCLUDED
#define SYMBMEMORY_H_INCLUDED

#include "Memory.h"
#include "FrameColl.h"
#include "MemoryDomain.h"
#include "tools/cheap_copy.h"

typedef unsigned FrameId;

class SymbMemory : public Memory
{
public:
   static void SetReuse(bool on) { reuse = on; }

   SymbMemory();

   SymbMemory(const SymbMemory & other);

   virtual ~SymbMemory() {}

   virtual SymbMemory * Copy() const {return new SymbMemory(*this);}

   virtual bool IsEqual(const Memory * other) const;

   bool operator ==(const SymbMemory & other) const;

   /** @copydoc Memory::AddrSingleLoc(const Value*) const */
   virtual bool AddrSingleLoc(const Value* addr) const;

   virtual Value * AllocFrame(const Size & size_of_frame_in_bits, 
                              const Size & size_of_ref_in_bits,
                              const std::string & annot = "");

   virtual void DeallocFrame(const Value * base_ptr);

   /** @return The annotation of the frame identified by @a frame_id */
   const std::string & GetFrameAnnot(FrameId frame_id) const;

   /** @copydoc Memory::Load(const Value*, const Size&) const */
   virtual Value * Load(const Value * address, const Size & nr_of_bits) const;

   /** @copydoc Memory::Load(const Value*,const Size&,bool&,bool&) const */
   virtual Value * Load(const Value * address, const Size & nr_of_bits,
      bool& successful_loads, bool& unsuccessful_loads) const;

   /** @copydoc Memory::Store(const Value*, const Value*,bool) */
   virtual void Store(const Value * address, const Value * value, bool ignore_volatile);

   /** @copydoc Memory::Store(const Value*,const Value*,bool,bool&,bool&) */
   virtual void Store(const Value * address, const Value * value, bool ignore_volatile,
      bool& successful_stores, bool& unsuccessful_stores);

   virtual void SetAsVolatile(const Value * address, const Size & size_in_bits);

   virtual Memory * LUB(const Memory * other) const;

   /** @copydoc Memory::GLB() */
   virtual Memory * GLB(const Memory * other) const;

   virtual Memory* Widening(const Memory* other) const;

   /** @copydoc Memory::Narrowing() */
   virtual Memory* Narrowing(const Memory* other) const;

   virtual std::ostream & Print(std::ostream & os) const;

private:
   static bool reuse;

   cheap_copy<FrameColl> frames;

   SymbMemory(cheap_copy<FrameColl> frames) : frames(frames) {}
};

/** MemoryDomain that creates symbolic memories and pointers
   @note All returned Value pointers should be deleted by the caller */
class SymbMemoryDomain : public MemoryDomain
{
public:
   /** Create a symbolic memory
      @note The returned pointer should be deleted by the caller */
	virtual Memory* CreateMemory() {return new SymbMemory;}

   /** Create a (symbolic) base pointer
      @note The returned pointer should be deleted by the caller */
   virtual Value * CreateBasePtr(const Size& size_in_bits, const Symbol& symbol);

   /** @copydoc MemoryDomain::CreatePointer(const Size&) */
   virtual Value* CreatePointer(const Size& size_in_bits);

   /** Create a pointer from a base pointer and an offset
      @note The returned pointer should be deleted by the caller */
   virtual Value * CreatePointer(const Value* base_ptr, const Value* offset);

   /** Create a pointer from a set of (symbol, offsets) mappings
      @post @a symbol_to_offset has been emptied */
   virtual Value * CreatePointer(const Size& size_in_bits, SymbolToOffset& symbol_to_offset);
};

#endif   // SYMBMEMORY_H_INCLUDED
