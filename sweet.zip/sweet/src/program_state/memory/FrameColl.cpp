#include "FrameColl.h"
#include "Frame.h"
#include "program_state/value/ValueDomain.h"
#include "program_state/value/Value.h"
#include "tools/RangeIterator.h"
#include "tools/IndentingOStream.h"
#include "tools/XAssert.h"
#include "globals.h"

using namespace std;

FrameColl::FrameColl(const FrameColl & other)
   : free_slots(other.free_slots) 
{
   reserve(other.size());
   if (reuse) {
      insert(this->begin(), other.begin(), other.end());
   } else {
      for (auto &f : other) {
         if (f) push_back(cheap_copy<Frame>(f->Copy()));
         else push_back(cheap_copy<Frame>());
      }
   }
}

Size FrameColl::SizeInBits() const
{
   Size size_in_bits = 0;
   for (const_iterator f = begin(); f != end(); ++f)
      size_in_bits += (*f)->SizeInBits();
   return size_in_bits;
}

Size FrameColl::SizeInBits(unsigned frame_id) const
{
   assert(HasFrame(frame_id));
   return at(frame_id)->SizeInBits();
}

bool FrameColl::operator ==(const FrameColl & other) const
{
   if (this == &other)
      return true;

   // If the frame collections do not have the same nr of frames, they are
   // not equal
   if (this->size() != other.size())
      return false;

   // Check that the ith frame of this fc equals the ith frame of the other
   for (RangeIterator<const FrameColl> i(*this), j(other); i; ++i,++j)
      if ((!*i != !*j) || (*i && !(*i)->IsEqual(j->get())))
         return false;
   return true;
}

FrameColl::FrameId FrameColl::AllocFrame(const Size & size_in_bits, const std::string & annot)
{
   size_type new_frame_id;
   if (free_slots.empty())
   {
      new_frame_id = size();
      resize(new_frame_id + 1);
   }
   else 
   {
      new_frame_id = free_slots.top();
      free_slots.pop();
      // Since elements are popped when frames are deallocated, the
      // new_frame_id might be invalid. In that case, all other ids in
      // free_slots are invalid as well (because it is sorted in descending
      // order), so clear it and generate a new new_frame_id.
      if (new_frame_id >= size())
      {
         free_slots = FreeSlotsQueue();
         new_frame_id = size();
         resize(new_frame_id + 1);
      }
   }
   at(new_frame_id).reset( new Frame(size_in_bits, annot) );
   return (unsigned)new_frame_id;
}

void FrameColl::DeallocFrame(unsigned frame_id)
{
   at(frame_id).reset(nullptr);
   free_slots.push(frame_id);
   while (!empty() && !back()) pop_back();
}

void FrameColl::SetAsVolatile(SopIterator & sops, const Size & nr_of_bits)
{
   while (!sops.AtEnd())
   {
      SymbolOffsetPair p = sops.GetNext();
      FrameId frame_id = p.GetSymbol().GetValue();
      unsigned long long offset = p.GetOffset();
      
      cheap_copy<Frame> &frame = at(frame_id);
      // If there is no frame allocated at frame_id, or the address is
      // outside the frame, just ignore it and continue
      if (!frame || LAU::LAUToBits(offset) + nr_of_bits > frame->SizeInBits()) {
         continue;
      } else {
         unsigned long long offset_in_bits = LAU::LAUToBits(offset);
         frame.get_mutable()->SetAsVolatile(offset_in_bits, offset_in_bits + nr_of_bits);
      }
   }
}

const std::string & FrameColl::GetFrameAnnot(FrameId frame_id) const
{
   assert(HasFrame(frame_id) || "Trying to get the annotation of a non-existing frame" == 0);
   return at(frame_id)->GetAnnot();
}

Value * FrameColl::Read(unsigned frame_id, unsigned long long offset_in_lau, const Size & nr_of_bits) const
{
   cheap_copy<Frame> frame = at(frame_id);
   if (LAU::LAUToBits(offset_in_lau) + nr_of_bits > frame->SizeInBits())
      return domain->CreateBottomValue(nr_of_bits);
   return frame->Read(nr_of_bits, offset_in_lau);
}

Value * FrameColl::ReadLUBed(SopIterator& sops, const Size & nr_of_bits, bool & unsuccessful) const
{
   unsuccessful = false;
   // Create an initial resulting value that is bottom
   unique_ptr<Value> result(domain->CreateBottomValue(nr_of_bits));
   // Then run through all the (symbol,offset) pairs in sops, read the addressed values,
   // and LUB them together with result
   while (!sops.AtEnd()) {
      SymbolOffsetPair p = sops.GetNext();
      FrameId frame_id = p.GetSymbol().GetValue();
      unsigned long long offset = p.GetOffset();
      
      cheap_copy<Frame> frame = at(frame_id);
      // If there is no frame allocated at frame_id, or the read will be performed
      // outside the frame, just ignore it and continue
      if (!frame || LAU::LAUToBits(offset) + nr_of_bits > frame->SizeInBits()) {
         unsuccessful = true;
         continue;
      } else {
         // Otherwise, read the value at the addresses position in the frame,
         // compute the LUB of that and the result so far
         unique_ptr<Value> read_value(frame->Read(nr_of_bits, offset));
         assert(!read_value->IsBottom());
         result.reset(result->LUB(read_value.get()));
      }
   }
   return result.release();
}

Value* FrameColl::ReadAllLUBed(const Size& nr_of_bits) const
{
   // Since it tends to be very expensive to call ReadAllLUBed() on every frame,
   // we settle with checking whether at least one frame is large enough that
   // 'nr_of_bits' bits can be read from it. If this is the case, top is
   // returned, otherwise bottom is returned.
   bool successful = false;
   for (int i = 0, n = (int)size(); i != n; ++i) {
      cheap_copy<Frame> frame = at(i);
      if (frame && frame->SizeInBits() >= nr_of_bits) {
         successful = true;
         break;
      }
   }
   return successful? domain->CreateTopValue(nr_of_bits) : domain->CreateBottomValue(nr_of_bits);
}

void FrameColl::Write(unsigned frame_id, unsigned long long offset_in_lau, 
                      const Value * value, bool ignore_volatile, bool & successful)
{
   cheap_copy<Frame> &frame = at(frame_id);
   if (LAU::LAUToBits(offset_in_lau) + value->SizeInBits() > frame->SizeInBits()) {
      successful = false;
      return;
   }
   frame.get_mutable()->Write(value, offset_in_lau, ignore_volatile);
   successful = true;
}

void FrameColl::WriteAndLUB(const Value * value, SopIterator & sops, bool ignore_volatile,
                            bool & successful, bool & unsuccessful)
{
   if (sops.IsSingleton()) {
      SymbolOffsetPair p = sops.GetNext();
      Write(p.GetSymbol().GetValue(), p.GetOffset(), value, ignore_volatile, successful);
      unsuccessful = !successful;
      return;
   }

   successful = unsuccessful = false;
   while (!sops.AtEnd()) {
      SymbolOffsetPair p = sops.GetNext();
      FrameId frame_id = p.GetSymbol().GetValue();
      unsigned long long offset = p.GetOffset();
      
      cheap_copy<Frame> &frame = at(frame_id);
      // If there is no frame allocated at frame_id, or the value will be written
      // outside the frame, just ignore it and continue
      if (!frame || LAU::LAUToBits(offset) + value->SizeInBits() > frame->SizeInBits()) {
         unsuccessful = true;
         continue;
      } else if (frame->AllPatchesTop()) {
         // successful write, but no need to call cheap_copy::get_mutable()
         successful = true;
         continue;
      } else {
         // Otherwise, read the value at the addresses position in the frame,
         // compute the LUB of that and the new value, and then write the result
         // back
         unique_ptr<Value> read_value(frame->Read(value->SizeInBits(), offset));
         unique_ptr<Value> lub(value->LUB(read_value.get()));
         frame.get_mutable()->Write(lub.get(), offset, ignore_volatile);
         successful = true;
      }
   }
}

void FrameColl::WriteAndLUBWithAll(const Value * value, bool ignore_volatile, bool & successful)
{
   successful = false;
   Size nr_of_bits = value->SizeInBits();
   for (unsigned i = 0, n = (int)size(); i != n; ++i) {
      cheap_copy<Frame> &frame = at(i);
      if (!frame || nr_of_bits > frame->SizeInBits())
         continue;
      else if (frame->AllPatchesTop()) {
         // successful write, but no need to call cheap_copy::get_mutable()
         successful = true;
         continue;
      } else {
         frame.get_mutable()->WriteAndLUBWithAll(value, ignore_volatile);
         successful = true;
      }
   }
}

bool FrameColl::reuse = true;

template <typename Op> FrameColl* FrameColl::PerformBinary(const Op& op, const FrameColl* other) const
{
   XASSERT(size() == other->size());

   unique_ptr<FrameColl> new_fc( new FrameColl );
   new_fc->reserve(size());

   for (auto f0 = begin(), f1 = other->begin(); f0 != end() && f1 != other->end(); ++f0, ++f1)
   {
      XASSERT(!*f0 == !*f1); // both equal to null or both not equal to null
      if (!*f0)
         new_fc->push_back(cheap_copy<Frame>());
      else
      {
         cheap_copy<Frame> new_frame = op(*f0, *f1);
         if (!new_frame)
            return 0;
         new_fc->push_back(move(new_frame));
      }
   }
   new_fc->free_slots = free_slots;
   return new_fc.release();
}

FrameColl * FrameColl::LUB(const FrameColl * other) const
{
   if (this == other)
      return Copy();
   if (reuse) {
      return PerformBinary(
         [] (const cheap_copy<Frame> &a, const cheap_copy<Frame> &b) -> cheap_copy<Frame> {
            if (a.get() == b.get()) return a;
            if (a->AllPatchesTop()) return a;
            if (b->AllPatchesTop()) return b;
            return cheap_copy<Frame>( a->LUB(b.get()) );
      }, other);
   } else {
      return PerformBinary(
         [] (const cheap_copy<Frame> &a, const cheap_copy<Frame> &b) {
            return cheap_copy<Frame>( a->LUB(b.get()) );
      }, other);
   }
}

FrameColl * FrameColl::GLB(const FrameColl * other) const
{
   if (this == other)
      return Copy();
   if (reuse) {
      return PerformBinary(
         [] (const cheap_copy<Frame> &a, const cheap_copy<Frame> &b) -> cheap_copy<Frame> {
            if (a.get() == b.get()) return a;
            if (a->AllPatchesTop()) return b;
            if (b->AllPatchesTop()) return a;
            return cheap_copy<Frame>( a->GLB(b.get()) );
      }, other);
   } else {
      return PerformBinary(
         [] (const cheap_copy<Frame> &a, const cheap_copy<Frame> &b) {
            return cheap_copy<Frame>( a->GLB(b.get()) );
      }, other);
   }
}

FrameColl* FrameColl::Widening(const FrameColl* other) const
{
   if (this == other)
      return Copy();
   if (reuse) {
      return PerformBinary(
         [] (const cheap_copy<Frame> &a, const cheap_copy<Frame> &b) -> cheap_copy<Frame> {
            if (a.get() == b.get()) return a;
            return cheap_copy<Frame>( a->Widening(b.get()) );
      }, other);
   } else {
      return PerformBinary(
         [] (const cheap_copy<Frame> &a, const cheap_copy<Frame> &b) {
            return cheap_copy<Frame>( a->Widening(b.get()) );
      }, other);
   }
}

FrameColl* FrameColl::Narrowing(const FrameColl* other) const
{
   if (this == other)
      return Copy();
   if (reuse) {
      return PerformBinary(
         [] (const cheap_copy<Frame> &a, const cheap_copy<Frame> &b) -> cheap_copy<Frame> {
            if (a.get() == b.get()) return a;
            return cheap_copy<Frame>( a->Narrowing(b.get()) );
      }, other);
   } else {
      return PerformBinary(
         [] (const cheap_copy<Frame> &a, const cheap_copy<Frame> &b) {
            return cheap_copy<Frame>( a->Narrowing(b.get()) );
      }, other);
   }
}

std::ostream & FrameColl::Print(std::ostream & os) const
{
   unsigned fi = 0;
   for (const_iterator f = begin(); f != end(); ++f, ++fi)
   {
      if (!*f)
         os << "(Frame " << fi << " is not allocated)" << endl;
      else
         os  << "Frame " << fi << ", \"" << (*f)->GetAnnot() << "\":" 
             << IncrIndent << endl << **f << endl << DecrIndent;
   }
   return os;
}
