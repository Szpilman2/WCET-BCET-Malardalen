#ifndef DATAPATCH_H_INCLUDED
#define DATAPATCH_H_INCLUDED

#include "program_state/Size.h" 
#include "tools/EInt.h"
#include <utility>

class Value;

/** Represents the part of the value @c value ranging from bit @c bit_range0 to bit @c bit_range1, were
    bit 0 is the least significant bit, i.e., little-endianness is used at all times. */
class DataPatch
{
public:
   /** The referenced value */
   Value *value;

   /** Starting bit index for the range */
   unsigned long long bit_range0;

   /** Ending bit index for the range */
   EIntULL bit_range1;

   /** Holds whether the patch is declared volatile or not; the meaning of
       a volatile data patch is given by the context in which the data patch
       is used */
   bool vola;

   DataPatch() : value(nullptr), bit_range0(0), bit_range1(EIntULL::Infinity()), vola(false) {}

   DataPatch(Value *value, const unsigned long long & br_low,
             const EIntULL & br_high, bool vola = false);
   
   /** Construct a data patch holding the entire value @a value. */
   DataPatch(Value *value, bool vola = false);

   DataPatch(const DataPatch &other) : value(nullptr) { *this = other; /* operator = */ }

   /** Move constructor */
   DataPatch(DataPatch &&other) : value(nullptr) { *this = std::move(other); /* operator = */ }

   ~DataPatch();

   DataPatch &operator =(const DataPatch &other);

   DataPatch &operator =(DataPatch &&other);

   Size SizeInBits() const {return bit_range1 - bit_range0;}

   bool IsVolatile() const {return vola;}

   bool operator ==(const DataPatch & other) const;
   bool operator !=(const DataPatch & other) const {return !(*this == other);}

   /** Returns the value stored in the data patch, clipped according to the bit range
      @note The returned value should be deleted by the caller */
   Value *GetClippedValue() const;

   /** Try to merge this with @a other without loosing precision. This can be done, for example,
      if both this and @a other point to top values.
      @return @c true if they could be merged without loss, @c false otherwise
      @pre This patch and @a other are assumed to be adjacent in the patch list
      @post If a merge could be done, this patch is the result;
            The @a other patch is unchanged regardless of the outcome */
   bool TryToMergeWithoutLoss(const DataPatch& other);
};

#endif   // DATAPATCH_H_INCLUDED
