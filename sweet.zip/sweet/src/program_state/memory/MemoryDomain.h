#ifndef MEMORYDOMAIN_H_INCLUDED
#define MEMORYDOMAIN_H_INCLUDED

#include "../value/SymbPointer.h"

class Memory;
template <typename> class EInt;
typedef EInt<unsigned long long> Size;

/** Factory class used to create memories and pointers. TODO: It is still kind of hard-coded to create
   symbolic memories/pointers. Make a new subclass to introduce a new memory/pointer domain.
   @note All returned pointers should be deleted by the caller */
class MemoryDomain
{
public:
   virtual ~MemoryDomain() {}
   
   /** Create a memory
      @note The returned pointer should be deleted by the caller */
   virtual Memory* CreateMemory() = 0;

   /** Create a (symbolic) base pointer
      @note The returned pointer should be deleted by the caller */
   virtual Value* CreateBasePtr(const Size& size_in_bits, const Symbol& symbol) = 0;

   /** Create a TOP pointer
      @note The returned pointer should be deleted by the caller */      
   virtual Value* CreatePointer(const Size& size_in_bits) = 0;

   /** Create a pointer from a base pointer and an offset
      @note The returned pointer should be deleted by the caller */
   virtual Value* CreatePointer(const Value* base_ptr, const Value* offset) = 0;

   /** Create a pointer from a set of (symbol, offsets) mappings
      @post @a symbol_to_offset has been emptied */
   virtual Value* CreatePointer(const Size& size_in_bits, SymbolToOffset& symbol_to_offset) = 0;
};

#endif   // #ifndef MEMORYDOMAIN_H_INCLUDED
