#include "SymbMemory.h"
#include "FrameColl.h"
#include "Frame.h"
#include "program_state/value/ReadValue.h"
#include "program_state/value/IntInterval.h"
#include "program_state/value/SymbIntervalPtrSet.h"
#include "program_state/value/ValueDomain.h"
#include "tools/RangeIterator.h"
#include "globals.h"
#include <vector>

using namespace std;

SymbMemory::SymbMemory()
: frames( new FrameColl )
{
}

SymbMemory::SymbMemory(const SymbMemory & other)
: Memory(other)
{
   if (reuse) frames = other.frames;
   else frames.reset( other.frames->Copy() );
}

bool SymbMemory::IsEqual(const Memory * other) const
{
   if (const SymbMemory * other_ = dynamic_cast<const SymbMemory *>(other))
      return *this == *other_;
   else
      return false;
}

bool SymbMemory::operator ==(const SymbMemory & other) const {
   return frames->IsEqual(other.frames.get());
}

bool SymbMemory::AddrSingleLoc(const Value* addr) const
{
   if (const SymbPointer* symb = addr->AsSymbPointer())
      return symb->IsSingleElem();
   else
      return false;
}

Value * SymbMemory::AllocFrame(const Size & size_of_frame_in_bits, 
                               const Size & size_of_ref_in_bits,
                               const std::string & annot)
{
   FrameColl::FrameId new_data_id = frames.get_mutable()->AllocFrame(size_of_frame_in_bits, annot);
   Symbol base_ptr_symbol(new_data_id, 0);
   base_ptr_symbol.SetAnnot(annot);
   return domain->GetMemoryDomain()->CreateBasePtr(size_of_ref_in_bits, base_ptr_symbol);
}

void SymbMemory::DeallocFrame(const Value * base_ptr)
{
   if (base_ptr->IsBottom())
      return;

   const SymbPointer* base_ptr_ = base_ptr->AsSymbPointer();
   if (base_ptr_ == 0)
      throw logic_error("Deallocing frames given by a top base pointer is not supported at present");

   SymbolColl symbols;
   base_ptr_->GetSymbols(symbols);
   for (SymbolColl::const_iterator f = symbols.begin(); f != symbols.end(); ++f)
      frames.get_mutable()->DeallocFrame(f->GetValue());
}

const std::string & SymbMemory::GetFrameAnnot(FrameId frame_id) const
{
   return frames->GetFrameAnnot(frame_id);
}

Value * SymbMemory::Load(const Value * address, const Size & nr_of_bits) const
{
   bool dummy_sl, dummy_ul;
   return Load(address, nr_of_bits, dummy_sl, dummy_ul);
}

Value* 
SymbMemory::Load(const Value * address, const Size & nr_of_bits,
                 bool& successful_loads, bool& unsuccessful_loads) const
{
   // Visitor that loads from a frame collection
   struct FrameCollLoader : public ValueVisitor {
      // input
      cheap_copy<FrameColl> frame_coll;
      Size nr_of_bits;
      bool reduce;
      // output
      unique_ptr<Value> loaded_value;
      bool successful_loads, unsuccessful_loads;
      
      // Handles the cases where the address is not a symbolic pointer. This
      // basically means that the address is either top or bottom.
      virtual void VisitValue(const Value& address)
      {
         // TODO: shouldn't bottom be returned if 'address' is, e.g., a bitstring, unless a
         // special option is enabled?

         // Bottom case
         if (address.IsBottom()) {
            loaded_value.reset( domain->CreateBottomValue(nr_of_bits) );
            successful_loads = unsuccessful_loads = false;
         }
         else {
            // note: regardless of the number of frames allocated, a top address always contains
            // references to nonexistent frames and references outside of frames, hence
            // the unsuccessful_loads = true
            loaded_value.reset( frame_coll->ReadAllLUBed(nr_of_bits) );
            successful_loads = !loaded_value->IsBottom();
            unsuccessful_loads = true;
         }
      }

      // Handle the case where the address is a symbolic pointer
      virtual void VisitSymbPointer(const SymbPointer& address)
      {
         // TODO: control with an option
         if (address.IsTopSymbPointer()) {
            unsuccessful_loads = true;
            // if at least one frame is large enough, a successful load is possible
            for (RangeIterator<const FrameColl> fi(*frame_coll); fi; ++fi) {
               if ((*fi)->SizeInBits() >= nr_of_bits) {
                  loaded_value.reset( domain->CreateTopValue(nr_of_bits) );
                  successful_loads = true;
                  return;
               }
            }
            // otherwise, there are no successful loads
            loaded_value.reset( domain->CreateBottomValue(nr_of_bits) );
            successful_loads = false;
            return;
         }

         if (reduce) {
            // Reduce the pointer to only include valid (symbol,offset) pairs
            bool reduced;
            unique_ptr<Value> reduced_addr(
               address.ReduceToPointInsideFrames(*frame_coll, nr_of_bits, reduced)
            );

            if (reduced) {
               // Recursively visit the reduced pointer and return
               reduce = false;
               reduced_addr->AcceptVisitor(this);
               unsuccessful_loads = true;
               return;
            }
         }

         // The visited pointer did not need to be reduced: use it to load from the frame collection
         unique_ptr<SopIterator> sops( address.GetIterator() );
         loaded_value.reset( frame_coll->ReadLUBed(*sops, nr_of_bits, unsuccessful_loads) );
         successful_loads = !loaded_value->IsBottom();
      }

      virtual void VisitReadValue(const ReadValue& address)
      {
         // Fuse and recursively visit the pointer
         unique_ptr<Value> fused( address.Fuse() );
         fused->AcceptVisitor(this);
      }
   };
   FrameCollLoader loader;
   loader.frame_coll = frames;
   loader.nr_of_bits = nr_of_bits;
   loader.reduce = true;
   address->AcceptVisitor(&loader);
   successful_loads = loader.successful_loads;
   unsuccessful_loads = loader.unsuccessful_loads;
   return loader.loaded_value.release();
}

void SymbMemory::Store(const Value * address, const Value * value, bool ignore_volatile)
{
   bool dummy_ss, dummy_us;
   Store(address, value, ignore_volatile, dummy_ss, dummy_us);
}

void 
SymbMemory::Store(const Value * address, const Value * value, bool ignore_volatile,
                  bool& successful_stores, bool& unsuccessful_stores)
{
   // Visitor that stores to a frame collection
   struct FrameCollStorer : public ValueVisitor {
      // input
      cheap_copy<FrameColl> *frame_coll;
      const Value* stored_value;
      bool ignore_volatile;
      bool reduce;
      // output
      bool successful_stores, unsuccessful_stores;

      // Handles the cases where the address is not a symbolic pointer. This
      // basically means that the address is either top or bottom.
      virtual void VisitValue(const Value& address)
      {
         // Bottom case
         if (address.IsBottom()) {
            successful_stores = unsuccessful_stores = false;
         }
         // Top case
         else {
            // note: regardless of the number of frames allocated, a top address always contains
            // references to nonexistent frames and references outside of frames, hence
            // the unsuccessful_stores = true
            frame_coll->get_mutable()->WriteAndLUBWithAll(stored_value, ignore_volatile, successful_stores);
            unsuccessful_stores = true;
         }
      }

      // Handle the case where the address is from a bitstring domain
      virtual void VisitBitstring(const Bitstring& address)
      {
         // If the "isi" flag is turned on, and address is a concrete value,
         // just skip the store.
         if (g_ignore_stores_to_int_addr && address.IsSingleElem()) {
            // For simplicity, the store is handled as though it were a successful store that
            // just happened to store the exact same value(s) that were already
            // stored to the memory location(s) in question.
            successful_stores = true;
            unsuccessful_stores = false;
            return;
         }
         // Otherwise, proceed by calling the base class' implementation
         ValueVisitor::VisitBitstring(address);
      }

      // Handle the case where the address is a symbolic pointer
      virtual void VisitSymbPointer(const SymbPointer& address)
      {
         if (reduce) {
            // Reduce the pointer to only include valid (symbol,offset) pairs
            bool reduced;
            unique_ptr<Value> reduced_addr(
               address.ReduceToPointInsideFrames(**frame_coll, stored_value->SizeInBits(), reduced)
            );

            if (reduced) {
               // Recursively visit the reduced pointer and return
               reduce = false;
               reduced_addr->AcceptVisitor(this);
               unsuccessful_stores = true;
               return;
            }
         }

         // The visited pointer did not need to be reduced: use it to store to the frame collection
         unique_ptr<SopIterator> sops( address.GetIterator() );
         frame_coll->get_mutable()->WriteAndLUB(stored_value, *sops, ignore_volatile, successful_stores, unsuccessful_stores);
      }

      virtual void VisitReadValue(const ReadValue& address)
      {
         // Fuse and recursively visit the pointer
         unique_ptr<Value> fused( address.Fuse() );
         fused->AcceptVisitor(this);
      }
   };

   FrameCollStorer frame_coll_storer;
   frame_coll_storer.frame_coll = &frames;
   frame_coll_storer.stored_value = value;
   frame_coll_storer.ignore_volatile = ignore_volatile;
   frame_coll_storer.reduce = true;
   address->AcceptVisitor(&frame_coll_storer);
   successful_stores = frame_coll_storer.successful_stores;
   unsuccessful_stores = frame_coll_storer.unsuccessful_stores;
}

void SymbMemory::SetAsVolatile(const Value * address, const Size & size_in_bits)
{
   const SymbPointer* address_ = address->AsSymbPointer();
   if (address_ == 0)
      throw logic_error("This is not supported yet");

   unique_ptr<SopIterator> sops( address_->GetIterator() );
   frames.get_mutable()->SetAsVolatile(*sops, size_in_bits);
}

Memory * SymbMemory::LUB(const Memory * other) const
{
   const SymbMemory * other_ = &dynamic_cast<const SymbMemory &>(*other);
   if (this == other_) return this->Copy();

   if (reuse && frames.get() == other_->frames.get())
      return new SymbMemory(frames);

   // Create a new LUB:ed memory
   return new SymbMemory( cheap_copy<FrameColl>( frames->LUB(other_->frames.get()) ) );
}

Memory * SymbMemory::GLB(const Memory * other) const
{
   const SymbMemory * other_ = &dynamic_cast<const SymbMemory &>(*other);
   if (this == other_) return this->Copy();

   if (reuse && frames.get() == other_->frames.get())
      return new SymbMemory(frames);

   // Take GLB of the frame collections
   cheap_copy<FrameColl> glb_fc( frames->GLB(other_->frames.get()) );

   // Check that we got a correct value
   if (!glb_fc)
      return 0;

   // Create a new GLB:ed memory
   return new SymbMemory(glb_fc);
}

Memory* SymbMemory::Widening(const Memory* other) const
{
   const SymbMemory * other_ = &dynamic_cast<const SymbMemory &>(*other);
   if (this == other_) return this->Copy();

   if (reuse && frames.get() == other_->frames.get())
      return new SymbMemory(frames);

   return new SymbMemory( cheap_copy<FrameColl>( frames->Widening(other_->frames.get()) ) );
}

Memory* SymbMemory::Narrowing(const Memory* other) const
{
   const SymbMemory * other_ = &dynamic_cast<const SymbMemory &>(*other);
   if (this == other_) return this->Copy();

   if (reuse && frames.get() == other_->frames.get())
      return new SymbMemory(frames);

   cheap_copy<FrameColl> narrowed( frames->Narrowing(other_->frames.get()) );
   if (!narrowed)
      return 0;
   return new SymbMemory(narrowed);
}

std::ostream & SymbMemory::Print(std::ostream & os) const
{
   return os << *frames;
}

bool SymbMemory::reuse = true;

// Members of SymbMemoryDomain - - - - - - - - - - - - - - - - - - - - - - - -

Value* SymbMemoryDomain::CreateBasePtr(const Size& size_in_bits, const Symbol& symbol)
{
   return new SymbIntervalPtrSet(size_in_bits, symbol, Integer(0));
}

Value* SymbMemoryDomain::CreatePointer(const Size& size_in_bits)
{
   return new SymbIntervalPtrSet(size_in_bits);
}

Value* SymbMemoryDomain::CreatePointer(const Value* base_ptr, const Value* offset)
{
   IntInterval _0(1, Integer(0));
   return base_ptr->Add(offset, &_0);
}

Value* SymbMemoryDomain::CreatePointer(const Size& size_in_bits, SymbolToOffset& symbol_to_offset)
{
   return symbol_to_offset.empty() ?
      domain->CreateBottomValue(size_in_bits)
      : new SymbIntervalPtrSet(size_in_bits, symbol_to_offset);
}
