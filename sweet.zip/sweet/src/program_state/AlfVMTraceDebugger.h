#ifndef ALFVMTRACEDEBUGGER_H_INCLUDED
#define ALFVMTRACEDEBUGGER_H_INCLUDED

#include "AlfVMDebugger.h"

class AlfVMTraceDebugger : public AlfVMDebugger
{
public:
   AlfVMTraceDebugger(IndentingOStream * output_stream)
      : os(output_stream), store_stmt(0) {}

   virtual void ExprEvalEnabled(bool enabled) {expr_eval_enabled = enabled;}

   virtual void Statement(const alf::AStmt * stmt, const State * state);
   virtual void StatementFinished(std::vector<State *> & updated_states);

   virtual void NullStatement(const alf::CNullStmtTuple * stmt);

   virtual void StoreStatement(const alf::CStoreStmtTuple * stmt);
   virtual void StoredValue(const Value * value);
   virtual void StoredToAddress(const Value * value);

   virtual void JumpStatement(const alf::CJumpStmtTuple * stmt);
   virtual void JumpedToPP(const ProgramPoint * program_point);

   virtual void SwitchStatement(const alf::CSwitchStmtTuple * stmt);
   virtual void EvaledSwitchExpr(const Value * value);
   virtual void BranchIntValue(const alf::CIntNumValTuple * value);
   virtual void FollowBranch(const ProgramPoint * jumped_to);
   virtual void DoNotFollowBranch();
   virtual void FollowFallThroughBranch(const ProgramPoint * jumped_to);
   virtual void DoNotFollowFallThroughBranch();

   virtual void RestrictedState(RestrictedALFState * restr_alf_state);
   virtual void Restrict(const alf::AExpr * expr, const Value * r);

   virtual void CallStatement(const alf::CCallStmtTuple * stmt);
   virtual void CalledFunction(const alf::CFuncTuple * function);
   virtual void FuncArgument(const Value * value);
   virtual void FuncRetValAddr(const Value * value);

   virtual void ReturnStatement(const alf::CReturnStmtTuple * stmt);
   virtual void ReturnedValue(const Value * value, const Value * address);
   virtual void ReturnedToPP(const ProgramPoint * program_point);

   virtual void FreeStatement(const alf::CFreeStmtTuple * stmt);
   virtual void FreedFrameRef(const Value * fref);

   virtual void EvalExpr(const alf::AExpr * expr);
   virtual void ResultFromEval(const Value * value);
   virtual void EvalOperand();

private:
   struct PushedExpr
   {
      PushedExpr(const alf::AExpr * pushed_expr)
         : expr(pushed_expr), operand_index(0) {}
      const alf::AExpr * expr;
      int operand_index;
   };

   IndentingOStream * os;

   bool expr_eval_enabled;

   const alf::CStoreStmtTuple * store_stmt;
   unsigned store_list_index;

   const alf::CCallStmtTuple * call_stmt;
   unsigned func_arg_index, func_addr_index;

   const alf::CReturnStmtTuple * return_stmt;
   unsigned ret_val_index;

   int branch_index;

   std::stack<PushedExpr> exprs;

   static std::string NodeTypeToStmtName(alf::CGenericNode::TYPE node_type);

   IndentingOStream & GetOS() const {return *os;}
   int GetBranchIndex() const {return branch_index;}
   void ResetBranchIndex() {branch_index = -1;}
   void IncrBranchIndex() {++branch_index;}
};

#endif   // #ifndef ALFVMTRACEDEBUGGER_H_INCLUDED
