#ifndef ALFVMDEBUGGER_H_INCLUDED
#define ALFVMDEBUGGER_H_INCLUDED

#include "ae/AEStrategy.h"
#include "State.h"
#include "program/alf/CGenericNode.h"
#include <vector>
#include <stack>

// Forward declarations --------------------------------------

namespace alf
{
   class AStmt;
   class AExpr;
   class CNullStmtTuple;
   class CStoreStmtTuple;
   class CJumpStmtTuple;
   class CSwitchStmtTuple;
   class CCallStmtTuple;
   class CReturnStmtTuple;
   class CFreeStmtTuple;
   class COpNumExprTuple;
   class CFuncTuple;
   class CIntNumValTuple;
}

class State;
class RestrictedALFState;
class Value;
class ProgramPoint;
template <typename, typename> class IndentingOStreamBase;
typedef IndentingOStreamBase<char, std::char_traits<char> > IndentingOStream;

/** Base class for ALF debuggers. Has empty methods. */
class AlfVMDebugger : public AEStrategyDebugger<State>
{
public:
   virtual ~AlfVMDebugger() { }

   virtual void ExprEvalEnabled(bool enabled) {}

   /** @name Functions for reporting events and results to the debugger
       @{ */

   virtual void Statement(const alf::AStmt * stmt, const State * state) {}
   virtual void StatementFinished(std::vector<State *> & updated_states) {}

   virtual void NullStatement(const alf::CNullStmtTuple * stmt) {}

   virtual void StoreStatement(const alf::CStoreStmtTuple * stmt) {}
   virtual void StoredValue(const Value * value) {}
   virtual void StoredToAddress(const Value * value) {}

   virtual void JumpStatement(const alf::CJumpStmtTuple * stmt) {}
   virtual void JumpedToPP(const ProgramPoint * program_point) {}

   virtual void SwitchStatement(const alf::CSwitchStmtTuple * stmt) {}
   virtual void EvaledSwitchExpr(const Value * value) {}
   virtual void BranchIntValue(const alf::CIntNumValTuple * value) {}
   virtual void FollowBranch(const ProgramPoint * jumped_to) {}
   virtual void DoNotFollowBranch() {}
   virtual void FollowFallThroughBranch(const ProgramPoint * jumped_to) {}
   virtual void DoNotFollowFallThroughBranch() {}

   virtual void RestrictedState(RestrictedALFState * restr_alf_state) {}
   virtual void Restrict(const alf::AExpr * expr, const Value * r) {}

   virtual void CallStatement(const alf::CCallStmtTuple * stmt) {}
   virtual void CalledFunction(const alf::CFuncTuple * function) {}
   virtual void FuncArgument(const Value * value) {}
   virtual void FuncRetValAddr(const Value * value) {}

   virtual void ReturnStatement(const alf::CReturnStmtTuple * stmt) {}
   virtual void ReturnedValue(const Value * value, const Value * address) {}
   virtual void ReturnedToPP(const ProgramPoint * program_point) {}

   virtual void FreeStatement(const alf::CFreeStmtTuple * stmt) {}
   virtual void FreedFrameRef(const Value * fref) {}

   virtual void EvalExpr(const alf::AExpr * expr) {}
   virtual void ResultFromEval(const Value * value) {}
   virtual void EvalOperand() {}

   virtual void RecordPerformedMerge(const State & a, const State & b,
                                     const State & merged) {}
   /** @} */
};

#endif   // #ifndef ALFVMDEBUGGER_H_INCLUDED
