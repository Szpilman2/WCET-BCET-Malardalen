#include "VarEnviron.h"
#include "value/Value.h"
#include "tools/XAssert.h"
#include "symtab/CSymTabBase.h"
#include "symtab/CSymTabIdentifier.h" 
#include <algorithm>

using namespace std;

template <typename Op> VariableInfo VariableInfo::Combine(const VariableInfo& other, const Op& op) const
{
   XASSERT(GetAmountAllocated() == other.GetAmountAllocated());
   return VariableInfo(op(GetBasePointer(), other.GetBasePointer()), GetAmountAllocated());
}

void VariableInfo::CleanUp()
{
   delete base_ptr;
   base_ptr = 0;
}

bool VariableInfo::operator ==(const VariableInfo & other) const
{
   if (GetAmountAllocated() != other.GetAmountAllocated())
      return false;
   return GetBasePointer()->IsEqual(other.GetBasePointer());
}

// Private members of VarEnviron -------------------------------

VarEnviron::VarEnviron(const VarEnviron & other)
{
   for (EnvIterator m = other.GetEnvIterator(); m != other.GetEnvEndIterator(); ++m)
      Update(m->first, unique_ptr<Value>(m->second.GetBasePointer()->Copy()), m->second.GetAmountAllocated());
}

VarEnviron::~VarEnviron()
{
   for (iterator m = begin(); m != end(); ++m)
      m->second.CleanUp();
}

bool VarEnviron::IsEqual(const VarEnviron * other) const
{
   return this == other || *this == *other;
}

bool VarEnviron::Defined(unsigned id) const
{
   return find(id) != end();
}

bool VarEnviron::Defined(const Value * base_ptr) const
{
   for (EnvIterator m = GetEnvIterator(); m != GetEnvEndIterator(); ++m)
      if (m->second.GetBasePointer() == base_ptr)
         return true;
   return false;
}

Value * VarEnviron::ApplyEnvFunction(unsigned id) const
{
   EnvIterator m = find(id);
   if (m == end())
      return 0;
   else
      return m->second.GetBasePointer()->Copy();
}

Size VarEnviron::GetAmountAllocated(unsigned id) const
{
   EnvIterator m = find(id);
   if (m == end())
      return 0;
   else
      return m->second.GetAmountAllocated();
}

void VarEnviron::Update(unsigned id, std::unique_ptr<Value> base_ptr, Size amount_allocated)
{
   assert(find(id) == end());
   insert(make_pair(id, VariableInfo(base_ptr.release(), amount_allocated)));
}

