#include "RestrictedALFState.h"
#include "ExprNode.h"
#include "State.h"
#include "value/ValueDomain.h"
#include "program_counter/ProgramCounterECFG.h"

using namespace std;
using namespace alf;

// RestrictedALFState - - - - - - - - - - - - - - - ->

RestrictedALFState::RestrictedALFState(const alf::AExpr * expr, std::unique_ptr<State> state,
                                       const ValueDomain * domain, const AlfVM * alf_vm)
: state(state.release()), domain(domain)
{
   RestrictedALFState::expr = ExprNode::Create(expr, RestrictedALFState::state,
                                               domain, alf_vm);
}

RestrictedALFState::RestrictedALFState(const RestrictedALFState & other)
{
   state = other.state->Copy();
   expr = other.expr->Copy(state);
   domain = other.domain;
}


RestrictedALFState::~RestrictedALFState()
{
   delete expr;
   delete state;
}

void RestrictedALFState::Swap(RestrictedALFState& other)
{
   ExprNode* old_this_expr = this->expr;
   State* old_this_state = this->state;
   const ValueDomain* old_this_domain = this->domain;

   this->expr = other.expr;
   this->state = other.state;
   this->domain = other.domain;

   other.expr = old_this_expr;
   other.state = old_this_state;
   other.domain = old_this_domain;
}

void RestrictedALFState::RestrictEq(const Value * r)
{
   if (GetState()->IsBottom())
      return;

   // Update the annotations in the tree (will hold the values of the
   // different subtrees in the current state during the restricting)
   expr->UpdateAnnot();
   
   bool is_bottom = expr->RestrictEq(r);

   // If the annotation of the root of the expression tree became bottom in
   // the restriction, replace the restricted state by a bottom state
   if (is_bottom)
   {
      unique_ptr<State> bottom_state(State::CreateBottomState(
         unique_ptr<ProgramCounterECFG>(state->GetProgramCounterECFG()->Copy())));
      delete state;
      state = bottom_state.release();
   }
}

void RestrictedALFState::RestrictNEq(const Value * r)
{
   if (GetState()->IsBottom())
      return;

   // Update the annotations in the tree (will hold the values of the
   // different subtrees in the current state during the restricting)
   expr->UpdateAnnot();

   bool bottom = expr->RestrictNEq(r);

   // If the annotation of the root of the expression tree became bottom in
   // the restriction, replace the restricted state by a bottom state
   if (bottom)
   {
      unique_ptr<State> bottom_state(State::CreateBottomState(
         unique_ptr<ProgramCounterECFG>(state->GetProgramCounterECFG()->Copy())));
      delete state;
      state = bottom_state.release();
   }
}

std::unique_ptr<State> RestrictedALFState::ReleaseState()
{
   unique_ptr<State> ret_state(state);
   state = 0;
   delete expr;
   expr = 0;
   return ret_state;
}

std::ostream & RestrictedALFState::Print(std::ostream & os) const
{
   return os << *expr;
}
