#include "CallStack.h"
#include "VarEnviron.h"
#include "value/Value.h"
#include "program_counter/ProgramCounter.h"
#include "tools/IndentingOStream.h"
#include "tools/RangeIterator.h"
#include "macros.h"
#include <iterator>
#include <functional>

using namespace std;

bool CallStack::operator ==(const CallStack& other) const
{
   if (this == &other) return true;
   // Check that they have the same size
   if (Height() != other.Height()) return false;
   // Check that all elements in the lists are equal
   auto this_elem = _elems.begin();
   auto other_elem = other._elems.begin();
   for(; this_elem != _elems.end(); this_elem++, other_elem++) {
      if(!(*this_elem)->IsEqual(**other_elem)) return false;
   }
   // All things are equal 
   return true;
}

void CallStack::PushFunction(std::unique_ptr<ProgramPoint> return_pp, std::unique_ptr<VarEnviron> env,
                             std::unique_ptr<RetAddrList> ret_addr_list, const std::string & func_name)
{
   for (auto &a : *ret_addr_list) {
      if (a->IsBottom())
         throw logic_error("Cannot push bottom return addresses to call stack");
   }

   _elems.push_back( cheap_copy<Elem>( new Elem(move(return_pp), move(env), move(ret_addr_list), func_name) ) );
}

void CallStack::PopFunction(unique_ptr<ProgramPoint> & return_pp)
{
   // TODO: this makes an unnecessary deep copy of the top Elem before popping it
   return_pp.reset(_elems.back().get_mutable()->RemoveRetProgramPoint());
   _elems.pop_back();
}

CallStack* CallStack::GLB(const CallStack* other) const
{
   assert(_elems.size() == other->_elems.size() || "The two call stacks must have the same number of elements" == NULL);

   unique_ptr<CallStack> ret_val(new CallStack);
   ret_val->_elems.reserve(_elems.size());

   for (auto e1 = _elems.begin(), e2 = other->_elems.begin();
        e1 != _elems.end() && e2 != other->_elems.end();
        ++e1, ++e2)
   {
      // check trivial case
      if (_reuse && (*e1).get() == (*e2).get()) {
         ret_val->_elems.push_back(*e1);
         continue;
      }

      // Do some debugging checks
      assert((*e1)->GetEnviron()->IsEqual((*e2)->GetEnviron()) || "Environments on the call stack must be equal" == NULL);
      assert((*e1)->GetRetProgramPoint()->IsEqual((*e2)->GetRetProgramPoint()) || "Program points on call stack must be equal" == NULL);
      assert((*e1)->FuncName() == (*e2)->FuncName() || "Function names on the call stack must be equal" == 0);

      unique_ptr<RetAddrList> glb_ral(new RetAddrList);
      bool not_bottom = BinRALOp(mem_fn(&Value::GLB), *(*e1)->GetRetAddrList(), *(*e2)->GetRetAddrList(), *glb_ral);
      if (!not_bottom)
         return 0;
      unique_ptr<ProgramPoint> glb_pp((*e1)->GetRetProgramPoint()->Copy());
      unique_ptr<VarEnviron> glb_env( new VarEnviron(*(*e1)->GetEnviron()) );
      string glb_func_name = (*e1)->FuncName();
      ret_val->_elems.push_back( cheap_copy<Elem>( new Elem(move(glb_pp), move(glb_env), move(glb_ral), glb_func_name) ) );
   }

   return ret_val.release();
}

CallStack* CallStack::LUB(const CallStack* other) const
{
   assert(_elems.size() == other->_elems.size() || "The two call stacks must have the same number of elements" == NULL);

   unique_ptr<CallStack> ret_val(new CallStack);
   ret_val->_elems.reserve(_elems.size());

   for (auto e1 = _elems.begin(), e2 = other->_elems.begin();
        e1 != _elems.end() && e2 != other->_elems.end();
        ++e1, ++e2)
   {
      // check trivial case
      if (_reuse && (*e1).get() == (*e2).get()) {
         ret_val->_elems.push_back(*e1);
         continue;
      }

      // Do some debugging checks
      assert((*e1)->GetEnviron()->IsEqual((*e2)->GetEnviron()) || "Environments on the call stack must be equal" == NULL);
      assert((*e1)->GetRetProgramPoint()->IsEqual((*e2)->GetRetProgramPoint()) || "Program points on call stack must be equal" == NULL);
      assert((*e1)->FuncName() == (*e2)->FuncName() || "Function names on the call stack must be equal" == 0);

      unique_ptr<RetAddrList> lub_ral(new RetAddrList);
      BinRALOp(mem_fn(&Value::LUB), *(*e1)->GetRetAddrList(), *(*e2)->GetRetAddrList(), *lub_ral);
      unique_ptr<ProgramPoint> lub_pp((*e1)->GetRetProgramPoint()->Copy());
      unique_ptr<VarEnviron> lub_env( new VarEnviron(*(*e1)->GetEnviron()) );
      string lub_func_name = (*e1)->FuncName();
      ret_val->_elems.push_back( cheap_copy<Elem>( new Elem(move(lub_pp), move(lub_env), move(lub_ral), lub_func_name) ) );
   }

   return ret_val.release();
}

CallStack* CallStack::Widening(const CallStack* other) const
{
   assert(_elems.size() == other->_elems.size() || "The two call stacks must have the same number of elements" == NULL);

   unique_ptr<CallStack> ret_val(new CallStack);
   ret_val->_elems.reserve(_elems.size());

   for (auto e1 = _elems.begin(), e2 = other->_elems.begin();
        e1 != _elems.end() && e2 != other->_elems.end();
        ++e1, ++e2)
   {
      // check trivial case
      if (_reuse && (*e1).get() == (*e2).get()) {
         ret_val->_elems.push_back(*e1);
         continue;
      }

      // Do some debugging checks
      assert((*e1)->GetEnviron()->IsEqual((*e2)->GetEnviron()) || "Environments on the call stack must be equal" == NULL);
      assert((*e1)->GetRetProgramPoint()->IsEqual((*e2)->GetRetProgramPoint()) || "Program points on call stack must be equal" == NULL);
      assert((*e1)->FuncName() == (*e2)->FuncName() || "Function names on the call stack must be equal" == 0);

      unique_ptr<RetAddrList> wid_ral(new RetAddrList);
      BinRALOp(mem_fn(&Value::Widening), *(*e1)->GetRetAddrList(), *(*e2)->GetRetAddrList(), *wid_ral);
      unique_ptr<ProgramPoint> wid_pp((*e1)->GetRetProgramPoint()->Copy());
      unique_ptr<VarEnviron> wid_env( new VarEnviron(*(*e1)->GetEnviron()) );
      string wid_func_name = (*e1)->FuncName();
      ret_val->_elems.push_back( cheap_copy<Elem>( new Elem(move(wid_pp), move(wid_env), move(wid_ral), wid_func_name) ) );
   }

   return ret_val.release();
}

CallStack* CallStack::Narrowing(const CallStack* other) const
{
   assert(_elems.size() == other->_elems.size() || "The two call stacks must have the same number of elements" == NULL);

   unique_ptr<CallStack> ret_val(new CallStack);
   ret_val->_elems.reserve(_elems.size());

   for (auto e1 = _elems.begin(), e2 = other->_elems.begin();
        e1 != _elems.end() && e2 != other->_elems.end();
        ++e1, ++e2)
   {
      // check trivial case
      if (_reuse && (*e1).get() == (*e2).get()) {
         ret_val->_elems.push_back(*e1);
         continue;
      }

      // Do some debugging checks
      assert((*e1)->GetEnviron()->IsEqual((*e2)->GetEnviron()) || "Environments on the call stack must be equal" == NULL);
      assert((*e1)->GetRetProgramPoint()->IsEqual((*e2)->GetRetProgramPoint()) || "Program points on call stack must be equal" == NULL);
      assert((*e1)->FuncName() == (*e2)->FuncName() || "Function names on the call stack must be equal" == 0);

      unique_ptr<RetAddrList> nar_ral(new RetAddrList);
      BinRALOp(mem_fn(&Value::Narrowing), *(*e1)->GetRetAddrList(), *(*e2)->GetRetAddrList(), *nar_ral);
      unique_ptr<ProgramPoint> nar_pp((*e1)->GetRetProgramPoint()->Copy());
      unique_ptr<VarEnviron> nar_env( new VarEnviron(*(*e1)->GetEnviron()) );
      string nar_func_name = (*e1)->FuncName();
      ret_val->_elems.push_back( cheap_copy<Elem>( new Elem(move(nar_pp), move(nar_env), move(nar_ral), nar_func_name) ) );
   }

   return ret_val.release();
}

// CallStack::Elem members - - - - - - - - - - - - - -

bool CallStack::Elem::operator ==(const Elem& other) const
{
  // If they have the same address 
  if (this == &other) {
    return true;
  }

  // If they refer to the same function
  if (FuncName() != other.FuncName()) {
    return false;
  }

  // If they refer to the same program point
  if (!GetRetProgramPoint()->IsEqual(other.GetRetProgramPoint())) {
    return false;
  }

  // If the environments are equal
  if (!GetEnviron()->IsEqual(other.GetEnviron())) {
    return false;
  }

  // If the return adresses are equal
  if (GetRetAddrList()->size() != other.GetRetAddrList()->size())
    return false;
  for (int i = 0, n = (int)GetRetAddrList()->size(); i<n; ++i) {
    if (!(*GetRetAddrList())[i]->IsEqual( (*other.GetRetAddrList())[i].get() ))
      return false;
  }

  return true;
}

// Private members of CallStack ------------------------------------------------------------

bool CallStack::_reuse = true;

template <typename Op>
bool CallStack::BinRALOp(const Op& op, const RetAddrList& a, const RetAddrList& b, RetAddrList& result)
{
   assert(a.size() == b.size());
   result.reserve(a.size());
   for (auto ai = a.begin(), bi = b.begin(), an = a.end(); ai != an; ++ai, ++bi) {
      unique_ptr<Value> op_result( op((*ai).get(), (*bi).get()) );
      if (op_result->IsBottom())
         return false;
      else
         result.push_back( move(op_result) );
   }
   return true;
}
