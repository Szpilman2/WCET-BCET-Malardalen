#include "AlfVM.h"
#include "absann/CALFAbsAnnot.h"
#include "program_counter/ProgramCounter.h"
#include "value/SymbolOffsetPair.h"
#include "value/ValueDomain.h"
#include "value/IntegerDomain.h"
#include "value/FloatDomain.h"
#include "memory/Memory.h"
#include "memory/MemoryDomain.h"
#include "tools/Integer.h"
#include "globals.h"

using namespace alf;

void AlfVM::HandleProgEntryALFAbsAnnot(State *state) const
{
   if (abs_annots == 0)
      return;
   if (CALFAbsAnnot *annot = abs_annots->GetProgEntryALFAbsAnnot())
         UpdateStateAccordingToAnnot(state, annot);
}

void AlfVM::HandleFuncEntryALFAbsAnnot(const alf::CFuncTuple * func, State *state) const
{
   if (abs_annots == 0)
      return;
   if (CALFAbsAnnot *annot = abs_annots->GetFuncEntryALFAbsAnnot(const_cast<CFuncTuple*>(func)))
      UpdateStateAccordingToAnnot(state, annot);
}

void AlfVM::HandleStmtEntryALFAbsAnnot(const alf::AStmt * stmt, State *state) const
{
   if (abs_annots == 0)
      return;
   if (list<CALFAbsAnnot *> * annot_list = abs_annots->GetStmtEntryALFAbsAnnot(const_cast<AStmt *>(stmt))) {
      for (list<CALFAbsAnnot *>::const_iterator ai = annot_list->begin(),
           an = annot_list->end(); ai != an; ++ai)
      {
         UpdateStateAccordingToAnnot(state, *ai);
      }
   }
}

void AlfVM::HandleStmtExitALFAbsAnnot(const alf::AStmt * stmt, vector<State*> &next_states) const
{
   if (abs_annots == 0)
      return;
   if (list<CALFAbsAnnot *> * annot_list = abs_annots->GetStmtExitALFAbsAnnot(const_cast<AStmt *>(stmt))) {
      for (vector<State *>::iterator si = next_states.begin(), sn = next_states.end(); si != sn; ++si)
      {
         for (list<CALFAbsAnnot *>::const_iterator ai = annot_list->begin(),
              an = annot_list->end(); ai != an; ++ai)
         {
            UpdateStateAccordingToAnnot(*si, *ai);
         }
      }
   }
}

void AlfVM::UpdateStateAccordingToAnnot(State * state, CALFAbsAnnot * annot) const
{
      // Get the program and the scope in which the stmt is positioned. Scope
      // statements are positioned in their surrounding scopes.
   
   const alf::CAlfTuple * ast = dynamic_cast<const alf::CAlfTuple*>(state->GetProgram());
   const alf::CScopeTuple * scope = GetScope(state, ast);
   const CSymTabBase * symbol_table = state->GetProgramCounter()->GetProgram()->GetSymTab();
   
   typedef list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > VarValPairList;
   VarValPairList * var_vals_pairs = annot->GetModifyableVarValsList();
   
      // The following vector holds the information if updates are direct (true) or via a pointer (false)
      // The vector is a parallel structure to the var_vals_pairs
   vector<bool> direct_updates;
      // The following vector holds the information if updates are concrete (true => ASSIGN) or abstract (false => LUB)
      // The vector is a parallel structure to the var_vals_pairs
   vector<bool> concrete_pointers;
   
   int listsize = (int)var_vals_pairs->size();
   
   int var_list_pos = 0;
   bool concrete_pointer = true;
   bool direct_update = true;
   while (var_list_pos < listsize) {
      concrete_pointers.push_back(concrete_pointer);
      direct_updates.push_back(direct_update);
      var_list_pos++;
   }
   
      // Go through the parallel de-referencing updates and create concrete updates
      // Add them to the end of the list
      // Do not perform any updates yet
   
      // Position in var list
   var_list_pos = 0;
   
   VarValPairList::iterator v = var_vals_pairs->begin();
   vector<bool>::iterator c = concrete_pointers.begin();
   vector<bool>::iterator d = direct_updates.begin();
   
   while (var_list_pos < listsize) {
      CALFAbsAnnotVar * var = v->first;
         // Some variables
      concrete_pointer = true;
      direct_update = true;
      string frame_id;
      Size frame_size;
      unsigned int key;
      
         // A structure where to store symbols and offsets
         // The position in the list corresponds to the dereferencing level
      
      typedef std::vector< SymbolOffsetPairColl > SymbolsAndOffsets;
      
      SymbolsAndOffsets symbols_and_offsets;
      int no_of_derefs = var->GetNoOfDerefs();
      assert(no_of_derefs >= 0);
      
      if (no_of_derefs > 0) {
         
         direct_update = false;
         
            // Make the initial points-to set
            // Get the frame id pointed to using the annotation
         unique_ptr<Value> base_addr(state->Lookup(var->GetKey(), cshack));
         Integer offset_val(var->HasFOffs() ? LAU::BitsToLAU(var->FOffsInBits()) : 0);
         unique_ptr<Value> offset(domain->GetIntegerDomain()->CreateInteger(base_addr->SizeInBits(), offset_val));
         unique_ptr<Value> address(domain->GetMemoryDomain()->CreatePointer(base_addr.get(), offset.get()));
            // Get the size of the pointer from the annotation
         Size value_size = var->PSize(0);
            // Get the pointer
         unique_ptr<Value> value(state->GetMemory()->Load(address.get(), value_size));
         assert(!value->IsBottom());
         const SymbPointer * pointer = value.get()->AsSymbPointer();
         assert(!pointer->IsTopSymbPointer());
         
            // Store base pointer in list
         symbols_and_offsets.resize(1);
         symbols_and_offsets.front().clear();
         pointer->GetSymbolOffsetPairs(symbols_and_offsets.front());
         
         if (symbols_and_offsets.front().size() > 1)
            concrete_pointer = false;
         
         if (no_of_derefs > 1) {
            symbols_and_offsets.resize(no_of_derefs);
            
               // De-reference a number of times
            for (int deref_level = 0; deref_level < no_of_derefs-1; ++deref_level) {
                  // if (!last (highest) level)
                  // Add new SymbolOffsetPairColl's in the symbols_and_offsets[no_of_deref], i.e. this level
                  // Loop through the symbols and offset sets on no_of_deref level
               for (SymbolOffsetPairColl::iterator sop = symbols_and_offsets.at(deref_level).begin();
                    sop != symbols_and_offsets.at(deref_level).end(); sop++) {
                  
                  frame_id = (*sop).GetSymbol().GetAnnot();
                  if (!(annot->DeclaresFRefIdInCurrentOrParentScopesOrGlobalScopeOrImports(ast, scope, frame_id, &frame_size, &key)))
                     assert(false); // must be found
                  
                     // Get the frame id pointed to using the annotation
                  unique_ptr<Value> base_addr(state->Lookup(key, cshack));
                  Integer offset_val((*sop).GetOffset());
                  unique_ptr<Value> offset(domain->GetIntegerDomain()->CreateInteger(base_addr->SizeInBits(), offset_val));
                  unique_ptr<Value> address(domain->GetMemoryDomain()->CreatePointer(base_addr.get(), offset.get()));
                     // Get the size of the pointer from the annotation
                  Size value_size = var->PSize(deref_level+1);
                  unique_ptr<Value> value(state->GetMemory()->Load(address.get(), value_size));
                  assert(!value->IsBottom());
                  
                  const SymbPointer * p = value.get()->AsSymbPointer();
                  if (p == NULL) {
                     stringstream ss;
                     ss << "The variable " << frame_id << " must be a pointer";
                     throw runtime_error(ss.str());
                  }
                  SymbolOffsetPairColl * sopcoll = new SymbolOffsetPairColl;
                  p->GetSymbolOffsetPairs(*sopcoll);
                  
                  if (sopcoll->size() > 1)
                     concrete_pointer = false;
                  
                  std::pair<SymbolOffsetPairColl::iterator,bool> ret;
                  for (SymbolOffsetPairColl::iterator it = sopcoll->begin(); it != sopcoll->end(); it++) {
                        // Store
                     ret = symbols_and_offsets.at(deref_level+1).insert(*it);
                     if (ret.second == false) {
                        stringstream ss;
                        ss << "The pointer: " << frame_id << ", with value " << *p << ", has a duplicate in the annotation";
                        throw runtime_error(ss.str());
                     }
                  }
                  delete sopcoll;
               }
            }
         }
            // else
            // On the last (highest) level, put new annotations at the end
         for (SymbolOffsetPairColl::iterator sop = symbols_and_offsets.at(no_of_derefs-1).begin();
              sop != symbols_and_offsets.at(no_of_derefs-1).end(); sop++) {
            assert (annot->DeclaresFRefIdInCurrentOrParentScopesOrGlobalScopeOrImports(ast, scope, (*sop).GetSymbol().GetAnnot(), &frame_size, &key));
            CALFAbsAnnotVar * new_var = var->Copy();
            new_var->SetFRefId(sop->GetSymbol().GetAnnot());
            new_var->SetFOffsInBits(LAU::LAUToBits(sop->GetOffset())); // Conversion necessary
            new_var->SetKey(key);
            new_var->SetNoOfDerefs(0);
            CALFAbsAnnotVal * val = v->second->front()->Copy();
            list<CALFAbsAnnotVal *> * val_list = new list<CALFAbsAnnotVal *>;
            val_list->push_back(val);
            pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> * new_var_vals = new pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *>(new_var, val_list);
            var_vals_pairs->push_back(*new_var_vals);
               // Store the information about the pointer
            concrete_pointers.push_back(concrete_pointer);
               // Store the information about the assignment
            direct_updates.push_back(direct_update);
         }
         v = var_vals_pairs->erase(v);
         c = concrete_pointers.erase(c);
         d = direct_updates.erase(d);
      } else {
         v++; c++; d++;
      }
      var_list_pos++;
   }
   
   var_vals_pairs = annot->GetModifyableVarValsList();
   
      // Create interval set "targets" which holds a set of <frame, bit_intervals> for each parallel annotation
   Targets targets;
   
      // Position in var list
   var_list_pos = 0;
   
      // Check for overlap with other parallel annotations
   bool overlap = false;
   
   for (VarValPairList::const_iterator v = var_vals_pairs->begin(); v != var_vals_pairs->end(); ++v, ++var_list_pos) {
      
         // Clear targets for this parallel annotation
      targets.clear();
      
         // No items with de-reference should be left in the list
      CALFAbsAnnotVar * var = v->first;
      assert(var->GetNoOfDerefs() == 0);
      
         // Get the size
      Size value_size;
      if (var->HasSize()) {
         value_size = var->SizeInBits();
      }
      else
         {     // If no size was specified in the annotation, we must go to the symbol
               // table and find out the size of the allocated frame and use this as size
            const CSymTabIdentifier * st_id = symbol_table->Lookup(var->GetKey())->GetIdentifier();
            const CAllocTuple * alloc = &dynamic_cast<const CAllocTuple &>(*st_id);
            value_size = alloc->GetFrameSize()->GetSizeInBits();
         }
      
         // Check that we do not try to store something outside the frame border
      const CSymTabIdentifier * st_id = symbol_table->Lookup(var->GetKey())->GetIdentifier();
      const CAllocTuple * alloc = &dynamic_cast<const CAllocTuple &>(*st_id);
      Size frame_size = alloc->GetFrameSize()->GetSizeInBits();
      
      if ((var->FOffsInBits() + (value_size * var->Repeat()) - 1) > frame_size) {
         stringstream s;
         s << "ERROR: abstract annotation: " << endl << *var << endl
         << "needs storage exeeding size allocated in global declaration " << endl;
         throw runtime_error(s.str());
      }
         // Check that we store the value on even LAUs
      if (var->HasFOffs() &&
          LAU::BitsToLAURoundUp(var->FOffsInBits()) != LAU::BitsToLAURoundDown(var->FOffsInBits())) {
         stringstream s;
         s << "ERROR: start address to store value at in abstract annotation: " << endl
         << *var << endl << "is not evenly dividable with LAU size " << endl;
         throw runtime_error(s.str());
      }
      
         // Prepare target info
         // Targets are the destination (frame id and bits interval) for the annotation
      string frame_id = var->FRefId();
      EInt<long long> low = var->FOffsInBits();
      EInt<long long> up = var->FOffsInBits() + value_size * var->Repeat() - 1;
      
      if (targets.find(frame_id) == targets.end()) {
         
            // Not there, add it and the bit interval
         BitIntervalLimits lower_limits;
         BitIntervalLimits upper_limits;
         lower_limits.push_back(low);
         upper_limits.push_back(up);
         BitIntervals intervals = make_pair(lower_limits, upper_limits);
         targets.insert(make_pair(frame_id, intervals));
         
      } else {
         
            // Frame id exists
         BitIntervalLimits * lower_limits = &(targets.at(frame_id).first);
         BitIntervalLimits * upper_limits = &(targets.at(frame_id).second);
         BitIntervalLimits::iterator l_llow, l_ulow, u_llow, u_ulow;
         l_llow = std::lower_bound (lower_limits->begin(), lower_limits->end(), low);
         int l_llow_index = int(l_llow - lower_limits->begin());
         u_llow = std::upper_bound (lower_limits->begin(), lower_limits->end(), low);
         
         BitIntervalLimits::iterator l_lup, l_uup, u_lup, u_uup;
         l_uup = std::lower_bound (upper_limits->begin(), upper_limits->end(), up);
         int l_uup_index = int(l_uup - upper_limits->begin());
         
         if (upper_limits->size() == 1) {
            
               // Only one interval
            assert(l_llow_index == l_uup_index);
            
            if (up < lower_limits->at(0)-1) { // put first
               
               lower_limits->insert(lower_limits->begin(), low);
               upper_limits->insert(upper_limits->begin(), up);
               
            } else if (low > upper_limits->at(0)+1) { // put last
               lower_limits->push_back(low);
               upper_limits->push_back(up);
               
            } else { // merge
               
                  // Calculate  min and max
               EInt<long long> min, max;
               if (lower_limits->at(0) < low)
                  min = lower_limits->at(0);
               else
                  min = low;
               if (upper_limits->at(0) > up)
                  max = upper_limits->at(0);
               else
                  max = up;
               
               lower_limits->at(0) = min;
               upper_limits->at(0) = max;
            }
            
         } else // more than one interval
            
            if (up < *lower_limits->begin()-1) { // put first
               
               lower_limits->insert(lower_limits->begin(), low);
               upper_limits->insert(upper_limits->begin(), up);
               
            } else if (low > upper_limits->at(upper_limits->size()-1)+1) { // put last
               
               lower_limits->push_back(low);
               upper_limits->push_back(up);
               
            } else if (l_llow_index == l_uup_index &&
                       low > upper_limits->at(l_llow_index-1)+1 &&
                       up < lower_limits->at(l_uup_index)-1) { // inbetween two intervals
               
               lower_limits->insert(l_llow, low);
               upper_limits->insert(l_uup, up);
               
            } else { // overlaps
               
               bool attach_lower;
               if (l_llow_index > 0)
                  attach_lower = low <= upper_limits->at(l_llow_index-1)+1;
               else
                  attach_lower = false;
               bool attach_upper = up >= lower_limits->at(l_uup_index)-1;
               
               int start_interval_for_removal, end_interval_for_removal;
               if (attach_lower) {
                  start_interval_for_removal = l_llow_index-1;
               } else {
                  start_interval_for_removal = l_llow_index;
               }
               if (attach_upper) {
                  end_interval_for_removal = l_uup_index;
               } else {
                  end_interval_for_removal = l_uup_index-1;
               }
               
               int no_of_intervals_to_remove = end_interval_for_removal-start_interval_for_removal+1;
               
               BitIntervalLimits::iterator l_it = lower_limits->begin(), u_it = upper_limits->begin();
               for (int k = 0; k < end_interval_for_removal; k++) {
                  l_it++, u_it++; // step up to the last interval to remove
               }
               
                  // Calculate new min and max
               EInt<long long> new_min, new_max;
               if (lower_limits->at(start_interval_for_removal) < low)
                  new_min = lower_limits->at(start_interval_for_removal);
               else
                  new_min = low;
               if (upper_limits->at(end_interval_for_removal) > up)
                  new_max = upper_limits->at(end_interval_for_removal);
               else
                  new_max = up;
               
               for (int i = 1; i <= no_of_intervals_to_remove; i++, l_it--, u_it--) {
                  lower_limits->erase(l_it);
                  upper_limits->erase(u_it);
               }
               
               BitIntervalLimits::iterator l, u;
               l = l_it;
               u = u_it;
               if (++l == lower_limits->begin()) {
                  lower_limits->insert(lower_limits->begin(), new_min);
                  upper_limits->insert(upper_limits->begin(), new_max);
               }
               else if (++u == upper_limits->end()) {
                  lower_limits->push_back(new_min);
                  upper_limits->push_back(new_max);
               }
               else {
                  lower_limits->insert(++l_it, new_min);
                  upper_limits->insert(++u_it, new_max);
               }
            }
      }
      
      BitIntervalLimits * lower_limits = &(targets.at(frame_id).first);
      BitIntervalLimits * upper_limits = &(targets.at(frame_id).second);
      
         // Check that the limits intervals are correct
      for (int i = 0; i < (int)lower_limits->size(); i++) {
         if (i > 0 && i < (int)lower_limits->size()-1)
            assert(lower_limits->at(i-1) < lower_limits->at(i) && upper_limits->at(i-1) < upper_limits->at(i));
      }
      (void)upper_limits; // to silence warning in Release builds
      
         // Create an abstract value from the val part of the annotation
         // For now, only (merged) single values are accepted
      if(v->second->size() != 1) {
         stringstream s;
         s << "Only single values are accepted in annotations - the OR construct is not implemented";
         throw runtime_error(s.str());
      }
      CALFAbsAnnotVal * val = v->second->front();
      unique_ptr<Value> annot_value;
      switch (val->Type())
      {
         case CALFAbsAnnotVal::TOP:
         {
         assert (val->IsTOP());
         annot_value.reset(domain->CreateTopValue(value_size));
         break;
         }
         case CALFAbsAnnotVal::INT:
         {
         CALFAbsAnnotValInt * val_ = static_cast<CALFAbsAnnotValInt *>(val);
         if (val->IsTOP_INT())
            annot_value.reset(domain->GetIntegerDomain()->CreateInteger(value_size));
         else
            annot_value.reset(domain->GetIntegerDomain()->CreateInteger(value_size,
                                                                        Integer(val_->ILow()), Integer(val_->IUpp())));
         break;
         }
         case CALFAbsAnnotVal::FLOAT:
         {
         CALFAbsAnnotValFloat * val_ = static_cast<CALFAbsAnnotValFloat *>(val);
            // Here we just check for the two standard float
            // sizes. If another size is given we will currently
            // report an error since we do not know how many bits
            // the exponent and fraction should be holding. Later
            // we should add the possibility to add floating point
            // exponent and fraction sizes to floats in annots.
         bool incl_NaNaNs = true;
         bool incl_NaN = false;
         if(value_size == 32) {
            Size exp_size(8);
            Size frac_size(23);
            if (val->IsTOP_FLOAT()) {
               annot_value.reset(domain->GetFloatDomain()->CreateFloat(exp_size, frac_size));
            }
            else {
               annot_value.reset(domain->GetFloatDomain()->CreateFloat(exp_size, frac_size,
                                                                       incl_NaNaNs, incl_NaN, val_->FLow(), val_->FUpp()));
            }
         }
         else if (value_size == 64) {
            Size exp_size(11);
            Size frac_size(52);
            if (val->IsTOP_FLOAT())
               annot_value.reset(domain->GetFloatDomain()->CreateFloat(exp_size, frac_size));
            else
               annot_value.reset(domain->GetFloatDomain()->CreateFloat(exp_size, frac_size,
                                                                       incl_NaNaNs, incl_NaN, val_->FLow(), val_->FUpp()));
         }
         else {
            stringstream s;
            s << "Cannot create abstract float of size "  << value_size << " since we cannot determine exponent and fraction size";
            throw runtime_error(s.str());
         }
         break;
         }
         case CALFAbsAnnotVal::ADDRESS:
         {
         if (direct_updates.at(var_list_pos) == false) {
            stringstream s;
            s << "We don't support annotations that update pointers through pointers";
            throw runtime_error(s.str());
         }
         
         if (val->IsTOP_ADDRESS())
            annot_value.reset(domain->GetMemoryDomain()->CreatePointer(value_size));
         else {
            CALFAbsAnnotValAddress * val_ = static_cast<CALFAbsAnnotValAddress *>(val);            
            const list<CFRefIdOffsetPair *> * iops = val_->FRefIdOffsetPairList();
               // The initial annot_value is bottom
            annot_value.reset( domain->CreateBottomValue(value_size) );
               // A zero carry used in the loop below
            unique_ptr<Value> zero_carry( domain->GetIntegerDomain()->CreateInteger(1, 0) );
            
               // For each CFRefIdOffsetPair: get the base address, add the offset to it, and LUB with the previous annot_value
            for (list<CFRefIdOffsetPair *>::const_iterator i = iops->begin(), i_end = iops->end(); i != i_end; ++i)
               {
               unique_ptr<Value> base_addr(state->Lookup((*i)->Key(), cshack));
               unique_ptr<Value> offset(domain->GetIntegerDomain()->CreateInteger(value_size,
                                                                                Integer(LAU::BitsToLAU((*i)->Offset_L())),
                                                                                Integer(LAU::BitsToLAU((*i)->Offset_U()))));
               base_addr.reset( base_addr->Add(offset.get(), zero_carry.get()) );
               annot_value.reset( annot_value->LUB(base_addr.get()) );
               }
         }
         break;
         }
         case CALFAbsAnnotVal::LABEL:
         {
         if (val->IsTOP_LABEL())
            annot_value.reset(domain->GetMemoryDomain()->CreatePointer(value_size));
         else {
            CALFAbsAnnotValLabel * val_ = static_cast<CALFAbsAnnotValLabel *>(val);
            const list<CLRefIdOffsetPair *> * lops = val_->LRefIdOffsetPairList();
            
               // Create an symbol-offset map from the CLRefIdOffsetPair list
            SymbolToOffset sto;
            for (list<CLRefIdOffsetPair *>::const_iterator lop = lops->begin();
                 lop != lops->end(); ++lop)
               {
               Symbol symbol((*lop)->Key(), 1);
               symbol.SetAnnot((*lop)->LRefId());
               unique_ptr<Value> offset(domain->GetIntegerDomain()->CreateInteger(value_size, 0));
               sto.insert(make_pair(symbol, offset.release()));
               }
            annot_value.reset(domain->GetMemoryDomain()->CreatePointer(value_size, sto));
         }
         }
         break;
      }
         // Get some information from the var part of the annotation
      unique_ptr<Value> base_addr(state->Lookup(var->GetKey(), cshack));
      Integer offset_val(var->HasFOffs() ? LAU::BitsToLAU(var->FOffsInBits()) : 0);
      Integer var_size_in_bits(value_size.AsBaseIntType());
      
         // For each iteration we add the var size (offs_incr) to the offset. However, if
         // the nr of repeats is 1, a var size should be allowed that is not evenly divisible by
         // the current LAU, so then we set offs_incr to the dummy value 0.
      uint32_t repeats = (uint32_t)var->Repeat();
      Integer offs_incr(0);
      if (repeats > 1) offs_incr = LAU::BitsToLAU(var_size_in_bits);
      for(uint32_t current_repeat = 0; current_repeat < repeats; current_repeat++, offset_val += offs_incr) {
            // Derive the address where the value should be stored
         unique_ptr<Value> offset(domain->GetIntegerDomain()->CreateInteger(base_addr->SizeInBits(), offset_val));
         unique_ptr<Value> address(domain->GetMemoryDomain()->CreatePointer(base_addr.get(), offset.get()));
         
            // Store the value according to the annotation type
         CALFAbsAnnot::UpdateType type = annot->Type();
            // Note that for abstract pointers, LUB should be used
         
         if (concrete_pointers.at(var_list_pos) == false)
            type = CALFAbsAnnot::LUB;
         
         switch (type)
         {
            case CALFAbsAnnot::ASSIGN:
            {
            state->GetMemory()->Store(address.get(), annot_value.get(), true);
            break;
            }
            case CALFAbsAnnot::GLB:
            {
            unique_ptr<Value> previous(state->GetMemory()->Load(address.get(), value_size));
            unique_ptr<Value> glb(previous->GLB(annot_value.get()));
            state->GetMemory()->Store(address.get(), glb.get(), true);
            break;
            }
            case CALFAbsAnnot::LUB:
            {
            unique_ptr<Value> previous(state->GetMemory()->Load(address.get(), value_size));
            unique_ptr<Value> lub(previous->LUB(annot_value.get()));
            state->GetMemory()->Store(address.get(), lub.get(), true);
            break;
            }
         }
      }
      
/*
      cout << "targets:" << endl;
      
      for (Targets::iterator it = targets.begin(); it != targets.end(); it++) {
         
         cout << it->first << endl;
         for (int j=0; j < (int)it->second.first.size(); j++) {
            cout << "bits: " << it->second.first.at(j) << " to " << it->second.second.at(j) << endl;
         }
      }
 */
      for (Targets::iterator it = targets.begin(); it != targets.end(); it++) {
         
         if (global_targets->find(it->first) == global_targets->end()) {
            
               // Not there, add it and the bit interval
            global_targets->insert(*it);
            overlap = false;
            
         } else {
            
            string frame_id = targets.find(it->first)->first;
            
            BitIntervalLimits * lower_limits = &(global_targets->at(frame_id).first);
            BitIntervalLimits * upper_limits = &(global_targets->at(frame_id).second);
            
            for (int i = 0; i < (int)lower_limits->size(); i++) {
               EInt<long long> low = lower_limits->at(i);
               EInt<long long> up = upper_limits->at(i);
               BitIntervalLimits::iterator l_llow, l_ulow, u_llow, u_ulow;
               l_llow = lower_bound(lower_limits->begin(), lower_limits->end(), low);
               int l_llow_index = int(l_llow - lower_limits->begin());
               u_llow = std::upper_bound(lower_limits->begin(), lower_limits->end(), low);
               
               BitIntervalLimits::iterator l_lup, l_uup, u_lup, u_uup;
               l_uup = lower_bound(upper_limits->begin(), upper_limits->end(), up);
               int l_uup_index = int(l_uup - upper_limits->begin());
               
               if (upper_limits->size() == 1) {
                  
                     // Only one interval
                  assert(l_llow_index == l_uup_index);
                  
                  if (up < lower_limits->at(0)-1) { // put first
                     
                     lower_limits->insert(lower_limits->begin(), low);
                     upper_limits->insert(upper_limits->begin(), up);
                     
                  } else if (low > upper_limits->at(0)+1) { // put last
                     
                     lower_limits->push_back(low);
                     upper_limits->push_back(up);
                     
                  } else { // overlap
                     overlap = true;
                  }
                  
               } else // more than one interval
                  if (up < *lower_limits->begin()-1) { // put first
                     
                     lower_limits->insert(lower_limits->begin(), low);
                     upper_limits->insert(upper_limits->begin(), up);
                     
                  } else if (low > upper_limits->at(upper_limits->size()-1)+1) { // put last
                     
                     lower_limits->push_back(low);
                     upper_limits->push_back(up);
                     
                  } else if (l_llow_index == l_uup_index &&
                             low > upper_limits->at(l_llow_index-1)+1 &&
                             up < lower_limits->at(l_uup_index)-1) { // inbetween two intervals
                     
                     lower_limits->insert(l_llow, low);
                     upper_limits->insert(l_uup, up);
                     
                  } else { // overlaps
                     overlap = true;
                  }
            }
         }
      }
      if (overlap) {
         stringstream s;
         s << "The target(s):" << endl;
         for (Targets::iterator it = targets.begin(); it != targets.end(); it++) {
            s << it->first << endl;
            for (int j=0; j < (int)it->second.first.size(); j++) {
               s << "bits: " << it->second.first.at(j) << " to " << it->second.second.at(j) << endl;
            }
         }
         s << "of the annotation with type:" << endl;
         if (annot->Type() == CALFAbsAnnot::ASSIGN) s << "CALFAbsAnnot::ASSIGN" << endl;
         if (annot->Type() == CALFAbsAnnot::GLB) s << "CALFAbsAnnot::GLB" << endl;
         if (annot->Type() == CALFAbsAnnot::LUB) s << "CALFAbsAnnot::LUB" << endl;
         s << "at:" << endl << *annot->Position() << endl;
         s << "may overlap with other parallel assigments of the same annotation";
         throw runtime_error(s.str());
      }
   }

/*
   cout << "global_targets:" << endl;
   
   for (Targets::iterator it = global_targets->begin(); it != global_targets->end(); it++) {
      
      cout << it->first << endl;
      for (int j=0; j < (int)it->second.first.size(); j++) {
         cout << "bits: " << it->second.first.at(j) << " to " << it->second.second.at(j) << endl;
      }
   }
*/
   
      // Clear global targets (since we accept overlaps between different annotations)
   global_targets->clear();
}
