#ifndef ALFVMINTERDEBUGGER_H_INCLUDED
#define ALFVMINTERDEBUGGER_H_INCLUDED

#include "AlfVMDebugger.h"
#include "tools/SignalHandling.h"
#include "program/CGenericStmt.h"
#include <vector>
#include <string>
#include <stdexcept>
#include <ostream>

class AlfVMInterDebugger;
class State;
template <typename> class AEStrategy;

/** Base class for all ALF AE debugger states */
class InterDebuggerState
{
public:
   virtual ~InterDebuggerState() {}

   /** Activate this state. Should be called before entering the state. */
   virtual void Activate() {}

   /** Deactivate this state. Should be called before leaving the state. */
   virtual void Deactivate() {}

   /** Show the debugger prompt (it depends on the state whether a prompt
      is actually shown) */
   virtual bool Prompt(const alf::AStmt * stmt, const State * state,
                       AlfVMInterDebugger & debugger) = 0;

   /** @copydoc AlfVMInterDebugger::RecordPerformedMerge(const State&,const State&,const State&) */
   virtual void RecordPerformedMerge(const State & a, const State & b,
                                     const State & merged) = 0;

   /** @copydoc AlfVMInterDebugger::HandleInterrupt() */
   virtual void HandleInterrupt(AlfVMInterDebugger & debugger);
};

/** Debugger state in which the AE proceeds running and breaks at breakpoints */
class Proceed : public InterDebuggerState
{
public:
   /** @copydoc InterDebuggerState::Prompt(const alf::AStmt*,const State*,AlfVMInterDebugger&) */
   virtual bool Prompt(const alf::AStmt * stmt, const State * state,
                       AlfVMInterDebugger & debugger);

   /** @copydoc InterDebuggerState::RecordPerformedMerge(const State&,const State&,const State&) */
   virtual void RecordPerformedMerge(const State & a, const State & b,
                                     const State & merged) {}

   /** Add a breakpoint at line @p line_nr */
   void AddBreakpoint(int line_nr) {breakpoints.insert(line_nr);}

   /** Add a breakpoint that breaks on all statements of type @p stmt_type */
   void AddStmtTypeBP(CGenericStmt::GS_TYPE stmt_type) { stmt_type_bps.insert(stmt_type); }

   /** Clear all breakpoints */
   void ClearBreakpoints() { breakpoints.clear(); stmt_type_bps.clear(); }

private:
   /** Set of breakpoints on line numbers */
   std::set<int> breakpoints;

   /** Set of breakpoints on statement types */
   std::set<CGenericStmt::GS_TYPE> stmt_type_bps;
};

/** Debugger state in which commands are accepted from the user */
class AcceptCommands : public InterDebuggerState
{
public:
   /** Base class for all debugger commands. Subclasses are defined in AlfVMInterDebugger.cpp. */
   class Command
   {
   public:
      virtual ~Command() {}

      /** Returns 0 if the command name in @a command_line does not match LongName() or ShortName() (i.e.\ another
         command was intended), 1 if the command was carried out successfully, and -1 if the command failed. */
      virtual int CarryOut(const std::vector<std::string> & command_line,
                           const alf::AStmt * stmt, const State * state,
                           AlfVMInterDebugger & debugger) = 0;

      virtual const char * LongName() const = 0;

      virtual const char * ShortName() const = 0;

      virtual const char * Description() const = 0;

   protected:
      static bool CheckCommandLine(const std::vector<std::string> & command_line, 
         const std::string & long_cmd_name, const std::string& short_cmd_name, int nr_arguments);
   };

   /** Exception class for failed commands */
   class FailedCommand : public std::runtime_error
   {
   public:
      FailedCommand(const std::string & message)
         : std::runtime_error(message) {}
   };

   AcceptCommands(Proceed & proceed_state, const AEStrategy<State> & ae_strategy);

   virtual ~AcceptCommands();

   /** @copydoc InterDebuggerState::Prompt(const alf::AStmt*,const State*,AlfVMInterDebugger&) */
   virtual bool Prompt(const alf::AStmt * stmt, const State * state,
                       AlfVMInterDebugger & debugger);

   /** @copydoc InterDebuggerState::RecordPerformedMerge(const State&,const State&,const State&) */
   virtual void RecordPerformedMerge(const State & a, const State & b,
                                     const State & merged);

   /** @copydoc InterDebuggerState::(AlfVMInterDebugger&) */
   virtual void HandleInterrupt(AlfVMInterDebugger & debugger);

private:
   std::vector<Command *> commands;

   bool CarryOutCommand(const std::vector<std::string> & command_line, 
                        const alf::AStmt * stmt, const State * state,
                        AlfVMInterDebugger & debugger);
};

/** Debugger state that works like proceed, except the height of the call stack
   is monitored during the execution */
class MonitorStackHeight : public Proceed
{
private:
   int min_height, max_height;

public:
   /* @copydoc Proceed::Activate() */
   virtual void Activate();

   /* @copydoc Proceed::Deactivate() */
   virtual void Deactivate();

   /** @copydoc Proceed::Prompt(const alf::AStmt*,const State*,AlfVMInterDebugger&) */
   virtual bool Prompt(const alf::AStmt * stmt, const State * state,
                       AlfVMInterDebugger & debugger);
};

/** Interactive ALF AE debugger */
class AlfVMInterDebugger : public AlfVMDebugger
{
   // States
   friend class InterDebuggerState;
   friend class Proceed;

   // Commands
   friend class Resume;
   friend class StepCommand;
   friend class StartMonitoringStackHeight;

public:
   AlfVMInterDebugger(const AEStrategy<State> & ae_strategy);

   /** @name Functions for reporting events and results to the debugger */
   ///@{
   virtual void ExprEvalEnabled(bool enabled) {}

   virtual void Statement(const alf::AStmt * stmt, const State * state);

   virtual void StatementFinished(std::vector<State *> & updated_states) {}

   virtual void NullStatement(const alf::CNullStmtTuple * stmt) {}

   virtual void StoreStatement(const alf::CStoreStmtTuple * stmt) {}

   virtual void StoredValue(const Value * value) {}

   virtual void StoredToAddress(const Value * value) {}

   virtual void JumpStatement(const alf::CJumpStmtTuple * stmt) {}

   virtual void JumpedToPP(const ProgramPoint * program_point) {}

   virtual void SwitchStatement(const alf::CSwitchStmtTuple * stmt) {}

   virtual void EvaledSwitchExpr(const Value * value) {}

   virtual void BranchIntValue(const alf::CIntNumValTuple * value) {}

   virtual void FollowBranch(const ProgramPoint * jumped_to) {}

   virtual void DoNotFollowBranch() {}

   virtual void FollowFallThroughBranch(const ProgramPoint * jumped_to) {}

   virtual void DoNotFollowFallThroughBranch() {}

   virtual void RestrictedState(RestrictedALFState * restr_alf_state) {}

   virtual void Restrict(const alf::AExpr * expr, const Value * r) {}

   virtual void CallStatement(const alf::CCallStmtTuple * stmt) {}
   virtual void CalledFunction(const alf::CFuncTuple * function) {}
   virtual void FuncArgument(const Value * value) {}
   virtual void FuncRetValAddr(const Value * value) {}

   virtual void ReturnStatement(const alf::CReturnStmtTuple * stmt) {}
   virtual void ReturnedValue(const Value * value, const Value * address) {}
   virtual void ReturnedToPP(const ProgramPoint * program_point) {}

   virtual void FreeStatement(const alf::CFreeStmtTuple * stmt) {}
   virtual void FreedFrameRef(const Value * fref) {}

   virtual void EvalExpr(const alf::AExpr * expr) {}
   virtual void ResultFromEval(const Value * value) {}
   virtual void EvalOperand() {}

   /** Record that a merge has been performed between states @p a and @p b,
      which resulted in the state @p merged */
   virtual void RecordPerformedMerge(const State & a, const State & b,
                                     const State & merged);
   ///@}

   static std::ostream & PrintStmtCoord(const alf::AStmt & stmt, std::ostream & o);

private:
   /** Handler for SIGINT signals */
   class SIGINTHandler : public SignalHandling::Handler
   {
   public:
      SIGINTHandler(AlfVMInterDebugger * debugger)
         : debugger(debugger) {}

      virtual void operator()(int parameter);
   private:
      AlfVMInterDebugger * debugger;
   };

   /** @name Debugger states
      Only one debugger state is active at a time. */
   ///${
   Proceed proceed_state;
   AcceptCommands acc_comms_state;
   MonitorStackHeight monit_sh_state;
   InterDebuggerState * state;
   ///@}

   SIGINTHandler sigint_handler;
   
   /** @name Functions for changing the debugger state */
   ///@{
   void ChangeState(InterDebuggerState * new_state);

   void ChangeStateToProceed() {ChangeState(&proceed_state);}

   void ChangeStateToAcceptCommands() {ChangeState(&acc_comms_state);}

   void ChangeStateToMonitorStackHeight() {ChangeState(&monit_sh_state);}
   ///$}

   /** Handle a SIGINT signal */
   void HandleInterrupt();
};

#endif   // ifndef ALFVMINTERDEBUGGER_H_INCLUDED
