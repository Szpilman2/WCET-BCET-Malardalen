#ifndef ENDIANNESS_H_INCLUDED
#define ENDIANNESS_H_INCLUDED

#include <utility>
#include <cassert>
#include <ostream>
#include "tools/EInt.h"

/** Represents an endianness setting (little or big) */
class Endianness
{
public:
   static Endianness Little() {return Endianness(0);}
   static Endianness Big() {return Endianness(1);}

   bool operator ==(const Endianness & other) const {return this->_little_or_big == other._little_or_big;}
   bool operator !=(const Endianness & other) const {return this->_little_or_big != other._little_or_big;}

   /** Select the subrange [l,u) from the range of bit positions [lf,uf), according to the 
       endianness. l and u specify a subrange such that l >= 0 && u <= (uf - lf).
       For example, with little endian: Select(1, 4, 10, 14) = (10 + 1, 10 + 4) = (11, 14), 
       while with big endian: Select(1, 4, 10, 14) = (14 - 4, 14 - 1) = (10, 13).
       @note All ranges are specified such that the upper bound is not actually included in the range */
   template <typename T> std::pair<T, T> Select(const T & l, const T & u, const T & lf, const T & uf) const;

   /** The same as Select, except the computed subrange of bit positions are returned through 
      @a l_from and @a u_from instead of using a return value */
   template <typename T> void Select2(const EInt<T>& l, const EInt<T>& u, EInt<T>& l_from, EInt<T>& u_from) const;

   std::ostream & Print(std::ostream & os) const
   {
      return os << (*this == Little()? "Little" : "Big");
   }

private:
   unsigned char _little_or_big;
   Endianness(unsigned char little_or_big) : _little_or_big(little_or_big) {}
};

template <typename T> std::pair<T, T> Endianness::Select(const T & l, const T & u, const T & lf, const T & uf) const
{
   assert(l >= 0 && u <= uf - lf && l < u);

   if (*this == Little())
      return std::make_pair(lf + l, lf + u);
   else
      return std::make_pair(uf - u, uf - l);
}

template <typename T> void Endianness::Select2(const EInt<T>& l, const EInt<T>& u, EInt<T>& l_from, EInt<T>& u_from) const
{
   assert(l >= 0 && u <= u_from - l_from && l < u);
   switch (_little_or_big)
   {
   case 0:
      u_from = l_from + u;
      l_from += l;
      return;
   case 1:
      l_from = u_from - u;
      u_from -= l;
      return;
   }
}

inline std::ostream & operator <<(std::ostream & os, const Endianness & endianness) {return endianness.Print(os);}

#endif   // ENDIANNESS_H_INCLUDED
