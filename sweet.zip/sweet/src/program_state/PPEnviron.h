#ifndef PPENVIRON_H_INCLUDED
#define PPENVIRON_H_INCLUDED

#include <map>
#include <vector>
#include <string>
#include <cassert>
#include <memory>
#include <utility>
#include <algorithm>

// Forward declarations ------------------------------------------------

class ProgramPointECFG;
class Value;

namespace alf
{
   class CAlfTuple;
   class AStmt;
   class CStmtList;
   class CFuncTuple;
}

/** Program point environment. Maps abstract addresses to program points. */
class PPEnviron
{
public:
   /** Represents the result of performing a function lookup. It comes in two variants:
       defined and undefined. Defined functions are
       regular functions, and for these the CFuncTuple and the ProgramPointECFG can be
       retrieved. Undefined functions are functions whose existence are only declared
       in the imports section of the ALF program. These can be returned from the lookup
       so that an appropriate action can be taken when a call to such a function is made. */
   class LookedUpFunction
   {
   public:
      /** Create a defined looked-up function
          @note None of the arguments are owned by the created object */
      static LookedUpFunction CreateDefined(alf::CFuncTuple * func_tuple, ProgramPointECFG * program_point)
         {return LookedUpFunction(func_tuple, program_point);}

      /** Create an undefined looked-up function */
      static LookedUpFunction CreateUndefined()
         {return LookedUpFunction(0, 0);}

      /** Returns if the looked-up function is defined or not */
      bool IsDefined() const {return defined_func.first != 0;}

      /** Get the CFuncTuple of the looked-up function
          @pre The function is defined (IsDefined() returns @c true)
          @note The returned pointer must not be deleted by the caller */
      alf::CFuncTuple * GetFuncTuple() const {assert(IsDefined()); return defined_func.first;}

      /** Get the ProgramPointECFG of the looked-up function
          @pre The function is defined (IsDefined() returns @c true)
          @post The returned pointer must not be deleted by the caller */
      ProgramPointECFG * GetProgramPoint() 
         {assert(defined_func.second != 0); return defined_func.second;}

   private:
      std::pair<alf::CFuncTuple *, ProgramPointECFG *> defined_func;

      LookedUpFunction(alf::CFuncTuple * func_tuple, ProgramPointECFG * program_point)
         : defined_func(func_tuple, program_point) {}
   };

   PPEnviron(const alf::CAlfTuple & program);

   PPEnviron(const PPEnviron & other);

   ~PPEnviron();

   bool IsEqual(const PPEnviron& other) const {return *this == other;}

   bool operator ==(const PPEnviron& other) const;

   /** Look up the program point(s) corresponding to an @p address. @p cur_pp
      is the current program point. */
   void LookupStmt(const ProgramPointECFG & cur_pp, const Value & address,
      std::vector<ProgramPointECFG *> & program_points) const;
   
   /** Look up the function(s) corresponding to an @p address. @p cur_pp
      is the current program point. */
   void LookupFunction(const ProgramPointECFG & cur_pp, const Value & address,
      std::vector<LookedUpFunction> & functions) const;

private:
   /** Address offset */
   typedef unsigned long long AddrOffset;

   /** For a given base pointer, maps offsets to the statement pointed to by
       creating an address from the base pointer and the offset */
   typedef std::map<AddrOffset, alf::AStmt *> AddrSet;

   /** Key in the AST */
   typedef unsigned ASTKey;

   /** Maps AST keys to pointer sets */
   typedef std::map<ASTKey, AddrSet *> ASTKeyToAddrSet;

   /** For a given base pointer, maps offsets to the function pointed to by
       creating an address from the base pointer and the offset */
   typedef std::map<AddrOffset, alf::CFuncTuple *> FuncSet;

   /** Maps AST keys to function sets */
   typedef std::map<ASTKey, FuncSet *> ASTKeyToFuncSet;

   /** Collection of AST keys */
   typedef std::vector<ASTKey> ASTKeySet;

   /** An address set and the set of AST keys that should be associated with
       the address set (because different AST keys can have the same meaning).
       Is used only during setup of the environment. */
   typedef std::pair<AddrSet, ASTKeySet> LRef;

   /** Collection of labels. Used during setup of the environment to keep
       track of which labels should be attached to a statement (which may be
       several for a single statement, since (ALF) scope statements can be
       labelled, which has the effect that the label will be attached to the
       first non-scope statement inside the scope, in addition a possible label
       on that statement). */
   typedef std::vector<alf::AStmt **> LabelColl;

   /** Maps string identifiers from the actual code (extended with a reference to
       the source file name - necessary in case of linked code) to the lref they
       reference. This is used only during setup of the environment */
   typedef std::map<std::pair<std::string,const std::string*>, LRef> CodeIDToLRef;

   /** Holds a set of functions and all the AST keys that should be associated
       with the function set. Is only used during setup of the environment. */
   typedef std::pair<FuncSet, ASTKeySet> FuncRef;

   /** Maps code identifiers to function reference information holders. Is only used
       during setting up the environment. */
   typedef std::map<std::string, FuncRef> CodeIDToFuncRef;

   class SymbolOffsetPairsExtractor;

   /** Implements the environment. Maps an lref's AST key to a holder of information about
       the lref, which in turn is a mapping from offsets to actual program points. */
   ASTKeyToAddrSet ast_key_to_addr_set;

   /** Implements the environment. Maps a function lref's AST key to a holder of information
       about the lref, which in turn is a mapping from offsets to actual functions. */
   ASTKeyToFuncSet ast_key_to_func_set;

   /** Used as a garbage collector, so that memory can be cleaned up easy when
       the object is destroyed */
   std::vector<AddrSet *> addr_sets;

   /** Used as a garbage collector, so that memory can be cleaned up easy when
       the object is destroyed */
   std::vector<FuncSet *> func_sets;

   void ProcessStmts(const alf::CStmtList & stmts, LabelColl & collected_labels,
                     CodeIDToLRef & code_id_to_lref);
};

#endif   // ifndef PPENVIRON_H_INCLUDED
