#ifndef EXPRNODE_H_INCLUDED
#define EXPRNODE_H_INCLUDED

#include "program/alf/COpNumExprTuple.h"
#include <ostream>
#include <memory>
#include <vector>

class State;
class Value;
class AlfVM;
class ValueDomain;

namespace alf
{
   class AExpr;
   class CLoadExprTuple;
}

class InternalExprNode;
class ExprLeaf;
class LoadLeaf;

class ExprNodeVisitor
{
public:
   virtual void VisitInternalExprNode(const InternalExprNode & node) = 0;
   virtual void VisitExprLeaf(const ExprLeaf & node) = 0;
   virtual void VisitLoadLeaf(const LoadLeaf & node) = 0;
};

/** Node in an expression tree. The expression tree is used internally by
    RestrictedALFState and represents the ALF expression given to its
    constructor. There are three types of nodes:
    
    - Internal nodes. Represent ALF operations. Each node holds the operator,
      the operand sizes, and pointers to the operand subexpression trees.
    - Constant leaf nodes. Leaves in the expression tree holding constants.
      Restricting these won't update the state (except possibly making it bottom).
    - Load leaf nodes. Hold { load ... } expressions. These are handled separately
      because when restricting them, the state's memory must be updated.

    Each node also holds an annotation, which caches the value that the subtree beneath
    it evaluated to in the state before starting the restriction. This annotation is used
    to make traversing the expression tree more efficient, and in some cases it actually improves
    precision of the involved calculations. Before starting a new restriction,
    the entire expression tree is traversed and all annotations are updated. An exception
    is the constant leaf nodes, whose annotations are initialized when the node is
    created, and then updated on-the-fly while the state is restricted. This is just a
    small optimization which is valid since updating the state's memory won't change the
    values of these constant expressions. In contrast, the annotations of load leaves must
    be updated in a separate pass like this because the same memory area
    can be referenced in several subtrees, so it is necessary to maintain consistency
    between these occurrences.  */
class ExprNode
{
   friend class LoadLeaf;

public:
   /** Create a tree from the ALF expression @a expr
       @param expr   The expression to represent. The caller is responsible for it.
       @param state  The state to restrict. The caller is responsible for it.
       @param domain Domain to use. The caller is responsible for it.
       @param alf_vm The ALF virtual machine to use. The caller is responsible for it. */
   static ExprNode * Create(const alf::AExpr * expr, State * state,
                            const ValueDomain * domain, const AlfVM * alf_vm);

   /** Destructor that destroys the subtree below it */
   virtual ~ExprNode();

   /** Make a copy of the node. Will make a deep copy of the annotation (if there is one)
       and shallow copies of all other members. The state member will be set to @a state.
       @note The caller is responsible for @a state */
   virtual ExprNode * Copy(State * state) const = 0;

   /** Accept visit from a ExprNodeVisitor */
   virtual void AcceptVisitor(ExprNodeVisitor * visitor) const = 0;

   /** Update all annotations of the subtree below and including this node (in principle
       non-load leaf nodes are updated as well, but their previous annotations will still
       be valid, so in practice they are skipped) */
   virtual const Value * UpdateAnnot() = 0;

   /** Return whether this node has an annotation */
   bool HasAnnot() const {return GetAnnot() != 0;}

   /** Get access to the node's annotation
       @note The returned value should @e not be deleted
       @note If HasAnnot() returns false, the returned pointer will be 0 */
   const Value * GetAnnot() const {return annot;}

   /** Restrict the state so that the subtree rooted at this node 
       evaluates to an abstract value fully included in @a r. The node annotations
       of leaf nodes will be updated, but annotations of all other nodes will remain
       unchanged.
       @return True if the restriction resulted in a bottom state (which signals
               that the state pointer hold by RestrictedALFState should be replaced by a 
               pointer to a bottom state)
       @pre    All annotations of the subtree beneath and including this node have been
               updated by a call to UpdateAnnot() on the root of the expression tree       
       @note   The state pointer will not be changed, even if the restricted state
               becomes bottom; changing this pointer is the responsibility of
               RestrictedALFState */
   virtual bool RestrictEq(const Value * r) = 0;

   /** Restrict the state so that the subtree rooted at this node 
       evaluates to an abstract value fully included in the @e complement of @a r.
       The node annotations of leaf nodes will be updated, but annotations of all 
       other nodes will remain unchanged.
       @return True if the restriction resulted in a bottom state (which signals
               that the state pointer hold by RestrictedALFState should be replaced by a 
               pointer to a bottom state)
       @pre    All annotations of the subtree beneath and including this node have been
               updated by a call to UpdateAnnot() on the root of the expression tree
       @note   The state pointer will not be changed, even if the restricted state
               becomes bottom; changing this pointer is the responsibility of
               RestrictedALFState */
   virtual bool RestrictNEq(const Value * r) = 0;

   /** Print a textual representation of the subtree beneath and including this node
       to @a os */
   virtual std::ostream & Print(std::ostream & os) const = 0;

protected:
   /*  Create an expression node
       @param state  The state to restrict. The caller is responsible for it.
       @param domain Domain to use. The caller is responsible for it.
       @param alf_vm The ALF virtual machine to use. The caller is responsible for it. */
   ExprNode(State * state, const ValueDomain * domain, const AlfVM * alf_vm);

   /** Construct a copy of @a other. Will make a deep copy of the annotation (if there is one)
       and shallow copies of all other members. The state member will be set to @a state.
       @note The caller is responsible for @a state */
   ExprNode(const ExprNode & other, State * state);

   /** Reset the node's annotation to @a annot. The old annotation will be destroyed. */
   void SetAnnot(std::unique_ptr<Value> annot);

   /** Get access to the state being restricted */
   State * GetState() const {return state;}

   /** Get access to the domain to use when evaluating operations */
   const ValueDomain * GetDomain() const {return domain;}

   /** Get access to the virtual machine to use when evaluating ALF
       expressions */
   const AlfVM * GetALFVM() const {return alf_vm;}

private:
   /** The node's annotation, which caches the value of the subtree beneath
       the node when evaluating it in the current state */
   const Value * annot;

   /** The state being restricted. All nodes in the tree do in principle have
       identical pointers. However, as an optimization, in case the restricted
       state becomes bottom, the pointer in RestricedALFState will be replaced
       to point at a bottom state, while the pointers in the nodes will still
       point to the old (and now destroyed) state. This should work because no
       meaningful operations can be done on the tree anyways. */
   State * state;

   /** The domain to use when evaluating operations */
   const ValueDomain * domain;

   /** The virtual machine to use when evaluating ALF expressions */
   const AlfVM * alf_vm;

   /** Copy constructor made impossible to call from the outside */
   ExprNode(const ExprNode & other) {}
};

/** Internal expression node 
    @see ExprNode */
class InternalExprNode : public ExprNode
{
public:
   typedef std::vector<ExprNode *> ChildList;
   typedef std::vector<Size> SizeList;

   /*  Create an internal node
       @param expr   The ALF operation to represent. The caller is responsible for it.
       @param state  The state to restrict. The caller is responsible for it.
       @param domain Domain to use. The caller is responsible for it.
       @param alf_vm The ALF virtual machine to use. The caller is responsible for it. */
   InternalExprNode(const alf::COpNumExprTuple * expr, State * state,
                    const ValueDomain * domain, const AlfVM * alf_vm);

   /** Construct a copy of @a other. Will make a deep copy of the annotation (if there is one)
       and shallow copies of all other members. The state member will be set to @a state.
       @note The caller is responsible for @a state */
   InternalExprNode(const InternalExprNode & other, State * state);

   /** Destructor that destroys the subtree below it */
   virtual ~InternalExprNode();

   /** Make a copy of the node. Will make a deep copy of the annotation (if there is one) and
       shallow copies of all other members. The state member will be set to @a state.
       @note The caller is responsible for @a state */
   virtual ExprNode * Copy(State * state) const {return new InternalExprNode(*this, state);}

   /** Accept visit from a ExprNodeVisitor */
   virtual void AcceptVisitor(ExprNodeVisitor * visitor) const {visitor->VisitInternalExprNode(*this);}

   /** Get access to the children of this node */
   const ChildList & GetChildren() const {return children;}

   /** Update all annotations of the subtree below and including this node (in principle
       non-load leaf nodes are updated as well, but their previous annotations will still
       be valid, so in practice they are skipped) */
   virtual const Value * UpdateAnnot();

   /** @copydoc ExprNode::RestrictEq(const Value*) */
   virtual bool RestrictEq(const Value * r);

   /** @copydoc ExprNode::RestrictNEq(const Value*) */
   virtual bool RestrictNEq(const Value * r);

   /** @copydoc ExprNode::Print(std::ostream&) const */
   virtual std::ostream & Print(std::ostream & os) const;

private:
   /** Internal restricting function */
   template <bool (ExprNode::*RestrictFunc)(const Value*)>
   bool Restrict(const Value * r);

   /** The operation this internal node represents */
   alf::COpNumExprTuple::OP_TYPE operation;

   /** Size operands */
   SizeList size_opers;

   /** List of expression trees making up the operands to the operation */
   ChildList children;
};

/** Constant-expression leaf node
    @see ExprNode */
class ExprLeaf : public ExprNode
{
public:
   /*  Create a constant leaf node
       @param expr   The constant ALF expression to represent. The caller is responsible for it.
       @param state  The state to restrict. The caller is responsible for it.
       @param domain Domain to use. The caller is responsible for it.
       @param alf_vm The ALF virtual machine to use. The caller is responsible for it. */
   ExprLeaf(const alf::AExpr * expr, State * state,
            const ValueDomain * domain, const AlfVM * alf_vm);

   /** Construct a copy of @a other. Will make a deep copy of the annotation (if there is one)
       and shallow copies of all other members. The state member will be set to @a state.
       @note The caller is responsible for @a state */
   ExprLeaf(const ExprLeaf & other, State * state);

   /** Accept visit from a ExprNodeVisitor */
   virtual void AcceptVisitor(ExprNodeVisitor * visitor) const {visitor->VisitExprLeaf(*this);}

   /** Make a copy of the node. Will make a deep copy of the annotation (if there is one) and
       shallow copies of all other members. The state member will be set to @a state.
       @note The caller is responsible for @a state */
   virtual ExprLeaf * Copy(State * state) const {return new ExprLeaf(*this, state);}

   /** Update all annotations of the subtree below and including this node (in principle
       non-load leaf nodes are updated as well, but their previous annotations will still
       be valid, so in practice they are skipped) */
   virtual const Value * UpdateAnnot();

   /** @copydoc ExprNode::RestrictEq(const Value*) */
   virtual bool RestrictEq(const Value * r);

   /** @copydoc ExprNode::RestrictNEq(const Value*) */
   virtual bool RestrictNEq(const Value * r);

   /** Print a textual representation of the subtree beneath and including this node
       to @a os */
   virtual std::ostream & Print(std::ostream & os) const;
};

/** Load-expression leaf node
    @see ExprNode */
class LoadLeaf : public ExprNode
{
public:
   /*  Create a { load ... } expression node
       @param expr   The load expression to represent. The caller is responsible for it.
       @param state  The state to restrict. The caller is responsible for it.
       @param domain Domain to use. The caller is responsible for it.
       @param alf_vm The ALF virtual machine to use. The caller is responsible for it. */
   LoadLeaf(const alf::CLoadExprTuple * expr, State * state,
            const ValueDomain * domain, const AlfVM * alf_vm);

   /** Construct a copy of @a other. Will make a deep copy of the annotation and
       shallow copies of all other members. The state member will be set to @a state.
       @note The caller is responsible for @a state */
   LoadLeaf(const LoadLeaf & other, State * state);

   /** Make a copy of the node. Will make a deep copy of the annotation and
       shallow copies of all other members. The state member will be set to @a state.
       @note The caller is responsible for @a state */
   virtual LoadLeaf * Copy(State * state) const {return new LoadLeaf(*this, state);}

   /** Accept visit from a ExprNodeVisitor */
   virtual void AcceptVisitor(ExprNodeVisitor * visitor) const {visitor->VisitLoadLeaf(*this);}

   /** Get access to the (evaluated) address of the @c load expression
       @note The returned value should be deleted by the caller */
   Value * GetAddress() const;

   /** Update all annotations of the subtree below and including this node (in principle
       non-load leaf nodes are updated as well, but their previous annotations will still
       be valid, so in practice they are skipped) */
   virtual const Value * UpdateAnnot();

   /** @copydoc ExprNode::RestrictEq(const Value*) */
   virtual bool RestrictEq(const Value * r);

   /** @copydoc ExprNode::RestrictNEq(const Value*) */
   virtual bool RestrictNEq(const Value * r);

   /** Print a textual representation of the subtree beneath and including this node
       to @a os */
   virtual std::ostream & Print(std::ostream & os) const;

private:
   /** How much to load from the memory */
   Size load_size;

   /** The address expression that evaluates to the address to read from. Is re-
       evaluated everytime a read is done. */
   const alf::AExpr * addr_expr;
};

inline std::ostream & operator <<(std::ostream & os, const ExprNode & en) {return en.Print(os);}

#endif
