#ifndef RESTRICTEDALFSTATE_H_INCLUDED
#define RESTRICTEDALFSTATE_H_INCLUDED

#include "program/alf/COpNumExprTuple.h"
#include <ostream>
#include <memory>

class Value;
class ValueDomain;
class AlfVM;
class State;
class ExprNode;

namespace alf
{
   class AExpr;
}

/** Class used to efficiently restrict an abstract ALF state. An object of the
    class is created around the state that should be restricted, and it then
    works as a support structure to get fast access to the relevant parts
    (the parts that are restricted) of the state. */
class RestrictedALFState
{
public:
   /** Create an object around the state @a state. The ALF expression @a expr is
       used to restrict the state in the following way: When RestrictEq() is called
       with some abstract restricting value @a r, the state is restricted so that evaluating
       @a expr results in an abstract value that is included in @a r, which might be bottom.
       RestricNEq() works similarly, except it restricts the state so that evaluating
       @a expr results in a value that does @e not overlap with @a r. 
       @param expr      (See above.) The caller is responsible for it.
       @param state     (See above.) Ownership is taken over by the constructed object.
       @param domain    The domain to be used. The caller is responsible for it.
       @param alf_vm    The ALF virtual machine to use for evaluating expressions. The caller
                        is responsible for it. */
   RestrictedALFState(const alf::AExpr * expr, std::unique_ptr<State> state,
                      const ValueDomain * domain, const AlfVM * alf_vm);

   /** Makes a deep copy of @a other, which means that the hold state is copied deep */
   RestrictedALFState(const RestrictedALFState & other);

   /** Create an appropriate subclass of RestrictedALFState. The created object is depending on the type of value domain.
       See constructor for argument description. */

   /** Destructor that will destroy the hold state if it has not been reclaimed before */
   virtual ~RestrictedALFState();

   /** Swap contents with @a other */
   void Swap(RestrictedALFState& other);

   /** Get access to the held state */
   const State * GetState() const {return state;}

   /** Get access to the internal expression tree */
   ExprNode * ExprTree() {return expr;}

   /** Get access to the internal expression tree */
   const ExprNode * ExprTree() const {return expr;}

   /** (See the constructor.) */
   virtual void RestrictEq(const Value * r);

   /** (See the constructor.) */
   virtual void RestrictNEq(const Value * r);

   /** Retrieve the restricted state.
       @pre    The function has not been called before on this particular object 
       @post   This object does not hold a state anymore, and no member functions are
               valid to call */
   std::unique_ptr<State> ReleaseState();

   /** Print a textual representation of this object to @a os */
   std::ostream & Print(std::ostream & os) const;


protected:
   /** The root of the internal expression tree */
   ExprNode * expr;

private:
   /** The current restricted state */
   State * state;

   /** The domain used to evaluate expressions */
   const ValueDomain * domain;
};

inline std::ostream & operator <<(std::ostream & os, const RestrictedALFState & r) {return r.Print(os);}

#endif   // #ifndef RESTRICTEDALFSTATE_H_INCLUDED
