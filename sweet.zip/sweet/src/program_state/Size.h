#ifndef SIZE_H_INCLUDED
#define SIZE_H_INCLUDED

#include "tools/EInt.h"

typedef EInt<unsigned long long> Size;

/* For forward declarations:

template <typename> class EInt;
typedef EInt<unsigned long long> Size;

*/

#endif // SIZE_H_INCLUDED
