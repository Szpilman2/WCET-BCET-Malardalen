#ifndef BOTTOMVALUE_H_INCLUDED
#define BOTTOMVALUE_H_INCLUDED

#include "Value.h"

class ValueDomain;

class BottomValue : public Value
{
public:
   BottomValue(const Size & size_in_bits) : Value(size_in_bits) {}

   virtual BottomValue * Copy() const {return new BottomValue(*this);}

   /** @copydoc Value::IsEqual(const Value*) const */
   virtual bool IsEqual(const Value * other) const
   { return other->AsBottomValue() != 0 && this->SizeInBits() == other->SizeInBits(); }

   virtual void AcceptVisitor(ValueVisitor * visitor) const
      { visitor->VisitBottomValue(*this); }

   /** Dynamic cast */
   virtual const BottomValue* AsBottomValue() const {return this;}

   virtual bool IsBottom() const {return true;}

   virtual bool IsSingleElem() const {return false;}

   std::ostream & Print(std::ostream & os) const {return os << "bottom";}
};

#endif   // #ifndef BOTTOMVALUE_H_INCLUDED
