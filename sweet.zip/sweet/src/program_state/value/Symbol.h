#ifndef SYMBOL_H_INCLUDED
#define SYMBOL_H_INCLUDED

#include <set>
#include <ostream>
#include <string>

/** Taken symbol spaces:
    0: Frame references,
    1: Label references */
class Symbol
{
public:
   typedef unsigned SymbRepr;
   typedef unsigned SymbSpaceRepr;

   class SetSymbolComparator
   {
   public:
      bool operator ()(const Symbol & a, const Symbol & b) const
      {
         if (a.GetSpace() < b.GetSpace())
            return true;
         if (b.GetSpace() < a.GetSpace())
            return false;
         // a.GetSpace() == b.GetSpace()
         if (a.GetValue() < b.GetValue())
            return true;
         if (b.GetValue() < a.GetValue())
            return false;
         // a.GetSpace() == b.GetSpace() && a.GetValue() == b.GetValue()
         return a.GetAnnot() < b.GetAnnot();
      }
   };

   Symbol(SymbRepr value, SymbSpaceRepr space);
   
   bool operator ==(const Symbol & other) const;

   SymbRepr GetValue() const {return value;}

   SymbSpaceRepr GetSpace() const {return space;}
   
   /** Get the annotation of this symbol. @see SetAnnot() */
   const std::string& GetAnnot() const { return annot; }

   /** Assign an annotation to this symbol. The annotation might be the static name of a frame or a program point
      that the symbol references. */
   void SetAnnot(const std::string& newAnnot) { annot = newAnnot; }

   std::ostream & Print(std::ostream & o) const;

private:
   SymbRepr value;
   SymbSpaceRepr space;

   /** An optional annotation attached to the symbol. TODO: It would perhaps be cleaner to have a
      reference into the symbol table instead. In that case neither the annotation nor the symbol space
      member would be needed either, because all that information could be retrieved from the symbol table. */
   std::string annot;
};

inline std::ostream & operator <<(std::ostream & o, const Symbol & symbol) {return symbol.Print(o);}

typedef std::set<Symbol, Symbol::SetSymbolComparator> SymbolColl;

#endif   // #ifndef SYMBOL_H_INCLUDED
