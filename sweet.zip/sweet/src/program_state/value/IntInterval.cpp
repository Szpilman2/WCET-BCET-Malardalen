#include "IntInterval.h"
#include "IntRangeTpl.h"
#include "ValueDomain.h"
#include "IntegerDomain.h"
#include "FloatDomain.h"
#include "globals.h"
#include "macros.h"
#include "tools/RangeIterator.h"
#include <cmath>
#include <stdint.h>
#include <limits>
#include <ciso646>
#include <queue>
#include <algorithm>
#include <iterator>

using namespace std;

Value* IntInterval::Create(const Size& size_in_bits, const Integer& l, const Integer& u)
{
   if (u < l)
      return domain->CreateBottomValue(size_in_bits);
   return new IntInterval(size_in_bits, l, u);
}

Value* IntInterval::Create(const Size& size_in_bits, IntRangeList& ranges)
{
   if (ranges.empty())
      return domain->CreateBottomValue(size_in_bits);
   return new IntInterval(size_in_bits, ranges);
}

IntInterval::IntInterval(const Size & size_in_bits)
: Bitstring(size_in_bits), is_top(true)
{
   assert(size_in_bits != 0 || "Cannot create an integer range of size 0" == NULL);
}

IntInterval::IntInterval(const Size & size_in_bits, const Integer & val)
: Bitstring(size_in_bits), is_top(false)
{
   assert(size_in_bits != 0 || "Cannot create an integer range of size 0" == NULL);
   InitRangeSet(val, val);
}

IntInterval::IntInterval(const Size & size_in_bits, const Integer & l, const Integer & u)
: Bitstring(size_in_bits), is_top(false) // Note: is_top might later be set to true in InitRangeSet()
{
   assert(size_in_bits != 0 || "Cannot create an integer range of size 0" == NULL);
   InitRangeSet(l, u);
   if (range_set.empty() && !is_top)
      throw logic_error(string(typeid(IntInterval).name()) + " cannot represent bottom. The class BottomValue should be used instead.");
}

IntInterval::IntInterval(const Size & size_in_bits, IntRangeList & rs)
: Bitstring(size_in_bits), is_top(false) // Note: is_top might later be set to true in InitRangeSet()
{
   assert(size_in_bits != 0 || "Cannot create an integer range of size 0" == NULL);
   InitRangeSet(rs);
   if (range_set.empty() && !is_top)
      throw logic_error(string(typeid(IntInterval).name()) + " cannot represent bottom. The class BottomValue should be used instead.");
}

IntInterval::IntInterval(const IntInterval & other)
   : Bitstring(other), range_set(other.range_set), is_top(other.is_top)
{
}

bool IntInterval::IsEqual(const Value * other) const
{
   const IntInterval* other_ = other->AsIntInterval();
   if (other_ == 0)
      return false;
   if (this->SizeInBits() != other_->SizeInBits())
      return false;
   if (GetRanges().size() != other_->GetRanges().size())
      return false;
   if (!equal(this->GetRanges().begin(), this->GetRanges().end(), other_->GetRanges().begin()))
      return false;
   return this->is_top == other_->is_top;
}

void IntInterval::AsUnsigned(std::vector<Integer> & values) const
{
   assert(!(SizeInBits() == Size::Infinity() && IsTopBitstring()) || "Cannot push "
          "infinitely many integers to the vector" == 0);

   Integer i;
   IntRangeList rs;
   GetUnsignedRanges(rs);
   for (IntRangeList::const_iterator r = rs.begin(); r != rs.end(); ++r)
   {
      for (i = r->L(); i <= r->U(); ++i)
         values.push_back(Integer(i));
   }
}

Integer IntInterval::LAsUnsigned() const
{
   if (IsTopBitstring())
      return SmallestRepresentableUnsigned<Integer>(*this);
   else
   {
      // Loop through all unsigned ranges and return the smallest value found
      IntRangeList rs;
      GetUnsignedRanges(rs);

      Integer smallest = rs.front().L();
      IntRangeList::iterator r = rs.begin();
      for (++r; r != rs.end(); ++r)
         smallest = std::min(smallest, r->L());
      return smallest;
   }
}

Integer IntInterval::UAsUnsigned() const
{   
   assert(!IsInfAndTopBitstring(*this) || "Infinite precision top value does not have an upper bound" == 0);
   if (IsTopBitstring())
      return LargestRepresentableUnsigned<Integer>(*this);
   else 
   {
      // Loop through all unsigned ranges and return the largest value found
      IntRangeList rs;
      GetUnsignedRanges(rs);

      Integer largest = rs.front().U();
      IntRangeList::iterator r = rs.begin();
      for (++r; r != rs.end(); ++r)
         largest = std::max(largest, r->U());
      return largest;
   }
}

Integer IntInterval::LAsSigned() const
{
   assert(!IsInfAndTopBitstring(*this) || "Infinite precision top value does not have a signed lower bound" == 0);
   if (IsTopBitstring())
      return SmallestRepresentableSigned<Integer>(*this);
   else 
   {
      // Loop through all signed ranges and return the smallest value found
      IntRangeList rs;
      GetSignedRanges(rs);

      Integer smallest = rs.front().L();
      IntRangeList::iterator r = rs.begin();
      for (++r; r != rs.end(); ++r)
         smallest = std::min(smallest, r->L());
      return smallest;
   }
}

Integer IntInterval::UAsSigned() const
{
   assert(!IsInfAndTopBitstring(*this) || "Infinite precision top value does not have an upper bound" == 0);
   if (IsTopBitstring())
      return LargestRepresentableSigned<Integer>(*this);
   else 
   {
      // Loop through all unsigned ranges and return the largest value found
      IntRangeList rs;
      GetSignedRanges(rs);

      Integer largest = rs.front().U();
      IntRangeList::iterator r = rs.begin();
      for (++r; r != rs.end(); ++r)
         largest = std::max(largest, r->U());
      return largest;
   }
}

AbsBitValue 
IntInterval::ValueOfBit(uint64_t bit) const
{
   assert(bit < SizeInBits());

   if (IsTopBitstring())
      return BOTH_ZERO_AND_ONE;
   else
   {
      IntRangeList rs;
      GetSignedRanges(rs);
      unsigned int lower = 1, upper = 0;

      // Now run through the signed ranges and determine whether they include some concrete
      // value where the bit is set and/or some value where the
      // bit is cleared. In the former case, upper will be set to 1, and in the latter case
      // lower will be set to 0.

      // Some temporary variables which are created outside the loop as an optimization
      Integer l, u, l_bit, mask, next_one, next_zero;
      for (IntRangeList::const_iterator r = rs.begin(); r != rs.end(); ++r)
      {
         // Get the lower and upper value of the range
         l = r->L();
         u = r->U();
         // Mask out the bit in question from the lower bound
         l_bit = l & (Integer(1) << bit);
         if (l_bit == 0)
         {
            lower = 0;
            // Find out the next number in which the bit is set to 1. This is derived by
            // setting all the bits below it in l to 1s and then adding 1 to the result.
            mask = (Integer(1) << bit) - 1;
            next_one = (l | mask) + 1;
            // If that number falls within the interval, it means that the bit can be set to 1 also
            if (next_one <= u)
            {
               upper = 1;
               break;
            }
         }
         // The bit is set to 1
         else
         {
            upper = 1;
            // Find out the next number in which the bit is set to 0. This is derived by
            // setting the bit and all the bits below it in l to 1s and then adding 1 to the
            // result
            mask = (Integer(1) << (bit + 1)) - 1;
            next_zero = (l | mask) + 1;
            // If that number falls within the interval, it means that the bit can be set to 0 also
            if (next_zero <= u)
            {
               lower = 0;
               break;
            }
         }
      }

      assert(lower <= upper);

      if (upper == 0)
         return ONLY_ZERO;
      else if (lower == 1)
         return ONLY_ONE;
      else
         return BOTH_ZERO_AND_ONE;
   }
}

bool IntInterval::IsTopBitstring() const
{
   return is_top? (assert(range_set.empty()), true) : false;
}

bool IntInterval::IsSingleElem() const
{
   return GetRanges().size() == 1 && GetRanges().front().L() == GetRanges().front().U();
}

Value * IntInterval::SExclUpperBelow() const
{
   assert(!IsInfAndTopBitstring(*this));
   // Create a new Value with ranges [minval..U - 1]
   Integer l = SmallestRepresentableSigned<Integer>(*this), u = UAsSigned() - 1;
   if (u < l)
      return domain->CreateBottomValue(SizeInBits());
   return domain->GetIntegerDomain()->CreateInteger(SizeInBits(), l, u);
}

Value * IntInterval::UExclUpperBelow() const
{
   assert(!IsInfAndTopBitstring(*this));
   // Create a new Value with ranges [minval..max(U)-1]
   Integer l = SmallestRepresentableUnsigned<Integer>(*this), u = UAsUnsigned() - 1;
   if (u < l)
      return domain->CreateBottomValue(SizeInBits());
   return domain->GetIntegerDomain()->CreateInteger(SizeInBits(), l, u);
}

Value * IntInterval::SExclLowerAbove() const
{
   assert(!IsInfAndTopBitstring(*this));
   // Create a new Value with ranges [min(L)+1..maxval]
   Integer l = LAsSigned() + 1, u = LargestRepresentableSigned<Integer>(*this);
   if (u < l)
      return domain->CreateBottomValue(SizeInBits());
   return domain->GetIntegerDomain()->CreateInteger(SizeInBits(), l, u);
}

Value * IntInterval::UExclLowerAbove() const
{
   assert(!IsInfAndTopBitstring(*this));
   // Create a new Value with ranges [min(L)+1..maxval]
   Integer l = LAsUnsigned() + 1, u = LargestRepresentableUnsigned<Integer>(*this);
   if (u < l)
      return domain->CreateBottomValue(SizeInBits());
   return domain->GetIntegerDomain()->CreateInteger(SizeInBits(), l, u);
}

Value * IntInterval::SInclUpperBelow() const
{
   assert(!IsInfAndTopBitstring(*this));
   // Create a new Value with ranges [minval..max(U)]
   return domain->GetIntegerDomain()->CreateInteger(SizeInBits(), SmallestRepresentableSigned<Integer>(*this), UAsSigned());
}

Value * IntInterval::UInclUpperBelow() const
{
   assert(!IsInfAndTopBitstring(*this));
   // Create a new Value with ranges [minval..max(U)]
   return domain->GetIntegerDomain()->CreateInteger(SizeInBits(), SmallestRepresentableUnsigned<Integer>(*this), UAsUnsigned());
}

Value * IntInterval::SInclLowerAbove() const
{
   assert(!IsInfAndTopBitstring(*this));
   // Create a new Value with ranges [min(L)..maxval]
   return domain->GetIntegerDomain()->CreateInteger(SizeInBits(), LAsSigned(), LargestRepresentableSigned<Integer>(*this));
}

Value * IntInterval::UInclLowerAbove() const
{
   assert(!IsInfAndTopBitstring(*this));
   // Create a new Value with ranges [min(L)..maxval]
   return domain->GetIntegerDomain()->CreateInteger(SizeInBits(), LAsUnsigned(), LargestRepresentableUnsigned<Integer>(*this));
}

ostream & IntInterval::Print(ostream & o) const
{
   if (IsTopBitstring())
      return o << "[MININT..MAXINT]";
   // we generally prefer to print the signed interpretation, but if this is a
   // 1-bit integer, or the unsigned interpretation contains only a single range --
   // and the signed one does not -- we print the value as unsigned instead
   if (SizeInBits() == 1) {
      // note: HasUnsignedRep() == true for SizeInBits() < Size::Infinity()
      return PrintAsUnsigned(o);
   }
   if (GetRanges().size() == 1 && HasUnsignedRep()) { // cheap first test
      IntRangeList rs;
      GetSignedRanges(rs);
      if (rs.size() > 1) {
         rs.clear();
         GetUnsignedRanges(rs);
         if (rs.size() == 1)
            return PrintAsUnsigned(o);
      }
   }
   return PrintAsSigned(o);
}

ostream & IntInterval::PrintAsSigned(ostream & o) const
{
   if (IsTopBitstring())
      return o << "[MININT..MAXINT]";
   IntRangeList rs;
   GetSignedRanges(rs);
   // Print the beginning of the set
   if (rs.size() > 1)
      o << '{';
   // Print all ranges
   copy(rs.begin(), --rs.end(), ostream_iterator<IntRangeTpl<Integer> >(o, ","));
   o << rs.back();
   // Print the end of the set
   if (rs.size() > 1)
      o << '}';
   return o;
}

ostream & IntInterval::PrintAsUnsigned(ostream & o) const
{
   if (IsTopBitstring())
      return o << "[MININT..MAXINT]";
   if (!HasUnsignedRep())
      return o << "(no unsigned rep.)";
   IntRangeList rs;
   GetUnsignedRanges(rs);
   // Print the beginning of the set
   if (rs.size() > 1)
      o << '{';
   // Print all ranges
   copy(rs.begin(), --rs.end(), ostream_iterator<IntRangeTpl<Integer> >(o, ","));
   o << rs.back();
   // Print the end of the set
   if (rs.size() > 1)
      o << '}';
   return o;
}

ostream & IntInterval::PrintBinary(ostream & o) const
{
   if (IsTopBitstring())
   {
      if (SizeInBits() == Size::Infinity())
         return o << "...???";
      else
      {
         for (unsigned b = 0; b < SizeInBits().AsBaseIntType(); ++b)
            o << "?";
         return o;
      }
   }
   else
   {
      IntRangeList rs;
      GetSignedRanges(rs);
      char enclosing[2];
      if (rs.size() > 1)
      {
         enclosing[0] = '{';
         enclosing[1] = '}';
      }
      else
      {
         enclosing[0] = '\0';
         enclosing[1] = '\0';
      }
      o << enclosing[0];
      for (IntRangeList::const_iterator r = rs.begin(); r != rs.end(); ++r)
      {
         if (r != rs.begin())
            o << ",";
         o << "[";
         print_num_binary(r->L(), static_cast<int>(SizeInBits().AsBaseIntType()), &o);
         o << ",";
         print_num_binary(r->U(), static_cast<int>(SizeInBits().AsBaseIntType()), &o);
         o << "]";
      }
      return o << enclosing[1];
   }
}

std::ostream & IntInterval::PrintAbsBinary(std::ostream & o) const
{
   unsigned long long end_bit;
   if (SizeInBits() == Size::Infinity())
   {
      Integer ored(0);
      Integer l = LAsSigned(), u = UAsSigned();
      if (l < 0)  ored |= ~l;
      else        ored |=  l;
      if (u < 0)  ored |= ~u;
      else        ored |=  u;
      for (end_bit = 0; ored > 0; ++end_bit)
         ored >>= 1;
      ++end_bit;
   }
   else
      end_bit = SizeInBits().AsBaseIntType() - 1;
   if (SizeInBits() == Size::Infinity())
      o << "...";
   for (signed long long p = end_bit; p >= 0; --p)
      switch (ValueOfBit(p))
      {
      case ONLY_ZERO:         o << "0"; break;
      case ONLY_ONE:          o << "1"; break;
      case BOTH_ZERO_AND_ONE: o << "?"; break;
      }
   return o;
}

// Private members starts here - - - - - - - - - - - - ->

class IntInterval::CompareLOfRanges
{
public:
   bool operator ()(const IntRangeTpl<Integer> & a, const IntRangeTpl<Integer> & b) const
   {
      return a.L() < b.L();
   }
};

class IntInterval::MergedIntervals
{
public:
   /** Used to reference the two prospective ranges to merge in the range set */
   IntRangeList::iterator left, right;

   /** Holds the gap between the two ranges. Is used to sort the priority_queue. */
   Integer gap;

   /** The new upper bound of the left range if
       the two ranges are merged (the right range is destroyed). */
   Integer new_u;

   MergedIntervals(IntRangeList::iterator left, IntRangeList::iterator right,
                   const Integer & gap, const Integer & new_u)
      : left(left), right(right), gap(gap), new_u(new_u) {}

   /** Comparison operator that makes the element with the smallest gap appear
       at the top of the priority_queue (i.e.\ , the element with the smallest gap
       is the largest) */
   bool operator <(const MergedIntervals & other) const {return gap > other.gap;}
};

void IntInterval::InitRangeSet(const Integer & l, const Integer & u)
{
   // Negative intervals are interpreted as empty intervals
   if (u < l)
      return;

   if (SizeInBits() == Size::Infinity()) {
     range_set.push_back(IntRangeTpl<Integer>(l, u));
   }
   else
   {
      // If the interval covers less values than is representable with this
      // integer type, remove all 1s in the significant bits and insert it
      // in the range set
      if (u - l + 1 < RepresentableRangeWidth<Integer>(*this))
      {
        Integer mask(1);
        mask <<= SizeInBits().AsBaseIntType();
        mask = mask - 1;
        range_set.push_back(IntRangeTpl<Integer>(l & mask, u & mask));
      }
      // Otherwise leave range_set empty because the value is a top value
      else 
         is_top = true;
   }
}

void IntInterval::InitRangeSet(IntRangeList & rs)
{
   if (SizeInBits() < Size::Infinity())
      InitRangeSetFinSize(rs);
   else
      InitRangeSetInfSize(rs);
}

/*
--------------------
   L0        U0
        L1        U1
--------------------
Gap: L1 - (U0 + 1)
Merge: [L0,max(U0, U1)]
--------------------
   U0   L0
             L1   U1
--------------------
Gap: L1 - (U0 + w + 1)
Merge: [L0,U0]
--------------------
   L0        U0
 U1     L1
--------------------
Gap: ...
--------------------
 U0      L0
    U1        L1
--------------------
         L0     U0
   L1       U1
--------------------
   U0    L0
   L1       U1
--------------------
          L0     U0
   U1   L1
--------------------
    U0       L0
  U1      L1
--------------------
*/

void IntInterval::InitRangeSetFinSize(IntRangeList & rs)
{
   // Get the ranges
   range_set.swap(rs);

   Integer rep_range_width = RepresentableRangeWidth<Integer>(*this);

   // For each range, check if it includes all representable integer values. If so,
   // the result is top, which is represented by an empty range set. If not, move the
   // range's bounds so that they lie in the interval [0..LargestRepresentableUnsigned()].
   // This might result in a range where the lower bound is larger than the upper bound,
   // but this is valid and is interpreted as follows: The range [a..b] where a > b is
   // interpreted as the LUB of the two ranges [0..b] and [a..LargestRepresentableUnsigned()].
   // Also, negative (i.e. empty) ranges are removed.
   {
      Integer mask = rep_range_width;
      --mask;
      for (IntRangeList::iterator r = range_set.begin(), r_end = range_set.end(); r != r_end; )
      {
         // Negative ranges are removed
         if (r->U() < r->L()) {
            r = range_set.erase(r);
            continue;
         }
         if (r->Cover() < rep_range_width)
         {
            r->L() &= mask;
            r->U() &= mask;
         }
         // If the range spans all integers that are representable in the precision of this
         // value, the result is top
         else
         {
            range_set.clear();
            is_top = true;
            return;
         }
         ++r;
      }
   }

   // An empty range set means a bottom value
   if (range_set.empty())
      return;

   range_set.sort(CompareLOfRanges());

   IntRangeTpl<Integer> unwr_r0, unwr_r1, unwr_merged;

   // Run through the ranges and merge any ranges where the merging does not
   // not introduce new values (i.e., overlapping or adjacent ranges)
   {
      IntRangeList::iterator r0, r1;
      Integer two(2);
      for (r0 = range_set.end(), --r0, r1 = range_set.begin(); 
           r1 != range_set.end() && range_set.size() > 1; )
      {
         // Make two "unwrapped" copies of the r0 and r1 ranges, which means that their
         // lower bounds are <= their upper bounds and that unwr_r0.L() <= unwr_r1.L().
         // These are used to determine if the ranges can be merged.
         unwr_r0 = *r0;
         if (unwr_r0.U() < unwr_r0.L())
            unwr_r0.U() += rep_range_width;

         unwr_r1 = *r1;
         if (unwr_r1.U() < unwr_r1.L())
            unwr_r1.U() += rep_range_width;
         if (unwr_r1.L() < unwr_r0.L())
         {
            unwr_r1.L() += rep_range_width;
            unwr_r1.U() += rep_range_width;
         }

         // Check if the ranges r0 and r1 can be merged
         if (unwr_r1.L() - unwr_r0.U() < two)
         {
            // Check if r0 needs to be extended (otherwise r0 covers the entire r1)
            if (unwr_r1.U() > unwr_r0.U())
            {
               // First create an unwrapped merged range and check if it includes
               // all possible integer values (which means the range set is top)
               unwr_merged.L() = unwr_r0.L();
               unwr_merged.U() = unwr_r1.U();
               if (unwr_merged.Cover() >= rep_range_width)
               {
                  range_set.clear();
                  is_top = true;
                  return;
               }
               // If not, extend r0 to cover r1
               r0->U() = r1->U();
            }
            r1 = range_set.erase(r1);
         }
         else
         {
            r0 = r1;
            ++r1;
         }
      }
   }

   if (range_set.size() == 1)
      return;

   // Now run through the remaining ranges, and merge ranges until only
   // IntInterval::max_number_of_ranges ranges remain. This is done by
   // always filling in the smallest gaps known, which means that a minimal number
   // of extra values are added. Note that this cannot result in top, because at
   // least one gap will be left. Furthermore, the range set must include gaps, because
   // otherwise we wouldn't have reached this point.
   {
      // This queue holds the largest gaps known and the involved ranges, and at
      // the top lies the smallest of these gaps, i.e., the first gap that will
      // be filled in if a larger gap is found
      priority_queue<MergedIntervals> sorted_gaps;
      Integer one(1), gap, new_u;
      IntRangeList::iterator r0, r1;
      for (r0 = range_set.end(), --r0, r1 = range_set.begin(); r1 != range_set.end(); )
      {
         // Make two "unwrapped" copies of the r0 and r1 ranges, which means that their
         // lower bounds are <= their upper bounds and that unwr_r0.L() <= unwr_r1.L().
         // These are used to compute the gap.
         unwr_r0 = *r0;
         if (unwr_r0.U() < unwr_r0.L())
            unwr_r0.U() += rep_range_width;

         unwr_r1 = *r1;
         if (unwr_r1.U() < unwr_r1.L())
            unwr_r1.U() += rep_range_width;
         if (unwr_r1.L() < unwr_r0.L())
         {
            unwr_r1.L() += rep_range_width;
            unwr_r1.U() += rep_range_width;
         }

         // Compute the gap that would be filled in if r0 and r1 where merged
         gap = unwr_r1.L() - (unwr_r0.U() + one);

         // If sorted_gaps does not hold enough gaps, just insert the new gap
         if (sorted_gaps.size() < IntInterval::max_number_of_ranges)
         {
            new_u = unwr_r1.U() > unwr_r0.U()? r1->U() : r0->U();
            sorted_gaps.push(MergedIntervals(r0, r1, gap, new_u));
            r0 = r1;
            ++r1;
         }
         else 
         {
            const MergedIntervals & queue_top = sorted_gaps.top();

            // If the new gap is smaller than the queue top, it's not among
            // the largest gaps known, so perform the merge and continue
            if (gap <= queue_top.gap)
            {
               if (unwr_r1.U() > unwr_r0.U())
                  r0->U() = r1->U();
               r1 = range_set.erase(r1);
            }
            // Otherwise, do the merge lying at the top of the queue, and then
            // insert the gap between r0 and r1 into the queue
            else
            {
               queue_top.left->U() = queue_top.new_u;
               if (r0 == queue_top.right)
                  r0 = queue_top.left;
               range_set.erase(queue_top.right);
               sorted_gaps.pop();
               new_u = unwr_r1.U() > unwr_r0.U()? r1->U() : r0->U();
               sorted_gaps.push(MergedIntervals(r0, r1, gap, new_u));
               r0 = r1;
               ++r1;
            }
         }
      }
   }
}

void IntInterval::InitRangeSetInfSize(IntRangeList & rs)
{
   // Get the ranges
   range_set.swap(rs);

   if (range_set.size() == 1)
      return;

   range_set.sort(CompareLOfRanges());

   // Run through the ranges and merge any ranges where the merging does not
   // not introduce new values (i.e., overlapping or adjacent ranges). Note that
   // since the value has infinite precision, no set of ranges can cause it to
   // become top.
   {
      IntRangeList::iterator r0, r1;
      Integer two(2);
      for (r0 = range_set.begin(), r1 = r0, ++r1; r1 != range_set.end(); r1 = r0, ++r1)
      {
         assert(r0->L() <= r0->U());
         if (r1->L() - r0->U() < two)
         {
            r0->U() = max(r0->U(), r1->U());
            range_set.erase(r1);
         }
         else
            ++r0;
      }
   }

   if (range_set.size() == 1)
      return;

   // Now run through the remaining ranges, and merge ranges until only
   // IntInterval::max_number_of_ranges ranges remain. This is done by
   // always filling in the smallest gaps known, which means that a minimal number
   // of extra values are added. Note that this cannot result in top, because 
   // the value has infinite precision, so no set of ranges can cause it to
   // become top.
   {
      // This queue holds the largest gaps known and the involved ranges, and at
      // the top lies the smallest of these gaps, i.e., the first gap that will
      // be filled in if a larger gap is found
      priority_queue<MergedIntervals> sorted_gaps;
      
      // Here a dummy gap is inserted with a gap size larger than any possible
      // gaps between two ranges in the range_set, which means it will always
      // lie at the bottom of the queue. This is to make sure that
      // one gap more than IntInterval::max_number_of_ranges is filled in
      // (this is taken care of automatically in InitRangeSetFinSize()).
      sorted_gaps.push(MergedIntervals(range_set.begin(), range_set.begin(),
                                       range_set.back().U() - range_set.front().L(),
                                       Integer(0)));
      Integer one(1), gap;
      IntRangeList::iterator r0, r1;
      for (r0 = range_set.begin(), r1 = r0, ++r1; r1 != range_set.end(); )
      {
         // Compute the gap that would be filled in if r0 and r1 where merged
         gap = r1->L() - (r0->U() + one);

         // If sorted_gaps does not hold enough gaps, just insert the new gap
         if (sorted_gaps.size() < IntInterval::max_number_of_ranges)
         {
            sorted_gaps.push(MergedIntervals(r0, r1, gap, max(r0->U(), r1->U())));
            r0 = r1;
            ++r1;
         }
         else 
         {
            const MergedIntervals & queue_top = sorted_gaps.top();

            // If the new gap is smaller than the queue top, it's not among
            // the largest gaps known, so perform the merge and continue
            if (gap <= queue_top.gap)
            {
               r0->U() = max(r0->U(), r1->U());
               r1 = range_set.erase(r1);
            }
            // Otherwise, do the merge lying at the top of the queue, and then
            // insert the gap between r0 and r1 into the queue
            else
            {
               queue_top.left->U() = queue_top.new_u;
               if (r0 == queue_top.right)
                  r0 = queue_top.left;
               range_set.erase(queue_top.right);
               sorted_gaps.pop();
               sorted_gaps.push(MergedIntervals(r0, r1, gap, max(r0->U(), r1->U())));
               r0 = r1;
               ++r1;
            }
         }
      }
   }
}

void IntInterval::GetSignedRanges(IntRangeList & rs) const
{
   assert(!IsInfAndTopBitstring(*this));
   if (SizeInBits() < Size::Infinity())
   {
      // Handle the case where this is a top integer
      if (IsTopBitstring())
      {
         rs.push_back(IntRangeTpl<Integer>(SmallestRepresentableSigned<Integer>(*this), LargestRepresentableSigned<Integer>(*this)));
         return;
      }
      else
      {
         unsigned long long size_in_bits = SizeInBits().AsBaseIntType();
         Integer signed_upper = LargestRepresentableSigned<Integer>(*this);
         Integer tail(-2);
         tail <<= (size_in_bits - 1);
         for (IntRangeList::const_iterator r = range_set.begin(); r != range_set.end(); ++r)
         {
            // Retrieve the range bounds
            IntRangeTpl<Integer> range = *r;
            // Sign-extend the range bounds (if the last bit position is a 1, a tail of 1s
            // is appended to it). Note that it may be the case that range.U() < range.L().
            if (range.L() > signed_upper)
               range.L() |= tail;
            if (range.U() > signed_upper)
               range.U() |= tail;
            // Non-wrapped around range - just add it to the range set
            if (range.L() <= range.U())
               rs.push_back(range);
            // Wrapped around range - split it into two ranges and add to the range set
            else
            {
               rs.push_back(IntRangeTpl<Integer>(SmallestRepresentableSigned<Integer>(*this), range.U()));
               rs.push_back(IntRangeTpl<Integer>(range.L(), LargestRepresentableSigned<Integer>(*this)));
            }
         }
      }
   }
   // Infinite precision - no splitting of the ranges needs to be done
   else for (IntRangeList::const_iterator r = range_set.begin(); r != range_set.end(); ++r)
   {
      assert(r->L() <= r->U());
      rs.push_back(*r);
   }
}

void IntInterval::GetUnsignedRanges(IntRangeList & rs) const
{
   assert(!IsInfAndTopBitstring(*this));
   if (SizeInBits() < Size::Infinity())
   {
      if (IsTopBitstring())
      {
         rs.push_back(IntRangeTpl<Integer>(SmallestRepresentableUnsigned<Integer>(*this), LargestRepresentableUnsigned<Integer>(*this)));
         return;
      }
      else
      {
         Integer l, u;
         for (IntRangeList::const_iterator r = range_set.begin(); r != range_set.end(); ++r)
         {
            // Retrieve the range bounds
            l = r->L();
            u = r->U();
            // Non-wrapped around range - just add it to the range set
            if (l <= u)
               rs.push_back(IntRangeTpl<Integer>(l, u));
            // Wrapped around range - split it into two ranges and add to the range set
            else
            {
               rs.push_back(IntRangeTpl<Integer>(SmallestRepresentableUnsigned<Integer>(*this), u));
               rs.push_back(IntRangeTpl<Integer>(l, LargestRepresentableUnsigned<Integer>(*this)));
            }
         }
      }
   }
   // Infinite precision - no splitting of the ranges needs to be done
   else for (IntRangeList::const_iterator r = range_set.begin(); r != range_set.end(); ++r)
   {
      assert(r->L() >= 0);
      assert(r->L() <= r->U());
      rs.push_back(*r);
   }
}

bool IntInterval::HasUnsignedRep() const
{
   // Finite sized values always have an unsigned representation
   if (SizeInBits() < Size::Infinity())
      return true;
   // Infinite-precision top intervals contain negative numbers, which cannot be
   // represented as unsigned
   else if (IsTopBitstring())
      return false;
   else {
      // Check if any range in the range set includes a negative value. Note
      // that infinite precision is used, which demands that all ranges [l..u]
      // in the range set fullfill l <= u.
      for (RangeIterator<const IntRangeList> r(GetRanges()); r; ++r) {
         if (r->L() < 0)
            return false;
      }
      return true;
   }
}

Integer LowerAND(const Integer & l1, const Integer & u1, const Integer & l2, const Integer & u2)
{
   // Use that fact that (A lower_and B)=~(~B upper_or ~A)
   Integer neg_l1 = ~l1;
   Integer neg_u1 = ~u1;
   Integer neg_l2 = ~l2;
   Integer neg_u2 = ~u2;

   // Get the answer (change places on u1 and l1 and on u2 and l2 due
   // to negation)
   return ~UpperOR(neg_u1, neg_l1, neg_u2, neg_l2);
}

Integer UpperAND(const Integer & l1, const Integer & u1, const Integer & l2, const Integer & u2)
{
   // The variable bit keeps track of the currently considered bit position by having that bit set and
   // all other bits cleared. It is here initialized by determining
   // the highest bit set for the positive range bounds and the highest bit cleared for the negative
   // range bounds, and then computing the maximum of these.
   Integer bit;
   {
      // Run through the range bounds and OR them together; if some of the values are negative,
      // they are first NOTed
      Integer bounds[4] = {l1, u1, l2, u2};
      Integer ored(0);
      for (unsigned int b = 0; b < 4; ++b)
         if (bounds[b] < 0)
            ored |= ~bounds[b];
         else
            ored |= bounds[b];
      // The highest bit set in the ORed values is set to the starting bit position
      bit = HighestBitSet(ored);
   }
   // A bit mask which has 1s in all the positions below and including the "bit" bit position
   Integer mask = (bit << 1) - 1;
   if (bit == 0)
      mask = Integer(0);

   // First take care of the "tail" bits, which are all bits that are more significant than
   // the "bit" bit. Since infinite precision is used, this can be seen as an infinite
   // bit string consisting of either all 0s or all 1s.

   Integer tail_mask = ~mask;
   Integer l1_tail = l1 & tail_mask;
   Integer u1_tail = u1 & tail_mask;
   Integer l2_tail = l2 & tail_mask;
   Integer u2_tail = u2 & tail_mask;

   // Initialize the result with the tail bits
   Integer result = u1_tail & u2_tail;

   // Create initial restricted intervals, starting with [sub_l1..sub_u1]
   Integer sub_l1, sub_u1, sub_l2, sub_u2;
   if (l1_tail == u1_tail)
   {
      sub_l1 = l1 & mask;
      sub_u1 = u1 & mask;
   }
   else if (u2_tail != 0 || u1 > u2)
   {
      sub_l1 = Integer(0);
      sub_u1 = u1 & mask;
   }
   else
      sub_l1 = sub_u1 = mask;

   // And then [sub_l2..sub_u2]
   if (l2_tail == u2_tail)
   {
      sub_l2 = l2 & mask;
      sub_u2 = u2 & mask;
   }
   else if (u1_tail != 0 || u2 > u1)
   {
      sub_l2 = Integer(0);
      sub_u2 = u2 & mask;
   }
   else
      sub_l2 = sub_u2 = mask;

   // The following loop considers all bits below and including the starting bit position.
   // The range bounds are before starting each new iteration restricted based on the result 
   // of ANDing the "bit" bits from the intervals.
   while (bit > 0)
   {
      // First test some simple cases
      if (sub_u1 == 0 || sub_u2 == 0)
         break;
      if (sub_u1 == mask)
      {
         result |= sub_u2;
         break;
      }
      if (sub_u2 == mask)
      {
         result |= sub_u1;
         break;
      }

      // No early exit was possible; extract the "bit" bits from the range bounds, update the result,
      // and then restrict the sub-ranges for the next iteration
      Integer l1_bit = sub_l1 & bit;
      Integer u1_bit = sub_u1 & bit;
      Integer l2_bit = sub_l2 & bit;
      Integer u2_bit = sub_u2 & bit;

      Integer anded = u1_bit & u2_bit;
      result |= anded;

      mask >>= 1;
      // Create a new sub-range [sub_l1..sub_u1] for the next iteration
      if (l1_bit == u1_bit)
      {
         sub_l1 &= mask;
         sub_u1 &= mask;
      }
      else if (anded == bit)
      {
         sub_l1 = Integer(0);
         sub_u1 &= mask;
      }
      else
         sub_l1 = sub_u1 = mask;

      // Restrict the [sub_l2..sub_u2] range for the next iteration
      if (l2_bit == u2_bit)
      {
         sub_l2 &= mask;
         sub_u2 &= mask;
      }
      else if (anded == bit)
      {
         sub_l2 = Integer(0);
         sub_u2 &= mask;
      }
      else
         sub_l2 = sub_u2 = mask;
      bit >>= 1;
   }

   return result;
}

Integer LowerOR(const Integer & l1, const Integer & u1, const Integer & l2, const Integer & u2)
{
   // Use that fact that (A lower_or B)=~(~B upper_and ~A)
   Integer neg_l1 = ~l1;
   Integer neg_u1 = ~u1;
   Integer neg_l2 = ~l2;
   Integer neg_u2 = ~u2;

   // Get the answer (change places on u1 and l1 and on u2 and l2 due
   // to negation)
   return ~UpperAND(neg_u1, neg_l1, neg_u2, neg_l2);
}

Integer UpperOR(const Integer &l1, const Integer &u1, const Integer &l2, const Integer &u2)
{
   // The variable bit keeps track of the currently considered bit position by having that bit set and
   // all other bits cleared. It is here initialized by determining
   // the highest bit set for the positive range bounds and the highest bit cleared for the negative
   // range bounds, and then computing the maximum of these.
   Integer bit;
   {
      // Run through the range bounds and OR them together; if some of the values are negative,
      // they are first NOTed
      Integer bounds[4] = {l1, u1, l2, u2};
      Integer ored(0);
      for (unsigned int b = 0; b < 4; ++b)
         if (bounds[b] < 0)
            ored |= ~bounds[b];
         else
            ored |= bounds[b];
      // The highest bit set in the ORed values is set to the starting bit position
      bit = HighestBitSet(ored);
   }
   // A bit mask which has 1s in all the positions below and including the "bit" bit position
   Integer mask = (bit << 1) - 1;
   if (bit == 0)
      mask = Integer(0);

   // First take care of the "tail" bits, which are all bits that are more significant than
   // the "bit" bit. Since infinite precision is used, this can be seen as an infinite
   // bit string consisting of either all 0s or all 1s.

   Integer tail_mask = ~mask;
   Integer l1_tail = l1 & tail_mask;
   Integer u1_tail = u1 & tail_mask;
   Integer l2_tail = l2 & tail_mask;
   Integer u2_tail = u2 & tail_mask;

   // Initialize the result
   Integer result = u1_tail | u2_tail;
   
   // Create initial restricted ranges, starting with [sub_l1..sub_u1]
   Integer sub_l1, sub_u1, sub_l2, sub_u2;
   if (l1_tail == u1_tail)
   {
      sub_l1 = l1 & mask;
      sub_u1 = u1 & mask;
   }
   else if (result == 0)
   {
      sub_l1 = Integer(0);
      sub_u1 = u1 & mask;
   }
   else
      sub_l1 = sub_u1 = mask;

   // Create initial sub-range [sub_l2..sub_u2]
   if (l2_tail == u2_tail)
   {
      sub_l2 = l2 & mask;
      sub_u2 = u2 & mask;
   }
   else if (result == 0)
   {
      sub_l2 = Integer(0);
      sub_u2 = u2 & mask;
   }
   else
      sub_l2 = sub_u2 = mask;

   // The following loop considers all bits below and including the starting bit position.
   // The range bounds are before starting each new iteration restricted based on the result 
   // of ORing the "bit" bits from the intervals.
   while (bit > 0)
   {
      // First test some simple cases, to try to make an early exit
      if (sub_u1 == 0)
      {
         result |= sub_u2;
         break;
      }
      if (sub_u2 == 0)
      {
         result |= sub_u1;
         break;
      }
      if (sub_u1 == mask || sub_u2 == mask)
      {
         result |= mask;
         break;
      }

      // If no early exit was possible, extract the "bit" bit from the range bounds, 
      // use this to update the result, and then further restrict the sub-ranges for
      // the next iteration
      Integer l1_bit = sub_l1 & bit;
      Integer u1_bit = sub_u1 & bit;
      Integer l2_bit = sub_l2 & bit;
      Integer u2_bit = sub_u2 & bit;

      Integer ored = u1_bit | u2_bit;
      result |= ored;

      // Now restrict the sub-ranges for the next iteration, starting with [sub_l1..sub_u1]

      mask >>= 1;
      if (l1_bit == u1_bit)
      {
         sub_l1 &= mask;
         sub_u1 &= mask;
      }
      else if (u2_bit == 0)
      {
         sub_l1 = Integer(0);
         sub_u1 &= mask;
      }
      else
         sub_l1 = sub_u1 = mask;

      // Create a new [sub_l2..sub_u2] range
      if (l2_bit == u2_bit)
      {
         sub_l2 &= mask;
         sub_u2 &= mask;
      }
      else if (u1_bit == 0)
      {
         sub_l2 = Integer(0);
         sub_u2 &= mask;
      }
      else
         sub_l2 = sub_u2 = mask;
      bit >>= 1;
   }

   return result;
}

Integer HighestBitSet(const Integer & bit_string)
{
   assert(bit_string >= 0);
   if (bit_string == 0) return Integer(0);
   Integer ret(1);
   ret <<= HighestBitPosSet(bit_string);
   return ret;
}

template <typename IntRep>
unsigned long long HighestBitPosSet(const IntRep & bit_string)
{
   assert(bit_string > 0);

   const IntRep _0(0), _1(1);

   // broad phase: find an interval [l..u) of bit indices to start with
   IntRep masked = bit_string;
   masked >>= 1;
   unsigned long long l = 0, u = 1;
   while (masked != _0) {
      masked >>= u;
      l = u;
      u *= 2;
   }

   // narrow phase: use binary search to locate bit
   while (true) {
      unsigned long long m = (l + u) / 2;
      masked = bit_string;
      masked >>= m;
      if (masked == _0) u = m;
      else if (masked == _1) return m;
      else l = m + 1;
   }

   assert(false); // should not reach this point
   return 0;
}

template unsigned long long HighestBitPosSet<unsigned>(const unsigned&); // for unit test

Value* Ops_IntInterval::Neg(const IntInterval* x)
{
   typedef IntInterval::IntRangeList IntRangeList;

   Size size_in_bits = x->SizeInBits();
   if (x->IsTopBitstring())
      return x->Copy();

   // Create temporary set of ranges
   IntRangeList rs1;
   x->GetSignedRanges(rs1);

   // To hold resulting ranges
   IntRangeList rs;

   // Iterate over all ranges in the range interval
   IntRangeList::const_iterator r1;
   FORALL(r1, rs1) {
      // Use the fact that NEG([l..u]) = [-u..-l]
      rs.push_back(IntRangeTpl<Integer>(-r1->U(), -r1->L()));
   }

   // Create a new Value from the list of ranges and the error value
   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::Add(const IntInterval* x, const IntInterval* y, const IntInterval* c)
{
   typedef IntInterval::IntRangeList IntRangeList;

   assert(x->SizeInBits() == y->SizeInBits() && c->SizeInBits() == 1);
   Size size_in_bits = x->SizeInBits();

   // top cases (most importantly, infinite-sized top values must be handled here)
   if (x->IsTopBitstring() || y->IsTopBitstring())
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   IntRangeList rs1, rs2;
   x->GetSignedRanges(rs1);
   y->GetSignedRanges(rs2);
   Integer c_l = c->LAsUnsigned(), c_u = c->UAsUnsigned();

   IntRangeList rs;

   // Iterate over all ranges in the first interval
   IntRangeList::const_iterator r1;
   FORALL(r1, rs1) {
      // Iterate over all ranges in the second interval
      IntRangeList::const_iterator r2;
      FORALL(r2, rs2) {
         // Apply ADD to two ranges
         Integer l = r1->L() + r2->L() + c_l;
         Integer u = r1->U() + r2->U() + c_u;

         rs.push_back(IntRangeTpl<Integer>(l, u));
      }
   }

   // Create a new abstract integer from the range set
   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::CAdd(const IntInterval* x, const IntInterval* y, const IntInterval* c)
{
   typedef IntInterval::IntRangeList IntRangeList;

   assert(x->SizeInBits() == y->SizeInBits() && c->SizeInBits() == 1);

   // Handle some straightforward cases
   if (x->IsTopBitstring() || y->IsTopBitstring())
      return domain->GetIntegerDomain()->CreateInteger(1);
   
   // Carry out from an addition of two infinite-sized values is always 0
   if (x->SizeInBits().IsInfinity())
      return domain->GetIntegerDomain()->CreateInteger(1, Integer(0));

   IntRangeList rs1, rs2;
   x->GetUnsignedRanges(rs1);
   y->GetUnsignedRanges(rs2);
   Integer c_l = c->LAsUnsigned(), c_u = c->UAsUnsigned();

   IntRangeList rs;
   // As a small optimization, these are declared only once, instead of in each iteration of the loop
   Integer l, u;
   unsigned long long carry_bit_pos = x->SizeInBits().AsBaseIntType();
   IntRangeList::const_iterator r1;
   FORALL(r1, rs1) 
   {
      IntRangeList::const_iterator r2;
      FORALL(r2, rs2) 
      {
         l = ((r1->L() + r2->L() + c_l) >> carry_bit_pos) & 1;
         u = ((r1->U() + r2->U() + c_u) >> carry_bit_pos) & 1;

         rs.push_back(IntRangeTpl<Integer>(l, u));
      }
   }

   // Create a new abstract integer from the range set
   return IntInterval::Create(1, rs);
}

Value* Ops_IntInterval::Sub(const IntInterval* x, const IntInterval* y, const IntInterval* c)
{
   // Use the fact that
   //    x - y - borrow = x + (-y) - borrow
   //                   = x + ~y + 1 - borrow
   //                   = x + ~y + ~borrow
   //                   = x + ~y + c
   // (Borrow is the inverted carry.)
   unique_ptr<Value> not_y( Not(y) );
   return x->Add(not_y.get(), c);
}

Value* Ops_IntInterval::CSub(const IntInterval* x, const IntInterval* y, const IntInterval* c)
{
   // Use the fact that
   //    x - y - borrow = x + (-y) - borrow
   //                   = x + ~y + 1 - borrow
   //                   = x + ~y + ~borrow
   //                   = x + ~y + c
   // (Borrow is the inverted carry.)
   unique_ptr<Value> not_y( Not(y) );
   return x->CAdd(not_y.get(), c);
}

Value* Ops_IntInterval::UMul(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;

   Size size_in_bits = x->SizeInBits() + y->SizeInBits();

   // Infinite-precision top intervals cannot be operated upon
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   // Get the (unsigned) ranges of the operands
   IntRangeList rs1, rs2;
   x->GetUnsignedRanges(rs1);
   y->GetUnsignedRanges(rs2);

   // To hold resulting ranges
   IntRangeList rs;

   Integer l1, u1, l2, u2, l, u;
   Integer l1_t_l2, l1_t_u2, u1_t_l2, u1_t_u2;

   // Iterate over all ranges in the first interval
   IntRangeList::const_iterator r1;
   FORALL(r1, rs1) {
      // Get lower and upper limits
      l1 = r1->L();
      u1 = r1->U();

      // Iterate over all ranges in the second interval
      IntRangeList::const_iterator r2;
      FORALL(r2, rs2) {
         // Get lower and upper limits
         l2 = r2->L();
         u2 = r2->U();

         l1_t_l2 = l1 * l2;
         l1_t_u2 = l1 * u2;
         u1_t_l2 = u1 * l2;
         u1_t_u2 = u1 * u2;

         // Calculate the smallest and largest values
         l = min4(l1_t_l2, l1_t_u2, u1_t_l2, u1_t_u2); // TODO: won't this always be == l1_t_l2? (since all values are unsigned)
         u = max4(l1_t_l2, l1_t_u2, u1_t_l2, u1_t_u2); // TODO: won't this always be == u1_t_u2? (since all values are unsigned)

         rs.push_back(IntRangeList::value_type(l,u));
      }
   }

   // Return the newly created interval
   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::SMul_Size(const IntInterval* x, const IntInterval* y, Size size_in_bits)
{
   typedef IntInterval::IntRangeList IntRangeList;

   // Infinite-precision top intervals cannot be operated upon
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   // Get the (signed) ranges of the operands
   IntRangeList rs1, rs2;
   x->GetSignedRanges(rs1);
   y->GetSignedRanges(rs2);

   // To hold resulting ranges
   IntRangeList rs;

   Integer l1, u1, l2, u2, l, u;
   Integer l1_t_l2, l1_t_u2, u1_t_l2, u1_t_u2;

   // Iterate over all ranges in the first interval
   IntRangeList::const_iterator r1;
   FORALL(r1, rs1) {
      // Get the lower and upper limits
      l1 = r1->L();
      u1 = r1->U();

      // Iterate over all ranges in the second interval
      IntRangeList::const_iterator r2;
      FORALL(r2, rs2) {
         // Get the lower and upper limits
         l2 = r2->L();
         u2 = r2->U();

         l1_t_l2 = l1 * l2;
         l1_t_u2 = l1 * u2;
         u1_t_l2 = u1 * l2;
         u1_t_u2 = u1 * u2;

         // Calculate the smallest and largest values
         l = min4(l1_t_l2, l1_t_u2, u1_t_l2, u1_t_u2);
         u = max4(l1_t_l2, l1_t_u2, u1_t_l2, u1_t_u2);

         rs.push_back(IntRangeList::value_type(l,u));
      }
   }

   // Return the newly created interval
   return IntInterval::Create(size_in_bits, rs);   
}

Value* Ops_IntInterval::UDiv(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;

   Size size_in_bits = x->SizeInBits();

   // Infinite-precision top intervals cannot be operated upon
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   IntRangeList rs1, rs2;
   x->GetUnsignedRanges(rs1);
   y->GetUnsignedRanges(rs2);

   Integer one(1);

   // Run through all the denominator intervals and check if they contain 0; if some
   // interval do, handle it appropriately
   for (IntRangeList::iterator r = rs2.begin(); r != rs2.end(); )
   {
      // If the interval contains 0, increase its lower bound by 1. The case where
      // the upper bound is 0 as well doesn't have to be considered, because in that
      // case the shrinked interval would become empty, and wouldn't be inserted back
      // into the range set
      if (r->L() == 0)
      {
         IntRangeTpl<Integer> right(one, r->U());
         if (right.U() - right.L() + one > 0)
            rs2.push_front(right);
         r = rs2.erase(r);
      }
      else
         ++r;
   }

   // To hold resulting ranges
   IntRangeList rs;

   // Some variables which are declared outside the loop, as a small optimization
   Integer l2, l1_div_l2, l1_div_u2, u1_div_l2, u1_div_u2, l, u;

   // Iterate over all ranges in the first interval
   IntRangeList::const_iterator r1;
   FORALL(r1, rs1) {
      // Iterate over all ranges in the second interval
      IntRangeList::const_iterator r2;
      FORALL(r2, rs2) {
         // Get the lower and upper limits
         const Integer & l1 = r1->L();
         const Integer & u1 = r1->U();

         l2 = r2->L();
         const Integer & u2 = r2->U();

         // Check whether the denominator may be 0
         if (l2 == 0)
            ++l2;
         // There is no need to test whether u2 == 0, since it has already been tested indirectly
         // in the first if statement above

         // Else, calculate the smallest and largest div values
         l1_div_l2 = l1 / l2;
         l1_div_u2 = l1 / u2;
         u1_div_l2 = u1 / l2;
         u1_div_u2 = u1 / u2;

         l = min4(l1_div_l2, l1_div_u2, u1_div_l2, u1_div_u2);
         u = max4(l1_div_l2, l1_div_u2, u1_div_l2, u1_div_u2);

         rs.push_back(IntRangeTpl<Integer>(l, u));
      }
   }

   // Return the newly created interval
   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::SDiv(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;
   
   Size size_in_bits = x->SizeInBits();

   // Infinite-precision top intervals cannot be operated upon
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   // Get ranges from the operands
   IntRangeList rs1, rs2;
   x->GetSignedRanges(rs1);
   y->GetSignedRanges(rs2);

   Integer minus_one(-1), zero(0), one(1);

   // Run through all the denominator intervals and check if they contain 0; if some
   // interval do, handle it appropriately
   for (IntRangeList::iterator r = rs2.begin(); r != rs2.end(); )
   {
      // If the denominator interval includes 0, split it into two intervals -
      // one containing the part below 0 and one containing the part above 0 -
      // and insert them at the beginning of rs2
      if (r->Includes(zero))
      {
         IntRangeTpl<Integer> left(r->L(), minus_one);
         if (left.U() - left.L() + 1 > 0)
            rs2.push_front(left);
         IntRangeTpl<Integer> right(one, r->U());
         if (right.U() - right.L() + 1 > 0)
            rs2.push_front(right);
         r = rs2.erase(r);
      }
      else
         ++r;
   }

   // Range set for the result
   IntRangeList rs;

   // Some variables which are declared outside the loop, as a small optimization
   Integer l1_div_l2, l1_div_u2, u1_div_l2, u1_div_u2, l, u;

   // Iterate over all ranges in the first interval
   IntRangeList::const_iterator r1;
   FORALL(r1, rs1) {
      // Iterate over all ranges in the second interval
      IntRangeList::iterator r2;
      FORALL(r2, rs2) {
         // Get the lower and upper limits
         const Integer & l1 = r1->L();
         const Integer & u1 = r1->U();

         // This assertion should not fire due to the previous loop above
         assert(!r2->Includes(Integer(0)));
         const Integer & l2 = r2->L();
         const Integer & u2 = r2->U();

         // Else, calculate the smallest and largest div values
         l1_div_l2 = l1 / l2;
         l1_div_u2 = l1 / u2;
         u1_div_l2 = u1 / l2;
         u1_div_u2 = u1 / u2;

         l = min4(l1_div_l2, l1_div_u2, u1_div_l2, u1_div_u2);
         u = max4(l1_div_l2, l1_div_u2, u1_div_l2, u1_div_u2);

         rs.push_back(IntRangeTpl<Integer>(l, u));
      }
   }

   // Return the newly created interval
   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::UMod(const IntInterval* x, const IntInterval* y)
{
   // This implementation relies on
   //    x % y = x - x / y * y,
   // i.e., the remainder of x / y. In case y contains only a single value (i.e., is not an interval),
   // this implementation should return the exact result, otherwise some overestimations may occur. If
   // y includes 0, this part is removed from the interval before the computation, since 0 is an invalid divisor.
   // In other words, any 0 in y is assumed to be due to overestimations in the analysis rather
   // than an invalid program.

   typedef IntInterval::IntRangeList IntRangeList;

   const Size size_in_bits = x->SizeInBits();

   // Infinite-precision top intervals cannot be operated upon
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   // Get (unsigned) ranges from the operands
   IntRangeList rs1, rs2, rs;
   x->GetUnsignedRanges(rs1);
   y->GetUnsignedRanges(rs2);

   Integer l2, l, u;
   const Integer _0(0), _1(1);

   // iterate through divisor ranges
   for (RangeIterator<const IntRangeList> r2(rs2); r2; ++r2)
   {
      // retrieve range and exclude 0
      const Integer &u2 = r2->U();
      if (u2 == _0) continue;
      l2 = r2->L();
      if (l2 == _0) ++l2;
      // iterate through dividend ranges
      for (RangeIterator<const IntRangeList> r1(rs1); r1; ++r1)
      {
         const Integer &l1 = r1->L(), &u1 = r1->U();
         l = l1 - u1 / l2 * u2;
         u = u1 - l1 / u2 * l2;
         // clamp resulting range
         if (l < _0) l = _0;
         if (u >= u2) u = u2 - _1;
         rs.push_back(IntRangeTpl<Integer>(l, u));
      }
   }

   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::SMod(const IntInterval* x, const IntInterval* y)
{
   // This implementation relies on
   //    x % y = x - x / y * y,
   // i.e., the remainder of x / y. Also, it uses the convention that the result gets the sign of x,
   // which means that the absolute value of y can be used as a simplication.
   // (The same convention is used in, e.g., C99, C++11, Pascal, and x86 assembly.)
   // In case y contains only a single value (i.e., is not an interval), this implementation should
   // return the exact result, otherwise some overestimations may occur. If y includes 0, this part 
   // is removed from the interval before the computation, since 0 is an invalid divisor. In other 
   // words, any 0 in y is assumed to be due to overestimations in the analysis rather than an invalid program.

   typedef IntInterval::IntRangeList IntRangeList;

   const Size size_in_bits = x->SizeInBits();

   // Infinite-precision top intervals cannot be operated upon
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   // Get (signed) ranges from the operands
   IntRangeList rs1, rs2, rs;
   x->GetSignedRanges(rs1);
   y->GetSignedRanges(rs2);

   Integer l1, u1, l1_, u1_, l2, u2, l, u, l_, u_;
   const Integer _0(0), _1(1), neg1(-1);

   // iterate through divisor ranges
   for (RangeIterator<const IntRangeList> r2(rs2); r2; ++r2)
   {
      // compute absolute value of divisor range and exclude 0
      l2 = r2->L(); u2 = r2->U();
      if (l2 >= _0) {   // [l2..u2] is positive
         if (l2 == _0) ++l2;
      }
      else if (u2 >= _0) {   // [l2..u2] contains positive & negative values
         u2 = max(abs(l2), abs(u2));
         l2 = _1;
      }
      else {   // [l2..u2] is negative
         swap(l2, u2);
         l2 = abs(l2);
         if (l2 == _0) ++l2;
         u2 = abs(u2);
      }
      if (l2 > u2) continue; // handle empty range

      // iterate through dividend ranges
      for (RangeIterator<const IntRangeList> r1(rs1); r1; ++r1)
      {
         l1 = r1->L(); u1 = r1->U();
         bool neg = false;
         // handle negative part of the range (if present)
         if (l1 < _0)
         {
            u1_ = min(neg1, u1);
            l = l1 - u1_ / u2 * l2;
            u = u1_ - l1 / l2 * u2;
            // clamp resulting range
            if (l <= -u2) l = -u2 + _1;
            if (u > _0) u = _0;
            neg = true;
         }
         // handle positive part of the range (if present)
         if (u1 >= _0)
         {
            l1_ = max(_0, l1);
            l_ = l1_ - u1 / l2 * u2;
            u_ = u1 - l1_ / u2 * l2;
            // clamp resulting range
            if (l_ < _0) l_ = _0;
            if (u_ >= u2) u_ = u2 - _1;
            // update range
            if (!neg) { l = l_; u = u_; }
            else {
               if (l_ < l) l = l_;
               if (u_ > u) u = u_;
            }
         }

         rs.push_back(IntRangeTpl<Integer>(l, u));
      }
   }

   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::Not(const IntInterval* x)
{
   typedef IntInterval::IntRangeList IntRangeList;

   if (x->IsTopBitstring())
      return x->Copy();

   // get ranges of x
   IntRangeList rs1;
   x->GetSignedRanges(rs1);

   // create new ranges
   IntRangeList rs;
   for (RangeIterator<IntRangeList> r1(rs1); r1; ++r1) {
      rs.push_back(IntRangeTpl<Integer>(~r1->U(), ~r1->L()));
      // consistency check
      assert(rs.back().L() <= rs.back().U());
   }

   return IntInterval::Create(x->SizeInBits(), rs);
}

Value* Ops_IntInterval::ZExt(const IntInterval* x, const Size& n)
{
   assert(n >= x->SizeInBits());
   if (n == x->SizeInBits())
      return x->Copy();
   IntInterval::IntRangeList rs;
   x->GetUnsignedRanges(rs);
   return IntInterval::Create(n, rs);
}

Value* Ops_IntInterval::SExt(const IntInterval* x, const Size& n)
{
   assert(n >= x->SizeInBits());
   if (n == x->SizeInBits())
      return x->Copy();
   IntInterval::IntRangeList rs;
   x->GetSignedRanges(rs);
   return IntInterval::Create(n, rs);
}

Value* Ops_IntInterval::LShift(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;

   Size size_in_bits = x->SizeInBits();

   // Infinite-precision top intervals cannot be operated upon
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   IntRangeList rsx, rsy, rs;
   x->GetSignedRanges(rsx);
   y->GetUnsignedRanges(rsy);
   Integer size_in_bits_(size_in_bits.AsBaseIntType());
   Integer l, u;
   for (RangeIterator<const IntRangeList> rx(rsx); rx; ++rx) {
      const Integer& lx = rx->L(), &ux = rx->U();
      for (RangeIterator<const IntRangeList> ry(rsy); ry; ++ry) {
         const Integer& ly = ry->L(), &uy = ry->U();
         // If the shift amount is larger than or equal to the number of bits, the
         // result is undefined (following �6.5.7 of the C99 standard)
         if (uy >= size_in_bits_)
            return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
         // If lx is negative, shift it as much as possible, otherwise shift it as little as possible
         if (lx < 0) l = lx << uy;
         else        l = lx << ly;
         // If ux is negative, shift it as little as possible, otherwise shift it as much as possible
         if (ux < 0) u = ux << ly;
         else        u = ux << uy;
         // Save the result
         rs.push_back(IntRangeTpl<Integer>(l, u));
      }
   }

   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::RShift(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;

   Size size_in_bits = x->SizeInBits();

   if (size_in_bits == Size::Infinity())
      return x->RShiftA(y);

   // Infinite-precision top intervals cannot be operated upon
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   // Get the range sets from the operands
   IntRangeList rs1, rs2;
   x->GetUnsignedRanges(rs1);
   y->GetUnsignedRanges(rs2);

   // To hold resulting ranges
   IntRangeList rs;
   Integer size_in_bits_(size_in_bits.AsBaseIntType());

   // Iterate over all ranges in the first interval
   for (IntRangeList::const_iterator r1 = rs1.begin(); r1 != rs1.end(); ++r1)
   {
      // Iterate over all ranges in the second interval
      for (IntRangeList::const_iterator r2 = rs2.begin(); r2 != rs2.end(); ++r2)
      {
         // If the shift amount is larger than or equal to the number of bits, the
         // result is undefined (following �6.5.7 of the C99 standard)
         if (r2->U() >= size_in_bits_)
            return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

         // Right shift lower limit as much as possible
         Integer l = r1->L() >> r2->U();

         // Right shift upper limit as little as possible
         Integer u = r1->U() >> r2->L();

         // Make some consistency check
         assert(l <= u);

         // Insert the resulting range.
         rs.push_back(IntRangeTpl<Integer>(l, u));
      }
   }

   // Create a new Value from the list of ranges and the error value
   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::RShiftA(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;

   Size size_in_bits = x->SizeInBits();

   // Infinite-precision top intervals cannot be operated upon
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   // Get the ranges from the operands
   IntRangeList rs1, rs2;
   x->GetSignedRanges(rs1);
   y->GetUnsignedRanges(rs2);

   // To hold resulting ranges
   IntRangeList rs;
   Integer size_in_bits_( size_in_bits.IsInfinity()? 0 : size_in_bits.AsBaseIntType() );

   // Iterate over all ranges in the first interval
   IntRangeList::const_iterator r1;
   FORALL(r1, rs1) {
      Integer l1 = r1->L(), u1 = r1->U();

      // Iterate over all ranges in the second interval
      IntRangeList::const_iterator r2;
      FORALL(r2, rs2) {
         Integer l2 = r2->L(), u2 = r2->U();

         // If the shift amount is larger than or equal to the number of bits, the
         // result is undefined (following �6.5.7 of the C99 standard)
         if (!size_in_bits.IsInfinity()) {
            if (u2 >= size_in_bits_)
               return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
         }

         // Compute lower and upper bounds on the result
         Integer l, u;
         if (l1 < 0) l = l1 >> l2;
         else        l = l1 >> u2;
         if (u1 < 0) u = u1 >> u2;
         else        u = u1 >> l2;
         assert(l <= u);

         rs.push_back(IntRangeTpl<Integer>(l, u));
      }
   }

   // Create a new Value from the list of ranges and the error value
   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::And(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;

   Size size_in_bits = x->SizeInBits();
   assert(size_in_bits == y->SizeInBits());

   // Infinite-precision top intervals cannot be operated upon
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   // Get the ranges of the operands
   IntRangeList rs1, rs2;
   x->GetSignedRanges(rs1);
   y->GetSignedRanges(rs2);

   // To hold resulting ranges
   IntRangeList rs;
   Integer l, u;

   // Iterate over all ranges in the first interval
   for (RangeIterator<IntRangeList> r1(rs1); r1; ++r1)
   {
      Integer &l1 = r1->L(), &u1 = r1->U();

      // Iterate over all ranges in the second interval
      for (RangeIterator<IntRangeList> r2(rs2); r2; ++r2)
      {
         Integer &l2 = r2->L(), &u2 = r2->U();

         // Calculate the lower and upper limit of the resulting interval
         l = LowerAND(l1, u1, l2, u2);
         u = UpperAND(l1, u1, l2, u2);
         assert(l <= u);

         rs.push_back(IntRangeTpl<Integer>(l, u));
      }
   }

   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::Or(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;

   Size size_in_bits = x->SizeInBits();
   assert(size_in_bits == y->SizeInBits());
   
   // Infinite-precision top intervals cannot be operated upon
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   // Get the ranges of the operands
   IntRangeList rs1, rs2;
   x->GetSignedRanges(rs1);
   y->GetSignedRanges(rs2);

   // To hold resulting ranges
   IntRangeList rs;
   Integer l, u;

   // Iterate over all ranges in the first interval
   for (RangeIterator<IntRangeList> r1(rs1); r1; ++r1)
   {
      Integer &l1 = r1->L(), &u1 = r1->U();

      // Iterate over all ranges in the second interval
      for (RangeIterator<IntRangeList> r2(rs2); r2; ++r2)
      {
         Integer &l2 = r2->L(), &u2 = r2->U();

         // Calculate the lower and upper limit of the resulting interval
         l = LowerOR(l1, u1, l2, u2);
         u = UpperOR(l1, u1, l2, u2);
         assert(l <= u);

         rs.push_back(IntRangeTpl<Integer>(l, u));
      }
   }

   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::XOr(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;

   assert(x->SizeInBits() == y->SizeInBits());

   Size size_in_bits = x->SizeInBits();

   // Infinite-precision top intervals cannot be operated upon
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   // Get the ranges of the operands
   IntRangeList rs1, rs2;
   x->GetSignedRanges(rs1);
   y->GetSignedRanges(rs2);

   // To hold resulting ranges
   IntRangeList rs;

   IntRangeList::const_iterator r1;
   FORALL(r1, rs1) {
      IntRangeList::const_iterator r2;
      FORALL(r2, rs2) {
         // Get the lower and upper limits (only positive values)
         Integer l1 = r1->L();
         Integer u1 = r1->U();
         Integer l2 = r2->L();
         Integer u2 = r2->U();

         // Use the fact that A xor B == ((~A) and B) or (A and (~B))
         IntInterval A(size_in_bits, l1, u1);
         IntInterval B(size_in_bits, l2, u2);
         unique_ptr<Value> nA(Not(&A));
         unique_ptr<Value> nB(Not(&B));
         unique_ptr<Value> nA_and_B(nA->And(&B));
         unique_ptr<Value> A_and_nB(A.And(nB.get()));
         unique_ptr<Value> res(nA_and_B->Or(A_and_nB.get()));

         // Extract the lower and upper values from res
         Integer l = dynamic_cast<IntInterval&>(*res.get()).LAsSigned();
         Integer u = dynamic_cast<IntInterval&>(*res.get()).UAsSigned();

         assert(l <= u);

         // Create one range, check for under or overflow and
         // insert in rs. Update potential error value due to
         // overflow.
         rs.push_back(IntRangeTpl<Integer>(l, u));
      }
   }

   // Create a new Value from the list of ranges and the error value
   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::Select(const IntInterval* x, const Size& m, const Size& n)
{
   typedef IntInterval::IntRangeList IntRangeList;

   assert(m <= n);
   assert(n < x->SizeInBits() || (n.IsInfinity() && x->SizeInBits().IsInfinity()));

   Size range_size = n - m + 1;
   unsigned long long m_ = m.AsBaseIntType();

   // Check some straightforward cases
   if (m_ == 0 && n == x->SizeInBits() - 1) return x->Copy();
   if (x->IsTopBitstring())
      return domain->GetIntegerDomain()->CreateInteger(range_size);

   // Create a mask that has ones in the selected bit positions (m to n)
   Integer mask(-1);
   if (!range_size.IsInfinity()) {
      mask <<= range_size.AsBaseIntType();
      mask = ~mask;
   }
   mask <<= m_;

   IntRangeList rs;
   x->GetSignedRanges(rs);

   IntRangeList resrs; // resulting ranges
   Integer l, u, resl, resu, _0(0), neg1(-1);

   for (RangeIterator<IntRangeList> r(rs); r; ++r) {
      l = r->L();
      u = r->U();
      // handle negative part
      if (l < _0) {
         u = min(neg1, u);
         resl = LowerAND(l, u, mask, mask);
         resu = UpperAND(l, u, mask, mask);
         resl >>= m_;
         resu >>= m_;
         resrs.push_back(IntRangeTpl<Integer>(resl, resu));
         u = r->U();
      }
      // handle positive part (>= 0)
      if (u >= _0) {
         l = max(_0, l);
         resl = LowerAND(l, u, mask, mask);
         resu = UpperAND(l, u, mask, mask);
         resl >>= m_;
         resu >>= m_;
         resrs.push_back(IntRangeTpl<Integer>(resl, resu));
      }
   }

   return IntInterval::Create(range_size, resrs);
}

Value* Ops_IntInterval::Conc(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;

   assert(y->SizeInBits() < Size::Infinity());

   Size size_in_bits = x->SizeInBits() + y->SizeInBits();

   // If x is an infinite sized top value, it cannot be operated upon
   // TODO: Shouldn't it be y, and not x?
   if (IsInfAndTopBitstring(*x))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   // Get the range sets from the operands. For y, the unsigned range set is used in
   // order to simplify the operation. Note that it is safe to compute the
   // unsigned representation of y, because y is guaranteed to be of finite
   // precision (due to the assertion above).
   IntRangeList x_rs, y_rs;
   x->GetSignedRanges(x_rs);
   y->GetUnsignedRanges(y_rs);

   IntRangeList rs;

   // Find out how much to shift the bits of x to the left
   unsigned long long x_shift = y->SizeInBits().AsBaseIntType();

   for (IntRangeList::const_iterator xr = x_rs.begin(); xr != x_rs.end(); ++xr)
   {
      for (IntRangeList::const_iterator yr = y_rs.begin(); yr != y_rs.end(); ++yr)
      {
         rs.push_back(*xr);
         rs.back().L() <<= x_shift;
         rs.back().U() <<= x_shift;
         rs.back().L() |= yr->L();
         rs.back().U() |= yr->U();
      }
   }

   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::Repeat(const IntInterval* x, const Size& n)
{
   assert(x->SizeInBits() == 1);
   if (x->IsTopBitstring())
      return domain->GetIntegerDomain()->CreateInteger(n, -1, 0);
   Integer val(x->LAsUnsigned() == 0? 0 : -1);
   return domain->GetIntegerDomain()->CreateInteger(n, val);
}

Value* Ops_IntInterval::Eq(const IntInterval* x, const IntInterval* y)
{
   assert(x->SizeInBits() == y->SizeInBits());

   // if x and y overlap, 1 should be included in the result
   if (Overlaps(x, y)) {
      if (x->IsSingleElem() && y->IsSingleElem())
         return domain->GetIntegerDomain()->CreateInteger(1, 1); // [1..1]
      else
         return domain->GetIntegerDomain()->CreateInteger(1); // [0..1]
}
   // otherwise, only 0 should be included in the result
   else
      return domain->GetIntegerDomain()->CreateInteger(1, 0); // [0..0]
}

Value* Ops_IntInterval::NEq(const IntInterval* x, const IntInterval* y)
{
   unique_ptr<Value> equality( Eq(x,y) ); 
   return equality->Not();
}

Value* Ops_IntInterval::SLT(const IntInterval* x, const IntInterval* y)
{
   assert(x->SizeInBits() == y->SizeInBits());

   // Infinite-precision top intervals cannot be operated upon
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(1);

   int lower = x->UAsSigned() >= y->LAsSigned()? 0 : 1;
   int upper = x->LAsSigned() <  y->UAsSigned()? 1 : 0;

   assert(lower <= upper || "Something is terribly wrong" == NULL);

   return domain->GetIntegerDomain()->CreateInteger(1, lower, upper);
}

Value* Ops_IntInterval::SLE(const IntInterval* x, const IntInterval* y)
{
   assert(x->SizeInBits() == y->SizeInBits());

   // Infinite-precision top intervals cannot be operated upon
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(1);

   int lower = x->UAsSigned() >  y->LAsSigned() ? 0 : 1;
   int upper = x->LAsSigned() <= y->UAsSigned() ? 1 : 0;

   assert(lower <= upper || "Something is terribly wrong" == NULL);

   return domain->GetIntegerDomain()->CreateInteger(1, lower, upper);
}

Value* Ops_IntInterval::SGE(const IntInterval* x, const IntInterval* y)
{
   // x >= y  <=>  y <= x
   return SLE(y, x);
}
   
Value* Ops_IntInterval::SGT(const IntInterval* x, const IntInterval* y)
{
   // x > y  <=>  y < x
   return SLT(y, x);
}

Value* Ops_IntInterval::ULT(const IntInterval* x, const IntInterval* y)
{
   assert(x->SizeInBits() == y->SizeInBits());

   // special handling of infinite-sized top integers
   if (IsInfAndTopBitstring(*x)) {
      // if y contains only 0, then no values of x are smaller
      if (y->IsSingleElem() && y->LAsUnsigned() == Integer(0))
         return domain->GetIntegerDomain()->CreateInteger(1, 0);
      else
         return domain->GetIntegerDomain()->CreateInteger(1);
   }
   else if (IsInfAndTopBitstring(*y))
      return domain->GetIntegerDomain()->CreateInteger(1);

   int lower = x->UAsUnsigned() >= y->LAsUnsigned() ? 0 : 1;
   int upper = x->LAsUnsigned() <  y->UAsUnsigned() ? 1 : 0;

   assert(lower <= upper || "Something is terribly wrong" == NULL);

   return domain->GetIntegerDomain()->CreateInteger(1, lower, upper);
}

Value* Ops_IntInterval::ULE(const IntInterval* x, const IntInterval* y)
{
   assert(x->SizeInBits() == y->SizeInBits());

   // special handling of infinite-sized top integers
   if (IsInfAndTopBitstring(*x))
      return domain->GetIntegerDomain()->CreateInteger(1);
   else if (IsInfAndTopBitstring(*y)) {
      // if x contains only 0, then it is smaller than or equal to all values in y
      if (x->IsSingleElem() && x->LAsUnsigned() == Integer(0))
         return domain->GetIntegerDomain()->CreateInteger(1, 1);
      else 
         return domain->GetIntegerDomain()->CreateInteger(1);
   }
   
   int lower = x->UAsUnsigned() >  y->LAsUnsigned()? 0 : 1;
   int upper = x->LAsUnsigned() <= y->UAsUnsigned()? 1 : 0;

   assert(lower <= upper || "Something is terribly wrong" == NULL);

   return domain->GetIntegerDomain()->CreateInteger(1, lower, upper);
}

Value* Ops_IntInterval::UGE(const IntInterval* x, const IntInterval* y)
{
   // x >= y  <=>  y <= x
   return ULE(y, x);
}
   
Value* Ops_IntInterval::UGT(const IntInterval* x, const IntInterval* y)
{
   // x > y  <=>  y < x
   return ULT(y, x);
}

Value* Ops_IntInterval::SToF(const IntInterval* x, const Size& m, const Size& n)
{
   typedef IntInterval::IntRangeList IntRangeList;

   if (x->IsTopBitstring())
   {
      // If the precision of this value is smaller than or equal to the size
      // of the long long data type, return the float interval [minint..maxint], where minint
      // is the smallest signed integer representable with this value's precision, and maxint is
      // the largest. This also implies that this value has finite precision. The motivation behind this
      // is that bignums need to be stored temporarily as a built-in data type before being cast
      // to a long double, and long long is (on most systems) the largest built-in signed integer
      // type available.
      if (x->SizeInBits() <= 8*sizeof(long long))
      {
         long double l = SmallestRepresentableSigned<Integer>(*x).As<long double>();
         long double u = LargestRepresentableSigned<Integer>(*x).As<long double>();
         return domain->GetFloatDomain()->CreateFloat(m, n, l, u);
}
      // Otherwise, just return a top floating-point value
      return domain->GetFloatDomain()->CreateFloat(m, n);
   }
   // Not bottom nor top value
   IntRangeList rs;
   x->GetSignedRanges(rs);
   long double l =  numeric_limits<long double>::infinity(),
               u = -numeric_limits<long double>::infinity();
   for (RangeIterator<IntRangeList> r(rs); r; ++r) {
      l = min(l, r->L().As<long double>());
      u = max(u, r->U().As<long double>());
   }
   return domain->GetFloatDomain()->CreateFloat(m, n, true, false, l, u);
}

Value* Ops_IntInterval::UToF(const IntInterval* x, const Size& m, const Size& n)
{
   typedef IntInterval::IntRangeList IntRangeList;
   
   if (x->IsTopBitstring())
   {
      // If the precision of this value is smaller than or equal to the size
      // of the unsigned long long data type, return the float interval [0..maxint], where maxint
      // is the largest unsigned integer representable with this value's precision.
      // This also implies that this value has finite precision. The motivation behind this
      // is that bignums need to be stored temporarily as a built-int variable before being converted to
      // a floating-point value, and unsigned long long is (on most systems) the largest built-in unsigned integer
      // type available.
      if (x->SizeInBits() <= 8*sizeof(unsigned long long))
      {
         long double l = 0;
         long double u = LargestRepresentableUnsigned<Integer>(*x).As<long double>();
         return domain->GetFloatDomain()->CreateFloat(m, n, l, u);
      }
      // Otherwise, just return a floating-point interval including all positive values
      return domain->GetFloatDomain()->CreateFloat(
         m, n, true, true, 0, numeric_limits<long double>::infinity());
   }
   // Not bottom nor top value
   IntRangeList rs;
   x->GetUnsignedRanges(rs);
   long double l =  numeric_limits<long double>::infinity(),
               u = -numeric_limits<long double>::infinity();
   for (RangeIterator<IntRangeList> r(rs); r; ++r) {
      l = min(l, r->L().As<long double>());
      u = max(u, r->U().As<long double>());
   }
   return domain->GetFloatDomain()->CreateFloat(m, n, true, false, l, u);
}

Value* Ops_IntInterval::If(const IntInterval* x, const Value* y, const Value* z)
{
   assert(x->SizeInBits() == 1);
   assert(y->SizeInBits() == z->SizeInBits());
   Size size_in_bits = y->SizeInBits();
   if (y->IsBottom() || z->IsBottom())
      return domain->CreateBottomValue(size_in_bits);
   // x == [0..1]
   if (x->IsTopBitstring())
      return y->LUB(z);
   // x == 1
   if (x->LAsUnsigned() == 1)
      return y->Copy();
   // x == 0
   return z->Copy();
}

Value* Ops_IntInterval::B2N(const IntInterval* x)
{
   return ZExt(x, Size::Infinity());
}

Value* Ops_IntInterval::Exp2(const IntInterval* x)
{
   typedef IntInterval::IntRangeList IntRangeList;
   
   if (x->IsTopBitstring()) {
      // If x is top, the lower bound of the result should be 1, since x can be at least 0, and 2^0 = 1.
      // However, since the result is of infinite size, no upper bound can be defined, and therefore a top value is
      // returned (which includes 0 as well) instead of a range.
      return domain->GetIntegerDomain()->CreateInteger(Size::Infinity());
   }

   Integer _1(1);
   IntRangeList rs1;
   x->GetUnsignedRanges(rs1);
   IntRangeList rs;
   for (RangeIterator<IntRangeList> r1(rs1); r1; ++r1)
      rs.push_back(IntRangeTpl<Integer>(_1 << r1->L(), _1 << r1->U()));
   return IntInterval::Create(Size::Infinity(), rs);
}

Value* Ops_IntInterval::ILog2(const IntInterval* x)
{
   typedef IntInterval::IntRangeList IntRangeList;

   // Find a set X of values such that for each value included in this interval that is
   // expressible as 2^x, where x is an integer, x is included in X
   IntRangeList rs, result;
   x->GetUnsignedRanges(rs);
   // Some variables which are created outside the loop for the sake of efficiency
   Integer l, u, b, _1(1);
   for (RangeIterator<IntRangeList> r(rs); r; ++r) {
      // Compute values pl and pu where pl is the smallest value such that
      // 2^pl >= r->L() and pu is the largest value such that 2^pu <= r->U()
      unsigned long long pl, pu;
      l = std::max<Integer>(r->L(), _1);
      pl = HighestBitPosSet(l);
      b = _1;
      b <<= pl;
      if (l != b)
         ++pl;
      u = r->U();
      if (u == 0)
         continue;
      pu = HighestBitPosSet(u);
      if (pl <= pu)
         result.push_back(IntRangeTpl<Integer>(Integer(pl), Integer(pu)));
}
   return IntInterval::Create(x->SizeInBits(), result);
}

Value* Ops_IntInterval::Restrict_NEq(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;
   
   // If y contains more than one concrete value, no value of x will be equal to all values in y. Also,
   // if x is of infinite size and top, the result can only be represented as a copy of x.
   if (!y->IsSingleElem() || IsInfAndTopBitstring(*x))
      return x->Copy();

   // Use the ranges of x as starting point
   IntRangeList ranges;
   x->GetSignedRanges(ranges);

   // Get the value of the single range in y
   Integer y_val = y->LAsSigned();

   for (RangeIterator<IntRangeList> rx(ranges); rx; ++rx)
   {
      if (rx->Includes(y_val))
      {
         // Split rx into two ranges, and remove the original rx
         Integer below_l = rx->L(), below_u = y_val - 1;
         Integer above_l = y_val + 1, above_u = rx->U();
         ranges.erase(rx);
         if (below_l <= below_u)
            ranges.push_back(IntRangeList::value_type(below_l, below_u));
         if (above_l <= above_u)
            ranges.push_back(IntRangeList::value_type(above_l, above_u));
         break;
      }
   }

   return IntInterval::Create(x->SizeInBits(), ranges);
}

Value* Ops_IntInterval::Restrict_SLT(const IntInterval* restr, const IntInterval* other)
{
   unique_ptr<Value> stencil( other->SExclUpperBelow() );
   return restr->GLB(stencil.get());
}

Value* Ops_IntInterval::Restrict_SLE(const IntInterval* restr, const IntInterval* other)
{
   unique_ptr<Value> stencil( other->SInclUpperBelow() );
   return restr->GLB(stencil.get());
}

Value* Ops_IntInterval::Restrict_SGE(const IntInterval* restr, const IntInterval* other)
{
   unique_ptr<Value> stencil( other->SInclLowerAbove() );
   return restr->GLB(stencil.get());
}

Value* Ops_IntInterval::Restrict_SGT(const IntInterval* restr, const IntInterval* other)
{
   unique_ptr<Value> stencil( other->SExclLowerAbove() );
   return restr->GLB(stencil.get());
}

Value* Ops_IntInterval::Restrict_ULT(const IntInterval* restr, const IntInterval* other)
{
   unique_ptr<Value> stencil( other->UExclUpperBelow() );
   return restr->GLB(stencil.get());
}

Value* Ops_IntInterval::Restrict_ULE(const IntInterval* restr, const IntInterval* other)
{
   unique_ptr<Value> stencil( other->UInclUpperBelow() );
   return restr->GLB(stencil.get());
}

Value* Ops_IntInterval::Restrict_UGE(const IntInterval* restr, const IntInterval* other)
{
   unique_ptr<Value> stencil( other->UInclLowerAbove() );
   return restr->GLB(stencil.get());
}

Value* Ops_IntInterval::Restrict_UGT(const IntInterval* restr, const IntInterval* other)
{
   unique_ptr<Value> stencil( other->UExclLowerAbove() );
   return restr->GLB(stencil.get());
}

Value* Ops_IntInterval::RevSMul(const IntInterval* r, const IntInterval* f, const Size& size_in_bits)
{
   typedef IntInterval::IntRangeList IntRangeList;

   // Here we want to compute a value x such that x * f = r.
   // For the concrete values, there are 5 cases:
   // 
   // 1. r != 0 and f != 0, f divides r:        x = r / f
   // 2. r != 0 and f != 0, f doesn't divide r: no such x exists (bottom)
   // 3. r != 0 and f = 0:                      no such x exists (bottom)
   // 4. r = 0 and f != 0:                      x = 0 (same result as 1)
   // 5. r = 0 and f = 0:                       all x are solutions (top)

   if (size_in_bits + f->SizeInBits() != r->SizeInBits())
      throw logic_error("RevSMul: the precision of the result must be the sum of the operands' precisions");

   // infinite-precision top intervals correspond to case 5
   if (IsInfAndTopBitstring(*r) || IsInfAndTopBitstring(*f))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   // get ranges from the operands
   IntRangeList rs_r, rs_f;
   r->GetSignedRanges(rs_r);
   f->GetSignedRanges(rs_f);

   Integer _0(0);

   // find out if r includes 0
   bool r_incl_0 = false;
   for (auto &ri : rs_r) {
      if (ri.Includes(_0)) {
         r_incl_0 = true;
         break;
      }
   }
   if (r_incl_0) {
      // if f too contains 0, this corresponds to case 5
      for (auto &ri : rs_f) {
         if (ri.Includes(_0))
            return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
      }
   } else {
      // if r doesn't include 0, we can remove any 0s included in f, since these
      // correspond to case 3
      Integer neg1(-1), _1(1);
      for (auto ri = rs_f.begin(), rn = rs_f.end(); ri != rn; ) {
         if (ri->Includes(_0)) {
            IntRangeTpl<Integer> left(ri->L(), neg1);
            if (left.U() - left.L() + _1 > _0)
               rs_f.push_front(left);
            IntRangeTpl<Integer> right(_1, ri->U());
            if (right.U() - right.L() + _1 > _0)
               rs_f.push_front(right);
            ri = rs_f.erase(ri);
         }
         else ++ri;
      }
   }

   // no we know that no ranges in rs_f include 0, i.e., cases 3 and 5 have been
   // taken care of

   IntRangeList rs;
   Integer l1_div_l2_l, l1_div_u2_l, u1_div_l2_l, u1_div_u2_l,
          l1_div_l2_u, l1_div_u2_u, u1_div_l2_u, u1_div_u2_u,
          abs_l1, abs_u1, abs_l2, abs_u2, l, u;

   // iterate over all ranges from r
   for (auto &r1 : rs_r) {
      // iterate over all ranges from f
      for (auto &r2 : rs_f) {
         assert(!r2.Includes(_0));

         // get the lower and upper limits
         const Integer &l1 = r1.L(), &u1 = r1.U();
         const Integer &l2 = r2.L(), &u2 = r2.U();

         abs_l1 = abs(l1); abs_u1 = abs(u1);
         abs_l2 = abs(l2); abs_u2 = abs(u2);

         // Candidates for upper bound are rounded down, and candidates for
         // lower bound are rounded up, since we are only interested in integer
         // solutions (which correspond to cases 1 and 4; we filter out
         // solutions corresponding to case 2).

         // Note: this strategy is not optimal. Theoretically, it would be
         // possible to remove more invalid solutions corresponding to case 2.
         // Preferably we should first remove from the ends of [l1..u1] all
         // values that are not divisible by any value in [l2..u2], and remove
         // from the ends of [l2..u2] all values that do not divide any value in
         // [l1..u1]. However, this seems like it could be expensive, if it
         // requires computing the set of divisors of l1,u1,etc.

         l1_div_l2_l = (abs_l1 + abs_l2 - 1) / abs_l2; // = ceil(abs(l1) / abs(l2))
         l1_div_l2_u = l1 / l2;
         if ((l1 < 0) ^ (l2 < 0)) { // (l1 < 0) && (0 <= l2) || (0 <= l1) && (l2 < 0)
            l1_div_l2_l = -l1_div_l2_l; // = floor(l1 / l2)
            swap(l1_div_l2_u,l1_div_l2_l);
         }
         // analogous reasoning for the remaining cases...

         l1_div_u2_l = (abs_l1 + abs_u2 - 1) / abs_u2;
         l1_div_u2_u = l1 / u2;
         if ((l1 < 0) ^ (u2 < 0)) {
            l1_div_u2_l = -l1_div_u2_l;
            swap(l1_div_u2_u,l1_div_u2_l);
         }

         u1_div_l2_l = (abs_u1 + abs_l2 - 1) / abs_l2;
         u1_div_l2_u = u1 / l2;
         if ((u1 < 0) ^ (l2 < 0)) {
            u1_div_l2_l = -u1_div_l2_l;
            swap(u1_div_l2_u,u1_div_l2_l);
         }

         u1_div_u2_l = (abs_u1 + abs_u2 - 1) / abs_u2;
         u1_div_u2_u = u1 / u2;
         if ((u1 < 0) ^ (u2 < 0)) {
            u1_div_u2_l = -u1_div_u2_l;
            swap(u1_div_u2_u,u1_div_u2_l);
         }

         l = min4(l1_div_l2_l, l1_div_u2_l, u1_div_l2_l, u1_div_u2_l);
         u = max4(l1_div_l2_u, l1_div_u2_u, u1_div_l2_u, u1_div_u2_u);

         if (l <= u)
            rs.push_back(IntRangeTpl<Integer>(l, u));
      }
   }

   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::RevUMul(const IntInterval* r, const IntInterval* f, const Size& size_in_bits)
{
   typedef IntInterval::IntRangeList IntRangeList;

   // Here we want to compute a value x such that x * f = r.
   // For the concrete values, there are 5 cases:
   // 
   // 1. r != 0 and f != 0, f divides r:        x = r / f
   // 2. r != 0 and f != 0, f doesn't divide r: no such x exists (bottom)
   // 3. r != 0 and f = 0:                      no such x exists (bottom)
   // 4. r = 0 and f != 0:                      x = 0 (same result as 1)
   // 5. r = 0 and f = 0:                       all x are solutions (top)

   if (size_in_bits + f->SizeInBits() != r->SizeInBits())
      throw logic_error("RevUMul: the precision of the result must be the sum of the operands' precisions");

   // infinite-precision top intervals correspond to case 5
   if (IsInfAndTopBitstring(*r) || IsInfAndTopBitstring(*f))
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   if (!r->HasUnsignedRep() || !f->HasUnsignedRep()) {
      // This is a "lazy" handling of the case where either r or f have infinite
      // precision and contain negative numbers. In the concrete case, if f < 0,
      // then there are no x such that x * f = r (they would all generate an
      // error), and if r < 0, there are no such x either. Thus, we could first
      // remove all negative numbers from f and r, and then proceed as usual.
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
   }

   // get ranges from the operands
   IntRangeList rs_r, rs_f;
   r->GetUnsignedRanges(rs_r);
   f->GetUnsignedRanges(rs_f);

   Integer _0(0);

   // find out if r includes 0
   bool r_incl_0 = false;
   for (auto &ri : rs_r) {
      if (ri.Includes(_0)) {
         r_incl_0 = true;
         break;
      }
   }

   if (r_incl_0) {
      // if f too contains 0, this corresponds to case 5
      for (auto &ri : rs_f) {
         if (ri.Includes(_0))
            return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
      }
   } else {
      // if r doesn't include 0, we can remove any 0s included in f, since these
      // correspond to case 3
      Integer _1(1);
      for (auto ri = rs_f.begin(), rn = rs_f.end(); ri != rn; ) {
         if (ri->L() == _0) {
            if (ri->U() == _0)
               ri = rs_f.erase(ri);
            else {
               *ri = IntRangeTpl<Integer>(_1, ri->U());
               ++ri;
            }
         }
         else ++ri;
      }
   }

   // no we know that no ranges in rs_f include 0, i.e., cases 3 and 5 have been
   // taken care of

   IntRangeList rs;
   Integer l1_div_l2_l, l1_div_u2_l, u1_div_l2_l, u1_div_u2_l,
          l1_div_l2_u, l1_div_u2_u, u1_div_l2_u, u1_div_u2_u, l, u;

   // iterate over all ranges from r
   for (auto &r1 : rs_r) {
      // iterate over all ranges from f
      for (auto &r2 : rs_f) {
         assert(!r2.Includes(_0));

         // get the lower and upper limits
         const Integer &l1 = r1.L(), &u1 = r1.U();
         const Integer &l2 = r2.L(), &u2 = r2.U();

         // Candidates for upper bound are rounded down, and candidates for
         // lower bound are rounded up, since we are only interested in integer
         // solutions (which correspond to cases 1 and 4; we filter out
         // solutions corresponding to case 2).

         // Note: this strategy is not optimal. Theoretically, it would be
         // possible to remove more invalid solutions corresponding to case 2.
         // Preferably we should first remove from the ends of [l1..u1] all
         // values that are not divisible by any value in [l2..u2], and remove
         // from the ends of [l2..u2] all values that do not divide any value in
         // [l1..u1]. However, this seems like it could be expensive, if it
         // requires computing the set of divisors of l1,u1,etc.

         l1_div_l2_l = (l1 + l2 - 1) / l2; // = ceil(l1 / l2)
         l1_div_l2_u = l1 / l2;

         l1_div_u2_l = (l1 + u2 - 1) / u2;
         l1_div_u2_u = l1 / u2;

         u1_div_l2_l = (u1 + l2 - 1) / l2;
         u1_div_l2_u = u1 / l2;

         u1_div_u2_l = (u1 + u2 - 1) / u2;
         u1_div_u2_u = u1 / u2;

         l = min4(l1_div_l2_l, l1_div_u2_l, u1_div_l2_l, u1_div_u2_l);
         u = max4(l1_div_l2_u, l1_div_u2_u, u1_div_l2_u, u1_div_u2_u);

         if (l <= u)
            rs.push_back(IntRangeTpl<Integer>(l, u));
      }
   }

   return IntInterval::Create(size_in_bits, rs);
}

Value* Ops_IntInterval::RevLShift1(const IntInterval* r, const IntInterval* y)
{
   // Compute a value x such that x << y = r

   assert(r->SizeInBits() == y->SizeInBits());
   Size size_in_bits = r->SizeInBits();

   Integer l, u;
   // If the operands are of infinite size, the derivation is straightforward, since
   // no bits can have been shifted off when shifting left. The smallest value of x is
   // the smallest value of r shifted as much as possible to the right, and the
   // largest value of x is the largest value of r shifted as little as possible to
   // the right.
   if (size_in_bits == Size::Infinity())
   {
      l = r->LAsSigned() >> y->UAsUnsigned();
      u = r->UAsSigned() >> y->LAsUnsigned();
   }
   else
   {
      // The smallest possible value of the sought x is the smallest value of r,
      // shifted to the right the number of positions given by the largest value of y, with
      // 0s inserted in all the shifted-in bit positions
      Integer y_u = y->UAsUnsigned();
      l = r->LAsUnsigned() >> y_u;

      // The largest possible value of the sought x is the largest value of r,
      // shifted to the right the number of positions given by the largest value of y, with
      // 1s inserted in all the shifted-in bit positions
      Integer mask = (Integer(1) << y_u) - 1;
      mask <<= size_in_bits.AsBaseIntType() - y_u.As<unsigned long long>();
      u = (r->UAsUnsigned() >> y_u) | mask;
   }
   return domain->GetIntegerDomain()->CreateInteger(size_in_bits, l, u);
}

Value* Ops_IntInterval::RevAnd(const IntInterval* r, const IntInterval* y)
{
   // A value x is computed and returned such that
   //    x & y = r,
   // or equivalently,
   //    x = r &r y,
   // where &r is the reverse AND function

   assert(r->SizeInBits() == y->SizeInBits());
   Size size_in_bits = r->SizeInBits();

   if (r->IsBottom())
   {
      // This is bottom and y is not bottom implicates that x is bottom
      if (!y->IsBottom())
         return domain->CreateBottomValue(size_in_bits);
      // If y is also bottom, the value of x can't be determined
      else
         return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
   }

   // TODO: Add support for reverse AND of infinite sized values
   assert(size_in_bits != Size::Infinity() || "Not supported yet" == 0);

   // Create upper and lower bounds.
   Integer upper(0);
   Integer lower(0);

   // Loop through all bits from most significant to least significant, and
   // create an upper and lower value to constrain with
   for (uint64_t bit = r->SizeInBits().AsBaseIntType() - 1; bit != uint64_t(-1); bit--) 
   {
      lower = lower << 1;
      upper = upper << 1;
      // Get the constraining bit (the value of the bit'th bit of r value)
      AbsBitValue constraining_bit = r->ValueOfBit(bit);
      // Get the argument value bit (the value of the bit'th bit of the value y)
      AbsBitValue arg_bit = y->ValueOfBit(bit);
      // Compare the bits and set the least significant bit accordingly
      if(constraining_bit == ONLY_ZERO && arg_bit == ONLY_ZERO) {
         lower += 0;
         upper += 1;
      }
      else if(constraining_bit == ONLY_ZERO && arg_bit == ONLY_ONE) {
         lower += 0;
         upper += 0;
      }
      else if(constraining_bit == ONLY_ONE && arg_bit == ONLY_ZERO) {
         return domain->CreateBottomValue(size_in_bits);
      }
      else if(constraining_bit == ONLY_ONE && arg_bit == ONLY_ONE) {
         lower += 1;
         upper += 1;
      }
      else if(constraining_bit == BOTH_ZERO_AND_ONE && arg_bit == ONLY_ZERO) {
         lower += 0;
         upper += 1;
      }
      else if(constraining_bit == BOTH_ZERO_AND_ONE && arg_bit == ONLY_ONE) {
         lower += 0;
         upper += 1;
      }
      else if(constraining_bit == ONLY_ZERO && arg_bit == BOTH_ZERO_AND_ONE) {
         lower += 0;
         upper += 1;
      }
      else if(constraining_bit == ONLY_ONE && arg_bit == BOTH_ZERO_AND_ONE) {
         lower += 1;
         upper += 1;
      }
      else if(constraining_bit == BOTH_ZERO_AND_ONE && arg_bit == BOTH_ZERO_AND_ONE) {
         lower += 0;
         upper += 1;
      }
   }
   Value* res = domain->GetIntegerDomain()->CreateInteger(size_in_bits,lower,upper);
   return res;
}

Value* Ops_IntInterval::RevOr(const IntInterval* r, const IntInterval* y)
{
   // A value x is computed and returned such that
   //    x | y = r,
   // or equivalently,
   //    x = r |r y,
   // where |r is the reverse bitwise OR

   assert(r->SizeInBits() == y->SizeInBits());
   Size size_in_bits = r->SizeInBits();

   if (r->IsBottom())
   {
      // r is bottom and y is not bottom implicates that x is bottom
      if (!y->IsBottom())
         return domain->CreateBottomValue(size_in_bits);
      // If y is also bottom, the value of x can't be determined
      else
         return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
   }

   // TODO: Add support for reverse OR of infinite sized values
   assert(size_in_bits != Size::Infinity() || "Not supported yet" == 0);

   // Create upper and lower bounds.
   Integer upper(0);
   Integer lower(0);

   // Loop through all bits, and create an upper and lower value to
   // constrain with
   for (uint64_t bit = r->SizeInBits().AsBaseIntType() - 1; bit != numeric_limits<uint64_t>::max(); bit--) {
      lower = lower << 1;
      upper = upper << 1;
      // Get the constraining bit
      AbsBitValue constraining_bit = r->ValueOfBit(bit);
      // Get the argument value bit
      AbsBitValue arg_bit = y->ValueOfBit(bit);
      // Compare the bits and set the least significant bit accordingly
      if(constraining_bit == ONLY_ZERO && arg_bit == ONLY_ZERO) {
         lower += 0;
         upper += 0;
      }
      else if(constraining_bit == ONLY_ZERO && arg_bit == ONLY_ONE) {
         return domain->CreateBottomValue(size_in_bits);
      }
      else if(constraining_bit == ONLY_ONE && arg_bit == ONLY_ZERO) {
         lower += 1;
         upper += 1;
      }
      else if(constraining_bit == ONLY_ONE && arg_bit == ONLY_ONE) {
         lower += 0;
         upper += 1;
      }
      else if(constraining_bit == BOTH_ZERO_AND_ONE && arg_bit == ONLY_ZERO) {
         lower += 0;
         upper += 1;
      }
      else if(constraining_bit == BOTH_ZERO_AND_ONE && arg_bit == ONLY_ONE) {
         lower += 0;
         upper += 1;
      }
      else if(constraining_bit == ONLY_ZERO && arg_bit == BOTH_ZERO_AND_ONE) {
         lower += 0;
         upper += 0;
      }
      else if(constraining_bit == ONLY_ONE && arg_bit == BOTH_ZERO_AND_ONE) {
         lower += 0;
         upper += 1;
      }
      else if(constraining_bit == BOTH_ZERO_AND_ONE && arg_bit == BOTH_ZERO_AND_ONE) {
         lower += 0;
         upper += 1;
      }
   }
   Value* res = domain->GetIntegerDomain()->CreateInteger(size_in_bits, lower, upper);
   return res;
}

Value* Ops_IntInterval::RevXOr(const IntInterval* r, const IntInterval* y)
{
   // A value x is computed and returned such that
   //    x ^ y = r,
   // or equivalently,
   //    x = r ^r y,
   // where ^r is the reverse bitwise XOR

   assert(r->SizeInBits() == y->SizeInBits());
   Size size_in_bits = r->SizeInBits();

   if (r->IsBottom())
   {
      // r is bottom and y is not bottom implicates that x is bottom
      if (!y->IsBottom())
         return domain->CreateBottomValue(size_in_bits);
      // If y is also bottom, the value of x can't be determined
      else
         return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
   }

   // TODO: Add support for reverse XOR of infinite sized values
   assert(size_in_bits != Size::Infinity() || "Not supported yet" == 0);

   // Create upper and lower bounds.
   Integer upper(0);
   Integer lower(0);

   // Loop through all bits, and create an upper and lower value to
   // constrain with
   for (uint64_t bit = r->SizeInBits().AsBaseIntType() - 1; bit != numeric_limits<uint64_t>::max(); bit--) {
      lower = lower << 1;
      upper = upper << 1;
      // Get the constraining bit
      AbsBitValue constraining_bit = r->ValueOfBit(bit);
      // Get the argument value bit
      AbsBitValue arg_bit = y->ValueOfBit(bit);
      // Compare the bits and set the least significant bit accordingly
      if(constraining_bit == ONLY_ZERO && arg_bit == ONLY_ZERO) {
         lower += 0;
         upper += 0;
      }
      else if(constraining_bit == ONLY_ONE && arg_bit == ONLY_ZERO) {
         lower += 1;
         upper += 1;
      }
      else if(constraining_bit == ONLY_ZERO && arg_bit == ONLY_ONE) {
         lower += 1;
         upper += 1;
      }
      else if(constraining_bit == ONLY_ONE && arg_bit == ONLY_ONE) {
         lower += 0;
         upper += 0;
      }
      else if(constraining_bit == BOTH_ZERO_AND_ONE && arg_bit == ONLY_ZERO) {
         lower += 0;
         upper += 1;
      }
      else if(constraining_bit == BOTH_ZERO_AND_ONE && arg_bit == ONLY_ONE) {
         lower += 0;
         upper += 1;
      }
      else if(constraining_bit == ONLY_ZERO && arg_bit == BOTH_ZERO_AND_ONE) {
         lower += 0;
         upper += 1;
      }
      else if(constraining_bit == ONLY_ONE && arg_bit == BOTH_ZERO_AND_ONE) {
         lower += 0;
         upper += 1;
      }
      else if(constraining_bit == BOTH_ZERO_AND_ONE && arg_bit == BOTH_ZERO_AND_ONE) {
         lower += 0;
         upper += 1;
      }
   }

   // Create the resulting integer
   Value* res = domain->GetIntegerDomain()->CreateInteger(size_in_bits, lower, upper);
   return res;
}

Value* Ops_IntInterval::RevSelect(const IntInterval* r, const Size& k, const Size& m)
{
   // Create an (abstract) bit string of size k of which this value is a substring
   // that starts at bit position m
   
   typedef IntInterval::IntRangeList IntRangeList;

   // Some assertions on the sizes
   assert(m < Size::Infinity());
   unsigned long long m_ = m.AsBaseIntType();
   assert(m_ + r->SizeInBits() <= k);

   // If this value is a finite substring of an infinite bit string, there is no upper bound
   // on the solution, so return top
   if (r->SizeInBits() < Size::Infinity() && k == Size::Infinity())
      return domain->GetIntegerDomain()->CreateInteger(Size::Infinity());

   // If the size of this value is finite, for simplicity a representation based on unsigned ranges
   // is used, otherwise signed ranges are used, since negative values of infinite precision
   // are not representable as unsigned values
   IntRangeList rs1;
   if (r->SizeInBits() == Size::Infinity())
      r->GetSignedRanges(rs1);
   else
      r->GetUnsignedRanges(rs1);
   IntRangeList result_rs;
   Integer l, u;
   // Create a mask that is used to insert 1s in bit positions [0..m) of the upper bound of all new ranges,
   // and, if r has finite precision, 1s in bit positions [(m + r->SizeInBits)..k)
   Integer u_mask = (Integer(1) << m_) - 1;
   if (r->SizeInBits() < Size::Infinity())
   {
      // s is where the suffix of the new upper bound bit string starts
      unsigned long long s = m_ + r->SizeInBits().AsBaseIntType();
      Integer u_mask_s = ((Integer(1) << (k.AsBaseIntType() - s)) - 1) << s;
      u_mask |= u_mask_s;
   }
   // Run through all ranges in the range set and create new ranges
   for (RangeIterator<IntRangeList> r1(rs1); r1; ++r1)
   {
      l = r1->L() << m_;
      u = (r1->U() << m_) | u_mask;
      result_rs.push_back(IntRangeTpl<Integer>(l, u));
   }
   return IntInterval::Create(k, result_rs);
}

bool Ops_IntInterval::Overlaps(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;
   
   if (x->SizeInBits() != y->SizeInBits()) return false;

   if (x->IsTopBitstring() || y->IsTopBitstring())
      return true;

   IntRangeList rs1, rs2;
   x->GetSignedRanges(rs1);
   y->GetSignedRanges(rs2);
   for (RangeIterator<const IntRangeList> r1(rs1); r1; ++r1)
      for (RangeIterator<const IntRangeList> r2(rs2); r2; ++r2)
         if (r1->Overlaps(&*r2))
            return true;

   return false;
}

bool Ops_IntInterval::Includes(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;
   
   if (x->SizeInBits() != y->SizeInBits()) return false;

   if (x->IsTopBitstring())
      return true;

   if (y->IsTopBitstring())
      return false;

   // Go through all ranges of y and check if they all are included in some range of x
   IntRangeList rs1, rs2;
   x->GetSignedRanges(rs1);
   y->GetSignedRanges(rs2);
   for (RangeIterator<const IntRangeList> r2(rs2); r2; ++r2)
   {
      bool included = false;
      for (RangeIterator<const IntRangeList> r1(rs1); r1; ++r1)
      {
         if (r1->Includes(&*r2))
         {
            included = true;
            break;
         }
      }
      if (!included)
         return false;
   }

   return true;
}

Value* Ops_IntInterval::LUB(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;
   
   assert(x->SizeInBits() == y->SizeInBits());
   Size size_in_bits = x->SizeInBits();
   
   if (x->IsTopBitstring() || y->IsTopBitstring())
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);

   // Create a LUB range which includes all signed ranges from both operands
   IntRangeList lub_rs;
   x->GetSignedRanges(lub_rs);
   y->GetSignedRanges(lub_rs);

   return IntInterval::Create(size_in_bits, lub_rs);   
}

Value* Ops_IntInterval::GLB(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;

   assert(x->SizeInBits() == y->SizeInBits());
   Size size_in_bits = x->SizeInBits();

   if (x->IsTopBitstring())
      return y->Copy();

   if (y->IsTopBitstring())
      return x->Copy();

   // Get the signed ranges from the operands
   IntRangeList rs1, rs2;
   x->GetSignedRanges(rs1);
   y->GetSignedRanges(rs2);

   // Compute the intersection of all ranges from rs1 and all ranges from rs2,
   // and add all resulting ranges with non-zero length to lub_rs
   IntRangeList glb_rs;
   Integer it_l, it_u;
   for (RangeIterator<const IntRangeList> r1(rs1); r1; ++r1)
   {
      for (RangeIterator<const IntRangeList> r2(rs2); r2; ++r2)
      {
         // Create the intersection of the ranges r1 and r2
         it_l = std::max(r1->L(), r2->L());
         it_u = std::min(r1->U(), r2->U());
         // If the intersection is non-empty, save the range
         if (it_u - it_l >= 0)
            glb_rs.push_back(IntRangeTpl<Integer>(it_l, it_u));
      }
   }
   return IntInterval::Create(size_in_bits, glb_rs);
}

Value* Ops_IntInterval::Widening(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;

   // To avoid unneccessary work
   // TODO: This might actually be a bit inefficient
   if(x->IsEqual(y)) {
      return x->Copy();
   }

   assert(x->SizeInBits() == y->SizeInBits());
   if (x->SizeInBits() == Size::Infinity()) {
     throw logic_error("Widening on infinite-sized operands is not supported yet");
   }

   Integer l1, u1, l2, u2, smallest, largest;
   {
      // Get the signed representations of the operands to determine which representation
      // (signed or unsigned) to base the operation on
      IntRangeList rs_x, rs_y;
      x->GetSignedRanges(rs_x);
      y->GetSignedRanges(rs_y);

      // If some of the signed representations consists of a single interval, use the
      // signed representations
      if (rs_x.size() == 1 || rs_y.size() == 1)
      {
         l1 = x->LAsSigned();
         u1 = x->UAsSigned();
         l2 = y->LAsSigned();
         u2 = y->UAsSigned();
         smallest = SmallestRepresentableSigned<Integer>(*x);
         largest = LargestRepresentableSigned<Integer>(*x);
      }
      // Otherwise, use the the unsigned representations
      else
      {
         l1 = x->LAsUnsigned();
         u1 = x->UAsUnsigned();
         l2 = y->LAsUnsigned();
         u2 = y->UAsUnsigned();
         smallest = SmallestRepresentableUnsigned<Integer>(*x);
         largest = LargestRepresentableUnsigned<Integer>(*x);
      }
   }

   // Compute the result [l..u]
   Integer l, u;
   if (!g_do_widening_stepwise) 
   {
      // Do the widening according to Jans PhD page 112
      l = l2 < l1? smallest : l1;
      u = u2 > u1? largest : u1;
   } 
   else 
   {
      // Do the widening in 3 steps, as minint / 4, minint / 2 and minint
      if (l2 < l1) 
      {
         Integer step1 = smallest >> 2;
         Integer step2 = smallest >> 1;
         if (l2 > step1)
            l = step1;
         else if (l2 > step2)
            l = step2;
         else
            l = smallest;
      } 
      else
         l = l1;

      // Do the widening in 3 steps, as maxint / 4, maxint / 2 and maxint
      if (u2 > u1) 
      {
         Integer step1 = largest >> 2;
         Integer step2 = largest >> 1;
         if (u2 < step1)
            u = step1;
         else if (u2 < step2)
            u = step2;
         else
            u = largest;
      } 
      else
         u = u1;
   }
   return IntInterval::Create(x->SizeInBits(), l, u);
}

Value* Ops_IntInterval::Narrowing(const IntInterval* x, const IntInterval* y)
{
   typedef IntInterval::IntRangeList IntRangeList;

   // To avoid unnecessary work
   // TODO: This might actually be a bit inefficient
   if(x->IsEqual(y)) {
      return x->Copy();
   }

   assert(x->SizeInBits() == y->SizeInBits());
   if (x->SizeInBits() == Size::Infinity())
      throw logic_error("Narrowing on infinite-sized operands is not supported yet");

   Integer l1, u1, l2, u2, smallest, largest;
   {
      // Get the signed representations of the operands to determine which representation
      // (signed or unsigned) to base the operation on
      IntRangeList rs_x, rs_y;
      x->GetSignedRanges(rs_x);
      y->GetSignedRanges(rs_y);

      // If some of the signed representations consists of a single interval, use the
      // signed representations
      if (rs_x.size() == 1 || rs_y.size() == 1)
      {
         l1 = x->LAsSigned();
         u1 = x->UAsSigned();
         l2 = y->LAsSigned();
         u2 = y->UAsSigned();
         smallest = SmallestRepresentableSigned<Integer>(*x);
         largest = LargestRepresentableSigned<Integer>(*x);
      }
      // Otherwise, use the the unsigned representations
      else
      {
         l1 = x->LAsUnsigned();
         u1 = x->UAsUnsigned();
         l2 = y->LAsUnsigned();
         u2 = y->UAsUnsigned();
         smallest = SmallestRepresentableUnsigned<Integer>(*x);
         largest = LargestRepresentableUnsigned<Integer>(*x);
      }
   }

   // To hold the result
   Integer l, u;

   // Do the narrowing according ot Jans PhD page 112
   if (!g_use_alternative_narrowing) 
   {
      if (l1 == smallest)
         l = l2;
      else
         l = l1;

      if (u1 == largest)
         u = u2;
      else
         u = u1;
   } 
   else 
   {
      // Alternative narrowing (slower but more accurate)  i1 N i2 = i2 ,if i2 subset i1. i1 otherwise
      if ((l2>=(l1/2) && u2<=u1) || ( u2<=(u1/2) && l2>=l1))
      {
         l=l2;
         u=u2;
      }
      else
      {
         l=l1;
         u=u1;
      }
   }
   // Create the integer and return it
   return IntInterval::Create(x->SizeInBits(), l, u);
}

// Members of IntervalIntDomain - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Value* IntervalIntDomain::CreateInteger(const Size& size_in_bits) const
{
   return new IntInterval(size_in_bits);
}

Value* IntervalIntDomain::CreateInteger(const Size& size_in_bits, int value) const
{
  // cerr << "IntIntervalValue IntervalIntDomain::CreateInteger size_in_bits: " << size_in_bits << " value: " << value << "\n";
  return new IntInterval(size_in_bits, Integer(value));
}

Value* IntervalIntDomain::CreateInteger(const Size& size_in_bits, const Integer& value) const
{
   return new IntInterval(size_in_bits, value);
}

Value* IntervalIntDomain::CreateInteger(const Size& size_in_bits, int lower, int upper) const
{
   if (upper < lower)
      return domain->CreateBottomValue(size_in_bits);
   return new IntInterval(size_in_bits, Integer(lower), Integer(upper));
}

Value* IntervalIntDomain::CreateInteger(const Size& size_in_bits,
                                          const Integer& lower,
                                          const Integer& upper) const
{
   if (upper < lower)
      return domain->CreateBottomValue(size_in_bits);
   return new IntInterval(size_in_bits, lower, upper);
}

