#ifndef INTEGERFACTORY_H_INCLUDED
#define INTEGERFACTORY_H_INCLUDED

class Value;
template <typename> class EInt;
typedef EInt<unsigned long long> Size;
class Integer;

/** Factory class used to create integers. Make a new subclass to introduce a new integer domain.
   @note All returned pointers should be deleted by the caller */
class IntegerDomain
{
public:
   virtual ~IntegerDomain() {}
   
   /** Create a TOP integer
      @note The returned pointer should be deleted by the caller */
   virtual Value* CreateInteger(const Size& size_in_bits) const = 0;

   /** @note The returned pointer should be deleted by the caller */
   virtual Value* CreateInteger(const Size& size_in_bits, int value) const = 0;

   /** @note The returned pointer should be deleted by the caller */
   virtual Value* CreateInteger(const Size& size_in_bits, const Integer& value) const = 0;

   /** @note The returned pointer should be deleted by the caller */
   virtual Value* CreateInteger(const Size& size_in_bits, int lower, int upper) const = 0;

   /** @note The returned pointer should be deleted by the caller */
   virtual Value* CreateInteger(const Size& size_in_bits, 
      const Integer& lower, const Integer& upper) const = 0;
};

#endif   // #ifndef INTEGERFACTORY_H_INCLUDED
