#include "OpPolicies.h"
#include "IntInterval.h"
#include "SymbIntervalPtrSet.h"
#include "FloatIntervalVal.h"
#include "ReadValue.h"

#include "globals.h"
#include "ValueDomain.h"

using namespace std;

static const IntInterval* extract_int(const Value* val, unique_ptr<const IntInterval>& newval)
{
   if (val->AsIntInterval())
      return (const IntInterval*)val;
   if (val->AsReadValue()) {
      unique_ptr<Value> fused( ((const ReadValue*)val)->Fuse() );
      const IntInterval* val_ = extract_int(fused.get(), newval);
      if (val_ && !newval.get()) {
         // val_ is the same as fused, so its ownership should be moved to newval
         fused.release();
         newval.reset(val_);
      }
      return val_;
   }
   if (val->AsBitstring() || val->IsTop()) {
      newval.reset( new IntInterval(val->SizeInBits()) );
      return newval.get();
   }
   return 0;
}

static const SymbIntervalPtrSet* extract_ptr(const Value* val, unique_ptr<const SymbIntervalPtrSet>& newval)
{
   if (val->AsSymbIntervalPtrSet())
      return (const SymbIntervalPtrSet*)val;
   if (val->AsReadValue()) {
      unique_ptr<Value> fused( ((const ReadValue*)val)->Fuse() );
      const SymbIntervalPtrSet* val_ = extract_ptr(fused.get(), newval);
      if (val_ && !newval.get()) {
         // val_ is the same as fused, so its ownership should be moved to newval
         fused.release();
         newval.reset(val_);
      }
      return val_;
   }
   if (val->IsTop()) {
      newval.reset( new SymbIntervalPtrSet(val->SizeInBits()) );
      return newval.get();
   }
   return 0;
}

static const OneFloatInterval8_23* extract_float8_23(const Value* val, unique_ptr<const OneFloatInterval8_23>& newval)
{
   if (val->AsOneFloatInterval8_23())
      return (const OneFloatInterval8_23*)val;
   if (val->AsReadValue()) {
      unique_ptr<Value> fused( ((const ReadValue*)val)->Fuse() );
      const OneFloatInterval8_23* val_ = extract_float8_23(fused.get(), newval);
      if (val_ && !newval.get()) {
         // val_ is the same as fused, so its ownership should be moved to newval
         fused.release();
         newval.reset(val_);
      }
      return val_;
   }
   if (val->AsBitstring() || val->IsTop()) {
      newval.reset( new OneFloatInterval8_23 );
      return newval.get();
   }
   return 0;
}

static const OneFloatInterval11_52* extract_float11_52(const Value* val, unique_ptr<const OneFloatInterval11_52>& newval)
{
   if (val->AsOneFloatInterval11_52())
      return (const OneFloatInterval11_52*)val;
   if (val->AsReadValue()) {
      unique_ptr<Value> fused( ((const ReadValue*)val)->Fuse() );
      const OneFloatInterval11_52* val_ = extract_float11_52(fused.get(), newval);
      if (val_ && !newval.get()) {
         // val_ is the same as fused, so its ownership should be moved to newval
         fused.release();
         newval.reset(val_);
      }
      return val_;
   }
   if (val->AsBitstring() || val->IsTop()) {
      newval.reset( new OneFloatInterval11_52 );
      return newval.get();
   }
   return 0;
}

/** Attempts to extract an IntInterval object from @a x, and calls @a func
   if this succeeds. Otherwise, a bottom value of size @a size_in_bits is returned. */
template <class Func>
static Value* UnIntOper(Func func, const Value* x, Size size_in_bits)
{
   const IntInterval* x_;
   unique_ptr<const IntInterval> newx;
   x_ = extract_int(x, newx);
   if (x_) return func(x_);
   else return domain->CreateBottomValue(size_in_bits);
}

/** Attempts to extract IntInterval objects from @a x and @a y, and calls @a func
   if this succeeds. Otherwise, a bottom value of size @a size_in_bits is returned. */
template <class Func>
static Value* BinIntOper(Func func, const Value* x, const Value* y, Size size_in_bits)
{
   const IntInterval *x_, *y_;
   unique_ptr<const IntInterval> newx, newy;
   if ((x_ = extract_int(x, newx)) && (y_ = extract_int(y, newy)))
      return func(x_, y_);
   else
      return domain->CreateBottomValue(size_in_bits);
}

template <class IntFunc, class PtrFunc>
static Value* BinIntPtrOper(IntFunc intfunc, PtrFunc ptrfunc, const Value* x, const Value* y, Size size_in_bits)
{
   const IntInterval *x_int, *y_int;
   const SymbIntervalPtrSet *x_ptr, *y_ptr; 
   unique_ptr<const IntInterval> newx_int, newy_int;
   unique_ptr<const SymbIntervalPtrSet> newx_ptr, newy_ptr;
   unique_ptr<Value> result, tmp;

   // try to extract the Value subtypes for which this operation is defined
   x_int = extract_int(x, newx_int);
   y_int = extract_int(y, newy_int);
   x_ptr = extract_ptr(x, newx_ptr);
   y_ptr = extract_ptr(y, newy_ptr);

   // int/int comparison
   if (x_int && y_int)
      result.reset( intfunc(x_int, y_int) );
   else
      result.reset( domain->CreateBottomValue(size_in_bits) );

   // ptr/ptr comparison
   if (x_ptr && y_ptr) {
      tmp.reset( ptrfunc(x_ptr, y_ptr) );
      result.reset( result->LUB( tmp.get() ) );
   }

   return result.release();
}


template <class FloatFunc8_23, class FloatFunc11_52>
Value* BinFloatOper(FloatFunc8_23 func8_23, FloatFunc11_52 func11_52, const Value* x, const Value* y, Size size_in_bits)
{
   Size opsize = x->SizeInBits();
   if (opsize == 32) {
      const OneFloatInterval8_23 *x_, *y_;
      unique_ptr<const OneFloatInterval8_23> newx, newy;
      if ((x_ = extract_float8_23(x, newx)) && (y_ = extract_float8_23(y, newy)))
         return func8_23(x_, y_);
      else
         return domain->CreateBottomValue(size_in_bits);
   }
   else if (opsize == 64) {
      const OneFloatInterval11_52 *x_, *y_;
      unique_ptr<const OneFloatInterval11_52> newx, newy;
      if ((x_ = extract_float11_52(x, newx)) && (y_ = extract_float11_52(y, newy)))
         return func11_52(x_, y_);
      else
         return domain->CreateBottomValue(size_in_bits);
   }
   else if ((x->AsBitstring() || x->AsTopValue()) && (y->AsBitstring() || y->AsTopValue())) {
      // unsupported size on operands; return a top bitstring
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
   }
   else
      return domain->CreateBottomValue(size_in_bits);
}

// members of OpPolicies_Interv -------------------------------------------------------------

Value* OpPolicies_Interv::Neg(const Value* x)
{
   return UnIntOper(&Ops_IntInterval::Neg, x, x->SizeInBits());
}

Value* OpPolicies_Interv::Add(const Value* x, const Value* y, const Value* c)
{
   const IntInterval *x_int, *y_int, *c_int;
   const SymbIntervalPtrSet *x_ptr, *y_ptr; 
   unique_ptr<const IntInterval> newx_int, newy_int, newc_int;
   unique_ptr<const SymbIntervalPtrSet> newx_ptr, newy_ptr;

   unique_ptr<Value> sum( domain->CreateBottomValue(x->SizeInBits()) ), tmp;

   // try to extract a IntInterval from c
   c_int = extract_int(c, newc_int);
   if (!c_int)
      return sum.release();

   // try to extract the Value subtypes for which this operation is defined
   x_int = extract_int(x, newx_int);
   y_int = extract_int(y, newy_int);
   x_ptr = extract_ptr(x, newx_ptr);
   y_ptr = extract_ptr(y, newy_ptr);

   // int/int addition
   if (x_int && y_int)
      sum.reset( Ops_IntInterval::Add(x_int, y_int, c_int) );

   // ptr/int addition
   if (x_ptr && y_int) {
      tmp.reset( Ops_SymbPointerSet<SymbIntervalPtrSet>::Add(x_ptr, y_int, c_int) );
      sum.reset( LUB(sum.get(), tmp.get()) );
   }
   if (x_int && y_ptr) {
      tmp.reset( Ops_SymbPointerSet<SymbIntervalPtrSet>::Add(x_int, y_ptr, c_int) );
      sum.reset( LUB(sum.get(), tmp.get()) );
   }

   return sum.release();
}

Value* OpPolicies_Interv::CAdd(const Value* x, const Value* y, const Value* c)
{
   const IntInterval *x_int, *y_int, *c_int;
   const SymbIntervalPtrSet *x_ptr, *y_ptr; 
   unique_ptr<const IntInterval> newx_int, newy_int, newc_int;
   unique_ptr<const SymbIntervalPtrSet> newx_ptr, newy_ptr;

   unique_ptr<Value> carryout( domain->CreateBottomValue(1) ), tmp;

   // try to extract a IntInterval from c
   c_int = extract_int(c, newc_int);
   if (!c_int)
      return carryout.release();

   // try to extract the Value subtypes for which this operation is defined
   x_int = extract_int(x, newx_int);
   y_int = extract_int(y, newy_int);
   x_ptr = extract_ptr(x, newx_ptr);
   y_ptr = extract_ptr(y, newy_ptr);

   // int/int addition
   if (x_int && y_int)
      carryout.reset( Ops_IntInterval::CAdd(x_int, y_int, c_int) );

   // ptr/int addition
   if (x_ptr && y_int) {
      tmp.reset( Ops_SymbPointerSet<SymbIntervalPtrSet>::CAdd(x_ptr, y_int, c_int) );
      carryout.reset( LUB(carryout.get(), tmp.get()) );
   }
   if (x_int && y_ptr) {
      tmp.reset( Ops_SymbPointerSet<SymbIntervalPtrSet>::CAdd(x_int, y_ptr, c_int) );
      carryout.reset( LUB(carryout.get(), tmp.get()) );
   }
   return carryout.release();
}

Value* OpPolicies_Interv::Sub(const Value* x, const Value* y, const Value* c)
{
   const IntInterval *x_int, *y_int, *c_int;
   const SymbIntervalPtrSet *x_ptr, *y_ptr; 
   unique_ptr<const IntInterval> newx_int, newy_int, newc_int;
   unique_ptr<const SymbIntervalPtrSet> newx_ptr, newy_ptr;

   unique_ptr<Value> diff( domain->CreateBottomValue(x->SizeInBits()) ), tmp;

   // try to extract a IntInterval from c
   c_int = extract_int(c, newc_int);
   if (!c_int)
      return diff.release();

   // try to extract the Value subtypes for which this operation is defined
   x_int = extract_int(x, newx_int);
   y_int = extract_int(y, newy_int);
   x_ptr = extract_ptr(x, newx_ptr);
   y_ptr = extract_ptr(y, newy_ptr);

   // int/int subtraction
   if (x_int && y_int)
      diff.reset( Ops_IntInterval::Sub(x_int, y_int, c_int) );

   // ptr/int subtraction
   if (x_ptr && y_int) {
      tmp.reset( Ops_SymbPointerSet<SymbIntervalPtrSet>::Sub(x_ptr, y_int, c_int) );
      diff.reset( LUB(diff.get(), tmp.get()) );
   }

   // ptr/ptr subtraction
   if (x_ptr && y_ptr) {
      tmp.reset( Ops_SymbPointerSet<SymbIntervalPtrSet>::Sub(x_ptr, y_ptr, c_int) );
      diff.reset( LUB(diff.get(), tmp.get()) );
   }

   return diff.release();
}

Value* OpPolicies_Interv::CSub(const Value* x, const Value* y, const Value* c)
{
   const IntInterval *x_int, *y_int, *c_int;
   const SymbIntervalPtrSet *x_ptr, *y_ptr; 
   unique_ptr<const IntInterval> newx_int, newy_int, newc_int;
   unique_ptr<const SymbIntervalPtrSet> newx_ptr, newy_ptr;

   unique_ptr<Value> carryout( domain->CreateBottomValue(1) ), tmp;

   // try to extract a IntInterval from c
   c_int = extract_int(c, newc_int);
   if (!c_int)
      return carryout.release();

   // try to extract the Value subtypes for which this operation is defined
   x_int = extract_int(x, newx_int);
   y_int = extract_int(y, newy_int);
   x_ptr = extract_ptr(x, newx_ptr);
   y_ptr = extract_ptr(y, newy_ptr);

   // int/int subtraction
   if (x_int && y_int)
      carryout.reset( Ops_IntInterval::CSub(x_int, y_int, c_int) );

   // ptr/int subtraction
   if (x_ptr && y_int) {
      tmp.reset( Ops_SymbPointerSet<SymbIntervalPtrSet>::CSub(x_ptr, y_int, c_int) );
      carryout.reset( LUB(carryout.get(), tmp.get()) );
   }

   // ptr/ptr subtraction
   if (x_ptr && y_ptr) {
      tmp.reset( Ops_SymbPointerSet<SymbIntervalPtrSet>::CSub(x_ptr, y_ptr, c_int) );
      carryout.reset( LUB(carryout.get(), tmp.get()) );
   }

   return carryout.release();
}

Value* OpPolicies_Interv::SMul(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::SMul, x, y, x->SizeInBits() + y->SizeInBits());
}

Value* OpPolicies_Interv::UMul(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::UMul, x, y, x->SizeInBits() + y->SizeInBits());
}

Value* OpPolicies_Interv::Mul_Trunc(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::Mul_Trunc, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::SDiv(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::SDiv, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::UDiv(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::UDiv, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::SMod(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::SMod, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::UMod(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::UMod, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::Eq(const Value* x, const Value* y)
{
   return BinIntPtrOper(&Ops_IntInterval::Eq, &Ops_SymbPointerSet<SymbIntervalPtrSet>::Eq, x, y, 1);
}

Value* OpPolicies_Interv::NEq(const Value* x, const Value* y)
{
   return BinIntPtrOper(&Ops_IntInterval::NEq, &Ops_SymbPointerSet<SymbIntervalPtrSet>::NEq, x, y, 1);
}

Value* OpPolicies_Interv::SLT(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::SLT, x, y, 1);
}

Value* OpPolicies_Interv::SLE(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::SLE, x, y, 1);
}

Value* OpPolicies_Interv::SGE(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::SGE, x, y, 1);
}

Value* OpPolicies_Interv::SGT(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::SGT, x, y, 1);
}

Value* OpPolicies_Interv::ULT(const Value* x, const Value* y)
{
   return BinIntPtrOper(&Ops_IntInterval::ULT, &Ops_SymbPointerSet<SymbIntervalPtrSet>::ULT, x, y, 1);
}

Value* OpPolicies_Interv::ULE(const Value* x, const Value* y)
{
   return BinIntPtrOper(&Ops_IntInterval::ULE, &Ops_SymbPointerSet<SymbIntervalPtrSet>::ULE, x, y, 1);
}

Value* OpPolicies_Interv::UGE(const Value* x, const Value* y)
{
   return BinIntPtrOper(&Ops_IntInterval::UGE, &Ops_SymbPointerSet<SymbIntervalPtrSet>::UGE, x, y, 1);
}

Value* OpPolicies_Interv::UGT(const Value* x, const Value* y)
{
   return BinIntPtrOper(&Ops_IntInterval::UGT, &Ops_SymbPointerSet<SymbIntervalPtrSet>::UGT, x, y, 1);
}

Value* OpPolicies_Interv::Not(const Value* x)
{
   if (x->AsReadValue()) return Ops_ReadValue::Not((const ReadValue*)x);
   return UnIntOper(&Ops_IntInterval::Not, x, x->SizeInBits());
}

Value* OpPolicies_Interv::And(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::And, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::Or(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::Or, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::XOr(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::XOr, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::LShift(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::LShift, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::RShift(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::RShift, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::RShiftA(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_IntInterval::RShiftA, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::ZExt(const Value* x, const Size& n)
{
   // ZExt is defined for both bitstring types and symbolic pointers
   if (x->AsIntInterval()) return Ops_IntInterval::ZExt((const IntInterval*)x, n);
   if (x->AsSymbIntervalPtrSet()) return Ops_SymbPointerSet<SymbIntervalPtrSet>::ZExt((const SymbIntervalPtrSet*)x, n);
   if (x->AsReadValue()) return Ops_ReadValue::ZExt((const ReadValue*)x, n);
   if (x->AsBitstring()) {
      IntInterval topint(x->SizeInBits());
      return Ops_IntInterval::ZExt(&topint, n);
   }
   if (x->IsTop()) return domain->CreateTopValue(n); // contains both bitstrings and symb. pointers
   return domain->CreateBottomValue(n);
}

Value* OpPolicies_Interv::SExt(const Value* x, const Size& n)
{
   const IntInterval* x_;
   unique_ptr<const IntInterval> newx;
   x_ = extract_int(x, newx);
   if (x_) return Ops_IntInterval::SExt(x_, n);
   else return domain->CreateBottomValue(n);
}

Value* OpPolicies_Interv::Repeat(const Value* x, const Size& n)
{
   const IntInterval* x_;
   unique_ptr<const IntInterval> newx;
   x_ = extract_int(x, newx);
   if (x_) return Ops_IntInterval::Repeat(x_, n);
   else return domain->CreateBottomValue(n);
}

Value* OpPolicies_Interv::Select(const Value* x, const Size& m, const Size& n)
{
   if (x->AsIntInterval()) return Ops_IntInterval::Select((const IntInterval*)x, m, n);
   if (x->AsReadValue()) return Ops_ReadValue::Select((const ReadValue*)x, m, n);
   Size size_in_bits = n - m + 1;
   if (x->AsBitstring()) {
      if (m == 0 && n == x->SizeInBits() - 1) return x->Copy();
      else return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
   }
   if (x->IsTop())
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
   // select is only defined for bitstring types
   return domain->CreateBottomValue(size_in_bits);
}

Value* OpPolicies_Interv::Conc(const Value* x, const Value* y)
{
   // this operation is only defined for bitstring types, but we have a special handling of ReadValue operands
   if (x->AsReadValue()) {
      if (y->AsReadValue()) return Ops_ReadValue::Conc_RR((const ReadValue*)x, (const ReadValue*)y);
      else return Ops_ReadValue::Conc_RV((const ReadValue*)x, y);
   }
   else if (y->AsReadValue())
      return Ops_ReadValue::Conc_VR(x, (const ReadValue*)y);
   else
      return BinIntOper(&Ops_IntInterval::Conc, x, y, x->SizeInBits() + y->SizeInBits());
}

Value* OpPolicies_Interv::FNeg(const Value* x)
{
   Size size_in_bits = x->SizeInBits();
   if (size_in_bits == 32) {
      const OneFloatInterval8_23* x_;
      unique_ptr<const OneFloatInterval8_23> newx;
      x_ = extract_float8_23(x, newx);
      if (x_) return Ops_OneFloatInterval<OneFloatInterval8_23>::FNeg(x_);
      return domain->CreateBottomValue(size_in_bits);      
   }
   else if (size_in_bits == 64) {
      const OneFloatInterval11_52* x_;
      unique_ptr<const OneFloatInterval11_52> newx;
      x_ = extract_float11_52(x, newx);
      if (x_) return Ops_OneFloatInterval<OneFloatInterval11_52>::FNeg(x_);
      return domain->CreateBottomValue(size_in_bits);      
   }
   else if (x->AsBitstring() || x->IsTop()) {
      // unsupported size - return a top bitstring
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
   }
   else
      return domain->CreateBottomValue(size_in_bits);
}

Value* OpPolicies_Interv::FAdd(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FAdd,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FAdd, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::FSub(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FSub,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FSub, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::FMul(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FMul,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FMul, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::FDiv(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FDiv,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FDiv, x, y, x->SizeInBits());
}

Value* OpPolicies_Interv::FToF(const Value* x, const Size& m, const Size& n)
{
   if (x->AsOneFloatInterval8_23()) return Ops_OneFloatInterval<OneFloatInterval8_23>::FToF((const OneFloatInterval8_23*)x, m, n);
   if (x->AsOneFloatInterval11_52()) return Ops_OneFloatInterval<OneFloatInterval11_52>::FToF((const OneFloatInterval11_52*)x, m, n);
   if (x->AsReadValue()) return Ops_ReadValue::TernOp_RSS<&Value::FToF>((const ReadValue*)x, m, n);
   Size size_in_bits = 1 + m + n;
   if (x->AsBitstring() || x->IsTop()) {
      if ((m == 8 && n == 23) || (m == 11 && n == 52))
         return domain->GetFloatDomain()->CreateFloat(m, n);
      else {
         // unsupported size for floats - return a top bitstring in the form of an int
         return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
      }
   }
   // the operation is only defined for bitstrings
   return domain->CreateBottomValue(size_in_bits);
}

Value* OpPolicies_Interv::FToS(const Value* x, const Size& n)
{
   if (x->AsOneFloatInterval8_23()) return Ops_OneFloatInterval<OneFloatInterval8_23>::FToS((const OneFloatInterval8_23*)x, n);
   if (x->AsOneFloatInterval11_52()) return Ops_OneFloatInterval<OneFloatInterval11_52>::FToS((const OneFloatInterval11_52*)x, n);
   if (x->AsReadValue()) return Ops_ReadValue::BinOp_RS<&Value::FToS>((const ReadValue*)x, n);
   if (x->AsBitstring() || x->IsTop()) return domain->GetIntegerDomain()->CreateInteger(n);
   // the operation is only defined for bitstrings
   return domain->CreateBottomValue(n);
}

Value* OpPolicies_Interv::FToU(const Value* x, const Size& n)
{
   if (x->AsOneFloatInterval8_23()) return Ops_OneFloatInterval<OneFloatInterval8_23>::FToU((const OneFloatInterval8_23*)x, n);
   if (x->AsOneFloatInterval11_52()) return Ops_OneFloatInterval<OneFloatInterval11_52>::FToU((const OneFloatInterval11_52*)x, n);
   if (x->AsReadValue()) return Ops_ReadValue::BinOp_RS<&Value::FToU>((const ReadValue*)x, n);
   if (x->AsBitstring() || x->IsTop()) return domain->GetIntegerDomain()->CreateInteger(n);
   // the operation is only defined for bitstrings
   return domain->CreateBottomValue(n);
}

Value* OpPolicies_Interv::SToF(const Value* x, const Size& m, const Size& n)
{
   const IntInterval* x_;
   unique_ptr<const IntInterval> newx;
   x_ = extract_int(x, newx);
   if (x_) return Ops_IntInterval::SToF(x_, m, n);
   else return domain->CreateBottomValue(1 + n + m);
}

Value* OpPolicies_Interv::UToF(const Value* x, const Size& m, const Size& n)
{
   const IntInterval* x_;
   unique_ptr<const IntInterval> newx;
   x_ = extract_int(x, newx);
   if (x_) return Ops_IntInterval::UToF(x_, m, n);
   else return domain->CreateBottomValue(1 + n + m);
}

Value* OpPolicies_Interv::FEq(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FEq,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FEq, x, y, 1);
}

Value* OpPolicies_Interv::FNEq(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FNEq,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FNEq, x, y, 1);
}

Value* OpPolicies_Interv::FLT(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FLT,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FLT, x, y, 1);
}

Value* OpPolicies_Interv::FLE(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FLE,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FLE, x, y, 1);
}

Value* OpPolicies_Interv::FGE(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FGE,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FGE, x, y, 1);
}

Value* OpPolicies_Interv::FGT(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FGT,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FGT, x, y, 1);
}

Value* OpPolicies_Interv::If(const Value* x, const Value* y, const Value* z)
{
   // here we assume that this operation is strict, which means there is no need to check y and z for bottom
   const IntInterval* x_;
   unique_ptr<const IntInterval> newx;
   x_ = extract_int(x, newx);
   if (x_) return Ops_IntInterval::If(x_, y, z);
   else return domain->CreateBottomValue(y->SizeInBits());
}

Value* OpPolicies_Interv::B2N(const Value* x)
{
   // TODO: should B2N be supported for symbolic pointers as well?
   return UnIntOper(&Ops_IntInterval::B2N, x, Size::Infinity());
}

Value* OpPolicies_Interv::Exp2(const Value* x)
{
   return UnIntOper(&Ops_IntInterval::Exp2, x, x->SizeInBits());
}

Value* OpPolicies_Interv::ILog2(const Value* x)
{
   return UnIntOper(&Ops_IntInterval::ILog2, x, x->SizeInBits());
}

bool OpPolicies_Interv::Includes(const Value* x, const Value* y)
{
   // IntInterval
   if (x->AsIntInterval() && y->AsIntInterval())
      return Ops_IntInterval::Includes((const IntInterval*)x, (const IntInterval*)y);

   // SymbIntervalPtrSet
   if (x->AsSymbIntervalPtrSet() && y->AsSymbIntervalPtrSet())
      return Ops_SymbPointerSet<SymbIntervalPtrSet>::Includes((const SymbIntervalPtrSet*)x, (const SymbIntervalPtrSet*)y);

   // OneFloatInterval8_23
   if (x->AsOneFloatInterval8_23() && y->AsOneFloatInterval8_23()) {
      return Ops_OneFloatInterval<OneFloatInterval8_23>::Includes(
         (const OneFloatInterval8_23*)x, (const OneFloatInterval8_23*)y);
   }

   // OneFloatInterval11_52
   if (x->AsOneFloatInterval11_52() && y->AsOneFloatInterval11_52()) {
      return Ops_OneFloatInterval<OneFloatInterval11_52>::Includes(
         (const OneFloatInterval11_52*)x, (const OneFloatInterval11_52*)y);
   }

   // ReadValue
   if (x->AsReadValue()) return Ops_ReadValue::BinOpBool_RV<&Value::Includes>((const ReadValue*)x, y);
   if (y->AsReadValue()) return Ops_ReadValue::BinOpBool_VR<&Value::Includes>(x, (const ReadValue*)y);

   if (x->SizeInBits() != y->SizeInBits()) return false;

   // bottom & top
   if (x->IsTop() || y->IsBottom()) return true;

   // Bitstring
   if (x->AsBitstring() && y->AsBitstring() && x->AsBitstring()->IsTopBitstring()) return true;

   // conservative answer
   return false;
}

bool OpPolicies_Interv::Overlaps(const Value* x, const Value* y)
{
   // IntInterval
   if (x->AsIntInterval() && y->AsIntInterval())
      return Ops_IntInterval::Overlaps((const IntInterval*)x, (const IntInterval*)y);

   // SymbIntervalPtrSet
   if (x->AsSymbIntervalPtrSet() && y->AsSymbIntervalPtrSet())
      return Ops_SymbPointerSet<SymbIntervalPtrSet>::Overlaps((const SymbIntervalPtrSet*)x, (const SymbIntervalPtrSet*)y);

   // OneFloatInterval8_23
   if (x->AsOneFloatInterval8_23() && y->AsOneFloatInterval8_23()) {
      return Ops_OneFloatInterval<OneFloatInterval8_23>::Overlaps(
         (const OneFloatInterval8_23*)x, (const OneFloatInterval8_23*)y);
   }

   // OneFloatInterval11_52
   if (x->AsOneFloatInterval11_52() && y->AsOneFloatInterval11_52()) {
      return Ops_OneFloatInterval<OneFloatInterval11_52>::Overlaps(
         (const OneFloatInterval11_52*)x, (const OneFloatInterval11_52*)y);
   }

   // ReadValue
   if (x->AsReadValue()) return Ops_ReadValue::BinOpBool_RV<&Value::Overlaps>((const ReadValue*)x, y);
   if (y->AsReadValue()) return Ops_ReadValue::BinOpBool_VR<&Value::Overlaps>(x, (const ReadValue*)y);

   if (x->SizeInBits() != y->SizeInBits()) return false;

   // bottom
   if (x->IsBottom() || y->IsBottom()) return false;

   // symbolic pointers and bitstrings never overlap
   if ((x->AsSymbPointer() && y->AsBitstring()) || (x->AsBitstring() && y->AsSymbPointer()))
      return false;

   // conservative answer
   return true;
}

Value* OpPolicies_Interv::GLB(const Value* x, const Value* y)
{
   // IntInterval
   if (x->AsIntInterval() && y->AsIntInterval())
      return Ops_IntInterval::GLB((const IntInterval*)x, (const IntInterval*)y);
   
   // SymbIntervalPtrSet
   if (x->AsSymbIntervalPtrSet() && y->AsSymbIntervalPtrSet())
      return Ops_SymbPointerSet<SymbIntervalPtrSet>::GLB((const SymbIntervalPtrSet*)x, (const SymbIntervalPtrSet*)y);
   
   // OneFloatInterval8_23
   if (x->AsOneFloatInterval8_23() && y->AsOneFloatInterval8_23())
      return Ops_OneFloatInterval<OneFloatInterval8_23>::GLB((const OneFloatInterval8_23*)x, (const OneFloatInterval8_23*)y);

   // OneFloatInterval11_52
   if (x->AsOneFloatInterval11_52() && y->AsOneFloatInterval11_52())
      return Ops_OneFloatInterval<OneFloatInterval11_52>::GLB((const OneFloatInterval11_52*)x, (const OneFloatInterval11_52*)y);

   // ReadValue
   if (x->AsReadValue() && y->AsReadValue())
      return Ops_ReadValue::GLB_RR((const ReadValue*)x, (const ReadValue*)y);

   // bottom cases
   if (x->IsBottom() || y->IsBottom()) return domain->CreateBottomValue(x->SizeInBits());

   // top cases
   if (x->IsTop()) return y->Copy();
   if (y->IsTop()) return x->Copy();

   // more ReadValue
   if (x->AsReadValue())
      return Ops_ReadValue::BinOp_RV<&Value::GLB>((const ReadValue*)x, y);
   if (y->AsReadValue())
      return Ops_ReadValue::BinOp_VR<&Value::GLB>(x, (const ReadValue*)y);

   // the GLB must be a subset of both x and y, so returning a copy of one
   // of the operands gives a safe over-approximation
   return x->Copy();
}

Value* OpPolicies_Interv::LUB(const Value* x, const Value* y)
{
   // IntInterval
   if (x->AsIntInterval() && y->AsIntInterval())
      return Ops_IntInterval::LUB((const IntInterval*)x, (const IntInterval*)y);
   
   // SymbIntervalPtrSet
   if (x->AsSymbIntervalPtrSet() && y->AsSymbIntervalPtrSet())
      return Ops_SymbPointerSet<SymbIntervalPtrSet>::LUB((const SymbIntervalPtrSet*)x, (const SymbIntervalPtrSet*)y);
   
   // OneFloatInterval8_23
   if (x->AsOneFloatInterval8_23() && y->AsOneFloatInterval8_23())
      return Ops_OneFloatInterval<OneFloatInterval8_23>::LUB((const OneFloatInterval8_23*)x, (const OneFloatInterval8_23*)y);

   // OneFloatInterval11_52
   if (x->AsOneFloatInterval11_52() && y->AsOneFloatInterval11_52())
      return Ops_OneFloatInterval<OneFloatInterval11_52>::LUB((const OneFloatInterval11_52*)x, (const OneFloatInterval11_52*)y);

   // ReadValue
   if (x->AsReadValue() && y->AsReadValue())
      return Ops_ReadValue::LUB_RR((const ReadValue*)x, (const ReadValue*)y);

   // bottom cases
   if (x->IsBottom()) return y->Copy();
   if (y->IsBottom()) return x->Copy();

   // more ReadValue
   if (x->AsReadValue())
      return Ops_ReadValue::BinOp_RV<&Value::LUB>((const ReadValue*)x, y);
   if (y->AsReadValue())
      return Ops_ReadValue::BinOp_VR<&Value::LUB>(x, (const ReadValue*)y);

   // if both operands are bitstrings, return a top bitstring
   if (x->AsBitstring() && y->AsBitstring())
      return domain->GetIntegerDomain()->CreateInteger(x->SizeInBits());

   return domain->CreateTopValue(x->SizeInBits());
}

Value* OpPolicies_Interv::Widening(const Value* x, const Value* y)
{
   // IntInterval
   if (x->AsIntInterval() && y->AsIntInterval())
      return Ops_IntInterval::Widening((const IntInterval*)x, (const IntInterval*)y);
   
   // SymbIntervalPtrSet
   if (x->AsSymbIntervalPtrSet() && y->AsSymbIntervalPtrSet())
      return Ops_SymbPointerSet<SymbIntervalPtrSet>::Widening((const SymbIntervalPtrSet*)x, (const SymbIntervalPtrSet*)y);
   
   // OneFloatInterval8_23
   if (x->AsOneFloatInterval8_23() && y->AsOneFloatInterval8_23())
      return Ops_OneFloatInterval<OneFloatInterval8_23>::Widening((const OneFloatInterval8_23*)x, (const OneFloatInterval8_23*)y);

   // OneFloatInterval11_52
   if (x->AsOneFloatInterval11_52() && y->AsOneFloatInterval11_52())
      return Ops_OneFloatInterval<OneFloatInterval11_52>::Widening((const OneFloatInterval11_52*)x, (const OneFloatInterval11_52*)y);

   // ReadValue
   if (x->AsReadValue()) return Ops_ReadValue::BinOp_RV<&Value::Widening>((const ReadValue*)x, y);
   if (y->AsReadValue()) return Ops_ReadValue::BinOp_VR<&Value::Widening>(x, (const ReadValue*)y);

   // bottom cases
   if (x->IsBottom()) return y->Copy();
   if (y->IsBottom()) return x->Copy();

   // TODO: Not sure what a suitable default action would be
   return domain->CreateTopValue(x->SizeInBits());
}

Value* OpPolicies_Interv::Narrowing(const Value* x, const Value* y)
{
   // IntInterval
   if (x->AsIntInterval() && y->AsIntInterval())
      return Ops_IntInterval::Narrowing((const IntInterval*)x, (const IntInterval*)y);
   
   // SymbIntervalPtrSet
   if (x->AsSymbIntervalPtrSet() && y->AsSymbIntervalPtrSet())
      return Ops_SymbPointerSet<SymbIntervalPtrSet>::Narrowing((const SymbIntervalPtrSet*)x, (const SymbIntervalPtrSet*)y);
   
   // OneFloatInterval8_23
   if (x->AsOneFloatInterval8_23() && y->AsOneFloatInterval8_23())
      return Ops_OneFloatInterval<OneFloatInterval8_23>::Narrowing((const OneFloatInterval8_23*)x, (const OneFloatInterval8_23*)y);

   // OneFloatInterval11_52
   if (x->AsOneFloatInterval11_52() && y->AsOneFloatInterval11_52())
      return Ops_OneFloatInterval<OneFloatInterval11_52>::Narrowing((const OneFloatInterval11_52*)x, (const OneFloatInterval11_52*)y);

   // ReadValue
   if (x->AsReadValue()) return Ops_ReadValue::BinOp_RV<&Value::Narrowing>((const ReadValue*)x, y);
   if (y->AsReadValue()) return Ops_ReadValue::BinOp_VR<&Value::Narrowing>(x, (const ReadValue*)y);

   // bottom cases
   if (x->IsBottom() || y->IsBottom()) return domain->CreateBottomValue(x->SizeInBits());

   // TODO: Not sure what a suitable default action would be
   return domain->CreateTopValue(x->SizeInBits());
}

Value* OpPolicies_Interv::Restrict_NEq(const Value* restr, const Value* other)
{
   return BinIntPtrOper(&Ops_IntInterval::Restrict_NEq, &Ops_SymbPointerSet<SymbIntervalPtrSet>::Restrict_NEq,
      restr, other, restr->SizeInBits());
}

Value* OpPolicies_Interv::Restrict_SLT(const Value* restr, const Value* other)
{
   return BinIntOper(&Ops_IntInterval::Restrict_SLT, restr, other, restr->SizeInBits());
}

Value* OpPolicies_Interv::Restrict_SLE(const Value* restr, const Value* other)
{
   return BinIntOper(&Ops_IntInterval::Restrict_SLE, restr, other, restr->SizeInBits());
}

Value* OpPolicies_Interv::Restrict_SGE(const Value* restr, const Value* other)
{
   return BinIntOper(&Ops_IntInterval::Restrict_SGE, restr, other, restr->SizeInBits());
}

Value* OpPolicies_Interv::Restrict_SGT(const Value* restr, const Value* other)
{
   return BinIntOper(&Ops_IntInterval::Restrict_SGT, restr, other, restr->SizeInBits());
}

Value* OpPolicies_Interv::Restrict_ULT(const Value* restr, const Value* other)
{
   return BinIntPtrOper(&Ops_IntInterval::Restrict_ULT, &Ops_SymbPointerSet<SymbIntervalPtrSet>::Restrict_ULT,
      restr, other, restr->SizeInBits());
}

Value* OpPolicies_Interv::Restrict_ULE(const Value* restr, const Value* other)
{
   return BinIntPtrOper(&Ops_IntInterval::Restrict_ULE, &Ops_SymbPointerSet<SymbIntervalPtrSet>::Restrict_ULE,
      restr, other, restr->SizeInBits());
}

Value* OpPolicies_Interv::Restrict_UGE(const Value* restr, const Value* other)
{
   return BinIntPtrOper(&Ops_IntInterval::Restrict_UGE, &Ops_SymbPointerSet<SymbIntervalPtrSet>::Restrict_UGE,
      restr, other, restr->SizeInBits());
}

Value* OpPolicies_Interv::Restrict_UGT(const Value* restr, const Value* other)
{
   return BinIntPtrOper(&Ops_IntInterval::Restrict_UGT, &Ops_SymbPointerSet<SymbIntervalPtrSet>::Restrict_UGT,
      restr, other, restr->SizeInBits());
}

Value* OpPolicies_Interv::Restrict_Select(const Value* restr, Size idx_first, const Value* result)
{
   unique_ptr<const IntInterval> newrestr_int;
   const IntInterval *restr_int = extract_int(restr, newrestr_int);
   if (restr_int) {
      if (result->AsIntInterval()) return Ops_IntInterval::RevSelect((const IntInterval*)result, restr->SizeInBits(), idx_first);
      if (result->AsReadValue()) return Ops_ReadValue::RevSelect((const ReadValue*)result, restr->SizeInBits(), idx_first);
      if (result->AsBitstring() && idx_first == 0 && result->SizeInBits() == restr->SizeInBits()) return result->Copy();
      if (result->AsBitstring() || result->IsTop()) {
         IntInterval topint(result->SizeInBits());
         return Ops_IntInterval::RevSelect(&topint, restr->SizeInBits(), idx_first);
      }
   }
   // since the select operation returns a bitstring, there are solutions to reverse select
   // only if 'result' is a bitstring
   return domain->CreateBottomValue(restr->SizeInBits());
}

Value* OpPolicies_Interv::RevSMul(const Value* result, const Value* op1, const Size& size_in_bits)
{
   const IntInterval *result_, *op1_;
   unique_ptr<const IntInterval> newresult, newop1;
   if ((result_ = extract_int(result, newresult)) && (op1_ = extract_int(op1, newop1)))
      return Ops_IntInterval::RevSMul(result_, op1_, size_in_bits);
   else
      return domain->CreateBottomValue(size_in_bits);
}

Value* OpPolicies_Interv::RevUMul(const Value* result, const Value* op1, const Size& size_in_bits)
{
   const IntInterval *result_, *op1_;
   unique_ptr<const IntInterval> newresult, newop1;
   if ((result_ = extract_int(result, newresult)) && (op1_ = extract_int(op1, newop1)))
      return Ops_IntInterval::RevUMul(result_, op1_, size_in_bits);
   else
      return domain->CreateBottomValue(size_in_bits);
}

Value* OpPolicies_Interv::RevAnd(const Value* result, const Value* op1)
{
   return BinIntOper(&Ops_IntInterval::RevAnd, result, op1, op1->SizeInBits());
}

Value* OpPolicies_Interv::RevOr(const Value* result, const Value* op1)
{
   return BinIntOper(&Ops_IntInterval::RevOr, result, op1, op1->SizeInBits());
}

Value* OpPolicies_Interv::RevXOr(const Value* result, const Value* op1)
{
   return BinIntOper(&Ops_IntInterval::RevXOr, result, op1, op1->SizeInBits());
}

Value* OpPolicies_Interv::RevLShift1(const Value* result, const Value* shamt)
{
   return BinIntOper(&Ops_IntInterval::RevLShift1, result, shamt, result->SizeInBits());
}
