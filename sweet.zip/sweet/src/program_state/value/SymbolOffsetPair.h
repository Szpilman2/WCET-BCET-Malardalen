#ifndef SYMBOLOFFSETPAIR_H_INCLUDED
#define SYMBOLOFFSETPAIR_H_INCLUDED

#include "Symbol.h"
#include <set>
#include <ostream>
#include <iostream> 

class SymbolOffsetPair : private std::pair<Symbol, unsigned long long>
{
public:
   class SetSOPComparator
   {
   public:
      bool operator ()(const SymbolOffsetPair & a,
                       const SymbolOffsetPair & b) const
      {
         return Symbol::SetSymbolComparator()(a.GetSymbol(), b.GetSymbol()) ||
            (a.GetSymbol() == b.GetSymbol() && a.GetOffset() < b.GetOffset());
      }
   };

   SymbolOffsetPair(const Symbol & symbol, unsigned long long offset)
      : std::pair<Symbol, unsigned long long>(symbol, offset) {}
   
   const Symbol & GetSymbol() const {return first;}

   void SetSymbol(const Symbol& symbol) {first = symbol;}

   unsigned long long GetOffset() const {return second;}

   void SetOffset(unsigned long long offset) {second = offset;}

   bool operator ==(const SymbolOffsetPair & other) const
      {return first == other.first && second == other.second;}

   std::ostream & Print(std::ostream & o = std::cout) const 
      {return o << '(' << first << ',' << second << ')';}
};

inline std::ostream & operator <<(std::ostream & o, const SymbolOffsetPair & sop) {return sop.Print(o);}

typedef std::set<SymbolOffsetPair, SymbolOffsetPair::SetSOPComparator> SymbolOffsetPairColl;

/** Forward iterator to access a collection of (symbol,offset) pairs */
class SopIterator
{
public:
   virtual ~SopIterator() {}

   /** Returns whether the collection contains only a single pair */
   virtual bool IsSingleton() = 0;

   /** To check if the end of the collection has been reached */
   virtual bool AtEnd() = 0;

   /** Returns the next pair in the collection and increments the iterator
       @pre  AtEnd() returns false
       @post The iterator has been incremented to the next pair */
   virtual SymbolOffsetPair GetNext() = 0;
};


#endif   // #ifndef SYMBOLOFFSETPAIR_H_INCLUDED
