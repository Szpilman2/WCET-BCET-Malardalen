#ifndef VALUE_H_INCLUDED
#define VALUE_H_INCLUDED

#include "ValueVisitor.h"
#include "ValueDomain.h"
#include "OpPolicies.h"
#include "program_state/LAU.h"
#include "program_state/Size.h"
#include "globals.h"
#include <ostream>

// Derived classes -----------
class BottomValue;
class TopValue;
class Bitstring;
class ClpValue;
class IntInterval;
class SymbPointer;
class SymbIntervalPtrSet;
class SymbClpPtrSet;
class FloatIntervalVal;
class OneFloatInterval8_23;
class OneFloatInterval11_52;
class ReadValue;

/** Superclass of all classes that represent abstract values. */
class Value
{
public:
   virtual ~Value() {}

   /** Make a deep copy of this value
       @note The caller is responsible for deleting the returned pointer */
   virtual Value * Copy() const = 0;

   /** Tests object equality between @a this and @a other.
       @note If two Value objects represent the same set of concrete values in different ways, e.g.,
             a top integer interval and a top float interval, this method returns false. For set
             equality, use IsSetEqual(). For the abstract equality operation, see Eq(). */
   virtual bool IsEqual(const Value * other) const = 0;

   /** Function implemented by all leaves in the class hierarchy, that calls the
      appropriate Visit* function on @a visitor */
   virtual void AcceptVisitor(ValueVisitor * visitor) const = 0;

   /** @name Dynamic casts to subclasses
       @{ */

   virtual const BottomValue* AsBottomValue() const {return 0;}

   virtual const TopValue* AsTopValue() const {return 0;}

   virtual const Bitstring* AsBitstring() const {return 0;}

   virtual const IntInterval* AsIntInterval() const {return 0;}

   virtual const ClpValue* AsClpValue() const {return 0;}

   virtual const SymbPointer* AsSymbPointer() const {return 0;}

   virtual const SymbIntervalPtrSet* AsSymbIntervalPtrSet() const {return 0;}

   virtual const SymbClpPtrSet* AsSymbClpPtrSet() const {return 0;}

   virtual const FloatIntervalVal* AsFloatIntervalVal() const {return 0;}

   virtual const OneFloatInterval8_23* AsOneFloatInterval8_23() const {return 0;}

   virtual const OneFloatInterval11_52* AsOneFloatInterval11_52() const {return 0;}

   virtual const ReadValue* AsReadValue() const {return 0;}

   /** @} */

   virtual Size SizeInBits() const {return _size_in_bits;}

   virtual Size SizeInLAU() const {return LAU::BitsToLAU(SizeInBits());}

   virtual bool IsBottom() const {return false;}

   virtual bool IsTop() const {return false;}

   /** Does the set contain only one element? */
   virtual bool IsSingleElem() const = 0;

   /* Abstract operations. Most of these operations simply call
      a corresponding method of the same name on the current OpPolicies object.
      The following macros simplify defining these methods. */

#  pragma push_macro("ABSOP_V")
#  define ABSOP_V(NAME) \
      Value *NAME() const { return domain->GetOpPolicies()->NAME(this); }

#  pragma push_macro("ABSOP_V_V")
#  define ABSOP_V_V(NAME,X) \
      Value *NAME(const Value *X) const { return domain->GetOpPolicies()->NAME(this, X); }

#  pragma push_macro("ABSOP_B_V")
#  define ABSOP_B_V(NAME,X) \
      bool NAME(const Value *X) const { return domain->GetOpPolicies()->NAME(this, X); }

#  pragma push_macro("ABSOP_V_S")
#  define ABSOP_V_S(NAME,X) \
      Value *NAME(const Size &X) const { return domain->GetOpPolicies()->NAME(this, X); }

#  pragma push_macro("ABSOP_V_VV")
#  define ABSOP_V_VV(NAME,X,Y) \
      Value *NAME(const Value *X, const Value *Y) const { return domain->GetOpPolicies()->NAME(this, X, Y); }

#  pragma push_macro("ABSOP_V_SS")
#  define ABSOP_V_SS(NAME,X,Y) \
      Value *NAME(const Size &X, const Size &Y) const { return domain->GetOpPolicies()->NAME(this, X, Y); }

   /** @name Arithmetic operations
       @{ */
   ABSOP_V(Neg)

   /** Compute x + y + c, where x is this object and c is the carry-in */
   ABSOP_V_VV(Add,  y, c)
   /** Compute the carry-out from x + y + c, where x is this object and c is the carry-in */
   ABSOP_V_VV(CAdd, y, c)
   ABSOP_V_VV(Sub,  y, c)
   ABSOP_V_VV(CSub, y, c)

   ABSOP_V_V(UMul, y)
   ABSOP_V_V(SMul, y)
   ABSOP_V_V(Mul_Trunc, y)
   ABSOP_V_V(UDiv, y)
   ABSOP_V_V(SDiv, y)
   ABSOP_V_V(UMod, y)
   ABSOP_V_V(SMod, y)
   /** @} */

   /** @name Comparison operations
       @{ */
   ABSOP_V_V(Eq, y)
   ABSOP_V_V(NEq, y)
   ABSOP_V_V(SLT, y)
   ABSOP_V_V(SLE, y)
   ABSOP_V_V(SGE, y)
   ABSOP_V_V(SGT, y)
   ABSOP_V_V(ULT, y)
   ABSOP_V_V(ULE, y)
   ABSOP_V_V(UGE, y)
   ABSOP_V_V(UGT, y)
   /** @} */

   /** @name Bitwise operations
       @{ */
   ABSOP_V(Not)
   ABSOP_V_V(And, y)
   ABSOP_V_V(Or,  y)
   ABSOP_V_V(XOr, y)
   ABSOP_V_V(LShift, y)
   ABSOP_V_V(RShift, y)
   ABSOP_V_V(RShiftA, y)
   ABSOP_V_S(ZExt, n);
   ABSOP_V_S(SExt, n);
   ABSOP_V_S(Repeat, n);
   ABSOP_V_SS(Select, m, n)
   ABSOP_V_V(Conc, y)
   /** @} */

   /** @name Floating-point operations
       @{ */
   ABSOP_V(FNeg)
   ABSOP_V_V(FAdd, y)
   ABSOP_V_V(FSub, y)
   ABSOP_V_V(FMul, y)
   ABSOP_V_V(FDiv, y)

   /** Treat this value as a floating-point value, and convert it to a new floating-point
      value with an exponent of size @p m bits and a fraction of size @p n bits */
   ABSOP_V_SS(FToF, m, n)

   ABSOP_V_S(FToS, n);
   ABSOP_V_S(FToU, n);

   /** Treat this value as a signed integer, and convert it to a floating-point
      value with an exponent of size @p m bits and a fraction of size @p n bits */
   ABSOP_V_SS(SToF, m, n)

   /** Treat this value as an unsigned integer, and convert it to a floating-point
      value with an exponent of size @p m bits and a fraction of size @p n bits */
   ABSOP_V_SS(UToF, m, n)
   /** @} */

   /** @name Floating-point comparison operations
       @{ */
   ABSOP_V_V(FEq, y)
   ABSOP_V_V(FNEq,y)
   ABSOP_V_V(FLT, y)
   ABSOP_V_V(FLE, y)
   ABSOP_V_V(FGE, y)
   ABSOP_V_V(FGT, y)
   /** @} */

   /** @name Miscellaneous
       @{ */
   ABSOP_V_VV(If, y, z)
   ABSOP_V(B2N)
   ABSOP_V(Exp2)

   /** Integer log2. Computes an interval X such that for each value included
       in this interval that is expressible as 2^x, where x is an integer, x is
       included in X */
   ABSOP_V(ILog2)
   /** @} */

   /** @name Set operations
       @{ */

   /** Returns whether this abstract value includes all the concrete values of @a y. In case
      this can't be determined, @c false is returned conservatively. */
   ABSOP_B_V(Includes, y)

   /** Returns whether this and @a y hold any common concrete values. In case this can't be
      determined, @c true is returned conservatively. */
   ABSOP_B_V(Overlaps, y)

   /** Returns whether @a this and @a y include the exact same set of concrete values.
       In case this can't be determined, @c false is returned conservatively. 
       @note This method may return true even if this->IsEqual(y) returns false, because the
             same set of concrete values may be represented in different ways. For the abstract
             equality operation, see Eq(). */
   bool IsSetEqual(const Value *y) const {
      // here we rely on the Includes() method, although we could be a bit more efficient
      return this->Includes(y) && y->Includes(this);
   }

   ABSOP_V_V(GLB, y)
   ABSOP_V_V(LUB, y)
   ABSOP_V_V(Widening, y)
   ABSOP_V_V(Narrowing, y)
   /** @} */

   /** @name Restriction
       @{ */

   /** Returns { x | x->NEq(y) == 1 or x->NEq(y) == [0..1] }, where x is a concrete value included
      in @a this and y is a concrete value included in @a other */
   ABSOP_V_V(Restrict_NEq, other)

   /** Returns { x | x->SLT(y) == 1 or x->SLT(y) == [0..1] }, where x is a concrete value included
      in @a this and y is a concrete value included in @a other */
   ABSOP_V_V(Restrict_SLT, other)

   /** Returns { x | x->SLE(y) == 1 or x->SLE(y) == [0..1] }, where x is a concrete value included
      in @a this and y is a concrete value included in @a other */
   ABSOP_V_V(Restrict_SLE, other)

   /** Returns { x | x->SGE(y) == 1 or x->SGE(y) == [0..1] }, where x is a concrete value included
      in @a this and y is a concrete value included in @a other */
   ABSOP_V_V(Restrict_SGE, other)

   /** Returns { x | x->SGT(y) == 1 or x->SGT(y) == [0..1] }, where x is a concrete value included
      in @a this and y is a concrete value included in @a other */
   ABSOP_V_V(Restrict_SGT, other)

   /** Returns { x | x->ULT(y) == 1 or x->ULT(y) == [0..1] }, where x is a concrete value included
      in @a this and y is a concrete value included in @a other */
   ABSOP_V_V(Restrict_ULT, other)

   /** Returns { x | x->ULE(y) == 1 or x->ULE(y) == [0..1] }, where x is a concrete value included
      in @a this and y is a concrete value included in @a other */
   ABSOP_V_V(Restrict_ULE, other)

   /** Returns { x | x->UGE(y) == 1 or x->UGE(y) == [0..1] }, where x is a concrete value included
      in @a this and y is a concrete value included in @a other */
   ABSOP_V_V(Restrict_UGE, other)

   /** Returns { x | x->UGT(y) == 1 or x->UGT(y) == [0..1] }, where x is a concrete value included
      in @a this and y is a concrete value included in @a other */
   ABSOP_V_V(Restrict_UGT, other)

   /** Returns a restricted version of 'this' such that
      select(this, idx_first, (result->SizeInBits() - idx_first - 1))
      returns 'result' */
   Value *Restrict_Select(Size idx_first, const Value *result) const {
      return domain->GetOpPolicies()->Restrict_Select(this, idx_first, result);
   }

   /** @} */

   /** @name Reverse operations
       @{ */
   Value *RevSMul(const Value *f, const Size &result_size) const {
      return domain->GetOpPolicies()->RevSMul(this, f, result_size);
   }

   Value *RevUMul(const Value *f, const Size &result_size) const {
      return domain->GetOpPolicies()->RevUMul(this, f, result_size);
   }

   ABSOP_V_V(RevAnd, y)
   ABSOP_V_V(RevOr,  y)
   ABSOP_V_V(RevXOr, y)

   /** Reverse left shift 1. Compute and return a value x such that x << y = this. */
   ABSOP_V_V(RevLShift1, y)
   /** @} */

   virtual Value *FExclUpperBelow() const {
      return domain->CreateBottomValue(SizeInBits());
   }

   virtual Value *FInclUpperBelow() const {
      return domain->CreateBottomValue(SizeInBits());
   }

   virtual Value *FInclLowerAbove() const {
      return domain->CreateBottomValue(SizeInBits());
   }

   virtual Value *FExclLowerAbove() const {
      return domain->CreateBottomValue(SizeInBits()); 
   }

#  pragma pop_macro("ABSOP_V")
#  pragma pop_macro("ABSOP_V_V")
#  pragma pop_macro("ABSOP_B_V")
#  pragma pop_macro("ABSOP_V_S")
#  pragma pop_macro("ABSOP_V_VV")
#  pragma pop_macro("ABSOP_V_SS")

   virtual std::ostream & Print(std::ostream & os = std::cout) const = 0;

protected:
   Value(Size size_in_bits) : _size_in_bits(size_in_bits) {}

private:
   Size _size_in_bits;
};

inline std::ostream & operator <<(std::ostream & os, const Value & value) {return value.Print(os);}
 
#endif // #ifndef VALUE_H_INCLUDED
