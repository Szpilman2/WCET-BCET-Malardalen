#ifndef TOPVALUE_H_INCL
#define TOPVALUE_H_INCL

#include "Value.h"
#include "ValueDomain.h"
#include "IntegerDomain.h"
#include "globals.h"
#include <memory>

class TopValue : public Value
{
public:
   TopValue(Size size_in_bits) : Value(size_in_bits) {}

   TopValue(const TopValue& other) : Value(other) {}

   // Abstract methods from Value ------------------------------------------------>

   TopValue* Copy() const { return new TopValue(*this); }

   const TopValue* AsTopValue() const /* override */ { return this; }

   void AcceptVisitor(ValueVisitor* visitor) const { visitor->VisitTopValue(*this); }

   bool IsEqual(const Value *) const;

   std::ostream &Print(std::ostream &os) const { return os << "top"; }

   // <----------------------------------------------------------------------------

   /** @name Queries
       @{ */

   virtual bool IsTop() const { return true; }
   
   bool IsSingleElem(void) const { return false; }

   /** @} */

   virtual Value *FExclUpperBelow() const;
   virtual Value *FInclUpperBelow() const;
   virtual Value *FInclLowerAbove() const;
   virtual Value *FExclLowerAbove() const;

};

#endif   // ifndef TOPVALUE_H_INCL
