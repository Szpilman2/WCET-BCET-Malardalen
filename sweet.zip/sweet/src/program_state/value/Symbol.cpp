#include "Symbol.h"

Symbol::Symbol(SymbRepr value, SymbSpaceRepr space)
: value(value), space(space)
{

}

bool Symbol::operator ==(const Symbol & other) const
{
   return value == other.value && space == other.space && annot == other.annot;
}

std::ostream & Symbol::Print(std::ostream & o) const
{
   if (!annot.empty())
      o << '"' << annot << '"';
   else
       o << value;
   return o << (space == 0? " (data)" : " (code)");
}
