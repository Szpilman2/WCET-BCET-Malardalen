#include "Bitstring.h"
#include "ValueDomain.h"
#include "FloatDomain.h"
#include "globals.h"

// TODO: temporary solution; these methods should be made members of OpPolicies instead

#define RESTRICT_FUNC(NAME)                                                  \
   Value* Bitstring::NAME() const {                                          \
      /* make a top float value and call this method on it */                \
      std::unique_ptr<Value> top_float;                                        \
      Size size_in_bits = this->SizeInBits();                                \
      if (size_in_bits == 32)                                                \
         top_float.reset( domain->GetFloatDomain()->CreateFloat(8, 23) );    \
      else if (size_in_bits == 64)                                           \
         top_float.reset( domain->GetFloatDomain()->CreateFloat(11, 52) );   \
      else                                                                   \
         return domain->CreateTopValue(size_in_bits); /* unsupported size */ \
      return top_float->NAME();                                              \
   }

RESTRICT_FUNC(FExclUpperBelow)
RESTRICT_FUNC(FInclUpperBelow)
RESTRICT_FUNC(FInclLowerAbove)
RESTRICT_FUNC(FExclLowerAbove)

