#ifndef SYMBINTERVALPTRSET_H_INCLUDED
#define SYMBINTERVALPTRSET_H_INCLUDED

#include "SymbPointerSet.h"

class IntInterval;
class SymbIntervalPtrSet;

template <>
class SymbPtrSetSubclassTraits<SymbIntervalPtrSet>
{
public:
   typedef IntInterval OffsetType;

   static const SymbIntervalPtrSet* CastToSubclass(const Value* value)
      {return value->AsSymbIntervalPtrSet();} 

   static const IntInterval* CastToOffsetType(const Value* value)
      {return value->AsIntInterval();}
};

class SymbIntervalPtrSet : public SymbPointerSet<SymbIntervalPtrSet>
{
public:
   typedef SymbPointerSet<SymbIntervalPtrSet> Baseclass;
   
   /** SopIterator subclass that employs lazy evaluation to avoid creating all
       (symbol,offset) pairs at once
       @see SymbIntervalPtrSet::GetIterator(), SopIterator */
   class LazyIterator;

   /** @copydoc SymbPointerSet<SymbIntervalPtrSet>::SymbPointerSet(const Size&) */
   SymbIntervalPtrSet(const Size & size_in_bits)
      : Baseclass(size_in_bits) {}

   /** @copydoc SymbPointerSet<SymbIntervalPtrSet>::SymbPointerSet(const Size&,const Symbol&,const Integer&) */
   SymbIntervalPtrSet(const Size & size_in_bits, const Symbol & symbol, const Integer & offset)
      : Baseclass(size_in_bits, symbol, offset) {}

   /** @copydoc SymbPointerSet<SymbIntervalPtrSet>::SymbPointerSet(const Size&,SymbolToOffset&) */
   SymbIntervalPtrSet(const Size & size_in_bits, SymbolToOffset & symbol_to_offset)
      : Baseclass(size_in_bits, symbol_to_offset) {}

   /** @copydoc SymbPointerSet<SymbIntervalPtrSet>::SymbPointerSet(const SymbIntervalPtrSet&) */
   SymbIntervalPtrSet(const SymbIntervalPtrSet& other)
      : Baseclass(other) {}

   virtual SymbIntervalPtrSet* Copy() const {return new SymbIntervalPtrSet(*this);}

   virtual void AcceptVisitor(ValueVisitor * visitor) const 
      {visitor->VisitSymbIntervalPtrSet(*this);}

   /** Dynamic cast */
   virtual const SymbIntervalPtrSet* AsSymbIntervalPtrSet() const {return this;}
   
private:
   /** @copydoc SymbPointer::GetIterator_Private */
   virtual SopIterator* GetIterator_Private() const;
};

#endif // SYMBINTERVALPTRSET_H_INCLUDED
