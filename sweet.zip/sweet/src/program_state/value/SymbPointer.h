#ifndef SYMBPOINTER_H_INCLUDED
#define SYMBPOINTER_H_INCLUDED

#include "SymbolOffsetPair.h"
#include "Value.h"
#include <vector>
#include <map>
#include <stdexcept>

class SymbMemory;
class FrameColl;

typedef std::map<Symbol, const Value *, Symbol::SetSymbolComparator> SymbolToOffset;

class SymbPointer : public Value
{
public:
   /** Simple default (symbol,offset) pair iterator
       @see SymbPointer::GetIterator */
   class DefaultIter : public SopIterator
   {
      SymbolOffsetPairColl coll;
      SymbolOffsetPairColl::iterator iter, end;

   public:
      DefaultIter(const SymbPointer& ptr) {
         ptr.GetSymbolOffsetPairs(coll);
         iter = coll.begin();
         end = coll.end();
      }

      /** @copydoc SopIterator::IsSingleton */
      virtual bool IsSingleton() { return coll.size() == 1; }

      /** @copydoc SopIterator::AtEnd */
      virtual bool AtEnd() { return iter == end; }

      /** @copydoc SopIterator::GetNext */
      virtual SymbolOffsetPair GetNext() { assert(iter != end); return *iter++; }
   };

   virtual ~SymbPointer() {}

   /** Dynamic cast */
   virtual const SymbPointer* AsSymbPointer() const {return this;}

   /** Returns whether this value includes all possible symbolic pointers
       @note This differs from Value::IsTop() in that it excludes bitstring values */
   virtual bool IsTopSymbPointer() const = 0;

   /** Returns a SopIterator to access all (symbol,offset) pairs in this pointer
       @pre  IsTopSymbPointer() returns false. If not, there would be infinitely many (symbol, offset) pairs
       @note The returned pointer should be deleted by the caller */
   SopIterator* GetIterator() const
   {
      if (this->IsTopSymbPointer())
         throw std::logic_error("Cannot retrieve (symbol, offset) pairs from TOP symbolic pointer");
      return GetIterator_Private();
   }

	/** Get all concrete (symbol, offset) pairs included in this pointer
		 @pre IsTopSymbPointer() returns false. If not, there would be infinitely many (symbol, offset) pairs */
   virtual void GetSymbolOffsetPairs(SymbolOffsetPairColl & sops) const = 0;

   /** Add the symbol(s) contained in this pointer to @p symbols
       @pre IsTopSymbPointer() returns false. If not, there would be infinitely many symbols. */
   virtual void GetSymbols(SymbolColl & symbols) const = 0;

   /** Retrieve this pointer's symbol-to-offset mappings
       @pre IsTopSymbPointer() returns false. If not, there would be infinitely many symbol-to-offset mappings.
       @note The returned value points to a newly allocated object which should be deleted by the caller */
   virtual SymbolToOffset * GetSymbolToOffset() const = 0;

   /** Returns whether the symbolic base of this pointer includes the symbol @a symbol */
   virtual bool IncludesSymbol(const Symbol & symbol) const = 0;

	/** Returns the offset associated with the symbol @p symbol
	    @note The returned value points to a newly allocated object which should be deleted by the caller */
   virtual Value * GetOffsetOfSymbol(const Symbol & symbol) const = 0;

	/** Get the number of symbols included in this pointer.
       @pre IsTopSymbPointer() returns false. If not, there would be infinitely many symbols. */
   virtual unsigned NrOfSymbols() const = 0;

   /** Reduce this pointer to only point inside the frames of @p frames, within @p offset_margin from
      the upper offset bounds of the frames. After the call, @p reduced tells whether the pointer needed
      to be reduced; if set to false, it means that an identical copy of @p this was returned. */
   virtual Value* ReduceToPointInsideFrames(const FrameColl& frames, Size offset_margin, bool& reduced) const = 0;

protected:
   // This is an interface class, which means that it should not be possible to
   // instantiate, so its constructors are made non-public
   SymbPointer(const Size & size_in_bits) : Value(size_in_bits) {}
   SymbPointer(const SymbPointer & copy_from) : Value(copy_from) {}

   /** Private overloadable implementation of GetIterator() */
   virtual SopIterator* GetIterator_Private() const { return new DefaultIter(*this); }
};

#endif // SYMBPOINTER_H_INCLUDED
