#include "FloatIntervalVal.h"
#include "ValueDomain.h"
#include "IntegerDomain.h"
#include "tools/DisassembledFloat.h"
#include "tools/Integer.h"
#include "tools/StrStream.h"
#include "globals.h"
#include <limits>

using namespace std;

template <typename FloatRep>
FloatInterval<FloatRep>::FloatInterval()
: FloatRepPair(-numeric_limits<FloatRep>::infinity(), numeric_limits<FloatRep>::infinity()),
  flags(INCL_NANANS | INCL_NAN)
{

}

template <typename FloatRep>
FloatInterval<FloatRep>::
FloatInterval(bool incl_NaNaNs, bool incl_NaN, const FloatRep & l, const FloatRep & u)
              : FloatRepPair(std::numeric_limits<FloatRep>::quiet_NaN(),
                             std::numeric_limits<FloatRep>::quiet_NaN()),
                             flags(0)

{
   if (incl_NaNaNs)
   {
      flags |= INCL_NANANS;
      FloatRepPair::first = l;
      FloatRepPair::second = u;
      assert(l == l);
      assert(u == u);
   }
   if (incl_NaN)
      flags |= INCL_NAN;
}
              
template <typename FloatRep>
bool FloatInterval<FloatRep>::IsTop() const
{
   if (!IncludesNaNaNs() || !IncludesNaN())
      return false;
   return L() == -numeric_limits<FloatRep>::infinity() &&
          U() ==  numeric_limits<FloatRep>::infinity();
}

template <typename FloatRep>
bool FloatInterval<FloatRep>::IncludesNegZero() const
{
   if (!IncludesNaNaNs()) return false;
   
   DisassembledFloat<FloatRep> dl = L();

   // If the entire interval lies to the left or to the right of -0, return false
   if (U() < 0) return false;
   if (dl.IsPosZero() || 0 < L()) return false;

   return true;
}

template <typename FloatRep>
bool FloatInterval<FloatRep>::IncludesPosZero() const
{
   if (!IncludesNaNaNs()) return false;
   
   DisassembledFloat<FloatRep> du = U();

   // If the entire interval lies to the left or to the right of +0, return false
   if (U() < 0 || du.IsNegZero()) return false;
   if (0 < L()) return false;

   return true;
}

template <typename FloatRep>
bool FloatInterval<FloatRep>::IncludesZero() const
{
   if (!IncludesNaNaNs()) return false;
   return L() <= 0 && 0 <= U();
}

template <typename FloatRep>
FloatRep & FloatInterval<FloatRep>::L()
{
   if (!IncludesNaNaNs())
      throw runtime_error("FloatInterval<FloatRep>::L: "
                          "The interval has no lower bound");
   return FloatRepPair::first;
}

template <typename FloatRep>
const FloatRep & FloatInterval<FloatRep>::L() const
{
   if (!IncludesNaNaNs())
      throw runtime_error("FloatInterval<FloatRep>::L: "
                          "The interval has no lower bound");
   return FloatRepPair::first;
}
   
template <typename FloatRep>
FloatRep & FloatInterval<FloatRep>::U()
{
   if (!IncludesNaNaNs())
      throw runtime_error("FloatInterval<FloatRep>::U: "
                          "The interval has no upper bound");
   return FloatRepPair::second;
}

template <typename FloatRep>
const FloatRep & FloatInterval<FloatRep>::U() const
{
   if (!IncludesNaNaNs())
      throw runtime_error("FloatInterval<FloatRep>::U: "
                          "The interval has no upper bound");
   return FloatRepPair::second;
}

template <typename FloatRep>
bool FloatInterval<FloatRep>::
operator ==(const FloatInterval<FloatRep> & other) const
{
   if (this->flags != other.flags)
      return false;
   if (this->IncludesNaNaNs())
   {
      if (!other.IncludesNaNaNs())
         return false;
      if (this->L() != other.L() || this->U() != other.U())
         return false;
   }
   return true;
}

template <typename FloatRep>
std::ostream & FloatInterval<FloatRep>::Print(std::ostream & os) const
{
   bool inclNaNaNs = IncludesNaNaNs(), inclNaN = IncludesNaN();
   if (inclNaNaNs) {
      const FloatRep inf = std::numeric_limits<FloatRep>::infinity(), ninf = -inf;
      const FloatRep &l = L(), &u = U();
      if (l != u) {
         os << '[';
         if (l == ninf)    os << "-inf";
         else if (l < inf) os << l;
         else              os << "inf";
         os << ',';
         if (u == ninf)    os << "-inf";
         else if (u < inf) os << u;
         else              os << "inf";
         os << ']';
         if (inclNaN)
            os << " U NaN";
         return os;
      } else {
         if (inclNaN)
            os << '{';
         if (l == ninf)    os << "-inf";
         else if (l < inf) os << l;
         else              os << "inf";
         if (inclNaN)
            os << ",NaN}";
         return os;
      }
   } else if (inclNaN) {
      return os << "NaN";
   } else {
      return os << "bottom float value";
   }
}

// OneFloatInterval - - - - - - - - - - - - - - - - - - - - - - ->

template <typename Subclass>
bool OneFloatInterval<Subclass>::IsEqual(const Value * other) const
{
   const Subclass* other_ = OneFltIntervSubclassTraits<Subclass>::CastToSubclass(other);
   if (other_ == 0)
      return false;
   if (this->ExpSizeInBits() != other_->ExpSizeInBits())
      return false;
   if (this->FracSizeInBits() != other_->FracSizeInBits())
      return false;
   return interval == other_->interval;
}

template <typename Subclass>
bool OneFloatInterval<Subclass>::IsSingleElem() const 
{
   // If the interval contains both NaNaNs and NaN, it clearly includes more than
   // one value; otherwise, return whether it includes exactly one NaNaN or only
   // NaN
   if (IncludesNaNaNs() && IncludesNaN())
      return false;
   if (IncludesNaNaNs())
   {
      DisassembledFloat<FloatRep> l = L(), u = U();
      return l.Equals(u);
   }
   return true;   // IncludesNaN() must be true and IncludeNaNaNs() false
}

// Operations starts here - - - - - - - - - - - - - - - - ->

template <typename Subclass>
Value* OneFloatInterval<Subclass>::FExclUpperBelow() const
{
   // NaN is always excluded from the returned interval, and if there are
   // no NaNaN values either, just return bottom.
   if (!IncludesNaNaNs())
      return domain->CreateBottomValue(SizeInBits());

   // Get the upper bound u of this interval and then compute the biggest
   // representable float value that is smaller than u, u'.
   DisassembledFloat<FloatRep> du = U();
   --du;

   // Return [-inf..u']
   return domain->GetFloatDomain()->CreateFloat(
      ExpSizeInBits(), FracSizeInBits(),
      true, false, -numeric_limits<FloatRep>::infinity(), du.AsFloat());
}

template <typename Subclass>
Value* OneFloatInterval<Subclass>::FInclUpperBelow() const
{
   // NaN is always excluded from the returned interval, and if there are
   // no NaNaN values either, just return bottom.
   if (!IncludesNaNaNs())
      return domain->CreateBottomValue(SizeInBits());

   // Return [-inf..u], where u is the upper bound of this interval
   return domain->GetFloatDomain()->CreateFloat(
      ExpSizeInBits(), FracSizeInBits(),
      true, false, -numeric_limits<FloatRep>::infinity(), U());
}

template <typename Subclass>
Value* OneFloatInterval<Subclass>::FInclLowerAbove() const
{
   // NaN is always excluded from the returned interval, and if there are
   // no NaNaN values either, just return bottom.
   if (!IncludesNaNaNs())
      return domain->CreateBottomValue(SizeInBits());

   // Return [l..inf], where l is the lower bound of this interval
   return domain->GetFloatDomain()->CreateFloat(
      ExpSizeInBits(), FracSizeInBits(),
      true, false, L(), numeric_limits<FloatRep>::infinity());
}

template <typename Subclass>
Value* OneFloatInterval<Subclass>::FExclLowerAbove() const
{
   // NaN is always excluded from the returned interval, and if there are
   // no NaNaN values either, just return bottom.
   if (!IncludesNaNaNs())
      return domain->CreateBottomValue(SizeInBits());

   // Get the lower bound l of this interval and then compute the smallest
   // representable float value that is bigger than l, l'.
   DisassembledFloat<FloatRep> dl = L();
   ++dl;

   // Return [l'..inf]
   return domain->GetFloatDomain()->CreateFloat(
      ExpSizeInBits(), FracSizeInBits(),
      true, false, dl.AsFloat(), numeric_limits<FloatRep>::infinity());
}

template <typename Subclass>
std::ostream & OneFloatInterval<Subclass>::Print(std::ostream & os) const
{
   return os << interval;
}

// Protected members - - - - - - - - - - - - - - - - ->

template <typename Subclass>
OneFloatInterval<Subclass>::
OneFloatInterval(const Size & exp_size, const Size & frac_size)
: FloatIntervalVal(exp_size, frac_size)
{}

template <typename Subclass>
OneFloatInterval<Subclass>::
OneFloatInterval(const Size & exp_size, const Size & frac_size,
                 bool incl_NaNaNs, bool incl_NaN, long double l, long double u)
: FloatIntervalVal(exp_size, frac_size),
  interval(incl_NaNaNs, incl_NaN, static_cast<FloatRep>(l), static_cast<FloatRep>(u))
{
   if (!incl_NaNaNs && !incl_NaN)
      throw logic_error(string(typeid(Subclass).name()) + " cannot represent bottom. The class BottomValue should be used instead.");
}

template <typename Subclass>
OneFloatInterval<Subclass>::
OneFloatInterval(const Size & exp_size, const Size & frac_size,
                 bool is_NaN, long double value)
: FloatIntervalVal(exp_size, frac_size),
  interval(!is_NaN, is_NaN, static_cast<FloatRep>(value), static_cast<FloatRep>(value))
{
}

// Operations involving OneFloatInterval<> - - - - - - - - - - - - - - - - - - - - - - - - - - ->

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::FNeg(const Subclass* x)
{
   typename Subclass::FloatRep l = 0, u = 0;
   if (x->IncludesNaNaNs()) {
      l = -x->U();
      u = -x->L();
   }
   return domain->GetFloatDomain()->CreateFloat(
      x->ExpSizeInBits(), x->FracSizeInBits(), x->IncludesNaNaNs(), x->IncludesNaN(), l, u);
}

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::FAdd(const Subclass* x, const Subclass* y)
{
   typedef typename Subclass::FloatRep FloatRep;

   const Size exp_size_in_bits = x->ExpSizeInBits();
   const Size frac_size_in_bits = x->FracSizeInBits();

   bool incl_NaNaNs;
   FloatRep l = 0, u = 0;
   if (x->IncludesNaNaNs() && y->IncludesNaNaNs())
   {
      incl_NaNaNs = true;
      l = x->L() + y->L();
      u = x->U() + y->U();
      // If the result is a NaN, return a top value
      if (l != l || u != u)
         return domain->GetFloatDomain()->CreateFloat(exp_size_in_bits, frac_size_in_bits);
   }
   else incl_NaNaNs = false;
   bool incl_NaN = x->IncludesNaN() || y->IncludesNaN();
   return domain->GetFloatDomain()->CreateFloat(exp_size_in_bits, frac_size_in_bits, incl_NaNaNs, incl_NaN, l, u);
}

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::FSub(const Subclass* x, const Subclass* y)
{
   typedef typename Subclass::FloatRep FloatRep;

   const Size exp_size_in_bits = x->ExpSizeInBits();
   const Size frac_size_in_bits = x->FracSizeInBits();

   bool incl_NaNaNs;
   FloatRep l = 0, u = 0;
   if (x->IncludesNaNaNs() && y->IncludesNaNaNs())
   {
      incl_NaNaNs = true;
      l = x->L() - y->U();
      u = x->U() - y->L();
      // If the result is a NaN, return a top value
      if (l != l || u != u)
         return domain->GetFloatDomain()->CreateFloat(exp_size_in_bits, frac_size_in_bits);
   }
   else incl_NaNaNs = false;
   bool incl_NaN = x->IncludesNaN() || y->IncludesNaN();
   return domain->GetFloatDomain()->CreateFloat(exp_size_in_bits, frac_size_in_bits, incl_NaNaNs, incl_NaN, l, u);
}

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::FMul(const Subclass* x, const Subclass* y)
{
   typedef typename Subclass::FloatRep FloatRep;

   const Size exp_size_in_bits = x->ExpSizeInBits();
   const Size frac_size_in_bits = x->FracSizeInBits();

   bool incl_NaNaNs = false;
   FloatRep l = 0, u = 0;
   if (x->IncludesNaNaNs() && y->IncludesNaNaNs())
   {
      incl_NaNaNs = true;
      const FloatRep & l1 = x->L(), & u1 = x->U();
      const FloatRep & l2 = y->L(), & u2 = y->U();
      // Calculate the smallest l value
      l =          l1 * l2;
      l = std::min(l1 * u2, l);
      l = std::min(u1 * l2, l);
      l = std::min(u1 * u2, l);
      // Calculate the largest u value
      u =          l1 * l2;
      u = std::max(l1 * u2, u);
      u = std::max(u1 * l2, u);
      u = std::max(u1 * u2, u);
      // If the result is a NaN, return a top value
      if (l != l || u != u)
         return domain->GetFloatDomain()->CreateFloat(exp_size_in_bits, frac_size_in_bits);
   }
   bool incl_NaN = x->IncludesNaN() || y->IncludesNaN();
   return domain->GetFloatDomain()->CreateFloat(exp_size_in_bits, frac_size_in_bits, incl_NaNaNs, incl_NaN, l, u);
}

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::FDiv(const Subclass* x, const Subclass* y)
{ 
   typedef typename Subclass::FloatRep FloatRep;

   const Size exp_size_in_bits = x->ExpSizeInBits();
   const Size frac_size_in_bits = x->FracSizeInBits();

   // Will the result include NaN?
   bool incl_NaN = x->IncludesNaN() || y->IncludesNaN();

   // If either x or y do not include any NaNaNs, the result can't include any
   // NaNaNs either.
   if (!x->IncludesNaNaNs() || !y->IncludesNaNaNs())
      return domain->GetFloatDomain()->CreateFloat(exp_size_in_bits, frac_size_in_bits, false, incl_NaN);

   // If the denominator interval includes both positive and negative values,
   // split it into two smaller intervals where each interval includes
   // only values with the same sign.
   typedef vector<pair<FloatRep, FloatRep> > Denoms;
   Denoms denoms;
   if (y->IncludesNegZero())
      denoms.push_back(make_pair(y->L(), -FloatRep(0)));
   if (y->IncludesPosZero())
      denoms.push_back(make_pair(FloatRep(0), y->U()));
   if (!y->IncludesNegZero() && !y->IncludesPosZero())
      denoms.push_back(make_pair(y->L(), y->U()));

   // Debug check
   if (denoms.empty())
      throw logic_error((StrStream() << "The denominator " << *y << " seems to be "
         "a bottom value. This should be represented by the class BottomValue.").Str());

   // Now compute the resulting interval.
   // We start with the inverted interval [+inf, -inf]. This will then
   // be updated in the loop below.
   FloatRep l = numeric_limits<FloatRep>::infinity(), u = -l;
   
   const FloatRep & l1 = x->L(), & u1 = x->U();
   for (typename Denoms::const_iterator d = denoms.begin(); d != denoms.end(); ++d)
   {
      const FloatRep & l2 = d->first, & u2 = d->second;

      // Update the smallest l value
      l = std::min(l1 / l2, l);
      l = std::min(l1 / u2, l);
      l = std::min(u1 / l2, l);
      l = std::min(u1 / u2, l);

      // Update the largest u value
      u = std::max(l1 / l2, u);
      u = std::max(l1 / u2, u);
      u = std::max(u1 / l2, u);
      u = std::max(u1 / u2, u);

      // If the result is a NaN, return a top value. This could probably be
      // handled with better precision, but that is a TODO.
      if (l != l || u != u)
         return domain->GetFloatDomain()->CreateFloat(exp_size_in_bits, frac_size_in_bits);
   }
   return domain->GetFloatDomain()->CreateFloat(exp_size_in_bits, frac_size_in_bits, true, incl_NaN, l, u);
}

// Comparison operations - - - - - - - - - - - - - - - - - - - - - - - - - - ->

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::FEq(const Subclass* x, const Subclass* y)
{
   // We start out with the inverted interval [1,0], and then update it below
   int lower = 1, upper = 0;

   // All comparisons involving NaNs return false
   if (x->IncludesNaN() || y->IncludesNaN())
      lower = 0;

   // If both intervals include NaNaN values, compare these
   if (x->IncludesNaNaNs() && y->IncludesNaNaNs())
   {
      // If the two intervals are not completely disjoint, include 1 in the result
      if (!(x->U() < y->L() || y->U() < x->L()))
         upper = 1;
      // If not both intervals include only one value, and that value is the same
      // in both intervals, include 0 in the result
      if (!(x->IsSingleElem() && y->IsSingleElem() && x->L() == y->L()))
         lower = 0;
   }
   return domain->GetIntegerDomain()->CreateInteger(1, lower, upper);
}

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::FNEq(const Subclass* x, const Subclass* y)
{
   // We start out with the inverted interval [1,0], and then update it below
   int lower = 1, upper = 0;

   // All comparisons involving NaNs return false
   if (x->IncludesNaN() || y->IncludesNaN())
      lower = 0;

   // If both intervals include NaNaN values, compare these
   if (x->IncludesNaNaNs() && y->IncludesNaNaNs())
   {
      // If not both intervals include only one value, and that value is the same
      // in both intervals, include 1 in the result
      if (!(x->IsSingleElem() && y->IsSingleElem() && x->L() == y->L()))
         upper = 1;

      // If the two intervals are not completely disjoint, include 0 in the result
      if (!(x->U() < y->L() || y->U() < x->L()))
         lower = 0;
   }
   return domain->GetIntegerDomain()->CreateInteger(1, lower, upper);
}

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::FLT(const Subclass* x, const Subclass* y)
{
   // We start out with the inverted interval [1,0], and then update it below
   int lower = 1, upper = 0;

   // All comparisons involving NaNs return false
   if (x->IncludesNaN() || y->IncludesNaN())
      lower = 0;

   // If both intervals include NaNaN values, compare these
   if (x->IncludesNaNaNs() && y->IncludesNaNaNs())
   {
      if (x->L() < y->U())
         upper = 1;
      if (x->U() >= y->L())
         lower = 0;
   }
   return domain->GetIntegerDomain()->CreateInteger(1, lower, upper);
}

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::FLE(const Subclass* x, const Subclass* y)
{
   // We start out with the inverted interval [1,0], and then update it below
   int lower = 1, upper = 0;

   // All comparisons involving NaNs return false
   if (x->IncludesNaN() || y->IncludesNaN())
      lower = 0;

   // If both intervals include NaNaN values, compare these
   if (x->IncludesNaNaNs() && y->IncludesNaNaNs())
   {
      if (x->L() <= y->U())
         upper = 1;
      if (x->U() > y->L())
         lower = 0;        
   }
   return domain->GetIntegerDomain()->CreateInteger(1, lower, upper);
}

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::FGE(const Subclass* x, const Subclass* y)
{
   // We start out with the inverted interval [1,0], and then update it below
   int lower = 1, upper = 0;

   // All comparisons involving NaNs return false
   if (x->IncludesNaN() || y->IncludesNaN())
      lower = 0;

   // If both intervals include NaNaN values, compare these
   if (x->IncludesNaNaNs() && y->IncludesNaNaNs())
   {
      if (x->U() >= y->L())
         upper = 1;
      if (x->L() < y->U())
         lower = 0;
   }
   return domain->GetIntegerDomain()->CreateInteger(1, lower, upper);
}

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::FGT(const Subclass* x, const Subclass* y)
{
   // We start out with the inverted interval [1,0], and then update it below
   int lower = 1, upper = 0;

   // All comparisons involving NaNs return false
   if (x->IncludesNaN() || y->IncludesNaN())
      lower = 0;

   // If both intervals include NaNaN values, compare these
   if (x->IncludesNaNaNs() && y->IncludesNaNaNs())
   {
      if (x->U() > y->L())
         upper = 1;
      if (x->L() <= y->U())
         lower = 0;
   }
   return domain->GetIntegerDomain()->CreateInteger(1, lower, upper);
}

// Conversion operations involving OneFloatInterval<> - - - - - - - - - - - - - - - - - - - ->

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::FToF(const Subclass* x, const Size& m, const Size& n)
{
   if (x->IncludesNaNaNs())
      return domain->GetFloatDomain()->CreateFloat(m, n, true, x->IncludesNaN(), x->L(), x->U());
   return domain->GetFloatDomain()->CreateFloat(m, n, false, x->IncludesNaN());
}

template <typename Subclass>
Value * Ops_OneFloatInterval<Subclass>::FToS(const Subclass* x, const Size& n)
{
   typedef typename Subclass::FloatRep FloatRep;

   if (!x->IncludesNaNaNs() || x->IncludesNaN())
      return domain->GetIntegerDomain()->CreateInteger(n);
   // For both interval bounds, get the significand with the hidden
   // bit included and shift it left by the amount given by the exponent. Finally
   // set the sign of the integer by looking at the sign bit.
   DisassembledFloat<FloatRep> l = x->L();
   Integer trunc_l(l.GetSignificandWithHiddenBit());   
   // Since the significand was already "shifted left" by the size of the fraction,
   // undo that shift by subtracting the size of the fraction from the shift amount.
   int sh_amt = l.GetExponent() - DisassembledFloat<FloatRep>::GetFracSize();
   if (sh_amt < 0) trunc_l >>= -sh_amt;
   else trunc_l <<= sh_amt;
   if (l.GetSignBit() == 1)
      trunc_l *= -1;

   // Move on to the upper bound; analogous to above
   DisassembledFloat<FloatRep> u = x->U();
   Integer trunc_u(u.GetSignificandWithHiddenBit());
   sh_amt = u.GetExponent() - DisassembledFloat<FloatRep>::GetFracSize();
   if (sh_amt < 0) trunc_u >>= -sh_amt;
   else trunc_u <<= sh_amt;
   if (u.GetSignBit() == 1)
      trunc_u *= -1;
   return domain->GetIntegerDomain()->CreateInteger(n, trunc_l, trunc_u);   
}

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::FToU(const Subclass* x, const Size& n)
{
   // Here we can use the same implementation as for signed integers
   return FToS(x, n);
}

// Set operations involving OneFloatInterval<> - - - - - - - - - - - - - - - - - - - ->

template <typename Subclass>
bool Ops_OneFloatInterval<Subclass>::Overlaps(const Subclass* x, const Subclass* y)
{
   if (x->SizeInBits() != y->SizeInBits()) return false;

   // If both intervals include NaN, they overlap on that value
   if (x->IncludesNaN() && y->IncludesNaN())
      return true;
   return !(x->U() < y->L() || y->U() < x->L());
}

template <typename Subclass>
bool Ops_OneFloatInterval<Subclass>::Includes(const Subclass* x, const Subclass* y)
{
   if (x->SizeInBits() != y->SizeInBits()) return false;

   // Test if y includes NaN but x don't
   if (y->IncludesNaN() && !x->IncludesNaN())
      return false;
   // Note that the condition below must be expressed in that way,
   // because the lower and upper bound of the values may be -inf or inf. TODO: Must it really?
   return !(y->L() < x->L() || x->U() < y->U());
}

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::LUB(const Subclass* x, const Subclass* y)
{
   typedef typename Subclass::FloatRep FloatRep;

   bool incl_NaNaNs = false;
   FloatRep l =  numeric_limits<FloatRep>::infinity(),
            u = -numeric_limits<FloatRep>::infinity();
   if (x->IncludesNaNaNs())
   {
      incl_NaNaNs = true;
      l = x->L();
      u = x->U();
   }
   if (y->IncludesNaNaNs())
   {
      incl_NaNaNs = true;
      l = std::min(l, y->L());
      u = std::max(u, y->U());
   }
   bool incl_NaN = x->IncludesNaN() || y->IncludesNaN();
   return domain->GetFloatDomain()->CreateFloat(x->ExpSizeInBits(), x->FracSizeInBits(), incl_NaNaNs, incl_NaN, l, u);
}

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::GLB(const Subclass* x, const Subclass* y)
{
   typedef typename Subclass::FloatRep FloatRep;

   bool incl_NaNaNs;
   FloatRep l = -numeric_limits<FloatRep>::infinity(),
            u = numeric_limits<FloatRep>::infinity();
   if (x->IncludesNaNaNs())
   {
      l = x->L();
      u = x->U();
   }
   if (y->IncludesNaNaNs())
   {
      l = std::max(l, y->L());
      u = std::min(u, y->U());
   }
   if (x->IncludesNaNaNs() && y->IncludesNaNaNs())
      incl_NaNaNs = l <= u;
   else
      incl_NaNaNs = false;
   bool incl_NaN = x->IncludesNaN() && y->IncludesNaN();
   return domain->GetFloatDomain()->CreateFloat(x->ExpSizeInBits(), x->FracSizeInBits(), incl_NaNaNs, incl_NaN, l, u);
}

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::Widening(const Subclass* x, const Subclass* y)
{
   typedef typename Subclass::FloatRep FloatRep;

   // TODO: This assert is just temporary; these cases should be supported as well
   assert(x->IncludesNaNaNs() && y->IncludesNaNaNs() && !x->IncludesNaN() && !y->IncludesNaN());
   FloatRep l = y->L() < x->L()? -numeric_limits<FloatRep>::infinity() : x->L();
   FloatRep u = y->U() > x->U()? numeric_limits<FloatRep>::infinity() : x->U();
   return domain->GetFloatDomain()->CreateFloat(x->ExpSizeInBits(), x->FracSizeInBits(), true, false, l, u);
}

template <typename Subclass>
Value* Ops_OneFloatInterval<Subclass>::Narrowing(const Subclass* x, const Subclass* y)
{
   typedef typename Subclass::FloatRep FloatRep;

   // TODO: This assert is just temporary; these cases should be supported as well
   assert(x->IncludesNaNaNs() && y->IncludesNaNaNs() && !x->IncludesNaN() && !y->IncludesNaN());
   FloatRep l = (x->L() == -numeric_limits<FloatRep>::infinity())? y->L() : x->L();
   FloatRep u = (x->U() == numeric_limits<FloatRep>::infinity())? y->U() : x->U();
   return domain->GetFloatDomain()->CreateFloat(x->ExpSizeInBits(), x->FracSizeInBits(), true, false, l, u);
}

// Implementations related to OneFloatInterval8_23 - - - - - - - - - - - - - ->

std::unique_ptr<const OneFloatInterval8_23> OneFloatInterval8_23::top_value;

const OneFloatInterval8_23 * OneFloatInterval8_23::TopValue() const
{
   if (top_value.get() == 0)
      top_value.reset( new OneFloatInterval8_23 );
   return top_value.get();
}

// Implementations related to OneFloatInterval11_52 - - - - - - - - - - - - - - ->

std::unique_ptr<const OneFloatInterval11_52> OneFloatInterval11_52::top_value;

const OneFloatInterval11_52 * OneFloatInterval11_52::TopValue() const
{
   if (top_value.get() == 0)
      top_value.reset(new OneFloatInterval11_52);
   return top_value.get();
}

// Some explicit template specializations to make it possible to have the
// function definitions in the .cpp file instead of in the .h file
template class OneFloatInterval<OneFloatInterval8_23>;
template class OneFloatInterval<OneFloatInterval11_52>;

// The following seems to be necessary with some compilers, because the entire FloatInterval template
// is not instantiated transitively by the explicit instantiations above
template class FloatInterval<OneFloatInterval<OneFloatInterval8_23>::FloatRep>;
template class FloatInterval<OneFloatInterval<OneFloatInterval11_52>::FloatRep>;

template struct Ops_OneFloatInterval<OneFloatInterval8_23>;
template struct Ops_OneFloatInterval<OneFloatInterval11_52>;

// Members of IntervalFloatDomain - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Value* IntervalFloatDomain::CreateFloat(const Size & exp_size, const Size & frac_size) const
{
   if (exp_size == 8 && frac_size == 23)
      return new OneFloatInterval8_23;
   if (exp_size == 11 && frac_size == 52)
      return new OneFloatInterval11_52;
   stringstream s;
   s << "Unsupported exp_size: " << exp_size << " and frac_size: " << frac_size << " on floating-point value";
   throw runtime_error(s.str());
}

Value * IntervalFloatDomain::CreateFloat(const Size & exp_size, const Size & frac_size,
                                         bool is_NaN, long double value) const
{
   if (exp_size == 8 && frac_size == 23)
      return new OneFloatInterval8_23(is_NaN, value);
   if (exp_size == 11 && frac_size == 52)
      return new OneFloatInterval11_52(is_NaN, value);
   stringstream s;
   s << "Unsupported exp_size: " << exp_size << " and frac_size: " << frac_size << " on floating-point value";
   throw runtime_error(s.str());
}

Value * IntervalFloatDomain::CreateFloat(const Size & exp_size, const Size & frac_size, 
                                         bool incl_NaNaNs, bool incl_NaN, long double l, long double u) const
{
   if (exp_size == 8 && frac_size == 23)
      return new OneFloatInterval8_23(incl_NaNaNs, incl_NaN, l, u);
   if (exp_size == 11 && frac_size == 52)
      return new OneFloatInterval11_52(incl_NaNaNs, incl_NaN, l, u);
   stringstream s;
   s << "Unsupported exp_size: " << exp_size << " and frac_size: " << frac_size << " on floating-point value";
   throw runtime_error(s.str());
}

// Members of TOPFloatDomain - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Value* TOPFloatDomain::CreateFloat(const Size & exp_size, const Size & frac_size) const
{
   if (exp_size == 8 && frac_size == 23)
      return new OneFloatInterval8_23;
   if (exp_size == 11 && frac_size == 52)
      return new OneFloatInterval11_52;
   stringstream s;
   s << "Unsupported exp_size: " << exp_size << " and frac_size: " << frac_size << " on floating-point value";
   throw runtime_error(s.str());
}

Value * TOPFloatDomain::CreateFloat(const Size & exp_size, const Size & frac_size,
                                         bool is_NaN, long double value) const
{
   return CreateFloat(exp_size, frac_size);
}

Value * TOPFloatDomain::CreateFloat(const Size & exp_size, const Size & frac_size, 
                                         bool incl_NaNaNs, bool incl_NaN, long double l, long double u) const
{
   return CreateFloat(exp_size, frac_size);
}
