#ifndef FLOATINTERVALVAL_H_INCLUDED
#define FLOATINTERVALVAL_H_INCLUDED

#include "Bitstring.h"
#include "FloatDomain.h"
#include <memory>
#include <iostream>
#include <utility>
#include <limits>

/** A single float interval. A float interval may include "Not-a-Not-a-Numbers" (NaNaNs),
    which is the set of "regular" floating-point values v, -inf <= v <= inf. This is implicated
    by the function IncludesNaNaNs() returning true. The interval can also include the
    special value Not-a-Number (NaN), and this is implicated by IncludesNaN() returning true.
    If IncludesNaNaNs(), the lower and upper bounds of the NaNaN interval can be retrieved
    by calling the functions L() and U().
    @param FloatRep The datatype used to represent float values */
template <typename FloatRep>
class FloatInterval : private std::pair<FloatRep, FloatRep>
{
private:
   typedef std::pair<FloatRep, FloatRep> FloatRepPair;

public:
   /** Constructor for creating a top interval, i.e., including all possible floating-point
       values, including NaN. */
   FloatInterval();

   /** Create a new float interval.
       @param incl_NaNaNs  Specifies whether the interval includes NaNaN values
       @param incl_NaN     Specifies whether the interval includes the NaN value
       @param l            The lower bound of the interval of NaNaN values; its value is
                           ignored if @a incl_NaNaNs is false
       @param u            The upper bound of the interval of NaNaN values; its values is
                           ignored if @a incl_NaNaNs is false */
   FloatInterval(bool incl_NaNaNs, bool incl_NaN,
                 const FloatRep & l = std::numeric_limits<FloatRep>::quiet_NaN(),
                 const FloatRep & u = std::numeric_limits<FloatRep>::quiet_NaN());
     
   /** Returns whether the interval includes no values */
   bool IsBottom() const {return !IncludesNaNaNs() && !IncludesNaN();}

   /** Returns whether the interval includes all possible floating-point values, including
       NaN */
   bool IsTop() const;

   /** Returns whether the interval includes any NaNaN values */
   bool IncludesNaNaNs() const {return (flags & INCL_NANANS) != 0;}

   /** Returns whether the interval includes the special value NaN */
   bool IncludesNaN() const {return (flags & INCL_NAN) != 0;}

   /** Returns whether the interval includes the value -0. Note that according to IEEE-754,
       +0 == -0 is true and -0 < +0 is false. This makes it a bit hard to determine, e.g.,
       whether an interval contains +0 but not -0, by just using these built-in operators. */
   bool IncludesNegZero() const;

   /** Returns whether the interval includes the value +0. Note that according to IEEE-754,
       +0 == -0 is true and -0 < +0 is false. This makes it a bit hard to determine, e.g.,
       whether an interval contains +0 but not -0, by just using these built-in operators. */
   bool IncludesPosZero() const;

   /** Returns whether the interval includes any of the values -0 or +0 */
   bool IncludesZero() const;

   /** Get the lower bound of the interval of NaNaNs
       @pre IncludesNaNaNs() returns true */
   FloatRep & L();

   /** Get the lower bound of the interval of NaNaNs
       @pre IncludesNaNaNs() returns true */
   const FloatRep & L() const;
   
   /** Get the upper bound of the interval of NaNaNs
       @pre IncludesNaNaNs() returns true */
   FloatRep & U();

   /** Get the upper bound of the interval of NaNaNs
       @pre g() returns true */
   const FloatRep & U() const;

   /** Determine whether two intervals include exactly the same set of values */
   bool operator ==(const FloatInterval<FloatRep> & other) const;

   std::ostream & Print(std::ostream & os) const;

private:
   enum Flags {INCL_NANANS = (1 << 0), INCL_NAN = (1 << 1)};
   unsigned flags;
};

template <typename FloatRep> inline std::ostream & 
operator <<(std::ostream & os, const FloatInterval<FloatRep> & fi) {return fi.Print(os);}

/** Superclass of all classes that represent sets of floating-point values using intervals */
class FloatIntervalVal : public Bitstring
{
public:
   FloatIntervalVal(const Size & exp_size, const Size & frac_size)
      : Bitstring(1 + exp_size + frac_size), exp_size(exp_size) {}

   /** Dynamic cast */
   virtual const FloatIntervalVal* AsFloatIntervalVal() const {return this;}

   /** Get the size in bits of the exponent part */
   Size ExpSizeInBits() const {return exp_size;}

   /** Get the size in bits of the fraction part */
   Size FracSizeInBits() const {return SizeInBits() - 1 - ExpSizeInBits();}

private:
   /** The size in bits of the exponent part for the floating-point
       representation used for this interval. As a small memory
       optimization, the size of the fraction is derived on-the-fly
       from the total bit size and this value. */
   Size exp_size;
};

/** Traits of a subclass of OneFloatInterval. Should be specialized for each instantiation. */
template <typename Subclass>
class OneFltIntervSubclassTraits
{
public:
   /** The type used to represent a floating-point value in the instantiation */
   typedef void FloatRep;

   /** Function to dynamically cast @a value to a pointer to the subclass */
   static const Subclass* CastToSubclass(const Value* value);  // Not implemented
};

/** Class representing a set of floating-point values using a single interval. Delegates
    much work to the class FloatInterval. Note that when operations result in intervals
    including NaN, as a simplification top values are returned instead. In the future,
    these situtations may eventually be handled in a better way.
    @param Subclass The class deriving from this class */
template <typename Subclass>
class OneFloatInterval : public FloatIntervalVal
{
private:
   typedef OneFloatInterval<Subclass> ThisClass;

public:
   typedef typename OneFltIntervSubclassTraits<Subclass>::FloatRep FloatRep;

   /** @copydoc FloatIntervalVal::IsEqual(const Value*) const */
   virtual bool IsEqual(const Value * other) const;

   /** Returns whether this interval includes all possible floating-point values */
   virtual bool IsTopBitstring() const {return interval.IsTop();}

   /** Returns whether the interval includes any NaNaN values */
   bool IncludesNaNaNs() const {return interval.IncludesNaNaNs();}

   /** Returns whether the interval includes the special value NaN */
   bool IncludesNaN() const {return interval.IncludesNaN();}

   /** Returns whether the interval includes the value -0. Note that according to IEEE-754,
       +0 == -0 is true and -0 < +0 is false. This makes it a bit hard to determine, e.g.,
       whether an interval contains +0 but not -0, by just using these built-in operators. */
   bool IncludesNegZero() const {return interval.IncludesNegZero();}

   /** Returns whether the interval includes the value +0. Note that according to IEEE-754,
       +0 == -0 is true and -0 < +0 is false. This makes it a bit hard to determine, e.g.,
       whether an interval contains +0 but not -0, by just using these built-in operators. */
   bool IncludesPosZero() const {return interval.IncludesPosZero();}

   /** Get the lower bound of the interval of NaNaNs
       @pre IncludesNaNaNs() returns true */
   const FloatRep & L() const {return interval.L();}

   /** Get the upper bound of the interval of NaNaNs
       @pre IncludesNaNaNs() returns true */
   const FloatRep & U() const {return interval.U();}

   /** Returns whether this interval includes a single value */
   virtual bool IsSingleElem() const;

   virtual Value* FExclUpperBelow() const;

   virtual Value* FInclUpperBelow() const;

   virtual Value* FInclLowerAbove() const;

   virtual Value* FExclLowerAbove() const;

   virtual std::ostream & Print(std::ostream & os) const;

protected:
   /** Create a top float interval.
       @param exp_size     The size in bits of the exponent part of the floating-point
                           representation
       @param frac_size    The size in bits of the fraction (or significand) of the floating-point
                           representation */
   OneFloatInterval(const Size & exp_size, const Size & frac_size);

   /** Create a new float interval.
       @param exp_size     The size in bits of the exponent part of the floating-point
                           representation
       @param frac_size    The size in bits of the fraction (or significand) of the floating-point
                           representation
       @param incl_NaNaNs  Specifies whether the interval includes NaNaN values
       @param incl_NaN     Specifies whether the interval includes the NaN value
       @param l            The lower bound of the interval of NaNaN values; its value is
                           ignored if @a incl_NaNaNs is false
       @param u            The upper bound of the interval of NaNaN values; its values is
                           ignored if @a incl_NaNaNs is false */
   OneFloatInterval(const Size & exp_size, const Size & frac_size,
                    bool incl_NaNaNs, bool incl_NaN,
                    long double l = std::numeric_limits<long double>::quiet_NaN(),
                    long double u = std::numeric_limits<long double>::quiet_NaN());

   /** Create a new float interval consisting of a single value.
       @param exp_size     The size in bits of the exponent part of the floating-point
                           representation
       @param frac_size    The size in bits of the fraction (or significand) of the floating-point
                           representation
       @param is_NaN       Specifies whether the single value is NaN or the value given by @a value
       @param value        The single NaNaN value if @a is_NaN is false; if @a is_NaN is true, its
                           value is ignored */
   OneFloatInterval(const Size & exp_size, const Size & frac_size,
                    bool is_NaN, long double value = std::numeric_limits<long double>::quiet_NaN());

private:
   /** The actual interval */
   FloatInterval<FloatRep> interval;
   
   virtual const ThisClass * TopValue() const = 0;
};

template <typename Subclass>
struct Ops_OneFloatInterval
{
   /** @name Arithmetic operations
       @{ */
   static Value* FNeg(const Subclass* x);
   static Value* FAdd(const Subclass* x, const Subclass* y);
   static Value* FSub(const Subclass* x, const Subclass* y);
   static Value* FMul(const Subclass* x, const Subclass* y);
   static Value* FDiv(const Subclass* x, const Subclass* y);
   /** @} */

   /** @name Comparison operations
       @{ */
   static Value* FEq(const Subclass* x, const Subclass* y);
   static Value* FNEq(const Subclass* x, const Subclass* y);
   static Value* FLT(const Subclass* x, const Subclass* y);
   static Value* FLE(const Subclass* x, const Subclass* y);
   static Value* FGE(const Subclass* x, const Subclass* y);
   static Value* FGT(const Subclass* x, const Subclass* y);
   /** @} */
   
   /** @name Conversion operations
       @{ */
   static Value* FToF(const Subclass* x, const Size& m, const Size& n);
   static Value* FToS(const Subclass* x, const Size& n);
   static Value* FToU(const Subclass* x, const Size& n);
   /** @} */

   /** @name Set operations
       @{ */
   static bool Overlaps(const Subclass* x, const Subclass* y);
   static bool Includes(const Subclass* x, const Subclass* y);
   static Value* LUB(const Subclass* x, const Subclass* y);
   static Value* GLB(const Subclass* x, const Subclass* y);
   /** @} */

   /** @name Widening and narrowing
       @{ */
   static Value* Widening(const Subclass* x, const Subclass* y);
   static Value* Narrowing(const Subclass* x, const Subclass* y);
   /** @} */
};

class OneFloatInterval8_23;

/** Traits of OneFloatInterval8_23 */
template <>
class OneFltIntervSubclassTraits<OneFloatInterval8_23>
{
public:
   /** OneFloatInterval8_23 uses the base type @c float to represent floating-point values */
   typedef float FloatRep;

   /** Dynamically cast @a value to a OneFloatInterval8_23 */
   static const OneFloatInterval8_23* CastToSubclass(const Value* value)
   {
      return value->AsOneFloatInterval8_23();
   }
};

/** Class derived from a template specialization of OneFloatInterval that
    should be used for floating-point intervals with a 8-bit exponent and a
    23-bit fraction */
class OneFloatInterval8_23 : public OneFloatInterval<OneFloatInterval8_23>
{
private:
   typedef OneFloatInterval<OneFloatInterval8_23> Baseclass;

public:
   /** Create a top float interval. */
   OneFloatInterval8_23() : Baseclass(8, 23) {}

   /** Create a new float interval.
       @param incl_NaNaNs  Specifies whether the interval includes NaNaN values
       @param incl_NaN     Specifies whether the interval includes the NaN value
       @param l            The lower bound of the interval of NaNaN values; its value is
                           ignored if @a incl_NaNaNs is false
       @param u            The upper bound of the interval of NaNaN values; its values is
                           ignored if @a incl_NaNaNs is false */
   OneFloatInterval8_23(bool incl_NaNaNs, bool incl_NaN,
                        long double l = std::numeric_limits<long double>::quiet_NaN(),
                        long double u = std::numeric_limits<long double>::quiet_NaN())
      : Baseclass(8, 23, incl_NaNaNs, incl_NaN, l, u) {}

   /** Create a new float interval consisting of a single value.
       @param is_NaN       Specifies whether the single value is NaN or the value given by @a value
       @param value        The single NaNaN value if @a is_NaN is false; if @a is_NaN is true, its
                           value is ignored */
   OneFloatInterval8_23(bool is_NaN, long double value)
      : Baseclass(8, 23, is_NaN, value) {}

   /** Make a deep copy.
       @note The caller is responsible for deleting the returned pointer */
   virtual OneFloatInterval8_23 * Copy() const {return new OneFloatInterval8_23(*this);}

   /** Accept visit from a ValueVisitor */
   virtual void AcceptVisitor(ValueVisitor * visitor) const
      {visitor->VisitOneFloatInterval8_23(*this);}

   /** Dynamic cast */
   virtual const OneFloatInterval8_23* AsOneFloatInterval8_23() const {return this;}

private:
   static std::unique_ptr<const OneFloatInterval8_23> top_value;

   virtual const OneFloatInterval8_23 * TopValue() const;
};

class OneFloatInterval11_52;

/** Traits of OneFloatInterval11_52 */
template <>
class OneFltIntervSubclassTraits<OneFloatInterval11_52>
{
public:
   /** OneFloatInterval11_52 uses the base type @c double to represent floating-point values */
   typedef double FloatRep;

   /** Dynamically cast @a value to a OneFloatInterval11_52 */
   static const OneFloatInterval11_52* CastToSubclass(const Value* value)
   {
      return value->AsOneFloatInterval11_52();
   }
};

/** Class derived from a template specialization of OneFloatInterval that
    should be used for floating-point intervals with a 11-bit exponent and a
    52-bit fraction */
class OneFloatInterval11_52 : public OneFloatInterval<OneFloatInterval11_52>
{
private:
   typedef OneFloatInterval<OneFloatInterval11_52> Baseclass;

public:
   /** Create a top float interval. */
   OneFloatInterval11_52() : Baseclass(11, 52) {}

   /** Create a new float interval.
       @param incl_NaNaNs  Specifies whether the interval includes NaNaN values
       @param incl_NaN     Specifies whether the interval includes the NaN value
       @param l            The lower bound of the interval of NaNaN values; its value is
                           ignored if @a incl_NaNaNs is false
       @param u            The upper bound of the interval of NaNaN values; its values is
                           ignored if @a incl_NaNaNs is false */
   OneFloatInterval11_52(bool incl_NaNaNs, bool incl_NaN,
                        long double l = std::numeric_limits<long double>::quiet_NaN(),
                        long double u = std::numeric_limits<long double>::quiet_NaN())
      : Baseclass(11, 52, incl_NaNaNs, incl_NaN, l, u) {}

   /** Create a new float interval consisting of a single value.
       @param is_NaN       Specifies whether the single value is NaN or the value given by @a value
       @param value        The single NaNaN value if @a is_NaN is false; if @a is_NaN is true, its
                           value is ignored */
   OneFloatInterval11_52(bool is_NaN, long double value)
      : Baseclass(11, 52, is_NaN, value) {}

   /** Make a deep copy.
       @note The caller is responsible for deleting the returned pointer */
   virtual OneFloatInterval11_52 * Copy() const {return new OneFloatInterval11_52(*this);}

   /** Accept visit from a ValueVisitor */
   virtual void AcceptVisitor(ValueVisitor * visitor) const
      {visitor->VisitOneFloatInterval11_52(*this);}

   /** Dynamic cast */
   virtual const OneFloatInterval11_52* AsOneFloatInterval11_52() const {return this;}

private:
   static std::unique_ptr<const OneFloatInterval11_52> top_value;

   virtual const OneFloatInterval11_52 * TopValue() const;
};

/** Float domain that creates float interval
   @note All returned pointers should be deleted by the caller */
class IntervalFloatDomain : public FloatDomain
{
public:
   /** @copydoc FloatDomain::CreateFloat(const Size&,const Size&) const */
   virtual Value* CreateFloat(const Size & exp_size, const Size & frac_size) const;

   /** Create a float value
      @param exp_size The size in bits of the exponent part of the representing bitstring
      @param frac_size The size in bits of the fraction part of the representing bitstring
      @param is_NaN Sets whether or not the float is NaN
      @param value The value; will be ignored if @a is_NaN is true
      @note The returned pointer should be deleted by the caller */
   virtual Value * CreateFloat(const Size & exp_size, const Size & frac_size,
      bool is_NaN, long double value = std::numeric_limits<long double>::quiet_NaN()) const;

   /** Create a float interval value
      @param exp_size The size in bits of the exponent part of the representing bitstring
      @param frac_size The size in bits of the fraction part of the representing bitstring
      @param incl_NaNaNs Sets whether or not the created value should include something other than NaN
      @param incl_NaN Sets whether or not the created value should include NaN
      @param l The lower bound of the interval; will be ignored if @a incl_NaNaNs is false
      @param u The upper bound of the interval; will be ignored if @a incl_NaNaNs is false
      @note The returned pointer should be deleted by the caller */
   virtual Value * CreateFloat(const Size & exp_size, const Size & frac_size, 
      bool incl_NaNaNs, bool incl_NaN,
      long double l = std::numeric_limits<long double>::quiet_NaN(),
      long double u = std::numeric_limits<long double>::quiet_NaN()) const;
};

/** A float domain that always creates a TOP float interval (for both concrete and abstract operations)
 @note All returned pointers should be deleted by the caller */
class TOPFloatDomain : public FloatDomain
{
public:
   /** @copydoc FloatDomain::CreateFloat(const Size&,const Size&) const */
   virtual Value* CreateFloat(const Size & exp_size, const Size & frac_size) const;

      /** Create a float value
       @param exp_size The size in bits of the exponent part of the representing bitstring
       @param frac_size The size in bits of the fraction part of the representing bitstring
       @param is_NaN Sets whether or not the float is NaN
       @param value The value; will be ignored if @a is_NaN is true
       @note The returned pointer should be deleted by the caller */
      virtual Value * CreateFloat(const Size & exp_size, const Size & frac_size,
                                  bool is_NaN, long double value = std::numeric_limits<long double>::quiet_NaN()) const;
      
      /** Create a float interval value
       @param exp_size The size in bits of the exponent part of the representing bitstring
       @param frac_size The size in bits of the fraction part of the representing bitstring
       @param incl_NaNaNs Sets whether or not the created value should include something other than NaN
       @param incl_NaN Sets whether or not the created value should include NaN
       @param l The lower bound of the interval; will be ignored if @a incl_NaNaNs is false
       @param u The upper bound of the interval; will be ignored if @a incl_NaNaNs is false
       @note The returned pointer should be deleted by the caller */
      virtual Value * CreateFloat(const Size & exp_size, const Size & frac_size, 
                                  bool incl_NaNaNs, bool incl_NaN,
                                  long double l = std::numeric_limits<long double>::quiet_NaN(),
                                  long double u = std::numeric_limits<long double>::quiet_NaN()) const;
};

#endif   // #ifndef FLOATINTERVALVAL_H_INCLUDED
