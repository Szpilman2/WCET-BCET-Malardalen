#include "TopValue.h"
#include "globals.h"

#include "ValueDomain.h"
#include "IntegerDomain.h"
#include "FloatDomain.h"
#include "program_state/memory/MemoryDomain.h"

#include "SymbPointer.h"

#include <memory>
#include <cassert>

using namespace std;

bool TopValue::IsEqual(const Value* other) const
{
   return this->SizeInBits() == other->SizeInBits() && other->AsTopValue() != 0;
}

// TODO: temporary solution; these methods should be made members of OpPolicies instead

#define RESTRICT_FUNC(NAME)                                                  \
   Value* TopValue::NAME() const {                                           \
      /* make a top float value and call this method on it */                \
      std::unique_ptr<Value> top_float;                                        \
      Size size_in_bits = this->SizeInBits();                                \
      if (size_in_bits == 32)                                                \
         top_float.reset( domain->GetFloatDomain()->CreateFloat(8, 23) );    \
      else if (size_in_bits == 64)                                           \
         top_float.reset( domain->GetFloatDomain()->CreateFloat(11, 52) );   \
      else                                                                   \
         return domain->CreateTopValue(size_in_bits); /* unsupported size */ \
      return top_float->NAME();                                              \
   }

RESTRICT_FUNC(FExclUpperBelow)
RESTRICT_FUNC(FInclUpperBelow)
RESTRICT_FUNC(FInclLowerAbove)
RESTRICT_FUNC(FExclLowerAbove)
