#ifndef OPPOLICIES_H_INCL
#define OPPOLICIES_H_INCL

class Value;
template <typename> class EInt;
typedef EInt<unsigned long long> Size;

class OpPolicies
{
public:
   virtual ~OpPolicies() {}

   /** @name Arithmetic operations
       @{ */
   virtual Value* Neg(const Value* x) = 0;
   virtual Value* Add(const Value* x, const Value* y, const Value* c) = 0;
   virtual Value* CAdd(const Value* x, const Value* y, const Value* c) = 0;
   virtual Value* Sub(const Value* x, const Value* y, const Value* c) = 0;
   virtual Value* CSub(const Value* x, const Value* y, const Value* c) = 0;
   virtual Value* SMul(const Value* x, const Value* y) = 0;
   virtual Value* UMul(const Value* x, const Value* y) = 0;
   virtual Value* Mul_Trunc(const Value* x, const Value* y) = 0;
   virtual Value* SDiv(const Value* x, const Value* y) = 0;
   virtual Value* UDiv(const Value* x, const Value* y) = 0;
   virtual Value* SMod(const Value* x, const Value* y) = 0;
   virtual Value* UMod(const Value* x, const Value* y) = 0;
   /** @} */

   /** @name Comparison operations
       @{ */
   virtual Value* Eq(const Value* x, const Value* y) = 0;
   virtual Value* NEq(const Value* x, const Value* y) = 0;
   virtual Value* SLT(const Value* x, const Value* y) = 0;
   virtual Value* SLE(const Value* x, const Value* y) = 0;
   virtual Value* SGE(const Value* x, const Value* y) = 0;
   virtual Value* SGT(const Value* x, const Value* y) = 0;
   virtual Value* ULT(const Value* x, const Value* y) = 0;
   virtual Value* ULE(const Value* x, const Value* y) = 0;
   virtual Value* UGE(const Value* x, const Value* y) = 0;
   virtual Value* UGT(const Value* x, const Value* y) = 0;
   /** @} */

   /** @name Bitwise operations
       @{ */
   virtual Value* Not(const Value* x) = 0;
   virtual Value* And(const Value* x, const Value* y) = 0;
   virtual Value* Or(const Value* x, const Value* y) = 0;
   virtual Value* XOr(const Value* x, const Value* y) = 0;
   virtual Value* LShift(const Value* x, const Value* y) = 0;
   virtual Value* RShift(const Value* x, const Value* y) = 0;
   virtual Value* RShiftA(const Value* x, const Value* y) = 0;
   virtual Value* ZExt(const Value* x, const Size& n) = 0;
   virtual Value* SExt(const Value* x, const Size& n) = 0;
   virtual Value* Repeat(const Value* x, const Size& n) = 0;
   virtual Value* Select(const Value* x, const Size& m, const Size& n) = 0;
   virtual Value* Conc(const Value* x, const Value* y) = 0;
   /** @} */

   /** @name Floating-point operations
       @{ */
   virtual Value* FNeg(const Value* x) = 0;
   virtual Value* FAdd(const Value* x, const Value* y) = 0;
   virtual Value* FSub(const Value* x, const Value* y) = 0;
   virtual Value* FMul(const Value* x, const Value* y) = 0;
   virtual Value* FDiv(const Value* x, const Value* y) = 0;
   virtual Value* FToF(const Value* x, const Size& m, const Size& n) = 0;
   virtual Value* FToS(const Value* x, const Size& n) = 0;
   virtual Value* FToU(const Value* x, const Size& n) = 0;
   virtual Value* SToF(const Value* x, const Size& m, const Size& n) = 0;
   virtual Value* UToF(const Value* x, const Size& m, const Size& n) = 0;
   /** @} */

   /** @name Floating-point comparison operations
       @{ */
   virtual Value* FEq(const Value* x, const Value* y) = 0;
   virtual Value* FNEq(const Value* x, const Value* y) = 0;
   virtual Value* FLT(const Value* x, const Value* y) = 0;
   virtual Value* FLE(const Value* x, const Value* y) = 0;
   virtual Value* FGE(const Value* x, const Value* y) = 0;
   virtual Value* FGT(const Value* x, const Value* y) = 0;
   /** @} */

   /** @name Miscellaneous
       @{ */
   virtual Value* If(const Value* x, const Value* y, const Value* z) = 0;
   virtual Value* B2N(const Value* x) = 0;
   virtual Value* Exp2(const Value* x) = 0;
   virtual Value* ILog2(const Value* x) = 0;
   /** @} */

   /** @name Set operations
       @{ */
   virtual bool Includes(const Value* x, const Value* y) = 0;
   virtual bool Overlaps(const Value* x, const Value* y) = 0;
   virtual Value* GLB(const Value* x, const Value* y) = 0;
   virtual Value* LUB(const Value* x, const Value* y) = 0;
   virtual Value* Widening(const Value* x, const Value* y) = 0;
   virtual Value* Narrowing(const Value* x, const Value* y) = 0;
   /** @} */

   /** @name Restriction
       @{ */
   virtual Value* Restrict_NEq(const Value* restr, const Value* other) = 0;
   virtual Value* Restrict_SLT(const Value* restr, const Value* other) = 0;
   virtual Value* Restrict_SLE(const Value* restr, const Value* other) = 0;
   virtual Value* Restrict_SGE(const Value* restr, const Value* other) = 0;
   virtual Value* Restrict_SGT(const Value* restr, const Value* other) = 0;
   virtual Value* Restrict_ULT(const Value* restr, const Value* other) = 0;
   virtual Value* Restrict_ULE(const Value* restr, const Value* other) = 0;
   virtual Value* Restrict_UGE(const Value* restr, const Value* other) = 0;
   virtual Value* Restrict_UGT(const Value* restr, const Value* other) = 0;

   virtual Value* Restrict_Select(const Value* x, Size idx_first, const Value* result) = 0;
   /** @} */

   /** @name Reverse operations
       @{ */
   virtual Value* RevSMul(const Value* result, const Value* op1, const Size& size_in_bits) = 0;
   virtual Value* RevUMul(const Value* result, const Value* op1, const Size& size_in_bits) = 0;
   virtual Value* RevAnd(const Value* result, const Value* op1) = 0;
   virtual Value* RevOr(const Value* result, const Value* op1) = 0;
   virtual Value* RevXOr(const Value* result, const Value* op1) = 0;
   virtual Value* RevLShift1(const Value* result, const Value* shamt) = 0;
   /** @} */
};

class OpPolicies_Interv : public OpPolicies
{
public:
   /** @name Arithmetic operations
       @{ */
   virtual Value* Neg(const Value* x);
   virtual Value* Add(const Value* x, const Value* y, const Value* c);
   virtual Value* CAdd(const Value* x, const Value* y, const Value* c);
   virtual Value* Sub(const Value* x, const Value* y, const Value* c);
   virtual Value* CSub(const Value* x, const Value* y, const Value* c);
   virtual Value* SMul(const Value* x, const Value* y);
   virtual Value* UMul(const Value* x, const Value* y);
   virtual Value* Mul_Trunc(const Value* x, const Value* y);
   virtual Value* SDiv(const Value* x, const Value* y);
   virtual Value* UDiv(const Value* x, const Value* y);
   virtual Value* SMod(const Value* x, const Value* y);
   virtual Value* UMod(const Value* x, const Value* y);
   /** @} */

   /** @name Comparison operations
       @{ */
   virtual Value* Eq(const Value* x, const Value* y);
   virtual Value* NEq(const Value* x, const Value* y);
   virtual Value* SLT(const Value* x, const Value* y);
   virtual Value* SLE(const Value* x, const Value* y);
   virtual Value* SGE(const Value* x, const Value* y);
   virtual Value* SGT(const Value* x, const Value* y);
   virtual Value* ULT(const Value* x, const Value* y);
   virtual Value* ULE(const Value* x, const Value* y);
   virtual Value* UGE(const Value* x, const Value* y);
   virtual Value* UGT(const Value* x, const Value* y);
   /** @} */

   /** @name Bitwise operations
       @{ */
   virtual Value* Not(const Value* x);
   virtual Value* And(const Value* x, const Value* y);
   virtual Value* Or(const Value* x, const Value* y);
   virtual Value* XOr(const Value* x, const Value* y);
   virtual Value* LShift(const Value* x, const Value* y);
   virtual Value* RShift(const Value* x, const Value* y);
   virtual Value* RShiftA(const Value* x, const Value* y);
   virtual Value* ZExt(const Value* x, const Size& n);
   virtual Value* SExt(const Value* x, const Size& n);
   virtual Value* Repeat(const Value* x, const Size& n);
   virtual Value* Select(const Value* x, const Size& m, const Size& n);
   virtual Value* Conc(const Value* x, const Value* y);
   /** @} */

   /** @name Floating-point operations
       @{ */
   virtual Value* FNeg(const Value* x);
   virtual Value* FAdd(const Value* x, const Value* y);
   virtual Value* FSub(const Value* x, const Value* y);
   virtual Value* FMul(const Value* x, const Value* y);
   virtual Value* FDiv(const Value* x, const Value* y);
   virtual Value* FToF(const Value* x, const Size& m, const Size& n);
   virtual Value* FToS(const Value* x, const Size& n);
   virtual Value* FToU(const Value* x, const Size& n);
   virtual Value* SToF(const Value* x, const Size& m, const Size& n);
   virtual Value* UToF(const Value* x, const Size& m, const Size& n);
   /** @} */

   /** @name Floating-point comparison operations
       @{ */
   virtual Value* FEq(const Value* x, const Value* y);
   virtual Value* FNEq(const Value* x, const Value* y);
   virtual Value* FLT(const Value* x, const Value* y);
   virtual Value* FLE(const Value* x, const Value* y);
   virtual Value* FGE(const Value* x, const Value* y);
   virtual Value* FGT(const Value* x, const Value* y);
   /** @} */

   /** @name Miscellaneous
       @{ */
   virtual Value* If(const Value* x, const Value* y, const Value* z);
   virtual Value* B2N(const Value* x);
   virtual Value* Exp2(const Value* x);
   virtual Value* ILog2(const Value* x);
   /** @} */

   /** @name Set operations
       @{ */
   virtual bool Includes(const Value* x, const Value* y);
   virtual bool Overlaps(const Value* x, const Value* y);
   virtual Value* GLB(const Value* x, const Value* y);
   virtual Value* LUB(const Value* x, const Value* y);
   virtual Value* Widening(const Value* x, const Value* y);
   virtual Value* Narrowing(const Value* x, const Value* y);
   /** @} */

   /** @name Restriction
       @{ */
   virtual Value* Restrict_NEq(const Value* restr, const Value* other);
   virtual Value* Restrict_SLT(const Value* restr, const Value* other);
   virtual Value* Restrict_SLE(const Value* restr, const Value* other);
   virtual Value* Restrict_SGE(const Value* restr, const Value* other);
   virtual Value* Restrict_SGT(const Value* restr, const Value* other);
   virtual Value* Restrict_ULT(const Value* restr, const Value* other);
   virtual Value* Restrict_ULE(const Value* restr, const Value* other);
   virtual Value* Restrict_UGE(const Value* restr, const Value* other);
   virtual Value* Restrict_UGT(const Value* restr, const Value* other);

   virtual Value* Restrict_Select(const Value* restr, Size idx_first, const Value* result) ;
   /** @} */

   /** @name Reverse operations
       @{ */
   virtual Value* RevSMul(const Value* result, const Value* op1, const Size& size_in_bits);
   virtual Value* RevUMul(const Value* result, const Value* op1, const Size& size_in_bits);
   virtual Value* RevAnd(const Value* result, const Value* op1);
   virtual Value* RevOr(const Value* result, const Value* op1);
   virtual Value* RevXOr(const Value* result, const Value* op1);
   virtual Value* RevLShift1(const Value* result, const Value* shamt);
   /** @} */
};

#endif // ifndef OPPOLICIES_H_INCL
