#include "ReadValue.h"
#include "IntegerDomain.h"
#include "ValueDomain.h"
#include "SymbIntervalPtrSet.h"
#include "program_state/memory/Frame.h"
#include "program_state/Endianness.h"
#include "tools/RangeIterator.h"
#include "tools/IndentingOStream.h"
#include "macros.h"
#include "globals.h"
#include <ostream>
#include <functional>
#include <algorithm>

using namespace std;
  
Value* ReadValue::Create(Frame* frame)
{
   if (!frame)
      return domain->CreateBottomValue(frame->SizeInBits());
   return new ReadValue(frame);
}

ReadValue::ReadValue(Frame* data)
: Value(0), _data(data)   // We do not use the _size_in_bits member of the superclass
{
   if (!data)
      throw logic_error("ReadValue cannot represent bottom. The class BottomValue should be used instead.");
}

ReadValue::ReadValue(const ReadValue & other)
: Value(0), _data(other._data->Copy())
{ 
}

ReadValue::~ReadValue()
{
   delete _data;
}

ReadValue & ReadValue::operator =(const ReadValue & other)
{
   // reuse copy constructor
   this->~ReadValue();
   new (this) ReadValue(other);
   return *this;
}

bool ReadValue::IsEqual(const Value * other) const
{
   if (this == other)
      return true;

   const ReadValue * other_ = other->AsReadValue();
   if (other_ == 0)
      return false;
   
   if (this->SizeInBits() != other->SizeInBits())
      return false;

   return this->Data()->IsEqual(other_->Data());
}

Size ReadValue::SizeInBits() const 
{
   return _data->SizeInBits();
}

bool ReadValue::IsBottom() const
{
   return unique_ptr<Value>(Fuse())->IsBottom();
}

bool ReadValue::IsTop() const
{
   return unique_ptr<Value>(Fuse())->IsTop();
}

bool ReadValue::IsSingleElem() const
{
   return unique_ptr<Value>(Fuse())->IsSingleElem();
}

Value * ReadValue::Fuse() const
{
   // This method attempts to reconstruct a value from the patch list by "clipping" and
   // concatenating the values stored in the patches.  Note that all adjacent
   // patches with matching bit indices in the list are assumed to be merged already.
   PatchList patch_list;  Data()->Patches(patch_list);   // TODO: Fuse on PatchStore instead of PatchList?
   unique_ptr<Value> fused;
   // run through the patch list and clip + concatenate the values
   RangeIterator<PatchList> p( patch_list );
   unique_ptr<Value> clipped( p->GetClippedValue() );
   assert( clipped->AsReadValue() == 0 ); // patch lists should never be hierarchical
   fused = move(clipped);
   for (++p; p; ++p) {
      clipped.reset( p->GetClippedValue() );
      assert( clipped->AsReadValue() == 0 ); // patch lists should never be hierarchical
      if (fused->AsBitstring() && clipped->AsBitstring()) {
         // concatenation works only for bitstring types
         if (g_endianness == Endianness::Little())
            fused.reset( clipped->Conc(fused.get()) );
         else
            fused.reset( fused->Conc(clipped.get()) );
      }
      else {
         fused.reset( domain->CreateTopValue(Data()->SizeInBits()) );
         break;
      }
   }
   return fused.release();
}

std::ostream & ReadValue::Print(std::ostream & os) const {
   return os << "value read from frame:\n" << *_data;
}

// Private members of ReadValue --------------------------------------------------

Value* ReadValue::UnOper(Value* (Value::*un_oper)() const) const
{
   unique_ptr<Value> fused(Fuse());
   return ((*fused).*un_oper)();
}

Value* Ops_ReadValue::Not(const ReadValue* x)
{
   unique_ptr<PatchList> inv_patches(new PatchList);
   x->Data()->Patches(*inv_patches);
   for (PatchList::iterator p = inv_patches->begin(), pn = inv_patches->end(); p != pn; ++p)
   {
      // replace by inverted value
      unique_ptr<Value> old_val(p->value);
      p->value = old_val->Not();
   }
   return ReadValue::Create(new Frame(move(inv_patches)));
}

Value* Ops_ReadValue::ZExt(const ReadValue* x, const Size& n)
{
   assert(n >= x->SizeInBits());
   if (n == x->SizeInBits())
      return x->Copy();

   // Retrieve the patch list from the data frame, add a zero data patch at the "most significant" 
   // side of it (which side that is depends on the endianness) to make it n bits, and then create
   // a new ReadValue from the patch list
   unique_ptr<PatchList> new_pl(new PatchList);
   const Frame* data = x->Data();
   Size size_ext = n - data->SizeInBits();
   DataPatch ext_patch( domain->GetIntegerDomain()->CreateInteger(size_ext, 0) );
   if (g_endianness == Endianness::Little())
   {
      data->Patches(*new_pl);
      new_pl->push_back(move(ext_patch));
   }
   else
   {
      new_pl->push_back(move(ext_patch));
      data->Patches(*new_pl);
   }
   return ReadValue::Create(new Frame(move(new_pl)));
}

Value* Ops_ReadValue::Select(const ReadValue* x, const Size& m, const Size& n)
{
   // The select operation is only valid for bitstring types, so first make sure x stores
   // something that contains a bitstring part
   unique_ptr<Value> fused( x->Fuse() );
   if ( !(fused->AsBitstring() || fused->IsTop()) )
      return domain->CreateBottomValue(n - m + 1);

   // A select is always performed under the assumption that bits are indexed
   // from lowest to highest significance. Since a frame behaves differently
   // depending on the endianness, the bit range [m..n] must first be recalculated
   // by Endianness::Select().
   std::pair<Size,Size> bit_range = g_endianness.Select(m, n + 1, Size(0), x->Data()->SizeInBits());
   return x->Data()->ReadRange(bit_range.first.AsBaseIntType(), bit_range.second);
}

Value* Ops_ReadValue::Conc_RV(const ReadValue* x, const Value* y)
{
   assert(y->SizeInBits() < Size::Infinity());
   
   // Retrieve the patch list from x's data frame and add the value y
   // as a new patch at the "least significant" side. If little endianness is used, this
   // is at the front of the list (the lowest offset), otherwise it is at the back of
   // the list (the highest offset).
   unique_ptr<PatchList> new_pl(new PatchList);
   x->Data()->Patches(*new_pl);
   DataPatch patch(y->Copy());
   if (g_endianness == Endianness::Little()) new_pl->push_front(move(patch));
   else new_pl->push_back(move(patch));
   
   // Create a new frame with this patch list and return
   return ReadValue::Create(new Frame(move(new_pl)));
}

Value* Ops_ReadValue::Conc_VR(const Value* x, const ReadValue* y)
{
   assert(y->SizeInBits() < Size::Infinity());
   
   // Retrieve the patch list from y's data frame and add the value x
   // as a new patch at the "most significant" side. If little endianness is used, this
   // is at the back of the list (the highest offset), otherwise it is at the front of
   // the list (the lowest offset).
   unique_ptr<PatchList> new_pl(new PatchList);
   y->Data()->Patches(*new_pl);
   DataPatch patch(x->Copy());
   if (g_endianness == Endianness::Little()) new_pl->push_back(move(patch));
   else new_pl->push_front(move(patch));
   
   // Create a new frame with this patch list and return
   return ReadValue::Create(new Frame(move(new_pl)));
}

Value* Ops_ReadValue::Conc_RR(const ReadValue* x, const ReadValue* y)
{
   assert(y->SizeInBits() < Size::Infinity());
   unique_ptr<PatchList> new_pl( new PatchList );   

   // Create a new patch list that contains all the patches from both x and y. The
   // patches from y should be put in the least significant part of the list, which
   // is at the front if little endianness is used and at the back if big endianness
   // is used.
   if (g_endianness == Endianness::Little()) 
   {
      // Add the patches from y before the patches from x
      y->Data()->Patches(*new_pl);
      x->Data()->Patches(*new_pl);
   }
   else   
   {
      // Add the patches from x before the patches from y
      x->Data()->Patches(*new_pl);
      y->Data()->Patches(*new_pl);
   }
   
   return ReadValue::Create(new Frame(move(new_pl)));
}

Value* Ops_ReadValue::LUB_RR(const ReadValue* x, const ReadValue* y)
{
   return ReadValue::Create(x->Data()->LUB(y->Data()));
}

Value* Ops_ReadValue::GLB_RR(const ReadValue* x, const ReadValue* y)
{
   return ReadValue::Create(x->Data()->GLB(y->Data()));
}

Value* Ops_ReadValue::RevSelect(const ReadValue* r, const Size& k, const Size& m)
{
   assert(m < Size::Infinity());
   assert(!(r->SizeInBits().IsInfinity() && !k.IsInfinity()));
   
   // The select operation is only valid for bitstring types, so first make sure r stores
   // something that contains a bitstring part
   unique_ptr<Value> fused( r->Fuse() );
   if ( !(fused->AsBitstring() || fused->IsTop()) )
      return domain->CreateBottomValue(k);

   // Compute the upper bit index n used in the select
   Size n = r->SizeInBits() + m - 1;

   // Make a copy of this value's patch list, with top patches inserted at
   // the front and/or the back as needed to give it the size k
   unique_ptr<PatchList> new_pl( new PatchList );
   r->Data()->Patches(*new_pl);
   // Possibly insert a top bitstring patch at the less significant end
   if (m > 0) {
      DataPatch top_patch_lo(domain->GetIntegerDomain()->CreateInteger(m));
      if (g_endianness == Endianness::Little())
         new_pl->push_front(move(top_patch_lo));
      else
         new_pl->push_back(move(top_patch_lo));
   }
   // Possibly insert a top bitstring patch at the more significant end
   if (n < k - 1) {
      DataPatch top_patch_hi(domain->GetIntegerDomain()->CreateInteger(k - n - 1));
      if (g_endianness == Endianness::Little())
         new_pl->push_back(move(top_patch_hi));
      else
         new_pl->push_front(move(top_patch_hi));
   }      
   return ReadValue::Create(new Frame(move(new_pl)));
}
