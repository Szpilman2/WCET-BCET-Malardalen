#ifndef SYMBCLPPTRSET_H_INCL
#define SYMBCLPPTRSET_H_INCL

#include "program_state/value/SymbPointerSet.h"
#include "program_state/memory/SymbMemory.h"

class ClpValue;
class SymbClpPtrSet;

template <>
class SymbPtrSetSubclassTraits<SymbClpPtrSet> {
public:
   typedef ClpValue OffsetType;
   static const SymbClpPtrSet* CastToSubclass(const Value* value) { return value->AsSymbClpPtrSet(); }
   static const ClpValue* CastToOffsetType(const Value* value) { return value->AsClpValue(); }
};

class SymbClpPtrSet : public SymbPointerSet<SymbClpPtrSet> {
public:
   typedef SymbPointerSet<SymbClpPtrSet> Baseclass;
   
   /** SopIterator subclass that employs lazy evaluation to avoid creating all
       (symbol,offset) pairs at once
       @see SymbClpPtrSet::GetIterator(), SopIterator */
   class LazyIterator;

   /** @copydoc Baseclass::SymbPointerSet(const Size&) */
   SymbClpPtrSet(Size size_in_bits) : Baseclass(size_in_bits) {}

   /** @copydoc Baseclass::SymbPointerSet(const Size&,const Symbol&,const Integer&) */
   SymbClpPtrSet(Size size_in_bits, const Symbol &symbol, const Integer &offset)
      : Baseclass(size_in_bits, symbol, offset) {}

   /** @copydoc Baseclass::SymbPointerSet(const Size&,SymbolToOffset&) */
   SymbClpPtrSet(Size size_in_bits, SymbolToOffset &symbol_to_offset)
      : Baseclass(size_in_bits, symbol_to_offset) {}

   /** @copydoc Baseclass::SymbPointerSet(const SymbClpPtrSet&) */
   SymbClpPtrSet(const SymbClpPtrSet& other)
      : Baseclass(other) {}

   /** @copydoc Baseclass::Copy() const */
   virtual SymbClpPtrSet* Copy() const { return new SymbClpPtrSet(*this); }

   /** @copydoc Baseclass::AsSymbClpPtrSet() const */
   virtual const SymbClpPtrSet* AsSymbClpPtrSet() const { return this; }

   /** @copydoc Baseclass::AcceptVisitor(ValueVisitor*) const */
   virtual void AcceptVisitor(ValueVisitor *visitor) const { visitor->VisitSymbClpPtrSet(*this); }
   
private:
   /** @copydoc Baseclass::GetIterator_Private */
   virtual SopIterator* GetIterator_Private() const;
};

class SymbClpMemDomain : public SymbMemoryDomain {
public:
   /** @copydoc SymbMemoryDomain::CreateBasePtr(const Size&, const Symbol&) */
   virtual Value *CreateBasePtr(const Size &size_in_bits, const Symbol &symbol);

   /** @copydoc SymbMemoryDomain::CreatePointer(const Size&) */
   virtual Value *CreatePointer(const Size &size_in_bits) {
      return new SymbClpPtrSet(size_in_bits);
   }
   /** @copydoc SymbMemoryDomain::CreatePointer(const Value*, const Value*) */
   virtual Value *CreatePointer(const Value *base_ptr, const Value *offset);

   /** @copydoc SymbMemoryDomain::CreatePointer(const Size&, SymbolToOffset&) */
   virtual Value *CreatePointer(const Size &size_in_bits, SymbolToOffset &symbol_to_offset) {
      return symbol_to_offset.empty()? domain->CreateBottomValue(size_in_bits)
         : new SymbClpPtrSet(size_in_bits, symbol_to_offset);
   }
};

#endif   // ifndef SYMBCLPPTRSET_H_INCL
