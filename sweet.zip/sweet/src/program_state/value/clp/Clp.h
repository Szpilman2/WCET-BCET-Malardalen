#ifndef CLP_H_INCL
#define CLP_H_INCL

#include "program_state/Size.h"
#include "tools/Integer.h"

/* TODO:
- Since 'Clp' doesn't store a bit size, it isn't really a *Circular* Linear Progression, so it should perhaps
  be renamed as, e.g., 'AritProg' to reflect that it is an arithmetic progression */
class Clp {
public:
   /** Creates an empty CLP */
   Clp() : base(0), stride(0), count(0) {}

   /** Creates the singleton CLP (base, 0, 1) */
   explicit Clp(const Integer &base) : base(base), stride(0), count(1) {}

   /** Creates the interval CLP [base..(base + count - 1)]
      @pre 'count' is non-negative
      @post If 'count' is 0 or 1, the stride will be set to 0 */
   Clp(const Integer &base, const Integer &count) : base(base), count(count) {
      if (this->count < 0) throw std::logic_error("Count must be non-negative");
      stride = (this->count < 2? 0 : 1);
   }

   /** Creates the CLP (base, stride, count)
      @pre 'count' is non-negative
      @post If 'count' is 0 or 1, the stride will be set to 0 */
   Clp(const Integer &base, const Integer &stride, const Integer &count) : base(base), stride(stride), count(count) {
      if (this->count < 0) throw std::logic_error("Count must be non-negative");
      if (this->count < 2) this->stride = 0;
      else if (this->stride == 0) this->count = 1;
   }

   const Integer &GetBase() const { return base; }
   const Integer &GetStride() const { return stride; }
   const Integer &GetCount() const { return count; }
   Integer GetUpper() const { return this->GetBase() + this->GetStride() * (this->GetCount() - 1); }
   /** Returns the concrete value at index 'idx' */
   Integer Get(Integer idx) const {
      if (idx < 0 || this->GetCount() <= idx)
         throw std::out_of_range("Invalid index");
      return this->GetBase() + idx * this->GetStride();
   }

   void SetBase(const Integer &newbase) { base = newbase; }
   /** @post If newstride == 0, the count will be set to 1 */
   void SetStride(const Integer &newstride) { stride = newstride; if (stride == 0) count = 1; }
   /** @pre 'newcount' is non-negative
      @post If 'newcount' is 0 or 1, the stride will be set to 0 */
   void SetCount(const Integer &newcount) {
      count = newcount;
      if (count < 0) throw std::logic_error("Count must be non-negative");
      if (count < 2) stride = 0;
   }
   void SetUpper(const Integer &newupper) {
      if (this->GetStride() == 0) {
         if (newupper != this->GetBase())
            throw std::logic_error("Invalid upper bound");
         this->SetCount(Integer(1));
      }
      else this->SetCount( (newupper - this->GetBase()) / this->GetStride() + 1 );
   }

private:
   Integer base, stride, count;
};

/** @note Two Clp objects are considered equal iff they have the exact same parameters */
inline bool operator ==(const Clp &a, const Clp &b) {
   return a.GetBase() == b.GetBase() &&
      a.GetStride() == b.GetStride() &&
      a.GetCount() == b.GetCount();
}

#include "tools/integer_utilities.h"
#include <vector>
#include <utility>

namespace ClpUtils {

inline bool IsEmpty(const Clp &clp) {
   return clp.GetCount() == 0;
}

inline bool IsSingleton(const Clp &clp) {
   return clp.GetCount() == 1;
}

inline void GetConcrete(const Clp &clp, std::vector<Integer> &vals_out) {
   vals_out.reserve( clp.GetCount().As<std::vector<Integer>::size_type>() );
   for (Integer val = clp.GetBase(), count = clp.GetCount(); count != 0; val += clp.GetStride(), --count)
      vals_out.push_back(val);
}

Clp OptimAbstract(unsigned long long size_in_bits, const std::vector<Integer> &vals);

/** Mathematical modulo operation (which differs from the % operation in most compilers).
   Returns the common residue b of the congruence class of 'a' modulo 'n', i.e.,
   the smallest non-negative value b such that a - b is a multiple of 'n'.
   @pre n != 0
   @note mod(a, -n) returns the same as mod(a, n) */
template <typename T>
inline T mod(const T &a, const T &n) {
   T abs_n = abs(n);
   // if 'a' is non-negative, we can rely on the % operator, since the behavior is standardized
   if (a >= 0) return a % abs_n;
   // otherwise, compute the smallest number of steps of size abs(n) needed to
   // get from 'a' to a non-negative value, then add abs(n) this many times to 'a':
   //
   //    a + ceil((0 - a) / abs(n)) * abs(n)
   //
   return a + ((-a - 1) / abs_n + 1) * abs_n;
}

/** Returns the (positive) greatest common divisor of 'a' and 'b'
   @note GCD(0, 0) is undefined, but this function returns 0 in this case */
inline Integer GCD(Integer a, Integer b) {
   if (a < 0) a = -a;
   if (b < 0) b = -b;
   if (a < b) std::swap(a, b);
   if (b == 0) return a; // captures also the case where a == 0, since a >= b
   // Compute the largest powers of 2 in the prime factorizations of 'a' and 'b', by extracting
   // the least significant "100..." substring of their binary representations.
   // If either 'a' or 'b' ever become powers of 2 below, the GCD must also be a
   // power of 2, specifically, the smallest of 'a_pow2' and 'b_pow2'.
   Integer a_pow2 = a & -a, b_pow2 = b & -b;
   if (a == a_pow2) // 'b' is tested in the loop below
      return std::min(a_pow2, b_pow2);
   Integer tmp1, tmp2;
   // this condition breaks the loop also when b == 0; note also that a != a_pow2
   // has already been tested in the previous iteration (or before the loop)
   while (b != b_pow2) {
      tmp1 = b; tmp2 = b_pow2;
      b = a % b;
      b_pow2 = b & -b;
      a = tmp1; a_pow2 = tmp2;
   }
   // test what condition breaked the loop
   if (b != 0) return std::min(a_pow2, b_pow2);
   else return a;
}

/** Returns in constant time the (positive) greatest common divisor of 'a' and 'b_pow2'
   @pre 'b_pow2' is a power of 2 (thus, not 0) */
inline Integer GCD_Pow2(const Integer &a, const Integer &b_pow2) {
   if (a == 0) return b_pow2;
   // The operand 'b_pow2' is only divisible by powers of 2.  Therefore, find the largest
   // power of 2 in the prime factorization of 'a', by extracting the least significant
   // "100..." substring of its binary representation.  If this factor is larger than 'b_pow2',
   // return 'b_pow2' instead.
   return std::min(a & -a, b_pow2);
}

inline Integer XGCD(const Integer &a, const Integer &b, Integer &s_out, Integer &t_out) {
   Integer s(0), s_(1),
      t(1), t_(0),
      r = b, r_ = a,
      q, tmp;
   while (r != 0) {
      q = r_ / r;
      tmp = r_; r_ = r; r = tmp - q * r;
      tmp = s_; s_ = s; s = tmp - q * s;
      tmp = t_; t_ = t; t = tmp - q * t;
   }
   s_out = s_;
   t_out = t_;
   return r_;
}

/** Returns the (positive) least common multiple of 'a' and 'b' */
inline Integer LCM(const Integer &a, const Integer &b) {
   Integer gcd = GCD(a, b);
   if (gcd == 0) return Integer(0);
   else return abs(a * b) / gcd;
}

/** Random-access iterator class that returns prime numbers given indices.  Previously
   generated prime numbers are cached, and new ones are generated lazily. */
class PrimeSieve {
public:
   typedef std::vector<bool>::size_type T;

   /** Initializes the object to store all prime numbers up to and including 'max' */
   PrimeSieve(T max = 100) {
      primes.push_back(2);
      UpdatePrimes(max);
   }

   /** Returns the 'i'th prime number */
   T Get(T i) {
      while (i >= primes.size())
         UpdatePrimes(2 * primes.back());
      return primes[i];
   }

private:
   /** Incrementally updated cache of primes */
   std::vector<T> primes;

   /** Adds new prime numbers up to and including 'newmax' using the sieve of Eratosthenes (TODO: quite naive implementation) */
   void UpdatePrimes(T newmax) {
      // we reallocate 'maybe_prime' every time, to avoid having it lying around and occupying memory
      // TODO: it is unnecessary to (allocate and) update maybe_prime[i] for i <= primes.back()
      std::vector<bool> maybe_prime(newmax + 1, true);
      // remove all multiples of any prime numbers already in 'primes'
      for (T i = 0, n = primes.size(); i < n; ++i) {
         T pi = primes[i];
         for (T j = pi * pi; j <= newmax; j += pi)
            maybe_prime[j] = false;
      }
      // generate new primes between (and including) 'next' and 'newmax'
      T next = primes.back() + 1;
      for (T i = next; i <= newmax; ++i) {
         if (maybe_prime[i]) {
            primes.push_back(i);
            for (T j = i * i; j <= newmax; j += i) // note: this loop will do nothing when i > sqrt(newmax)
               maybe_prime[j] = false;
         }
      }
   }
};

/** Global 'PrimeSieve' object that can be used from anywhere (not thread-safe, though) */
extern PrimeSieve prime_sieve;

/** Returns in 'divs_out' all divisors of 'n' */
void GetDivisors(Integer n, std::vector<Integer> &divs_out);

/** Returns whether 'clp' includes the value 'val' */
inline bool Includes(const Clp &clp, const Integer &val) {
   if (IsSingleton(clp)) // fast handling of common case
      return (clp.GetBase() == val);
   if (IsEmpty(clp))
      return false;
   Integer diff = val - clp.GetBase();
   // check boundaries
   if (diff < 0) return false;
   if (clp.GetUpper() < val) return false;
   return (diff % clp.GetStride() == 0);
}

/** Returns whether 'a' fully includes 'b' */
inline bool Includes(const Clp &a, const Clp &b) {
   if (IsSingleton(a) && IsSingleton(b)) // fast handling of common case
      return (a.GetBase() == b.GetBase());
   if (a.GetCount() < b.GetCount())
      return false;
   // note: here a.GetStride() > 0 must hold, since 'a' is not a singleton
   Integer diff = b.GetBase() - a.GetBase();
   // check boundaries
   if (diff < 0) return false;
   if (a.GetUpper() < b.GetUpper()) return false;
   // check that every value in 'b' is visited by 'a'
   if (diff % a.GetStride() != 0)
      return false;
   if (b.GetStride() % a.GetStride() != 0)
      return false;
   return true;
}

inline Clp GLB(const Clp &a, const Clp &b) {
   // The following code is based on the intersection operation as described in
   // [Sen and Srikant. Executable Analysis using Abstract Interpretation with Circular Linear Progressions. 2007].
   if (IsEmpty(a)) return a;
   if (IsEmpty(b)) return b;
   Clp a_ = a, b_ = b;
   // sort on bases
   if (a_.GetBase() > b_.GetBase())
      std::swap(a_, b_);
   // handle special case where 'a_' is a singleton, to simplify the remaining code
   if (IsSingleton(a_)) {
      if (a_.GetBase() == b_.GetBase()) return a_;
      else return Clp();
   }
   Integer upper = std::min(a_.GetBase() + a_.GetStride() * (a_.GetCount() - 1),
      b_.GetBase() + b_.GetStride() * (b_.GetCount() - 1));
   Integer base = upper + 1; // dummy initial value that is too large
   // Now find the smallest concrete value common to both CLPs by first finding the smallest positive
   // solution x == x0 to the congruence
   //
   //    (b_.GetBase() - a_.GetBase()) + b_.GetStride() * x === 0  (mod a_.GetStride()),
   //
   // which can be rewritten as
   //
   //    b_.GetStride() * x === a_.GetBase() - b_.GetBase()  (mod a_.GetStride()).
   //
   // The base is then given by
   //
   //    b_.GetBase() + b_.GetStride() * x0.
   //
   // If there is no such solution, or the base becomes larger than 'upper', then the GLB is empty.
   Integer s, t, rhs = a_.GetBase() - b_.GetBase();
   Integer d = XGCD(b_.GetStride(), a_.GetStride(), s, t);
   if (rhs % d == 0) {
      Integer xmod = a_.GetStride() / d;
      Integer x0 = mod(s * rhs / d, xmod);
      base = b_.GetBase() + b_.GetStride() * x0;
   }
   if (base > upper)
      return Clp(); // empty
   // compute stride = LCM(a_.GetStride(), b_.GetStride()) by reusing the GCD
   Integer stride = abs(a_.GetStride() * b_.GetStride()) / d;
   if (stride == 0) return Clp(base);
   Integer count = (upper - base) / stride + 1;
   return Clp(base, stride, count);
}

inline Clp LUB(const Clp &a, const Clp &b) {
   if (ClpUtils::IsEmpty(a)) return b;
   if (ClpUtils::IsEmpty(b)) return a;
   Integer base = std::min(a.GetBase(), b.GetBase());
   Integer stride = GCD(a.GetStride(), b.GetStride());
   stride = GCD(stride, a.GetBase() - b.GetBase());
   Integer count;
   if (stride != 0) {
      Integer upper = std::max(a.GetBase() + a.GetStride() * (a.GetCount() - 1), b.GetBase() + b.GetStride() * (b.GetCount() - 1));
      count = (upper - base) / stride + 1;
   }
   else count = 1;
   return Clp(base, stride, count);
}

/** TODO: I haven't proved that "canonized" CLPs are in fact unique, i.e., that
   there can't be more than one canonized CLPs that represent the same set */
inline void Canonize(Clp &clp, Size size_in_bits) {
   if (size_in_bits.IsInfinity())
      return; // already in canonical form
   Integer width = RepresentableRangeWidth<Integer>(size_in_bits.AsBaseIntType()), mask = width - 1;
   // Reduce 'count' so that no concrete value is included more than once in the CLP. The maximum 'count' necessary
   // is given by width / GCD(stride, width). This follows from that all solutions to the linear congruence
   //
   //    stride * x === 0  (mod width)
   //
   // are congruent modulo width / GCD(stride, width) [http://en.wikipedia.org/wiki/Linear_congruence_theorem#Solving_a_linear_congruence].
   // Clearly, x == 0 is a solution, and x == width / GCD(stride, width) is the smallest positive solution.
   Integer d = ClpUtils::GCD_Pow2(clp.GetStride(), width);
   Integer maxcount = width / d;
   if (clp.GetCount() >= maxcount) {
      // there exist only one gap length - set the base to the smallest unsigned
      // value and the stride to this gap length (this handles singleton and top cases as well)
      clp.SetBase(clp.GetBase() & (d - 1)); // note: d is always a power of 2
      clp.SetStride(d & mask); // "& mask" is only for the case d == width
      clp.SetCount(maxcount);
   } else if (clp.GetCount() == maxcount - 1) {
      // there are exactly two gap lengths, the larger of which occurs only once -
      // set the base to the first value after the larger gap and set the stride
      // to the smaller gap length
      clp.SetBase((clp.GetUpper() + clp.GetStride() + d) & mask);
      clp.SetStride(d);
   } else {
      // there are two or three gap lengths - confine the base to [0..width) and the
      // stride to [0..width/2) by "reversing" the CLP if necessary
      clp.SetStride(clp.GetStride() & mask);
      // note that clp.GetStride() != width/2 at this point, otherwise
      // clp.GetCount() >= maxcount above would be true
      if (clp.GetStride() < (width >> 1))
         clp.SetBase(clp.GetBase() & mask);
      else {
         clp.SetBase(clp.GetUpper() & mask);
         clp.SetStride(width - clp.GetStride());
      }
   }
}

inline Clp Add(const Clp &a, const Clp &b) {
   if (IsEmpty(a)) return a;
   if (IsEmpty(b)) return b;
   Clp sum;
   sum.SetBase( a.GetBase() + b.GetBase() );
   sum.SetStride( GCD(a.GetStride(), b.GetStride()) );
   if (sum.GetStride() != 0) {
      // here, the term sum.GetBase() is implicit in 'upper'
      Integer upper = a.GetStride() * (a.GetCount() - 1) + b.GetStride() * (b.GetCount() - 1);
      sum.SetCount( upper / sum.GetStride() + 1 );
   }
   return sum;
}

inline Clp Mul(const Clp &a, const Clp &b) {
   if (IsEmpty(a)) return a;
   if (IsEmpty(b)) return b;
   Clp prod;
   Integer ua = a.GetBase() + a.GetStride() * (a.GetCount() - 1);
   Integer ub = b.GetBase() + b.GetStride() * (b.GetCount() - 1);
   Integer laXlb = a.GetBase() * b.GetBase(),
      laXub = a.GetBase() * ub,
      uaXlb = ua * b.GetBase(),
      uaXub = ua * ub;
   // compute min(laXlb, laXub, uaXlb, uaXub) and max(laXlb, laXub, uaXlb, uaXub) in parallel
   Integer l = laXlb, u = laXlb;
   if (laXub < l) l = laXub; else if (u < laXub) u = laXub;
   if (uaXlb < l) l = uaXlb; else if (u < uaXlb) u = uaXlb;
   if (uaXub < l) l = uaXub; else if (u < uaXub) u = uaXub;
   prod.SetBase( l );
   prod.SetStride( GCD(GCD(abs(a.GetBase() * b.GetStride()), abs(b.GetBase() * a.GetStride())), a.GetStride() * b.GetStride()) );
   if (prod.GetStride() != 0)
      prod.SetCount( (u - prod.GetBase()) / prod.GetStride() + 1 );
   return prod;
}

/* @pre b.GetUpper() < 0 or 0 < b.GetBase() */
inline Clp Div(const Clp &a, const Clp &b) {
   // This implementation differs somewhat from that described by Sen and Srikant.  Their
   // design pessimistically sets the stride of the quotient to 1 whenever 'b' is not a
   // singleton, whereas this implementation attempts to derive a larger stride.  Also,
   // their handling of the case where 'b' is a singleton is incorrect.
   if (IsEmpty(a)) return a;
   if (IsEmpty(b)) return b;
   Clp q;
   const Integer &la = a.GetBase(), &lb = b.GetBase();
   Integer ua = a.GetUpper();
   if (IsSingleton(b)) {
      if (IsSingleton(a)) return Clp(la / lb); // trivial case
      Integer laDlb = la / lb, uaDlb = ua / lb;
      q.SetBase(std::min(laDlb, uaDlb));
      q.SetStride(Integer(1)); // start with a pessimistic stride
      if (a.GetStride() % lb == 0) { // if 'b' divides the stride sa of 'a'
         // If 'b' divides 'la' as well, each element of 'q', given by
         //    (la + sa * i) / lb, where 0 <= i < a.GetCount(),
         // can be written as
         //    la / lb + (sa / lb) * i.
         // Since la / lb is an element of 'q', a safe stride is thus given by |sa / lb|.
         // If 'b' does not divide 'la', at least all concrete quotients will be
         // rounded-off in the same direction if 'a' lies entirely on one side of 0. Thus,
         // the same stride is safe in this case as well.
         if (la % lb == 0 || ua < 0 || la > 0)
            q.SetStride(abs(a.GetStride() / lb));
      }
      q.SetUpper(std::max(laDlb, uaDlb));
      return q;
   }
   Integer ub = b.GetUpper();
   // compute the endpoints of 'q'
   Integer laDlb, laDub, uaDlb, uaDub;
   laDlb = la / lb;
   laDub = la / ub;
   uaDlb = ua / lb;
   uaDub = ua / ub;
   // compute min(laDlb, laDub, uaDlb, uaDub) and max(laDlb, laDub, uaDlb, uaDub) in parallel
   Integer l = laDlb, u = laDlb;
   if (laDub < l) l = laDub; else if (u < laDub) u = laDub;
   if (uaDlb < l) l = uaDlb; else if (u < uaDlb) u = uaDlb;
   if (uaDub < l) l = uaDub; else if (u < uaDub) u = uaDub;
   q.SetBase(l);
   // Analogous to the case above where 'b' is a singleton, a stride > 1 might be possible if
   // every concrete value of 'b',
   //    (lb + sb * j) where 0 <= j < b.GetCount(),
   // divides the stride sa of 'a', and if every such value also divides 'la' or all concrete
   // values of 'a' lie on the same side of 0.  We test this using a loop over the concrete values
   // of 'b'.  Note that this loop shouldn't make many iterations in the general case, since if
   // b.GetCount() is large, it is unlikely that a stride > 1 is found, and this should be detected
   // after only a few iterations.  Conversely, if such a stride is found, b.GetCount() is likely
   // quite small.  This can be seen by considering that lcm( lb, lb + sb, lb + 2 * sb, ..., ub )
   // must divide sa.
   Integer stride(0);
   bool a1side = (ua < 0 || la > 0);
   // to increase the chances of an early exit, loop through 'b' starting from
   // the endpoint with the largest absolute value
   Integer belem, inc;
   if (abs(lb) > abs(ub)) { belem = lb; inc = b.GetStride(); }
   else { belem = ub; inc = -b.GetStride(); }
   // also, instead of using 'la', select the element of 'a' with the smallest absolute value
   Integer aelem = (abs(la) < abs(ua))? la : ua;
   for (Integer j(0); j != b.GetCount(); ++j, belem += inc) {
      if (a.GetStride() % belem != 0 ||
         !(aelem % belem == 0 || a1side) ||
         stride == 1) // since the stride will get no better, exit early
      { stride = 1; break; }
      // All elements of 'q' can be written as
      //    (aelem + sa * k) / (lb + sb * j) == aelem / (lb + sb * j) + sa / (lb + sb * j) * k,
      // where 0 <= j < b.GetCount() and k is some integer.  Thus, each j introduces the element
      // aelem / (lb + sb * j), which is congruent to 'l' modulo aelem / (lb + sb * j) - l, as well
      // as elements congruent to this element modulo sa / (lb + sb * j).
      stride = GCD(stride, GCD(aelem / belem - l, a.GetStride() / belem));
   }
   q.SetStride(stride);
   q.SetUpper(u);
   return q;
}

/** @pre a.GetBase() >= 0
   @pre b.GetBase() >= 0 */
inline Clp LShift(const Clp &a, const Clp &b) {
   if (IsEmpty(a)) return a;
   if (IsEmpty(b)) return b;
   Clp shifted;
   shifted.SetBase(a.GetBase() << b.GetBase());
   if (IsSingleton(b))
      shifted.SetStride(a.GetStride() << b.GetBase());
   else
      shifted.SetStride( GCD(a.GetBase(), a.GetStride()) << b.GetBase() );
   if (shifted.GetStride() != 0)
      shifted.SetUpper( a.GetUpper() << b.GetUpper() );
   return shifted;
}

/** @pre b.GetBase() >= 0 */
inline Clp RShift(const Clp &a, const Clp &b) {
   // This implementation differs somewhat from that described by Sen and Srikant.  Their
   // design pessimistically sets the stride of the result to 1 whenever 'b' is not a
   // singleton, whereas this implementation attempts to derive a larger stride.  Also,
   // their handling of the case where 'b' is a singleton is incorrect.
   if (IsEmpty(a)) return a;
   if (IsEmpty(b)) return b;
   Clp shifted;
   Integer l, u;
   const Integer &la = a.GetBase(), &lb = b.GetBase(), ua = a.GetUpper(), ub = b.GetUpper();
   if (la < 0) l = la >> lb;
   else l = la >> ub;
   if (ua < 0) u = ua >> ub;
   else u = ua >> lb;
   shifted.SetBase(l);
   Integer s(1); // pessimistic initial stride
   // Now try to increase the stride.  The elements of 'shifted' are given by
   //    (la + sa * i) >> (lb + sb * j), where 0 <= i < a.GetCount(), 0 <= j < b.GetCount().  (1)
   // If for every j it holds that
   //    (sa >> (lb + sb * j)) << (lb + sb * j) == sa,                                        (2)
   // that is, the (lb + sb * j) least significant bits of 'sa' are 0, then the bits shifted
   // off of 'a' are not affected by the addition of the stride 'sa' and are therefore fixed.
   // Then expression (1) can be rewritten as
   //    la >> (lb + sb * j) + (sa >> (lb + sb * j)) * i.
   // Thus, a stride that divides both
   //    (la >> (lb + sb * (j + 1))) - (la >> (lb + sb * j)) for 0 <= j < b.GetCount() - 1,   (3)
   // and
   //    (sa >> (lb + sb * j)) for 0 <= j < b.GetCount()                                      (4)
   // is safe to use for 'shifted'.
   //
   // compute a mask for the bits of 'a' that are guaranteed not to be shifted off
   Integer mask(-1);
   mask <<= ub;
   // to test condition (2) for all j, it suffices to test it for j == b.GetCount() - 1.
   if (a.GetStride() == (a.GetStride() & mask)) {
      // Compute a stride 'sj' that divides expression (3) and a stride 'si' that divides
      // expression (4).  A safe stride for 'shifted' is then given by gcd(sj, si).
      Integer sj, si;
      if (IsSingleton(b))
         sj = 0; // 'sj' is undefined, because j can only take on the value 0
      else {
         // If the bits of 'la' that might be shifted off are all 0 or all 1, then
         // expression (3), for all j, is a multiple of
         //    (la >> (ub - sb)) - (la >> ub).
         // (This is quite easy to show, but it takes some math.)  In fact, this
         // holds if said bits of 'la' follow any repeating bit pattern of length
         // b.GetStride(), but these cases are skipped here for simplicity.
         if (la == (la & mask) || la == (la | ~mask))
            sj = abs( (la >> (ub - b.GetStride())) - (la >> ub) );
         else
            sj = 1;
      }
      // expression (4), for all j, is a multiple of sa >> ub
      si = a.GetStride();
      si >>= ub;
      s = GCD(si, sj);
   }
   shifted.SetStride(s);
   shifted.SetUpper(u);
   return shifted;
}

inline Clp Not(const Clp &a) { return Clp(~a.GetUpper(), a.GetStride(), a.GetCount()); }

/** Returns a bit mask with 1s in all bit positions to the right of and
   including the leftmost bit set in 'x' */
inline Integer fill_right(Integer x) {
   Integer tmp = x;
   tmp >>= 1;
   tmp |= x;
   for (int i = 2; tmp != x; i *= 2) {
      x = tmp;
      tmp >>= i;
      tmp |= x;
   }
   return x;
}

/** Returns 2^m, where m is the position of the leftmost bit set in 'x' */
inline Integer hibit(const Integer &x) { return (fill_right(x) + 1) >> 1; }

Clp And(const Clp &a, const Clp &b);

}

#endif // ifndef CLP_H_INCL
