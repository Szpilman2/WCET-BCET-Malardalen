#include "SymbClpPtrSet.h"
#include "ClpValue.h"
#include "tools/Integer.h"
#include "program_state/value/SymbPointerSet.inl"

template class SymbPointerSet<SymbClpPtrSet>;

class SymbClpPtrSet::LazyIterator : public SopIterator {
   const SymbClpPtrSet &ptr;
   SymbolToOffsetType::const_iterator iter, end;
   Integer i, offset, mask;
   
public:
   LazyIterator(const SymbClpPtrSet& ptr) : ptr(ptr) {
      iter = ptr.symbol_to_offset.begin();
      end = ptr.symbol_to_offset.end();
      if (iter != end) {
         i = 0;
         offset = iter->second->GetClp().GetBase();
      }
      if (!ptr.SizeInBits().IsInfinity())
         mask = LargestRepresentableUnsigned<Integer>(ptr.SizeInBits().AsBaseIntType());
      else
         mask = -1;
   }

   /** @copydoc SopIterator::IsSingleton */
   virtual bool IsSingleton() {
      return ptr.symbol_to_offset.size() == 1 &&
         ptr.symbol_to_offset.begin()->second->IsSingleElem();
   }

   /** @copydoc SopIterator::AtEnd */
   virtual bool AtEnd() { return iter == end; }

   /** @copydoc SopIterator::GetNext */
   virtual SymbolOffsetPair GetNext() {
      assert(iter != end);
      SymbolOffsetPair sop(iter->first, (offset & mask).As<unsigned long long>());
      ++i;
      if (i != iter->second->GetClp().GetCount())
         offset += iter->second->GetClp().GetStride();
      else {
         ++iter;
         if (iter != end) {
            i = 0;
            offset = iter->second->GetClp().GetBase();
         }
      }
      return sop;
   }
};

SopIterator* SymbClpPtrSet::GetIterator_Private() const { return new LazyIterator(*this); }

template struct Ops_SymbPointerSet<SymbClpPtrSet>;

// ------------------------------------------------------------------------------->
// SymbClpMemDomain

Value *SymbClpMemDomain::CreateBasePtr(const Size &size_in_bits, const Symbol &symbol) {
   return new SymbClpPtrSet(size_in_bits, symbol, Integer(0));
}

Value *SymbClpMemDomain::CreatePointer(const Value *base_ptr, const Value *offset) {
   ClpValue _0(1, Integer(0));
   return base_ptr->Add(offset, &_0);
}
// <-------------------------------------------------------------------------------
