#ifndef CLPVALUE_H_INCL
#define CLPVALUE_H_INCL

#include "program_state/value/Bitstring.h"
#include "program_state/value/IntegerDomain.h"
#include "Clp.h"
#include <vector>

class ClpValue : public Bitstring {
public:
   /** @name Basic functionality
       @{ */
   /** Creates a top ClpValue */
   ClpValue(Size size_in_bits) : Bitstring(size_in_bits) {
      if (!size_in_bits.IsInfinity()) {
         clp.SetBase(Integer(0));
         clp.SetStride(Integer(1));
         clp.SetCount(RepresentableRangeWidth<Integer>(size_in_bits.AsBaseIntType()));
      }
      // infinite-precision top values are represented with an empty 'Clp' object
   }

   /** Creates the singleton CLP (base, 0, 1) */
   ClpValue(Size size_in_bits, const Integer &base)
      : Bitstring(size_in_bits), clp(base) { ClpUtils::Canonize(clp, size_in_bits); }

   /** Creates the interval CLP [base..base + count - 1]
      @pre 'count' is positive */
   ClpValue(Size size_in_bits, const Integer &base, const Integer &count);

   /** Creates the CLP (base, stride, count)
      @pre 'stride' is non-negative
      @pre 'count' is positive */
   ClpValue(Size size_in_bits, const Integer &base, const Integer &stride, const Integer &count);

   /** @pre clp.GetStride() is non-negative
      @pre clp.GetCount() is positive */
   ClpValue(Size size_in_bits, const Clp &clp);

   ClpValue(Size size_in_bits, const char *descr);

   /** Makes a copy of other */
   ClpValue(const ClpValue &other) : Bitstring(other), clp(other.clp) {}

   virtual ~ClpValue() {}

   ClpValue &operator =(const ClpValue &other) { this->~ClpValue(); new (this) ClpValue(other); return *this; }

   bool operator ==(const ClpValue &other) const;

   virtual const ClpValue *AsClpValue() const { return this; }

   virtual void AcceptVisitor(ValueVisitor *visitor) const { visitor->VisitClpValue(*this); }

   virtual ClpValue *Copy() const { return new ClpValue(*this); }

   virtual bool IsEqual(const Value *other) const;
   /** @} */

   /** @name Access to the CLP parameters
       @{ */
   /** Returns whether or not the signed representation of 'this' consists of a finite number of
      concrete bitstrings.
      @remark If this->SizeInBits() < Size::Infinity(), this method always returns true. */
   bool HasSignedBounds() const {
      // the signed representation of 'this' has bounds if 'this' either has finite precision,
      // or it has infinite precision but consists of a finite number of bitstrings
      return !this->SizeInBits().IsInfinity() || !this->IsTopBitstring();
   }
   /** Returns whether or not the unsigned representation of 'this' consists of a finite number of
      concrete bitstrings.  Note that in the concrete semantics, interpreting a negative bitstring
      of infinite precision (i.e., a bitstring with an infinite number of leading 1 bits) as unsigned
      gives an undefined result.  Thus, if this->SizeInBits() == Size::Infinity() and 'this' contains
      negative values, this method returns false.
      @remark If this->SizeInBits() < Size::Infinity(), this method always returns true. */
   bool HasUnsignedBounds() const {
      // the unsigned representation of 'this' has bounds if 'this' either has finite precision,
      // or it has infinite precision but consists of a finite number of *non-negative* bitstrings
      return !this->SizeInBits().IsInfinity() || (!this->IsTopBitstring() && this->clp.GetBase() >= 0);
   }
   /** @pre !IsInfAndTopBitstring(*this) */
   const Clp &GetClp() const {
      // this prevents bugs caused by accessing the (invalid) CLP data of infinite-precision top CLPs
      if (IsInfAndTopBitstring(*this))
         throw std::logic_error("The stored CLP data is invalid for infinite-precision top CLPs");
      return clp;
   }
   /** @pre this->HasSignedBounds() */
   void GetSigned(std::vector<Clp> &clps_out) const;
   /** @pre this->HasUnsignedBounds() */
   void GetUnsigned(std::vector<Clp> &clps_out) const;
   /** @} */

   /** @name Lower and upper bounds
       @{ */
   /** @pre this->HasSignedBounds() */
   Integer GetSmallestSigned() const;
   /** @pre this->HasSignedBounds() */
   Integer GetLargestSigned() const;
   /** @remark Returns 0 if !this->HasUnsignedBounds() */
   Integer GetSmallestUnsigned() const;
   /** @pre this->HasUnsignedBounds() */
   Integer GetLargestUnsigned() const;
   /** @} */

   /** @pre this->HasUnsignedBounds() */
   void GetConcrete(std::vector<Integer> &vals_out) const;

   // TODO: remove these once SymbPointer::GetSymbolOffsetPairs() has been removed
   void AsUnsigned(std::vector<Integer>&) const {}
   std::ostream & PrintAsUnsigned(std::ostream & o = std::cout) const { return o; }

   /** @name Set operations
       @{ */
   virtual bool IsSingleElem() const { return ClpUtils::IsSingleton(clp); }
   virtual bool IsTopBitstring() const {
      Size size_in_bits = this->SizeInBits();
      if (size_in_bits.IsInfinity())
         return ClpUtils::IsEmpty(clp);
      return clp.GetCount() == RepresentableRangeWidth<Integer>(size_in_bits.AsBaseIntType());
   }
   /** @} */

   /** @name Output operations
       @{ */
   virtual std::ostream &Print(std::ostream &out = std::cout) const;
   /** @} */

private:
   Clp clp;

   /** @pre !this->IsTopBitstring() */
   void GetSigUnsig(const Integer &width, const Integer &upper, std::vector<Clp> &clps_out) const;
};

namespace ClpValueUtils {
   /** @name The Three Gap Theorem
       Functions based on the Three Gap Theorem, or Steinhaus's Conjecture, which can be used to, e.g., step
       through the concrete values of a ClpValue in clockwise/counterclockwise order on the "number circle".
       See, e.g., [Noel B. Slater, 1967.  Gaps and steps for the sequence n&theta; mod 1].
       @{ */
   /** Returns in 'a_out' and 'b_out' the indices of the concrete values of 'clpval' that immediately succeed
      and proceed, respectively, the base value of 'clpval' (which itself has index 0) when placed on the
      "number circle".  If both 'lower' and 'c_out' are provided, 'c_out' is assigned the index of the concrete
      value that lies closest to 'lower' on the circle in the clockwise direction.  If 'lower' coincides with
      a value in 'clpval', 'c_out' is assigned the index of this value.
      @pre clpval.SizeInBits() != Size::Infinity() */
   void GetGapInfo(const ClpValue &clpval, Integer &a_out, Integer &b_out, const Integer *lower = 0, Integer *c_out = 0);

   /** Increments the index 'i', given gap parameters returned from GetGapInfo() */
   void Increment(const ClpValue &clpval, const Integer &a, const Integer &b, Integer &i);

   /** Decrements the index 'i', given gap parameters returned from GetGapInfo() */
   void Decrement(const ClpValue &clpval, const Integer &a, const Integer &b, Integer &i);
   /** @} */
}

struct Ops_ClpValue {
   /** @name Set operations
       @{ */
   static bool Overlaps(const ClpValue *x, const ClpValue *y);
   static bool Includes(const ClpValue *x, const ClpValue *y);
   static Value *GLB(const ClpValue *x, const ClpValue *y);
   static ClpValue *LUB(const ClpValue *x, const ClpValue *y);
   /** @} */

   /** @name Arithmetic operations
       @{ */
   static ClpValue *Neg(const ClpValue *x);
   static ClpValue *Add(const ClpValue *x, const ClpValue *y, const ClpValue *c);
   static ClpValue *CAdd(const ClpValue *x, const ClpValue *y, const ClpValue *c);
   static ClpValue *Sub(const ClpValue *x, const ClpValue *y, const ClpValue *c);
   static ClpValue *CSub(const ClpValue *x, const ClpValue *y, const ClpValue *c);
   static ClpValue *SMul(const ClpValue *x, const ClpValue *y);
   static ClpValue *UMul(const ClpValue *x, const ClpValue *y);
   static ClpValue *Mul_Trunc(const ClpValue *x, const ClpValue *y);
   // TODO: these might return bottom, when y is { 0 }
   static ClpValue *SDiv(const ClpValue *x, const ClpValue *y);
   static ClpValue *UDiv(const ClpValue *x, const ClpValue *y);
   static ClpValue *SMod(const ClpValue *x, const ClpValue *y);
   static ClpValue *UMod(const ClpValue *x, const ClpValue *y);
   /** @} */

   /** @name Bit operations
       @{ */
   static ClpValue *SExt(const ClpValue *x, Size new_size);
   static ClpValue *ZExt(const ClpValue *x, Size new_size);
   static ClpValue *LShift(const ClpValue *x, const ClpValue *y);
   static ClpValue *RShift(const ClpValue *x, const ClpValue *y);
   static ClpValue *RShiftA(const ClpValue *x, const ClpValue *y);
   static ClpValue *Not(const ClpValue *x);
   static ClpValue *And(const ClpValue *x, const ClpValue *y);
   static ClpValue *Or(const ClpValue *x, const ClpValue *y);
   static ClpValue *XOr(const ClpValue *x, const ClpValue *y);
   static ClpValue *Conc(const ClpValue *x, const ClpValue *y);
   static ClpValue *Select(const ClpValue *x, Size idx_first, Size idx_last);
   static ClpValue *Repeat(const ClpValue *x, Size nreps);
   /** @} */

   /** @name Comparison operations
       @{ */
   static ClpValue *Eq(const ClpValue *x, const ClpValue *y);
   static ClpValue *NEq(const ClpValue *x, const ClpValue *y);
   static ClpValue *SLT(const ClpValue *x, const ClpValue *y);
   static ClpValue *SLE(const ClpValue *x, const ClpValue *y);
   static ClpValue *SGE(const ClpValue *x, const ClpValue *y) { return SLE(y, x); }
   static ClpValue *SGT(const ClpValue *x, const ClpValue *y) { return SLT(y, x); }
   static ClpValue *ULT(const ClpValue *x, const ClpValue *y);
   static ClpValue *ULE(const ClpValue *x, const ClpValue *y);
   static ClpValue *UGE(const ClpValue *x, const ClpValue *y) { return ULE(y, x); }
   static ClpValue *UGT(const ClpValue *x, const ClpValue *y) { return ULT(y, x); }
   /** @} */

   /** @name Integer-to-float conversions
       @{ */
   static Value *SToF(const ClpValue *x, Size exp_size, Size frac_size);
   static Value *UToF(const ClpValue *x, Size exp_size, Size frac_size);
   /** @} */

   /** @name Miscellaneous
       @{ */
   static Value *If(const ClpValue *x, const Value *y, const Value *z);
   static ClpValue *B2N(const ClpValue *x) { return ZExt(x, Size::Infinity()); } // TODO: unnecessary: does the same as ZExt(x, inf)
   static ClpValue *Exp2(const ClpValue *x) { ClpValue _1(Size::Infinity(), Integer(1)); return LShift(&_1, x); } // TODO: unnecessary?
   /** @} */

   /** @name Restriction
       @{ */
   static Value *Restrict_NEq(const ClpValue *x, const ClpValue *y);
   static Value *Restrict_SLT(const ClpValue *x, const ClpValue *y);
   static Value *Restrict_SLE(const ClpValue *x, const ClpValue *y);
   static Value *Restrict_SGE(const ClpValue *x, const ClpValue *y);
   static Value *Restrict_SGT(const ClpValue *x, const ClpValue *y);
   static Value *Restrict_ULT(const ClpValue *x, const ClpValue *y);
   static Value *Restrict_ULE(const ClpValue *x, const ClpValue *y);
   static Value *Restrict_UGE(const ClpValue *x, const ClpValue *y);
   static Value *Restrict_UGT(const ClpValue *x, const ClpValue *y);

   static Value *Restrict_Select(const ClpValue *x, const Size& idx_first, const ClpValue *result);
   /** @} */

   /** @name Reverse operations
       @{ */
   static Value *RevSMul(const ClpValue *result, const ClpValue *fac, Size result_size);
   static Value *RevUMul(const ClpValue *result, const ClpValue *fac, Size size_in_bits);
   /** @} */

   /** @name To be implemented
       @{ */
   static ClpValue *ILog2(const ClpValue *x) { return new ClpValue(x->SizeInBits()); }

   static ClpValue *RevLShift1(const ClpValue *result, const ClpValue *y) { return new ClpValue(result->SizeInBits()); }
   static ClpValue *RevAnd(const ClpValue *result, const ClpValue *y) { return new ClpValue(result->SizeInBits()); }
   static ClpValue *RevOr(const ClpValue *result, const ClpValue *y) { return new ClpValue(result->SizeInBits()); }
   static ClpValue *RevXOr(const ClpValue *result, const ClpValue *y) { return new ClpValue(result->SizeInBits()); }

   static ClpValue *Widening(const ClpValue *x, const ClpValue *y) { return new ClpValue(x->SizeInBits()); }
   static ClpValue *Narrowing(const ClpValue *x, const ClpValue *y) { return new ClpValue(x->SizeInBits()); }
   /** @} */
};

class ClpDomain : public IntegerDomain {
public:
   /** @copydoc IntegerDomain::CreateInteger(const Size&) const */
   virtual Value* CreateInteger(const Size& size_in_bits) const { return new ClpValue(size_in_bits); }
   /** @copydoc IntegerDomain::CreateInteger(const Size&, int) const */
   virtual Value* CreateInteger(const Size& size_in_bits, int value) const { return new ClpValue(size_in_bits, Integer(value)); }
   /** @copydoc IntegerDomain::CreateInteger(const Size&, const Integer&) const */
   virtual Value* CreateInteger(const Size& size_in_bits, const Integer& value) const { return new ClpValue(size_in_bits, value); }
   /** @copydoc IntegerDomain::CreateInteger(const Size&, int, int) const */
   virtual Value* CreateInteger(const Size& size_in_bits, int lower, int upper) const {
      return new ClpValue(size_in_bits, Integer(lower), Integer(upper - lower + 1));
   }
   /** @copydoc IntegerDomain::CreateInteger(const Size&, const Integer&, const Integer&) const */
   virtual Value* CreateInteger(const Size& size_in_bits, const Integer& lower, const Integer& upper) const {
      return new ClpValue(size_in_bits, lower, upper - lower + 1);
   }
};

#endif // ifndef CLPVALUE_H_INCL
