#include "ClpValue.h"
#include "program_state/value/ValueDomain.h"
#include "program_state/value/FloatDomain.h"
#include "tools/RangeIterator.h"
#include "globals.h"
#include <algorithm>

using namespace std;

ClpValue::ClpValue(Size size_in_bits, const Integer &base, const Integer &count)
   : Bitstring(size_in_bits), clp(base, count)
{
   if (count < 1) throw logic_error("Count must be positive");
   ClpUtils::Canonize(clp, size_in_bits);
}

ClpValue::ClpValue(Size size_in_bits, const Integer &base, const Integer &stride, const Integer &count)
   : Bitstring(size_in_bits), clp(base, stride, count)
{
   if (stride < 0) throw logic_error("Stride must be non-negative");
   if (count < 1) throw logic_error("Count must be positive");
   ClpUtils::Canonize(clp, size_in_bits);
}

ClpValue::ClpValue(Size size_in_bits, const Clp &clp)
   : Bitstring(size_in_bits), clp(clp)
{
   if (clp.GetStride() < 0) throw logic_error("Stride must be non-negative");
   if (clp.GetCount() < 1) throw logic_error("Count must be positive");
   ClpUtils::Canonize(this->clp, size_in_bits);
}

ClpValue::ClpValue(Size size_in_bits, const char *descr) : Bitstring(size_in_bits) {
   if (isdigit(descr[0]) || descr[0] == '-') {
      int base;
      sscanf(descr, "%d", &base);
      clp.SetBase(Integer(base));
      clp.SetCount(Integer(1));
   } else if (descr[0] == '[') {
      int base_, upper;
      sscanf(descr, "[%d..%d]", &base_, &upper);
      Integer base(base_);
      Integer count;
      if (size_in_bits.IsInfinity())
         count = Integer(upper) - base + 1;
      else {
         Integer mask = LargestRepresentableUnsigned<Integer>(size_in_bits.AsBaseIntType());
         count = ((Integer(upper) - base) & mask) + 1;
      }
      clp.SetBase(base);
      clp.SetStride(Integer(1));
      clp.SetCount(count);
   } else {
      int base_, stride_, count_;
      sscanf(descr, "(%d, %d, %d)", &base_, &stride_, &count_);
      Integer base(base_), stride(stride_), count(count_);
      if (stride < 0) throw logic_error("Stride must be non-negative");
      if (count < 1) throw logic_error("Count must be positive");
      clp.SetBase(base);
      clp.SetStride(stride);
      clp.SetCount(count);
   }
   ClpUtils::Canonize(clp, size_in_bits);
}

bool ClpValue::operator ==(const ClpValue &other) const {
   return this->SizeInBits() == other.SizeInBits() && this->clp == other.clp;
}

bool ClpValue::IsEqual(const Value *other) const {
   const ClpValue *other_ = other->AsClpValue();
   if (other_ == 0) return false;
   else return *this == *other_;
}

void ClpValue::GetSigned(std::vector<Clp> &clps_out) const {
   if (!this->HasSignedBounds())
      throw logic_error("Cannot represent an unbounded ClpValue with the Clp class");
   if (this->SizeInBits().IsInfinity()) {
      clps_out.push_back(clp);
      return;
   }
   Integer width = RepresentableRangeWidth<Integer>(*this), upper = (width >> 1) - 1;
   GetSigUnsig(width, upper, clps_out);
}

/** @pre num >= 0
   @pre denom > 0 */
template <class T>
T ceildiv(const T &num, const T &denom) { return (num + denom - 1) / denom; }

void ClpValue::GetUnsigned(std::vector<Clp> &clps_out) const {
   if (!this->HasUnsignedBounds())
      throw logic_error("Cannot represent an unbounded ClpValue with the Clp class");
   if (this->SizeInBits().IsInfinity()) {
      clps_out.push_back(clp);
      return;
   }
   Integer width = RepresentableRangeWidth<Integer>(*this), upper = width - 1;
   GetSigUnsig(width, upper, clps_out);
}

Integer ClpValue::GetSmallestSigned() const {
   if (!this->HasSignedBounds())
      throw logic_error("Cannot retrieve the smallest concrete value of an unbounded ClpValue");
   if (this->SizeInBits().IsInfinity())
      return clp.GetBase();
   Integer width = RepresentableRangeWidth<Integer>(SizeInBits().AsBaseIntType());
   Integer lower = width >> 1, mask = width - 1;
   Integer a, b, c;
   ClpValueUtils::GetGapInfo(*this, a, b, &lower, &c);
   Integer val = (clp.GetBase() + c * clp.GetStride()) & mask;
   if (val >= lower)
      val -= width;
   return val;
}

Integer ClpValue::GetLargestSigned() const {
   if (!this->HasSignedBounds())
      throw logic_error("Cannot retrieve the largest concrete value of an unbounded ClpValue");
   if (this->SizeInBits().IsInfinity())
      return clp.GetUpper();
   Integer width = RepresentableRangeWidth<Integer>(SizeInBits().AsBaseIntType());
   Integer lower = width >> 1, mask = width - 1;
   Integer a, b, c;
   ClpValueUtils::GetGapInfo(*this, a, b, &lower, &c);
   ClpValueUtils::Decrement(*this, a, b, c);
   Integer val = (clp.GetBase() + c * clp.GetStride()) & mask;
   if (val >= lower)
      val -= width;
   return val;
}

Integer ClpValue::GetSmallestUnsigned() const {
   if (!this->HasUnsignedBounds())
      return Integer(0); // safe lower bound
   if (this->SizeInBits().IsInfinity())
      return clp.GetBase();
   Integer lower(0), mask = LargestRepresentableUnsigned<Integer>(SizeInBits().AsBaseIntType());
   Integer a, b, c;
   ClpValueUtils::GetGapInfo(*this, a, b, &lower, &c);
   Integer val = (clp.GetBase() + c * clp.GetStride()) & mask;
   return val;
}

Integer ClpValue::GetLargestUnsigned() const {
   if (!this->HasUnsignedBounds())
      throw logic_error("Cannot retrieve the largest concrete value of an unbounded ClpValue");
   if (this->SizeInBits().IsInfinity())
      return clp.GetUpper();
   Integer lower(0), mask = LargestRepresentableUnsigned<Integer>(SizeInBits().AsBaseIntType());
   Integer a, b, c;
   ClpValueUtils::GetGapInfo(*this, a, b, &lower, &c);
   ClpValueUtils::Decrement(*this, a, b, c);
   Integer val = (clp.GetBase() + c * clp.GetStride()) & mask;
   return val;
}

void ClpValue::GetConcrete(std::vector<Integer> &vals_out) const {
   // TODO: should return the signed representation instead of the unsigned representation
   if (!this->HasUnsignedBounds())
      throw std::logic_error("Cannot enumerate an unbounded ClpValue");
   if (SizeInBits().IsInfinity() || ClpUtils::IsSingleton(clp)) {
      ClpUtils::GetConcrete(clp, vals_out);
      return;
   }
   Integer width = RepresentableRangeWidth<Integer>(SizeInBits().AsBaseIntType()), mask = width - 1;
   Integer lower(0);
   Integer a, b, c;
   ClpValueUtils::GetGapInfo(*this, a, b, &lower, &c);
   Integer i = c;
   do {
      vals_out.push_back((clp.GetBase() + i * clp.GetStride()) & mask);
      ClpValueUtils::Increment(*this, a, b, i);
   } while (i != c);
}

std::ostream &ClpValue::Print(std::ostream &out) const {
   if (this->IsTopBitstring())
      return out << "[MININT..MAXINT]";
   vector<Clp> clps;
   this->GetSigned(clps);
   if (clps.size() == 1) {
      // try to use more compact notation
      const Clp &c = clps.front();
      if (ClpUtils::IsSingleton(c))
         return out << c.GetBase();
      else if (c.GetStride() == 1 && c.GetCount() > 2) // interval wider than 2
         return out << '[' << c.GetBase() << ".." << c.GetUpper() << ']';
   }
   // use set notation
   out << '{';
   vector<Integer> vals;
   for (RangeIterator<vector<Clp> > c(clps);;) {
      if (ClpUtils::IsSingleton(*c))
         out << c->GetBase();
      else if (c->GetStride() == 1 && c->GetCount() > 2) // interval wider than 2
         out << c->GetBase() << ".." << c->GetUpper();
      else if (c->GetCount() > 3)
         out << c->GetBase() << ',' << c->GetBase() + c->GetStride() << ",...," << c->GetUpper();
      else {
         // print out each of the (at most three) concrete values
         vals.clear();
         ClpUtils::GetConcrete(*c, vals);
         for (RangeIterator<vector<Integer> > v(vals);;) {
            out << *v;
            ++v;
            if (v) out << ',';
            else break;
         }
      }
      ++c;
      if (c) out << ',';
      else break;
   }
   out << '}';
   return out;
}

// -----------------------------------------------------------------------------
// private members of ClpValue

void ClpValue::GetSigUnsig(const Integer &width, const Integer &upper, std::vector<Clp> &clps_out) const {
   Integer base = clp.GetBase();
   if (base > upper) base -= width;
   // special handling of singletons
   if (ClpUtils::IsSingleton(clp)) {
      clps_out.push_back( Clp(base) );
      return;
   }
   Integer mask = width - 1;
   // compute the # of sub-CLPs that would result from a simple unwrap-and-split
   // strategy, to enable an early exit from the more sophisticated strategy below
   Integer maxsub = ceildiv(max(Integer(0), (base + clp.GetStride() * (clp.GetCount() - 1)) - upper + 1), width) + 1;
   // retrieve gap information
   Integer a, b, lower = upper + 1, c;
   ClpValueUtils::GetGapInfo(*this, a, b, &lower, &c);
   Integer ab_diff = a - b, k = clp.GetCount() - a;
   Integer alpha = (a * clp.GetStride()) & mask, beta = width - ((b * clp.GetStride()) & mask), alpbet = alpha + beta;
   // precompute some values needed for the special case that alpha == beta (explained below)
   Integer m = width / ClpUtils::GCD_Pow2(clp.GetStride(), width);
   Integer d, s, dummy;
   d = ClpUtils::XGCD(a, m, s, dummy);
   Size log2md = mpz_scan1((m / d).GetMpz().get_mpz_t(), 0);
   // Starting from the smallest concrete value (index 'c'), step one revolution around the number circle and
   // divide 'this' into smaller, non-wrapping CLPs.  If the number of CLPs ever becomes larger than 'maxsub',
   // abandon this strategy and resort to a simple unwrap-and-split strategy.
   std::vector<Clp> clps;
   Integer stride, count, nleft = clp.GetCount();
   Integer i = c, incr;
   for (;;) { // breaks when nleft == 0
      // check for early exit
      if (maxsub <= clps.size()) {
         // a simple unwrap-and-split strategy would give fewer sub-CLPs, so abandon this strategy
         clps.clear();
         break;
      }
      // set base
      base = clp.Get(i) & mask;
      if (base > upper) base -= width;
      // determine stride and increment (of the index 'i'), and compute the count
      if (alpha == beta && (i < k || b <= i)) {
         // When alpha == beta, consecutive "alpha" and "beta" sub-CLPs can be merged into longer sub-CLPs.
         // This may speed up the computations considerably, and also gives fewer sub-CLPs.  Note that in
         // this situation, it holds that
         //    i + a === i - b  (mod m),
         // where 'm' is the maximum number of unique concrete values with the current stride and modulus.
         // Thus, when i < k or b <= i, it is equivalent to update 'i' according to either the left-hand
         // side above:
         //    i = mod(i + a, m),
         // or the right-hand side:
         //    i = mod(i - b, m).
         // We use the first alternative here.   We want to make as many such increments as possible in one
         // go, so we must compute the number of such increments before 'i' enters the interval [k..b-1].
         // 
         // Let u = b - k - 1.  To get the minimum number of steppings by 'a' before 'i' enters [k..b-1],
         // we need to find the smallest positive solutions c0, c1, ..., cu to the following linear
         // congruences, and then find the smallest of these solutions.
         //    i + a * c0 === k    (mod m),
         //    i + a * c1 === k+1  (mod m),
         //    ...
         //    i + a * cu === b-1  (mod m).
         // Every one of these congruences must have solutions, otherwise there would be indices
         // in [k..b-1] that would not be included in the CLP.  Let d = gcd(a, m) and 's' be the
         // Bezout coefficient for 'a'.  Further let all the congruences above be represented by
         //    i + a * cj === k+j  (mod m),
         // which can be rewritten as
         //    a * cj === k+j - i  (mod m).
         // Each (smallest positive) solution cj is given by
         //    cj = mod(s * (k+j - i) / d, m / d).
         // In fact, all these solutions can be represented by a single CLP with
         //    base   s * (k - i) / d,
         //    stride s / d,
         //    count  u + 1.
         // To make this CLP wrap around at m / d, we set its size in bits to log2(m / d).  (Note
         // that m / d is guaranteed to be a power of 2.)  Finally, we can use the already existing
         // logic to extract the smallest concrete value of this CLP.
         stride = alpha;
         incr = a;
         if (k == b)
            count = nleft; // the interval [k..b-1] is empty - use up all remaining steps
         else {
            ClpValue counts(log2md, s * (k - i) / d, s / d, b - k);
            count = counts.GetSmallestUnsigned() + 1;
         }
      }
      // general case
      else {
         if (i < k) { // 0 <= i < k
            stride = alpha;
            incr = a;
            count = ceildiv(k - i, a) + 1;
         } else if (i < b) { // k <= i < b
            stride = alpbet;
            incr = ab_diff;
            if (ab_diff < 0) count = ceildiv(i - k + 1, -ab_diff) + 1;
            else count = ceildiv(b - i, ab_diff) + 1;
         } else { // b <= i < clp.GetCount()
            stride = beta;
            incr = -b;
            count = ceildiv(i - b + 1, b) + 1;
         }
      }
      if (count > nleft) count = nleft; // clamp the count
      clps.push_back( Clp(base, stride, count) );
      nleft -= count;
      if (nleft == 0) break;
      i = ClpUtils::mod(i + incr * (count - 1), m); // increment 'i' to the last element of the current segment
      ClpValueUtils::Increment(*this, a, b, i); // increment 'i' to the start of the next segment
   }
   // if the above strategy succeeded, return the resulting sub-CLPs
   if (!clps.empty()) {
      clps_out.insert(clps_out.end(), clps.begin(), clps.end());
      return;
   }
   // otherwise, resort to unwrap-and-split
   base = clp.GetBase();
   if (base > upper) base -= width;
   stride = clp.GetStride();
   nleft = clp.GetCount();
   clps_out.reserve(clps_out.size() + maxsub.As<vector<Clp>::size_type>());
   for (;;) { // breaks when nleft == 0
      count = min(nleft, (upper - base) / stride + 1);
      clps_out.push_back( Clp(base, stride, count) );
      nleft -= count;
      if (nleft == 0) break;
      base += stride * count - width;
   }
}

namespace ClpValueUtils {

void GetGapInfo(const ClpValue &clpval, Integer &a_out, Integer &b_out, const Integer *lower, Integer *c_out) {
   if (clpval.SizeInBits().IsInfinity())
      throw std::logic_error("No gap information can be retrieved from infinite-precision CLPs, since they do not wrap around");
   const Clp &clp = clpval.GetClp();
   if (ClpUtils::IsSingleton(clp)) {
      a_out = b_out = 0;
      if (lower && c_out)
         *c_out = 0;
      return;
   }
   const Integer width = RepresentableRangeWidth<Integer>(clpval.SizeInBits().AsBaseIntType()), mask = width - 1;
   const Integer m = clp.GetCount() - 1;
   // 'alpha' and 'beta' are the non-negative arc lengths between clp.GetBase() and its closest neighbours
   // to the right and left, respectively, on the "number circle" on which 'clp' wraps around. 'a' and 'b' are the
   // respective indices of said neighbours. 'c' is the index of the concrete value of 'clp' closest to 'lower'
   // on the right, and 'gamma' is the non-negative arc length between 'lower' and this value. If 'lower' is
   // an element of 'clp', 'c' will eventually be set to this element and 'gamma' to 0.
   // This notation is borrowed from [Noel B. Slater, 1967.  Gaps and steps for the sequence n&theta; mod 1].
   Integer a, b, c, alpha, beta, gamma, gamma_, steps;
   a = b = 1;
   alpha = clp.GetStride();
   beta = width - clp.GetStride();
   if (lower && c_out) {
      c = 0;
      gamma = (clp.GetBase() - *lower) & mask;
      gamma_ = (clp.GetBase() + clp.GetStride() - *lower) & mask;
      if (gamma_ < gamma) {
         c = 1;
         gamma = gamma_;
      }
   } else {
      // set dummy values
      c = 0;
      gamma = width;
   }
   // this loop is very similar to the Euclidean algorithm, but interleaves updates of 'c' and 'gamma',
   // as well as uses a different termination criterion
   while (a + b < clp.GetCount()) { // due to Eq. (5) in the paper cited above
      if (alpha < beta) {
         // update 'c' and 'gamma' using 'a' and 'alpha', and 'b' and 'beta'
         // here 'c' is first stepped once by 'b' (and 'gamma' decreased by 'beta'), which makes it
         // appear counterclockwise of 'lower' on the circle, and then stepped by 'a' the minimum
         // number of times to make it appear clockwise again.
         steps = ceildiv(-(gamma - beta), alpha); // no. steps with stride 'alpha' (or 'a')
         if (steps <= (m - (c + b)) / a) { // check if such a stepping can be "afforded"
            gamma_ = gamma - (beta - steps * alpha);
            if (gamma_ < gamma) { // update only if this decreases 'gamma'
               c += b + steps * a;
               gamma = gamma_;
            }
         }
         // update 'b' and 'beta' using 'a' and 'alpha'
         steps = std::min((beta - 1) / alpha, (m - b) / a); // no. steps with stride 'alpha' (or 'a')
         b += steps * a;
         beta -= steps * alpha;
      } else {
         // update 'c' and 'gamma' using 'b' and 'beta'
         steps = std::min(gamma / beta, (m - c) / b); // no. steps with stride 'beta' (or 'b')
         c += steps * b;
         gamma -= steps * beta;
         // update 'a' and 'alpha' using 'b' and 'beta'
         steps = std::min((alpha - 1) / beta, (m - a) / b); // no. steps with stride 'beta' (or 'b')
         a += steps * b;
         alpha -= steps * beta;
      }
   }
   a_out = a;
   b_out = b;
   if (lower && c_out)
      *c_out = c;
}

void Increment(const ClpValue &clpval, const Integer &a, const Integer &b, Integer &i) {
   const Integer &n = clpval.GetClp().GetCount();
   Integer incr(0);
   if (i < b) incr += a;
   if (n - a <= i) incr -= b;
   i += incr;
}

void Decrement(const ClpValue &clpval, const Integer &a, const Integer &b, Integer &i) {
   const Integer &n = clpval.GetClp().GetCount();
   Integer incr(0);
   if (i < a) incr += b;
   if (n - b <= i) incr -= a;
   i += incr;
}

}

bool Ops_ClpValue::Overlaps(const ClpValue *x, const ClpValue *y) {
   if (x->IsTopBitstring() || y->IsTopBitstring()) return true;
   if (!x->SizeInBits().IsInfinity()) {
      Integer width = RepresentableRangeWidth<Integer>(x->SizeInBits().AsBaseIntType());
      // First check that following congruence has solutions i,j:
      //    lx + sx * i === ly + sy * j  (mod width).
      // This can be rewritten as
      //    sx * i === ly - lx + sy * j  (mod width).
      // There exist solutions iff gcd(sx, width) divides the right-hand side, i.e., iff
      //    ly - lx + sy * j === 0  (mod gcd(sx, width)),
      // which can be rewritten as
      //    sy * j === lx - ly  (mod gcd(sx, width)).
      // This congruence, in turn, has solutions iff gcd(sy, gcd(sx, width)) divides lx - ly.
      Integer d = ClpUtils::GCD_Pow2(y->GetClp().GetStride(), ClpUtils::GCD_Pow2(x->GetClp().GetStride(), width));
      if ((x->GetClp().GetBase() - y->GetClp().GetBase()) % d != 0)
         return false;
   }
   // now check that there are in fact solutions i,j such that 0 <= i < cx and 0 <= j < cy
   vector<Clp> xclps, yclps;
   x->GetSigned(xclps); y->GetSigned(yclps);
   Clp glb;
   for (RangeIterator<vector<Clp> > xclp(xclps); xclp; ++xclp) {
      for (RangeIterator<vector<Clp> > yclp(yclps); yclp; ++yclp) {
         glb = ClpUtils::GLB(*xclp, *yclp);
         if (!ClpUtils::IsEmpty(glb))
            return true;
      }
   }
   return false;
}

bool Ops_ClpValue::Includes(const ClpValue *x, const ClpValue *y) {
   if (x->IsTopBitstring()) return true;
   else if (y->IsTopBitstring()) return false;
   // Consider the following congruence:
   //    lx + sx * i === ly + sy * j  (mod width).
   // For 'x' to fully include 'y', there must exist, for each 0 <= j < cy,
   // a solution i to this congruence such that 0 <= i < cx.  The congruence
   // can be rewritten as
   //    sx * i === ly - lx + sy * j  (mod width).
   // For each j, there exist solutions i iff d = gcd(sx, width) divides
   // the right-hand side.  For j == 0, d must therefore divide ly - lx,
   // which further means that d must also divide sy when j > 0 (when cy == 1,
   // sy == 0 anyway).  For each j, a solution i is given by
   // s * (ly - lx + sy * j) / d, where s is the Bezout coefficient of sx
   // returned by the extended Euclidean algorithm when computing d.
   // The smallest non-negative solution i == i0 is given by
   //    i0 = mod(s * (ly - lx + sy * j) / d, width / d).
   // Now, since d divides both ly - lx and sy, the set of (smallest
   // positive) solutions for 0 <= j < cy can be represented with a CLP with
   // size log2(width / d) bits (width / d is guaranteed to be a power of 2),
   // base s * (ly - lx) / d, stride s * sy / d, and count cy.  The largest
   // unsigned value of this CLP must be smaller than cx for 'x' to fully include 'y'.
   const Clp &xclp = x->GetClp(), &yclp = y->GetClp();
   if (x->SizeInBits().IsInfinity())
      return ClpUtils::Includes(xclp, yclp);
   if (ClpUtils::IsSingleton(xclp) && ClpUtils::IsSingleton(yclp)) // fast handling of common case
      return (xclp.GetBase() == yclp.GetBase());
   if (xclp.GetCount() < yclp.GetCount()) // simple rejection test
      return false;
   Integer diff = yclp.GetBase() - xclp.GetBase();
   Integer width = RepresentableRangeWidth<Integer>(x->SizeInBits().AsBaseIntType());
   Integer d = ClpUtils::GCD_Pow2(xclp.GetStride(), width); // postpone calling XGCD()
   if (diff % d != 0 || yclp.GetStride() % d != 0)
      return false;
   Integer s, dummy;
   ClpUtils::XGCD(xclp.GetStride(), width, s, dummy); // now we need 's', so recompute 'd'
   Integer imod = width / d;
   //Integer i;
   //for (Integer j(0); j < yclp.GetCount(); ++j) {
   //   i = ClpUtils::mod(s * (diff + j * yclp.GetStride()) / d, imod);
   //   if (i >= xclp.GetCount())
   //      return false;
   //}
   ClpValue isols(mpz_scan1(imod.GetMpz().get_mpz_t(), 0), s * diff / d,
      (s * yclp.GetStride() / d) & (width - 1), yclp.GetCount());
   return (isols.GetLargestUnsigned() < xclp.GetCount());
}

Value *Ops_ClpValue::GLB(const ClpValue *x, const ClpValue *y) {
   if (x->IsTopBitstring()) return y->Copy();
   if (y->IsTopBitstring()) return x->Copy();

   Integer width = RepresentableRangeWidth<Integer>(x->SizeInBits().AsBaseIntType());
   const Clp &c1 = x->GetClp(), &c2 = y->GetClp();
   const Integer &b1 = c1.GetBase(), &b2 = c2.GetBase();
   // We want to find the values of i and j satisfying the congruence
   //    b1 + s1 * i === b2 + s2 * j  (mod width),      (1)
   // such that 0 <= i < c1.GetCount() and 0 <= j < c2.GetCount().  The found values of i
   // then correspond to the concrete values of 'c1' that overlap with some value in 'c2',
   // and only these concrete values should be included in the returned result.
   //
   // Rewrite (1) as
   //    s1 * i === b2 - b1 + s2 * j  (mod width),      (1')
   // and let d,s = xgcd(s1, width).  For each j, one or more values of i satisfying (1)
   // exist iff d divides the right-hand side of (1'), i.e., iff
   //    b2 - b1 + s2 * j === 0  (mod d).               (2)
   // The smallest non-negative such i is then given by
   //    (s * (b2 - b1 + s2 * j) / d) mod (width / d).  (3)
   //
   // Rewrite (2) as
   //    s2 * j === b1 - b2  (mod d),                   (2')
   // and let e,t = xgcd(s2,d).  One or more j satisfying (2) exist iff e divides
   // the right-hand side of (2').  The smallest such j is then given by
   //    j0 = (t * (b1 - b2) / e) mod (d / e),
   // and any other solutions are congruent to j0 modulo d / e.
   Integer d, e, s, t, dummy;
   d = ClpUtils::XGCD(c1.GetStride(), width, s, dummy);
   e = ClpUtils::XGCD(c2.GetStride(), d, t, dummy);
   Integer div_wd = width / d, div_de = d / e;
   if (s < 0) s += div_wd; // make sure 's' is positive
   // check that any solutions to (2) exist at all
   Integer sub_b1b2 = b1 - b2;
   if (e == 0 || sub_b1b2 % e != 0)
      return domain->CreateBottomValue(x->SizeInBits());
   Integer j0 = ClpUtils::mod(t * sub_b1b2 / e, div_de);
   // check that some solutions to (2) are within the bounds of 'c2'
   if (j0 >= c2.GetCount())
      return domain->CreateBottomValue(x->SizeInBits());
   Integer numj = ceildiv(c2.GetCount() - j0, div_de); // nr. of solutions to (2) within 'c2'
   // Now plug all of the 'numj' solutions j to (2) into (3) to get the smallest non-negative i
   // satisfying (1) for each such j.  This information fits nicely into the following CLP 'isols'.
   // Its base is given by simply plugging j == j0 into (3):
   //    (s * (b2 - b1 + s2 * j0) / d) mod (width / d).
   // To compute the stride, note that the remaining values are given by
   //    (s * (b2 - b1 + s2 * (j0 + d/e * k)) / d) mod (width / d),
   // where k == 1,2,...,numj-1.  Rewrite the left-hand side of this as
   //    s * (b2 - b1 + s2 * (j0 + d/e * k)) / d
   //       == s * (b2 - b1 + s2 * j0 + s2 * d/e * k) / d
   //       == s * (b2 - b1 + s2 * j0) / d + s * (s2 * d/e * k) / d
   //       == s * (b2 - b1 + s2 * j0) / d + s * s2 / e * k.
   // This gives the stride s * s2 / e.  To get wraparound at width / d, the size in bits
   // is set to log2(width / d) (note that width / d is guaranteed to be a power of 2).
   ClpValue isols(log2(div_wd), s * (-sub_b1b2 + c2.GetStride() * j0) / d, s * c2.GetStride() / e, numj);
   // get the smallest index 'ig' at which 'c1' overlaps with 'c2'
   Integer a, b, _0(0), g;
   ClpValueUtils::GetGapInfo(isols, a, b, &_0, &g);
   Integer ig = isols.GetClp().Get(g) % div_wd;
   // check that at least some i is within the bounds of 'c1'
   if (ig >= c1.GetCount())
      return domain->CreateBottomValue(x->SizeInBits());
   // get the largest index 'ih' at which 'c1' overlaps with 'c2'
   Integer h;
   ClpValueUtils::GetGapInfo(isols, a, b, &c1.GetCount(), &h);
   ClpValueUtils::Decrement(isols, a, b, h);
   Integer ih = isols.GetClp().Get(h) % div_wd;
   // based on how the indices from 'ig' up to 'ih' are dispersed, compute a multiplier for
   // c1.GetStride() to filter out the values of 'c1' whose indices do not satisfy (1)
   Integer strmul;
   if (isols.IsSingleElem())
      strmul = 0;
   else {
      // the difference between two adjacent solutions i is either alpha, beta, or alpha + beta,
      // as given by the gap information from 'isols'
      Integer alpha = (a * isols.GetClp().GetStride()) % div_wd;
      Integer beta = div_wd - (b * isols.GetClp().GetStride()) % div_wd;
      // starting from 'g', step 'g_' as far as possible before the gap length changes
      Integer g_ = g;
      Integer k = isols.GetClp().GetCount() - a;
      if (g < k) { // 0 <= g < k
         strmul = alpha;
         g_ += ceildiv(k - g, a) * a;
      } else if (g < b) { // k <= g < b
         Integer sub_ab = a - b;
         strmul = alpha + beta;
         if (sub_ab < 0) g_ += ceildiv(g - (k - 1), -sub_ab) * sub_ab;
         else g_ += ceildiv(b - g, sub_ab) * sub_ab;        
      } else { // b <= g < isols.GetCount()
         strmul = beta;
         g_ -= ceildiv(g - (b - 1), b) * b;
      }
      // if the value at 'g_' in 'isols' hasn't reached 'ih' at this point, more than one
      // gap lengths exist between the solutions i, so set the multiplier to the gcd of
      // all possible gap lengths
      if (isols.GetClp().Get(g_) % div_wd < ih)
         strmul = ClpUtils::GCD(alpha, beta);
   }
   // compute the value to return
   Integer base = c1.GetBase() + ig * c1.GetStride();
   Integer stride = strmul * c1.GetStride();
   Integer count(1);
   if (stride != 0)
      count = (c1.Get(ih) - base) / stride + 1;
   return new ClpValue(x->SizeInBits(), base, stride, count);
}

ClpValue *Ops_ClpValue::LUB(const ClpValue *x, const ClpValue *y) {
   // TODO: this implementation does *not* return the optimal CLP; it remains an open question how
   // the optimum could be computed
   if (x->IsTopBitstring()) return x->Copy();
   if (y->IsTopBitstring()) return y->Copy();
   const Clp &a = x->GetClp(), &b = y->GetClp();
   Size size_in_bits = x->SizeInBits();
   // handle straightforward cases
   if ((ClpUtils::IsSingleton(a) && ClpUtils::IsSingleton(b)) || size_in_bits.IsInfinity())
      return new ClpValue(size_in_bits, ClpUtils::LUB(a, b));
   // here size_in_bits != Size::Infinity()
   Integer width = RepresentableRangeWidth<Integer>(size_in_bits.AsBaseIntType());
   Integer sub_bbba = b.GetBase() - a.GetBase();
   Integer gcd_sasb = ClpUtils::GCD(a.GetStride(), b.GetStride()), g = ClpUtils::GCD(gcd_sasb, sub_bbba);
   Integer stride, count;
   Integer d, s, dummy, div_wd, IJbase, Istr, Jstr, _0(0);
   Size log2_div_wd;
   Clp best(_0, Integer(1), width); // start with top
   // get all divisors of 'gcd_sasb'
   vector<Integer> divs;
   ClpUtils::GetDivisors(gcd_sasb, divs);
   // now run through all divisors of 'gcd_sasb', and find the best stride among gcd_sasb / divs[di]
   for (int di = 0, dn = (int)divs.size(); di < dn; ++di) {
      stride = gcd_sasb / divs[di];
      if (g % (stride & -stride) != 0) // gcd(stride, width) must divide 'g'
         continue;
      d = ClpUtils::XGCD(stride, width, s, dummy);
      div_wd = width / d;
      if (s < 0) s += div_wd; // make sure 's' is nonnegative
      // some common subexpressions
      log2_div_wd = log2(div_wd);
      IJbase = s * sub_bbba / d;
      Istr = s * a.GetStride() / d, Jstr = s * b.GetStride() / d;
      // let 'a' swallow 'b'
      ClpValue I_ab(log2_div_wd, _0, Istr, a.GetCount());
      count = I_ab.GetLargestUnsigned() + 1;
      if (count < best.GetCount()) {
         ClpValue J_ab(log2_div_wd, IJbase, Jstr, b.GetCount());
         count = max(count, J_ab.GetLargestUnsigned() + 1);
         if (count < best.GetCount()) {
            best.SetBase( a.GetBase() );
            best.SetStride( stride );
            best.SetCount( count );
         }
      }
      // let 'b' swallow 'a'
      ClpValue I_ba(log2_div_wd, -IJbase, Istr, a.GetCount());
      count = I_ba.GetLargestUnsigned() + 1;
      if (count < best.GetCount()) {
         ClpValue J_ba(log2_div_wd, _0, Jstr, b.GetCount());
         count = max(count, J_ba.GetLargestUnsigned() + 1);
         if (count < best.GetCount()) {
            best.SetBase( b.GetBase() );
            best.SetStride( stride );
            best.SetCount( count );
         }
      }
   }
   return new ClpValue(size_in_bits, best);
}

ClpValue *Ops_ClpValue::Neg(const ClpValue *x) {
   if (x->IsTopBitstring()) return x->Copy();
   // -x = ~x + 1
   Clp negx = ClpUtils::Not(x->GetClp());
   negx.SetBase(negx.GetBase() + 1);
   return new ClpValue(x->SizeInBits(), negx);
}

ClpValue *Ops_ClpValue::Add(const ClpValue *x, const ClpValue *y, const ClpValue *c) {
   Size size_in_bits = x->SizeInBits();
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return new ClpValue(size_in_bits);
   Clp sum = ClpUtils::Add( ClpUtils::Add(x->GetClp(), y->GetClp()), c->GetClp() );
   return new ClpValue(size_in_bits, sum);
}

ClpValue *Ops_ClpValue::CAdd(const ClpValue *x, const ClpValue *y, const ClpValue *c) {
   if (x->SizeInBits().IsInfinity())
      return new ClpValue(1, Integer(0));
   // note: here x->HasUnsignedBounds() && y->HasUnsignedBounds() must hold
   const Integer upper = LargestRepresentableUnsigned<Integer>(x->SizeInBits().AsBaseIntType());
   int l = 0, u = 1; // start with no information
   if (x->GetSmallestUnsigned() + y->GetSmallestUnsigned() + c->GetSmallestUnsigned() > upper)
      l = 1; // here u == 1 must hold
   else if (x->GetLargestUnsigned() + y->GetLargestUnsigned() + c->GetLargestUnsigned() <= upper)
      u = 0; // here l == 0 must hold
   return new ClpValue(1, Integer(l), Integer(u - l + 1));
}

ClpValue *Ops_ClpValue::Sub(const ClpValue *x, const ClpValue *y, const ClpValue *c) {
   // here we use the fact that
   //    x - y - borrow == x + (-y) - borrow
   //                   == x + ~y + 1 - borrow
   //                   == x + ~y + ~borrow
   //                   == x + ~y + c
   // (the carry is the inverted borrow)
   unique_ptr<ClpValue> noty( Not(y) );
   return Add(x, noty.get(), c);
}

ClpValue *Ops_ClpValue::CSub(const ClpValue *x, const ClpValue *y, const ClpValue *c) {
   // here we use the fact that
   //    x - y - borrow == x + (-y) - borrow
   //                   == x + ~y + 1 - borrow
   //                   == x + ~y + ~borrow
   //                   == x + ~y + c
   // (the carry is the inverted borrow)
   unique_ptr<ClpValue> noty( Not(y) );
   return CAdd(x, noty.get(), c);
}

ClpValue *Ops_ClpValue::SMul(const ClpValue *x, const ClpValue *y) {
   Size size_in_bits = x->SizeInBits() + y->SizeInBits();
   if (!x->HasSignedBounds() || !y->HasSignedBounds())
      return new ClpValue(size_in_bits);
   vector<Clp> xclps, yclps;
   x->GetSigned(xclps); y->GetSigned(yclps);
   Clp prod, prod_;
   for (RangeIterator<vector<Clp> > xclp(xclps); xclp; ++xclp) {
      for (RangeIterator<vector<Clp> > yclp(yclps); yclp; ++yclp)  {
         prod_ = ClpUtils::Mul(*xclp, *yclp);
         prod = ClpUtils::LUB(prod, prod_);
      }
   }
   return new ClpValue(size_in_bits, prod);
}

ClpValue *Ops_ClpValue::UMul(const ClpValue *x, const ClpValue *y) {
   Size size_in_bits = x->SizeInBits() + y->SizeInBits();
   if (!x->HasUnsignedBounds() || !y->HasUnsignedBounds())
      return new ClpValue(size_in_bits);
   vector<Clp> xclps, yclps;
   x->GetUnsigned(xclps); y->GetUnsigned(yclps);
   Clp prod, prod_;
   for (RangeIterator<vector<Clp> > xclp(xclps); xclp; ++xclp) {
      for (RangeIterator<vector<Clp> > yclp(yclps); yclp; ++yclp)  {
         prod_ = ClpUtils::Mul(*xclp, *yclp);
         prod = ClpUtils::LUB(prod, prod_);
      }
   }
   return new ClpValue(size_in_bits, prod);
}

ClpValue *Ops_ClpValue::Mul_Trunc(const ClpValue *x, const ClpValue *y) {
   Size size_in_bits = x->SizeInBits();
   assert(size_in_bits == y->SizeInBits());
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return new ClpValue(size_in_bits);
   Clp xclp = x->GetClp(), yclp = y->GetClp();
   if (size_in_bits < Size::Infinity()) {
      // Wrap the base values to the signed range, to attempt to improve precision.
      // Since this reduces the magnitude of the endpoints of the CLPs (when
      // treating them as general arithmetic progressions), this reduces the
      // distance between the endpoints of the result. However, it is not obvious
      // that this always improves precision, since it could also lead to a smaller
      // stride in the result (see the implementation of ClpUtils::Mul()), which is
      // generally bad for precision. Nevertheless, it is also likely that this is
      // always outweighed by the benefit of keeping the endpoints as close
      // together as possible.
      Integer width = RepresentableRangeWidth<Integer>(size_in_bits.AsBaseIntType());
      if (xclp.GetBase() >= (width >> 1))
         xclp.SetBase(xclp.GetBase() - width);
      if (yclp.GetBase() >= (width >> 1))
         yclp.SetBase(yclp.GetBase() - width);
   }
   Clp prod = ClpUtils::Mul( xclp, yclp );
   return new ClpValue(size_in_bits, prod);
}

ClpValue *Ops_ClpValue::SDiv(const ClpValue *x, const ClpValue *y) {
   Size size_in_bits = x->SizeInBits();
   if (!x->HasSignedBounds() || !y->HasSignedBounds())
      return new ClpValue(size_in_bits);
   vector<Clp> xclps, yclps;
   x->GetSigned(xclps); y->GetSigned(yclps);
   Clp quot, quot_, yclp_;
   Integer uy, ly_, uy_;
   for (RangeIterator<vector<Clp> > xclp(xclps); xclp; ++xclp) {
      for (RangeIterator<vector<Clp> > yclp(yclps); yclp; ++yclp)  {
         uy = yclp->GetUpper();
         // special handling of when the interval spanned by 'yclp' contains 0
         if (yclp->GetBase() <= 0 && uy >= 0) {
            // split 'yclp' into two parts
            yclp_ = *yclp; uy_ = uy; // make a copy of 'yclp'
            uy = ly_ = ClpUtils::mod(yclp->GetBase(), yclp->GetStride()); // smallest non-negative value of 'yclp'
            uy -= yclp->GetStride(); // move to the largest negative value
            if (yclp->GetBase() <= uy) { // if 'yclp' still forms a non-empty CLP
               yclp->SetUpper(uy);
               quot_ = ClpUtils::Div(*xclp, *yclp);
               quot = ClpUtils::LUB(quot, quot_);
            }
            if (ly_ == 0) ly_ += yclp_.GetStride(); // move to the smallest positive value
            if (ly_ <= uy_) { // if 'yclp_' still forms a non-empty CLP
               yclp_.SetBase(ly_);
               yclp_.SetUpper(uy_);
               quot_ = ClpUtils::Div(*xclp, yclp_);
               quot = ClpUtils::LUB(quot, quot_);
            }
         } else {
            quot_ = ClpUtils::Div(*xclp, *yclp);
            quot = ClpUtils::LUB(quot, quot_);
         }
      }
   }
   return new ClpValue(size_in_bits, quot);
}

ClpValue *Ops_ClpValue::UDiv(const ClpValue *x, const ClpValue *y) {
   Size size_in_bits = x->SizeInBits();
   if (!x->HasUnsignedBounds() || !y->HasUnsignedBounds())
      return new ClpValue(size_in_bits);
   vector<Clp> xclps, yclps;
   x->GetUnsigned(xclps); y->GetUnsigned(yclps);
   Clp quot, quot_;
   for (RangeIterator<vector<Clp> > xclp(xclps); xclp; ++xclp) {
      for (RangeIterator<vector<Clp> > yclp(yclps); yclp; ++yclp) {
         if (yclp->GetBase() == 0) {
            yclp->SetBase(yclp->GetBase() + yclp->GetStride());
            yclp->SetCount(yclp->GetCount() - 1);
         }
         quot_ = ClpUtils::Div(*xclp, *yclp);
         quot = ClpUtils::LUB(quot, quot_);
      }
   }
   return new ClpValue(size_in_bits, quot);
}

ClpValue *Ops_ClpValue::SMod(const ClpValue *x, const ClpValue *y) {
   // here we use the fact that x % y == x - x / y * y
   // TODO: this is slow and gives suboptimal precision
   unique_ptr<ClpValue> t;
   t.reset( SDiv(x, y) );
   t.reset( SMul(t.get(), y) ); // TODO: if 'y' includes 0, this gives overestimations
   t.reset( SExt(t.get(), x->SizeInBits()) );
   ClpValue _1(1, Integer(1));
   return Sub(x, t.get(), &_1);
}

ClpValue *Ops_ClpValue::UMod(const ClpValue *x, const ClpValue *y) {
   // here we use the fact that x % y == x - x / y * y
   // TODO: this is slow and gives suboptimal precision
   unique_ptr<ClpValue> t;
   t.reset( UDiv(x, y) );
   t.reset( UMul(t.get(), y) ); // TODO: if 'y' includes 0, this gives overestimations
   t.reset( ZExt(t.get(), x->SizeInBits()) );
   ClpValue _1(1, Integer(1));
   return Sub(x, t.get(), &_1);
}

ClpValue *Ops_ClpValue::SExt(const ClpValue *x, Size new_size) {
   if (!x->HasSignedBounds()) return new ClpValue(new_size);
   if (new_size > x->SizeInBits()) {
      vector<Clp> xclps;
      x->GetSigned(xclps);
      while (xclps.size() > 1) {
         xclps.front() = ClpUtils::LUB(xclps.front(), xclps.back());
         xclps.pop_back();
      }
      return new ClpValue(new_size, xclps.front());
   }
   else return new ClpValue(new_size, x->GetClp());
}

ClpValue *Ops_ClpValue::ZExt(const ClpValue *x, Size new_size) {
   if (new_size > x->SizeInBits()) {
      if (!x->HasUnsignedBounds()) return new ClpValue(new_size);
      vector<Clp> xclps;
      x->GetUnsigned(xclps);
      while (xclps.size() > 1) {
         xclps.front() = ClpUtils::LUB(xclps.front(), xclps.back());
         xclps.pop_back();
      }
      return new ClpValue(new_size, xclps.front());
   } else {
      if (IsInfAndTopBitstring(*x)) return new ClpValue(new_size);
      else return new ClpValue(new_size, x->GetClp());
   }
}

ClpValue *Ops_ClpValue::LShift(const ClpValue *x, const ClpValue *y) {
   Size size_in_bits = x->SizeInBits();
   if (IsInfAndTopBitstring(*x) || !y->HasUnsignedBounds())
      return new ClpValue(size_in_bits);
   // no need to split 'x' into only signed or unsigned parts
   vector<Clp> yclps;
   y->GetUnsigned(yclps);
   Clp shifted, shifted_;
   for (RangeIterator<vector<Clp> > yclp(yclps); yclp; ++yclp)  {
      shifted_ = ClpUtils::LShift(x->GetClp(), *yclp);
      shifted = ClpUtils::LUB(shifted, shifted_);
   }
   return new ClpValue(size_in_bits, shifted);
}

ClpValue *Ops_ClpValue::RShift(const ClpValue *x, const ClpValue *y) {
   Size size_in_bits = x->SizeInBits();
   if (!x->HasUnsignedBounds() || !y->HasUnsignedBounds())
      return new ClpValue(size_in_bits);
   vector<Clp> xclps, yclps;
   x->GetUnsigned(xclps); y->GetUnsigned(yclps);
   Clp shifted, shifted_;
   for (RangeIterator<vector<Clp> > xclp(xclps); xclp; ++xclp) {
      for (RangeIterator<vector<Clp> > yclp(yclps); yclp; ++yclp)  {
         shifted_ = ClpUtils::RShift(*xclp, *yclp);
         shifted = ClpUtils::LUB(shifted, shifted_);
      }
   }
   return new ClpValue(size_in_bits, shifted);
}

ClpValue *Ops_ClpValue::RShiftA(const ClpValue *x, const ClpValue *y) {
   Size size_in_bits = x->SizeInBits();
   if (!x->HasSignedBounds() || !y->HasUnsignedBounds())
      return new ClpValue(size_in_bits);
   vector<Clp> xclps, yclps;
   x->GetSigned(xclps); y->GetUnsigned(yclps);
   Clp shifted, shifted_;
   for (RangeIterator<vector<Clp> > xclp(xclps); xclp; ++xclp) {
      for (RangeIterator<vector<Clp> > yclp(yclps); yclp; ++yclp)  {
         shifted_ = ClpUtils::RShift(*xclp, *yclp);
         shifted = ClpUtils::LUB(shifted, shifted_);
      }
   }
   return new ClpValue(size_in_bits, shifted);
}

ClpValue *Ops_ClpValue::Not(const ClpValue *x) {
   if (IsInfAndTopBitstring(*x))
      return x->Copy();
   return new ClpValue(x->SizeInBits(), ClpUtils::Not(x->GetClp()));
}

ClpValue *Ops_ClpValue::And(const ClpValue *x, const ClpValue *y) {
   Size size_in_bits = x->SizeInBits();
   if (!x->HasUnsignedBounds() || !y->HasUnsignedBounds())
      return new ClpValue(size_in_bits);
   vector<Clp> xclps, yclps;
   x->GetUnsigned(xclps); y->GetUnsigned(yclps);
   Clp result, result_;
   for (RangeIterator<vector<Clp> > xclp(xclps); xclp; ++xclp) {
      for (RangeIterator<vector<Clp> > yclp(yclps); yclp; ++yclp)  {
         result_ = ClpUtils::And(*xclp, *yclp);
         result = ClpUtils::LUB(result, result_);
      }
   }
   return new ClpValue(size_in_bits, result);
}

ClpValue *Ops_ClpValue::Or(const ClpValue *x, const ClpValue *y) {
   // here we rely on x | y == ~(~x & ~y)
   unique_ptr<ClpValue> notx, noty, t;
   notx.reset( Not(x) ); noty.reset( Not(y) );
   t.reset( And(notx.get(), noty.get()) );
   return Not(t.get());
}

ClpValue *Ops_ClpValue::XOr(const ClpValue *x, const ClpValue *y) {
   // here we rely on x ^ y == (x & ~y) | (~x & y)
   unique_ptr<ClpValue> notx, noty, s, t;
   notx.reset( Not(x) ); noty.reset( Not(y) );
   s.reset( And(x, noty.get()) );
   t.reset( And(notx.get(), y) );
   return Or(s.get(), t.get());
}

ClpValue *Ops_ClpValue::Conc(const ClpValue *x, const ClpValue *y) {
   Size size_in_bits = x->SizeInBits() + y->SizeInBits();
   if (IsInfAndTopBitstring(*x) || y->SizeInBits().IsInfinity())
      return new ClpValue(size_in_bits);
   Clp xshamt(Integer(y->SizeInBits().AsBaseIntType()));
   Clp xclp = ClpUtils::LShift(x->GetClp(), xshamt);
   vector<Clp> yclps;
   y->GetUnsigned(yclps);
   Clp result, result_;
   for (RangeIterator<vector<Clp> > yclp(yclps); yclp; ++yclp)  {
      result_ = ClpUtils::Add(xclp, *yclp);
      result = ClpUtils::LUB(result, result_);
   }
   return new ClpValue(size_in_bits, result);
}

ClpValue *Ops_ClpValue::Select(const ClpValue *x, Size idx_first, Size idx_last) {
   // these first two tests make sure that idx_last - idx_first + 1 gives a valid size
   if (idx_first.IsInfinity()) throw logic_error("Select: first index cannot be infinity");
   if (idx_first > idx_last) throw logic_error("Select: first index cannot be larger than last index");
   // if 'x' is of finite precision, 'idx_last' must be within this precision
   if (!x->SizeInBits().IsInfinity() && idx_last >= x->SizeInBits())
         throw logic_error("Select: last index out of bounds");
   Size size_in_bits = idx_last - idx_first + 1;
   if (IsInfAndTopBitstring(*x))
      return new ClpValue(size_in_bits);
   Clp shamt(Integer(idx_first.AsBaseIntType()));
   Clp shifted = ClpUtils::RShift(x->GetClp(), shamt);
   return new ClpValue(size_in_bits, shifted);
}

ClpValue *Ops_ClpValue::Repeat(const ClpValue *x, Size nreps) {
   if (ClpUtils::IsSingleton(x->GetClp())) {
      if (x->GetClp().GetBase() == 0)
         return new ClpValue(nreps, Integer(0));
      else
         return new ClpValue(nreps, Integer(-1));
   }
   else return new ClpValue(nreps, Integer(-1), Integer(2));
}

ClpValue *Ops_ClpValue::Eq(const ClpValue *x, const ClpValue *y) {
   if (IsInfAndTopBitstring(*x) || IsInfAndTopBitstring(*y))
      return new ClpValue(1);
   int l = 0, u = 1; // start with no information
   if (ClpUtils::IsSingleton(x->GetClp()) && ClpUtils::IsSingleton(y->GetClp()) &&
      x->GetClp().GetBase() == y->GetClp().GetBase())
      l = 1; // here 'u' must be 1
   else if (!Overlaps(x, y))
      u = 0; // here 'l' must be 0
   return new ClpValue(1, Integer(l), Integer(u - l + 1));
}

ClpValue *Ops_ClpValue::NEq(const ClpValue *x, const ClpValue *y) {
   unique_ptr<ClpValue> eq( Eq(x, y) );
   return Not( eq.get() );
}

ClpValue *Ops_ClpValue::SLT(const ClpValue *x, const ClpValue *y) {
   if (!x->HasSignedBounds() || !y->HasSignedBounds())
      return new ClpValue(1);
   int l = 0, u = 1; // start with no information
   if (x->GetSmallestSigned() >= y->GetLargestSigned())
      u = 0; // here 'l' must be 0
   else if (x->GetLargestSigned() < y->GetSmallestSigned())
      l = 1; // here 'u' must be 1
   return new ClpValue(1, Integer(l), Integer(u - l + 1));
}

ClpValue *Ops_ClpValue::SLE(const ClpValue *x, const ClpValue *y) {
   unique_ptr<ClpValue> gt( SGT(x, y) );
   return Not( gt.get() );
}

ClpValue *Ops_ClpValue::ULT(const ClpValue *x, const ClpValue *y) {
   if (!x->HasUnsignedBounds() || !y->HasUnsignedBounds())
      return new ClpValue(1);
   int l = 0, u = 1; // start with no information
   if (x->GetSmallestUnsigned() >= y->GetLargestUnsigned())
      u = 0; // here 'l' must be 0
   else if (x->GetLargestUnsigned() < y->GetSmallestUnsigned())
      l = 1; // here 'u' must be 1
   return new ClpValue(1, Integer(l), Integer(u - l + 1));
}

ClpValue *Ops_ClpValue::ULE(const ClpValue *x, const ClpValue *y) {
   unique_ptr<ClpValue> gt( UGT(x, y) );
   return Not( gt.get() );
}

Value *Ops_ClpValue::SToF(const ClpValue *x, Size exp_size, Size frac_size) {
   if (!x->HasSignedBounds())
      return domain->GetFloatDomain()->CreateFloat(exp_size, frac_size);
   long double l = x->GetSmallestSigned().As<long double>(), u = x->GetLargestSigned().As<long double>();
   return domain->GetFloatDomain()->CreateFloat(exp_size, frac_size, true, false, l, u);
}

Value *Ops_ClpValue::UToF(const ClpValue *x, Size exp_size, Size frac_size) {
   if (!x->HasUnsignedBounds())
      return domain->GetFloatDomain()->CreateFloat(exp_size, frac_size);
   long double l = x->GetSmallestUnsigned().As<long double>(), u = x->GetLargestUnsigned().As<long double>();
   return domain->GetFloatDomain()->CreateFloat(exp_size, frac_size, true, false, l, u);
}

Value *Ops_ClpValue::If(const ClpValue *x, const Value *y, const Value *z) {
   if (!ClpUtils::IsSingleton(x->GetClp()))
      return y->LUB(z);
   else
      return (x->GetLargestUnsigned() == 1? y->Copy() : z->Copy());
}

Value *Ops_ClpValue::Restrict_NEq(const ClpValue *x, const ClpValue *y) {
   if (!y->IsSingleElem())
      return x->Copy();
   const Integer &ly = y->GetClp().GetBase();
   if (x->SizeInBits().IsInfinity()) {
      // if the operands are of infinite precision, there are limited opportunities for restriction
      if (x->IsTopBitstring())
         return x->Copy();
      const Clp &cx = x->GetClp();
      if (ly == cx.GetBase()) {
         if (ClpUtils::IsSingleton(cx)) return domain->CreateBottomValue(x->SizeInBits());
         return new ClpValue(x->SizeInBits(), Clp(cx.GetBase() + cx.GetStride(), cx.GetStride(), cx.GetCount() - 1));
      }
      // note: !ClpUtils::IsSingleton(cx) must hold here
      if (ly == cx.GetUpper())
         return new ClpValue(x->SizeInBits(), Clp(cx.GetBase(), cx.GetStride(), cx.GetCount() - 1));
      if (cx.GetCount() == 3 && ly == cx.GetBase() + cx.GetStride()) // 'cx' is ternary and 'ly' is the midpoint
         return new ClpValue(x->SizeInBits(), Clp(cx.GetBase(), cx.GetStride() * 2, Integer(2)));
      return x->Copy();
   }
   Integer stclbase = ly + 1;
   Integer stclcount = RepresentableRangeWidth<Integer>(y->SizeInBits().AsBaseIntType()) - 1;
   ClpValue stencil(x->SizeInBits(), stclbase, stclcount);
   return GLB(x, &stencil);
}

Value *Ops_ClpValue::Restrict_SLT(const ClpValue *x, const ClpValue *y) {
   if (!x->HasSignedBounds() || !y->HasSignedBounds())
      return x->Copy();
   Integer stclbase = x->GetSmallestSigned();
   Integer stclcount = y->GetLargestSigned() - stclbase;
   if (stclcount <= 0)
      return domain->CreateBottomValue(x->SizeInBits());
   ClpValue stencil(x->SizeInBits(), stclbase, stclcount);
   return GLB(x, &stencil);
}

Value *Ops_ClpValue::Restrict_SLE(const ClpValue *x, const ClpValue *y) {
   if (!x->HasSignedBounds() || !y->HasSignedBounds())
      return x->Copy();
   Integer stclbase = x->GetSmallestSigned();
   Integer stclcount = y->GetLargestSigned() - stclbase + 1;
   if (stclcount <= 0)
      return domain->CreateBottomValue(x->SizeInBits());
   ClpValue stencil(x->SizeInBits(), stclbase, stclcount);
   return GLB(x, &stencil);
}

Value *Ops_ClpValue::Restrict_SGE(const ClpValue *x, const ClpValue *y) {
   if (!x->HasSignedBounds() || !y->HasSignedBounds())
      return x->Copy();
   Integer stclbase = y->GetSmallestSigned();
   Integer stclcount = x->GetLargestSigned() - stclbase + 1;
   if (stclcount <= 0)
      return domain->CreateBottomValue(x->SizeInBits());
   ClpValue stencil(x->SizeInBits(), stclbase, stclcount);
   return GLB(x, &stencil);
}

Value *Ops_ClpValue::Restrict_SGT(const ClpValue *x, const ClpValue *y) {
   if (!x->HasSignedBounds() || !y->HasSignedBounds())
      return x->Copy();
   Integer stclbase = y->GetSmallestSigned() + 1;
   Integer stclcount = x->GetLargestSigned() - stclbase + 1;
   if (stclcount <= 0)
      return domain->CreateBottomValue(x->SizeInBits());
   ClpValue stencil(x->SizeInBits(), stclbase, stclcount);
   return GLB(x, &stencil);
}

Value *Ops_ClpValue::Restrict_ULT(const ClpValue *x, const ClpValue *y) {
   if (!y->HasUnsignedBounds())
      return x->Copy();
   Integer stclbase = x->GetSmallestUnsigned();
   Integer stclcount = y->GetLargestUnsigned() - stclbase;
   if (stclcount <= 0)
      return domain->CreateBottomValue(x->SizeInBits());
   ClpValue stencil(x->SizeInBits(), stclbase, stclcount);
   return GLB(x, &stencil);
}

Value *Ops_ClpValue::Restrict_ULE(const ClpValue *x, const ClpValue *y) {
   if (!y->HasUnsignedBounds())
      return x->Copy();
   Integer stclbase = x->GetSmallestUnsigned();
   Integer stclcount = y->GetLargestUnsigned() - stclbase + 1;
   if (stclcount <= 0)
      return domain->CreateBottomValue(x->SizeInBits());
   ClpValue stencil(x->SizeInBits(), stclbase, stclcount);
   return GLB(x, &stencil);
}

Value *Ops_ClpValue::Restrict_UGE(const ClpValue *x, const ClpValue *y) {
   if (!x->HasUnsignedBounds())
      return x->Copy();
   Integer stclbase = y->GetSmallestUnsigned();
   Integer stclcount = x->GetLargestUnsigned() - stclbase + 1;
   if (stclcount <= 0)
      return domain->CreateBottomValue(x->SizeInBits());
   ClpValue stencil(x->SizeInBits(), stclbase, stclcount);
   return GLB(x, &stencil);
}

Value *Ops_ClpValue::Restrict_UGT(const ClpValue *x, const ClpValue *y) {
   if (!x->HasUnsignedBounds())
      return x->Copy();
   Integer stclbase = y->GetSmallestUnsigned() + 1;
   Integer stclcount = x->GetLargestUnsigned() - stclbase + 1;
   if (stclcount <= 0)
      return domain->CreateBottomValue(x->SizeInBits());
   ClpValue stencil(x->SizeInBits(), stclbase, stclcount);
   return GLB(x, &stencil);
}

Value *Ops_ClpValue::Restrict_Select(const ClpValue *x, const Size& idx_first, const ClpValue *result) {
   // it would be an error to give infinity as the starting index of a select
   if (idx_first.IsInfinity()) throw logic_error("Restrict_Select: first index cannot be infinity");
   // the original value 'x' must be at least idx_first + result->SizeInBits() bits
   if (idx_first + result->SizeInBits() > x->SizeInBits())
      throw logic_error("Restrict_Select: last index out of bounds");
   if (IsInfAndTopBitstring(*result))
      return new ClpValue(x->SizeInBits());
   unsigned long long f = idx_first.AsBaseIntType();
   const Clp &cx = x->GetClp();
   Clp cr = result->GetClp();
   if (f != 0) {
      // left shift 'cr' by 'idx_first' and add in the 'idx_first' least significant bits of 'cx'
      Clp shamt(Integer(f), Integer(1));
      cr = ClpUtils::LShift(cr, shamt);
      ClpValue tx(idx_first, cx); // 'cx' truncated to 'idx_first' bits
      vector<Clp> txsub;
      tx.GetUnsigned(txsub);
      Clp lsbs;
      for (RangeIterator<vector<Clp> > t(txsub); t; ++t)
         lsbs = ClpUtils::LUB(lsbs, *t);
      cr = ClpUtils::Add(cr, lsbs);
   }
   Integer width = RepresentableRangeWidth<Integer>(f + result->SizeInBits().AsBaseIntType());
   const Integer &lx = cx.GetBase(), &lr = cr.GetBase();
   // We want to find the values of i and j satisfying the congruence
   //    lx + sx * i === lr + sr * j  (mod width),      (1)
   // such that 0 <= i < cx.GetCount() and 0 <= j < cr.GetCount().  The found values of i
   // then correspond to the concrete values of 'cx' that overlap with some value in 'cr',
   // and only these concrete values should be included in the returned result.
   //
   // Rewrite (1) as
   //    sx * i === lr - lx + sr * j  (mod width),      (1')
   // and let d,s = xgcd(sx, width).  For some j, one or more values of i satisfying (1)
   // exist iff d divides the right-hand side of (1'), i.e., iff
   //    lr - lx + sr * j === 0  (mod d).               (2)
   // The smallest non-negative such i is then given by
   //    (s * (lr - lx + sr * j) / d) mod (width / d),  (3)
   // and any other i are congruent to this modulo width / d.
   //
   // Rewrite (2) as
   //    sr * j === lx - lr  (mod d),                   (2')
   // and let e,t = xgcd(sr,d).  One or more j satisfying (2) exist iff e divides
   // the right-hand side of (2').  The smallest such j is then given by
   //    j0 = (t * (lx - lr) / e) mod (d / e),
   // and any other j are congruent to j0 modulo d / e.
   Integer d, e, s, t, dummy;
   d = ClpUtils::XGCD(cx.GetStride(), width, s, dummy);
   e = ClpUtils::XGCD(cr.GetStride(), d, t, dummy);
   Integer div_wd = width / d, div_de = d / e;
   if (s < 0) s += div_wd; // make sure 's' is positive
   // check that any solutions to (2) exist at all
   Integer sub_lxlr = lx - lr;
   if (e == 0 || sub_lxlr % e != 0)
      return domain->CreateBottomValue(x->SizeInBits());
   Integer j0 = ClpUtils::mod(t * sub_lxlr / e, div_de);
   // check that some solutions to (2) are within the bounds of 'cr'
   if (j0 >= cr.GetCount())
      return domain->CreateBottomValue(x->SizeInBits());
   Integer numj = ceildiv(cr.GetCount() - j0, div_de); // nr. of solutions to (2) within 'cr'
   // Now plug all of the 'numj' solutions j to (2) into (3) to get the smallest non-negative i
   // satisfying (1) for each such j.  This information fits nicely into the following CLP 'isols'.
   // Its base is given by simply plugging j == j0 into (3):
   //    (s * (lr - lx + sr * j0) / d) mod (width / d).
   // To compute the stride, note that the remaining values are given by
   //    (s * (lr - lx + sr * (j0 + d/e * k)) / d) mod (width / d),
   // where k == 1,2,...,numj-1.  Rewrite the left-hand side of this as
   //    s * (lr - lx + sr * (j0 + d/e * k)) / d
   //       == s * (lr - lx + sr * j0 + sr * d/e * k) / d
   //       == s * (lr - lx + sr * j0) / d + s * (sr * d/e * k) / d
   //       == s * (lr - lx + sr * j0) / d + s * sr / e * k.
   // This gives the stride s * sr / e.  To get wraparound at width / d, the size in bits
   // is set to log2(width / d) (note that width / d must be a power of 2).
   ClpValue isols(log2(div_wd), s * (-sub_lxlr + cr.GetStride() * j0) / d, s * cr.GetStride() / e, numj);
   // get the smallest index 'ig' at which 'cx' overlaps with 'cr'
   Integer a, b, _0(0), g;
   ClpValueUtils::GetGapInfo(isols, a, b, &_0, &g);
   Integer ig = isols.GetClp().Get(g) % div_wd;
   // check that at least some i is within the bounds of 'cx'
   if (ig >= cx.GetCount())
      return domain->CreateBottomValue(x->SizeInBits());
   // get the largest index 'ih' at which 'cx' overlaps with 'cr'
   Integer h;
   ClpValueUtils::GetGapInfo(isols, a, b, &cx.GetCount(), &h);
   ClpValueUtils::Decrement(isols, a, b, h);
   Integer ih = isols.GetClp().Get(h) % div_wd;
   ih += (cx.GetCount() - 1 - ih) / div_wd * div_wd;
   // based on how the indices from 'ig' up to 'ih' are dispersed, compute a multiplier for
   // cx.GetStride() to filter out the values of 'cx' whose indices do not satisfy (1)
   Integer strmul;
   if (isols.IsSingleElem())
      strmul = div_wd;
   else {
      // the difference between two adjacent solutions i is either alpha, beta, or alpha + beta,
      // as given by the gap information from 'isols'
      Integer alpha = (a * isols.GetClp().GetStride()) % div_wd;
      Integer beta = div_wd - (b * isols.GetClp().GetStride()) % div_wd;
      // starting from 'g', step 'g_' as far as possible before the gap length changes
      Integer g_ = g;
      Integer k = isols.GetClp().GetCount() - a;
      if (g < k) { // 0 <= g < k
         strmul = alpha;
         g_ += ceildiv(k - g, a) * a;
      } else if (g < b) { // k <= g < b
         Integer sub_ab = a - b;
         strmul = alpha + beta;
         if (sub_ab < 0) g_ += ceildiv(g - (k - 1), -sub_ab) * sub_ab;
         else g_ += ceildiv(b - g, sub_ab) * sub_ab;        
      } else { // b <= g < isols.GetCount()
         strmul = beta;
         g_ -= ceildiv(g - (b - 1), b) * b;
      }
      // if the value at 'g_' in 'isols' hasn't reached 'ih' at this point, more than one
      // gap lengths exist between the solutions i, so set the multiplier to the gcd of
      // all possible gap lengths
      if (isols.GetClp().Get(g_) % div_wd < ih)
         strmul = ClpUtils::GCD(alpha, beta);
   }
   // compute the value to return
   Integer base = cx.GetBase() + ig * cx.GetStride();
   Integer stride = strmul * cx.GetStride();
   Integer count(1);
   if (stride != 0)
      count = (cx.Get(ih) - base) / stride + 1;
   return new ClpValue(x->SizeInBits(), base, stride, count);
}

Value *Ops_ClpValue::RevSMul(const ClpValue *result, const ClpValue *fac, Size size_in_bits) {
   // This function could use some improvement.  In theory, we are only interested in
   // combinations of concrete values r and f from 'result' and 'fac', respectively,
   // such that f evenly divides r.  All other combinations of r and f are irrelevant,
   // since for these combinations there are no values x such that x * f == r.
   // I haven't figured out exactly how to use this fact in the best way, so this
   // function uses some ad-hoc tricks to get a reasonably precise result.  Also note
   // that the result of a multiplication is represented with as many bits as the operands
   // are together, so no wraparound effects need to be considered.
   if (size_in_bits + fac->SizeInBits() != result->SizeInBits())
      throw logic_error("RevSMul: the precision of the result must be the sum of the operands' precisions");
   if (size_in_bits.IsInfinity())
      return new ClpValue(size_in_bits);
   Clp clp, quot; // used to maintain the result
   Clp rstencil, fstencil; // stencils used to filter the sub-CLPs of 'result' and 'fac'
   Clp rfilt, ffilt; // the filtered sub-CLPs of 'result' and 'fac'
   Clp top(SmallestRepresentableSigned<Integer>(size_in_bits.AsBaseIntType()),
           RepresentableRangeWidth<Integer>(size_in_bits.AsBaseIntType()));
   Integer _0(0);
   // get the non-wrapping sub-CLPs
   vector<Clp> rclps, fclps;
   result->GetSigned(rclps);
   fac->GetSigned(fclps);
   // determine whether 'result' contains 0
   bool r_incl_0 = false;
   for (RangeIterator<vector<Clp> > rc(rclps); rc; ++rc) {
      if (ClpUtils::Includes(*rc,_0)) {
         r_incl_0 = true;
         break;
      }
   }
   if (r_incl_0) {
      // if 'fac' too contains 0, nothing can be determined
      for (RangeIterator<vector<Clp> > fc(fclps); fc; ++fc) {
         if (ClpUtils::Includes(*fc,_0))
            return new ClpValue(size_in_bits);
      }
   } else {
      // if 'result' doesn't include 0, we can remove any 0s included in 'fac',
      // since no multiple of 0 is non-zero
      fstencil = Clp(top.GetBase(),-top.GetBase()); // [MININT..-1]
      Clp fstencil2(Integer(1),top.GetUpper());     // [1..MAXINT]
      Clp left, right;
      for (int i = 0, n = (int)fclps.size(); i < n; ++i) {
         Clp &fc = fclps[i];
         if (ClpUtils::Includes(fc,_0)) {
            // split 'fc' into a positive and a negative sub-CLP
            left = ClpUtils::GLB( fc, fstencil );
            right = ClpUtils::GLB( fc, fstencil2 );
            if (!ClpUtils::IsEmpty(left)) {
               fclps[i] = left;
               if (!ClpUtils::IsEmpty(right))
                  fclps.push_back(right);
            } else if (!ClpUtils::IsEmpty(right))
               fclps[i] = right;
         }
      }
   }
   // run through all sub-CLP combinations
   for (RangeIterator<vector<Clp> > fc(fclps); fc; ++fc) {
      rstencil = ClpUtils::Mul(*fc, top); // all possible multiples of 'fc'
      for (RangeIterator<vector<Clp> > rc(rclps); rc; ++rc) {
         // filter 'rc' so that it contains only (or mostly) multiples of 'fc'
         rfilt = ClpUtils::GLB( *rc, rstencil );
         if (ClpUtils::IsEmpty(rfilt))
            continue;
         // filter 'fc' so that it contains only (or mostly) divisors of 'rfilt'
         // (we know that 'fc' doesn't contain 0 here)
         if (!ClpUtils::Includes(rfilt,_0)) {
            // remove from 'fc' any values of larger magnitude than the maximum
            // magnitude in 'rfilt' (these values can't divide any value in 'rfilt')
            Integer maxmag = max(abs(rfilt.GetBase()),abs(rfilt.GetUpper()));
            fstencil = Clp(-maxmag, maxmag * 2 + 1);
            ffilt = ClpUtils::GLB( *fc, fstencil );
         } else {
            // everything in 'fc' divides 0
            ffilt = *fc;
         }
         quot = ClpUtils::Div( rfilt, ffilt );
         // if 'quot' contains 0 and 'result' doesn't, remove the 0 from 'quot' (as no
         // multiple of 0 can be non-zero)
         if (!ClpUtils::IsEmpty(quot) && !ClpUtils::Includes(rfilt,_0)) {
            // we only remove the 0 if it appears on the ends of the CLP
            if (quot.GetBase() == 0) {
               quot.SetBase(quot.GetBase() + quot.GetStride());
               quot.SetCount(quot.GetCount() - 1);
            } else if (quot.GetUpper() == 0) {
               quot.SetCount(quot.GetCount() - 1);
            }
         }
         clp = ClpUtils::LUB( clp, quot );
      }
   }
   if (ClpUtils::IsEmpty(clp))
      return domain->CreateBottomValue(size_in_bits);
   return new ClpValue(size_in_bits, clp);
}

Value *Ops_ClpValue::RevUMul(const ClpValue *result, const ClpValue *fac, Size size_in_bits) {
   // This function could use some improvement.  In theory, we are only interested in
   // combinations of concrete values r and f from 'result' and 'fac', respectively,
   // such that f evenly divides r.  All other combinations of r and f are irrelevant,
   // since for these combinations there are no values x such that x * f == r.
   // I haven't figured out exactly how to use this fact in the best way, so this
   // function uses some ad-hoc tricks to get a reasonably precise result.  Also note
   // that the result of a multiplication is represented with as many bits as the operands
   // are together, so no wraparound effects need to be considered.
   if (size_in_bits + fac->SizeInBits() != result->SizeInBits())
      throw logic_error("RevUMul: the precision of the result must be the sum of the operands' precisions");
   if (size_in_bits.IsInfinity())
      return new ClpValue(size_in_bits);
   Clp clp, quot; // used to maintain the result
   Clp rstencil, fstencil; // stencils used to filter the sub-CLPs of 'result' and 'fac'
   Clp rfilt, ffilt; // the filtered sub-CLPs of 'result' and 'fac'
   Clp top(Integer(0), RepresentableRangeWidth<Integer>(size_in_bits.AsBaseIntType()));
   // get the non-wrapping sub-CLPs
   vector<Clp> rclps, fclps;
   result->GetUnsigned(rclps);
   fac->GetUnsigned(fclps);
   // run through all sub-CLP combinations
   for (RangeIterator<vector<Clp> > fc(fclps); fc; ++fc) {
      rstencil = ClpUtils::Mul(*fc, top); // all possible multiples of 'fc'
      for (RangeIterator<vector<Clp> > rc(rclps); rc; ++rc) {
         // if 'fac' and 'result' both contain 0, nothing can be determined
         if (fc->GetBase() == 0 && rc->GetBase() == 0)
            return new ClpValue(size_in_bits);
         // filter 'rc' so that it contains only (or mostly) multiples of 'fc'
         rfilt = ClpUtils::GLB( *rc, rstencil );
         if (ClpUtils::IsEmpty(rfilt))
            continue;
         // filter 'fc' so that it contains only (or mostly) divisors of 'rfilt'
         if (rfilt.GetBase() != 0) {
            // remove 0 and any values larger than rfilt->GetUpper() from 'fc'
            fstencil = Clp(Integer(1), rfilt.GetUpper());
            ffilt = ClpUtils::GLB( *fc, fstencil );
         } else {
            // everything in 'fc' divides 0 (we know that 'fc' doesn't contain 0 here)
            ffilt = *fc;
         }
         quot = ClpUtils::Div( rfilt, ffilt );
         // if 'quot' contains 0 and 'result' doesn't, remove the 0 from 'quot' (as no
         // multiple of 0 can be non-zero)
         if (!ClpUtils::IsEmpty(quot) && quot.GetBase() == 0 && rfilt.GetBase() != 0) {
            quot.SetBase(quot.GetBase() + quot.GetStride());
            quot.SetCount(quot.GetCount() - 1);
         }
         clp = ClpUtils::LUB( clp, quot );
      }
   }
   if (ClpUtils::IsEmpty(clp))
      return domain->CreateBottomValue(size_in_bits);
   return new ClpValue(size_in_bits, clp);
}
