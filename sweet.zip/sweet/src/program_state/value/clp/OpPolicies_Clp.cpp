#include "OpPolicies_Clp.h"
#include "ClpValue.h"
#include "SymbClpPtrSet.h"
#include "program_state/value/FloatIntervalVal.h"
#include "program_state/value/ReadValue.h"

#include "globals.h"
#include "program_state/value/ValueDomain.h"

using namespace std;

static const ClpValue* extract_int(const Value* val, unique_ptr<const ClpValue>& newval)
{
   if (val->AsClpValue())
      return (const ClpValue*)val;
   if (val->AsReadValue()) {
      unique_ptr<Value> fused( ((const ReadValue*)val)->Fuse() );
      const ClpValue* val_ = extract_int(fused.get(), newval);
      if (val_ && !newval.get()) {
         // val_ is the same as fused, so its ownership should be moved to newval
         fused.release();
         newval.reset(val_);
      }
      return val_;
   }
   if (val->AsBitstring() || val->IsTop()) {
      newval.reset( new ClpValue(val->SizeInBits()) );
      return newval.get();
   }
   return 0;
}

static const SymbClpPtrSet* extract_ptr(const Value* val, unique_ptr<const SymbClpPtrSet>& newval)
{
   if (val->AsSymbClpPtrSet())
      return (const SymbClpPtrSet*)val;
   if (val->AsReadValue()) {
      unique_ptr<Value> fused( ((const ReadValue*)val)->Fuse() );
      const SymbClpPtrSet* val_ = extract_ptr(fused.get(), newval);
      if (val_ && !newval.get()) {
         // val_ is the same as fused, so its ownership should be moved to newval
         fused.release();
         newval.reset(val_);
      }
      return val_;
   }
   if (val->IsTop()) {
      newval.reset( new SymbClpPtrSet(val->SizeInBits()) );
      return newval.get();
   }
   return 0;
}

static const OneFloatInterval8_23* extract_float8_23(const Value* val, unique_ptr<const OneFloatInterval8_23>& newval)
{
   if (val->AsOneFloatInterval8_23())
      return (const OneFloatInterval8_23*)val;
   if (val->AsReadValue()) {
      unique_ptr<Value> fused( ((const ReadValue*)val)->Fuse() );
      const OneFloatInterval8_23* val_ = extract_float8_23(fused.get(), newval);
      if (val_ && !newval.get()) {
         // val_ is the same as fused, so its ownership should be moved to newval
         fused.release();
         newval.reset(val_);
      }
      return val_;
   }
   if (val->AsBitstring() || val->IsTop()) {
      newval.reset( new OneFloatInterval8_23 );
      return newval.get();
   }
   return 0;
}

static const OneFloatInterval11_52* extract_float11_52(const Value* val, unique_ptr<const OneFloatInterval11_52>& newval)
{
   if (val->AsOneFloatInterval11_52())
      return (const OneFloatInterval11_52*)val;
   if (val->AsReadValue()) {
      unique_ptr<Value> fused( ((const ReadValue*)val)->Fuse() );
      const OneFloatInterval11_52* val_ = extract_float11_52(fused.get(), newval);
      if (val_ && !newval.get()) {
         // val_ is the same as fused, so its ownership should be moved to newval
         fused.release();
         newval.reset(val_);
      }
      return val_;
   }
   if (val->AsBitstring() || val->IsTop()) {
      newval.reset( new OneFloatInterval11_52 );
      return newval.get();
   }
   return 0;
}

/** Attempts to extract an ClpValue object from @a x, and calls @a func
   if this succeeds. Otherwise, a bottom value of size @a size_in_bits is returned. */
template <class Func>
static Value* UnIntOper(Func func, const Value* x, Size size_in_bits)
{
   const ClpValue* x_;
   unique_ptr<const ClpValue> newx;
   x_ = extract_int(x, newx);
   if (x_) return func(x_);
   else return domain->CreateBottomValue(size_in_bits);
}

/** Attempts to extract ClpValue objects from @a x and @a y, and calls @a func
   if this succeeds. Otherwise, a bottom value of size @a size_in_bits is returned. */
template <class Func>
static Value* BinIntOper(Func func, const Value* x, const Value* y, Size size_in_bits)
{
   const ClpValue *x_, *y_;
   unique_ptr<const ClpValue> newx, newy;
   if ((x_ = extract_int(x, newx)) && (y_ = extract_int(y, newy)))
      return func(x_, y_);
   else
      return domain->CreateBottomValue(size_in_bits);
}

template <class IntFunc, class PtrFunc>
static Value* BinIntPtrOper(IntFunc intfunc, PtrFunc ptrfunc, const Value* x, const Value* y, Size size_in_bits)
{
   const ClpValue *x_int, *y_int;
   const SymbClpPtrSet *x_ptr, *y_ptr; 
   unique_ptr<const ClpValue> newx_int, newy_int;
   unique_ptr<const SymbClpPtrSet> newx_ptr, newy_ptr;
   unique_ptr<Value> result, tmp;

   // try to extract the Value subtypes for which this operation is defined
   x_int = extract_int(x, newx_int);
   y_int = extract_int(y, newy_int);
   x_ptr = extract_ptr(x, newx_ptr);
   y_ptr = extract_ptr(y, newy_ptr);

   // int/int comparison
   if (x_int && y_int)
      result.reset( intfunc(x_int, y_int) );
   else
      result.reset( domain->CreateBottomValue(size_in_bits) );

   // ptr/ptr comparison
   if (x_ptr && y_ptr) {
      tmp.reset( ptrfunc(x_ptr, y_ptr) );
      result.reset( result->LUB( tmp.get() ) );
   }

   return result.release();
}


template <class FloatFunc8_23, class FloatFunc11_52>
Value* BinFloatOper(FloatFunc8_23 func8_23, FloatFunc11_52 func11_52, const Value* x, const Value* y, Size size_in_bits)
{
   Size opsize = x->SizeInBits();
   if (opsize == 32) {
      const OneFloatInterval8_23 *x_, *y_;
      unique_ptr<const OneFloatInterval8_23> newx, newy;
      if ((x_ = extract_float8_23(x, newx)) && (y_ = extract_float8_23(y, newy)))
         return func8_23(x_, y_);
      else
         return domain->CreateBottomValue(size_in_bits);
   }
   else if (opsize == 64) {
      const OneFloatInterval11_52 *x_, *y_;
      unique_ptr<const OneFloatInterval11_52> newx, newy;
      if ((x_ = extract_float11_52(x, newx)) && (y_ = extract_float11_52(y, newy)))
         return func11_52(x_, y_);
      else
         return domain->CreateBottomValue(size_in_bits);
   }
   else if ((x->AsBitstring() || x->AsTopValue()) && (y->AsBitstring() || y->AsTopValue())) {
      // unsupported size on operands; return a top bitstring
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
   }
   else
      return domain->CreateBottomValue(size_in_bits);
}

// members of OpPolicies_Clp -------------------------------------------------------------

Value* OpPolicies_Clp::Neg(const Value* x)
{
   return UnIntOper(&Ops_ClpValue::Neg, x, x->SizeInBits());
}

Value* OpPolicies_Clp::Add(const Value* x, const Value* y, const Value* c)
{
   const ClpValue *x_int, *y_int, *c_int;
   const SymbClpPtrSet *x_ptr, *y_ptr; 
   unique_ptr<const ClpValue> newx_int, newy_int, newc_int;
   unique_ptr<const SymbClpPtrSet> newx_ptr, newy_ptr;

   unique_ptr<Value> sum( domain->CreateBottomValue(x->SizeInBits()) ), tmp;

   // try to extract a ClpValue from c
   c_int = extract_int(c, newc_int);
   if (!c_int)
      return sum.release();

   // try to extract the Value subtypes for which this operation is defined
   x_int = extract_int(x, newx_int);
   y_int = extract_int(y, newy_int);
   x_ptr = extract_ptr(x, newx_ptr);
   y_ptr = extract_ptr(y, newy_ptr);

   // int/int addition
   if (x_int && y_int)
      sum.reset( Ops_ClpValue::Add(x_int, y_int, c_int) );

   // ptr/int addition
   if (x_ptr && y_int) {
      tmp.reset( Ops_SymbPointerSet<SymbClpPtrSet>::Add(x_ptr, y_int, c_int) );
      sum.reset( LUB(sum.get(), tmp.get()) );
   }
   if (x_int && y_ptr) {
      tmp.reset( Ops_SymbPointerSet<SymbClpPtrSet>::Add(x_int, y_ptr, c_int) );
      sum.reset( LUB(sum.get(), tmp.get()) );
   }

   return sum.release();
}

Value* OpPolicies_Clp::CAdd(const Value* x, const Value* y, const Value* c)
{
   const ClpValue *x_int, *y_int, *c_int;
   const SymbClpPtrSet *x_ptr, *y_ptr; 
   unique_ptr<const ClpValue> newx_int, newy_int, newc_int;
   unique_ptr<const SymbClpPtrSet> newx_ptr, newy_ptr;

   unique_ptr<Value> carryout( domain->CreateBottomValue(1) ), tmp;

   // try to extract a ClpValue from c
   c_int = extract_int(c, newc_int);
   if (!c_int)
      return carryout.release();

   // try to extract the Value subtypes for which this operation is defined
   x_int = extract_int(x, newx_int);
   y_int = extract_int(y, newy_int);
   x_ptr = extract_ptr(x, newx_ptr);
   y_ptr = extract_ptr(y, newy_ptr);

   // int/int addition
   if (x_int && y_int)
      carryout.reset( Ops_ClpValue::CAdd(x_int, y_int, c_int) );

   // ptr/int addition
   if (x_ptr && y_int) {
      tmp.reset( Ops_SymbPointerSet<SymbClpPtrSet>::CAdd(x_ptr, y_int, c_int) );
      carryout.reset( LUB(carryout.get(), tmp.get()) );
   }
   if (x_int && y_ptr) {
      tmp.reset( Ops_SymbPointerSet<SymbClpPtrSet>::CAdd(x_int, y_ptr, c_int) );
      carryout.reset( LUB(carryout.get(), tmp.get()) );
   }
   return carryout.release();
}

Value* OpPolicies_Clp::Sub(const Value* x, const Value* y, const Value* c)
{
   const ClpValue *x_int, *y_int, *c_int;
   const SymbClpPtrSet *x_ptr, *y_ptr; 
   unique_ptr<const ClpValue> newx_int, newy_int, newc_int;
   unique_ptr<const SymbClpPtrSet> newx_ptr, newy_ptr;

   unique_ptr<Value> diff( domain->CreateBottomValue(x->SizeInBits()) ), tmp;

   // try to extract a ClpValue from c
   c_int = extract_int(c, newc_int);
   if (!c_int)
      return diff.release();

   // try to extract the Value subtypes for which this operation is defined
   x_int = extract_int(x, newx_int);
   y_int = extract_int(y, newy_int);
   x_ptr = extract_ptr(x, newx_ptr);
   y_ptr = extract_ptr(y, newy_ptr);

   // int/int subtraction
   if (x_int && y_int)
      diff.reset( Ops_ClpValue::Sub(x_int, y_int, c_int) );

   // ptr/int subtraction
   if (x_ptr && y_int) {
      tmp.reset( Ops_SymbPointerSet<SymbClpPtrSet>::Sub(x_ptr, y_int, c_int) );
      diff.reset( LUB(diff.get(), tmp.get()) );
   }

   // ptr/ptr subtraction
   if (x_ptr && y_ptr) {
      tmp.reset( Ops_SymbPointerSet<SymbClpPtrSet>::Sub(x_ptr, y_ptr, c_int) );
      diff.reset( LUB(diff.get(), tmp.get()) );
   }

   return diff.release();
}

Value* OpPolicies_Clp::CSub(const Value* x, const Value* y, const Value* c)
{
   const ClpValue *x_int, *y_int, *c_int;
   const SymbClpPtrSet *x_ptr, *y_ptr; 
   unique_ptr<const ClpValue> newx_int, newy_int, newc_int;
   unique_ptr<const SymbClpPtrSet> newx_ptr, newy_ptr;

   unique_ptr<Value> carryout( domain->CreateBottomValue(1) ), tmp;

   // try to extract a ClpValue from c
   c_int = extract_int(c, newc_int);
   if (!c_int)
      return carryout.release();

   // try to extract the Value subtypes for which this operation is defined
   x_int = extract_int(x, newx_int);
   y_int = extract_int(y, newy_int);
   x_ptr = extract_ptr(x, newx_ptr);
   y_ptr = extract_ptr(y, newy_ptr);

   // int/int subtraction
   if (x_int && y_int)
      carryout.reset( Ops_ClpValue::CSub(x_int, y_int, c_int) );

   // ptr/int subtraction
   if (x_ptr && y_int) {
      tmp.reset( Ops_SymbPointerSet<SymbClpPtrSet>::CSub(x_ptr, y_int, c_int) );
      carryout.reset( LUB(carryout.get(), tmp.get()) );
   }

   // ptr/ptr subtraction
   if (x_ptr && y_ptr) {
      tmp.reset( Ops_SymbPointerSet<SymbClpPtrSet>::CSub(x_ptr, y_ptr, c_int) );
      carryout.reset( LUB(carryout.get(), tmp.get()) );
   }

   return carryout.release();
}

Value* OpPolicies_Clp::SMul(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::SMul, x, y, x->SizeInBits() + y->SizeInBits());
}

Value* OpPolicies_Clp::UMul(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::UMul, x, y, x->SizeInBits() + y->SizeInBits());
}

Value* OpPolicies_Clp::Mul_Trunc(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::Mul_Trunc, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::SDiv(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::SDiv, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::UDiv(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::UDiv, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::SMod(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::SMod, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::UMod(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::UMod, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::Eq(const Value* x, const Value* y)
{
   return BinIntPtrOper(&Ops_ClpValue::Eq, &Ops_SymbPointerSet<SymbClpPtrSet>::Eq, x, y, 1);
}

Value* OpPolicies_Clp::NEq(const Value* x, const Value* y)
{
   return BinIntPtrOper(&Ops_ClpValue::NEq, &Ops_SymbPointerSet<SymbClpPtrSet>::NEq, x, y, 1);
}

Value* OpPolicies_Clp::SLT(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::SLT, x, y, 1);
}

Value* OpPolicies_Clp::SLE(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::SLE, x, y, 1);
}

Value* OpPolicies_Clp::SGE(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::SGE, x, y, 1);
}

Value* OpPolicies_Clp::SGT(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::SGT, x, y, 1);
}

Value* OpPolicies_Clp::ULT(const Value* x, const Value* y)
{
   return BinIntPtrOper(&Ops_ClpValue::ULT, &Ops_SymbPointerSet<SymbClpPtrSet>::ULT, x, y, 1);
}

Value* OpPolicies_Clp::ULE(const Value* x, const Value* y)
{
   return BinIntPtrOper(&Ops_ClpValue::ULE, &Ops_SymbPointerSet<SymbClpPtrSet>::ULE, x, y, 1);
}

Value* OpPolicies_Clp::UGE(const Value* x, const Value* y)
{
   return BinIntPtrOper(&Ops_ClpValue::UGE, &Ops_SymbPointerSet<SymbClpPtrSet>::UGE, x, y, 1);
}

Value* OpPolicies_Clp::UGT(const Value* x, const Value* y)
{
   return BinIntPtrOper(&Ops_ClpValue::UGT, &Ops_SymbPointerSet<SymbClpPtrSet>::UGT, x, y, 1);
}

Value* OpPolicies_Clp::Not(const Value* x)
{
   if (x->AsReadValue()) return Ops_ReadValue::Not((const ReadValue*)x);
   return UnIntOper(&Ops_ClpValue::Not, x, x->SizeInBits());
}

Value* OpPolicies_Clp::And(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::And, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::Or(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::Or, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::XOr(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::XOr, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::LShift(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::LShift, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::RShift(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::RShift, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::RShiftA(const Value* x, const Value* y)
{
   return BinIntOper(&Ops_ClpValue::RShiftA, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::ZExt(const Value* x, const Size& n)
{
   // ZExt is defined for both bitstring types and symbolic pointers
   if (x->AsClpValue()) return Ops_ClpValue::ZExt((const ClpValue*)x, n);
   if (x->AsSymbClpPtrSet()) return Ops_SymbPointerSet<SymbClpPtrSet>::ZExt((const SymbClpPtrSet*)x, n);
   if (x->AsReadValue()) return Ops_ReadValue::ZExt((const ReadValue*)x, n);
   if (x->AsBitstring()) {
      ClpValue topint(x->SizeInBits());
      return Ops_ClpValue::ZExt(&topint, n);
   }
   if (x->IsTop()) return domain->CreateTopValue(n); // contains both bitstrings and symb. pointers
   return domain->CreateBottomValue(n);
}

Value* OpPolicies_Clp::SExt(const Value* x, const Size& n)
{
   const ClpValue* x_;
   unique_ptr<const ClpValue> newx;
   x_ = extract_int(x, newx);
   if (x_) return Ops_ClpValue::SExt(x_, n);
   else return domain->CreateBottomValue(n);
}

Value* OpPolicies_Clp::Repeat(const Value* x, const Size& n)
{
   const ClpValue* x_;
   unique_ptr<const ClpValue> newx;
   x_ = extract_int(x, newx);
   if (x_) return Ops_ClpValue::Repeat(x_, n);
   else return domain->CreateBottomValue(n);
}

Value* OpPolicies_Clp::Select(const Value* x, const Size& m, const Size& n)
{
   if (x->AsClpValue()) return Ops_ClpValue::Select((const ClpValue*)x, m, n);
   if (x->AsReadValue()) return Ops_ReadValue::Select((const ReadValue*)x, m, n);
   Size size_in_bits = n - m + 1;
   if (x->AsBitstring()) {
      if (m == 0 && n == x->SizeInBits() - 1) return x->Copy();
      else return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
   }
   if (x->IsTop())
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
   // select is only defined for bitstring types
   return domain->CreateBottomValue(size_in_bits);
}

Value* OpPolicies_Clp::Conc(const Value* x, const Value* y)
{
   // this operation is only defined for bitstring types, but we have a special handling of ReadValue operands
   if (x->AsReadValue()) {
      if (y->AsReadValue()) return Ops_ReadValue::Conc_RR((const ReadValue*)x, (const ReadValue*)y);
      else return Ops_ReadValue::Conc_RV((const ReadValue*)x, y);
   }
   else if (y->AsReadValue())
      return Ops_ReadValue::Conc_VR(x, (const ReadValue*)y);
   else
      return BinIntOper(&Ops_ClpValue::Conc, x, y, x->SizeInBits() + y->SizeInBits());
}

Value* OpPolicies_Clp::FNeg(const Value* x)
{
   Size size_in_bits = x->SizeInBits();
   if (size_in_bits == 32) {
      const OneFloatInterval8_23* x_;
      unique_ptr<const OneFloatInterval8_23> newx;
      x_ = extract_float8_23(x, newx);
      if (x_) return Ops_OneFloatInterval<OneFloatInterval8_23>::FNeg(x_);
      return domain->CreateBottomValue(size_in_bits);      
   }
   else if (size_in_bits == 64) {
      const OneFloatInterval11_52* x_;
      unique_ptr<const OneFloatInterval11_52> newx;
      x_ = extract_float11_52(x, newx);
      if (x_) return Ops_OneFloatInterval<OneFloatInterval11_52>::FNeg(x_);
      return domain->CreateBottomValue(size_in_bits);      
   }
   else if (x->AsBitstring() || x->IsTop()) {
      // unsupported size - return a top bitstring
      return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
   }
   else
      return domain->CreateBottomValue(size_in_bits);
}

Value* OpPolicies_Clp::FAdd(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FAdd,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FAdd, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::FSub(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FSub,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FSub, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::FMul(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FMul,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FMul, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::FDiv(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FDiv,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FDiv, x, y, x->SizeInBits());
}

Value* OpPolicies_Clp::FToF(const Value* x, const Size& m, const Size& n)
{
   if (x->AsOneFloatInterval8_23()) return Ops_OneFloatInterval<OneFloatInterval8_23>::FToF((const OneFloatInterval8_23*)x, m, n);
   if (x->AsOneFloatInterval11_52()) return Ops_OneFloatInterval<OneFloatInterval11_52>::FToF((const OneFloatInterval11_52*)x, m, n);
   if (x->AsReadValue()) return Ops_ReadValue::TernOp_RSS<&Value::FToF>((const ReadValue*)x, m, n);
   Size size_in_bits = 1 + m + n;
   if (x->AsBitstring() || x->IsTop()) {
      if ((m == 8 && n == 23) || (m == 11 && n == 52))
         return domain->GetFloatDomain()->CreateFloat(m, n);
      else {
         // unsupported size for floats - return a top bitstring in the form of an int
         return domain->GetIntegerDomain()->CreateInteger(size_in_bits);
      }
   }
   // the operation is only defined for bitstrings
   return domain->CreateBottomValue(size_in_bits);
}

Value* OpPolicies_Clp::FToS(const Value* x, const Size& n)
{
   if (x->AsOneFloatInterval8_23()) return Ops_OneFloatInterval<OneFloatInterval8_23>::FToS((const OneFloatInterval8_23*)x, n);
   if (x->AsOneFloatInterval11_52()) return Ops_OneFloatInterval<OneFloatInterval11_52>::FToS((const OneFloatInterval11_52*)x, n);
   if (x->AsReadValue()) return Ops_ReadValue::BinOp_RS<&Value::FToS>((const ReadValue*)x, n);
   if (x->AsBitstring() || x->IsTop()) return domain->GetIntegerDomain()->CreateInteger(n);
   // the operation is only defined for bitstrings
   return domain->CreateBottomValue(n);
}

Value* OpPolicies_Clp::FToU(const Value* x, const Size& n)
{
   if (x->AsOneFloatInterval8_23()) return Ops_OneFloatInterval<OneFloatInterval8_23>::FToU((const OneFloatInterval8_23*)x, n);
   if (x->AsOneFloatInterval11_52()) return Ops_OneFloatInterval<OneFloatInterval11_52>::FToU((const OneFloatInterval11_52*)x, n);
   if (x->AsReadValue()) return Ops_ReadValue::BinOp_RS<&Value::FToU>((const ReadValue*)x, n);
   if (x->AsBitstring() || x->IsTop()) return domain->GetIntegerDomain()->CreateInteger(n);
   // the operation is only defined for bitstrings
   return domain->CreateBottomValue(n);
}

Value* OpPolicies_Clp::SToF(const Value* x, const Size& m, const Size& n)
{
   const ClpValue* x_;
   unique_ptr<const ClpValue> newx;
   x_ = extract_int(x, newx);
   if (x_) return Ops_ClpValue::SToF(x_, m, n);
   else return domain->CreateBottomValue(1 + n + m);
}

Value* OpPolicies_Clp::UToF(const Value* x, const Size& m, const Size& n)
{
   const ClpValue* x_;
   unique_ptr<const ClpValue> newx;
   x_ = extract_int(x, newx);
   if (x_) return Ops_ClpValue::UToF(x_, m, n);
   else return domain->CreateBottomValue(1 + n + m);
}

Value* OpPolicies_Clp::FEq(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FEq,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FEq, x, y, 1);
}

Value* OpPolicies_Clp::FNEq(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FNEq,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FNEq, x, y, 1);
}

Value* OpPolicies_Clp::FLT(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FLT,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FLT, x, y, 1);
}

Value* OpPolicies_Clp::FLE(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FLE,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FLE, x, y, 1);
}

Value* OpPolicies_Clp::FGE(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FGE,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FGE, x, y, 1);
}

Value* OpPolicies_Clp::FGT(const Value* x, const Value* y)
{
   return BinFloatOper(&Ops_OneFloatInterval<OneFloatInterval8_23>::FGT,
      &Ops_OneFloatInterval<OneFloatInterval11_52>::FGT, x, y, 1);
}

Value* OpPolicies_Clp::If(const Value* x, const Value* y, const Value* z)
{
   // here we assume that this operation is strict, which means there is no need to check y and z for bottom
   const ClpValue* x_;
   unique_ptr<const ClpValue> newx;
   x_ = extract_int(x, newx);
   if (x_) return Ops_ClpValue::If(x_, y, z);
   else return domain->CreateBottomValue(y->SizeInBits());
}

Value* OpPolicies_Clp::B2N(const Value* x)
{
   // TODO: should B2N be supported for symbolic pointers as well?
   return UnIntOper(&Ops_ClpValue::B2N, x, Size::Infinity());
}

Value* OpPolicies_Clp::Exp2(const Value* x)
{
   return UnIntOper(&Ops_ClpValue::Exp2, x, x->SizeInBits());
}

Value* OpPolicies_Clp::ILog2(const Value* x)
{
   return UnIntOper(&Ops_ClpValue::ILog2, x, x->SizeInBits());
}

bool OpPolicies_Clp::Includes(const Value* x, const Value* y)
{
   // ClpValue
   if (x->AsClpValue() && y->AsClpValue())
      return Ops_ClpValue::Includes((const ClpValue*)x, (const ClpValue*)y);

   // SymbClpPtrSet
   if (x->AsSymbClpPtrSet() && y->AsSymbClpPtrSet())
      return Ops_SymbPointerSet<SymbClpPtrSet>::Includes((const SymbClpPtrSet*)x, (const SymbClpPtrSet*)y);

   // OneFloatInterval8_23
   if (x->AsOneFloatInterval8_23() && y->AsOneFloatInterval8_23()) {
      return Ops_OneFloatInterval<OneFloatInterval8_23>::Includes(
         (const OneFloatInterval8_23*)x, (const OneFloatInterval8_23*)y);
   }

   // OneFloatInterval11_52
   if (x->AsOneFloatInterval11_52() && y->AsOneFloatInterval11_52()) {
      return Ops_OneFloatInterval<OneFloatInterval11_52>::Includes(
         (const OneFloatInterval11_52*)x, (const OneFloatInterval11_52*)y);
   }

   // ReadValue
   if (x->AsReadValue()) return Ops_ReadValue::BinOpBool_RV<&Value::Includes>((const ReadValue*)x, y);
   if (y->AsReadValue()) return Ops_ReadValue::BinOpBool_VR<&Value::Includes>(x, (const ReadValue*)y);

   if (x->SizeInBits() != y->SizeInBits()) return false;

   // bottom & top
   if (x->IsTop() || y->IsBottom()) return true;

   // Bitstring
   if (x->AsBitstring() && y->AsBitstring() && x->AsBitstring()->IsTopBitstring()) return true;

   // conservative answer
   return false;
}

bool OpPolicies_Clp::Overlaps(const Value* x, const Value* y)
{
   // ClpValue
   if (x->AsClpValue() && y->AsClpValue())
      return Ops_ClpValue::Overlaps((const ClpValue*)x, (const ClpValue*)y);

   // SymbClpPtrSet
   if (x->AsSymbClpPtrSet() && y->AsSymbClpPtrSet())
      return Ops_SymbPointerSet<SymbClpPtrSet>::Overlaps((const SymbClpPtrSet*)x, (const SymbClpPtrSet*)y);

   // OneFloatInterval8_23
   if (x->AsOneFloatInterval8_23() && y->AsOneFloatInterval8_23()) {
      return Ops_OneFloatInterval<OneFloatInterval8_23>::Overlaps(
         (const OneFloatInterval8_23*)x, (const OneFloatInterval8_23*)y);
   }

   // OneFloatInterval11_52
   if (x->AsOneFloatInterval11_52() && y->AsOneFloatInterval11_52()) {
      return Ops_OneFloatInterval<OneFloatInterval11_52>::Overlaps(
         (const OneFloatInterval11_52*)x, (const OneFloatInterval11_52*)y);
   }

   // ReadValue
   if (x->AsReadValue()) return Ops_ReadValue::BinOpBool_RV<&Value::Overlaps>((const ReadValue*)x, y);
   if (y->AsReadValue()) return Ops_ReadValue::BinOpBool_VR<&Value::Overlaps>(x, (const ReadValue*)y);

   if (x->SizeInBits() != y->SizeInBits()) return false;

   // bottom
   if (x->IsBottom() || y->IsBottom()) return false;

   // symbolic pointers and bitstrings never overlap
   if ((x->AsSymbPointer() && y->AsBitstring()) || (x->AsBitstring() && y->AsSymbPointer()))
      return false;

   // conservative answer
   return true;
}

Value* OpPolicies_Clp::GLB(const Value* x, const Value* y)
{
   // ClpValue
   if (x->AsClpValue() && y->AsClpValue())
      return Ops_ClpValue::GLB((const ClpValue*)x, (const ClpValue*)y);
   
   // SymbClpPtrSet
   if (x->AsSymbClpPtrSet() && y->AsSymbClpPtrSet())
      return Ops_SymbPointerSet<SymbClpPtrSet>::GLB((const SymbClpPtrSet*)x, (const SymbClpPtrSet*)y);
   
   // OneFloatInterval8_23
   if (x->AsOneFloatInterval8_23() && y->AsOneFloatInterval8_23())
      return Ops_OneFloatInterval<OneFloatInterval8_23>::GLB((const OneFloatInterval8_23*)x, (const OneFloatInterval8_23*)y);

   // OneFloatInterval11_52
   if (x->AsOneFloatInterval11_52() && y->AsOneFloatInterval11_52())
      return Ops_OneFloatInterval<OneFloatInterval11_52>::GLB((const OneFloatInterval11_52*)x, (const OneFloatInterval11_52*)y);

   // ReadValue
   if (x->AsReadValue() && y->AsReadValue())
      return Ops_ReadValue::GLB_RR((const ReadValue*)x, (const ReadValue*)y);

   // bottom cases
   if (x->IsBottom() || y->IsBottom()) return domain->CreateBottomValue(x->SizeInBits());

   // top cases
   if (x->IsTop()) return y->Copy();
   if (y->IsTop()) return x->Copy();

   // more ReadValue
   if (x->AsReadValue()) return Ops_ReadValue::BinOp_RV<&Value::GLB>((const ReadValue*)x, y);
   if (y->AsReadValue()) return Ops_ReadValue::BinOp_VR<&Value::GLB>(x, (const ReadValue*)y);

   // the GLB must be a subset of both x and y, so returning a copy of one
   // of the operands gives a safe over-approximation
   return x->Copy();
}

Value* OpPolicies_Clp::LUB(const Value* x, const Value* y)
{
   // ClpValue
   if (x->AsClpValue() && y->AsClpValue())
      return Ops_ClpValue::LUB((const ClpValue*)x, (const ClpValue*)y);
   
   // SymbClpPtrSet
   if (x->AsSymbClpPtrSet() && y->AsSymbClpPtrSet())
      return Ops_SymbPointerSet<SymbClpPtrSet>::LUB((const SymbClpPtrSet*)x, (const SymbClpPtrSet*)y);
   
   // OneFloatInterval8_23
   if (x->AsOneFloatInterval8_23() && y->AsOneFloatInterval8_23())
      return Ops_OneFloatInterval<OneFloatInterval8_23>::LUB((const OneFloatInterval8_23*)x, (const OneFloatInterval8_23*)y);

   // OneFloatInterval11_52
   if (x->AsOneFloatInterval11_52() && y->AsOneFloatInterval11_52())
      return Ops_OneFloatInterval<OneFloatInterval11_52>::LUB((const OneFloatInterval11_52*)x, (const OneFloatInterval11_52*)y);

   // ReadValue
   if (x->AsReadValue() && y->AsReadValue())
      return Ops_ReadValue::LUB_RR((const ReadValue*)x, (const ReadValue*)y);

   // bottom cases
   if (x->IsBottom()) return y->Copy();
   if (y->IsBottom()) return x->Copy();

   // more ReadValue
   if (x->AsReadValue()) return Ops_ReadValue::BinOp_RV<&Value::LUB>((const ReadValue*)x, y);
   if (y->AsReadValue()) return Ops_ReadValue::BinOp_VR<&Value::LUB>(x, (const ReadValue*)y);

   // if both operands are bitstrings, return a top bitstring
   if (x->AsBitstring() && y->AsBitstring())
      return domain->GetIntegerDomain()->CreateInteger(x->SizeInBits());

   return domain->CreateTopValue(x->SizeInBits());
}

Value* OpPolicies_Clp::Widening(const Value* x, const Value* y)
{
   // ClpValue
   if (x->AsClpValue() && y->AsClpValue())
      return Ops_ClpValue::Widening((const ClpValue*)x, (const ClpValue*)y);
   
   // SymbClpPtrSet
   if (x->AsSymbClpPtrSet() && y->AsSymbClpPtrSet())
      return Ops_SymbPointerSet<SymbClpPtrSet>::Widening((const SymbClpPtrSet*)x, (const SymbClpPtrSet*)y);
   
   // OneFloatInterval8_23
   if (x->AsOneFloatInterval8_23() && y->AsOneFloatInterval8_23())
      return Ops_OneFloatInterval<OneFloatInterval8_23>::Widening((const OneFloatInterval8_23*)x, (const OneFloatInterval8_23*)y);

   // OneFloatInterval11_52
   if (x->AsOneFloatInterval11_52() && y->AsOneFloatInterval11_52())
      return Ops_OneFloatInterval<OneFloatInterval11_52>::Widening((const OneFloatInterval11_52*)x, (const OneFloatInterval11_52*)y);

   // ReadValue
   if (x->AsReadValue()) return Ops_ReadValue::BinOp_RV<&Value::Widening>((const ReadValue*)x, y);
   if (y->AsReadValue()) return Ops_ReadValue::BinOp_VR<&Value::Widening>(x, (const ReadValue*)y);

   // bottom cases
   if (x->IsBottom()) return y->Copy();
   if (y->IsBottom()) return x->Copy();

   // TODO: Not sure what a suitable default action would be
   return domain->CreateTopValue(x->SizeInBits());
}

Value* OpPolicies_Clp::Narrowing(const Value* x, const Value* y)
{
   // ClpValue
   if (x->AsClpValue() && y->AsClpValue())
      return Ops_ClpValue::Narrowing((const ClpValue*)x, (const ClpValue*)y);
   
   // SymbClpPtrSet
   if (x->AsSymbClpPtrSet() && y->AsSymbClpPtrSet())
      return Ops_SymbPointerSet<SymbClpPtrSet>::Narrowing((const SymbClpPtrSet*)x, (const SymbClpPtrSet*)y);
   
   // OneFloatInterval8_23
   if (x->AsOneFloatInterval8_23() && y->AsOneFloatInterval8_23())
      return Ops_OneFloatInterval<OneFloatInterval8_23>::Narrowing((const OneFloatInterval8_23*)x, (const OneFloatInterval8_23*)y);

   // OneFloatInterval11_52
   if (x->AsOneFloatInterval11_52() && y->AsOneFloatInterval11_52())
      return Ops_OneFloatInterval<OneFloatInterval11_52>::Narrowing((const OneFloatInterval11_52*)x, (const OneFloatInterval11_52*)y);

   // ReadValue
   if (x->AsReadValue()) return Ops_ReadValue::BinOp_RV<&Value::Narrowing>((const ReadValue*)x, y);
   if (y->AsReadValue()) return Ops_ReadValue::BinOp_VR<&Value::Narrowing>(x, (const ReadValue*)y);

   // bottom cases
   if (x->IsBottom() || y->IsBottom()) return domain->CreateBottomValue(x->SizeInBits());

   // TODO: Not sure what a suitable default action would be
   return domain->CreateTopValue(x->SizeInBits());
}

Value* OpPolicies_Clp::Restrict_NEq(const Value* restr, const Value* other)
{
   return BinIntPtrOper(&Ops_ClpValue::Restrict_NEq, &Ops_SymbPointerSet<SymbClpPtrSet>::Restrict_NEq,
      restr, other, restr->SizeInBits());
}

Value* OpPolicies_Clp::Restrict_SLT(const Value* restr, const Value* other)
{
   return BinIntOper(&Ops_ClpValue::Restrict_SLT, restr, other, restr->SizeInBits());
}

Value* OpPolicies_Clp::Restrict_SLE(const Value* restr, const Value* other)
{
   return BinIntOper(&Ops_ClpValue::Restrict_SLE, restr, other, restr->SizeInBits());
}

Value* OpPolicies_Clp::Restrict_SGE(const Value* restr, const Value* other)
{
   return BinIntOper(&Ops_ClpValue::Restrict_SGE, restr, other, restr->SizeInBits());
}

Value* OpPolicies_Clp::Restrict_SGT(const Value* restr, const Value* other)
{
   return BinIntOper(&Ops_ClpValue::Restrict_SGT, restr, other, restr->SizeInBits());
}

Value* OpPolicies_Clp::Restrict_ULT(const Value* restr, const Value* other)
{
   return BinIntPtrOper(&Ops_ClpValue::Restrict_ULT, &Ops_SymbPointerSet<SymbClpPtrSet>::Restrict_ULT,
      restr, other, restr->SizeInBits());
}

Value* OpPolicies_Clp::Restrict_ULE(const Value* restr, const Value* other)
{
   return BinIntPtrOper(&Ops_ClpValue::Restrict_ULE, &Ops_SymbPointerSet<SymbClpPtrSet>::Restrict_ULE,
      restr, other, restr->SizeInBits());
}

Value* OpPolicies_Clp::Restrict_UGE(const Value* restr, const Value* other)
{
   return BinIntPtrOper(&Ops_ClpValue::Restrict_UGE, &Ops_SymbPointerSet<SymbClpPtrSet>::Restrict_UGE,
      restr, other, restr->SizeInBits());
}

Value* OpPolicies_Clp::Restrict_UGT(const Value* restr, const Value* other)
{
   return BinIntPtrOper(&Ops_ClpValue::Restrict_UGT, &Ops_SymbPointerSet<SymbClpPtrSet>::Restrict_UGT,
      restr, other, restr->SizeInBits());
}

Value* OpPolicies_Clp::Restrict_Select(const Value* restr, Size idx_first, const Value* result)
{
   unique_ptr<const ClpValue> newrestr_int;
   const ClpValue *restr_int = extract_int(restr, newrestr_int);
   if (restr_int) {
      if (result->AsClpValue()) return Ops_ClpValue::Restrict_Select(restr_int, idx_first, (const ClpValue*)result);
      if (result->AsReadValue()) return Ops_ReadValue::RevSelect((const ReadValue*)result, restr->SizeInBits(), idx_first);
      if (result->AsBitstring() && idx_first == 0 && result->SizeInBits() == restr->SizeInBits()) return result->Copy();
      if (result->AsBitstring() || result->IsTop()) {
         ClpValue topint(result->SizeInBits());
         return Ops_ClpValue::Restrict_Select(restr_int, idx_first, &topint);
      }
   }
   // since the select operation returns a bitstring, there are solutions to reverse select
   // only if 'result' is a bitstring
   return domain->CreateBottomValue(restr->SizeInBits());
}

Value* OpPolicies_Clp::RevSMul(const Value* result, const Value* op1, const Size& size_in_bits)
{
   const ClpValue *result_, *op1_;
   unique_ptr<const ClpValue> newresult, newop1;
   if ((result_ = extract_int(result, newresult)) && (op1_ = extract_int(op1, newop1)))
      return Ops_ClpValue::RevSMul(result_, op1_, size_in_bits);
   else
      return domain->CreateBottomValue(size_in_bits);
}

Value* OpPolicies_Clp::RevUMul(const Value* result, const Value* op1, const Size& size_in_bits)
{
   const ClpValue *result_, *op1_;
   unique_ptr<const ClpValue> newresult, newop1;
   if ((result_ = extract_int(result, newresult)) && (op1_ = extract_int(op1, newop1)))
      return Ops_ClpValue::RevUMul(result_, op1_, size_in_bits);
   else
      return domain->CreateBottomValue(size_in_bits);
}

Value* OpPolicies_Clp::RevAnd(const Value* result, const Value* op1)
{
   return BinIntOper(&Ops_ClpValue::RevAnd, result, op1, op1->SizeInBits());
}

Value* OpPolicies_Clp::RevOr(const Value* result, const Value* op1)
{
   return BinIntOper(&Ops_ClpValue::RevOr, result, op1, op1->SizeInBits());
}

Value* OpPolicies_Clp::RevXOr(const Value* result, const Value* op1)
{
   return BinIntOper(&Ops_ClpValue::RevXOr, result, op1, op1->SizeInBits());
}

Value* OpPolicies_Clp::RevLShift1(const Value* result, const Value* shamt)
{
   return BinIntOper(&Ops_ClpValue::RevLShift1, result, shamt, result->SizeInBits());
}
