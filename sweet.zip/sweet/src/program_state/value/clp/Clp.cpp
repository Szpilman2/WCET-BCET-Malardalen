#include "Clp.h"
#include <vector>
#include <algorithm>
#include <limits>

using namespace std;

namespace ClpUtils {

Clp OptimAbstract(unsigned long long size_in_bits, const std::vector<Integer> &vals) {
   // Collection of "facts":
   // - Only strides < 'width' need to be considered.  Any other stride gives
   //   the same set of concrete values as the stride % 'width' does.
   // - Every pair (v0, v1) of concrete values gives two possible strides,
   //   (v0 - v1) % width and (v1 - v0) % width.
   // - Only bases that coincide with a value in 'v' need to be considered.  Any
   //   other base can be stepped until it does coincide with a value in 'v',
   //   and thereby give a better approximation.

   Integer width = RepresentableRangeWidth<Integer>(size_in_bits);
   Integer mask = width - 1;
   vector<Integer> v = vals;
   for (int vi = 0, vn = (int)v.size(); vi != vn; ++vi) v[vi] &= mask;
   sort(v.begin(), v.end());
   unique(v.begin(), v.end());
   Clp best(v[0], width); // initialize to top
   // for each possible base
   for (int bi = 0, bn = (int)v.size(); bi != bn; ++bi) {
      Integer base = v[bi];
      // find the best stride given the current base (very brute-force)
      for (Integer stride = width / 2; stride > 0; --stride) {
         bool valid = true;
         Integer count(1);
         Integer d = GCD_Pow2(stride, width);
         // for each value in 'v', compute the count necessary to reach it from 'base'
         for (int vi = (bi + 1) % bn; vi != bi; vi = (vi + 1) % bn) {
            // early exit - the current stride cannot improve the CLP
            if (count >= best.GetCount()) {
               valid = false;
               break;
            }
            // find the least solution (if it exists) to the linear congruence
            //    base + stride * x === v[vi]  (mod width)
            //    <=>
            //    base + stride * x - base === v[vi] - base  (mod width)
            //    <=>
            //    stride * x === v[vi] - base  (mod width)
            //
            Integer b = v[vi] - base;
            if (b % d == 0) { // a solution exists
               // TODO: this can be solved analytically
               Integer c(0);
               for (;;) {
                  if (((base + stride * c) & mask) == v[vi]) {
                     ++c;
                     break;
                  }
                  ++c;
               }
               count = max(count, c);
            } else {
               valid = false;
               break;
            }
         }
         if (valid) {
            if (count < best.GetCount()) {
               best.SetBase(base);
               best.SetStride(stride);
               best.SetCount(count);
            }
         }
      }
   }
   return best;
}

Clp And(const Clp &a, const Clp &b) {
   if (IsEmpty(a)) return a;
   if (IsEmpty(b)) return b;
   Clp a_ = a, b_ = b;
   Integer laANDlb = a_.GetBase() & b_.GetBase();
   if (IsSingleton(a_)) {
      if (IsSingleton(b_)) return Clp(laANDlb);
      else std::swap(a_, b_); // to simplify the subsequent code
   }
   Clp result;
   Integer ua = a_.GetUpper(), ub = b_.GetUpper();
   // handle special case
   if (IsSingleton(b_) && a_.GetCount() == 2) {
      result.SetBase(laANDlb);
      result.SetStride((ua & b_.GetBase()) - laANDlb);
      result.SetCount(Integer(2));
      return result;
   }
   // 'L1' and 'L2' will have 1 in the least significant bit position where 'a_' and 'b_' vary, respectively,
   // and 0 in all other bits.  Similarly, 'U1' and 'U2' will have 1 in the most significant bit position
   // where 'a_' and 'b_' vary.  In the report, these names refer to the corresponding *bit positions*, but here it
   // is more useful to have them refer to 2^(bit position).
   Integer varmask, L1, U1, L2, U2;
   L1 = a_.GetStride() & -a_.GetStride();
   U1 = hibit(a_.GetBase() ^ ua);
   varmask = (((U1 << 1) - 1) ^ (L1 - 1));
   if (IsSingleton(b_))
      L2 = U2 = 0; // dummy values
   else {
      L2 = b_.GetStride() & -b_.GetStride();
      U2 = hibit(b_.GetBase() ^ ub);
      varmask |= (((U2 << 1) - 1) ^ (L2 - 1));
   }
   // now 'varmask' has 1s in the bit positions where the values of 'a_' or 'b_' vary
   // compute the bit indices 'L' and 'U' where the *result* varies (again, 'L' and 'U'
   // actually store 2^(bit position)).
   Integer L, U;
   if (IsSingleton(b_)) {
      L = (b_.GetBase() & varmask);
      U = hibit(L);
      L &= -L;
   } else {
      if (L1 == L2)
         L = L1;
      else if (L2 > L1) {
         L = b_.GetBase();
         L &= (L2 - 1);
         L &= ~(L1 - 1);
         L &= -L;
         if (L == 0) L = L2;
      } else {
         L = a_.GetBase();
         L &= (L1 - 1);
         L &= ~(L2 - 1);
         L &= -L;
         if (L == 0) L = L1;
      }
      if (U1 == U2)
         U = U1;
      else if (U1 > U2) {
         U = b_.GetBase();
         U &= (U1 << 1) - 1;
         U = hibit(U);
      } else {
         U = a_.GetBase();
         U &= (U2 << 1) - 1;
         U = hibit(U);
      }
   }
   varmask &= ((U << 1) - 1) ^ (L - 1);
   // now 'varmask' has 1s in the bit positions where the result varies
   if (varmask == 0) {
      // no bits vary in the result
      result.SetBase( laANDlb );
      result.SetCount( Integer(1) );
      return result;
   }
   result.SetStride( L ); // safe stride
   // set the bits of 'varmask' where the result is monotonically increasing to 0
   if (U1 > U2) {
      // note: if U1 > U, this loop will terminate immediately, because (b_.GetBase() & x) != 0 will
      // be false from the start
      // note 2: if U2 == 0 here (i.e., 'b_' is a singleton), U2 << 1 is also 0, but this doesn't matter
      // because it must hold that L1,L >= 1
      for (Integer x = U1, x_end = std::max(U2 << 1, std::max(L1, L)); x >= x_end && (b_.GetBase() & x) != 0; x >>= 1) {
         assert((varmask & x) != 0);
         varmask ^= x;
      }
      // now 'varmask' has 1s in the bit positions where the result is not (necessarily) monotonically increasing
      if (varmask == 0)
         result.SetStride( std::max(result.GetStride(), a_.GetStride()) );
   } else if (U2 > U1) {
      // note: if U2 > U, this loop will terminate immediately, because (a_.GetBase() & x) != 0 will
      // be false from the start
      for (Integer x = U2, x_end = std::max(U1 << 1, std::max(L2, L)); x >= x_end && (a_.GetBase() & x) != 0; x >>= 1) {
         assert((varmask & x) != 0);
         varmask ^= x;
      }
      // now 'varmask' has 1s in the bit positions where the result is not (necessarily) monotonically increasing
      if (varmask == 0)
         result.SetStride( std::max(result.GetStride(), b_.GetStride()) );
   }
   Integer slb = laANDlb & ~varmask; // safe lower bound
   Integer sub = std::min((ua & ub) | varmask, std::min(ua, ub)); // safe upper bound
   result.SetBase( laANDlb + result.GetStride() * ((slb - laANDlb) / result.GetStride()) );
   result.SetUpper( sub );
   return result;
}

PrimeSieve prime_sieve;

void GetDivisors(Integer n, std::vector<Integer> &divs_out) {
   // Adapted from code given here: http://stackoverflow.com/questions/171765/what-is-the-best-way-to-get-all-the-divisors-of-a-number#171784
   typedef PrimeSieve::T T;
   assert(n <= std::numeric_limits<T>::max());
   assert(n > 0);
   const T n_ = n.As<T>();
   divs_out.push_back(Integer(1));
   if (n_ == 1)
      return; // done
   // find the prime factors of 'n' and store them in 'facs_'
   std::vector<T> facs_;
   T m = n_;
   // special, more efficient handling of the prime number 2
   T pow2 = m & (~m + 1);
   if (pow2 != 1) {
      facs_.push_back(2);
      m /= pow2;
   }
   for (T i = 1;; ++i) { // start at the prime number 3
      // TODO: should perhaps check if 'm' is a prime number, and if so, break the loop early?
      T pi = ClpUtils::prime_sieve.Get(i);
      if (pi > m)
         break;
      if (m % pi == 0) {
         facs_.push_back(pi);
         // now remove 'pi' from 'm'
         m /= pi;
         for (;;) {
            T newn = m / pi;
            if (newn * pi == m)
               m = newn;
            else
               break;
         }
      }
   }
   const T *facs = &facs_.at(0); // it's faster to use C array
   const T nfacs = facs_.size();
   // now generate all divisors using the prime factors in 'facs'
   std::vector<T> mults_(nfacs, 1);
   T *mults = &mults_.at(0); // it's faster to use C array
   T div = 1; // implicitly stores the product of mults[i] for 0 <= i < nfacs
   for (T i = 0;;) {
      T newmult = mults[i] * facs[i];
      if (n_ % newmult == 0) {
         mults[i] = newmult;
         div *= facs[i];
         divs_out.push_back(Integer(div));
         i = 0;
         continue;
      }
      // reset mults[i] to 1 and move on
      div /= mults[i];
      mults[i] = 1;
      ++i;
      if (i >= nfacs)
         return;
   }
}

}
