#ifndef INTINTERVAL_H_INCLUDED
#define INTINTERVAL_H_INCLUDED

#include "Bitstring.h"
#include "IntRangeTpl.h"
#include "IntegerDomain.h" 
#include "program_state/Endianness.h"
#include "tools/Integer.h"
#include <vector>
#include <iostream>
#include <list>
#include <stdexcept>

class DataPatch;
typedef std::list<DataPatch> PatchList;

enum AbsBitValue
{
   ONLY_ONE, 
   ONLY_ZERO, 
   BOTH_ZERO_AND_ONE
};

class IntInterval;

class IntInterval : public Bitstring
{
public:
   typedef Integer IntRep;
   typedef IntRangeTpl<Integer> IntRange;
   typedef std::list<IntRange> IntRangeList;
   
   /** Try to create an IntInterval<Subclass> with values [l..u]. If u < l, a bottom
      value is created instead. */
   static Value* Create(const Size& size_in_bits, const Integer& l, const Integer& u);

   /** Try to create an IntInterval<Subclass> from a set of @a ranges. If @a ranges holds more ranges
      than @c max_number_of_ranges, ranges are merged until there are only that many left. If @a ranges
      is empty, a bottom value is created instead. */   
   static Value* Create(const Size& size_in_bits, IntRangeList& ranges);

   /** Create a top integer interval */
   IntInterval(const Size & size_in_bits);

   IntInterval(const Size & size_in_bits, const Integer & val);

   IntInterval(const Size & size_in_bits, const Integer & l, const Integer & u);

   /** Create an integer interval value from the range set @a rs.
       @note @a rs will be empty after the call */
   IntInterval(const Size & size_in_bits, IntRangeList & rs);

   IntInterval(const IntInterval & other);

   virtual IntInterval * Copy() const { return new IntInterval(*this); }

   virtual void AcceptVisitor(ValueVisitor * visitor) const 
      { visitor->VisitIntInterval(*this); }

   /** Dynamic cast */
   virtual const IntInterval* AsIntInterval() const { return this; }

   /** @copydoc Bitstring::IsEqual(const Value*) const */
   bool IsEqual(const Value * other) const;
   
   /** Fill in @a rs with this interval interpreted as a signed range set */
   void GetSignedRanges(IntRangeList & rs) const;

   /** Fill in @a rs with this interval interpreted as an unsigned range set */
   void GetUnsignedRanges(IntRangeList & rs) const;

   /** Returns whether this integer interval has an unsigned representation or not.
       If infinite precision is used, it might not because if it includes negative
       values, those values cannot be represented as unsigned (i.e., be wrapped around) */
   bool HasUnsignedRep() const;

   /** Fill in @a values with all the concrete integer values that this value represents,
       interpreted as unsigned values */
   void AsUnsigned(std::vector<Integer> & values) const;

   Integer LAsUnsigned() const;
   Integer UAsUnsigned() const;
   Integer LAsSigned() const;
   Integer UAsSigned() const;

   /** Returns the abstract value of a certain bit. The bits are counted from
       0 to bitsize - 1. */
   AbsBitValue ValueOfBit(uint64_t bit) const;

   virtual bool IsTopBitstring() const;

   virtual bool IsSingleElem() const;

   Value * SExclUpperBelow() const;
   Value * UExclUpperBelow() const;
   Value * SExclLowerAbove() const;
   Value * UExclLowerAbove() const;
   Value * SInclUpperBelow() const;
   Value * UInclUpperBelow() const;
   Value * SInclLowerAbove() const;
   Value * UInclLowerAbove() const;

   std::ostream & Print(std::ostream & o = std::cout) const;
   std::ostream & PrintAsSigned(std::ostream & o = std::cout) const;
   std::ostream & PrintAsUnsigned(std::ostream & o = std::cout) const;
   std::ostream & PrintBinary(std::ostream & o = std::cout) const;
   std::ostream & PrintAbsBinary(std::ostream & o = std::cout) const;

private:
   /** Class which is used to compare two ranges in terms of their lower bounds (used when sorting) */
   class CompareLOfRanges;
   /** Help class used when merging ranges in range_set (see InitRangeSetFinSize() and InitRangeSetInfSize()) */
   class MergedIntervals;

   /** The maximum number of ranges allowed to be held by a IntInterval object, which means that range sets
      with more ranges than this have their ranges merged until they hold this number of ranges
      @note This value cannot be changed at present */
   static const unsigned max_number_of_ranges = 1;

   /** Represents the included bit strings as a set of ranges. Each range is
       represented as [l..u], where 0 <= l,u <= LargestRepresentableUnsigned().
       If l <= u, the range represents the set of bit strings
       { b | l <= b <= u }, otherwise it represents
       { b | 0 <= b <= u && l <= b <= LargestRepresentableUnsigned() }.
       An exception to this is when SizeInBits() == Size::Infinity(); then
       each range satisfies l <= u and simply represents an interval of natural
       numbers.  It is not recommended that this member is accessed directly,
       but rather that a transformed copy of it is retrieved by a call to
       GetSignedRanges() or GetUnsignedRanges(). */
   IntRangeList range_set;

   bool is_top;

   void InitRangeSet(const Integer & l, const Integer & u);

   void InitRangeSet(IntRangeList & rs);

   void InitRangeSetFinSize(IntRangeList & rs);

   void InitRangeSetInfSize(IntRangeList & rs);

   const IntRangeList & GetRanges() const {return range_set;}
};

/** @name Utility functions
    @{ */

/** Compute the smallest possible value la = a & b, where a lies in the range [l1..u1] and b lies in the range [l2..u2]
    @note All values are treated as infinite precision bit strings expressing the values using twos-complement.
          This means that positive values are treated as having an infinite "tail" of 0s, and negative 
          values as having an infinite tail of 1s. */
Integer LowerAND(const Integer & l1, const Integer & u1, const Integer & l2, const Integer & u2);

/** Compute the largest possible value ua = a & b, where a lies in the range [l1..u1] and b lies in the range [l2..u2]
    @note All values are treated as infinite precision bit strings expressing the values using twos-complement.
          This means that positive values are treated as having an infinite "tail" of 0s, and negative 
          values as having an infinite tail of 1s. */
Integer UpperAND(const Integer & l1, const Integer & u1, const Integer & l2, const Integer & u2);

/** Compute the smallest possible value lo = a | b, where a lies in the range [l1..u1] and b lies in the range [l2..u2]
    @note All values are treated as infinite precision bit strings expressing the values using twos-complement.
          This means that positive values are treated as having an infinite "tail" of 0s, and negative 
          values as having an infinite tail of 1s. */
Integer LowerOR(const Integer & l1, const Integer & u1, const Integer & l2, const Integer & u2);

/** Compute the largest possible value lo = a | b, where a lies in the range [l1..u1] and b lies in the range [l2..u2]
    @note All values are treated as infinite precision bit strings expressing the values using twos-complement.
          This means that positive values are treated as having an infinite "tail" of 0s, and negative 
          values as having an infinite tail of 1s. */
Integer UpperOR(const Integer & l1, const Integer & u1, const Integer & l2, const Integer & u2);

/** Returns a value k = 2^p, where p is the index of the highest bit set (where the bit positions are indexed from 0)
    @pre @p bit_string >= 0 */
Integer HighestBitSet(const Integer & bit_string);

/** Returns the index of the highest bit set in @p bit_string
    @pre @p bit_string > 0 */
template <typename IntRep>
unsigned long long HighestBitPosSet(const IntRep & bit_string);

/** @} */

struct Ops_IntInterval
{
   /** @name Arithmetic operations
       @{ */
   static Value* Neg(const IntInterval* x);
   static Value* Add(const IntInterval* x, const IntInterval* y, const IntInterval* c);
   static Value* CAdd(const IntInterval* x, const IntInterval* y, const IntInterval* c);
   static Value* Sub(const IntInterval* x, const IntInterval* y, const IntInterval* c);
   static Value* CSub(const IntInterval* x, const IntInterval* y, const IntInterval* c);
   static Value* UMul(const IntInterval* x, const IntInterval* y);
   static Value* SMul(const IntInterval* x, const IntInterval* y) {
      return SMul_Size(x,y,x->SizeInBits() + y->SizeInBits());
   }
   static Value* Mul_Trunc(const IntInterval* x, const IntInterval* y) {
      Size size_in_bits = x->SizeInBits();
      assert(size_in_bits == y->SizeInBits());
      // In the concrete semantics, it doesn't matter whether we use signed or
      // unsigned multiplication to implement this method, but using signed
      // multiplication improves precision in the abstract semantics. This is
      // because the signed interpretation of a bitstring is always smaller than
      // or equal in magnitude to the unsigned interpretation, so this reduces
      // the scaling up of the intervals.
      return SMul_Size(x,y,size_in_bits);
   }
   /** Version of SMul that takes an argument, @a size_in_bits, that determines the size of the result */
   static Value* SMul_Size(const IntInterval* x, const IntInterval* y, Size size_in_bits);
   static Value* UDiv(const IntInterval* x, const IntInterval* y);
   static Value* SDiv(const IntInterval* x, const IntInterval* y);
   static Value* UMod(const IntInterval* x, const IntInterval* y);
   static Value* SMod(const IntInterval* x, const IntInterval* y);
   /** @} */

   /** @name Bitwise operations 
       @{ */
   static Value* Not(const IntInterval* x);
   static Value* ZExt(const IntInterval* x, const Size& n);
   static Value* SExt(const IntInterval* x, const Size& n);
   static Value* LShift(const IntInterval* x, const IntInterval* y);
   static Value* RShift(const IntInterval* x, const IntInterval* y);
   static Value* RShiftA(const IntInterval* x, const IntInterval* y);
   static Value* And(const IntInterval* x, const IntInterval* y);
   static Value* Or(const IntInterval* x, const IntInterval* y);
   static Value* XOr(const IntInterval* x, const IntInterval* y);
   static Value* Select(const IntInterval* x, const Size& m, const Size& n);
   static Value* Conc(const IntInterval* x, const IntInterval* y);
   static Value* Repeat(const IntInterval* x, const Size& n);
   /** @} */

   /** @name Integer comparison operations
       @{ */
   static Value* Eq(const IntInterval* x, const IntInterval* y);
   static Value* NEq(const IntInterval* x, const IntInterval* y);
   static Value* SLT(const IntInterval* x, const IntInterval* y);
   static Value* SLE(const IntInterval* x, const IntInterval* y);
   static Value* SGE(const IntInterval* x, const IntInterval* y);
   static Value* SGT(const IntInterval* x, const IntInterval* y);
   static Value* ULT(const IntInterval* x, const IntInterval* y);
   static Value* ULE(const IntInterval* x, const IntInterval* y);
   static Value* UGE(const IntInterval* x, const IntInterval* y);
   static Value* UGT(const IntInterval* x, const IntInterval* y);
   /** @} */

   /** @name Conversion operations
       @{ */
   static Value* SToF(const IntInterval* x, const Size& m, const Size& n);
   static Value* UToF(const IntInterval* x, const Size& m, const Size& n);
   /** @} */

   /** @name
       @{ */
   static Value* If(const IntInterval* x, const Value* y, const Value* z);
   static Value* B2N(const IntInterval* x);
   static Value* Exp2(const IntInterval* x);
   static Value* ILog2(const IntInterval* x);
   /** @} */

   /** @name Restriction
       @{ */
   static Value* Restrict_NEq(const IntInterval* x, const IntInterval* y);
   static Value* Restrict_SLT(const IntInterval* restr, const IntInterval* other);
   static Value* Restrict_SLE(const IntInterval* restr, const IntInterval* other);
   static Value* Restrict_SGE(const IntInterval* restr, const IntInterval* other);
   static Value* Restrict_SGT(const IntInterval* restr, const IntInterval* other);
   static Value* Restrict_ULT(const IntInterval* restr, const IntInterval* other);
   static Value* Restrict_ULE(const IntInterval* restr, const IntInterval* other);
   static Value* Restrict_UGE(const IntInterval* restr, const IntInterval* other);
   static Value* Restrict_UGT(const IntInterval* restr, const IntInterval* other);
   /** @} */

   /** @name Reverse operations
       @{ */
   static Value* RevSMul(const IntInterval* r, const IntInterval* f, const Size& result_size);
   static Value* RevUMul(const IntInterval* r, const IntInterval* f, const Size& result_size);
   static Value* RevLShift1(const IntInterval* r, const IntInterval* y);
   static Value* RevAnd(const IntInterval* r, const IntInterval* y);
   static Value* RevOr(const IntInterval* r, const IntInterval* y);
   static Value* RevXOr(const IntInterval* r, const IntInterval* y);
   static Value* RevSelect(const IntInterval* r, const Size& k, const Size& m);
   /** @} */

   /** @name Set operations
       @{ */
   static bool Overlaps(const IntInterval* x, const IntInterval* y);
   static bool Includes(const IntInterval* x, const IntInterval* y);
   static Value* LUB(const IntInterval* x, const IntInterval* y);
   static Value* GLB(const IntInterval* x, const IntInterval* y);
   /** @} */

   /** @name Widening and narrowing
       @{ */
   static Value* Widening(const IntInterval* x, const IntInterval* y);
   static Value* Narrowing(const IntInterval* x, const IntInterval* y);
   /** @} */
};

/** IntegerDomain that creates interval integers
   @note All returned pointers should be deleted by the caller */
class IntervalIntDomain : public IntegerDomain
{
public:
   /** @note The returned pointer should be deleted by the caller */
   virtual Value* CreateInteger(const Size& size_in_bits) const;

   /** @note The returned pointer should be deleted by the caller */
   virtual Value* CreateInteger(const Size& size_in_bits, int value) const;

   /** @note The returned pointer should be deleted by the caller */
   virtual Value* CreateInteger(const Size& size_in_bits, const Integer& value) const;

   /** @note The returned pointer should be deleted by the caller */
   virtual Value* CreateInteger(const Size& size_in_bits, int lower, int upper) const;

   /** @note The returned pointer should be deleted by the caller */
   virtual Value* CreateInteger(const Size& size_in_bits, 
      const Integer& lower, const Integer& upper) const;
};

#endif   // #ifndef INTINTERVAL_H_INCLUDED
