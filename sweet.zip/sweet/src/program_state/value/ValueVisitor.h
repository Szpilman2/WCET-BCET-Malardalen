#ifndef VALUEVISITOR_H_INCLUDED
#define VALUEVISITOR_H_INCLUDED

class Value;
class BottomValue;
class TopValue;
class Bitstring;
class IntInterval;
class ClpValue;
class SymbPointer;
class SymbIntervalPtrSet;
class SymbClpPtrSet;
class FloatIntervalVal;
class OneFloatInterval8_23;
class OneFloatInterval11_52;
class ReadValue;

class ValueVisitor
{
public:
   virtual ~ValueVisitor() {}
	
   virtual void VisitValue(const Value& value) = 0;

   virtual void VisitBottomValue(const BottomValue& value);

   virtual void VisitTopValue(const TopValue& value);

   virtual void VisitBitstring(const Bitstring& value);

   virtual void VisitIntInterval(const IntInterval& value);

   virtual void VisitClpValue(const ClpValue& value);

   virtual void VisitSymbPointer(const SymbPointer& value);

   virtual void VisitSymbIntervalPtrSet(const SymbIntervalPtrSet& value);

   virtual void VisitSymbClpPtrSet(const SymbClpPtrSet& value);

   virtual void VisitFloatIntervalVal(const FloatIntervalVal& value);

   virtual void VisitOneFloatInterval8_23(const OneFloatInterval8_23& value);

   virtual void VisitOneFloatInterval11_52(const OneFloatInterval11_52& value);

   virtual void VisitReadValue(const ReadValue& value);
};

#endif   // #ifndef VALUEVISITOR_H_INCLUDED
