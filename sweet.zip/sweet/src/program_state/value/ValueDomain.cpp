#include "ValueDomain.h"
#include "IntegerDomain.h"
#include "FloatDomain.h"
#include "BottomValue.h"
#include "TopValue.h"
#include "OpPolicies.h"
#include "program_state/memory/MemoryDomain.h"

ValueDomain::~ValueDomain()
{
   delete integer_domain;
   delete memory_domain;
   delete float_domain;
   delete op_policies;
}

void ValueDomain::SetIntegerDomain(IntegerDomain* integer_domain)
{ 
   delete ValueDomain::integer_domain; 
   ValueDomain::integer_domain = integer_domain; 
}

void ValueDomain::SetMemoryDomain(MemoryDomain* memory_domain)
{ 
   delete ValueDomain::memory_domain; 
   ValueDomain::memory_domain = memory_domain; 
}

void ValueDomain::SetFloatDomain(FloatDomain* float_domain)
{ 
   delete ValueDomain::float_domain; 
   ValueDomain::float_domain = float_domain; 
}

void ValueDomain::SetOpPolicies(OpPolicies* op_policies)
{ 
   delete ValueDomain::op_policies; 
   ValueDomain::op_policies = op_policies; 
}

Value * ValueDomain::CreateTopValue(const Size & size_in_bits) const
{
   return new TopValue(size_in_bits);
}

Value * ValueDomain::CreateBottomValue(const Size & size_in_bits) const
{
   return new BottomValue(size_in_bits);
}

Value * ValueDomain::CreateUninitializedValue(const Size &size_in_bits) const
{
   return CreateTopValue(size_in_bits);
}
