#ifndef SYMBPOINTERSET_H_INCLUDED
#define SYMBPOINTERSET_H_INCLUDED

#include "SymbPointer.h"
#include "../memory/DataPatch.h"
#include <map>
#include <list>
#include <cassert>

class DataPatch;
typedef std::list<DataPatch> PatchList;
class Integer;
class FrameColl;

/** This template should be specialized for each subclass of SymbPointerSet */
template <typename Subclass> 
class SymbPtrSetSubclassTraits 
{
public:
   /** This typedef should be defined in the specialization as the type used as offset */
   typedef void OffsetType;

   /** Should be defined in the specialization to do a dynamic cast of @a value to
      @a Subclass, returning 0 in case of failure */
   static const Subclass* CastToSubclass(const Value* value);

   /** Should be defined in the specialization to do a dynamic cast of @a value to
      the OffsetType, and to return 0 in case of failure */
   static const OffsetType* CastToOffsetType(const Value* value);
};

/** Template which implements the SymbPointer interface.
   To be inherited from; the template parameter @a Subclass is the implementing type. */
template <typename Subclass>
class SymbPointerSet : public SymbPointer
{
public:
   typedef SymbPtrSetSubclassTraits<Subclass> SubclassTraits;
   typedef typename SubclassTraits::OffsetType OffsetType;

   /** Create a top symbolic pointer */
   SymbPointerSet(const Size & size_in_bits);

   SymbPointerSet(const Size & size_in_bits, const Symbol & symbol, const Integer & offset);

   /** @pre @p symbol_to_offset is non-empty
       @post @p symbol_to_offset is empty */
   SymbPointerSet(const Size & size_in_bits, SymbolToOffset & symbol_to_offset);

   SymbPointerSet(const SymbPointerSet & copy_from);

   virtual ~SymbPointerSet();

   /** Make a deep copy of this pointer */
   virtual SymbPointerSet * Copy() const = 0;

   /** @copydoc SymbPointer::IsEqual(const Value*) const */
   virtual bool IsEqual(const Value * val) const;
   
   /** @copydoc SymbPointer::IsTop */
   virtual bool IsTopSymbPointer() const { return is_top? (assert(symbol_to_offset.empty()), true) : false; }

   /** @copydoc SymbPointer::GetSymbols(SymbolColl&) const */
   virtual void GetSymbols(SymbolColl & symbols) const;

   /** @copydoc SymbPointer::GetSymbolOffsetPairs(SymbolOffsetPairColl&) const */
   virtual void GetSymbolOffsetPairs(SymbolOffsetPairColl & sops) const;

   /** @copydoc SymbPointer::GetSymbolToOffset() const */
   virtual SymbolToOffset * GetSymbolToOffset() const;

   /** @copydoc SymbPointer::IncludesSymbol(const Symbol&) const */
   virtual bool IncludesSymbol(const Symbol & symbol) const {return symbol_to_offset.find(symbol) != symbol_to_offset.end();}

   /** @copydoc SymbPointer::GetOffsetOfSymbol(const Symbol&) const */
   virtual Value * GetOffsetOfSymbol(const Symbol & symbol) const;

	/** @copydoc SymbPointer::NrOfSymbols() const */
   virtual unsigned NrOfSymbols() const;

   virtual bool IsSingleElem() const;

   /** @copydoc SymbPointer::ReduceToPointInsideFrames(const FrameColl&,Size,bool&) const */
   virtual Value* ReduceToPointInsideFrames(const FrameColl& frames, Size offset_margin, bool& reduced) const;

   virtual std::ostream & Print(std::ostream & o = std::cout) const;

public:  // TODO 2012-03-27: Better access control
   typedef std::map<Symbol, const OffsetType *, Symbol::SetSymbolComparator> SymbolToOffsetType;

   SymbolToOffsetType symbol_to_offset;

   bool is_top;
};

template <typename Subclass>
struct Ops_SymbPointerSet
{
   typedef typename Subclass::OffsetType OffsetType;

   /** @name Arithmetic operations
       @{ */
   static Value* Add(const Subclass* x, const OffsetType* y, const OffsetType* c);
   static Value* Add(const OffsetType* x, const Subclass* y, const OffsetType* c);
   static Value* CAdd(const Subclass* x, const OffsetType* y, const OffsetType* c);
   static Value* CAdd(const OffsetType* x, const Subclass* y, const OffsetType* c);
   static Value* Sub(const Subclass* x, const OffsetType* y, const OffsetType* c);
   static Value* Sub(const Subclass* x, const Subclass* y, const OffsetType* c);
   static Value* Sub_Unsafe(const Subclass* x, const Subclass* y, const OffsetType* c);
   static Value* CSub(const Subclass* x, const OffsetType* y, const OffsetType* c);
   static Value* CSub(const Subclass* x, const Subclass* y, const OffsetType* c);
   /** @} */

   /** @name Bitwise operations
       @{ */
   static Value* ZExt(const Subclass* x, const Size& n);
   /** @} */

   /** @name Integer comparison operations, safe versions
       @{ */
   static Value* Eq(const Subclass* x, const Subclass* y);
   static Value* NEq(const Subclass* x, const Subclass* y);
   static Value* ULT(const Subclass* x, const Subclass* y);
   static Value* UGE(const Subclass* x, const Subclass* y);
   static Value* UGT(const Subclass* x, const Subclass* y);
   static Value* ULE(const Subclass* x, const Subclass* y);
   /** @} */

   /** @name Integer comparison operations, unsafe versions
       @{ */
   static Value* ULT_Unsafe(const Subclass* x, const Subclass* y);
   static Value* UGE_Unsafe(const Subclass* x, const Subclass* y);
   static Value* UGT_Unsafe(const Subclass* x, const Subclass* y);
   static Value* ULE_Unsafe(const Subclass* x, const Subclass* y);
   /** @} */

   /** @name Set operations
       @{ */
   static bool Overlaps(const Subclass* x, const Subclass* y);
   static bool Includes(const Subclass* x, const Subclass* y);
   static Value* LUB(const Subclass* x, const Subclass* y);
   static Value* GLB(const Subclass* x, const Subclass* y);
   /** @} */

   /** @name Restriction
       @{ */
   static Value* Restrict_NEq(const Subclass* x, const Subclass* y);
   static Value* Restrict_ULT(const Subclass* restr, const Subclass* other);
   static Value* Restrict_ULE(const Subclass* restr, const Subclass* other);
   static Value* Restrict_UGE(const Subclass* restr, const Subclass* other);
   static Value* Restrict_UGT(const Subclass* restr, const Subclass* other);
   /** @} */

   /** @name Widening and narrowing
       @{ */
   static Value* Widening(const Subclass* x, const Subclass* y);
   static Value* Narrowing(const Subclass* x, const Subclass* y);
   /** @} */

private:
   template <Value* (Value::*RestrictMethod)(const Value*) const>
   static Value* Restrict(const Subclass* restr, const Subclass* other);
};

#endif   // #ifndef SYMBPOINTERSET_H_INCLUDED
