#ifndef FLOATDOMAIN_H_INCLUSION_GUARD
#define FLOATDOMAIN_H_INCLUSION_GUARD

#include <limits>

class Value;
template <typename> class EInt;
typedef EInt<unsigned long long> Size;

/** Factory class that creates floating-point Values
   @note All returned pointers should be deleted by the caller */
class FloatDomain
{
public:
   virtual ~FloatDomain() {}
   
   /** Create a TOP float value
      @note The returned pointer should be deleted by the caller */
   virtual Value* CreateFloat(const Size & exp_size, const Size & frac_size) const = 0;

   /** Create a float value
      @param exp_size The size in bits of the exponent part of the representing bitstring
      @param frac_size The size in bits of the fraction part of the representing bitstring
      @param is_NaN Sets whether or not the float is NaN
      @param value The value; will be ignored if @a is_NaN is true
      @note The returned pointer should be deleted by the caller */
   virtual Value * CreateFloat(const Size & exp_size, const Size & frac_size,
      bool is_NaN, long double value = std::numeric_limits<long double>::quiet_NaN()) const = 0;

   /** Create a float interval value
      @param exp_size The size in bits of the exponent part of the representing bitstring
      @param frac_size The size in bits of the fraction part of the representing bitstring
      @param incl_NaNaNs Sets whether or not the created value should include something other than NaN
      @param incl_NaN Sets whether or not the created value should include NaN
      @param l The lower bound of the interval; will be ignored if @a incl_NaNaNs is false
      @param u The upper bound of the interval; will be ignored if @a incl_NaNaNs is false
      @note The returned pointer should be deleted by the caller */
   virtual Value * CreateFloat(const Size & exp_size, const Size & frac_size, 
      bool incl_NaNaNs, bool incl_NaN,
      long double l = std::numeric_limits<long double>::quiet_NaN(),
      long double u = std::numeric_limits<long double>::quiet_NaN()) const = 0;
};

#endif   // #ifndef FLOATDOMAIN_H_INCLUSION_GUARD
