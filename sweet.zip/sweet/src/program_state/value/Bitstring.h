#ifndef BITSTRINGSET_H_INCL
#define BITSTRINGSET_H_INCL

#include "Value.h"
#include "tools/integer_utilities.h"

class Bitstring : public Value
{
public:
   Bitstring(const Size& size_in_bits) : Value(size_in_bits) {}

   /** @copydoc Value::AsBitstring() const */
   virtual const Bitstring* AsBitstring() const { return this; }

   /** @copydoc Value::AcceptVisitor(ValueVisitor*) const */
   virtual void AcceptVisitor(ValueVisitor* visitor) const { visitor->VisitBitstring(*this); }

   /** Returns whether this value includes all possible bitstrings
       @note This differs from Value::IsTop() in that it excludes symbolic pointer values */
   virtual bool IsTopBitstring() const = 0;

   Value* FExclUpperBelow() const;

   Value* FInclUpperBelow() const;

   Value* FInclLowerAbove() const;

   Value* FExclLowerAbove() const;
};

/** Returns whether val is both top and has infinite precision */
inline bool IsInfAndTopBitstring(const Bitstring& val) { return val.SizeInBits().IsInfinity() && val.IsTopBitstring(); }

template <typename IntRep>
IntRep SmallestRepresentableUnsigned(const Bitstring& val)
{ return ::SmallestRepresentableUnsigned<IntRep>(val.SizeInBits().AsBaseIntType()); }

template <typename IntRep>
IntRep LargestRepresentableUnsigned(const Bitstring& val)
{ return ::LargestRepresentableUnsigned<IntRep>(val.SizeInBits().AsBaseIntType()); }

template <typename IntRep>
IntRep SmallestRepresentableSigned(const Bitstring& val)
{ return ::SmallestRepresentableSigned<IntRep>(val.SizeInBits().AsBaseIntType()); }

template <typename IntRep>
IntRep LargestRepresentableSigned(const Bitstring& val)
{ return ::LargestRepresentableSigned<IntRep>(val.SizeInBits().AsBaseIntType()); }

template <typename IntRep>
IntRep RepresentableRangeWidth(const Bitstring& val)
{
   Size size_in_bits = val.SizeInBits();
   assert(!size_in_bits.IsInfinity());
   IntRep rw(1);
   rw <<= size_in_bits.AsBaseIntType();
   return rw;
}

#endif   // ifndef BITSTRINGSET_H_INCL
