/* $Id: IntRangeTpl.h 1123 2009-10-05 13:32:58Z lkg02 $ */
#ifndef INTRANGETPL_H_INCLUDED
#define INTRANGETPL_H_INCLUDED

#include "tools/integer_utilities.h"
#include <iostream>
#include <cassert>
#include <stdint.h>

/** \class
   Represents an integer range (interval). Intervals can be extended,
   can decide if it overlaps another interval etc.
   */
template <typename IntRep>
class IntRangeTpl
{
public:
   IntRangeTpl() {}

   /** Construct a new integer range with lower bound l and upper bound u
      \pre l \< u
      */
   IntRangeTpl(const IntRep & l, const IntRep & u) : _l(l), _u(u) {}

   /// Destroys this integer range.
   virtual ~IntRangeTpl() {}

   /// Returns the lower bound of the interval
   const IntRep & L() const { return _l; }

   IntRep & L() {return _l;}

   /// Returns the upper bound of the interval
   const IntRep & U() const { return _u; }

   IntRep & U() {return _u;}

   /// Returns a pointer to a new integer range that is a duplicate of this integer range.
   IntRangeTpl* Copy() const { return new IntRangeTpl(_l, _u); }

   bool operator ==(const IntRangeTpl & other) const {return _l == other._l && _u == other._u;}
   bool operator !=(const IntRangeTpl & other) const {return !(*this == other);}

   /// Checks if this integer range includes a certain point
   /// \param i The integer to be checked
   /// \return True if the point is included in the range.
   bool Includes(const IntRep & i) const { return i >= _l && i <= _u; }

   /// Checks if this integer range includes another range
   /// \param other The integer range to be checked
   /// \return True if the union between this and the other range is the same as this range, else false
   bool Includes(const IntRangeTpl* other) const { return other->L() >= _l && other->U() <= _u; }

   /// Checks if this integer range overlaps antoher integer range
   /// \param other The integer range to be checked
   /// \return True if the intersection between this and the other is not empty, else false
   bool Overlaps(const IntRangeTpl* other) const { return !(other->U() < _l || other->L() > _u); }

   /// Merges this integer interval with another
   /// \param other The integer range to merge with
   /// \return A new single integer range that includes this and the other interval ranges
   IntRangeTpl* Merge(const IntRangeTpl* other) const { return new IntRangeTpl(std::min(_l, other->L()),std::max(_u,other->U())); }

   /// Extends this integer interval to include another
   /// \param other The integer range to merge with
   /// \return A new single integer range that includes this and the other interval ranges
   void ExtendWith(const IntRangeTpl* other) { _l = std::min(_l, other->L()); _u = std::max(_u,other->U()); }

   ///  \return The number of integers that this integer range represents
   IntRep Cover() const {assert(_l <= _u); return _u - _l + 1;}

   /// Prints this integer range as text to a stream
   std::ostream & Print(std::ostream & o = std::cout) const {
      if (_l == _u)
         return o << _l;
      else
         return o << '[' << _l << ".." << _u << ']';
   }

private:
   // To hold the upper and lower values
   IntRep _l;
   IntRep _u;
};

// Alternative printing function
template <typename IntRep>
std::ostream &operator << (std::ostream &o, const IntRangeTpl<IntRep> &r) {return r.Print(o);}

#endif   // #ifndef INTRANGETPL_H_INCLUDED
