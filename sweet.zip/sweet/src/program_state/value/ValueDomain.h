#ifndef VALUEDOMAIN_H_INCLUSION_GUARD
#define VALUEDOMAIN_H_INCLUSION_GUARD

class IntegerDomain;
class MemoryDomain;
class FloatDomain;
class Value;
class OpPolicies;
template <typename> class EInt;
typedef EInt<unsigned long long> Size;

/** Factory class used to create values, for example, integers, floats, and pointers */
class ValueDomain
{ 
public:
   ValueDomain() : integer_domain(0), memory_domain(0), float_domain(0), op_policies(0) {}

   virtual ~ValueDomain();

   /** Set the integer domain. The pointer is a gift from the caller. */
   void SetIntegerDomain(IntegerDomain* integer_domain);

   /** Set the memory domain. The pointer is a gift from the caller. */
   void SetMemoryDomain(MemoryDomain* memory_domain);

   /** Set the float domain. The pointer is a gift from the caller. */
   void SetFloatDomain(FloatDomain* float_domain);

   /** Set the operation policies. The pointer is a gift from the caller. */
   void SetOpPolicies(OpPolicies* op_policies);

   /** Get access to the integer domain. The returned pointer should @e not be deleted. */
   IntegerDomain* GetIntegerDomain() const { return integer_domain; }

   /** Get access to the memory domain. The returned pointer should @e not be deleted. */
   MemoryDomain* GetMemoryDomain() const { return memory_domain; }

   /** Get access to the float domain. The returned pointer should @e not be deleted. */
   FloatDomain* GetFloatDomain() const { return float_domain; }

   /** Get access to the operation policies. The returned pointer should @e not be deleted. */
   OpPolicies* GetOpPolicies() const { return op_policies; }

   /** Create a top value
      @note The returned pointer should be deleted by the caller */
   virtual Value * CreateTopValue(const Size & size_in_bits) const;

   /** Create a bottom value
      @note The returned pointer should be deleted by the caller */
   virtual Value * CreateBottomValue(const Size & size_in_bits) const;

   /** Create an uninitialized value. Most often this will be a top value.
      @note The returned pointer should be deleted by the caller */
   virtual Value * CreateUninitializedValue(const Size & size_in_bits) const;

private:
   IntegerDomain* integer_domain;

   MemoryDomain* memory_domain;

   FloatDomain* float_domain;

   OpPolicies* op_policies;
};

#endif   // #ifndef VALUEDOMAIN_H_INCLUSION_GUARD
