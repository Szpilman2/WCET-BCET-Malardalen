#include "ValueVisitor.h"
#include "BottomValue.h"
#include "TopValue.h"
#include "IntInterval.h"
#include "clp/ClpValue.h"
#include "SymbIntervalPtrSet.h"
#include "clp/SymbClpPtrSet.h"
#include "FloatIntervalVal.h"
#include "ReadValue.h"

void ValueVisitor::VisitBottomValue(const BottomValue& value)
{
   VisitValue(value);
}

void ValueVisitor::VisitTopValue(const TopValue& value)
{
	VisitValue(value);
}

void ValueVisitor::VisitBitstring(const Bitstring& value)
{
   VisitValue(value);
}

void ValueVisitor::VisitIntInterval(const IntInterval& value)
{
   VisitBitstring(value);
}

void ValueVisitor::VisitClpValue(const ClpValue& value) { VisitBitstring(value); }

void ValueVisitor::VisitSymbPointer(const SymbPointer& value)
{
   VisitValue(value);
}

void ValueVisitor::VisitSymbIntervalPtrSet(const SymbIntervalPtrSet& value)
{
   VisitSymbPointer(value);
}

void ValueVisitor::VisitSymbClpPtrSet(const SymbClpPtrSet& value) { VisitSymbPointer(value); }

void ValueVisitor::VisitFloatIntervalVal(const FloatIntervalVal& value)
{
   VisitBitstring(value);
}

void ValueVisitor::VisitOneFloatInterval8_23(const OneFloatInterval8_23& value)
{
   VisitFloatIntervalVal(value);
}

void ValueVisitor::VisitOneFloatInterval11_52(const OneFloatInterval11_52& value)
{
   VisitFloatIntervalVal(value);
}

void ValueVisitor::VisitReadValue(const ReadValue& value)
{
   VisitValue(value);
}
