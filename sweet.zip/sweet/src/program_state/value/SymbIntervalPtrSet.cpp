#include "SymbIntervalPtrSet.h"
#include "SymbPointerSet.inl"
#include "IntInterval.h"
#include "../memory/FrameColl.h"

template class SymbPointerSet<SymbIntervalPtrSet>;

class SymbIntervalPtrSet::LazyIterator : public SopIterator
{
   const SymbIntervalPtrSet& ptr;
   SymbolToOffsetType::const_iterator iter, end;
   unsigned long long offset, u;

public:
   LazyIterator(const SymbIntervalPtrSet& ptr)
      : ptr(ptr)
   {
      iter = ptr.symbol_to_offset.begin();
      end = ptr.symbol_to_offset.end();
      if (iter != end) {
         offset = iter->second->LAsUnsigned().As<unsigned long long>();
         u = iter->second->UAsUnsigned().As<unsigned long long>();
      }
   }

   /** @copydoc SopIterator::IsSingleton */
   virtual bool IsSingleton() {
      return ptr.symbol_to_offset.size() == 1 &&
         ptr.symbol_to_offset.begin()->second->IsSingleElem();
   }

   /** @copydoc SopIterator::AtEnd */
   virtual bool AtEnd() { return iter == end; }

   /** @copydoc SopIterator::GetNext */
   virtual SymbolOffsetPair GetNext() {
      assert(iter != end);
      SymbolOffsetPair sop(iter->first, offset);
      if (offset < u) ++offset;
      else {
         ++iter;
         if (iter != end) {
            offset = iter->second->LAsUnsigned().As<unsigned long long>();
            u = iter->second->UAsUnsigned().As<unsigned long long>();
         }
      }
      return sop;
   }
};

SopIterator* SymbIntervalPtrSet::GetIterator_Private() const { return new LazyIterator(*this); }

template struct Ops_SymbPointerSet<SymbIntervalPtrSet>;
