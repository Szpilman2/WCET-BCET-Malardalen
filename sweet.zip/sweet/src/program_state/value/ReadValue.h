#ifndef READVALUE_H_INCLUDED
#define READVALUE_H_INCLUDED

#include "Value.h"
#include <memory>
#include <iostream>

class Frame;

class ReadValue : public Value
{
public:
   /** Create a new value from @a frame. If @a frame is 0, a bottom value is created,
      otherwise a ReadValue is created. 
      @note The pointer is a gift to the function */
   static Value* Create(Frame* frame);

   /** Constructs a new ReadValue. The memory pointed to by @a data is a gift from the caller. */
   ReadValue(Frame * data);

   ReadValue(const ReadValue & other);

   virtual ~ReadValue();

   ReadValue * Copy() const {return new ReadValue(*this);}

   ReadValue & operator =(const ReadValue & other);

   /** Gives access to the frame used to represent the value */
   const Frame * Data() const { return _data; }

   /** @copydoc Value::IsEqual(const Value*) const */
   bool IsEqual(const Value * other) const;

   virtual void AcceptVisitor(ValueVisitor * visitor) const
      {visitor->VisitReadValue(*this);}

   /** Dynamic cast */
   virtual const ReadValue* AsReadValue() const {return this;}

   virtual Size SizeInBits() const;

   /** Does this ReadValue evaluate to bottom? */
   virtual bool IsBottom() const;

   /** Does this ReadValue evaluate to top? */
   virtual bool IsTop() const;

   virtual bool IsSingleElem() const;

   Value* Fuse() const;

   virtual Value* FExclUpperBelow() const {return UnOper(&Value::FExclUpperBelow);}

   virtual Value* FInclUpperBelow() const {return UnOper(&Value::FInclUpperBelow);}

   virtual Value* FInclLowerAbove() const {return UnOper(&Value::FInclLowerAbove);}

   virtual Value* FExclLowerAbove() const {return UnOper(&Value::FExclLowerAbove);}

   std::ostream & Print(std::ostream & o = std::cout) const;

public:
   Value* UnOper(Value* (Value::*un_oper)() const) const;

   Frame * _data;
};

struct Ops_ReadValue
{
   /** @name Unary operation templates
       @{ */
   template <Value* (Value::*Op)() const>
   static Value* UnOp(const ReadValue* x)
   {
      std::unique_ptr<Value> x_(x->Fuse());
      return ((*x_).*Op)();
   }
   /** @} */

   /** @name Binary operation templates
       @{ */

   template <Value* (Value::*Op)(const Value*) const>
   static Value* BinOp_RV(const ReadValue* x, const Value* y)
   {
      std::unique_ptr<Value> x_(x->Fuse());
      return ((*x_).*Op)(y);
   }

   template <Value* (Value::*Op)(const Value*) const>
   static Value* BinOp_VR(const Value* x, const ReadValue* y)
   {
      std::unique_ptr<Value> y_(y->Fuse());
      return (x->*Op)(y_.get());
   }

   template <Value* (Value::*Op)(const Size&) const>
   static Value* BinOp_RS(const ReadValue* x, const Size& y)
   {
      std::unique_ptr<Value> x_(x->Fuse());
      return ((*x_).*Op)(y);
   }

   template <bool (Value::*Op)(const Value*) const>
   static bool BinOpBool_RV(const ReadValue* x, const Value* y)
   {
      std::unique_ptr<Value> x_(x->Fuse());
      return ((*x_).*Op)(y);
   }

   template <bool (Value::*Op)(const Value*) const>
   static bool BinOpBool_VR(const Value* x, const ReadValue* y)
   {
      std::unique_ptr<Value> y_(y->Fuse());
      return (x->*Op)(y_.get());
   }

   /** @} */

   /** @name Ternary operation templates
       @{ */

   template <Value* (Value::*Op)(const Value*, const Value*) const>
   static Value* TernOp_RVV(const ReadValue* x, const Value* y,  const Value* z)
   {
      std::unique_ptr<Value> x_(x->Fuse());
      return ((*x_).*Op)(y, z);
   }

   template <Value* (Value::*Op)(const Value*, const Value*) const>
   static Value* TernOp_VRV(const Value* x, const ReadValue* y, const Value* z)
   {
      std::unique_ptr<Value> y_(y->Fuse());
      return (x->*Op)(y_.get(), z);
   }

   template <Value* (Value::*Op)(const Value*, const Value*) const>
   static Value* TernOp_VVR(const Value* x, const Value* y, const ReadValue* z)
   {
      std::unique_ptr<Value> z_(z->Fuse());
      return (x->*Op)(y, z_.get());
   }

   template <Value* (Value::*Op)(const Value*, const Size&) const>
   static Value* TernOp_RVS(const ReadValue* x, const Value* y, const Size& z)
   {
      std::unique_ptr<Value> x_(x->Fuse());
      return ((*x_).*Op)(y, z);
   }

   template <Value* (Value::*Op)(const Value*, const Size&) const>
   static Value* TernOp_VRS(const Value* x, const ReadValue* y, const Size& z)
   {
      std::unique_ptr<Value> y_(y->Fuse());
      return (x->*Op)(y_.get(), z);
   }

   template <Value* (Value::*Op)(const Size&, const Size&) const>
   static Value* TernOp_RSS(const ReadValue* x, const Size& y, const Size& z)
   {
      std::unique_ptr<Value> x_(x->Fuse());
      return ((*x_).*Op)(y, z);
   }

   /** @} */

   /** @name Bitwise operations
       @{ */
   static Value* Not(const ReadValue* x);
   static Value* ZExt(const ReadValue* x, const Size& n);
   static Value* Select(const ReadValue* x, const Size& m, const Size& n);
   static Value* Conc_RV(const ReadValue* x, const Value* y);
   static Value* Conc_VR(const Value* x, const ReadValue* y);
   static Value* Conc_RR(const ReadValue* x, const ReadValue* y);
   /** @} */

   /** @name Set operations
       @{ */
   static Value* LUB_RR(const ReadValue* x, const ReadValue* y);
   static Value* GLB_RR(const ReadValue* x, const ReadValue* y);
   /** @} */

   /** @name Reverse operations
       @{ */
   static Value* RevSelect(const ReadValue* r, const Size& k, const Size& m);
   /** @} */
};

#endif // #ifndef READVALUE_H_INCLUDED
