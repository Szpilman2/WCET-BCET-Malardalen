#ifndef PROGRAMCOUNTERAE_H_INCLUDED
#define PROGRAMCOUNTERAE_H_INCLUDED

#include <vector>
#include "ProgramPointECFG.h"
#include "ProgramCounterECFG.h"
#include "ae/CRecorderHolderSet.h"
#include <memory>

// =======================================================
// =======================================================
// ProgramCounterECFG_AE -
// An ECFG_AE program counter holds an ECFG_AE program point (which holds
// an ECFGNode) and a recoorder holder set (and a server for
// updating, copying, ...) this set. The recorder holder set will 
// include a scope index vector.
// =======================================================
// =======================================================
class ProgramCounterECFG_AE : public ProgramCounterECFG
{
public:
  // To create a program counter from an already existing one
  ProgramCounterECFG_AE(const CGenericProgram * program, unique_ptr<ProgramPointECFG> pp,
                        CRecorderHolderSet * rhs, CRecorderHolderSetServer * rhs_server);
  // To delete the program counter.
  virtual ~ProgramCounterECFG_AE(void);

  // To make a deep copy of the program counter
  ProgramCounterECFG_AE * Copy(void) const;

  /** @return @c true if this program counter is equal to @a pc2, otherwise @c false */
  virtual bool IsEqual(const ProgramCounter* other_pc) const;

  // To get the current recorder holder set and server
  const CRecorderHolderSet * GetRecorderHolderSet(void) const;
  const CRecorderHolderSetServer * GetRecorderHolderSetServer(void) const;

  // To update the PC. Will indirectlty update the included recorder set. 
  void UpdateWithProgramStart(void); // No pp given, use the one given at creation
  void UpdateWithNewProgramPoint(unique_ptr<ProgramPoint> new_pp);
  // void UpdateWithProgramExit(void);

  // Print information about this program point to the output stream os
  virtual std::ostream & Print(std::ostream & os = std::cout) const;
  
  // To check what subtype the class is
  virtual bool IsProgramCounterECFG_AE() const { return true; }
  virtual const ProgramCounterECFG_AE* AsProgramCounterECFG_AE() const { return this; }

protected:

  // Functions that must be implemented by subclasses
  bool AreMergable(const ProgramCounterECFG * other_pc) const;
  ProgramCounterECFG * LUB(const ProgramCounterECFG * other_pc) const;
  ProgramCounterECFG * GLB(const ProgramCounterECFG * other_pc) const;

  // Also keeps an ECFG program point, but this is done by parent class

  // To keep track of recorders
  CRecorderHolderSet * _rhs;
  CRecorderHolderSetServer * _rhs_server;
};

#endif   // PROGRAMCOUNTERECFG_AE_H_INCLUDED
