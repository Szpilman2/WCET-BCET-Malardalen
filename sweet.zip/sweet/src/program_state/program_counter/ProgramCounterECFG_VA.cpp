#include "ProgramCounterECFG_VA.h"

using namespace std;

ProgramCounterECFG_VA::
ProgramCounterECFG_VA(const CGenericProgram * program, unique_ptr<ProgramPointECFG> pp)
  : ProgramCounterECFG(program, move(pp))
{
  // Do nothing
}

ProgramCounterECFG_VA::
~ProgramCounterECFG_VA(void)
{
  // Parent delete will delete the program point
}

ProgramCounterECFG_VA *
ProgramCounterECFG_VA::
Copy(void) const
{
  // The program point must also be copied
  unique_ptr<ProgramPointECFG> new_pp(GetProgramPointECFG()->Copy());

  // Create and return the new program counter
  return new ProgramCounterECFG_VA(GetProgram(), move(new_pp));
}

bool 
ProgramCounterECFG_VA::
IsEqual(const ProgramCounter* other_pc) const 
{
  // Check if the other pc is of the same type
  if (!other_pc->IsProgramCounterECFG_VA())
    return false;

  // Else convert the pc to an ecfg pc
  const ProgramCounterECFG_VA* pc1 = other_pc->AsProgramCounterECFG_VA();
  const ProgramCounterECFG_VA* pc2 = this;

   if (pc1->GetProgram() != pc2->GetProgram())
      return false;

   if (!pc1->GetProgramPoint()->IsEqual(pc2->GetProgramPoint()))
      return false;

   return true;
}


bool
ProgramCounterECFG_VA::
AreMergable(const ProgramCounterECFG * bpc) const
{
  if(!bpc->IsProgramCounterECFG_VA()) 
    return false;

  const ProgramCounterECFG_VA * apc = this;
  // If the program counters have different program points they can not be merged
  if (!(apc->GetProgramPoint()->IsEqual(bpc->GetProgramPoint())))
    return false; 
  else
    return true;
}

ProgramCounterECFG * 
ProgramCounterECFG_VA::
LUB(const ProgramCounterECFG * bpc) const
{
  const ProgramCounterECFG_VA * apc = this;
  assert(apc->AreMergable(bpc));
  return apc->Copy();
}


ProgramCounterECFG * 
ProgramCounterECFG_VA::
GLB(const ProgramCounterECFG * bpc) const
{  
  const ProgramCounterECFG_VA * apc = this;
  assert(apc->AreMergable(bpc));
  return apc->Copy();
}

std::ostream & ProgramCounterECFG_VA::Print(std::ostream & os) const
{
  assert(GetProgramPointECFG());
  GetProgramPointECFG()->Print(os);
  return os;
}

