#ifndef PROGRAMPOINT_H_INCLUDED
#define PROGRAMPOINT_H_INCLUDED

#include <memory>
#include <ostream>
#include "program/CGenericStmt.h"
#include "graphs/cfg/CFlowGraphNode.h"

using namespace std;

class ProgramPointECFG;
class ProgramCounter;

// -------------------------------------------------------
// Class hierarchy
//
// ProgramPoint
//   |
//   |-- ProgramPointECFG
// 
// -------------------------------------------------------


// =======================================================
// =======================================================
// ProgramPoint -
// Base class holding functionality neccessary for all program points
// =======================================================
// =======================================================
class ProgramPoint
{
public:
  ProgramPoint(bool is_final=false) : _is_final(is_final) {}
  virtual ~ProgramPoint() {};
  
  /// Make a deep copy of this program point. @note The caller is
  /// responsible for deleting the returned pointer
  virtual ProgramPoint * Copy(void) const = 0;
  
  // Th check if two programpoints are equal
  virtual bool IsEqual(const ProgramPoint * other) const = 0;
  
  // Return the statement at this program point
  virtual const CGenericStmt * GetStmt(void) const = 0;

  // Get the current CFG node
  virtual const CFlowGraphNode * GetFlowGraphNode(void) const = 0;
  
  // Return the program point following this program point. This is
  // not necessarily the next program point in the program flow,
  // since the current program point may be something like a jump
  // statement or a call statement. @note The caller is responsible
  // for deleting the returned pointer.
  virtual ProgramPoint * GetTextualSuccessor() const = 0;
  
  // @return true if this program point is the end of a basic block,
  // false otherwise
  virtual bool IsEndOfBasicBlock() const = 0;
  
  // Returns if program point is a final program point
  inline bool IsFinal() const {return _is_final;}
  virtual std::ostream & Print(std::ostream & os = std::cout) const = 0;
  
  // To get the type of subclass of the program point. Needs to be reimplemented by subclasses.
  virtual bool IsProgramPointECFG() const { return false; }
  virtual const ProgramPointECFG * AsProgramPointECFG() const { assert(0); return NULL; }
  
  // To set and get a backward pointer to the state that wons the PC. Is called
  // at program counter creation and at updates of the program point.
  void SetProgramCounterBackwardPtr(ProgramCounter * pc) { _pc_backward_ptr = pc; }
  const ProgramCounter * GetProgramCounterBackwardPtr(void) const { return _pc_backward_ptr; }

protected:
  
  // To keep track of if the program point has reached it final state
  bool _is_final;

  // Backward pointer to PC owning the PP
  ProgramCounter * _pc_backward_ptr;
};

/// Print information about a program point to the output stream os
inline std::ostream & operator <<(std::ostream & os, const ProgramPoint & pp) {return pp.Print(os);}

#endif   // PROGRAMPOINT_H_INCLUDED
