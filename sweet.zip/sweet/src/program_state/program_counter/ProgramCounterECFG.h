#ifndef PROGRAMCOUNTERECFG_H_INCLUDED
#define PROGRAMCOUNTERECFG_H_INCLUDED

#include <vector>
#include "ProgramCounter.h"
#include "ae/CRecorderHolderSet.h"
#include "graphs/ecfg/CECFGNode.h"
#include <memory>

class ProgramPointECFG;

// =======================================================
// =======================================================
// ProgramCounterECFG -
// An ECFG program counter holds an ECFG program point (which holds
// an ECFGNode) and a recoorder holder set (and a server for
// updating, copying, ...) this set.
// =======================================================
// =======================================================
class ProgramCounterECFG : public ProgramCounter
{
public:
  // To create a program counter from an already existing one
  ProgramCounterECFG(const CGenericProgram * program, unique_ptr<ProgramPointECFG> pp);
  // To delete the program counter.
  virtual ~ProgramCounterECFG(void);

  // To make a deep copy of the program counter
  virtual ProgramCounterECFG * Copy(void) const = 0;

  // @return true if this program counter is equal to @a other_pc, otherwise @c false 
  virtual bool IsEqual(const ProgramCounter* other_pc) const = 0;

  // To get the program points as an ECFG program point
  const ProgramPointECFG * GetProgramPointECFG() const;

  // To update the PC. Will indirectly update the included recorder set. 
  void UpdateWithProgramStart(void); // No pp given, use the one given at creation
  void UpdateWithNewProgramPoint(unique_ptr<ProgramPoint> new_pp);

  // Step to the successor statement, i.e. the program point
  // following the current program point. This is not necessarily the
  // next program point in the execution flow, since the current
  // program point may be a jump statement or a call statement, or
  // similar.  
  // @pre Stmt()->Type() returns either SKIP, STORE, FREE or CALL
  virtual void StepToTextualSuccessor();

  // Print information about this program point to the output stream os
  virtual std::ostream & Print(std::ostream & os = std::cout) const;

  // To check and get the program point
  virtual bool IsProgramCounterECFG() const { return true; }
  virtual const ProgramCounterECFG* AsProgramCounterECFG() const { return this; }
  
  // To check if two VA PC's are mergable (i.e. we can apply LUB or GLB
  // on them). Basically, two ECFG_VA PCs will be mergable if they are at
  // the same program point.
  static bool AreMergable(const ProgramCounterECFG * pc1, const ProgramCounterECFG * pc2) { return pc1->AreMergable(pc2); }

  // To perform merge and intersect between two PCs. Asserts if not mergable.
  // The resulting PC is owned by the caller. 
  static ProgramCounterECFG * LUB(const ProgramCounterECFG * pc1, const ProgramCounterECFG * pc2) { return pc1->LUB(pc2); }
  static ProgramCounterECFG * GLB(const ProgramCounterECFG * pc1, const ProgramCounterECFG * pc2) { return pc1->GLB(pc2); }
  
  // Functions that must be implemented by subclasses
  virtual bool AreMergable(const ProgramCounterECFG * other_pc) const = 0;
  virtual ProgramCounterECFG * LUB(const ProgramCounterECFG * other_pc) const = 0;
  virtual ProgramCounterECFG * GLB(const ProgramCounterECFG * other_pc) const = 0;

  // Keeps an ECFG program point, but this is done by parent class
  
};

#endif   // PROGRAMCOUNTERECFG_H_INCLUDED
