#ifndef PROGRAMCOUNTERVA_H_INCLUDED
#define PROGRAMCOUNTERVA_H_INCLUDED

#include <vector>
#include "ProgramPointECFG.h"
#include "ProgramCounterECFG.h"
#include "ae/CRecorderHolderSet.h"
#include <memory>

// =======================================================
// =======================================================
// ProgramCounterECFG_VA -
// An ECFG_VA program counter holds an ECFG_VA program point (which holds
// an ECFGNode) and a recoorder holder set (and a server for
// updating, copying, ...) this set. The recorder holder set will 
// include a scope index vector.
// =======================================================
// =======================================================
class ProgramCounterECFG_VA : public ProgramCounterECFG
{
public:
  // To create a program counter from an already existing one
  ProgramCounterECFG_VA(const CGenericProgram * program, unique_ptr<ProgramPointECFG> pp);
  // To delete the program counter.
  virtual ~ProgramCounterECFG_VA(void);

  // To make a deep copy of the program counter
  ProgramCounterECFG_VA * Copy(void) const;

  /** @return @c true if this program counter is equal to @a pc2, otherwise @c false */
  virtual bool IsEqual(const ProgramCounter* other_pc) const;

  // Print information about this program point to the output stream os
  virtual std::ostream & Print(std::ostream & os = std::cout) const;

  // To check what subtype the class is
  virtual bool IsProgramCounterECFG_VA() const { return true; }
  virtual const ProgramCounterECFG_VA* AsProgramCounterECFG_VA() const { return this; }
  
protected:

  // Functions that must be implemented by subclasses
  bool AreMergable(const ProgramCounterECFG * other_pc) const;
  ProgramCounterECFG * LUB(const ProgramCounterECFG * other_pc) const;
  ProgramCounterECFG * GLB(const ProgramCounterECFG * other_pc) const;

  // Also keeps an ECFG program point, but this is done by parent class

};

#endif   // PROGRAMCOUNTERECFG_VA_H_INCLUDED
