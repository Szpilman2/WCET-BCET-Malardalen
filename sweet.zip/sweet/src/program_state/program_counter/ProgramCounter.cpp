#include "ProgramCounter.h"

ProgramCounter::
~ProgramCounter(void)
{
  // Not needed since we use unique_ptr
  if(_program_point) delete _program_point;
}

// ProgramCounter *
// ProgramCounter::
// CreateProgramCounter(const CGenericProgram * program, unique_ptr<ProgramPoint> pp)
// {
//   ProgramCounter * pc = new ProgramCounter(program, pp);
//   pp->SetProgramCounterBackwardPtr(pc);
//   return pc;
// }

ProgramCounter::
ProgramCounter(const CGenericProgram * program, unique_ptr<ProgramPoint> pp)
  : _program_point(pp.release()), _program(program)
{
   assert(_program_point);
   _program_point->SetProgramCounterBackwardPtr(this);
}

ProgramCounter::ProgramCounter(const ProgramCounter & other)
: _program_point(other.GetProgramPoint()->Copy()), _program(other.GetProgram())
{
  _program_point->SetProgramCounterBackwardPtr(this);
}


const ProgramPoint *
ProgramCounter::
GetProgramPoint(void) const
{
  return _program_point;
}

void
ProgramCounter::
UpdateProgramPoint(unique_ptr<ProgramPoint> new_program_point)
{
  // cerr << " _program_point; " <<  *_program_point << endl;
  // cerr << " new_program_point; " <<  *new_program_point << endl;
  // cerr << "ProgramCounter::UpdateProgramPoint \n";
  // cerr << "ProgramCounter::UpdateProgramPoint \n";
  // cerr << "copy: " << *(_program_point->Copy()) << endl;
  if(_program_point) delete _program_point;
  // cerr << "ProgramCounter::UpdateProgramPoint 1\n";
  // cerr << "ProgramCounter::UpdateProgramPoint 1\n";
  _program_point = new_program_point.release();
  // cerr << "ProgramCounter::UpdateProgramPoint 2\n";
  // cerr << "ProgramCounter::UpdateProgramPoint 2\n";
  // _program_point->SetProgramCounterBackwardPtr(this);
}

// To set backward pointer to state owning the PC
void
ProgramCounter::
SetStateBackwardPtr(State * state) 
{
  _state_backward_ptr = state;
}

// To get backward pointer to state owning the PC
const 
State *
ProgramCounter::
GetStateBackwardPtr() const
{
  return _state_backward_ptr;
}


