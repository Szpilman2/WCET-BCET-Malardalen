#include "ProgramPointECFG.h"
#include <vector>

ProgramPointECFG::
ProgramPointECFG(CECFGNode * ecfg_node, bool is_final)
  : ProgramPoint(is_final), _ecfg_node(ecfg_node)
{
  
}

ProgramPointECFG::
ProgramPointECFG()
  : ProgramPoint(true)
{
  _ecfg_node = NULL;
}


ProgramPointECFG::
~ProgramPointECFG(void)
{
  // Do nothing
}

ProgramPointECFG *
ProgramPointECFG::
Copy(void) const
{
   return new ProgramPointECFG(_ecfg_node, _is_final);
}

// Two program points are considered equal if they hold the same ecfg
// node
bool 
ProgramPointECFG::
IsEqual(const ProgramPoint * other_pp) const
{
  if(!other_pp->IsProgramPointECFG())
    return false;

  const ProgramPointECFG * pp1 = other_pp->AsProgramPointECFG();
  const ProgramPointECFG * pp2 = this;

  if(pp1->GetECFGNode() != pp2->GetECFGNode())
    return false;

  return true;
}

// We get the statement from the current CFG node
const CGenericStmt * 
ProgramPointECFG::GetStmt(void) const 
{
   assert(!IsFinal() || "Final program points have no statements" == 0);
   assert(_ecfg_node);
   assert(_ecfg_node->GetFlowGraphNode());
   assert(_ecfg_node->GetFlowGraphNode()->Stmt());
   return _ecfg_node->GetFlowGraphNode()->Stmt();
}

// We get the current CFG node from the ECFG
const CFlowGraphNode * 
ProgramPointECFG::
GetFlowGraphNode(void) const
{
  return _ecfg_node->GetFlowGraphNode();
}

// Just return the current ECFG node
CECFGNode * 
ProgramPointECFG::
GetECFGNode(void) 
{
  return _ecfg_node;
}

const CECFGNode * 
ProgramPointECFG::
GetECFGNode(void) const
{
  return _ecfg_node;
}

ProgramPointECFG *
ProgramPointECFG::
GetTextualSuccessor(void) const
{
  // cerr << "ProgramPointECFG::GetTextualSuccessor\n";
   CECFGNode * succ_ecfg_node = 0;
   switch (GetStmt()->Type())
   {
   case CGenericStmt::GS_SKIP:
   case CGenericStmt::GS_STORE:
   case CGenericStmt::GS_FREE:
     {
       assert(GetECFGNode()->SuccSize() == 1 ||
              "This function is only defined for program points with a "
              "single textual successor" == NULL);
       succ_ecfg_node = const_cast<CECFGNode *>(GetECFGNode())->SuccBegin()->node;
       break;
     }
   case CGenericStmt::GS_CALL:
     {
       // Get the return-to-ecfg-node after the call node
       if(!GetECFGNode()->HasFalseEdgeSuccessor()) {
         std::cerr << "ERROR: Func call node with no textual successor! "
                   << GetECFGNode()->GetFlowGraphNode()->Stmt()->Name() << endl;
       }
       assert(GetECFGNode()->HasFalseEdgeSuccessor());
       succ_ecfg_node = GetECFGNode()->GetFalseEdgeSuccessor();
       break;
     }
   case CGenericStmt::GS_COND:
      {
	std::vector<CECFGNode::successor_type> fall_through_succ;
	_ecfg_node->GetSuccessorsWithAnnotNumber(_ecfg_node->GetHighestAnnotNumber(), &fall_through_succ);
	assert(fall_through_succ.size() == 1);
	succ_ecfg_node = fall_through_succ.front().node;
	break;
      }
   default:
      assert("Successor node cannot be determined" == NULL);
      succ_ecfg_node = NULL;
      break;
   }

   return new ProgramPointECFG(succ_ecfg_node);
}

bool
ProgramPointECFG::
IsEndOfBasicBlock(void) const
{
  return _ecfg_node->IsEndOfBasicBlock();
}

std::ostream & 
ProgramPointECFG::
Print(std::ostream & os) const
{
//  std::cerr << "ProgramPointECFG::Print\n";
  if(IsFinal()) {
    os << "FINAL";
  }
  else {
  //  std::cerr << "ProgramPointECFG::Print 2\n";
    assert(GetECFGNode());
  //  std::cerr << "ProgramPointECFG::Print 3\n";
    os << *const_cast<CECFGNode *>(GetECFGNode());
  //  std::cerr << "ProgramPointECFG::Print 4\n";
  }
  return os;
}
