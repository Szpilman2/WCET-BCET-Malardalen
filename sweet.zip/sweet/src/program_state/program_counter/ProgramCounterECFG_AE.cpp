#include "ProgramCounterECFG_AE.h"
#include "graphs/ecfg/CECFGNode.h"
#include "graphs/scopes/CScope.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "ae/CRecorderHolder.h"

using namespace std;

ProgramCounterECFG_AE::
ProgramCounterECFG_AE(const CGenericProgram * program, unique_ptr<ProgramPointECFG> pp, 
		      CRecorderHolderSet * rhs, CRecorderHolderSetServer * rhs_server)
  : ProgramCounterECFG(program, move(pp)), _rhs(rhs), _rhs_server(rhs_server)
{
  // Do nothing
}

ProgramCounterECFG_AE::
~ProgramCounterECFG_AE(void)
{
  // We delete the recorder holder set using the server. The server
  // itself should not be deleted.
  _rhs_server->DeleteRecorderHolderSet(_rhs);

  // Parent delete will delete the program point
}

ProgramCounterECFG_AE *
ProgramCounterECFG_AE::
Copy(void) const
{
  // Copy the set of recorder holders using the server
  CRecorderHolderSet * new_rhs = _rhs_server->CopyRecorderHolderSet(_rhs);

  // The program point must also be copied
  unique_ptr<ProgramPointECFG> new_pp(GetProgramPointECFG()->Copy());

  // Create and return the new program counter
  return new ProgramCounterECFG_AE(GetProgram(), move(new_pp), new_rhs, _rhs_server);
}

bool 
ProgramCounterECFG_AE::
IsEqual(const ProgramCounter* other_pc) const 
{
  // Check if the other pc is of the same type
  if (!other_pc->IsProgramCounterECFG_AE())
    return false;

  // Else convert the pc to an ecfg pc
  const ProgramCounterECFG_AE* pc1 = other_pc->AsProgramCounterECFG_AE();
  const ProgramCounterECFG_AE* pc2 = this;

   if (pc1->GetProgram() != pc2->GetProgram())
      return false;

   if (!pc1->GetProgramPoint()->IsEqual(pc2->GetProgramPoint()))
      return false;

   // TODO: What to do with recorder holder set/rhs server?

   return true;
}

const CRecorderHolderSet *
ProgramCounterECFG_AE::
GetRecorderHolderSet(void) const
{
  return _rhs;
}

const CRecorderHolderSetServer *
ProgramCounterECFG_AE::
GetRecorderHolderSetServer(void) const
{
  return _rhs_server;
}


void
ProgramCounterECFG_AE::
UpdateWithProgramStart(void)
{
  // Dowcast to the right type
  const ProgramPointECFG * pp_ae = GetProgramPointECFG();

  // Call the recorder set with the corresponding function
  const CECFGNode * ecfg_node_after = pp_ae->GetECFGNode();
  _rhs_server->UpdateRecorderHolderSetWithProgramStart(&_rhs, const_cast<CECFGNode *>(ecfg_node_after));
}

void 
ProgramCounterECFG_AE::
UpdateWithNewProgramPoint(unique_ptr<ProgramPoint> new_pp)
{
  assert(new_pp.get() != NULL);
  // Check that it is an ECFG program point
  assert((new_pp.get())->IsProgramPointECFG());

  // cerr << "ProgramCounterECFG_AE::UpdateWithNewProgramPoint 1\n";

  // Get the corresponding prev ECFG_AE program point
  const ProgramPointECFG * pp_ae_before = GetProgramPointECFG(); 
  const CECFGNode * ecfg_node_before = pp_ae_before->GetECFGNode();

  // Get the corresponding new ECFG_AE program point
  const ProgramPointECFG * pp_ae_after = (new_pp.get())->AsProgramPointECFG(); 
  const CECFGNode * ecfg_node_after = pp_ae_after->GetECFGNode();

  // cerr << "ProgramCounterECFG_AE::UpdateWithNewProgramPoint 2\n";

  // Update server differently depending on if it is the final state or nor
  if(pp_ae_after->IsFinal()) {
    // cerr << "ProgramCounterECFG_AE::UpdateWithNewProgramPoint 2\n";
    _rhs_server->UpdateRecorderHolderSetWithProgramExit(&_rhs, const_cast<CECFGNode *>(ecfg_node_before));
  }
  else {
    // cerr << "ProgramCounterECFG_AE::UpdateWithNewProgramPoint 3\n";
    _rhs_server->UpdateRecorderHolderSetWithProgramCounterChange(&_rhs, const_cast<CECFGNode *>(ecfg_node_before), 
                                                                 const_cast<CECFGNode *>(ecfg_node_after));
  }

  // cerr << "ProgramCounterECFG_AE::UpdateWithNewProgramPoint 4\n";
  // Call parent function that will delete old program point and set the new one
  UpdateProgramPoint(move(new_pp));
}

bool
ProgramCounterECFG_AE::
AreMergable(const ProgramCounterECFG * bpc) const
{
  if(!bpc->IsProgramCounterECFG_AE()) 
    return false;

  const ProgramCounterECFG_AE * apc = this;

  // Cast away constness. Should be removed when called functions are constified.
  ProgramCounterECFG_AE * a = const_cast<ProgramCounterECFG_AE *>(apc);
  ProgramCounterECFG_AE * b = const_cast<ProgramCounterECFG_AE *>(bpc->AsProgramCounterECFG_AE());

  // If the program counters have different program points they can not be merged
  if (!(apc->GetProgramPoint()->IsEqual(bpc->GetProgramPoint())))
    return false; 

  // If the program counters have different scope index vectors they can not be merged
  CRecorderHolderSet * a_rhs = const_cast<CRecorderHolderSet *>(a->GetRecorderHolderSet());
  CRecorderHolderSet * b_rhs = const_cast<CRecorderHolderSet *>(b->GetRecorderHolderSet());
  if (!(a_rhs->GetScopeIndexRecorderHolder()->IsEqual(b_rhs->GetScopeIndexRecorderHolder())))
    return false;
  else
    return true;
}

ProgramCounterECFG * 
ProgramCounterECFG_AE::LUB(const ProgramCounterECFG * bpc) const
{
  const ProgramCounterECFG_AE * apc = this;

  assert(apc->AreMergable(bpc));

  // Cast away constness. Should be removed when called functions are constified.
  ProgramCounterECFG_AE * a = const_cast<ProgramCounterECFG_AE *>(apc);
  ProgramCounterECFG_AE * b = const_cast<ProgramCounterECFG_AE *>(bpc->AsProgramCounterECFG_AE());

  // Take a copy of the program point
  unique_ptr<ProgramPointECFG> new_pp(a->GetProgramPointECFG()->Copy());

  // Cast away constness. Should be removed when called functions are constified.
  CRecorderHolderSet * a_rhs = const_cast<CRecorderHolderSet *>(a->GetRecorderHolderSet());
  CRecorderHolderSet * b_rhs = const_cast<CRecorderHolderSet *>(b->GetRecorderHolderSet());

  // Merge the recorder holder sets using the server
  CRecorderHolderSet * new_rhs = a->_rhs_server->MergeRecorderHolderSets(a_rhs, b_rhs);

  // Create and return a new PC
  return new ProgramCounterECFG_AE(apc->GetProgram(), move(new_pp), new_rhs, a->_rhs_server);
}

ProgramCounterECFG * 
ProgramCounterECFG_AE::
GLB(const ProgramCounterECFG * bpc) const
{  
  const ProgramCounterECFG_AE * apc = this;
  assert(apc->AreMergable(bpc));
  return apc->Copy();
}

std::ostream & ProgramCounterECFG_AE::Print(std::ostream & os) const
{
  assert(GetProgramPointECFG());
  GetProgramPointECFG()->Print(os);
  os << "\nRecorder Holder Set: \n";
  if(_rhs) 
    _rhs->Print(&os);
  return os;
}

