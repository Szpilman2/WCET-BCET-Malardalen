#include "ProgramCounterECFG.h"
#include "ProgramPointECFG.h"
#include "macros.h"
#include <memory>

ProgramCounterECFG::
ProgramCounterECFG(const CGenericProgram * program, std::unique_ptr<ProgramPointECFG> pp)
  : ProgramCounter(program, unique_ptr<ProgramPoint>(move(pp)))
{
  // Do nothing
}

ProgramCounterECFG::
~ProgramCounterECFG(void)
{
  // Parent delete will delete the program point
}

// ProgramCounterECFG *
// ProgramCounterECFG::
// Copy(void) const
// {
//   // Create and return the new program counter
//   std::unique_ptr<ProgramPointECFG> new_pp(GetProgramPointECFG()->Copy());
//   return new ProgramCounterECFG(GetProgram(), new_pp);
// }

// bool 
// ProgramCounterECFG::
// IsEqual(const ProgramCounter* other_pc) const
// {
//   // Check if the other pc is of the same type
//   if (!other_pc->IsProgramCounterECFG())
//     return false;

//   // Else convert the pc to an ecfg pc
//   const ProgramCounterECFG* pc1 = other_pc->AsProgramCounterECFG();
//   const ProgramCounterECFG* pc2 = this;
  
//   if (pc1->GetProgram() != pc2->GetProgram())
//     return false;
  
//   if (!pc1->GetProgramPoint()->IsEqual(pc2->GetProgramPoint()))
//     return false;
  
//   return true;
// }

const ProgramPointECFG *
ProgramCounterECFG::
GetProgramPointECFG(void) const
{
   assert(_program_point);
   const ProgramPointECFG *pp_ecfg = _program_point->AsProgramPointECFG();
   assert(pp_ecfg);
   return pp_ecfg;
}



void
ProgramCounterECFG::
UpdateWithProgramStart(void)
{
  // Do nothing
}

void 
ProgramCounterECFG::
UpdateWithNewProgramPoint(std::unique_ptr<ProgramPoint> new_pp)
{
  assert(new_pp.get() != NULL);
  // Check that it is an ECFG program point
  assert((new_pp.get())->IsProgramPointECFG());
  // Call parent function that will delete old program point and set the new one
  UpdateProgramPoint(move(new_pp));
}

void 
ProgramCounterECFG::
StepToTextualSuccessor(void)
{
  // cerr << "ProgramCounterECFG::StepToTextualSuccessor \n";
  std::unique_ptr<ProgramPoint> succ(GetProgramPoint()->GetTextualSuccessor());
  // cerr << "ProgramCounterECFG::StepToTextualSuccessor 1\n";
  UpdateWithNewProgramPoint(move(succ));
  // cerr << "ProgramCounterECFG::StepToTextualSuccessor 2\n";
}

std::ostream & ProgramCounterECFG::Print(std::ostream & os) const
{
  GetProgramPointECFG()->Print(os);
  return os;
}


