#ifndef PROGRAMPOINTECFG_H_INCLUDED
#define PROGRAMPOINTECFG_H_INCLUDED

#include "ProgramCounter.h"
#include "graphs/ecfg/CECFGNode.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "program/CGenericStmt.h"

// =======================================================
// =======================================================
// ProgramPointECFG -
// A program point which is represented by an ECFG node.
// Inherits most functionality from ProgramPoint.
// =======================================================
// =======================================================
class ProgramPointECFG : public ProgramPoint
{
public:
  // To create a program point we need an ECFG. 
  ProgramPointECFG(CECFGNode * ecfg_node, bool is_final=false);

  // To create a final program point, i.e a program point without an
  // ECFG mode. The IsFinal() attribute will then be true.
  ProgramPointECFG();
  
  // To delete the ECFG program point.
  virtual ~ProgramPointECFG(void);
  
  // Make a deep copy of this program point
  virtual ProgramPointECFG * Copy(void) const;
  
  // To check if two program points are equal. 
  bool IsEqual(const ProgramPoint * other) const;

  // To get the current ECFG node
  CECFGNode * GetECFGNode(void);
  const CECFGNode * GetECFGNode() const;

  // To get the current CFG node from the ECFG node.
  const CFlowGraphNode * GetFlowGraphNode(void) const;

  // To get the statement of this program point from the CFG node.
  const CGenericStmt * GetStmt(void) const;

  /// Return the program point following this program point. This is
  /// not necessarily the next program point in the program flow,
  /// since the current program point may be something like a jump
  /// statement or a call statement.  
  /// @pre Stmt()->Type() returns either SKIP, STORE, FREE or CALL
  /// @note The caller is responsible for deleting the returned pointer
  virtual ProgramPointECFG * GetTextualSuccessor() const;

  /// @return true if this program point is the end of a basic block, false otherwise
  bool IsEndOfBasicBlock() const;

  // To get the type of program point
  bool IsProgramPointECFG() const { return true; }
  const ProgramPointECFG * AsProgramPointECFG() const { return this; }

  std::ostream & Print(std::ostream & os = std::cout) const;

protected:

  // A ECFG node holds one CFG node. The CFG node holds a single
  // statement.
  CECFGNode * _ecfg_node;

};

#endif // PROGRAMPOINTECFG_H_INCLUDED
