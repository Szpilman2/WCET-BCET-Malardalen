#ifndef PROGRAMCOUNTER_H_INCLUDED
#define PROGRAMCOUNTER_H_INCLUDED

#include <memory>
#include <ostream>
#include "ProgramPoint.h"
#include "program/CGenericStmt.h"
#include "graphs/cfg/CFlowGraphNode.h"

using namespace std;

class State;
class CGenericProgram;
class ProgramCounterECFG;
class ProgramCounterECFG_AE;
class ProgramCounterECFG_VA;

// -------------------------------------------------------
// Class hierarchy
//
// ProgramCounter
//   |
//   |-- ProgramCounterECFG
//          |
//          | -- ProgramCounterECFG_VA
//          | -- ProgramCounterECFG_AE
// 
// -------------------------------------------------------

// =======================================================
// =======================================================
// ProgramCounter -
// Base class holding functionality neccessary for all program
// Counters (PCs).  Each PC includes a program point.
// =======================================================
// =======================================================
class ProgramCounter
{
public:

   // We have made the create functions protected to make sure that they not are called directly
   // To create and delete the program counter
   ProgramCounter(const CGenericProgram * program, unique_ptr<ProgramPoint> pp);

   // Make a deep copy of the program counter @a other
   ProgramCounter(const ProgramCounter & other);




   // To create and delete the program counter
   // static ProgramCounter * CreateProgramCounter(const CGenericProgram * program, unique_ptr<ProgramPoint> pp);
   // Make a deep copy of the program counter @a other
   // static ProgramCounter * CreateProgramCounter(const ProgramCounter & other);

   // To delete the PC
   virtual ~ProgramCounter(void);

   // Make a deep copy of the PC
   virtual ProgramCounter * Copy(void) const = 0;

   // @return @c true if this program counter is equal to @a other_pc, otherwise @c false 
   virtual bool IsEqual(const ProgramCounter* other_pc) const = 0;

   // Return the program
   const CGenericProgram * GetProgram() const { return _program; }

   // To get the program point held by the PC
   virtual const ProgramPoint * GetProgramPoint(void) const;

   // To update the PC with a program point change
   virtual void UpdateWithProgramStart(void) = 0;
   virtual void UpdateWithNewProgramPoint(unique_ptr<ProgramPoint> new_pp) = 0;
   // virtual void UpdateWithProgramExit(void) = 0;

   // Print information about this program point to the output stream os
   virtual std::ostream & Print(std::ostream & os = std::cout) const = 0;

   // Step to the successor statement, i.e. the pp following the
   // current program point. This is not necessarily the next program
   // point in the execution flow, since the current program point may
   // be a jump statement or a call statement, or similar.
   virtual void StepToTextualSuccessor() = 0;

   // To check what subtype the class is (to be overwritten by subclasses).
   virtual bool IsProgramCounterECFG() const { return false; }
   virtual const ProgramCounterECFG* AsProgramCounterECFG() const { assert(0); return NULL; }
   virtual bool IsProgramCounterECFG_VA() const { return false; }
   virtual const ProgramCounterECFG_VA* AsProgramCounterECFG_VA() const { assert(0); return NULL; }
   virtual bool IsProgramCounterECFG_AE() const { return false; }
   virtual const ProgramCounterECFG_AE* AsProgramCounterECFG_AE() const { assert(0); return NULL; }

   // To set and get a backward pointer to the state that owns the PC. Is called
   // at state creation
   void SetStateBackwardPtr(State * state);
   const State * GetStateBackwardPtr(void) const;

protected:

   // Help functions used by subclasses
   virtual void UpdateProgramPoint(unique_ptr<ProgramPoint> new_program_point); 

   // The actual program point 
   ProgramPoint * _program_point;

   // Backward pointer to state owning the PC
   State * _state_backward_ptr;

private:
   const CGenericProgram * _program;
};

// Print information about a program point to the output stream os
inline std::ostream & operator <<(std::ostream & os, const ProgramCounter & program_counter) {return program_counter.Print(os);}

#endif   // PROGRAMCOUNTER_H_INCLUDED
