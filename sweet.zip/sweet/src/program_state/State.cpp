#include "State.h"
#include "CallStack.h"
#include "PPEnviron.h"
#include "memory/Memory.h"
#include "memory/MemoryDomain.h"
#include "value/SymbPointer.h"
#include "value/ValueDomain.h"
#include "program_counter/ProgramCounter.h"
#include "program_counter/ProgramCounterECFG.h"
#include "program_counter/ProgramCounterECFG_AE.h"
#include "program_counter/ProgramPointECFG.h"
#include "program/CGenericProgram.h"
#include "program/alf/CGenericNode.h"
#include "tools/CAlfLabelSource.h"
#include "tools/TextTable.h"
#include "tools/IndentingOStream.h"
#include "tools/RangeIterator.h"
#include "tools/XAssert.h"
#include "globals.h"
#include <stdexcept>

using namespace std;

State::State(std::unique_ptr<ProgramCounterECFG> pc, std::unique_ptr<PPEnviron> pp_environ, bool is_bottom)
   : _name(GetNextIntName()),
     _is_bottom(is_bottom),
     _pc(pc.release()),
     _pp_environ(pp_environ.release()),
     _mem(nullptr),
     _call_stack(nullptr)
{
   if (!is_bottom) {
      _genv.reset( new VarEnviron );
      _mem = domain->GetMemoryDomain()->CreateMemory();
      _call_stack.reset( new CallStack );
   }
}

State *State::CreateBottomState(std::unique_ptr<ProgramCounterECFG> pc) { return new State(move(pc), 0, true); }

State::~State()
{
   delete _pc;
   delete _mem;
}

State *State::Copy() const
{
   if (IsBottom()) {
      assert(GetProgramCounter());
      std::unique_ptr<ProgramCounterECFG> pc_ae(GetProgramCounterECFG()->Copy());
      return State::CreateBottomState(move(pc_ae));
   }
   else {
      return new State(*this);
   }
}

bool State::operator ==(const State &other) const
{
   // If both states are bottom
   if (IsBottom() && other.IsBottom()) {
      return true;
   }
   // If just one of the states are bottom
   if (IsBottom() || other.IsBottom()) {
      return false;
   }
   // Check if the program counters are equal
   if (!GetProgramCounter()->IsEqual(other.GetProgramCounter())) {
      return false;
   }
   // Check if the environments are equal
   if (!GetPPEnviron()->IsEqual(*other.GetPPEnviron())) {
      return false;
   }
   // Check if memories are equal
   if (!GetMemory()->IsEqual(other.GetMemory())) {
      return false;
   }
   // Check if callstacks are equal
   if (!GetCallStack()->IsEqual(other.GetCallStack())) {
      return false;
   }
   return true;
}

bool State::IsFinalState() const
{
   return IsBottom()? false : GetProgramCounter()->GetProgramPoint()->IsFinal();
}

ProgramCounter *State::GetProgramCounter() const { return _pc; }

const CGenericProgram *State::GetProgram() const { return GetProgramCounter()->GetProgram(); }

const VarEnviron *State::GetEnviron() const { CheckNotBottom(); return _call_stack->GetTop().GetEnviron(); }

Value *State::Lookup(unsigned id, bool cshack) const
{
   CheckNotBottom();
   const CallStack::SizeType csheight = _call_stack->Height();
   if (!cshack) {
      if (csheight > 0) {
         const VarEnviron *env = GetEnviron();
         if (env->Defined(id))
            return env->ApplyEnvFunction(id);
      }
   }
   else if (csheight > 1) {
      // handling of "call stack hack"
      CallStack::ConstIterator sf = --(--(_call_stack->IterEnd())); // traverse one step down from the top
      const VarEnviron *env = (*sf)->GetEnviron();
      if (env->Defined(id))
         return env->ApplyEnvFunction(id);
   }
   if (GetGlobEnviron()->Defined(id))
      return GetGlobEnviron()->ApplyEnvFunction(id);

   throw runtime_error("Lookup of id failed (i.e., a non-existing base pointer was referenced in the code)");
   return 0; // Should not reach here   
}

const RetAddrList *State::GetRetAddrList() const 
{
   CheckNotBottom();
   return _call_stack->GetTop().GetRetAddrList();
}

bool State::AreMergeable(const State *state2) const
{
   // Possibly other stuff should be checked too
  return GetProgramCounterECFG()->AreMergable(state2->GetProgramCounterECFG());
}

State *State::GLB(const State *state2) const
{
   const State *state1 = this;

   if (state1->IsBottom())
      return state1->Copy();
   if (state2->IsBottom())
      return state2->Copy();

   XASSERT(state1->GetProgramCounterECFG()->GetProgramPoint()->IsEqual(
      state2->GetProgramCounterECFG()->GetProgramPoint())) << "GLB: States must be at the same program point";

   unique_ptr<ProgramCounterECFG> glb_pc(state1->GetProgramCounterECFG()->GLB(state2->GetProgramCounterECFG()));
   unique_ptr<Memory> glb_mem(state1->GetMemory()->GLB(state2->GetMemory()));
   cheap_copy<CallStack> glb_cs;
   if (_reuse_call_stack && state1->_call_stack.get() == state2->_call_stack.get())
      glb_cs = state1->_call_stack;
   else
      glb_cs.reset( state1->_call_stack->GLB(state2->_call_stack.get()) );

   // Check if we got an erroneous value
   if (!glb_mem || !glb_cs)
      return CreateBottomState(unique_ptr<ProgramCounterECFG>(state1->GetProgramCounterECFG()->Copy()));

   return new State(move(glb_pc), state1->_genv, move(glb_mem), move(glb_cs), state1->_pp_environ);
}

State *State::LUB(const State *state2) const
{
   const State *state1 = this;

   if (state1->IsBottom())
      return state2->Copy();
   if (state2->IsBottom())
      return state1->Copy();

   XASSERT(state1->GetProgramCounterECFG()->GetProgramPoint()->IsEqual(
      state2->GetProgramCounterECFG()->GetProgramPoint())) << "LUB: States must be at the same program point";

   // Create new LUB:d environment, memory, parameter area and callstack.
   unique_ptr<ProgramCounterECFG> lub_pc(state1->GetProgramCounterECFG()->LUB(state2->GetProgramCounterECFG()));
   unique_ptr<Memory> lub_mem(state1->GetMemory()->LUB(state2->GetMemory()));
   cheap_copy<CallStack> lub_cs;
   if (_reuse_call_stack && state1->_call_stack.get() == state2->_call_stack.get())
      lub_cs = state1->_call_stack;
   else
      lub_cs.reset( state1->_call_stack->LUB(state2->_call_stack.get()) );
   
   // LUB should never give bottom
   assert(lub_mem);
   assert(lub_cs);
   
   return new State(move(lub_pc), state1->_genv, move(lub_mem), move(lub_cs), state1->_pp_environ);
}

State *State::Widening(const State *state2) const
{
   const State *state1 = this;

   // Test some special cases
   if (state1->IsBottom())
      return state2->Copy();
   if (state2->IsBottom())
      return Copy();

   XASSERT(state1->GetProgramCounterECFG()->GetProgramPoint()->IsEqual(
      state2->GetProgramCounterECFG()->GetProgramPoint())) << "Widening: States must be at the same program point";

   // Compute widened components
   unique_ptr<ProgramCounterECFG> wid_pc(GetProgramCounterECFG()->Copy());
   unique_ptr<Memory> wid_mem(GetMemory()->Widening(state2->GetMemory()));
   cheap_copy<CallStack> wid_cs;
   if (_reuse_call_stack && state1->_call_stack.get() == state2->_call_stack.get())
      wid_cs = state1->_call_stack;
   else
      wid_cs.reset(state1->_call_stack->Widening(state2->_call_stack.get()));
   
   return new State(move(wid_pc), state1->_genv, move(wid_mem), move(wid_cs), state1->_pp_environ);
}

State *State::Narrowing(const State *state2) const
{
   const State *state1 = this;

   // Test some special cases
   if (state1->IsBottom())
      return state2->Copy();
   if (state2->IsBottom())
      return Copy();

   XASSERT(state1->GetProgramCounterECFG()->GetProgramPoint()->IsEqual(
      state2->GetProgramCounterECFG()->GetProgramPoint())) << "Narrowing: States must be at the same program point";

   // Compute narrowed state components
   unique_ptr<ProgramCounterECFG> nar_pc(GetProgramCounterECFG()->Copy());
   unique_ptr<Memory> nar_mem(GetMemory()->Narrowing(state2->GetMemory()));
   cheap_copy<CallStack> nar_cs;
   if (_reuse_call_stack && state1->_call_stack.get() == state2->_call_stack.get())
      nar_cs = state1->_call_stack;
   else
      nar_cs.reset(state1->_call_stack->Narrowing(state2->_call_stack.get()));
   
   // Check if we got an erroneous value
   if (!nar_mem || !nar_cs)
      return CreateBottomState(unique_ptr<ProgramCounterECFG>(state1->GetProgramCounterECFG()->Copy()));

   return new State(move(nar_pc), state1->_genv, move(nar_mem), move(nar_cs), state1->_pp_environ);
}

static void PrintPP(const ProgramPoint *pp, ostream &os) {
   if (!pp->IsFinal()) {
      const CGenericStmt *stmt = pp->GetStmt();
      if (const CAlfLabelSource *srcinfo = stmt->GetSourceInfo()) {
         os << *srcinfo;
      } else {
         string stmt_name = stmt->Name();
         if (!stmt_name.empty())
            os << '"' << stmt_name << "\" @ ";
         const alf::CGenericNode *node = dynamic_cast<const alf::CGenericNode*>(stmt);
         alf::COORD coord = node->GetCoord();
         os << *coord.source_file << ':' << coord.line << ':' << coord.col;
      }
   } else {
      os << "FINAL";
   }
}

static void PrintFrame(VarEnviron::EnvIterator &fi, const Memory *mem,
                       SymbolColl &syms, TextTable &tab, IndentingOStream &itabstr)
{
   // look up the frame and load its contents
   const Value *ptr = fi->second.GetBasePointer();
   Size amt_alloc = fi->second.GetAmountAllocated();
   unique_ptr<Value> frame_val( mem->Load(ptr, amt_alloc) );
   // if the frame id has an annotation (which it should have), print it
   if (const SymbPointer *sym_ptr = dynamic_cast<const SymbPointer*>(ptr)) {
      syms.clear(); sym_ptr->GetSymbols(syms);
      assert(syms.size() == 1);
      itabstr << '"' << syms.begin()->GetAnnot() << "\":";
   } else { // otherwise, simply print the frame ID
      itabstr << "frame " << fi->first << ':';
   }
   // value column
   tab.NextColumn();
   itabstr << *frame_val;
   // size column
   tab.NextColumn();
   Size size_in_bits = frame_val->SizeInBits();
   itabstr << '(' << size_in_bits;
   if (size_in_bits != 1) itabstr << " bits)"; // plural
   else itabstr << " bit)";                    // singular
   tab.NextRow();
}

ostream &State::Print(ostream &os) const
{
   if (this->IsFinalState())
      return os << "(final state)";
   if (this->IsBottom())
      return os << "(bottom state)";
   const Memory *mem = this->GetMemory();
   SymbolColl syms;
   TextTable tab;
   // since we are printing to a TextTable, we use spaces instead of tabs for indentation
   IndentingOStream itabstr(tab.GetStream().rdbuf(), "    ");
   // PC --------------------------------------------------
   os << "program point: ";
   PrintPP(this->GetProgramCounter()->GetProgramPoint(), os);
   os << endl;
   // global vars --------------------------------------------------
   os << "global frames:" << endl << IncrIndent;
   const VarEnviron *genv = this->GetGlobEnviron();
   // for each mapping in the global environment
   for (VarEnviron::EnvIterator fi = genv->GetEnvIterator(),
        fn = genv->GetEnvEndIterator(); fi != fn; ++fi)
   {
      PrintFrame(fi, mem, syms, tab, itabstr);
   }
   os << tab << endl << DecrIndent;
   // call stack --------------------------------------------------
   os << "call stack:" << endl << IncrIndent;
   this->PrintCallStack(os) << DecrIndent;
   return os;
}

ostream &State::PrintCallStack(ostream &os) const
{
   if (this->IsFinalState() || this->IsBottom())
      return os;
   const CallStack *cs = this->GetCallStack();
   const Memory *mem = this->GetMemory();
   SymbolColl syms;
   TextTable tab;
   // since we are printing to a TextTable, we use spaces instead of tabs for indentation
   IndentingOStream itabstr(tab.GetStream().rdbuf(), "    ");
   CallStack::SizeType ai = 0, an = cs->Height(); // activation record indices
   for (CallStack::ConstIterator ei = cs->IterBegin(),
        en = cs->IterEnd(); ei != en; /* ++ei at end of body*/ ++ai)
   {
      os << '[' << ai << ']';
      if (ai == 0)
         os << " (bottom of stack)";
      else if (ai == an - 1)
         os << " (top of stack)";
      os << endl << IncrIndent;
      // function name
      os << "function: \"" << (*ei)->FuncName() << '"' << endl;
      // local variables
      const VarEnviron *env = (*ei)->GetEnviron();
      tab.Clear();
      if (env->GetNumMappings() > 0) {
         os << "local frames:" << endl << IncrIndent;
         VarEnviron::EnvIterator fi = env->GetEnvIterator(), fn = env->GetEnvEndIterator();
         do { PrintFrame(fi, mem, syms, tab, itabstr); ++fi; }
         while (fi != fn);
         os << tab << endl << DecrIndent;
      }
      // return information
      const RetAddrList *ret_addrs = (*ei)->GetRetAddrList();
      if (ret_addrs->size() == 1) { // usual case
         os << "return value address: " << *ret_addrs->at(0) << endl;
      } else if (ret_addrs->size() > 1) {
         os << "return value addresses:" << endl << IncrIndent;
         for (RetAddrList::const_iterator ri = ret_addrs->begin(), rn = ret_addrs->end(); ri != rn; ++ri)
            os << **ri << endl;
         os << DecrIndent;
      }
      os << "return program point: ";
      PrintPP((*ei)->GetRetProgramPoint(), os);
      ++ei;
      if (ei != en) os << endl;
      os << DecrIndent;
   }
   return os;
}

ostream &State::Draw(ostream &os) const
{
   // print the state to a buffer
   ostringstream str;
   IndentingOStream istr(str.rdbuf(), "\\ \\ \\ \\ ");
   this->Print(istr);
   string buf = str.str();
   // replace all newlines by "\l" to get left-justified text in the graph
   for (string::size_type c1 = 0;;) {
      string::size_type c2 = buf.find('\n', c1);
      if (c2 == string::npos) {
         os << buf.substr(c1, string::npos) << "\\l";
         break;
      }
      os << buf.substr(c1, c2 - c1) << "\\l";
      c1 = c2 + 1; // move past the newline
   }
   return os;
}

// - - - - - - - - - - - - - - - - -

int State::_name_int = 0;

bool State::_reuse_call_stack = true;

string State::GetNextIntName()
{
   ostringstream s;
   s << _name_int;
   ++_name_int;
   return s.str();
}

State::State(unique_ptr<ProgramCounterECFG> pc, cheap_copy<VarEnviron> genv,
             unique_ptr<Memory> mem, cheap_copy<CallStack> call_stack,
             cheap_copy<PPEnviron> pp_environ)
   : _name(GetNextIntName()),
     _is_bottom(false),
     _pc(pc.release()),
     _genv(move(genv)),
     _pp_environ(move(pp_environ)),
     _mem(mem.release()),
     _call_stack(move(call_stack))
{
   // Set state backward pointer
   _pc->SetStateBackwardPtr(this);
}

State::State(const State &other)
   : _name(GetNextIntName()),
     _is_bottom(other._is_bottom),
     _pc(other.GetProgramCounterECFG()->Copy()),
     _genv(other._genv),
     _pp_environ(other._pp_environ),
     _mem(other.GetMemory()->Copy()), 
     _call_stack(other._call_stack)
{
   assert(_pc);
   // Set state backward pointer
   _pc->SetStateBackwardPtr(this);
   if (!_reuse_call_stack)
      _call_stack.reset( other._call_stack->Copy() );
}

// Public members of MergeableStateTraits<State> ----------------------------------

const char * MergeableStateTraits<State>::GetStateName(const State & state)
{
   return state.GetName();
}

CECFGNode * MergeableStateTraits<State>::GetECFGNode(const State & state)
{
  return const_cast<CECFGNode *>(state.GetProgramCounterECFG()->GetProgramPointECFG()->GetECFGNode());
}

bool MergeableStateTraits<State>::AreMergeable(const State & state1, const State & state2)
{
   return state1.AreMergeable(&state2);
}

bool MergeableStateTraits<State>::CompareStatesIndexVecs(const State & a, const State & b)
{
   assert(a.GetProgramCounterECFG()->IsProgramCounterECFG_AE());
   assert(b.GetProgramCounterECFG()->IsProgramCounterECFG_AE());
   const ProgramCounterECFG_AE * pc_a = a.GetProgramCounterECFG()->AsProgramCounterECFG_AE();
   const ProgramCounterECFG_AE * pc_b = b.GetProgramCounterECFG()->AsProgramCounterECFG_AE();
   return pc_a->GetRecorderHolderSet()->GetScopeIndexRecorderHolder()
      ->IsLessThan(pc_b->GetRecorderHolderSet()->GetScopeIndexRecorderHolder());
}

unique_ptr<State> MergeableStateTraits<State>::MergeStates(const State & state1,
                                                         const State & state2)
{
   unique_ptr<State> merged(state1.LUB(&state2));
   return merged;
}
