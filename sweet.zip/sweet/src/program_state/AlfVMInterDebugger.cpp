#include "AlfVMInterDebugger.h"
#include "value/IntegerDomain.h"
#include "memory/MemoryDomain.h"
#include "program_counter/ProgramCounterECFG.h"
#include "ae/AEStrategy.h"
#include "program/alf/AStmt.h"
#include "program/alf/CLabelTuple.h"
#include "program/alf/CLRefTuple.h"
#include "program/alf/CIntNumValTuple.h"
#include "program/alf/CNumber.h"
#include "program_state/CallStack.h"
#include "program_state/State.h"
#include "program_state/value/ValueDomain.h"
#include "program_state/value/Value.h"
#include "program_state/memory/Memory.h"
#include "tools/IndentingOStream.h"
#include "tools/TextTable.h"
#include "tools/RangeIterator.h"
#include "macros.h"
#include "globals.h"
#include <sstream>
#include <algorithm>
#include <functional>
#include <cstring>
#include <iterator>
#include <limits>
#include <iomanip>

using namespace std;
using namespace alf;

void InterDebuggerState::HandleInterrupt(AlfVMInterDebugger & debugger)
{
   debugger.ChangeStateToAcceptCommands();
}

// Public members of AlfVMInterDebugger -----------------------------

AlfVMInterDebugger::
AlfVMInterDebugger(const AEStrategy<State> & ae_strategy)
: proceed_state(), acc_comms_state(proceed_state, ae_strategy),
  state(&acc_comms_state), sigint_handler(this)
{
   SignalHandling::RegisterSIGINTHandler(&sigint_handler);
}

void AlfVMInterDebugger::
Statement(const alf::AStmt * stmt, const State * state)
{
   do ; while (AlfVMInterDebugger::state->Prompt(stmt, state, *this));
}

void AlfVMInterDebugger::RecordPerformedMerge(const State & a, const State & b,
                                                      const State & merged)
{
   state->RecordPerformedMerge(a, b, merged);
}

std::ostream & AlfVMInterDebugger::PrintStmtCoord(const AStmt & stmt, std::ostream & o)
{
   o << stmt.GetLine() << ":" << stmt.GetColumn();
   if (!stmt.HasInternalGeneratedLabel())
   {
      const CLabelTuple * stmts_label = stmt.GetLabel();
      o << ", (\"" << stmts_label->GetLRef()->GetId()
         << "\"," << stmts_label->GetOffset()->GetNumber()->GetValueAsBignum().get_str() 
         << ")";
   }      
   return o << " (" << stmt.StatementTypeName() << ")";
}

// Protected members of AlfVMInterDebugger --------------------------

void AlfVMInterDebugger::ChangeState(InterDebuggerState * new_state)
{
   state->Deactivate();
   state = new_state;
   state->Activate();
}

void AlfVMInterDebugger::HandleInterrupt()
{
   state->HandleInterrupt(*this);
}

// Public members of AlfVMInterDebugger::SIGINTHandler --------------------

void AlfVMInterDebugger::SIGINTHandler::operator()(int parameter)
{
   debugger->HandleInterrupt();
}

// Protected members of AcceptCommands::Command -------------------------------

bool AcceptCommands::Command::CheckCommandLine(const std::vector<std::string> & command_line, 
                                               const std::string & long_cmd_name, const std::string& short_cmd_name, 
                                               int nr_arguments)
{
   // Ignore empty command lines
   if (command_line.empty()) return false;

   // Make the expected command name lower-case
   string long_cmd_name_, short_cmd_name_;
   transform(long_cmd_name.begin(), long_cmd_name.end(), 
      back_inserter(long_cmd_name_), ptr_fun<int, int>(&tolower));
   transform(short_cmd_name.begin(), short_cmd_name.end(), 
      back_inserter(short_cmd_name_), ptr_fun<int, int>(&tolower));

   // Make the first word of the command line lower-case
   string first_word;
   transform(command_line.front().begin(), command_line.front().end(), 
      back_inserter(first_word), ptr_fun<int, int>(&tolower));
   
   if (first_word != long_cmd_name_ && first_word != short_cmd_name_) 
      return false;

   // Check the number of arguments
   if (int(command_line.size()) - 1 != nr_arguments)
   {
      ostringstream message("The command ");
      message << command_line.front() << " expects " << nr_arguments
              << " arguments";
      throw FailedCommand(message.str());
   }
   return true;
}


// AcceptCommands::Command subclasses (used below by AcceptCommands) -------------------------------

class Help : public AcceptCommands::Command
{
public:
   Help(const std::vector<Command *> & commands)
      : commands(commands)
   {}

   virtual int CarryOut(const std::vector<std::string> & command_line,
                        const alf::AStmt * stmt, const State * state,
                        AlfVMInterDebugger & debugger)
   {
      if (!CheckCommandLine(command_line, LongName(), ShortName(), 0))
         return 0;
      cout << "Available debugger commands (all commands are case-insensitive):" << endl
           << "----------------------------------------------------------------" << endl;
      TextTable cmdtab;
      for (RangeIterator<const vector<Command*> > c(commands); c; ++c) {
         cmdtab.GetStream() << string((*c)->LongName()) + '/' + (*c)->ShortName();
         cmdtab.NextColumn();
         cmdtab.GetStream() << (*c)->Description();
         cmdtab.NextRow();
      }
      cout << cmdtab << endl;
      return 1;
   }

   virtual const char * LongName() const {return "Help";}

   virtual const char * ShortName() const {return "h";}

   virtual const char * Description() const {return "List all available debugger commands";}

private:
   const std::vector<Command *> & commands;
};

class QuitProgram : public AcceptCommands::Command
{
public:
   virtual int CarryOut(const std::vector<std::string> & command_line,
                        const alf::AStmt * stmt, const State * state,
                        AlfVMInterDebugger & debugger)
   {
      if (!CheckCommandLine(command_line, LongName(), ShortName(), 0))
         return 0;
      cout << "Premature termination..." << endl;
      exit(0);
      return -1;
   }

   virtual const char * LongName() const {return "Quit";}

   virtual const char * ShortName() const {return "q";}

   virtual const char * Description() const {return "Terminate the ALF program";}
};

class Resume : public AcceptCommands::Command
{
public:
   virtual int CarryOut(const std::vector<std::string> & command_line,
                        const alf::AStmt * stmt, const State * state,
                        AlfVMInterDebugger & debugger)
   {
      if (!CheckCommandLine(command_line, LongName(), ShortName(), 0))
         return 0;

      debugger.ChangeStateToProceed();
      return -1;
   }

   virtual const char * LongName() const {return "Run";}

   virtual const char * ShortName() const {return "r";}

   virtual const char * Description() const {return "Resume execution of the ALF program";}
};

class Stmt : public AcceptCommands::Command
{
public:
   virtual int CarryOut(const std::vector<std::string> & command_line, 
                        const alf::AStmt * stmt, const State * state,
                        AlfVMInterDebugger & debugger)
   {
      if (!CheckCommandLine(command_line, LongName(), ShortName(), 0))
         return 0;
      stmt->PrintWithEndl(cout);
      return 1;
   }

   virtual const char * LongName() const {return "Stmt";}

   virtual const char * ShortName() const {return "stm";}

   virtual const char * Description() const {return "Print the current ALF statement";}
};

class StepCommand : public AcceptCommands::Command
{
public:
   virtual int CarryOut(const std::vector<std::string> & command_line, 
                        const alf::AStmt * stmt, const State * state,
                        AlfVMInterDebugger & debugger)
   {
      if (!CheckCommandLine(command_line, LongName(), ShortName(), 0))
         return 0;
      return -1;
   }

   virtual const char * LongName() const {return "Step";}

   virtual const char * ShortName() const {return "s";}

   virtual const char * Description() const {return "Step to the next statement";}
};

class PrintCallStack : public AcceptCommands::Command
{
public:
   virtual int CarryOut(const std::vector<std::string> & command_line, 
                        const alf::AStmt * stmt, const State * state,
                        AlfVMInterDebugger & debugger)
   {
      if (!CheckCommandLine(command_line, LongName(), ShortName(), 0))
         return 0;
      PrintTheCallStack(*state);      
      return 1;
   }

   void PrintTheCallStack(const State & state) const
   {
      IndentingOStream iout(cout.rdbuf());
      state.PrintCallStack(iout) << endl;
   }

   virtual const char * LongName() const {return "BackTrace";}

   virtual const char * ShortName() const {return "bt";}

   virtual const char * Description() const {return "Print out the call stack (bottom to top) including the local variables";}
};

class Show : public AcceptCommands::Command
{
   /** Performs a (linear) search for a frame with annotation ann in the environment env. If such
       a frame is found, its contents are returned; otherwise, 0 is returned. */
   Value* Lookup(const string &ann, const State *state, const VarEnviron *env)
   {
      SymbolColl syms;
      // iterate through all frames mapped to in the environment
      for (VarEnviron::EnvIterator i = env->GetEnvIterator(), n = env->GetEnvEndIterator(); i != n; ++i)
      {
         // fetch the symbol part of the frame pointer
         const SymbPointer *ptr = i->second.GetBasePointer()->AsSymbPointer();
         if (ptr == 0) continue; // no symbols or annotations can be retrieved
         syms.clear();
         ptr->GetSymbols(syms);
         // if the symbol's annotation is a match, return the contents of the frame
         if (syms.begin()->GetAnnot() == ann)
            return state->GetMemory()->Load(ptr, i->second.GetAmountAllocated());
      }
      return 0;
   }

public:
   virtual int CarryOut(const std::vector<std::string> & command_line, 
                        const alf::AStmt * stmt, const State * state,
                        AlfVMInterDebugger & debugger)
   {
      if (!CheckCommandLine(command_line, "show", "sh", 1)) return 0;
      // start by searching the local environment
      unique_ptr<Value> contents( Lookup(command_line[1], state, state->GetEnviron()) );
      // if nothing was found, search the global environment
      if (contents.get() == 0) contents.reset( Lookup(command_line[1], state, state->GetGlobEnviron()) );
      if (contents.get() == 0)
         throw AcceptCommands::FailedCommand(string("No frame named \"") + command_line[1] + "\" was found");
      IndentingOStream iout(cout.rdbuf());
      iout << *contents << endl;
      return 1;
   }
   
   virtual const char * LongName() const {return "Show <n>";}

   virtual const char * ShortName() const {return "sh <n>";}

   virtual const char * Description() const {return "Shows the contents of the frame \"n\" in the current state and scope";}
};

class SetBreakpoint : public AcceptCommands::Command
{
public:
   SetBreakpoint(Proceed & proceed_state)
      : proceed_state(proceed_state)
   {
      str2stmt_type["null"] = CGenericStmt::GS_SKIP;
      str2stmt_type["store"] = CGenericStmt::GS_STORE;
      str2stmt_type["switch"] = CGenericStmt::GS_COND;
      str2stmt_type["jump"] = CGenericStmt::GS_JUMP;
      str2stmt_type["call"] = CGenericStmt::GS_CALL;
      str2stmt_type["return"] = CGenericStmt::GS_RETURN;
      str2stmt_type["free"] = CGenericStmt::GS_FREE;
   }

   virtual int CarryOut(const std::vector<std::string> & command_line, 
                        const alf::AStmt * stmt, const State * state,
                        AlfVMInterDebugger & debugger)
   {
      if (!CheckCommandLine(command_line, "breakpt", "bp", 1))
         return 0;

      // Check if the specified breakpoint is a line number or not
      for (string::size_type c = 0, l = command_line[1].length(); c < l; ++c)
      {
         // Not a line number - parse it as a statement type and add it to the
         // statement type breakpoints
         if (!isdigit(command_line[1][c]))
         {
            proceed_state.AddStmtTypeBP(ParseStmtType(command_line[1]));
            return 1;
         }
      }

      // Line number - add it to the line number breakpoints
      int line = atoi(command_line[1].c_str());
      proceed_state.AddBreakpoint(line);
      return 1;
   }

   virtual const char * LongName() const {return "BreakPt <p>";}

   virtual const char * ShortName() const {return "bp <p>";}

   virtual const char * Description() const
   {
      return "Set a breakpoint at p, where p is either a line number or "
         "a statement type";
   }

private:
   Proceed & proceed_state;

   map<string, CGenericStmt::GS_TYPE> str2stmt_type;

   CGenericStmt::GS_TYPE ParseStmtType(string type_str)
   {
      transform(type_str.begin(), type_str.end(), 
         type_str.begin(), ptr_fun<int, int>(&tolower));
      map<string, CGenericStmt::GS_TYPE>::iterator s = str2stmt_type.find(type_str);
      if (s == str2stmt_type.end())
         throw runtime_error(type_str + " is not a valid statement type");
      return s->second;
   }
};

class ClearBreakpoints : public AcceptCommands::Command
{
public:
   ClearBreakpoints(Proceed & proceed_state)
      : proceed_state(proceed_state)
   {
   }

   virtual int CarryOut(const std::vector<std::string> & command_line, 
                        const alf::AStmt * stmt, const State * state,
                        AlfVMInterDebugger & debugger)
   {
      if (!CheckCommandLine(command_line, LongName(), ShortName(), 0))
         return 0;

      proceed_state.ClearBreakpoints();
      return 1;
   }

   virtual const char * LongName() const {return "ClearBPs";}

   virtual const char * ShortName() const {return "cb";}

   virtual const char * Description() const {return "Clear all breakpoints";}

private:
   Proceed & proceed_state;
};

class PrintStates : public AcceptCommands::Command
{
private:
   class StatePrinter
   {
   public:
      StatePrinter(ostream & o)
         : o(o) {}

      void operator ()(const State * state)
      {
         const AStmt & stmt = dynamic_cast<const AStmt &>(
            *state->GetProgramCounter()->GetProgramPoint()->GetStmt());
         AlfVMInterDebugger::PrintStmtCoord(stmt, o) << ":\tState \"" 
            << state->GetName() << "\"" << endl;
      }

   private:
      ostream & o;
   }; 

   const AEStrategy<State> & ae_strategy;

public:
   PrintStates(const AEStrategy<State> & ae_strategy)
      : ae_strategy(ae_strategy) {}

   virtual int CarryOut(const std::vector<std::string> & command_line, 
                        const alf::AStmt * stmt, const State * state,
                        AlfVMInterDebugger & debugger)
   {
      if (!CheckCommandLine(command_line, LongName(), ShortName(), 0))
         return 0;

      // Get lists of states from the AE strategy
      vector<const State *> active_states, waiting_states;
      ae_strategy.GetStates(active_states, waiting_states);
      active_states.push_back(&dynamic_cast<const State &>(*state));

      // Print out active states
      IndentingOStream iout(cout.rdbuf());
      iout << "Active states (" << active_states.size() << " states):" << IncrIndent << endl;
      for_each(active_states.begin(), active_states.end(), StatePrinter(iout));
      iout << DecrIndent;

      // Print out states waiting at merge points
      if (waiting_states.empty())
         iout << "(No states waiting at merge points)" << endl;
      else
      {
         iout << "States waiting at merge points (" << waiting_states.size() << " states):"
            << endl << IncrIndent;
         for_each(waiting_states.begin(), waiting_states.end(), StatePrinter(iout));
         iout << DecrIndent;
      }
      return 1;
   }

   virtual const char * LongName() const {return "States";}

   virtual const char * ShortName() const {return "sts";}

   virtual const char * Description() const {return "Print summary of current program states";}
};

class PrintStateByName : public AcceptCommands::Command
{
private:
   const AEStrategy<State> & ae_strategy;

   const State* FindStateByName(const std::string& name, const State* current_state)
   {
      if (current_state->GetName() == name)
         return current_state;
      return ae_strategy.GetStateByName(name);
   }

public:
   PrintStateByName(const AEStrategy<State> & ae_strategy)
      : ae_strategy(ae_strategy) {}

   virtual int CarryOut(const std::vector<std::string> & command_line, 
                        const alf::AStmt * stmt, const State * state,
                        AlfVMInterDebugger & debugger)
   {
      if (!CheckCommandLine(command_line, "state", "sta", 1))
         return 0;

      const State* state_with_name = FindStateByName(command_line[1], state);
      if (state_with_name == 0)
      {
         ostringstream message("There is no state named \"");
         message << command_line[1] << "\"";
         throw AcceptCommands::FailedCommand(message.str());
      }
      IndentingOStream iout(cout.rdbuf());
      iout << "State \"" << command_line[1] << "\":" << endl 
           << IncrIndent << *state_with_name << endl << DecrIndent;
      return 1;
   }

   virtual const char * LongName() const {return "State <n>";}

   virtual const char * ShortName() const {return "sta <n>";}

   virtual const char * Description() const {return "Print information about state \"n\"";}
};

class StartMonitoringStackHeight : public AcceptCommands::Command
{
public:
   virtual int CarryOut(const std::vector<std::string> & command_line, 
                        const alf::AStmt * stmt, const State * state,
                        AlfVMInterDebugger & debugger)
   {
      if (!CheckCommandLine(command_line, LongName(), ShortName(), 0))
         return 0;

      debugger.ChangeStateToMonitorStackHeight();
      return -1;
   }

   virtual const char * LongName() const {return "StackHeight";}

   virtual const char * ShortName() const {return "sth";}

   virtual const char * Description() const {return "Start monitoring call stack height";}
};

// Public members of Proceed ----------------------------------------------

bool Proceed::Prompt(const alf::AStmt * stmt, const State * state,
                     AlfVMInterDebugger & debugger)
{
   int line_nr = stmt->GetLine();
   if (breakpoints.find(line_nr) != breakpoints.end() ||
      stmt_type_bps.find(stmt->Type()) != stmt_type_bps.end())
   {
      cout << "Reached a breakpoint" << endl;
      debugger.ChangeStateToAcceptCommands();
      return true;
   }   
   return false;
}

// Public members of AcceptCommands ---------------------------------------

AcceptCommands::AcceptCommands(Proceed & proceed_state, 
                               const AEStrategy<State> & ae_strategy)
{
   commands.push_back(new Help(commands));
   commands.push_back(new Stmt);
   commands.push_back(new PrintCallStack);
   commands.push_back(new Show);
   commands.push_back(new PrintStates(ae_strategy));
   commands.push_back(new PrintStateByName(ae_strategy));
   commands.push_back(new StepCommand);
   commands.push_back(new Resume);
   commands.push_back(new SetBreakpoint(proceed_state));
   commands.push_back(new ClearBreakpoints(proceed_state));
   commands.push_back(new StartMonitoringStackHeight);
   commands.push_back(new QuitProgram);
}

AcceptCommands::~AcceptCommands()
{
   for_each(commands.begin(), commands.end(), Deleter());
}

bool AcceptCommands::Prompt(const alf::AStmt * stmt, const State * state,
                            AlfVMInterDebugger & debugger)
{
   cout << stmt->StatementTypeName() << " on " << stmt->GetLine() 
        << ":" << stmt->GetColumn();
   if (!stmt->HasInternalGeneratedLabel())
   {
      const CLabelTuple * stmts_label = stmt->GetLabel();
      cout << ", (\"" << stmts_label->GetLRef()->GetId()
         << "\"," << stmts_label->GetOffset()->GetNumber()->GetValueAsBignum().get_str()
         << ")";
   }
   cout << " in state \"" << state->GetName() << "\"" << endl << "> ";
   char command_line[1000];
   cin.getline(command_line, sizeof(command_line) / sizeof(char));
   std::vector<string> command_line_;
   istringstream is(command_line);
   copy(istream_iterator<string>(is),
        istream_iterator<string>(),
        back_inserter<vector<string> >(command_line_));
   try
   {
      return CarryOutCommand(command_line_, stmt, state, debugger);
   }
   catch (FailedCommand & fc)
   {
      cerr << "Command failed: " << fc.what() << ". Try again." << endl;
      return true;
   }
   return false;
}

void AcceptCommands::RecordPerformedMerge(const State & a, const State & b,
                                          const State & merged)
{
   const AStmt& stmt = dynamic_cast<const AStmt &>(*a.GetProgramCounter()->GetProgramPoint()->GetStmt());
   cout << "States \"" << a.GetName() << "\" and \"" << b.GetName() << "\" merged on ";
   AlfVMInterDebugger::PrintStmtCoord(stmt, cout) 
      << ", resulting in the state \"" << merged.GetName() << "\"" << endl;
}

void AcceptCommands::HandleInterrupt(AlfVMInterDebugger & debugger)
{
   exit(0);
}

// Private members of AcceptCommands ---------------------------------------------

bool AcceptCommands::CarryOutCommand(const std::vector<string> & command_line,
                                     const alf::AStmt * stmt, const State * state,
                                     AlfVMInterDebugger & debugger)
{
   if (command_line.empty())
      return true;
   for (vector<Command *>::iterator c = commands.begin();
        c != commands.end(); ++c)
   {
      switch ((*c)->CarryOut(command_line, stmt, state, debugger))
      {
      case -1:
         return false;
         break;
      case 0:
         continue;
         break;
      case 1:
         return true;
         break;
      }
   }
   ostringstream message;
   message << "Command '" << command_line.front() << "' is not recognized";
   throw FailedCommand(message.str());
}

// Public members of MonitorStackHeight -------------------------------

void MonitorStackHeight::Activate()
{
   min_height = numeric_limits<int>::max();
   max_height = numeric_limits<int>::min();
   Proceed::Activate();
}

void MonitorStackHeight::Deactivate()
{
   cout << "Maximum height: " << max_height << ", minimum height: " << min_height << endl;
   Proceed::Deactivate();
}

bool MonitorStackHeight::Prompt(const alf::AStmt * stmt, const State * state,
                                AlfVMInterDebugger & debugger)
{
   int height = int(state->GetCallStack()->Height());
   min_height = min(min_height, height);
   max_height = max(max_height, height);
   return Proceed::Prompt(stmt, state, debugger);
}
