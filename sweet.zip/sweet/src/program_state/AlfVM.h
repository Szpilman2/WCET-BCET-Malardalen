#ifndef ALFVM_H_INCLUSION
#define ALFVM_H_INCLUSION

#include "AlfVMDebugger.h"

#include <memory>
#include <vector>
#include <list>
#include <map>

class State;
class Value;
class CALFAbsAnnotStorage;
class CALFAbsAnnot;
class CALFOutAnnotSpecStorage;
class CALFOutAnnotSpec;
class AESettings;
class CSourceLoader;
template <typename> class AEStrategy;

namespace alf {
class AStmt;
class CNullStmtTuple;
class CStoreStmtTuple;
class CJumpStmtTuple;
class CSwitchStmtTuple;
class CCallStmtTuple;
class CReturnStmtTuple;
class CFreeStmtTuple;
class CScopeTuple;
class CFuncTuple;
class AExpr;
class ANumVal;
class CIntNumValTuple;
class CFloatValTuple;
class CFRefTuple;
class CAddrTuple;
class CCompAddrTuple;
class CLRefTuple;
class CLabelTuple;
class CCompLabelTuple;
class CLoadExprTuple;
class CDynAllocTuple;
class COpNumExprTuple;
class CUndefinedExprTuple;
class CUnknownExpr;
class CAlfTuple;
class CImportsTuple;
class CDeclList;
class CInitList;
class CExprList;
class CString;
}

/** Virtual machine for abstract execution of ALF programs */
class AlfVM
{
   friend class ExprLeaf;
   friend class LoadLeaf;

public:
   AlfVM();
   virtual ~AlfVM();

   /** Set abstract annotations to use in the analysis */
   void SetAbsAnnots(CALFAbsAnnotStorage * abs_annots)
      { this->abs_annots = abs_annots; }

   void SetOutAnnotSpecs(CALFOutAnnotSpecStorage * out_ann_specs)
      { this->out_ann_specs = out_ann_specs; }

   /** Set the debugger to use */
   void SetDebugger(AlfVMDebugger * debugger)
      { this->debugger = debugger; }

   void SetSourceLoader(const CSourceLoader *source_loader)
      { this->source_loader = source_loader; }

   /** Enables or disables the "call stack hack". When disabled (default), the environment in the
       top stack frame is used to map variables to memory locations. When enabled, the environment
       in the stack frame immediately below the top is used instead. This feature is used by some
       analyses that need to evaluate expressions that provide the arguments to the current function
       (these expressions may reference variables declared in the calling function, which are not
       visible in the current function). */
   void SetCallStackHack(bool enabled) { cshack = enabled; }

   /** Initialize the state @p state to make it ready to be updated by running the
       program @p program, where @p start_function is the entry function. @p ignore_volatile
       determines whether the "volatile" property on frames should be ignored or not. */
   virtual void InitializeState(const alf::CAlfTuple * program, const alf::CFuncTuple * start_function, State * state, bool ignore_volatile) const;

   /** Execute the ALF statement at the current program point in the state @p state.
       The resulting state(s) will be returned in @p next_states. */
   virtual void StepStmt(std::unique_ptr<State> initial_state, std::vector<State *> & next_states);

   /** Update @p state repeatedly until the end of the current basic block has been reached, i.e.,
      until the last statement of the current basic block has been executed. After the call,
      @p next_states will hold the resuling state(s). */
   void StepBB(std::unique_ptr<State> state, std::vector<State*> & next_states, const AESettings *settings);

   /** Execute @p state till termination. @p final_states will hold the final states after the call. */
   void ExecuteTillTermination(std::unique_ptr<State> state, std::vector<State *> & final_states,
                               AEStrategy<State> & strategy, 
                               const AESettings * settings,
                               std::stringstream & bbt);

   /** Performs a (linear) search for a base pointer with annotation ann in the
       environment env.  If no such base pointer is found, 0 is returned. */
   static const Value *Lookup(const VarEnviron *env, const std::string &ann);

private:
   /** Silent debugger, used when no other debugger has been specified */
   static AlfVMDebugger silent_debugger;
   
   /** Abstract ALF annotations */
   CALFAbsAnnotStorage * abs_annots;
   CALFOutAnnotSpecStorage * out_ann_specs;
 
   /** A debugger to report to */
   AlfVMDebugger * debugger;
   const CSourceLoader *source_loader;

   bool cshack;

   typedef std::map<CALFOutAnnotSpec *, std::list<Value *>, bool(*)(CALFOutAnnotSpec *, CALFOutAnnotSpec *)> OutAnnotsValuesMap;

   /** @note This container is cleared in ~AlfVM() */
   OutAnnotsValuesMap out_annots_values_map;
   
   typedef std::vector< EInt<long long> > BitIntervalLimits;
   typedef std::pair<BitIntervalLimits, BitIntervalLimits> BitIntervals;
   typedef std::map<std::string, BitIntervals> Targets;

   /** @note Deleted in ~AlfVM() */
   Targets * global_targets;

   bool _allow_call_site_return_addresses_different_from_return_values;

   /** Get the debugger to report to */
   AlfVMDebugger * GetAEDebugger() const;

   /** Reports to stdout that an invalid state is being discarded */
   void ReportDiscardedState(const State &discarded) const;

   /** Go through all imported frame references (which reference undefined frames) in @p imports
       and allocate frames of infinite size for them. This is useful for being able to execute unlinked
       ALF code. */
   void HandleUnresolvedGlobals(const alf::CImportsTuple * imports, State * state) const;

   /** Update the variable environment @p env and the memory @p mem according to
       the declaration list @p decls and the initialization list @p inits */
   void HandleDeclsAndInits(const alf::CDeclList * decls, const alf::CInitList * inits, VarEnviron * env, 
                            Memory * mem, State * state, bool ignore_volatile) const;

   /** Called when entering the first function in the analysis. This
      function will not have any actual input argument to be evaluated
      and stored at the addresses of the formal input arguments. Moreover, 
      frames that store the function's return parameters must be created. */
   void EnterFirstFunction(const alf::CFuncTuple * function, State * state) const;

   /** Update state by entering function
       @returns Whether entering the function succeeded or not, i.e., whether the updated
                state is valid */
   bool EnterFunction(const alf::CFuncTuple * function, std::unique_ptr<ProgramPoint> func_entry_pp, 
                      const alf::CExprList * arg_exprs, const alf::CExprList * ret_addr_expr_list, 
                      State * state, const alf::CCallStmtTuple * call_stmt) const;

   /** Create a final program point, which is the program point eventually reached
       in a successful execution of the ALF program */
   std::unique_ptr<ProgramPoint> CreateFinalProgramPoint() const; 

   /** @name Stepping of statements
       @{ */
   /** Step a "null" statement in program state @p state. Afterwards, @p next_states will contain the updated program state. */
   void StepStmtNull(const alf::CNullStmtTuple *null_stmt, std::unique_ptr<State> state, std::vector<State *> & next_states) const;
   
   /** Step a "store" statement in program state @p state. Afterwards, @p next_states will contain the updated program state(s). */
   void StepStmtStore(const alf::CStoreStmtTuple *store_stmt, std::unique_ptr<State> state,
                      std::vector<State *> & next_states) const;
   
   /** Step a "jump" statement in program state @p state. Afterwards, @p next_states will contain the resulting program state(s). */
   void StepStmtJump(const alf::CJumpStmtTuple * jump_stmt, std::unique_ptr<State> state, std::vector<State *> & next_states) const;

   /** Step a "switch" statement in program state @p state. Afterwards, @p next_states will contain the resulting program state(s). */
   void StepStmtSwitch(const alf::CSwitchStmtTuple * switch_stmt, std::unique_ptr<State> state, std::vector<State *> & next_states) const;

   /** Step a "call" statement in program state @p state. Afterwards, @p next_states will contain the updated program state. */
   void StepStmtCall(const alf::CCallStmtTuple *call_stmt, std::unique_ptr<State> state, std::vector<State *> & next_states) const;
   
   /** Step a "return" statement in program state @p state. Afterwards, @p next_states will contain the updated program state. */
   void StepStmtReturn(const alf::CReturnStmtTuple *return_stmt, std::unique_ptr<State> state, std::vector<State *> & next_states) const;
   
   /** Step a "free" statement in program state @p state. Afterwards, @p next_states will contain the updated program state. */
   void StepStmtFree(const alf::CFreeStmtTuple *free_stmt, std::unique_ptr<State> state, std::vector<State *> & next_states) const;
   /** @} */

   /** @name Expression evaluation
       @{ */
   /** Evaluate the expression \p expr in state \p state. The state may be updated by
       expressions containing dyn_alloc expressions which allocate more frames in memory.
       @return A pointer to the resulting value
       @note The returned pointer should be deleted by the caller */
   Value * EvalExpr(const alf::AExpr *expr, State *state) const;

   /** @note The returned pointer should be deleted by the caller */
   Value * EvalExprOp(const alf::COpNumExprTuple *op_expr, State *state) const;

   /** @note The returned pointer should be deleted by the caller */
   Value * EvalExprNumValInt(const alf::CIntNumValTuple *num_val_int_expr) const;
   /** @note The returned pointer should be deleted by the caller */
   Value * EvalExprNumValFloat(const alf::CFloatValTuple *num_val_float_expr) const;
   /** @note The returned pointer should be deleted by the caller */
   Value * EvalExprFRef(const alf::CFRefTuple *fref_expr, State *state) const;
   /** @note The returned pointer should be deleted by the caller */
   Value * EvalExprAddr(const alf::CAddrTuple *addr_expr, State *state) const;
   /** @note The returned pointer should be deleted by the caller */
   Value * EvalExprCompAddr(const alf::CCompAddrTuple *comp_addr_expr, State *state) const;
   /** @note The returned pointer should be deleted by the caller */
   Value * EvalExprLRef(const alf::CLRefTuple *lref, State *state) const;
   /** @note The returned pointer should be deleted by the caller */
   Value * EvalExprLabel(const alf::CLabelTuple *label_expr, State *state) const;
   /** @note The returned pointer should be deleted by the caller */
   Value * EvalExprCompLabel(const alf::CCompLabelTuple *comp_label_expr, State *state) const;
   /** @note The returned pointer should be deleted by the caller */
   Value * EvalExprLoad(const alf::CLoadExprTuple *load_expr, State *state) const;
   /** @note The returned pointer should be deleted by the caller */
   Value * EvalExprDynAlloc(const alf::CDynAllocTuple *dyn_alloc_expr, State *state) const;
   /** @note The returned pointer should be deleted by the caller */
   Value * EvalExprUndefined(const alf::CUndefinedExprTuple *undefined_expr, State *state) const;
   /** @} */
   
   const alf::CScopeTuple * GetScope(State * state, const alf::CAlfTuple * ast) const;

   /** @name Input annotations
       @{ */
   void HandleProgEntryALFAbsAnnot(State *state) const;
   void HandleFuncEntryALFAbsAnnot(const alf::CFuncTuple * func, State *state) const;
   void HandleStmtEntryALFAbsAnnot(const alf::AStmt * stmt, State *state) const;
   void HandleStmtExitALFAbsAnnot(const alf::AStmt * stmt, std::vector<State*> &next_states) const;

   /** Update @p state as specified by @p annot */
   void UpdateStateAccordingToAnnot(State * state, CALFAbsAnnot * annot) const;
   /** @} */

   /** @name Output annotations
       @{ */
   void HandleStmtEntryALFOutAnnotSpec(const alf::AStmt * stmt, const State *state);
   void HandleStmtExitALFOutAnnotSpec(const alf::AStmt * stmt, const std::vector<State*> &next_states);

   /** Print the value in @p state as specified by @p out annot spec */
   void HandleALFOutAnnotSpec(const State * state, CALFOutAnnotSpec * annot);
   
   CALFAbsAnnot * TransformValueToAnnot(const CALFOutAnnotSpec *, const std::list<Value *> *) const;
   /** @} */
};

#endif   // ALFVM_H_INCLUSION
