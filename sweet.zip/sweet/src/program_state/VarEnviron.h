#ifndef VARENVIRON_H_INCLUDED
#define VARENVIRON_H_INCLUDED

#include "Size.h"
#include "value/Value.h"
#include "symtab/CSymTabBase.h"
#include <map>
#include <memory>
#include <ostream>

class VariableInfo
{
public:
   VariableInfo(Value * base_ptr, Size amount_allocated)
      : amount_allocated(amount_allocated), base_ptr(base_ptr) {}

   VariableInfo DeepCopy() const {return VariableInfo(GetBasePointer()->Copy(), GetAmountAllocated());}

   template <typename Op> VariableInfo Combine(const VariableInfo& other, const Op& op) const;

   void CleanUp();

   const Value * GetBasePointer() const {return base_ptr;}

   /** Returns the size of the variable (frame) in bits */
   Size GetAmountAllocated() const {return amount_allocated;}

   bool operator ==(const VariableInfo & other) const;
 
   bool operator !=(const VariableInfo & other) const
      {return !(*this == other);}

private:
   Size amount_allocated;
   Value * base_ptr;
};

/** Variable environment mapping identifiers (AST keys) to values which can be
    used as memory addresses. */
class VarEnviron : private std::map<unsigned, VariableInfo>
{
public:
   typedef const_iterator EnvIterator;

   VarEnviron() {}

   VarEnviron(const VarEnviron & other);

   ~VarEnviron();

   bool IsEqual(const VarEnviron * other) const;

   /** @return @c true if there is a mapping from @a id to some base pointer, @c false otherwise */
   bool Defined(unsigned id) const;

   /** @return @c true if there is a mapping to @a base_ptr from some id, @c false otherwise */
   bool Defined(const Value * base_ptr) const;

   /** Retrieve the base pointer that is associated with @a id
       @return The base pointer if there is an base pointer associated with @a id, 0 otherwise
       @note The returned pointer should be deleted by the caller */
   Value * ApplyEnvFunction(unsigned id) const;

   /** Return the amount of memory, in bits, that was allocated for 
       the variable associated in this environment with @a id */
   Size GetAmountAllocated(unsigned id) const;

   /** Add a mapping from @a id to @a base_ptr, which points to an allocation of
       @a amount_allocated bits */
   void Update(unsigned id, std::unique_ptr<Value> base_ptr, Size amount_allocated);

   int GetNumMappings() const { return (int)size(); }

   EnvIterator GetEnvIterator() const {return begin();}

   EnvIterator GetEnvEndIterator() const {return end();}
};

#endif   // #ifndef VARENVIRON_H_INCLUDED
