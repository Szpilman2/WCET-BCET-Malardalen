#include "PPEnviron.h"
#include "program_counter/ProgramCounterECFG.h"
#include "program_counter/ProgramPointECFG.h"
#include "value/SymbIntervalPtrSet.h"
#include "graphs/ecfg/CECFGNode.h"
#include "program/alf/CAlfTuple.h"
#include "program/alf/CImportsTuple.h"
#include "program/alf/CFuncTuple.h"
#include "program/alf/CFuncList.h"
#include "program/alf/CScopeTuple.h"
#include "program/alf/CStmtList.h"
#include "program/alf/CLRefList.h"
#include "program/alf/CLRefTuple.h"
#include "program/alf/CLabelTuple.h"
#include "program/alf/CNumber.h"
#include "tools/Integer.h"
#include <set>
#include <sstream>

using namespace std;
using namespace alf;

PPEnviron::PPEnviron(const alf::CAlfTuple & program)
{
   LabelColl collected_labels;
   CodeIDToLRef code_id_to_lref;
   CodeIDToFuncRef code_id_to_func_ref;

   // Run through all function definitions in the program
   const CFuncList * funcs = program.GetFuncs();
   for (CFuncList::const_list_iterator f = funcs->ConstIterator();
        f != funcs->InvalidIterator(); ++f)
   {
      // Retrieve some information about the function
      const CLabelTuple * func_label = (*f)->GetLabel();
      const CLRefTuple * func_lref = func_label->GetLRef();
      string func_lref_id = func_lref->GetId();
      FuncRef & func_ref = code_id_to_func_ref[func_lref_id];

      // Add a coupling from the (fref, offset) pair to the function
      Integer offset = func_label->GetOffset()->GetNumber()->GetValueAsBignum();
      AddrOffset offset_ = offset.As<AddrOffset>();
      FuncSet::iterator offset_mapping = func_ref.first.find(offset_);
      if (offset_mapping != func_ref.first.end())
      {
         ostringstream msg;
         msg << "Construction of program point environment failed: the label ("
            << func_lref_id << ", " << offset_ << ") on line " << func_label->GetLine()
            << " has already been used by the function defined on line "
            << offset_mapping->second->GetLine() << '.';
         throw runtime_error(msg.str());
      }
      func_ref.first[offset_] = *f;
      func_ref.second.push_back(func_lref->GetKey());
      ProcessStmts(*(*f)->GetScope()->GetStmts(), collected_labels, code_id_to_lref);
   }
   for (CodeIDToFuncRef::iterator m = code_id_to_func_ref.begin();
        m != code_id_to_func_ref.end(); ++m)
   {
      FuncRef & func_ref = m->second;
      func_sets.push_back(new FuncSet(func_ref.first));
      for (ASTKeySet::iterator k = func_ref.second.begin();
           k != func_ref.second.end(); ++k)
      {
         ast_key_to_func_set[*k] = func_sets.back();
      }
   }
   for (CodeIDToLRef::iterator m = code_id_to_lref.begin();
        m != code_id_to_lref.end(); ++m)
   {
      LRef & lref = m->second;
      addr_sets.push_back(new AddrSet(lref.first));
      for (ASTKeySet::iterator k = lref.second.begin();
           k != lref.second.end(); ++k)
      {
         ast_key_to_addr_set[*k] = addr_sets.back();
      }
   }
   const CLRefList * imported_funcs = program.GetImports()->GetLRefList();
   for (CLRefList::const_list_iterator l = imported_funcs->ConstIterator();
        l != imported_funcs->InvalidIterator(); ++l)
   {
      ast_key_to_func_set[(*l)->GetKey()] = 0;
   }
}

PPEnviron::PPEnviron(const PPEnviron & other)
{
   throw logic_error("It shouldn't be necessary to copy an AE PP environment");
}

PPEnviron::~PPEnviron()
{
   // Delete all address sets
   for (std::vector<AddrSet *>::iterator a = addr_sets.begin();
        a != addr_sets.end(); ++a) delete *a;
   // Delete all function sets
   for (std::vector<FuncSet *>::iterator f = func_sets.begin();
        f != func_sets.end(); ++f) delete *f;
}

bool PPEnviron::operator ==(const PPEnviron& other) const
{
   if (this == &other)
      return true;

   throw logic_error("PPEnviron::operator ==: Not implemented, because there should be only one "
      "program point environment");
}

void PPEnviron::LookupStmt(const ProgramPointECFG & cur_pp, const Value & address,
                           std::vector<ProgramPointECFG *> & program_points) const
{
   // Get an iterator to extract the individual (symbol, offset) pairs
   unique_ptr<SopIterator> sopiter;
   if (address.AsSymbPointer()) sopiter.reset( ((const SymbPointer&)address).GetIterator() );
   else throw runtime_error("Cannot extract (symbol, offset) pairs from address");

   // Extract the ECFG node of the current program point and put all its successor nodes into a set
   const CECFGNode * ecfg_node = cur_pp.GetECFGNode();
   std::set<const CECFGNode *> succs;
   for (CECFGNode::const_succ_iterator s = ecfg_node->SuccBegin(); s != ecfg_node->SuccEnd(); ++s) 
      succs.insert(s->node);

   // For all the (symbol, offset) pairs, first map the symbol to a set of addresses (which all have
   // the same base pointer but different offsets), then lookup the address (statement) in that set that
   // has the offset, finally find the right ECFG node among the current ECFG node's successors
   while (!sopiter->AtEnd()) {
      SymbolOffsetPair sop = sopiter->GetNext();
      ASTKeyToAddrSet::const_iterator addr_set = ast_key_to_addr_set.find(static_cast<ASTKey>(sop.GetSymbol().GetValue()));
      assert(addr_set != ast_key_to_addr_set.end());
      AddrSet::const_iterator stmt = addr_set->second->find(sop.GetOffset());
      assert(stmt != addr_set->second->end());
      for (std::set<const CECFGNode *>::iterator s = succs.begin(); s != succs.end(); ++s)
      {
         if ((*s)->GetFlowGraphNode()->Stmt() == stmt->second)
         {
            program_points.push_back(new ProgramPointECFG(const_cast<CECFGNode *>(*s)));
            succs.erase(s);
            break;
         }
      }
      // If no ECFG node was found, we assume that it has already been included in the
      // program_points vector
   }
}

void PPEnviron::LookupFunction(const ProgramPointECFG & cur_pp, const Value & address,
                               vector<LookedUpFunction> & functions) const
{
   // Get an iterator to extract the individual (symbol, offset) pairs
   unique_ptr<SopIterator> sopiter;
   if (address.AsSymbPointer()) sopiter.reset( ((const SymbPointer&)address).GetIterator() );
   else throw runtime_error("Cannot extract (symbol, offset) pairs from address");

   // Extract the ECFG node of the current program point and put all its successor nodes into a set. The goal
   // is to find which ECFG nodes correspond to the entry statements of the called function(s).
   const CECFGNode * ecfg_node = cur_pp.GetECFGNode();
   std::set<const CECFGNode *> succs;
   for (CECFGNode::const_succ_iterator s = ecfg_node->SuccBegin(); s != ecfg_node->SuccEnd(); ++s)
      succs.insert(s->node);

   // Loop through all the (symbol, offset) pairs of the called function pointer
   while (!sopiter->AtEnd()) {
      SymbolOffsetPair sop = sopiter->GetNext();
      // Treat the symbol part as an AST key, and lookup the set of functions that result from combining
      // the key with different offsets (one function for each offset)
      ASTKeyToFuncSet::const_iterator func_set = ast_key_to_func_set.find(static_cast<ASTKey>(sop.GetSymbol().GetValue()));
      assert(func_set != ast_key_to_func_set.end());

      // Undefined function set
      if (func_set->second == 0)
      {
         functions.push_back(LookedUpFunction::CreateUndefined());
         continue;
      }

      // Combine the symbol and the offset to get the function pointed to
      FuncSet::const_iterator func = func_set->second->find(sop.GetOffset());
      assert(func != func_set->second->end());

      // Derive the first statement in the called function's statement list that is not a
      // scope tuple. This may involve recursively visiting nested scopes.
      AStmt* entry_stmt = *func->second->GetScope()->GetStmts()->Iterator();
      if (entry_stmt->IsType(alf::CGenericNode::TYPE_SCOPE_TUPLE))
      {
         // Stack to hold the successor statement to scope statements. Will be needed
         // in case empty scopes.
         stack<AStmt*> succ_stack;
         do
         {
            CScopeTuple* cur_scope = static_cast<CScopeTuple*>(entry_stmt);
            CStmtList* scopes_stmts = cur_scope->GetStmts();
            // If the current scope doesn't contain any statements, pick a new scope to visit
            // from the successor stack
            if (scopes_stmts->ElementCount() == 0)
            {
               if (succ_stack.empty())
               {
                  stringstream msg;
                  msg << "Function " << func->second->Name() << " consists only of empty scopes" << endl;
                  throw runtime_error(msg.str());
               }
               entry_stmt = succ_stack.top();
               succ_stack.pop();
               continue;
            }
            // Else, get the first statement in the scope's statement list
            entry_stmt = *scopes_stmts->Iterator();
            // Push the second statement of the statement list, if it exists
            if (scopes_stmts->ElementCount() > 1)
               succ_stack.push(*(++scopes_stmts->Iterator()));
         }
         while (entry_stmt->IsType(alf::CGenericNode::TYPE_SCOPE_TUPLE));
      }

      // Now find the successor ECFG node corresponding the function entry point found above
      for (std::set<const CECFGNode *>::iterator s = succs.begin(); s != succs.end(); ++s)
      {
         if ((*s)->GetFlowGraphNode()->Stmt() == entry_stmt)
         {
            functions.push_back(LookedUpFunction::CreateDefined
               (func->second, new ProgramPointECFG(const_cast<CECFGNode *>(*s))));
            succs.erase(s);
            break;
         }
      }
   }
}

// Private members of PPEnviron - - - - - - - - - - - - - -

void PPEnviron::ProcessStmts(const CStmtList & stmts, LabelColl & collected_labels,
                             CodeIDToLRef & code_id_to_lref)
{
   for (CStmtList::const_list_iterator s = stmts.ConstIterator();
        s != stmts.InvalidIterator(); ++s)
   {
      // Get the statement's label and lref
      const CLabelTuple * label = (*s)->GetLabel();
      const CLRefTuple * lref = label->GetLRef();
      string lref_id = lref->GetId();

      // Make a connection from the lref's code identifier to the lref data
      // holder
      LRef & looked_up_lref = code_id_to_lref[make_pair(lref_id, lref->GetSourceFile())];
      looked_up_lref.second.push_back(lref->GetKey());

      // Save the label to be able to attach it to a statement later on
      Integer offset = label->GetOffset()->GetNumber()->GetValueAsBignum();
      AddrOffset offset_ = offset.As<AddrOffset>();
      AddrSet::iterator offset_mapping = looked_up_lref.first.find(offset_);
      if (offset_mapping != looked_up_lref.first.end())
      {
         ostringstream msg;
         msg << "Construction of program point environment failed: : the label ("
            << lref_id << ", " << offset_ << ") on line " << label->GetLine()
            << " has already been used for the statement on line "
            << offset_mapping->second->GetLine() << '.';
         throw runtime_error(msg.str());
      }
      collected_labels.push_back(&looked_up_lref.first[offset_]);

      if ((*s)->IsType(CGenericNode::TYPE_SCOPE_TUPLE))
         ProcessStmts(*static_cast<const CScopeTuple *>(*s)->GetStmts(),
                      collected_labels, code_id_to_lref);
      else
      {
         while (!collected_labels.empty())
         {
            *collected_labels.back() = *s;
            collected_labels.pop_back();
         }
      }
   }
}
