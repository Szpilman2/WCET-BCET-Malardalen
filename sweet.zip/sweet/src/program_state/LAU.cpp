#include "LAU.h"

namespace LAU
{

   static unsigned long long _lau = 8;

   unsigned long long LAU()
   {
      return _lau;
   }

   void SetLAU(unsigned long long lau)
   {
      _lau = lau;
   }

}
