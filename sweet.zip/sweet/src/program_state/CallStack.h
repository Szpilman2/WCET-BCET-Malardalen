#ifndef CALLSTACK_H_INCLUDED
#define CALLSTACK_H_INCLUDED

#include "program_state/VarEnviron.h"
#include "program_state/program_counter/ProgramPoint.h"
#include "tools/cheap_copy.h"
#include <memory>
#include <iostream>
#include <vector>

class Value;

typedef std::vector<std::unique_ptr<Value>> RetAddrList;

/** A call stack where each element stores an environment that is local to an instance of a
function invocation, a list of return addresses to where the values returned from the 
function will be stored, and a program point that will be jumped to when the function 
returns. */
class CallStack
{
public:
   /** Element on the call stack */
   class Elem
   {
   public:
      Elem(std::unique_ptr<ProgramPoint> return_pp, std::unique_ptr<VarEnviron> env,
           std::unique_ptr<RetAddrList> ret_addr_list, const std::string & func_name)
         : _return_pp(return_pp.release()), _env(env.release()),
           _ret_addr_list(ret_addr_list.release()),
           _func_name(func_name) {}

      Elem(const Elem &other)
         : _return_pp(other._return_pp->Copy()),
           _env( new VarEnviron(*other._env)),
           _ret_addr_list( new RetAddrList )
      {
         _ret_addr_list->reserve(other._ret_addr_list->size());
         for (auto &a : *other._ret_addr_list)
            _ret_addr_list->push_back( std::unique_ptr<Value>(a->Copy()) );
      }

      ~Elem() {
         delete _return_pp;
         delete _env;
         delete _ret_addr_list;
      }

      bool operator ==(const Elem& other) const;
      bool IsEqual(const Elem& other) const { return *this == other; }

      const ProgramPoint * GetRetProgramPoint(void) const {return _return_pp;}
      const VarEnviron * GetEnviron(void) const {return _env;}
      const RetAddrList * GetRetAddrList(void) const {return _ret_addr_list;}
      const std::string & FuncName() const {return _func_name;}

      /** @note The caller is responsible for deleting the returned pointer */
      ProgramPoint * RemoveRetProgramPoint() {ProgramPoint * return_pp = _return_pp; _return_pp = 0; return return_pp;}

   private:
      ProgramPoint * _return_pp;
      VarEnviron * _env;
      RetAddrList * _ret_addr_list;
      std::string _func_name;
   };

   typedef std::vector<cheap_copy<Elem>>::iterator Iterator;
   typedef std::vector<cheap_copy<Elem>>::const_iterator ConstIterator;
   typedef std::vector<cheap_copy<Elem>>::size_type SizeType;

   /** Set whether reuse should be used for the elements of the call stack */
   static void SetReuse(bool on) { _reuse = on; }

   CallStack() {}

   CallStack(const CallStack & other) {
      if (_reuse)
         _elems = other._elems;
      else {
         _elems.reserve(other._elems.size());
         for (auto &e : other._elems)
            _elems.push_back( cheap_copy<Elem>( new Elem(*e) ) );
      }
   }

   /** Perform a deep copy of this call stack
      @note The returned pointer should be deleted by the caller */
   CallStack * Copy() const {return new CallStack(*this);}

   SizeType Height() const { return _elems.size(); }

   bool IsEqual(const CallStack* other) const {return *this == *other;}

   bool operator ==(const CallStack& other) const;

   bool operator !=(const CallStack& other) const {return !(*this == other);}

   void PushFunction(std::unique_ptr<ProgramPoint> return_pp, std::unique_ptr<VarEnviron> env,
      std::unique_ptr<RetAddrList> ret_addr_list, const std::string & func_name);

   void PopFunction(std::unique_ptr<ProgramPoint> & return_pp);

   const Elem &GetTop() const { return *_elems.back(); }

   /** Returns an iterator pointing to the bottom of the stack */
   Iterator IterBegin() {return _elems.begin();}

   /** Returns an iterator pointing (conceptually) above the top of the stack */
   Iterator IterEnd() {return _elems.end();}

   /** Returns an iterator pointing to the bottom of the stack */
   ConstIterator IterBegin() const {return _elems.begin();}

   /** Returns an iterator pointing (conceptually) above the top of the stack */
   ConstIterator IterEnd() const {return _elems.end();}

   /** @returns A pointer to the result, or 0 if the result is bottom
       @note The caller is responsible for deleting the returned pointer */
   CallStack* GLB(const CallStack* other) const;

   /** @note The caller is responsible for deleting the returned pointer */
   CallStack* LUB(const CallStack* other) const;

   /** @note The caller is responsible for deleting the returned pointer */
   CallStack* Widening(const CallStack* other) const;

   /** @returns A pointer to the result, or 0 if the result is bottom
       @note The caller is responsible for deleting the returned pointer */
   CallStack* Narrowing(const CallStack* other) const;

protected:
   static bool _reuse;

   std::vector<cheap_copy<Elem>> _elems;

   template <typename Op>
   static bool BinRALOp(const Op& op, const RetAddrList& a, const RetAddrList& b, RetAddrList& result);
};

#endif   // #ifndef CALLSTACK_H_INCLUDED
