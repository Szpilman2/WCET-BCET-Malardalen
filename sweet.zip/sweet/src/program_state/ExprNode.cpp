#include "ExprNode.h"
#include "AlfVM.h"
#include "State.h"
#include "value/ValueDomain.h"
#include "value/IntegerDomain.h"
#include "memory/Memory.h"
#include "program/alf/CLoadExprTuple.h"
#include "program/alf/CSizeList.h"
#include "program/alf/CExprList.h"
#include "tools/IndentingOStream.h"

using namespace std;
using namespace alf;

// Public members of ExprNode - - - - - - - - - - - - - - - - - - ->

ExprNode * ExprNode::Create(const alf::AExpr * expr, State * state,
                            const ValueDomain * domain, const AlfVM * alf_vm)
{
   // Choose an appropriate node type based on the type of the ALF expression
 
   switch (expr->GetNodeType())
   {
   case CGenericNode::TYPE_OP_EXPR_TUPLE:
      return new InternalExprNode(static_cast<const COpNumExprTuple *>(expr), 
                                  state, domain, alf_vm);
      break;
   case CGenericNode::TYPE_LOAD_EXPR_TUPLE:
      return new LoadLeaf(static_cast<const CLoadExprTuple *>(expr), state,
                          domain, alf_vm);
      break;
   default:
      return new ExprLeaf(expr, state, domain, alf_vm);
      break;
   }
}

ExprNode::~ExprNode()
{
   delete annot;
}

// Protected members of ExprNode - - - - - - - - - - - - - - - ->

ExprNode::ExprNode(State * state, const ValueDomain * domain,
                   const AlfVM * alf_vm)
: annot(0), state(state), domain(domain), alf_vm(alf_vm)
{

}

ExprNode::ExprNode(const ExprNode & other, State * state)
: annot(0), state(state), domain(other.domain),
  alf_vm(other.alf_vm)
{
   if (other.HasAnnot())
      annot = other.GetAnnot()->Copy();
}

void ExprNode::SetAnnot(unique_ptr<Value> annot)
{
   delete ExprNode::annot;
   ExprNode::annot = annot.release();
}

// Public members of InteralExprNode - - - - - - - - - - - - - - ->

InternalExprNode::
InternalExprNode(const alf::COpNumExprTuple * expr, State * state,
                 const ValueDomain * domain, const AlfVM * alf_vm)
: ExprNode(state, domain, alf_vm), operation(expr->GetOperator())
{
   // Save the size arguments
   const CSizeList * sizes = expr->GetSizes();
   for (CSizeList::const_list_iterator s = sizes->ConstIterator();
        s != sizes->InvalidIterator(); ++s)
   {
      size_opers.push_back((*s)->GetSizeInBits());
   }
   // Create the children
   const CExprList * operands = expr->GetNumExprs();
   for (CExprList::const_list_iterator o = operands->ConstIterator();
        o != operands->InvalidIterator(); ++o)
   {
      children.push_back(ExprNode::Create(*o, state, domain, alf_vm));
   }
   return;
}

InternalExprNode::InternalExprNode(const InternalExprNode & other, State * state)
: ExprNode(other, state), operation(other.operation), size_opers(other.size_opers)
{
   for (ChildList::const_iterator c = other.children.begin();
        c != other.children.end(); ++c)
   {
      children.push_back((*c)->Copy(state));
   }
}

InternalExprNode::~InternalExprNode()
{
   for (ChildList::const_iterator c = children.begin();
        c != children.end(); ++c)
   {
      delete *c;
   }
}

const Value * InternalExprNode::UpdateAnnot()
{
   // Update the annotations in the operand subtrees, and then update the annotation
   // of this node based on the represented operation
   switch (operation)
   {
   case COpNumExprTuple::OP_TYPE_NEG:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->Neg()));
      break;
   case COpNumExprTuple::OP_TYPE_ADD:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->Add(children[1]->UpdateAnnot(),
                                                   children[2]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_C_ADD:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->CAdd(children[1]->UpdateAnnot(), 
                                                    children[2]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_SUB:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->Sub(children[1]->UpdateAnnot(), 
                                                   children[2]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_C_SUB:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->CSub(children[1]->UpdateAnnot(),
                                                    children[2]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_U_MUL:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->UMul(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_S_MUL:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->SMul(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_U_DIV:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->UDiv(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_S_DIV:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->SDiv(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_U_MOD:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->UMod(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_S_MOD:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->SMod(children[1]->UpdateAnnot())));
      break;
   // OP_BIT - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   case COpNumExprTuple::OP_TYPE_L_SHIFT:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->LShift(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_R_SHIFT:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->RShift(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_R_SHIFT_A:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->RShiftA(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_S_EXT:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->SExt(size_opers[1])));
      break;
   case COpNumExprTuple::OP_TYPE_NOT:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->Not()));
      break;
   case COpNumExprTuple::OP_TYPE_AND:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->And(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_OR:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->Or(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_XOR:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->XOr(children[1]->UpdateAnnot())));
      break;
   // OP_FLOAT - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   case COpNumExprTuple::OP_TYPE_F_NEG:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->FNeg()));
      break;
   case COpNumExprTuple::OP_TYPE_F_ADD:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->FAdd(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_F_SUB:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->FSub(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_F_MUL:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->FMul(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_F_DIV:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->FDiv(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_F_TO_F:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->FToF(size_opers[1], size_opers[3])));
      break;
   case COpNumExprTuple::OP_TYPE_F_TO_U:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->FToU(size_opers[2])));
      break;
   case COpNumExprTuple::OP_TYPE_F_TO_S:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->FToS(size_opers[2])));
      break;
   case COpNumExprTuple::OP_TYPE_U_TO_F:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->UToF(size_opers[0], size_opers[1])));
      break;
   case COpNumExprTuple::OP_TYPE_S_TO_F:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->SToF(size_opers[0], size_opers[1])));
      break;

   // OP_CMP - - - - - - - - - - - - - - - - - - - - - - - - - - -
   case COpNumExprTuple::OP_TYPE_EQ:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->Eq(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_NEQ:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->NEq(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_U_LT:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->ULT(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_U_GE:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->UGE(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_U_GT:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->UGT(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_U_LE:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->ULE(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_S_LT:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->SLT(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_S_GE:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->SGE(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_S_GT:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->SGT(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_S_LE:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->SLE(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_F_EQ:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->FEq(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_F_NE:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->FNEq(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_F_LT:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->FLT(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_F_GE:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->FGE(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_F_GT:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->FGT(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_F_LE:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->FLE(children[1]->UpdateAnnot())));
      break;
   // OP_MATH - - - - - - - - - - - - - -
   case COpNumExprTuple::OP_TYPE_IF:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->If(children[1]->UpdateAnnot(),  
                                                  children[2]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_B2N:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->B2N()));
      break;
   case COpNumExprTuple::OP_TYPE_EXP2:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->Exp2()));
      break;
   // OP_BITSTR - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   case COpNumExprTuple::OP_TYPE_SELECT:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->Select(size_opers[1], size_opers[2])));
      break;
   case COpNumExprTuple::OP_TYPE_CONC:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->Conc(children[1]->UpdateAnnot())));
      break;
   case COpNumExprTuple::OP_TYPE_REPEAT:
      SetAnnot(unique_ptr<Value>(children[0]->UpdateAnnot()->Repeat(size_opers[0])));
      break;
   default:
      assert("Should not reach here" == 0);
      break;
   }
   return GetAnnot();
}

bool InternalExprNode::RestrictEq(const Value * r)
{
   const Value* annot = GetAnnot();

   // If the restrict value is top, no restriction will be done
   if (r->IsTop())
      return annot->IsBottom();

   // Do a restrict of this node's annotation to see if there is a point in 
   // traversing the subtree. Also, the restricting value might be restricted 
   // itself, which improves precision in the succeeding restrictions.
   unique_ptr<Value> r_(annot->GLB(r));
   if (r_->IsBottom())  return true;
   if (r_->IsSetEqual(annot))  return false;  // annot cannot be bottom

   return Restrict<&ExprNode::RestrictEq>(r_.get());
}

bool InternalExprNode::RestrictNEq(const Value * r)
{
   const Value* annot = GetAnnot();
   // Do a restrict of this node's annotation to see if there is a point in 
   // traversing the subtree.
   unique_ptr<Value> restr_annot(annot->Restrict_NEq(r));
   if (restr_annot->IsBottom())  return true;
   if (restr_annot->IsSetEqual(annot))  return false;  // annot cannot be bottom

   return Restrict<&ExprNode::RestrictNEq>(r);
}

ostream & InternalExprNode::Print(ostream & os) const
{
  os << "InternalExprNode ";
  os << "(" << COpNumExprTuple::GetName(operation) <<  "," << endl
    /* <<  (GetAnnot() ? *GetAnnot() : Value(0) ) */ <<  ")" << endl << IncrIndent;
   for (ChildList::const_iterator c = children.begin();
      c != children.end(); ++c)
   {
      os << "|-" << endl << IncrIndent;
      // If the annotation of this node is bottom, the subtrees are not
      // printed out
     if (!GetAnnot()) os << **c;
     else
     {
        if (!GetAnnot()->IsBottom())
          os << **c;
        else
          os << "...";
        if (c + 1 != children.end())
          os << endl;
        os << DecrIndent;
     }
   }
   return os << DecrIndent << DecrIndent;
}

// Private members of InternalExprNode - - - - - - - - - - - - - - - ->

template <bool (ExprNode::*RestrictFunc)(const Value*)>
bool InternalExprNode::Restrict(const Value * r)
{
   // Special handling of boolean operators
   if (COpNumExprTuple::IsBooleanOperator(operation))
   {
      COpNumExprTuple::OP_TYPE bool_oper = operation;
      
      // Turn the expression into one that should evaluate to true
      if (RestrictFunc == &ExprNode::RestrictEq) {
         // (a op b) == 0  =>  (a revop b) == 1
         unique_ptr<Value> _0( GetDomain()->GetIntegerDomain()->CreateInteger(1, 0) );
         if (r->IsSetEqual(_0.get())) 
            bool_oper = COpNumExprTuple::OppositeOp(bool_oper);   
      }
      else {  // RestrictFunc == &ExprNode::RestrictNEq
         // (a op b) != 1  =>  (a revop b) == 1
         unique_ptr<Value> _1( GetDomain()->GetIntegerDomain()->CreateInteger(1, 1) );
         if (r->IsSetEqual(_1.get())) 
            bool_oper = COpNumExprTuple::OppositeOp(bool_oper);   
      }

      // Derive restriction values for the operands
      unique_ptr<Value> rs[2];
      switch (bool_oper)
      {
      case COpNumExprTuple::OP_TYPE_EQ:
         // return immediately, to avoid copying the annots
         return children[0]->RestrictEq(children[1]->GetAnnot()) ||
                children[1]->RestrictEq(children[0]->GetAnnot());
         break;
      case COpNumExprTuple::OP_TYPE_NEQ:
         // return immediately, to avoid copying the annots
         return children[0]->RestrictNEq(children[1]->GetAnnot()) || 
                children[1]->RestrictNEq(children[0]->GetAnnot());
         break;
      case COpNumExprTuple::OP_TYPE_U_LT:
         rs[0].reset(children[0]->GetAnnot()->Restrict_ULT(children[1]->GetAnnot()));
         rs[1].reset(children[1]->GetAnnot()->Restrict_UGT(children[0]->GetAnnot()));
         break;
      case COpNumExprTuple::OP_TYPE_U_LE:
         rs[0].reset(children[0]->GetAnnot()->Restrict_ULE(children[1]->GetAnnot()));
         rs[1].reset(children[1]->GetAnnot()->Restrict_UGE(children[0]->GetAnnot()));
         break;
      case COpNumExprTuple::OP_TYPE_U_GT: 
         rs[0].reset(children[0]->GetAnnot()->Restrict_UGT(children[1]->GetAnnot()));
         rs[1].reset(children[1]->GetAnnot()->Restrict_ULT(children[0]->GetAnnot()));
         break;
      case COpNumExprTuple::OP_TYPE_U_GE: 
         rs[0].reset(children[0]->GetAnnot()->Restrict_UGE(children[1]->GetAnnot()));
         rs[1].reset(children[1]->GetAnnot()->Restrict_ULE(children[0]->GetAnnot()));
         break;
      case COpNumExprTuple::OP_TYPE_S_LT:
         rs[0].reset(children[0]->GetAnnot()->Restrict_SLT(children[1]->GetAnnot()));
         rs[1].reset(children[1]->GetAnnot()->Restrict_SGT(children[0]->GetAnnot()));
         break;
      case COpNumExprTuple::OP_TYPE_S_LE:
         rs[0].reset(children[0]->GetAnnot()->Restrict_SLE(children[1]->GetAnnot()));
         rs[1].reset(children[1]->GetAnnot()->Restrict_SGE(children[0]->GetAnnot()));
         break;
      case COpNumExprTuple::OP_TYPE_S_GT: 
         rs[0].reset(children[0]->GetAnnot()->Restrict_SGT(children[1]->GetAnnot()));
         rs[1].reset(children[1]->GetAnnot()->Restrict_SLT(children[0]->GetAnnot()));
         break;
      case COpNumExprTuple::OP_TYPE_S_GE: 
         rs[0].reset(children[0]->GetAnnot()->Restrict_SGE(children[1]->GetAnnot()));
         rs[1].reset(children[1]->GetAnnot()->Restrict_SLE(children[0]->GetAnnot()));
         break;
      case COpNumExprTuple::OP_TYPE_F_LT:
         rs[0].reset(children[1]->GetAnnot()->FExclUpperBelow());
         rs[1].reset(children[0]->GetAnnot()->FExclLowerAbove());
         break;
      case COpNumExprTuple::OP_TYPE_F_LE:
         rs[0].reset(children[1]->GetAnnot()->FInclUpperBelow());
         rs[1].reset(children[0]->GetAnnot()->FInclLowerAbove());
         break;
      case COpNumExprTuple::OP_TYPE_F_GE:
         rs[0].reset(children[1]->GetAnnot()->FInclLowerAbove());
         rs[1].reset(children[0]->GetAnnot()->FInclUpperBelow());
         break;
      case COpNumExprTuple::OP_TYPE_F_GT:
         rs[0].reset(children[1]->GetAnnot()->FExclLowerAbove());
         rs[1].reset(children[0]->GetAnnot()->FExclUpperBelow());
         break;
      default:
         // Restriction not supported
         return false;
         break;
      }
      return children[0]->RestrictEq(rs[0].get()) || children[1]->RestrictEq(rs[1].get());
   }
   // Non-boolean operators
   else
   {
      // For simplicity, memory is allocated for three restriction values, but depending on the
      // number of operands, only some of them might be used
      unique_ptr<Value> rs[3];

      // Derive new restriction values for the operands based on the operation
      switch (operation)
      {
      // OP_INT (and pointer arithmetics) - - - - - - - - - - - - - - - - - - - -
      case COpNumExprTuple::OP_TYPE_NEG:
         {
            // r = -x
            // => x = -r
            rs[0].reset(r->Neg());
            break;
         }
      case COpNumExprTuple::OP_TYPE_ADD:
         {
            unique_ptr<Value> inv_c(children[2]->GetAnnot()->Not());
            rs[0].reset(r->Sub(children[1]->GetAnnot(), inv_c.get()));
            rs[1].reset(r->Sub(children[0]->GetAnnot(), inv_c.get()));
            // TODO: Fix better restricting value for the carry
            rs[2].reset(GetDomain()->CreateTopValue(1));
            break;
         }
      case COpNumExprTuple::OP_TYPE_SUB:
         {
            // Compute restrict values according to:
            // x - y - b = x - y - (1 - c) = r =>
            //   x = r + y + (1 - c) = AddWithCarry(r, y, ~c),
            //   y = x - r - (1 - c) = SubWithCarry(x, r,  c),
            //   c = select([0..0], r - x + y + 1)
            //     = Select([0..0], AddWithCarry(r - x, y, 1)),
            //   where b is the borrow flag = inverted carry flag
            unique_ptr<Value> inv_c(children[2]->GetAnnot()->Not());
            rs[0].reset(r->Add(children[1]->GetAnnot(), inv_c.get()));
            rs[1].reset(children[0]->GetAnnot()->Sub(r, children[2]->GetAnnot()));
            unique_ptr<Value> one(GetDomain()->GetIntegerDomain()->CreateInteger(1, 1));
            unique_ptr<Value> rs2a(r->Sub(children[0]->GetAnnot(), one.get()));
            unique_ptr<Value> rs2b(rs2a->Add(children[1]->GetAnnot(), one.get()));
            rs[2].reset(rs2b->Select(0, 0));
            break;
         }
      case COpNumExprTuple::OP_TYPE_U_MUL:
         {
            // We have x * y = r
            //    => x = r /r y
            //    => y = r /r x
            // where /r is reversed multiplication
            rs[0].reset(r->RevUMul(children[1]->GetAnnot(), size_opers[0]));
            rs[1].reset(r->RevUMul(children[0]->GetAnnot(), size_opers[1]));
            break;
         }
      case COpNumExprTuple::OP_TYPE_S_MUL: 
         {
            // Same reasoning as in the previous case
            rs[0].reset(r->RevSMul(children[1]->GetAnnot(), size_opers[0]));
            rs[1].reset(r->RevSMul(children[0]->GetAnnot(), size_opers[1]));
            break;
         }
      // OP_BIT - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
      case COpNumExprTuple::OP_TYPE_S_EXT:
         {
            // s_ext(x, n) = r
            // x = Select([0..(size(x) - 1)], r)
            rs[0].reset(r->Select(0, size_opers[0] - 1));
            break;
         }
      case COpNumExprTuple::OP_TYPE_NOT:
         {
            // not(x) = r => x = not(r)
            rs[0].reset(r->Not());
            break;
         }
      case COpNumExprTuple::OP_TYPE_AND: 
         {
            rs[0].reset(r->RevAnd(children[1]->GetAnnot()));
            rs[1].reset(r->RevAnd(children[0]->GetAnnot()));
            break;
         }
      case COpNumExprTuple::OP_TYPE_OR:
         {
            rs[0].reset(r->RevOr(children[1]->GetAnnot()));
            rs[1].reset(r->RevOr(children[0]->GetAnnot()));
            break;
         }
      case COpNumExprTuple::OP_TYPE_XOR: 
         {
            rs[0].reset(r->RevXOr(children[1]->GetAnnot()));
            rs[1].reset(r->RevXOr(children[0]->GetAnnot()));
            break;
         }
      // OP_MATH - - - - - - - - - - - - - - - - - - - - - - - - - -
      case COpNumExprTuple::OP_TYPE_IF:
         {
            // Compute restrict values according to:
            // if x y z = r =>
            //   x = (if Overlaps(y, r) then [1..1] else bottom) LUB
            //          (if Overlaps(z, r) then [0..0] else bottom),
            //   y = if x' = [1..1] then r else top,
            //   z = if x' = [0..0] then r else top,
            //   where x' is x after being restricted
            unique_ptr<Value> zero(GetDomain()->GetIntegerDomain()->CreateInteger(1, (long long)(0))),
               one(GetDomain()->GetIntegerDomain()->CreateInteger(1, 1));
            // Compute restricting value for x
            unique_ptr<Value> rs0a;
            if (children[1]->GetAnnot()->Overlaps(r))
               rs0a.reset(one->Copy());
            else
               rs0a.reset(GetDomain()->CreateBottomValue(1));
            unique_ptr<Value> rs0b;
            if (children[2]->GetAnnot()->Overlaps(r))
               rs0b.reset(zero->Copy());
            else
               rs0b.reset(GetDomain()->CreateBottomValue(1));
            rs[0].reset(rs0a->LUB(rs0b.get()));

            // Compute x's restricted value
            unique_ptr<Value> restr_c0(children[0]->GetAnnot()->GLB(rs[0].get()));

            // Compute restricting values for y and z
            if (restr_c0->IsSetEqual(one.get()))
               rs[1].reset(r->Copy());
            else
               rs[1].reset(GetDomain()->CreateTopValue(r->SizeInBits()));
            if (restr_c0->IsSetEqual(zero.get()))
               rs[2].reset(r->Copy());
            else
               rs[2].reset(GetDomain()->CreateTopValue(r->SizeInBits()));
            break;
         }
      case COpNumExprTuple::OP_TYPE_B2N:
         {
            rs[0].reset(r->Select(0, size_opers[0] - 1));
            break;
         }
      case COpNumExprTuple::OP_TYPE_EXP2:
         {
            // We have 2^x = r
            //    => x = log2(r)
            rs[0].reset(r->ILog2());
            break;
         }
      // OP_BITSTR - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
      case COpNumExprTuple::OP_TYPE_SELECT:
         {
            rs[0].reset( children[0]->GetAnnot()->Restrict_Select(size_opers[1], r) );
            break;
         }
      case COpNumExprTuple::OP_TYPE_CONC:
         {
            // x ++ y = r
            //    =>    x = Select(y->SizeInBits(), r->SizeInBits() - 1, r)
            //    and   y = Select(0, y->SizeInBits() - 1, r)
            rs[0].reset(r->Select(size_opers[1], r->SizeInBits() - 1));
            rs[1].reset(r->Select(0, size_opers[1] - 1));
            break;
         }
      case COpNumExprTuple::OP_TYPE_REPEAT:
         {
            // If r includes the value -1 (a bit string of all 1s), then include 1 in the new
            // restrict value, and if r includes the value 0, include 0. If r doesn't include
            // any of those two, the new restrict value is _|_.
            rs[0].reset(GetDomain()->CreateBottomValue(1));
            unique_ptr<Value> minus_one(GetDomain()->GetIntegerDomain()->CreateInteger(r->SizeInBits(), -1));
            if (r->Includes(minus_one.get()))
               rs[0].reset(GetDomain()->GetIntegerDomain()->CreateInteger(1, 1));
            unique_ptr<Value> zero(GetDomain()->GetIntegerDomain()->CreateInteger(r->SizeInBits(), (long long)(0)));
            if (r->Includes(zero.get()))
            {
               unique_ptr<Value> zero_1bit(GetDomain()->GetIntegerDomain()->CreateInteger(1, (long long)(0)));
               rs[0].reset(rs[0]->LUB(zero_1bit.get()));
            }
            break;
         }
      default:
         // Restriction not supported
         return false;
         break;
      }
      // Recursively restrict the operand subtrees and report upwards whether some
      // subtree made the state become bottom
      bool bottom = false;
      for (ChildList::size_type c = 0, cn = children.size(); c != cn && !bottom; ++c)
      {
         // children[c]->Print(cout);
         bottom = bottom || (children[c]->*RestrictFunc)(rs[c].get());
      }
      return bottom;
   }
}

// Public members of ExprLeaf - - - - - - - - - - - - - - - - ->

ExprLeaf::ExprLeaf(const alf::AExpr * expr, State * state,
                   const ValueDomain * domain, const AlfVM * alf_vm)
: ExprNode(state, domain, alf_vm)
{
   // For this node type, the annotation is set when it is created, and it then only needs
   // to be updated when it is restricted (and not when some other node or subtree is restricted,
   // as in the case of load leaves)
   SetAnnot(unique_ptr<Value>(GetALFVM()->EvalExpr(expr, state)));
}

ExprLeaf::ExprLeaf(const ExprLeaf & other, State * state)
: ExprNode(other, state)
{

}

const Value * ExprLeaf::UpdateAnnot()
{
   // Do nothing
   return GetAnnot();
}

bool ExprLeaf::RestrictEq(const Value * r)
{
   // Restrict the annotation and return whether it made the
   // state become bottom
   SetAnnot(unique_ptr<Value>(GetAnnot()->GLB(r)));
   return GetAnnot()->IsBottom();
}

bool ExprLeaf::RestrictNEq(const Value * r)
{
   // Restrict the annotation and return whether it made the
   // state become bottom
   SetAnnot(unique_ptr<Value>(GetAnnot()->Restrict_NEq(r)));
   return GetAnnot()->IsBottom();
}

ostream & ExprLeaf::Print(ostream & os) const
{
   os << "ExprLeaf ";
   return os << "(constant," << endl /*<< (GetAnnot() ? *GetAnnot() : " ")*/ << ")";
}

// Public members of LoadLeaf - - - - - - - - - - - - - - - - ->

LoadLeaf::LoadLeaf(const alf::CLoadExprTuple * expr, State * state,
                   const ValueDomain * domain, const AlfVM * alf_vm)
: ExprNode(state, domain, alf_vm), load_size(expr->GetSize()->GetSizeInBits()),
  addr_expr(expr->GetAddrExpr())
{

}

LoadLeaf::LoadLeaf(const LoadLeaf & other, State * state)
: ExprNode(other, state), load_size(other.load_size), addr_expr(other.addr_expr)
{

}

Value * LoadLeaf::GetAddress() const
{
   unique_ptr<Value> address(GetALFVM()->EvalExpr(addr_expr, GetState()));
   return address.release();
}

const Value * LoadLeaf::UpdateAnnot()
{
   // Update the annotation by reading it from the memory
   unique_ptr<Value> address(GetALFVM()->EvalExpr(addr_expr, GetState()));
   unique_ptr<Value> value(GetState()->GetMemory()->Load(address.get(), load_size));
   SetAnnot(move(value));
   return GetAnnot();
}

bool LoadLeaf::RestrictEq(const Value * r)
{
   // Only if the address refers to exactly one location in memory can
   // the loaded value be restricted.
   unique_ptr<Value> address(GetALFVM()->EvalExpr(addr_expr, GetState()));
   if (!GetState()->GetMemory()->AddrSingleLoc(address.get()))
      return false;
   // Read the loaded value from the state's memory, GLB it with the
   // restrict value, and, if the value is not bottom, store it back
   // to the same memory address. The address itself is not restricted,
   // but in principle it could be, at least in some cases.
   unique_ptr<Value> value(GetState()->GetMemory()->Load(address.get(), load_size));
   unique_ptr<Value> glb(value->GLB(r));
   if (!glb->IsBottom())
   {
      GetState()->GetMemory()->Store(address.get(), glb.get(), false);
      return false;
   }
   // If the restricted value is bottom, just drop it; the RestrictedALFState object
   // will delete the state and replace it with a bottom state
   return true;
}

bool LoadLeaf::RestrictNEq(const Value * r)
{
   if (!r->IsSingleElem())
      return false;
   // Only if the address refers to exactly one location in memory can
   // the loaded value be restricted.
   unique_ptr<Value> address(GetALFVM()->EvalExpr(addr_expr, GetState()));
   if (!GetState()->GetMemory()->AddrSingleLoc(address.get()))
      return false;
   // Read the loaded value from the state's memory, restrict it, and,
   // if the value is not bottom, store it back to the same memory address.
   // The address itself is not restricted, but in principle it could be,
   // at least in some cases.
   unique_ptr<Value> value(GetState()->GetMemory()->Load(address.get(), load_size));
   unique_ptr<Value> restr(value->Restrict_NEq(r));
   if (!restr->IsBottom())
   {
      GetState()->GetMemory()->Store(address.get(), restr.get(), false);
      return false;
   }
   // If the restricted value is bottom, just drop it; the RestrictedALFState object
   // will delete the state and replace it with a bottom state
   return true;
}

ostream & LoadLeaf::Print(ostream & os) const
{
   os << "LoadLeaf ";
   return os << "(load," << endl /*<< (GetAnnot() ? *GetAnnot() : "")*/ << ")";
}
