#ifndef STATE_H_INCL
#define STATE_H_INCL

#include "VarEnviron.h"
#include "CallStack.h"
#include "ae/MergeableStateTraits.h"
#include "tools/cheap_copy.h"
#include <memory>
#include <iostream>
#include <stdexcept>

class ProgramCounter;
class ProgramCounterECFG;
class PPEnviron;
class CGenericProgram;
class Memory;
class Value;
class CECFGNode;

/** Represents an abstract program state during the execution of an ALF program.

The state consists of a global environment, a memory, and a call stack. The call
stack has one element for each function call that has not yet been returned
from, with the top element corresponding to the currently visited function.

If IsBottom() returns true, access to the state's environments, memory, and call
stack is prohibited and will throw an exception. */
class State
{
public:
   /** Set whether reuse should be used for the call stack */
   static void SetReuse_CallStack(bool on) { _reuse_call_stack = on; }

   State(std::unique_ptr<ProgramCounterECFG> pc, std::unique_ptr<PPEnviron> pp_environ, bool is_bottom = false);

   /** @note The caller is responsible for deleting the returned pointer */
   static State *CreateBottomState(std::unique_ptr<ProgramCounterECFG> pc);

   virtual ~State();

   /** Make a deep copy of the state
       @note The caller is responsible for deleting the returned pointer */
   virtual State *Copy() const;

   /** To test if two abstract states are equal. Will return true if all components 
       of this state and the other state are equal, and false otherwise. */
   virtual bool IsEqual(const State *other) const { return *this == *other; }
   bool operator ==(const State& other) const;

   const char *GetName() const { return _name.c_str(); }

   bool IsBottom() const { return _is_bottom; }

   bool IsFinalState() const;

   ProgramCounter *GetProgramCounter() const;

   /** To get the program counter as an ECFG PC */
   ProgramCounterECFG *GetProgramCounterECFG() const { return _pc; }

   /** Returns the program that this state belongs to */
   const CGenericProgram *GetProgram() const;

   /** Returns the local environment in the currently visited function (i.e.\
       the one at the top of the call stack)
       @pre !IsBottom() */
   const VarEnviron *GetEnviron() const;

   /** Returns the global environment (mutable version; should only be used when initializing the first state)
       @pre !IsBottom() */
   VarEnviron *GetMutableGlobEnviron() { CheckNotBottom(); return _genv.get_mutable(); }

   /** Returns the global environment
       @pre !IsBottom() */
   const VarEnviron *GetGlobEnviron() const { CheckNotBottom(); return _genv.get(); }

   /** Look in the environments for a base pointer mapped to by the identifier
       @a id, which corresponds to an identifier in a program. First the local
       @c Env() environment is checked, then the global @c GEnv() environment. If
       @a cshack is true, the "call stack hack" takes effect, which means that the
       local environment of the @em caller of the current function is used
       instead of that of the current function.
       @pre !IsBottom()
       @note The caller is responsible for deleting the returned pointer */
   Value *Lookup(unsigned id, bool cshack = false) const;

   /** To get the program point environment
       @pre !IsBottom() */
   const PPEnviron *GetPPEnviron() const { CheckNotBottom(); return _pp_environ.get(); }

   /** Return the memory
       @pre !IsBottom() */
   Memory *GetMemory() const { CheckNotBottom(); return _mem; }

   /** Return the ordered list of addresses to where the currently visited function should
       put its results
       @pre !IsBottom() */
   const RetAddrList *GetRetAddrList() const;

   /** Return the call stack (mutable version)
       @pre !IsBottom() */
   CallStack *GetMutableCallStack() { CheckNotBottom(); return _call_stack.get_mutable(); }

   /** Return the call stack
       @pre !IsBottom() */
   const CallStack *GetCallStack() const { CheckNotBottom(); return _call_stack.get(); }

   /** To test if two abstract states can be merged. Only possible if the states
       are in the same program point */
   bool AreMergeable(const State *state2) const;

   /** @note The caller is responsible for deleting the returned pointer */
   virtual State *GLB(const State *state2) const;

   /** @note The caller is responsible for deleting the returned pointer */
   virtual State *LUB(const State *state2) const;

   /** @note The caller is responsible for deleting the returned pointer */
   virtual State *Widening(const State *state2) const;

   /** @note The caller is responsible for deleting the returned pointer */
   virtual State *Narrowing(const State *state2) const;

   /** Prints a textual representation of the state to @a os */
   virtual std::ostream &Print(std::ostream &os = std::cout) const;

   /** Prints a textral representation of the state's call stack to @a os */
   virtual std::ostream &PrintCallStack(std::ostream &os = std::cout) const;

   virtual std::ostream &Draw(std::ostream &os = std::cout) const;

protected:
   static int _name_int;
   static bool _reuse_call_stack;

   static std::string GetNextIntName();

   std::string _name;
   bool _is_bottom;
   ProgramCounterECFG *_pc;
   cheap_copy<VarEnviron> _genv;
   cheap_copy<PPEnviron> _pp_environ;
   Memory *_mem;
   cheap_copy<CallStack> _call_stack;

   State(std::unique_ptr<ProgramCounterECFG> pc, cheap_copy<VarEnviron> genv, 
         std::unique_ptr<Memory> mem, cheap_copy<CallStack> call_stack,
         cheap_copy<PPEnviron> pp_environ);

   State(const State &other);

   void CheckNotBottom() const {
      if (IsBottom())
         throw std::logic_error("This method should not be called on bottom states");
   }
};

inline std::ostream &operator <<(std::ostream &os, const State &state) { return state.Print(os); }

template <>
class MergeableStateTraits<State>
{
public:
   static const char* GetStateName(const State& state);

   static CECFGNode * GetECFGNode(const State & state);

   static bool AreMergeable(const State & state1, const State & state2);

   static bool CompareStatesIndexVecs(const State & a, const State & b);

   static std::unique_ptr<State> MergeStates(const State & state1,
                                           const State & state2);
};

#endif   // ifndef STATE_H_INCL
