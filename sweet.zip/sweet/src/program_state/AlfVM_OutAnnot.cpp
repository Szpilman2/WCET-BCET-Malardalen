#include "AlfVM.h"
#include "absann/CALFOutAnnotSpec.h"
#include "program_counter/ProgramCounter.h"
#include "value/IntInterval.h"
#include "value/FloatIntervalVal.h"
#include "value/SymbIntervalPtrSet.h"
#include "value/ReadValue.h"
#include "value/ValueDomain.h"
#include "value/IntegerDomain.h"
#include "value/clp/ClpValue.h"
#include "value/clp/SymbClpPtrSet.h"
#include "memory/Memory.h"
#include "memory/MemoryDomain.h"
#include "tools/Integer.h"
#include "tools/RangeIterator.h"
#include "globals.h"
#include "macros.h"

using namespace alf;

bool compare_out_annot_specs(CALFOutAnnotSpec * annot1, CALFOutAnnotSpec * annot2)
{
      // Note: assumes that there is only one var in varlist
   if (annot1->Position()->Type() < annot2->Position()->Type())
      return true;
   if (annot2->Position()->Type() < annot1->Position()->Type())
      return false;

   if (annot1->Position()->Func() < annot2->Position()->Func())
      return true;
   if (annot2->Position()->Func() < annot1->Position()->Func())
      return false;

   if (annot1->Position()->LRefId() < annot2->Position()->LRefId())
      return true;
   if (annot2->Position()->LRefId() < annot1->Position()->LRefId())
      return false;

   if (annot1->Position()->LOffs() < annot2->Position()->LOffs())
      return true;
   if (annot2->Position()->LOffs() < annot1->Position()->LOffs())
      return false;

   assert(annot1->VarList()->size() == 1);
   assert(annot2->VarList()->size() == 1);

   if (annot1->VarList()->front()->FRefId() < annot2->VarList()->front()->FRefId())
      return true;
   if (annot2->VarList()->front()->FRefId() < annot1->VarList()->front()->FRefId())
      return false;

   if (annot1->VarList()->front()->FOffsInBits() < annot2->VarList()->front()->FOffsInBits())
      return true;
   if (annot2->VarList()->front()->FOffsInBits() < annot1->VarList()->front()->FOffsInBits())
      return false;

   if (annot1->VarList()->front()->SizeInBits() < annot2->VarList()->front()->SizeInBits())
      return true;
   if (annot2->VarList()->front()->SizeInBits() < annot1->VarList()->front()->SizeInBits())
      return false;

   return false;
}

void AlfVM::HandleStmtEntryALFOutAnnotSpec(const alf::AStmt * stmt, const State *state)
{
   if (out_ann_specs == 0)
      return;
   if (list<CALFOutAnnotSpec *> * annot_list = out_ann_specs->GetStmtEntryALFOutAnnotSpec(const_cast<AStmt *>(stmt)))
   {
      for (list<CALFOutAnnotSpec *>::const_iterator ai = annot_list->begin(),
           an = annot_list->end(); ai != an; ++ai)
        {
            HandleALFOutAnnotSpec(state, *ai);
        }
   }
}

void AlfVM::HandleStmtExitALFOutAnnotSpec(const alf::AStmt * stmt, const vector<State*> &next_states)
{
   if (out_ann_specs == 0)
      return;
   if (list<CALFOutAnnotSpec *> * annot_list = out_ann_specs->GetStmtExitALFOutAnnotSpec(const_cast<AStmt *>(stmt)))
   {
      for (vector<State *>::const_iterator si = next_states.begin(),
           sn = next_states.end(); si != sn; ++si)
      {
         for (list<CALFOutAnnotSpec *>::const_iterator ai = annot_list->begin(),
              an = annot_list->end(); ai != an; ++ai)
         {
            HandleALFOutAnnotSpec(*si, *ai);
         }
      }
   }
}

void AlfVM::HandleALFOutAnnotSpec(const State * state, CALFOutAnnotSpec * annot) {

   const CSymTabBase * symbol_table = state->GetProgramCounter()->GetProgram()->GetSymTab();

      // Handle the variables
   for(list<CALFOutAnnotSpecVar * >::const_iterator var = annot->VarList()->begin();
       var != annot->VarList()->end(); var++) {
      Size value_size;
      if ((*var)->HasSizeInBits()) {
         value_size = (*var)->SizeInBits();
      }
      else
         {  // If no size was specified in the annotation, we must go to the symbol
            // table and find out the size of the allocated frame and use this as size
            const CSymTabIdentifier * st_id = symbol_table->Lookup((*var)->GetKey())->GetIdentifier();
            const CAllocTuple * alloc = &dynamic_cast<const CAllocTuple &>(*st_id);
            value_size = alloc->GetFrameSize()->GetSizeInBits();
         }

         // Get the value using the annotation
      unique_ptr<Value> base_addr(state->Lookup((*var)->GetKey(), cshack));
      Integer offset_val((*var)->HasFOffs() ? LAU::BitsToLAU((*var)->FOffsInBits()) : 0);
         // Conversion necessary
      unique_ptr<Value> offset(domain->GetIntegerDomain()->CreateInteger(base_addr->SizeInBits(), offset_val));
      unique_ptr<Value> address(domain->GetMemoryDomain()->CreatePointer(base_addr.get(), offset.get()));
      unique_ptr<Value> value(state->GetMemory()->Load(address.get(), value_size));
      assert(!value->IsBottom());
      list<CALFOutAnnotSpecVar * > * var_list = new list<CALFOutAnnotSpecVar * >;
      var_list->push_back((*var)->Copy());

         // Create the new out annotation specification
      unique_ptr<CALFOutAnnotSpec> new_annot_spec( new CALFOutAnnotSpec(annot->Position()->Copy(), var_list) );

      OutAnnotsValuesMap::iterator curr_spec = out_annots_values_map.find(new_annot_spec.get());
      if(curr_spec == out_annots_values_map.end()) {
            // No entry exists for the out annot. Add the annot and the value.
         out_annots_values_map[new_annot_spec.release()].push_back(value.release());
      } else if (g_merged_outp_annots == false) {
            // Add the value
         curr_spec->second.push_back(value.release());
      } else {
            // Merge in the value
         unique_ptr<Value> previous( curr_spec->second.front() );
         curr_spec->second.pop_back();
         assert(curr_spec->second.empty());
         unique_ptr<Value> lub(previous->LUB(value.get()));
         curr_spec->second.push_back(lub.release());
      }
   }
}

CALFAbsAnnot * AlfVM::TransformValueToAnnot(const CALFOutAnnotSpec * out_annot, const list<Value *> * value_list) const {
   struct AnnotValueVisitor : public ValueVisitor {
      vector<CALFAbsAnnotVal*> vals;

      ~AnnotValueVisitor() {
         for (RangeIterator<vector<CALFAbsAnnotVal*> > i(vals); i; ++i) delete *i;
      }

      virtual void VisitValue(const Value& value)
      {
         throw runtime_error("Cannot find correct subclass of Value");
      }

      // *********** TOP ******************
      virtual void VisitTopValue(const TopValue& value) { vals.push_back( new CALFAbsAnnotValTop() ); }

      // *********** INT ******************
      virtual void VisitIntInterval(const IntInterval& value)
      {
         if (value.IsTopBitstring())
            vals.push_back( new CALFAbsAnnotValInt() ); // Create a TOP_INT value
         else {
            // extract non-wrapping ranges from the signed interpretation of 'value' (the signed
            // interpretation is an arbitrary choice)
            IntInterval::IntRangeList subranges;
            value.GetSignedRanges(subranges);
            for (RangeIterator<IntInterval::IntRangeList> r(subranges); r; ++r) {
               int64_t l = r->L().As<int64_t>(), u = r->U().As<int64_t>();
            if (l == u)
                  vals.push_back( new CALFAbsAnnotValInt(l) );
            else
                  vals.push_back( new CALFAbsAnnotValInt(l, u) );
         }
      }
      }

      // *********** INT (CLP) **************
      virtual void VisitClpValue(const ClpValue& value)
      {
         if (value.IsTopBitstring())
            vals.push_back( new CALFAbsAnnotValInt() ); // Create a TOP_INT value
         else {
            // extract non-wrapping CLPs from the signed interpretation of 'value' (the signed
            // interpretation is an arbitrary choice)
            vector<Clp> subclps;
            value.GetSigned(subclps);
            for (RangeIterator<vector<Clp> > c(subclps); c; ++c) {
               int64_t l = c->GetBase().As<int64_t>();
               int64_t u = c->GetUpper().As<int64_t>();
               int64_t s = c->GetStride().As<int64_t>();
               if (l == u)
                  vals.push_back( new CALFAbsAnnotValInt(l) );
               else if (s == 1)
                  vals.push_back( new CALFAbsAnnotValInt(l, u) );
               else
                  vals.push_back( new CALFAbsAnnotValInt(l, u, s) );
            }
         }
      }

      // *********** FLOAT 32 bits ******************
      virtual void VisitOneFloatInterval8_23(const OneFloatInterval8_23& value)
      {
         if (value.IsTopBitstring())
            vals.push_back( new CALFAbsAnnotValFloat() ); // Create a TOP value
         else if (value.L() == value.U())
            vals.push_back( new CALFAbsAnnotValFloat(value.L()) );
         else
            vals.push_back( new CALFAbsAnnotValFloat(value.L(), value.U()) );
      }

      // *********** FLOAT 32 bits ******************
      virtual void VisitOneFloatInterval11_52(const OneFloatInterval11_52& value)
      {
         if (value.IsTopBitstring())
            vals.push_back( new CALFAbsAnnotValFloat() ); // Create a TOP value
         else if (value.L() == value.U())
            vals.push_back( new CALFAbsAnnotValFloat((float)value.L()) );
         else
            vals.push_back( new CALFAbsAnnotValFloat((float)value.L(), (float)value.U()) );
      }

      // *********** ADDR/LABEL ******************
      virtual void VisitSymbIntervalPtrSet(const SymbIntervalPtrSet& value) {
         if (value.IsTopSymbPointer()) {
            // since 'value' contains all possible addresses as well as all possible labels, push both
            vals.push_back( new CALFAbsAnnotValAddress() );
            vals.push_back( new CALFAbsAnnotValLabel() );
            return;
         }
         unique_ptr<SymbolToOffset> symbol_to_offset( value.GetSymbolToOffset() );
         unique_ptr<list<CFRefIdOffsetPair*> > frefid_offset_pair_list( new list<CFRefIdOffsetPair *> );
         unique_ptr<list<CLRefIdOffsetPair*> > lrefid_offset_pair_list( new list<CLRefIdOffsetPair *> );
         try {
            for (RangeIterator<SymbolToOffset> iter(*symbol_to_offset); iter; ++iter) {
                  const IntInterval * offset = iter->second->AsIntInterval();
                  int64_t l = offset->LAsSigned().As<int64_t>(), u = offset->UAsSigned().As<int64_t>();
               if (iter->first.GetSpace() == 0) { // address
                  // The offset can be one value or an interval
                  unique_ptr<CFRefIdOffsetPair> frefid_offset_pair;
                  if (l == u && l == 0)
                     frefid_offset_pair.reset( new CFRefIdOffsetPair(iter->first.GetAnnot(), (int32_t)0) );
                  else if (l == u)
                     frefid_offset_pair.reset( new CFRefIdOffsetPair(iter->first.GetAnnot(), LAU::LAUToBits(l)) );
                  else
                     frefid_offset_pair.reset( new CFRefIdOffsetPair(iter->first.GetAnnot(), LAU::LAUToBits(l), LAU::LAUToBits(u)) );
                  frefid_offset_pair_list->push_back(frefid_offset_pair.release());
               }
               else if (iter->first.GetSpace() == 1) { // label
                  assert(l == u);
                  unique_ptr<CLRefIdOffsetPair> lrefid_offset_pair( new CLRefIdOffsetPair(iter->first.GetAnnot(), l) );
                  lrefid_offset_pair_list->push_back(lrefid_offset_pair.release());
               }
            }
            if (!frefid_offset_pair_list->empty())
               vals.push_back( new CALFAbsAnnotValAddress(frefid_offset_pair_list.release()) );
            if (!lrefid_offset_pair_list->empty())
               vals.push_back( new CALFAbsAnnotValLabel(lrefid_offset_pair_list.release()) );          
            // clean up
               for (RangeIterator<SymbolToOffset> i(*symbol_to_offset); i; ++i) delete i->second;
         } catch (...) {
            // clean up and re-throw
            for (RangeIterator<SymbolToOffset> i(*symbol_to_offset); i; ++i) delete i->second;
            if (frefid_offset_pair_list.get())
               for_each(frefid_offset_pair_list->begin(), frefid_offset_pair_list->end(), Deleter());
            if (lrefid_offset_pair_list.get())
               for_each(lrefid_offset_pair_list->begin(), lrefid_offset_pair_list->end(), Deleter());
            throw;
         }
      }

      // *********** ADDR/LABEL (CLP) ************
      virtual void VisitSymbClpPtrSet(const SymbClpPtrSet& value) {
         if (value.IsTopSymbPointer()) {
            // since 'value' contains all possible addresses as well as all possible labels, push both
            vals.push_back( new CALFAbsAnnotValAddress() );
            vals.push_back( new CALFAbsAnnotValLabel() );
            return;
         }
         unique_ptr<list<CFRefIdOffsetPair*> > frefid_offset_pair_list( new list<CFRefIdOffsetPair*> );
         unique_ptr<list<CLRefIdOffsetPair*> > lrefid_offset_pair_list( new list<CLRefIdOffsetPair*> );
         try {
            unique_ptr<SopIterator> iter( value.GetIterator() );
            while (!iter->AtEnd()) {
               SymbolOffsetPair sop = iter->GetNext();
               if (sop.GetSymbol().GetSpace() == 0) // address
                  frefid_offset_pair_list->push_back( new CFRefIdOffsetPair(sop.GetSymbol().GetAnnot(), (int64_t)LAU::LAUToBits(sop.GetOffset())) );
               else if (sop.GetSymbol().GetSpace() == 1) // label
                  lrefid_offset_pair_list->push_back( new CLRefIdOffsetPair(sop.GetSymbol().GetAnnot(), (int64_t)LAU::LAUToBits(sop.GetOffset())) );
            }
            if (!frefid_offset_pair_list->empty())
               vals.push_back( new CALFAbsAnnotValAddress(frefid_offset_pair_list.release()) );
            if (!lrefid_offset_pair_list->empty())
               vals.push_back( new CALFAbsAnnotValLabel(lrefid_offset_pair_list.release()) );
         } catch (...) {
            // clean up and re-throw
            if (frefid_offset_pair_list.get())
               for_each(frefid_offset_pair_list->begin(), frefid_offset_pair_list->end(), Deleter());
            if (lrefid_offset_pair_list.get())
               for_each(lrefid_offset_pair_list->begin(), lrefid_offset_pair_list->end(), Deleter());
            throw;
         }
      }

      // *********** ReadValue ******************
      virtual void VisitReadValue(const ReadValue& value)
      {
         // Fuse and visit recursively
         unique_ptr<Value> fused(value.Fuse());
         fused->AcceptVisitor(this);
      }
   };

   CALFAbsAnnotPositionStmtEntry * entry_position;
   CALFAbsAnnotPositionStmtExit * exit_position;

   list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> > * new_var_vals_list =
      new list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >;
   list<CALFAbsAnnotVal *> * new_val_list = new list<CALFAbsAnnotVal *>;

   // Only one var-val pair
   assert(out_annot->VarList()->size() == 1);
   CALFOutAnnotSpecVar * var = out_annot->VarList()->front();
   CALFAbsAnnotVar * new_var = new CALFAbsAnnotVar(var->FRefId(), var->FOffsInBits(), var->SizeInBits());

   for (RangeIterator<const list<Value*> > iter(*value_list); iter; ++iter) {
      AnnotValueVisitor v;
      (*iter)->AcceptVisitor(&v);
      new_val_list->insert(new_val_list->end(), v.vals.begin(), v.vals.end());
      v.vals.clear();
   }
   new_var_vals_list->push_back(make_pair(new_var, new_val_list));

   // Create the abstract annotation
   if (out_annot->Position()->Type() == CALFAbsAnnotPosition::STMT_ENTRY) {
      entry_position = new CALFAbsAnnotPositionStmtEntry(out_annot->Position()->Func(),
         out_annot->Position()->LRefId(),
         out_annot->Position()->LOffs());
      return new CALFAbsAnnot(entry_position, CALFAbsAnnot::ASSIGN, new_var_vals_list);
   }
   else if (out_annot->Position()->Type() == CALFAbsAnnotPosition::STMT_EXIT) {
      exit_position = new CALFAbsAnnotPositionStmtExit(out_annot->Position()->Func(),
         out_annot->Position()->LRefId(),
         out_annot->Position()->LOffs());
      return new CALFAbsAnnot(exit_position, CALFAbsAnnot::ASSIGN, new_var_vals_list);
   }

   assert(false);
   return 0;
}
