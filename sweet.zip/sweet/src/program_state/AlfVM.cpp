#include "AlfVM.h"
#include "ae/AlfAbstractExecution.h"
#include "ae/AEStrategy.h"
#include "program/alf/alf.h"
#include "absann/CALFOutAnnotSpec.h"
#include "State.h"
#include "PPEnviron.h"
#include "VarEnviron.h"
#include "CallStack.h"
#include "LAU.h"
#include "RestrictedALFState.h"
#include "memory/Memory.h"
#include "value/Value.h"
#include "value/ReadValue.h"
#include "value/ValueDomain.h"
#include "value/IntegerDomain.h"
#include "value/FloatDomain.h"
#include "memory/MemoryDomain.h"
#include "program_counter/ProgramPointECFG.h"
#include "program_counter/ProgramCounterECFG.h"
#include "tools/Integer.h"
#include "tools/CSourceLoader.h"
#include "tools/RangeIterator.h"
#include "tools/IndentingOStream.h"
#include "tools/StrStream.h"
#include "globals.h"
#include "macros.h"

using namespace std;
using namespace alf;

bool compare_out_annot_specs(CALFOutAnnotSpec * annot1, CALFOutAnnotSpec * annot2);

AlfVMDebugger AlfVM::silent_debugger;

AlfVM::AlfVM()
   : abs_annots(0), out_ann_specs(0), debugger(&silent_debugger), source_loader(0),
     cshack(false), out_annots_values_map(&compare_out_annot_specs),
     global_targets(new Targets), _allow_call_site_return_addresses_different_from_return_values(false)
{}

AlfVM::~AlfVM()
{
   for (RangeIterator<OutAnnotsValuesMap> oi(out_annots_values_map); oi; ++oi) {
      delete oi->first;
      for_each(oi->second.begin(), oi->second.end(), Deleter());
   }
   delete global_targets;
}

void AlfVM::InitializeState(const alf::CAlfTuple * program, const alf::CFuncTuple * start_function,
                            State * state, bool ignore_volatile) const
{
   // Begin by declaring infinite-sized frames for unresolved (imported) global variables, as these
   // might later be referenced in the inits section
   HandleUnresolvedGlobals(program->GetImports(), state);
   // Handle global declarations and inits
   HandleDeclsAndInits(program->GetDecls(), program->GetInits(),
                       state->GetMutableGlobEnviron(), state->GetMemory(),
                       state, ignore_volatile);
   // Apply PROG_START annotations to global variables (before entering the first
   // function; this is important)
   HandleProgEntryALFAbsAnnot(state);
   EnterFirstFunction(start_function, state);
   state->GetProgramCounter()->UpdateWithProgramStart();
   // If there is a "func-entry" annotation on the starting function, apply it.
   HandleFuncEntryALFAbsAnnot(start_function, state);
}

void AlfVM::StepStmt(std::unique_ptr<State> state, std::vector<State *> & next_states)
{
   assert(state->GetProgramCounter());
   assert(state->GetProgramCounter()->GetProgramPoint());
   assert(state->GetProgramCounter()->GetProgramPoint()->GetStmt());
   const AStmt * stmt = dynamic_cast<const AStmt *>(state->GetProgramCounter()->GetProgramPoint()->GetStmt());
   assert(stmt);

   // update the state according to any "statement-entry" annotations
   HandleStmtEntryALFAbsAnnot(stmt, state.get());

   // handle any "statement-entry" output annotation specifications
   HandleStmtEntryALFOutAnnotSpec(stmt, state.get());

   debugger->Statement(stmt, state.get());

#  pragma push_macro("STMT_TYPE_CASE")
#  define STMT_TYPE_CASE(TYPE, SUBCLASS, METHOD)                            \
      case CGenericNode::TYPE:                                              \
         {                                                                  \
            const SUBCLASS *cast_stmt = static_cast<const SUBCLASS*>(stmt); \
            METHOD(cast_stmt, move(state), next_states);                    \
            break;                                                          \
         }

   switch (stmt->GetNodeType())
   {
   STMT_TYPE_CASE(TYPE_NULL_STMT_TUPLE,   CNullStmtTuple,   StepStmtNull)
   STMT_TYPE_CASE(TYPE_STORE_STMT_TUPLE,  CStoreStmtTuple,  StepStmtStore)
   STMT_TYPE_CASE(TYPE_JUMP_STMT_TUPLE,   CJumpStmtTuple,   StepStmtJump)
   STMT_TYPE_CASE(TYPE_SWITCH_STMT_TUPLE, CSwitchStmtTuple, StepStmtSwitch)
   STMT_TYPE_CASE(TYPE_CALL_STMT_TUPLE,   CCallStmtTuple,   StepStmtCall)
   STMT_TYPE_CASE(TYPE_RETURN_STMT_TUPLE, CReturnStmtTuple, StepStmtReturn)
   STMT_TYPE_CASE(TYPE_FREE_STMT_TUPLE,   CFreeStmtTuple,   StepStmtFree)
   default:
      assert("Unsupported statement" == NULL);
      break;
   }
#  pragma pop_macro("STMT_TYPE_CASE")

   debugger->StatementFinished(next_states);

   // update the state(s) according to any "statement-exit" annotations
   HandleStmtExitALFAbsAnnot(stmt, next_states);

   // handle any "statement-exit" output annotation specifications
   HandleStmtExitALFOutAnnotSpec(stmt, next_states);
}

void AlfVM::StepBB(std::unique_ptr<State> state, std::vector<State*> & next_states, const AESettings *settings)
{
   next_states.push_back(state.release());
   bool is_end_of_bb;
   do
   {
      if (next_states.size() > 1)
         throw logic_error("AlfVM::StepBB: next_states should not hold more than one state");
      unique_ptr<State> state(next_states.front());
      next_states.clear();
      is_end_of_bb = state->GetProgramCounter()->GetProgramPoint()->IsEndOfBasicBlock();
      StepStmt(move(state), next_states);
   }
   while (!is_end_of_bb);
}

void AlfVM::ExecuteTillTermination(std::unique_ptr<State> initial_state,
                                   std::vector<State *> & final_states,
                                   AEStrategy<State> & strategy,
                                   const AESettings *ae_settings,
                                   stringstream & bbt)
{
   bool use_css = ae_settings->css;
   bool use_bbt = ae_settings->gtf;

   while (strategy.MoreStatesToExecute())
   {
      // Get the next abstract state to process
      unique_ptr<State> state = strategy.GetNextStateToExecute();
      CECFGNode * prev_ecfg_node = const_cast<CECFGNode *>(state->GetProgramCounterECFG()->GetProgramPointECFG()->GetECFGNode());
      assert(state->GetProgramCounter());
      assert(state->GetProgramCounter()->GetProgramPoint());
      assert(state->GetProgramCounter()->GetProgramPoint()->GetStmt());
      AStmt const* stmt = &dynamic_cast<const AStmt &>(*state->GetProgramCounter()->GetProgramPoint()->GetStmt());
      // Process the abstract state
      try
      {
         vector<State *> state_set;
         StepStmt(move(state), state_set);

         if (use_bbt && prev_ecfg_node)
            bbt << prev_ecfg_node->GetFlowGraphNode()->Name() << " ";

         // Place resulting states in merge list and in final list
         MergeableStateColl<State> state_coll;
         for (vector<State *>::const_iterator s = state_set.begin(); s != state_set.end(); ++s)
         {
            if ((*s)->IsFinalState())
               final_states.push_back(*s);
            else
               state_coll.Insert(unique_ptr<State>(*s));
         }
         // Insert collected states in merge strategy data structure
         strategy.InsertStates(*prev_ecfg_node, state_coll);
      }
      // Check if we got some error
      catch (const SinglePathAEStrategy<State>::MoreThanOneState&)
      {
         stringstream ss;
         string used_option;
         if(use_css)
            used_option = "-ae css";
         else if(bbt)
            used_option = "-ae bbt";
         if(stmt)
            ss << "Error, more than one abstract state generated after executing statement at (line,column) " << stmt->GetLine() << ',' << stmt->GetColumn() << ". Not allowed when option " << used_option << " is used.";
         else
            ss << "Error, more than one abstract state generated. Not allowed when option " << used_option << " is used.";
         throw runtime_error(ss.str());
      }
      catch(std::exception const& e)
      {
         if (stmt)
         {
            stringstream ss;
            ss << "Error executing statement at (line,column) " << stmt->GetLine() << ',' << stmt->GetColumn() << ": " << e.what();
            throw runtime_error(ss.str());
         }
         else
         {
            stringstream ss;
            ss << "Error executing state: " << e.what();
            throw runtime_error(ss.str());
         }
      }
   }

   if(out_annots_values_map.size() > 0) {
      list<CALFAbsAnnot *> annot_list;
      try {
            // Create annots from the map
         for (OutAnnotsValuesMap::iterator iter = out_annots_values_map.begin(); iter != out_annots_values_map.end(); iter++) {
            CALFAbsAnnot * abs_annot = TransformValueToAnnot(iter->first, &(iter->second));
            annot_list.push_back(abs_annot);
         }
         for (list<CALFAbsAnnot *>::iterator iter1 = annot_list.begin(); iter1 != annot_list.end(); iter1++) {
            for (list<CALFAbsAnnot *>::iterator iter2 = iter1; iter2 != annot_list.end(); ) {
                  // Skip the first
               if (iter2 == iter1) {
                  iter2++;
               }
               if (iter2 != annot_list.end()) {
                  if ((((*iter1)->Position())->IsEqual((*iter2)->Position())) && ((*iter1)->Type() == (*iter2)->Type())) {
                        // So far, all annots should have just one var-val list member
                     assert((*iter2)->VarValsList()->size() == 1);
                     CALFAbsAnnotVar * new_var = (*iter2)->VarValsList()->front().first->Copy();
                     if (g_merged_outp_annots) {
                           // If we have a merged value, the list must contain only one (merged) value
                        assert((*iter2)->VarValsList()->front().second->size() == 1);
                        CALFAbsAnnotVal * new_val = (*iter2)->VarValsList()->front().second->front()->Copy();
                        list<CALFAbsAnnotVal *> * new_val_list = new list<CALFAbsAnnotVal *>;
                        new_val_list->push_back(new_val);
                        pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> new_vvpair = make_pair(new_var, new_val_list);
                        (*iter1)->GetModifyableVarValsList()->push_back(new_vvpair);
                     } else {
                           // If we don't have a merged value, create a list of values
                        list<CALFAbsAnnotVal *> * new_val_list = new list<CALFAbsAnnotVal *>;
                        for(list<CALFAbsAnnotVal *>::iterator val = (*iter2)->VarValsList()->front().second->begin();
                           val != (*iter2)->VarValsList()->front().second->end(); val++ ) {
                              CALFAbsAnnotVal * new_val = (*val)->Copy();
                              new_val_list->push_back(new_val);
                        }
                        pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> new_vvpair = make_pair(new_var, new_val_list);
                        (*iter1)->GetModifyableVarValsList()->push_back(new_vvpair);
                     }

                        // Clean up
                     delete (*iter2)->VarValsList()->front().first;
                        // Loop through the parallel assignments in the abstract annotation updating map
                     for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::const_iterator var_vals = (*iter2)->VarValsList()->begin();
                        var_vals != (*iter2)->VarValsList()->end(); ++var_vals) {
                           delete (*var_vals).second;
                     }
                     delete (*iter2)->VarValsList();
                     delete (*iter2)->Position();
                     iter2 = annot_list.erase(iter2);
                  } else {
                     ++iter2;
                  }
               }
            }
         }

         if (!g_merged_outp_annots) {
               // Eliminate duplicates in non-merged list
            for (list<CALFAbsAnnot *>::iterator annot = annot_list.begin(); annot != annot_list.end(); annot++) {
                  // Loop through the parallel assignments in the abstract annotation updating map
               for(list<pair<CALFAbsAnnotVar *, list<CALFAbsAnnotVal *> *> >::const_iterator var_vals = (*annot)->VarValsList()->begin();
                  var_vals != (*annot)->VarValsList()->end(); ++var_vals) {
                     list<CALFAbsAnnotVal *> *vals = var_vals->second;
                        // Eliminate duplicates in the annotations
                     for (list<CALFAbsAnnotVal *>::iterator val = vals->begin(); val != vals->end(); ++val) {
                        (*val)->Eliminate_Duplicates();
                     }
                     for (list<CALFAbsAnnotVal *>::iterator val1 = vals->begin(); val1 != vals->end(); ++val1) {
                        list<CALFAbsAnnotVal *>::iterator val2 = val1;
                        ++val2; // Skip the first
                        while (val2 != vals->end()) {
                           if (!(*val1)->IsEqual(*val2)) {
                              ++val2;
                           } else {
                              val2 = vals->erase(val2);
                           }
                        }
                     }
               }
            }
         }
            // Fix the file name
         string base_name;
         size_t dot_pos = g_output_annotation_specification_file_name.find_last_of('.');
         if (dot_pos != string::npos) {
            base_name = g_output_annotation_specification_file_name.substr(0, dot_pos);
         }
         base_name = base_name + ".out";

            // Print the list to file
         ofstream file_stream;
         file_stream.open(base_name.c_str(), ios::out);
         if (file_stream.fail()) {
            throw runtime_error("The file " + base_name + " could not be opened");
         }
         for (list<CALFAbsAnnot *>::iterator iter = annot_list.begin(); iter != annot_list.end(); iter++) {
            file_stream << **iter << endl;
         }
         file_stream.close();
         for_each(annot_list.begin(), annot_list.end(), Deleter());
      }
      catch (...) {
         for_each(annot_list.begin(), annot_list.end(), Deleter());
         throw;
      }
   }
}

const Value *AlfVM::Lookup(const VarEnviron *env, const string &ann)
{
   SymbolColl syms;
   // iterate through all frames mapped to in the environment
   for (VarEnviron::EnvIterator i = env->GetEnvIterator(), n = env->GetEnvEndIterator(); i != n; ++i) {
      // fetch the symbol part of the frame pointer
      const SymbPointer *ptr = i->second.GetBasePointer()->AsSymbPointer();
      if (ptr == 0) continue; // no symbols or annotations can be retrieved
      syms.clear();
      ptr->GetSymbols(syms);
      // if the symbol's annotation is a match, return the base pointer
      if (syms.begin()->GetAnnot() == ann)
         return ptr;
   }
   return 0;
}

AlfVMDebugger * AlfVM::GetAEDebugger() const
{
   return static_cast<AlfVMDebugger *>(debugger);
}

void AlfVM::ReportDiscardedState(const State &discarded) const { cout << "Discarding state \"" << discarded.GetName() << "\"." << endl; }

void AlfVM::HandleUnresolvedGlobals(const alf::CImportsTuple * imports, State * state) const
{
   VarEnviron * genv = state->GetMutableGlobEnviron();
   Memory * mem = state->GetMemory();
   const CFRefList * imported_frefs = imports->GetFRefList();
   for (CFRefList::const_list_iterator f = imported_frefs->ConstIterator();
        f != imported_frefs->InvalidIterator(); ++f)
   {
      unsigned fref_id = (*f)->GetKey();
      assert(genv->Defined(fref_id) == false || "Multiple declarations of the same frame id" == 0);
      Size ref_size = (*f)->GetSize()->GetSizeInBits();
      unique_ptr<Value> ref_to_frame(mem->AllocFrame(Size::Infinity(), ref_size, (*f)->GetId()));
      // Set the whole frame as volatile
      // mem->SetAsVolatile(ref_to_frame.get(), Size::Infinity());
      // Store connection in environment
      genv->Update(fref_id, move(ref_to_frame), Size::Infinity());
   }
}

void AlfVM::HandleDeclsAndInits(const alf::CDeclList * decls, const alf::CInitList * inits, 
                                VarEnviron * env, Memory * mem, State * state, bool ignore_volatile) const
{

   // Run through the list of declarations, allocate frames in mem plus add mappings from the declared identifiers
   // to the reference to the newly allocated frame
   for (CDeclList::const_list_iterator di = decls->ConstIterator(); di != decls->InvalidIterator(); ++di)
   {
      unsigned fref_id = (*di)->GetKey();
      assert(env->Defined(fref_id) == false || "Multiple declarations of the same frame id" == 0);

      Size frame_size = (*di)->GetFrameSize()->GetSizeInBits();
      Size ref_size = (*di)->GetBitstringSize()->GetSizeInBits();
      unique_ptr<Value> ref_to_frame(mem->AllocFrame(frame_size, ref_size, (*di)->Name()));
      env->Update(fref_id, move(ref_to_frame), frame_size);
   }

   // A useful value to use as carry in to various additions
   assert(domain->GetIntegerDomain());
   unique_ptr<Value> carry_in(domain->GetIntegerDomain()->CreateInteger(1, 0));

   // Run through the list of initializations, evaluate each expression, and store the resulting value in the newly
   // allocated memory
   for (CInitList::const_list_iterator i = inits->ConstIterator(); i != inits->InvalidIterator(); ++i)
   {

      const CRefTuple * ref_tuple = (*i)->GetRef();
      unsigned fref_id = ref_tuple->GetKey();
      assert(env->Defined(fref_id) || "Trying to initialize an undeclared frame" == NULL);
      
      unique_ptr<Value> fref(env->ApplyEnvFunction(fref_id));
      unique_ptr<Value> offset(EvalExprNumValInt(ref_tuple->GetOffset()));

      const AVal * value = (*i)->GetVal();
      bool set_to_volatile = (*i)->GetInitOption() == CInitTuple::VOLATILE && !ignore_volatile;

      // Check the type of initialization and carry it out
      if (value->IsType(CGenericNode::TYPE_CONST))
      {
         unique_ptr<Value> init_addr(domain->GetMemoryDomain()->CreatePointer(fref.get(), offset.get()));
         const AExpr * expr = DynCast<const AExpr>(DynCast<const AConst>(value));
         if (!set_to_volatile)
         {
            unique_ptr<Value> val(EvalExpr(expr, state)); // TODO: can this become bottom?
            mem->Store(init_addr.get(), val.get(), false);
         }
         else
            mem->SetAsVolatile(init_addr.get(), expr->GetSize()->GetSizeInBits());
      }
      else if (value->IsType(CGenericNode::TYPE_CONSTREPEAT_TUPLE))
      {
         const CConstRepeatTuple * repeat_tuple = DynCast<const CConstRepeatTuple>(value);
         const AExpr * expr = DynCast<const AExpr>(repeat_tuple->GetConst());
         unsigned int nr_repeats = repeat_tuple->GetRepeats();
         if (!set_to_volatile)
         {
            // Write the constant nr_repeats times to the frame
            unique_ptr<Value> evaled(EvalExpr(expr, state)); // TODO: can this become bottom?
            unique_ptr<Value> offset_incr(domain->GetIntegerDomain()->CreateInteger(offset->SizeInBits(), Integer(evaled->SizeInLAU().AsBaseIntType())));
            for (unsigned int r = 0; r < nr_repeats; ++r)
            {
               unique_ptr<Value> init_addr(domain->GetMemoryDomain()->CreatePointer(fref.get(), offset.get()));
               mem->Store(init_addr.get(), evaled.get(), false);
               offset.reset(offset->Add(offset_incr.get(), carry_in.get()));
            }
         }
         else
         {
            // Multiply the size of the constant with nr_repeats and set the frame part
            // as volatile
            unique_ptr<Value> init_addr(domain->GetMemoryDomain()->CreatePointer(fref.get(), offset.get()));
            mem->SetAsVolatile(init_addr.get(), expr->GetSize()->GetSizeInBits() * nr_repeats);
         }
      }
      else if (value->IsType(CGenericNode::TYPE_CONST_LIST))
      {
         const CConstList * const_list = DynCast<const CConstList>(value);
         for (CConstList::const_list_iterator c = const_list->ConstIterator();
              c != const_list->InvalidIterator(); ++c)
         {
            const AExpr * expr = DynCast<const AExpr>(*c);
            unique_ptr<Value> init_addr(domain->GetMemoryDomain()->CreatePointer(fref.get(), offset.get()));
            if (!set_to_volatile)
            {
               unique_ptr<Value> evaled(EvalExpr(expr, state)); // TODO: can this result in bottom?
               mem->Store(init_addr.get(), evaled.get(), false);
            }
            else
               mem->SetAsVolatile(init_addr.get(), expr->GetSize()->GetSizeInBits());
            // Update the offset for the next iteration
            unique_ptr<Value> offset_incr(domain->GetIntegerDomain()->CreateInteger(offset->SizeInBits(), 
               Integer(LAU::BitsToLAU(expr->GetSize()->GetSizeInBits().AsBaseIntType()))));
            offset.reset(offset->Add(offset_incr.get(), carry_in.get()));
         }
      }
      else if (value->IsType(CGenericNode::TYPE_INT_LIST))
      {
         const CIntListTuple * int_list = static_cast<const CIntListTuple *>(value);
         for (CIntListTuple::const_list_iterator i = int_list->ConstIterator();
              i != int_list->InvalidIterator(); ++i)
         {
            unique_ptr<Value> init_addr(domain->GetMemoryDomain()->CreatePointer(fref.get(), offset.get()));
            if (!set_to_volatile)
            {
               unique_ptr<Value> evaled(EvalExprNumValInt(*i));
               mem->Store(init_addr.get(), evaled.get(), false);
            }
            else
               mem->SetAsVolatile(init_addr.get(), (*i)->GetSize()->GetSizeInBits());
            // Update the offset for the next iteration
            unique_ptr<Value> offset_incr(domain->GetIntegerDomain()->CreateInteger(offset->SizeInBits(), 
               Integer(LAU::BitsToLAU((*i)->GetSize()->GetSizeInBits().AsBaseIntType()))));
            offset.reset(offset->Add(offset_incr.get(), carry_in.get()));
         }
      }
      else if (value->IsType(CGenericNode::TYPE_FLOAT_LIST))
      {
         const CFloatListTuple * float_list = static_cast<const CFloatListTuple *>(value);
         for (CFloatListTuple::const_list_iterator f = float_list->ConstIterator();
              f != float_list->InvalidIterator(); ++f)
         {
            // Add the sizes of the sign bit, the exponent, and the fraction part to
            // get the value's total size
            Size size_in_bits = 1 + (*f)->GetExpSize()->GetSizeInBits()
                              + (*f)->GetFracSize()->GetSizeInBits();
            unique_ptr<Value> init_addr(domain->GetMemoryDomain()->CreatePointer(fref.get(), offset.get()));
            if (!set_to_volatile)
            {
               unique_ptr<Value> evaled(EvalExprNumValFloat(*f));
               mem->Store(init_addr.get(), evaled.get(), false);
            }
            else               
               mem->SetAsVolatile(init_addr.get(), size_in_bits);
            // Update the offset for the next iteration
            unique_ptr<Value> offset_incr(domain->GetIntegerDomain()->CreateInteger(offset->SizeInBits(), 
                                         Integer(LAU::BitsToLAU(size_in_bits.AsBaseIntType()))));
            offset.reset(offset->Add(offset_incr.get(), carry_in.get()));
         }
      }
      else if (value->IsType(CGenericNode::TYPE_CHARSTRING_TUPLE))
      {
         const CCharStringTuple * char_string_tuple = static_cast<const CCharStringTuple *>(value);
         string char_string = char_string_tuple->GetString()->Get();
         unique_ptr<Value> offset_incr(domain->GetIntegerDomain()->CreateInteger(offset->SizeInBits(), 1));
         for (string::const_iterator c = char_string.begin(); c != char_string.end(); ++c)
         {
            unique_ptr<Value> init_addr(domain->GetMemoryDomain()->CreatePointer(fref.get(), offset.get()));
            if (!set_to_volatile)
            {
               unique_ptr<Value> evaled(domain->GetIntegerDomain()->CreateInteger(LAU::LAU(), (unsigned char)(*c)));
               mem->Store(init_addr.get(), evaled.get(), false);
            }
            else
               mem->SetAsVolatile(init_addr.get(), LAU::LAU());
            // Update the offset for the next iteration
            offset.reset(offset->Add(offset_incr.get(), carry_in.get()));
         }
      }
      // Other types
      else 
      {
         assert("Not implemented" == NULL);
      }
   }
}

void AlfVM::EnterFirstFunction(const CFuncTuple * function, State * state) const
{    
   // Create a new environment to hold mappings between frame refs and frames 
   unique_ptr<VarEnviron> env( new VarEnviron );

   // 0. Allocate frames corresponding to the function's formal argument list.
   // Compared to a normal function call there are no actual arguments that should 
   // be evaluated and stored in memory.

   // Loop through all formal arguments
   const CArgDeclList * form_args = function->GetArgs();
   for (CArgDeclList::const_list_iterator farg = form_args->ConstIterator();
        farg != form_args->InvalidIterator(); farg++)
   {
      // Allocate frame and add mapping to environment
      unsigned fref_id = (*farg)->GetKey();
      Size frame_size = (*farg)->GetFrameSize()->GetSizeInBits();
      Size ref_size = (*farg)->GetBitstringSize()->GetSizeInBits();
      unique_ptr<Value> fref(state->GetMemory()->AllocFrame(frame_size, ref_size, (*farg)->Name()));
      // We assume that the offset has the same size as the ref
      unique_ptr<Value> offset(domain->GetIntegerDomain()->CreateInteger(ref_size, 0));
      unique_ptr<Value> addr(domain->GetMemoryDomain()->CreatePointer(fref.get(), offset.get()));
      env->Update(fref_id, move(fref), frame_size);
   }

   // 1. Collect all the scope tuples in the function. For all scope tuples we handle 
   // their declarations and initialization of variables. 

   vector<CGenericStmt *> scope_stmts;
   scope_stmts.push_back((CScopeTuple *) function->GetScope());
   function->GetStmtsInFunctionScopeAndSubordinateScopes(&scope_stmts, CGenericNode::TYPE_SCOPE_TUPLE);

   for (vector<CGenericStmt *>::const_iterator sc = scope_stmts.begin(); sc != scope_stmts.end(); ++sc)
   {
      const CScopeTuple * scope_tuple = dynamic_cast<const CScopeTuple *>(*sc);
      assert(scope_tuple != 0);

      HandleDeclsAndInits(scope_tuple->GetDecls(), scope_tuple->GetInits(), 
                          env.get(), state->GetMemory(), state, true);
   }

   // 2. Allocate frames corresponding to the function's return 
   // arguments and put their addresses on the return address list.
   // Compared to a normal function return these frames will never be  
   // popped from the list and the function result statement

   // Get the list of return statements
   std::vector<CGenericStmt*> return_stmts;
   function->GetStmtsInFunctionScopeAndSubordinateScopes(&return_stmts, CGenericNode::TYPE_RETURN_STMT_TUPLE);
   assert(return_stmts.size() > 0);

   // Create a place to store the return addresses in
   unique_ptr<RetAddrList> ret_addr_list(new RetAddrList);

   // Loop through all argument exprs and allocate a frame where to store the content
   const CExprList * return_arg_exprs = (DynCast<CReturnStmtTuple>(return_stmts.front()))->GetExprs();
   for(CExprList::list_iterator return_arg_expr = return_arg_exprs->ConstIterator();
       return_arg_expr != return_arg_exprs->InvalidIterator(); return_arg_expr++) 
   {
      // Derive the size of the frame where to store the result
      AExpr * arg_expr = (*return_arg_expr);
      Size arg_expr_size = arg_expr->GetSizeOfEvaluatedExpr();

      // Allocate the frame of the given size from memory
      unique_ptr<Value> fref(state->GetMemory()->AllocFrame(arg_expr_size, Size::Infinity(),
                                                          "return value from entry function"));
      unique_ptr<Value> offset(domain->GetIntegerDomain()->CreateInteger(Size::Infinity(), 0));
      unique_ptr<Value> addr(domain->GetMemoryDomain()->CreatePointer(fref.get(), offset.get()));
      // Store the address in the list of return addresses
      ret_addr_list->push_back(move(addr));
   }

   // Push the resulting environment and return address list on the call stack. We use the 
   // specified argument program point. It should be a final program point and not actually 
   // returned to.
   unique_ptr<ProgramPoint> final_pp = CreateFinalProgramPoint();
   assert(final_pp->IsFinal());
   state->GetMutableCallStack()->PushFunction(move(final_pp), move(env), move(ret_addr_list), function->Name());
}

bool AlfVM::EnterFunction(const CFuncTuple * function, unique_ptr<ProgramPoint> func_entry_pp, const alf::CExprList * arg_exprs,
                          const alf::CExprList * ret_addr_expr_list, State * state, const CCallStmtTuple * call_stmt) const
{
   // Evaluate the list of return address expressions into real addresses
   unique_ptr<RetAddrList> ret_addr_list(new RetAddrList);

   for (CExprList::const_list_iterator ra = ret_addr_expr_list->ConstIterator(); 
        ra != ret_addr_expr_list->InvalidIterator(); ++ra)
   {
      ret_addr_list->push_back( unique_ptr<Value>(EvalExpr(*ra, state)) );
      if (ret_addr_list->back()->IsBottom()) {
         cout << "Note: call at " << call_stmt->GetCoord() << " failed since the return address expression at "
              << (*ra)->GetCoord() << " did not evaluate to a valid address:\n\n"
              << *ret_addr_list->back() << "\n\n";
         ReportDiscardedState(*state);
         // note: the state is discarded in the invoking function StepStmtCall()
         return false;
      }
   }

   // Collect all the scope tuples in the function
   vector<CGenericStmt *> scope_stmts;
   scope_stmts.push_back((CScopeTuple *) function->GetScope());
   function->GetStmtsInFunctionScopeAndSubordinateScopes(&scope_stmts, CGenericNode::TYPE_SCOPE_TUPLE);

   unique_ptr<VarEnviron> env( new VarEnviron );

   for (vector<CGenericStmt *>::const_iterator sc = scope_stmts.begin(); sc != scope_stmts.end(); ++sc)
   {
      const CScopeTuple * scope_tuple = dynamic_cast<const CScopeTuple *>(*sc);
      assert(scope_tuple != 0);

      HandleDeclsAndInits(scope_tuple->GetDecls(), scope_tuple->GetInits(), 
                          env.get(), state->GetMemory(), state, true);
   }

   const CArgDeclList * form_args = function->GetArgs();
   if (arg_exprs->ElementCount() != form_args->ElementCount())
   {
      assert("Wrong number of arguments passed to function" == NULL);
   }

   CArgDeclList::const_list_iterator farg;
   CExprList::const_list_iterator aarg;
   for (farg = form_args->ConstIterator(), aarg = arg_exprs->ConstIterator();
	    farg != form_args->InvalidIterator() && aarg != arg_exprs->InvalidIterator();
        ++farg, ++aarg)
   {
      // Allocate frame and add mapping to environment
      {
         unsigned fref_id = (*farg)->GetKey();
         if (env->Defined(fref_id))
         {
            assert("Multiple declarations of the same frame id" == NULL);
         }

         Size frame_size = (*farg)->GetFrameSize()->GetSizeInBits();
         Size ref_size = (*farg)->GetBitstringSize()->GetSizeInBits();
         unique_ptr<Value> fref(state->GetMemory()->AllocFrame(frame_size, ref_size, (*farg)->Name()));
         // We assume that the offset has the same size as the ref
         unique_ptr<Value> offset(domain->GetIntegerDomain()->CreateInteger(ref_size, 0));
         unique_ptr<Value> addr(domain->GetMemoryDomain()->CreatePointer(fref.get(), offset.get()));

         unique_ptr<Value> evaled_arg(EvalExpr(*aarg, state));
         if (evaled_arg->IsBottom()) {
            // note: the state is discarded in the invoking function StepStmtCall()
            cout << "Note: call at " << call_stmt->GetCoord() << " failed since the argument expression at "
                 << (*aarg)->GetCoord() << " did not evaluate to a valid value:\n\n"
                 << *evaled_arg << "\n\n";
            ReportDiscardedState(*state);
            return false;
         }

         state->GetMemory()->Store(addr.get(), evaled_arg.get(), false);
         env->Update(fref_id, move(fref), frame_size);
      }
   }
   unique_ptr<ProgramPoint> return_pp(state->GetProgramCounter()->GetProgramPoint()->GetTextualSuccessor());
   state->GetMutableCallStack()->PushFunction(move(return_pp), move(env), move(ret_addr_list), function->Name());

   state->GetProgramCounter()->UpdateWithNewProgramPoint(move(func_entry_pp));

   assert(state->GetProgramCounter()->GetProgramPoint());
   return true;
}

unique_ptr<ProgramPoint> AlfVM::CreateFinalProgramPoint() const
{
   return unique_ptr<ProgramPoint>(new ProgramPointECFG());
}

void
AlfVM::
StepStmtNull(const CNullStmtTuple *null_stmt, std::unique_ptr<State> state,
             std::vector<State *> & next_states) const
{

   assert(state.get());
   assert(state->GetProgramCounter());
   state->GetProgramCounter()->StepToTextualSuccessor();
   next_states.push_back(state.release());
}

void AlfVM::StepStmtStore(const CStoreStmtTuple *store_stmt, std::unique_ptr<State> state,
                          std::vector<State *> & next_states) const
{
   struct {
      void operator ()(const CStoreStmtTuple *stmt, int idx, const Value *addr) {
         cout << "Note: store at " << stmt->GetCoord() << " failed since the address expression at "
            << stmt->GetAddrExprs()->ElementAt(idx)->GetCoord() << " did not evaluate to "
            "any valid memory locations:\n\n" << *addr << "\n\n";
      }
   }
   PrintInvalidStoreMsg;

   // Report to the debugger
   debugger->StoreStatement(store_stmt);

   // Retrieve components of store statement
   const CExprList* exprs = store_stmt->GetExprs();
   const CExprList* addr_exprs = store_stmt->GetAddrExprs();
   assert(exprs->ElementCount() == addr_exprs->ElementCount());

   int nr_exprs = (int)exprs->ElementCount();
   vector<Value*> ev_exprs(nr_exprs, (Value*)0), ev_addrs(nr_exprs, (Value*)0); // TODO: less messy cleanup of these

   try {
      // Evaluate expressions to be stored and addresses
      for (int e = 0; e != nr_exprs; ++e) {
         // Evaluate stored expression
         ev_exprs[e] = EvalExpr(exprs->ElementAt(e), state.get());
         debugger->StoredValue(ev_exprs[e]);
         // Check the value
         if (ev_exprs[e]->IsBottom()) {
            cout << "Note: store at " << store_stmt->GetCoord() << " failed since the stored expression at "
                 << exprs->ElementAt(e)->GetCoord() << " did not evaluate to a valid value:\n\n"
                 << *ev_exprs[e] << "\n\n";
            ReportDiscardedState(*state);
            for_each(ev_exprs.begin(), ev_exprs.end(), Deleter());
            for_each(ev_addrs.begin(), ev_addrs.end(), Deleter());
            return;
         }

         // Evaluate address to store to
         ev_addrs[e] = EvalExpr(addr_exprs->ElementAt(e), state.get());
         const ReadValue *rv_addr = ev_addrs[e]->AsReadValue();
         if (rv_addr != 0) { // TODO: ugly
            unique_ptr<Value> tmp( ev_addrs[e] );
            ev_addrs[e] = rv_addr->Fuse();
         }
         debugger->StoredToAddress(ev_addrs[e]);
         // Check the value
         if (ev_addrs[e]->IsBottom()) {
            cout << "Note: store at " << store_stmt->GetCoord() << " failed since the address expression at "
                 << exprs->ElementAt(e)->GetCoord() << " did not evaluate to a valid address:\n\n"
                 << *ev_exprs[e] << "\n\n";
            ReportDiscardedState(*state);
            for_each(ev_exprs.begin(), ev_exprs.end(), Deleter());
            for_each(ev_addrs.begin(), ev_addrs.end(), Deleter());
            return;
         }
      }

      // Perform stores with concrete addresses
      for (int e = 0; e != nr_exprs; ++e) {
         // check if address is concrete symbolic address
         const SymbPointer *addr = ev_addrs[e]->AsSymbPointer();
         if (addr == 0 || !addr->IsSingleElem()) continue;
         // perform store
         // TODO: If this store overlaps with a previous concrete store, the previous
         //       one is overwritten. Preferrably, both store orders should be represented
         //       in the new state.
         bool successful_stores, unsuccessful_stores;
         state->GetMemory()->Store(addr, ev_exprs[e], false, successful_stores, unsuccessful_stores);
         // Check that the stored-to address overlapped at least one valid memory location;
         // if that is not the case, terminate immediately because the state is then invalid.
         // TODO: Report this as a special case to the debugger?
         if (!successful_stores) {
            PrintInvalidStoreMsg(store_stmt, e, addr);
            ReportDiscardedState(*state);
            for_each(ev_exprs.begin(), ev_exprs.end(), Deleter());
            for_each(ev_addrs.begin(), ev_addrs.end(), Deleter());
            return;
         }
      }

      // Perform stores with abstract addresses
      Memory *mem = state->GetMemory();
      for (int e = 0; e != nr_exprs; ++e) {
         // skip concrete symbolic addresses
         const SymbPointer *addr = ev_addrs[e]->AsSymbPointer();
         if (addr != 0 && addr->IsSingleElem()) continue;
         // Store the value
         bool successful_stores, unsuccessful_stores;
         mem->Store(ev_addrs[e], ev_exprs[e], false, successful_stores, unsuccessful_stores);
         // Check that the stored-to address overlapped at least one valid memory location;
         // if that is not the case, terminate immediately because the state is then invalid.
         if (!successful_stores) {
            PrintInvalidStoreMsg(store_stmt, e, ev_addrs[e]);
            ReportDiscardedState(*state);
            for_each(ev_exprs.begin(), ev_exprs.end(), Deleter());
            for_each(ev_addrs.begin(), ev_addrs.end(), Deleter());
            return;
         }
      }

      state->GetProgramCounter()->StepToTextualSuccessor();
      next_states.push_back(state.release());
      for_each(ev_exprs.begin(), ev_exprs.end(), Deleter());
      for_each(ev_addrs.begin(), ev_addrs.end(), Deleter());
   }
   catch (...) {
      for_each(ev_exprs.begin(), ev_exprs.end(), Deleter());
      for_each(ev_addrs.begin(), ev_addrs.end(), Deleter());
      throw;
   }
}

void AlfVM::StepStmtJump(const CJumpStmtTuple * jump_stmt, unique_ptr<State> state,
                         std::vector<State *> & next_states) const
{
   debugger->JumpStatement(jump_stmt);

   const AExpr *label_expr = jump_stmt->GetLabelExpr();
   unique_ptr<Value> jump_addr(EvalExpr(label_expr, state.get()));

   vector<ProgramPointECFG *> jumped_to_pps;
   state->GetPPEnviron()->LookupStmt(
      *state->GetProgramCounterECFG()->GetProgramPointECFG(), *jump_addr, jumped_to_pps);

   if (jumped_to_pps.empty()) {
      cout << "Note: jump at " << jump_stmt->GetCoord() << " failed since the label expression at "
           << label_expr->GetCoord() << " did not evaluate to any valid jump targets:\n\n" << *jump_addr << "\n\n";
      ReportDiscardedState(*state);
      return;
   }

   unique_ptr<State> new_state;
   while (!jumped_to_pps.empty())
   {
      unique_ptr<ProgramPoint> p(jumped_to_pps.back());
      jumped_to_pps.pop_back();
      if (!jumped_to_pps.empty())
         new_state.reset(state->Copy());
      else
         new_state = move(state);
      debugger->JumpedToPP(p.get());
      new_state->GetProgramCounter()->UpdateWithNewProgramPoint(move(p));
      next_states.push_back(new_state.release());
   }
}

void AlfVM::StepStmtSwitch(const CSwitchStmtTuple * switch_stmt,
                           unique_ptr<State> state,
                           std::vector<State *> & next_states) const
{
   int nr_succ_states = 0;

   // Tell the debugger that a switch statement is being executed
   GetAEDebugger()->SwitchStatement(switch_stmt);

   const AExpr * num_expr = switch_stmt->GetNumExpr();

   // TODO: When StepStmtSwitch_NEqSpecial() has been thoroughly tested, remove
   // "&& false" and add a parameter that controls whether the function should be used
   //if (num_expr->IsType(CGenericNode::TYPE_OP_EXPR_TUPLE) && false)
   //{
   //   const COpNumExprTuple* op_expr = (COpNumExprTuple*) num_expr;
   //   if (op_expr->GetOperator() == COpNumExprTuple::OP_TYPE_EQ ||
   //       op_expr->GetOperator() == COpNumExprTuple::OP_TYPE_NEQ)
   //   {
   //      StepStmtSwitch_NEqSpecial(switch_stmt, op_expr, state, next_states);
   //      return;
   //   }
   //}

   // Evaluate switch expression
   unique_ptr<Value> evaled_switch_expr(EvalExpr(num_expr, state.get()));
   GetAEDebugger()->EvaledSwitchExpr(evaled_switch_expr.get());

   // Check validity of the state
   if (evaled_switch_expr->IsBottom()) {
      cout << "Note: switch at " << switch_stmt->GetCoord() << " failed since the expression at "
           << num_expr->GetCoord() << " did not evaluate to a valid value:\n\n"
           << *evaled_switch_expr << "\n\n";
      ReportDiscardedState(*state);
      return;
   }

   // Insert the state into the state-restriction support structure. For each case,
   // this state is restricted before moving on to the next case.
   RestrictedALFState restr_state(num_expr, move(state), domain.get(), this);

   // Run through all the targets in the target list
   // TODO: This loop could be terminated as soon as restr_state becomes bottom. However, the
   // nr_succ_states == 0 condition should be tested if a default case is present
   const CTargetList * targ_list = switch_stmt->GetTargets();
   for (CTargetList::const_list_iterator t = targ_list->ConstIterator(),
        t_end = targ_list->InvalidIterator(); t != t_end; ++t)
   {
      unique_ptr<State> eq_state;
      const AExpr * label_expr = 0;
      bool default_case = false;

      // { target ... }
      if ((*t)->IsType(CGenericNode::TYPE_TARGET_TUPLE))
      {
         // Get the numerical value of the branch
         const CTargetTuple * targ = static_cast<const CTargetTuple *>(*t);
         const CIntNumValTuple * targ_num_expr = targ->GetIntNumVal();
         GetAEDebugger()->BranchIntValue(targ_num_expr);
         unique_ptr<Value> targ_val(EvalExprNumValInt(targ_num_expr));

         // Make a copy of fall-through state
         RestrictedALFState eq_restr_state = restr_state;
         // Swap names of states
         eq_restr_state.Swap(restr_state);
         // Restrict the state with the value of this case
         eq_restr_state.RestrictEq(targ_val.get());
         GetAEDebugger()->RestrictedState(&eq_restr_state);
         // Get the state
         eq_state = eq_restr_state.ReleaseState();
         // Get the target label (will be used later)
         label_expr = targ->GetLabelExpr();
         // Restrict the fall-through state with the complement of this case value
         restr_state.RestrictNEq(targ_val.get());
      }
      // { default ... }
      else if ((*t)->IsType(CGenericNode::TYPE_DEFAULT_TUPLE))
      {
         const CDefaultTuple * targ = static_cast<const CDefaultTuple *>(*t);
         // Get the default state
         eq_state = restr_state.ReleaseState();
         // Get the target label (will be used later)
         label_expr = targ->GetLabelExpr();
         default_case = true;
      }
      // If the restricted state to be used in this case is not bottom, set the program counter
      // for each possible target state
      if (!eq_state->IsBottom())
      {
         // Get the set of targeted program points
         unique_ptr<Value> target_addr(EvalExpr(label_expr, eq_state.get()));
         vector<ProgramPointECFG *> branched_to_pps;
         eq_state->GetPPEnviron()->LookupStmt(
            *eq_state->GetProgramCounterECFG()->GetProgramPointECFG(), *target_addr, branched_to_pps);

         // Run through all the targeted program points and fork off a state copy
         // for each program point
         while (!branched_to_pps.empty())
         {
            // Pop the list from the tail
            unique_ptr<ProgramPoint> p(branched_to_pps.back());
            branched_to_pps.pop_back();
            unique_ptr<State> new_state;
            // Skip copying of the last state
            if (!branched_to_pps.empty())
               new_state.reset(eq_state->Copy());
            else
               new_state = move(eq_state);
            debugger->FollowBranch(p.get());
            new_state->GetProgramCounter()->UpdateWithNewProgramPoint(move(p));
            // Put into work list
            next_states.push_back(new_state.release());
            ++nr_succ_states;
         }
      }
      else {
         debugger->DoNotFollowBranch();
      }
      // We assume that all cases following the default case are dead code
      if (default_case) {
         if (nr_succ_states == 0) {
            throw logic_error((StrStream() << "Execution of switch statement at " << switch_stmt->GetCoord()
                               << " failed: no branch was followed, but the state to follow the "
                               "default branch became bottom.").Str());
         }
         return;
      }
   }

   // There was no default case. If implicit fall-through is disabled, then we are done.
   if (!g_ft_continue) {
      // This warning is controlled by an option
      if (g_ft_warn) cout << "Warning: AlfVM::StepStmtSwitch: the fall through state at " << switch_stmt->GetCoord()
                          <<  " is not bottom - this may be due to overestimations" << endl;
      return;
   }

   // Handle the fall-through state
   if (restr_state.GetState()->IsBottom()) {
      if (nr_succ_states == 0) {
         throw logic_error((StrStream() << "Execution of switch statement at " << switch_stmt->GetCoord()
                            << " failed: no branch was followed, but the fall-through state became bottom.").Str());
      }
      debugger->DoNotFollowFallThroughBranch();
   }
   else
   {
      GetAEDebugger()->RestrictedState(&restr_state);
      unique_ptr<State> new_state = restr_state.ReleaseState();
      unique_ptr<ProgramPoint> textual_succ(new_state->GetProgramCounter()->
         GetProgramPoint()->GetTextualSuccessor());
      debugger->FollowFallThroughBranch(textual_succ.get());
      new_state->GetProgramCounter()->UpdateWithNewProgramPoint(move(textual_succ));
      next_states.push_back(new_state.release());
      ++nr_succ_states;
   }
}

void AlfVM::StepStmtCall(const CCallStmtTuple *call_stmt, unique_ptr<State> state,
                         std::vector<State *> & next_states) const
{
   debugger->CallStatement(call_stmt);

   const AExpr *label_expr = call_stmt->GetLabelExpr();
   unique_ptr<Value> address(EvalExpr(label_expr, state.get()));

   // Find the called functions (may be several, if the function pointer is abstract)
   vector<PPEnviron::LookedUpFunction> funcs;
   state->GetPPEnviron()->LookupFunction(
      *state->GetProgramCounterECFG()->GetProgramPointECFG(),
      *address, funcs);

   if (funcs.empty()) {
      cout << "Note: call at " << call_stmt->GetCoord() << " failed since the label expression at "
           << label_expr->GetCoord() << " did not evaluate to any valid call targets:\n\n" << *address << '\n' << endl;
      ReportDiscardedState(*state);
      return;
   }

   // For all the functions, fork off new states and update their program counters, etc.
   while (!funcs.empty())
   {
      // Fork off a new state (in the last iteration, the current state is reused)
      unique_ptr<State> new_state;
      if (funcs.size() > 1)
         new_state.reset(state->Copy());
      else
         new_state = move(state);

      if (funcs.back().IsDefined())
      {
         CFuncTuple * func_tuple = funcs.back().GetFuncTuple();
         unique_ptr<ProgramPoint> entry_pp(funcs.back().GetProgramPoint());
         funcs.pop_back();
         debugger->CalledFunction(func_tuple);
         const CExprList * arg_exprs = call_stmt->GetExprs();
         const CExprList * ret_addr_exprs = call_stmt->GetAddrExprs();
         if (!EnterFunction(func_tuple, move(entry_pp), arg_exprs, ret_addr_exprs, new_state.get(), call_stmt))
            continue;
         HandleFuncEntryALFAbsAnnot(func_tuple, new_state.get());
         next_states.push_back(new_state.release());
      }
      else
      {
        // Undefined function - just step the program counter to the textual successor of the
        // call statement
        funcs.pop_back();
        new_state->GetProgramCounter()->StepToTextualSuccessor();
        next_states.push_back(new_state.release());
      }
   }
}

void
AlfVM::
StepStmtReturn(const CReturnStmtTuple *return_stmt, unique_ptr<State> state,
               std::vector<State *> & next_states) const
{
   debugger->ReturnStatement(return_stmt);

   const CExprList* exprs = return_stmt->GetExprs();
   const RetAddrList &ret_addrs = *state->GetRetAddrList();
	
   // Check the the number of returned values at the called function
   // correspond to the number of return address in the call site
   if(!_allow_call_site_return_addresses_different_from_return_values && 
      (exprs->ElementCount() != ret_addrs.size()))
     {
       ostringstream msg_str;
       msg_str << "Returning " << exprs->ElementCount() << " values, but "
               << ret_addrs.size() << " addresses for storing the returned values where given "
               << "when calling the function.";
       throw runtime_error(msg_str.str());
     }
   
   Memory *mem = state->GetMemory();
   {
     // Evaluate return expressions and store them in return addresses. 
     unsigned i = 0;
     for (const unsigned n = (unsigned)min(ret_addrs.size(), exprs->ElementCount()); i != n; ++i)
       {
         unique_ptr<Value> ev_expr(EvalExpr(exprs->ElementAt(i), state.get()));
         debugger->ReturnedValue(ev_expr.get(), ret_addrs[i].get());
         if (ev_expr->IsBottom()) {
            cout << "Note: return at " << return_stmt->GetCoord() << " failed since the returned expression at "
                 << exprs->ElementAt(i)->GetCoord() << " did not evaluate to a valid value:\n\n"
                 << *ev_expr << "\n\n";
            ReportDiscardedState(*state);
            return;
         }
         mem->Store(ret_addrs[i].get(), ev_expr.get(), false);
       }
     assert((i == exprs->ElementCount()) || _allow_call_site_return_addresses_different_from_return_values);
   }

   const VarEnviron * env = state->GetEnviron();
   for (VarEnviron::EnvIterator p = env->GetEnvIterator(); p != env->GetEnvEndIterator(); ++p)
   {
      const Value * fref = p->second.GetBasePointer();
      mem->DeallocFrame(fref);
   }

   if (state->GetCallStack()->Height() > 0)
   {
      unique_ptr<ProgramPoint> return_pp;
      state->GetMutableCallStack()->PopFunction(return_pp);
      debugger->ReturnedToPP(return_pp.get());
      state->GetProgramCounter()->UpdateWithNewProgramPoint(move(return_pp));
      next_states.push_back(state.release());    
   }
}

void
AlfVM::
StepStmtFree(const CFreeStmtTuple *free_stmt, unique_ptr<State> state,
             std::vector<State *> & next_states) const
{
   debugger->FreeStatement(free_stmt);
   const AExpr *fref_expr = free_stmt->GetFrefExpr();
   unique_ptr<Value> ev_fref_expr(EvalExpr(fref_expr, state.get()));
   debugger->FreedFrameRef(ev_fref_expr.get());
   if (ev_fref_expr->IsBottom()) {
      cout << "Note: free at " << free_stmt->GetCoord() << " failed since the address expression at "
           << fref_expr->GetCoord() << " did not evaluate to a valid address:\n\n"
           << *ev_fref_expr << "\n\n";
      ReportDiscardedState(*state);
      return;
   }
   if (state->GetEnviron()->Defined(ev_fref_expr.get()) ||
       state->GetGlobEnviron()->Defined(ev_fref_expr.get()))
   {
      assert("Can only free frames allocated through dynalloc expressions" == NULL);
   }

   Memory *mem = state->GetMemory();
   mem->DeallocFrame(ev_fref_expr.get());

   state->GetProgramCounter()->StepToTextualSuccessor();
   next_states.push_back(state.release());
}

Value * AlfVM::EvalExpr(const AExpr *expr, State *state) const
{
   debugger->EvalExpr(expr);
   unique_ptr<Value> result;

#  pragma push_macro("EXPR_TYPE_CASE_CONST")
#  pragma push_macro("EXPR_TYPE_CASE")
#  define EXPR_TYPE_CASE_CONST(TYPE, SUBCLASS, METHOD)                       \
      case CGenericNode::TYPE:                                               \
         {                                                                   \
            const SUBCLASS *cast_expr = dynamic_cast<const SUBCLASS*>(expr); \
            result.reset( METHOD(cast_expr) );                               \
            break;                                                           \
         }
#  define EXPR_TYPE_CASE(TYPE, SUBCLASS, METHOD)                             \
      case CGenericNode::TYPE:                                               \
         {                                                                   \
            const SUBCLASS *cast_expr = dynamic_cast<const SUBCLASS*>(expr); \
            result.reset( METHOD(cast_expr, state) );                        \
            break;                                                           \
         }
   
   switch (expr->GetNodeType()) {
   EXPR_TYPE_CASE_CONST(TYPE_INTVAL_TUPLE,    CIntNumValTuple,     EvalExprNumValInt)
   EXPR_TYPE_CASE_CONST(TYPE_FLOATVAL_TUPLE,  CFloatValTuple,      EvalExprNumValFloat)
   EXPR_TYPE_CASE(TYPE_FREF_TUPLE,            CFRefTuple,          EvalExprFRef)
   EXPR_TYPE_CASE(TYPE_ADDR_EXPR_TUPLE,       CAddrTuple,          EvalExprAddr)
   EXPR_TYPE_CASE(TYPE_COMPADDR_EXPR_TUPLE,   CCompAddrTuple,      EvalExprCompAddr)
   EXPR_TYPE_CASE(TYPE_LREF_TUPLE,            CLRefTuple,          EvalExprLRef)
   EXPR_TYPE_CASE(TYPE_LABEL_TUPLE,           CLabelTuple,         EvalExprLabel)
   EXPR_TYPE_CASE(TYPE_COMPLABEL_EXPR_TUPLE,  CCompLabelTuple,     EvalExprCompLabel)
   EXPR_TYPE_CASE(TYPE_LOAD_EXPR_TUPLE,       CLoadExprTuple,      EvalExprLoad)
   EXPR_TYPE_CASE(TYPE_DYNALLOC_EXPR_TUPLE,   CDynAllocTuple,      EvalExprDynAlloc)
   EXPR_TYPE_CASE(TYPE_OP_EXPR_TUPLE,         COpNumExprTuple,     EvalExprOp)
   EXPR_TYPE_CASE(TYPE_UNDEFINED_EXPR_TUPLE,  CUndefinedExprTuple, EvalExprUndefined)
   default:
      assert("Wrong node type in call to AlfVM::EvalExpr!" == NULL);
      break;
   }
#  pragma pop_macro("EXPR_TYPE_CASE_CONST")
#  pragma pop_macro("EXPR_TYPE_CASE")

   debugger->ResultFromEval(result.get());

   return result.release();
}

Value * AlfVM::EvalExprOp(const COpNumExprTuple *op_expr, State *state) const
{
   const CExprList* arg_exprs = op_expr->GetNumExprs();
   const CSizeList* sizes = op_expr->GetSizes();

   assert(sizes != 0);

   unique_ptr<Value> evaled_args[3];

   if (op_expr->GetOperator() != COpNumExprTuple::OP_TYPE_SELECT) {
      for (unsigned int e = 0; e < arg_exprs->ElementCount(); ++e) {
         debugger->EvalOperand();
         evaled_args[e].reset(EvalExpr(arg_exprs->ElementAt(e), state));
      }
   }

   unique_ptr<Value> result;

#  pragma push_macro("EXPR_TYPE_CASE1")
#  pragma push_macro("EXPR_TYPE_CASE2")
#  pragma push_macro("EXPR_TYPE_CASE3")
#  define EXPR_TYPE_CASE1(TYPE, NUM_SIZES, METHOD)                                        \
      case COpNumExprTuple::TYPE:                                                         \
         {                                                                                \
            assert(sizes->ElementCount() == NUM_SIZES && arg_exprs->ElementCount() == 1); \
            result.reset( evaled_args[0]->METHOD() );                                     \
            break;                                                                        \
         }
#  define EXPR_TYPE_CASE2(TYPE, NUM_SIZES, METHOD)                                        \
      case COpNumExprTuple::TYPE:                                                         \
         {                                                                                \
            assert(sizes->ElementCount() == NUM_SIZES && arg_exprs->ElementCount() == 2); \
            result.reset( evaled_args[0]->METHOD(evaled_args[1].get()) );                 \
            break;                                                                        \
         }
#   define EXPR_TYPE_CASE3(TYPE, NUM_SIZES, METHOD)                                             \
      case COpNumExprTuple::TYPE:                                                               \
         {                                                                                      \
            assert(sizes->ElementCount() == NUM_SIZES && arg_exprs->ElementCount() == 3);       \
            result.reset( evaled_args[0]->METHOD(evaled_args[1].get(), evaled_args[2].get()) ); \
            break;                                                                              \
         }

   switch (op_expr->GetOperator()) 
   {
   // OP_INT (and pointer arithmetics) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   EXPR_TYPE_CASE1(OP_TYPE_NEG,   1, Neg)
   EXPR_TYPE_CASE3(OP_TYPE_ADD,   1, Add)
   EXPR_TYPE_CASE3(OP_TYPE_C_ADD, 1, CAdd)
   EXPR_TYPE_CASE3(OP_TYPE_SUB,   1, Sub)
   EXPR_TYPE_CASE3(OP_TYPE_C_SUB, 1, CSub)
   EXPR_TYPE_CASE2(OP_TYPE_U_MUL, 2, UMul)
   EXPR_TYPE_CASE2(OP_TYPE_S_MUL, 2, SMul)
   EXPR_TYPE_CASE2(OP_TYPE_U_DIV, 2, UDiv)
   EXPR_TYPE_CASE2(OP_TYPE_S_DIV, 2, SDiv)
   EXPR_TYPE_CASE2(OP_TYPE_U_MOD, 2, UMod)
   EXPR_TYPE_CASE2(OP_TYPE_S_MOD, 2, SMod)

      // OP_BIT - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   EXPR_TYPE_CASE2(OP_TYPE_L_SHIFT,   2, LShift)
   EXPR_TYPE_CASE2(OP_TYPE_R_SHIFT,   2, RShift)
   EXPR_TYPE_CASE2(OP_TYPE_R_SHIFT_A, 2, RShiftA)
   case COpNumExprTuple::OP_TYPE_S_EXT:
      {
         assert(sizes->ElementCount() == 2 && arg_exprs->ElementCount() == 1);
         result.reset( evaled_args[0]->SExt(sizes->ElementAt(1)->GetSizeInBits()) );
         break;
      }
   EXPR_TYPE_CASE1(OP_TYPE_NOT, 1, Not)
   EXPR_TYPE_CASE2(OP_TYPE_AND, 1, And)
   EXPR_TYPE_CASE2(OP_TYPE_OR,  1, Or)
   EXPR_TYPE_CASE2(OP_TYPE_XOR, 1, XOr)
   // OP_FLOAT - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   EXPR_TYPE_CASE1(OP_TYPE_F_NEG, 2, FNeg)
   EXPR_TYPE_CASE2(OP_TYPE_F_ADD, 2, FAdd)
   EXPR_TYPE_CASE2(OP_TYPE_F_SUB, 2, FSub)
   EXPR_TYPE_CASE2(OP_TYPE_F_MUL, 2, FMul)
   EXPR_TYPE_CASE2(OP_TYPE_F_DIV, 2, FDiv)
   case COpNumExprTuple::OP_TYPE_F_TO_F:
      {
         assert(sizes->ElementCount() == 4 && arg_exprs->ElementCount() == 1);
         Size m = sizes->ElementAt(1)->GetSizeInBits();
         Size n = sizes->ElementAt(3)->GetSizeInBits();
         result.reset( evaled_args[0]->FToF(m, n) );
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_TO_U:
      {
         assert(sizes->ElementCount() == 3 && arg_exprs->ElementCount() == 1);
         Size n = sizes->ElementAt(2)->GetSizeInBits();
         result.reset( evaled_args[0]->FToU(n) );
         break;
      }
   case COpNumExprTuple::OP_TYPE_F_TO_S:
      {
         assert(sizes->ElementCount() == 3 && arg_exprs->ElementCount() == 1);
         Size n = sizes->ElementAt(2)->GetSizeInBits();
         result.reset( evaled_args[0]->FToS(n) );
         break;
      }
   case COpNumExprTuple::OP_TYPE_U_TO_F:
      {
         assert(sizes->ElementCount() == 3 && arg_exprs->ElementCount() == 1);
         Size m = sizes->ElementAt(0)->GetSizeInBits();
         Size n = sizes->ElementAt(1)->GetSizeInBits();
         result.reset( evaled_args[0]->UToF(m, n) );
         break;
      }
   case COpNumExprTuple::OP_TYPE_S_TO_F:
      {
         assert(sizes->ElementCount() == 3 && arg_exprs->ElementCount() == 1);
         Size m = sizes->ElementAt(0)->GetSizeInBits();
         Size n = sizes->ElementAt(1)->GetSizeInBits();
         result.reset( evaled_args[0]->SToF(m, n) );
         break;
      }

   // OP_CMP - - - - - - - - - - - - - - - - - - - - - - - - - - -
   EXPR_TYPE_CASE2(OP_TYPE_EQ,   1, Eq)
   EXPR_TYPE_CASE2(OP_TYPE_NEQ,  1, NEq)
   EXPR_TYPE_CASE2(OP_TYPE_U_LT, 1, ULT)
   EXPR_TYPE_CASE2(OP_TYPE_U_GE, 1, UGE)
   EXPR_TYPE_CASE2(OP_TYPE_U_GT, 1, UGT)
   EXPR_TYPE_CASE2(OP_TYPE_U_LE, 1, ULE)
   EXPR_TYPE_CASE2(OP_TYPE_S_LT, 1, SLT)
   EXPR_TYPE_CASE2(OP_TYPE_S_GE, 1, SGE)
   EXPR_TYPE_CASE2(OP_TYPE_S_GT, 1, SGT)
   EXPR_TYPE_CASE2(OP_TYPE_S_LE, 1, SLE)
   EXPR_TYPE_CASE2(OP_TYPE_F_EQ, 2, FEq)
   EXPR_TYPE_CASE2(OP_TYPE_F_NE, 2, FNEq)
   EXPR_TYPE_CASE2(OP_TYPE_F_LT, 2, FLT)
   EXPR_TYPE_CASE2(OP_TYPE_F_GE, 2, FGE)
   EXPR_TYPE_CASE2(OP_TYPE_F_GT, 2, FGT)
   EXPR_TYPE_CASE2(OP_TYPE_F_LE, 2, FLE)

   // OP_MATH - - - - - - - - - - - - - -
   EXPR_TYPE_CASE3(OP_TYPE_IF,   1, If)
   EXPR_TYPE_CASE1(OP_TYPE_B2N,  0, B2N)
   EXPR_TYPE_CASE1(OP_TYPE_EXP2, 0, Exp2)

   // OP_BITSTR - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   case COpNumExprTuple::OP_TYPE_SELECT:
      {
         assert(sizes->ElementCount() == 3 && arg_exprs->ElementCount() == 1);
         Size m = sizes->ElementAt(1)->GetSizeInBits();
         Size n = sizes->ElementAt(2)->GetSizeInBits();

         // special handling of "truncated multiplication", which is a multiplication followed
         // by a select to truncate the result back to the same size as the operands; this is
         // is handled as an atomic operation for extra precision and efficiency
         if (m == 0 && arg_exprs->ElementAt(0)->IsType(CGenericNode::TYPE_OP_EXPR_TUPLE)) {
            const COpNumExprTuple *arg_expr = (const COpNumExprTuple*)arg_exprs->ElementAt(0);
            // the operand to the select is a multiplication
            if (arg_expr->GetOperator() == COpNumExprTuple::OP_TYPE_S_MUL ||
                arg_expr->GetOperator() == COpNumExprTuple::OP_TYPE_U_MUL)
            {
               const CSizeList *arg_sizes = arg_expr->GetSizes();
               Size size0 = arg_sizes->ElementAt(0)->GetSizeInBits();
               Size size1 = arg_sizes->ElementAt(1)->GetSizeInBits();
               // multiplication operands are of the same size, which also matches the selected range
               if (size0 == size1 && size0 == n + 1) {
                  const CExprList *mul_args = arg_expr->GetNumExprs();
                  for (unsigned int e = 0; e < 2; ++e) {
                     debugger->EvalOperand();
                     evaled_args[e].reset( EvalExpr(mul_args->ElementAt(e), state) );
                  }
                  result.reset( evaled_args[0]->Mul_Trunc( evaled_args[1].get() ) );
                  break;
               }
            }
         }

         // general case
         for (unsigned int e = 0; e < arg_exprs->ElementCount(); ++e) {
            debugger->EvalOperand();
            evaled_args[e].reset(EvalExpr(arg_exprs->ElementAt(e), state));
         }
         result.reset( evaled_args[0]->Select(m, n) );
         break;
      }
   EXPR_TYPE_CASE2(OP_TYPE_CONC, 2, Conc)
   case COpNumExprTuple::OP_TYPE_REPEAT:
      {
         assert(sizes->ElementCount() == 1 && arg_exprs->ElementCount() == 1);
         Size n = sizes->ElementAt(0)->GetSizeInBits();
         result.reset( evaled_args[0]->Repeat(n) );
         break;
      }
   default:
      assert(false);
      break;
   }
#  pragma pop_macro("EXPR_TYPE_CASE3")
#  pragma pop_macro("EXPR_TYPE_CASE2")
#  pragma pop_macro("EXPR_TYPE_CASE1")

   return result.release();
}

Value *
AlfVM::
EvalExprNumValInt(const CIntNumValTuple *num_val_int_expr) 
const
{
   Size size_in_bits = num_val_int_expr->GetSize()->IsInfinity()?
      Size::Infinity()
      : Size(num_val_int_expr->GetSize()->GetSizeInBits());
   CIntegerNumber * number = num_val_int_expr->GetNumber();
   return domain->GetIntegerDomain()->CreateInteger(size_in_bits, number->GetValueAsBignum());
}

Value *
AlfVM::
EvalExprNumValFloat(const alf::CFloatValTuple *num_val_float_expr) 
const
{
   long double float_val = num_val_float_expr->GetFloatValue()->GetValueAsFloat();
   return domain->GetFloatDomain()->CreateFloat(
      num_val_float_expr->GetExpSize()->GetSizeInBits(),
      num_val_float_expr->GetFracSize()->GetSizeInBits(),
      float_val != float_val,
      float_val);
}

Value *
AlfVM::
EvalExprFRef(const CFRefTuple *fref_expr, State *state)
const
{
   unsigned fref_id = fref_expr->GetKey();
   return state->Lookup(fref_id, cshack);
}

Value *
AlfVM::
EvalExprAddr(const CAddrTuple *addr_expr, State *state) 
const
{
   const CFRefTuple * fref_tuple = addr_expr->GetFref();
   unique_ptr<Value> fref(EvalExprFRef(fref_tuple, state));

   const CIntNumValTuple * offset_tuple = addr_expr->GetOffset();
   unique_ptr<Value> offset(EvalExprNumValInt(offset_tuple));

   Value * addr = domain->GetMemoryDomain()->CreatePointer(fref.get(), offset.get());
   
   assert(addr->SizeInBits() == Size(addr_expr->GetSize()->GetSizeInBits()) ||
          "Size of computed value does not match the size specified in the expression" == NULL);

   return addr;
}

Value *
AlfVM::
EvalExprCompAddr(const alf::CCompAddrTuple *comp_addr_expr, State *state) 
const
{
   const AExpr * fref_expr = comp_addr_expr->GetFRefExpr();
   const AExpr * offset_expr = comp_addr_expr->GetNumExpr();

   unique_ptr<Value> fref(EvalExpr(fref_expr, state));
   unique_ptr<Value> offset(EvalExpr(offset_expr, state));

   Value * addr = domain->GetMemoryDomain()->CreatePointer(fref.get(), offset.get());
   
   assert(addr->SizeInBits() == Size(comp_addr_expr->GetSize()->GetSizeInBits()) ||
          "Size of computed value does not match the size specified in the expression" == NULL);

   return addr;
}

Value * AlfVM::EvalExprLRef(const CLRefTuple *lref, State *state) const
{
   Symbol symbol(lref->GetKey(), 1);
   symbol.SetAnnot(lref->GetId());
   return domain->GetMemoryDomain()->CreateBasePtr(lref->GetSize()->GetSizeInBits(), symbol);
}

Value * AlfVM::EvalExprLabel(const CLabelTuple * label_expr, State * state) const
{
   const CLRefTuple * lref_tuple = label_expr->GetLRef();
   unique_ptr<Value> lref(EvalExprLRef(lref_tuple, state));

   const CIntNumValTuple * offset_tuple = label_expr->GetOffset();
   unique_ptr<Value> offset(EvalExprNumValInt(offset_tuple));

   Value * label = domain->GetMemoryDomain()->CreatePointer(lref.get(), offset.get());
   
   assert(label->SizeInBits() == Size(label_expr->GetSize()->GetSizeInBits()) ||
          "Size of computed value does not match the size specified in the expression" == NULL);

   return label;
}

Value * AlfVM::EvalExprCompLabel(const alf::CCompLabelTuple *comp_label_expr, State *state) const
{
   const AExpr * lref_expr = comp_label_expr->GetLRefExpr();
   const AExpr * offset_expr = comp_label_expr->GetNumExpr();

   unique_ptr<Value> lref(EvalExpr(lref_expr, state));
   unique_ptr<Value> offset(EvalExpr(offset_expr, state));

   Value * label = domain->GetMemoryDomain()->CreatePointer(lref.get(), offset.get());
   
   assert(label->SizeInBits() == Size(comp_label_expr->GetSize()->GetSizeInBits()) ||
          "Size of computed value does not match the size specified in the expression" == NULL);

   return label;
}

Value *
AlfVM::
EvalExprLoad(const alf::CLoadExprTuple *load_expr, State *state) 
const
{
   const AExpr * addr_expr  = load_expr->GetAddrExpr();
   const CSize * size_tuple = load_expr->GetSize();

   unique_ptr<Value> evaled_addr(EvalExpr(addr_expr, state));
   Size size = size_tuple->GetSizeInBits();

   Memory * mem = state->GetMemory();
   bool succ_loads, unsucc_loads;
   unique_ptr<Value> loaded_val( mem->Load(evaled_addr.get(), size, succ_loads, unsucc_loads) );

   if (!succ_loads) {
      cout << "Note: load at " << load_expr->GetCoord() << " failed since the address expression at "
           << addr_expr->GetCoord() << " did not evaluate to any valid memory locations:\n\n"
           << *evaled_addr << '\n' << endl;
   }

   return loaded_val.release();
}

Value *
AlfVM::
EvalExprDynAlloc(const alf::CDynAllocTuple *dyn_alloc_expr, State *state) 
const
{
   assert("Not implemented" == NULL);
   return 0;
}

Value * AlfVM::EvalExprUndefined(const alf::CUndefinedExprTuple *undefined_expr, State *state) const
{
	return domain->GetIntegerDomain()->CreateInteger(undefined_expr->GetSize()->GetSizeInBits());
}

const
alf::CScopeTuple *
AlfVM::
GetScope(State * state, const alf::CAlfTuple * ast) const {

   ProgramCounter * pc = state->GetProgramCounter();
   const ProgramPoint * pp = pc->GetProgramPoint();
   const CFlowGraphNode * fgn = pp->GetFlowGraphNode();
   CFlowGraph * fg = fgn->FlowGraph();
   const CGenericFunction * f = fg->Function();
   string func_name = f->Name();

      // The scope
   const alf::CScopeTuple * scope = NULL;

      // Derive function with the given func_name
   bool func_with_func_name_exists = false;
   const alf::CFuncList * funcs = ast->GetFuncs();
   for(alf::CFuncList::const_list_iterator func = funcs->ConstIterator(); func != funcs->InvalidIterator(); func++) {
         // Check if the function has the wanted name
      if((*func)->Name() == func_name) {
            // Yes, remember the scope and function
         scope = (*func)->GetScope();
            // Remember that we found a function
         func_with_func_name_exists = true;
         break;
      }
   }

      // Check if function existed
   assert (func_with_func_name_exists);
   return scope;
}
