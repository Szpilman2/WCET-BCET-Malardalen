#include "AlfVMTraceDebugger.h"
#include "RestrictedALFState.h"
#include "ExprNode.h"
#include "State.h"
#include "value/Value.h"
#include "memory/Memory.h"
#include "program_counter/ProgramCounter.h"
#include "program/alf/AStmt.h"
#include "program/alf/CNullStmtTuple.h"
#include "program/alf/CStoreStmtTuple.h"
#include "program/alf/CJumpStmtTuple.h"
#include "program/alf/CSwitchStmtTuple.h"
#include "program/alf/CCallStmtTuple.h"
#include "program/alf/CReturnStmtTuple.h"
#include "program/alf/CFreeStmtTuple.h"
#include "program/alf/CGenericNode.h"
#include "program/alf/AExpr.h"
#include "program/alf/CExprList.h"
#include "program/alf/COpNumExprTuple.h"
#include "program/alf/CFuncTuple.h"
#include "program/alf/CIntNumValTuple.h"
#include "tools/IndentingOStream.h"

using namespace std;
using namespace alf;

// Public members of AlfVMTraceDebugger ------------------------------------------

void AlfVMTraceDebugger::Statement(const alf::AStmt * stmt, const State * state)
{
   *os << "Executing " << NodeTypeToStmtName(stmt->GetNodeType())
    << " statement on line " << stmt->GetLine() << " in state \""
    << state->GetName() << "\":\n" << IncrIndent;
}

void AlfVMTraceDebugger::StatementFinished(std::vector<State *> & updated_states)
{
   *os << DecrIndent;
   for (std::vector<State *>::const_iterator s = updated_states.begin();
        s != updated_states.end(); ++s)
   {
      if ((*s)->IsFinalState())
         *os << "Memory contents in final state:" << endl << *(*s)->GetMemory();
   }   
}

void AlfVMTraceDebugger::NullStatement(const alf::CNullStmtTuple * stmt)
{
   // Do nothing
}

void AlfVMTraceDebugger::StoreStatement(const alf::CStoreStmtTuple * stmt)
{
   store_stmt = stmt;
   store_list_index = 0;
   *os << "Expression for stored value 1:\n";
   store_stmt->GetExprs()->ElementAt(store_list_index)->PrintWithEndl(*os);   
}

void AlfVMTraceDebugger::StoredValue(const Value * value)
{
   *os << "which evaluates to\n" << *value << endl;
   *os << "Address stored to " << (store_list_index+1) << ":\n";
   store_stmt->GetAddrExprs()->ElementAt(store_list_index)->PrintWithEndl(*os);
}

void AlfVMTraceDebugger::StoredToAddress(const Value * value)
{
   *os << "which evaluates to\n" << *value << endl;
   ++store_list_index;
   if (store_list_index < store_stmt->GetExprs()->ElementCount())
   {
      *os << "Expression for stored value " << (store_list_index+1) << ":\n";
      store_stmt->GetExprs()->ElementAt(store_list_index)->PrintWithEndl(*os);
   }
}

void AlfVMTraceDebugger::JumpStatement(const alf::CJumpStmtTuple * stmt)
{
   *os << "Label expression:\n";
   stmt->GetLabelExpr()->PrintWithEndl(*os);
}

void AlfVMTraceDebugger::JumpedToPP(const ProgramPoint * program_point)
{
   const CGenericNode * stmt = dynamic_cast<const CGenericNode *>(program_point->GetStmt());
   *os << "which evaluates to the " << NodeTypeToStmtName(stmt->GetNodeType())
       << " statement on line " << stmt->GetLine() << endl;
}

void AlfVMTraceDebugger::SwitchStatement(const alf::CSwitchStmtTuple * stmt)
{
   GetOS() << "Switch expression:\n";
   stmt->GetNumExpr()->PrintWithEndl(GetOS());
   ResetBranchIndex();
}

void AlfVMTraceDebugger::EvaledSwitchExpr(const Value * value)
{
   GetOS() << "which evaluates to\n" << *value << endl;
}

void AlfVMTraceDebugger::BranchIntValue(const alf::CIntNumValTuple * value)
{
   IncrBranchIndex();
   GetOS() << "Branch " << (GetBranchIndex()+1) << " integer value:\n";
   value->PrintWithEndl(GetOS());
}

void AlfVMTraceDebugger::FollowBranch(const ProgramPoint * jumped_to)
{
   const CGenericNode * stmt = dynamic_cast<const CGenericNode *>(jumped_to->GetStmt());
   GetOS() << "Following branch " << (GetBranchIndex()+1) << " to the "
           << NodeTypeToStmtName(stmt->GetNodeType())
           << " statement on line " << stmt->GetLine() << endl;
}

void AlfVMTraceDebugger::DoNotFollowBranch()
{
   GetOS() << "Skipping branch " << (GetBranchIndex()+1) << endl;
}

void AlfVMTraceDebugger::FollowFallThroughBranch(const ProgramPoint * jumped_to)
{
   const CGenericNode * stmt = dynamic_cast<const CGenericNode *>(jumped_to->GetStmt());
   GetOS() << "Following fall-through branch to the "
           << NodeTypeToStmtName(stmt->GetNodeType())
           << " statement on line " << stmt->GetLine() << endl;
}

void AlfVMTraceDebugger::DoNotFollowFallThroughBranch()
{
   GetOS() << "Skipping fall-through branch" << endl;
}

void AlfVMTraceDebugger::RestrictedState(RestrictedALFState * restr_alf_state)
{
   class ExprNodePrinter : public ExprNodeVisitor
   {
   public:
      ExprNodePrinter(IndentingOStream & os_printed_to)
         : os_printed_to(os_printed_to) {}

      virtual void VisitInternalExprNode(const InternalExprNode & node)
      {
         const InternalExprNode::ChildList & children = node.GetChildren();
         for (InternalExprNode::ChildList::const_iterator c = children.begin();
              c != children.end(); ++c)
         {
            (*c)->AcceptVisitor(this);
         }
      }

      virtual void VisitExprLeaf(const ExprLeaf & node) {}

      virtual void VisitLoadLeaf(const LoadLeaf & node)
      {
         unique_ptr<Value> address(node.GetAddress());
         os_printed_to  << *address << endl << IncrIndent
                        << "stores " << *node.GetAnnot() << DecrIndent << endl;
      }

   private:
      IndentingOStream & os_printed_to;
   };

   const State * state = restr_alf_state->GetState();
   if (state->IsBottom())
      return;
   GetOS() << "State \"" << state->GetName() << "\" after restriction:\n" << IncrIndent;
   ExprNodePrinter expr_node_printer(GetOS());
   restr_alf_state->ExprTree()->UpdateAnnot();
   restr_alf_state->ExprTree()->AcceptVisitor(&expr_node_printer);
   GetOS().DecrIndent();
}

void AlfVMTraceDebugger::Restrict(const alf::AExpr * expr, const Value * r)
{
   GetOS() << IncrIndent << "Restricting the expression\n";
   expr->PrintWithEndl(GetOS());
   GetOS() << "with the value\n" << *r << endl << DecrIndent;
}


void AlfVMTraceDebugger::CallStatement(const alf::CCallStmtTuple * stmt)
{
   call_stmt = stmt;
   func_arg_index = func_addr_index = 0;
   *os << "Called label:\n";
   call_stmt->GetLabelExpr()->PrintWithEndl(*os);
}

void AlfVMTraceDebugger::CalledFunction(const CFuncTuple * function)
{
   *os   << "which evaluates to the function " << function->Name()
         << " defined on line " << function->GetLine() << endl;
   if (call_stmt->GetExprs()->ElementCount() > 0)
   {
      *os << "Argument 1:\n";
      call_stmt->GetExprs()->ElementAt(func_arg_index)->PrintWithEndl(*os);
   }
   else if (call_stmt->GetAddrExprs()->ElementCount() > 0)
   {
      *os << "Address for returned value 1:\n";
      call_stmt->GetAddrExprs()->ElementAt(func_addr_index)->PrintWithEndl(*os);
   }
}

void AlfVMTraceDebugger::FuncArgument(const Value * value)
{
   *os << "which evaluates to\n" << *value << endl;
   ++func_arg_index;
   if (func_arg_index < call_stmt->GetExprs()->ElementCount())
   {
      *os << "Argument " << (func_arg_index + 1) << ":\n";
      call_stmt->GetExprs()->ElementAt(func_arg_index)->PrintWithEndl(*os);
   }
   else if (call_stmt->GetAddrExprs()->ElementCount() > 0)
   {
      *os << "Address for returned value 1:\n";
      call_stmt->GetAddrExprs()->ElementAt(func_addr_index)->PrintWithEndl(*os);
   }
}

void AlfVMTraceDebugger::FuncRetValAddr(const Value * value)
{
   *os << "which evaluates to\n" << *value << endl;
   ++func_addr_index;
   if (func_addr_index < call_stmt->GetAddrExprs()->ElementCount())
   {
      *os << "Argument " << (func_addr_index+1) << ":\n";
      call_stmt->GetAddrExprs()->ElementAt(func_addr_index)->PrintWithEndl(*os);
   }
}

void AlfVMTraceDebugger::ReturnStatement(const alf::CReturnStmtTuple * stmt)
{
   return_stmt = stmt;
   ret_val_index = 0;
   if (stmt->GetExprs()->ElementCount() > 0)
   {
      *os << "Returned expression 1:\n";
      (*stmt->GetExprs()->ConstIterator())->PrintWithEndl(*os);
   }
}

void AlfVMTraceDebugger::ReturnedValue(const Value * value, const Value * address)
{
   *os << "which evaluates to\n" << *value << endl
       << "Address for returned expression " << (ret_val_index+1) << ":\n"
       << *address << endl;
   ++ret_val_index;
   if (ret_val_index < return_stmt->GetExprs()->ElementCount())
   {
      *os << "Returned expression " << (ret_val_index+1) << ":\n";
      return_stmt->GetExprs()->ElementAt(ret_val_index)->PrintWithEndl(*os);
   }
}

void AlfVMTraceDebugger::ReturnedToPP(const ProgramPoint * program_point)
{
   if (program_point->IsFinal())
      *os << "Returning to the final program point" << endl;
   else
   {
      const CGenericNode * stmt = dynamic_cast<const CGenericNode *>(program_point->GetStmt());
      *os << "Returning to the " << NodeTypeToStmtName(stmt->GetNodeType())
          << " statement on line " << stmt->GetLine() << endl;
   }
}

void AlfVMTraceDebugger::FreeStatement(const alf::CFreeStmtTuple * stmt)
{
   *os << "Frame reference expression:\n";
   stmt->GetFrefExpr()->PrintWithEndl(*os);
}

void AlfVMTraceDebugger::FreedFrameRef(const Value * value)
{
   *os << "which evaluates to\n" << *value << endl;
}

void AlfVMTraceDebugger::EvalExpr(const alf::AExpr * expr)
{
   if (!expr_eval_enabled)
      return;
   // Evaluating expression:
   // { ... }
   //     Evaluating expression:
   //     { ... }
   //         ...
   //     Result:
   //     (Result)
   // Result:
   // (Result)
   *os << IncrIndent << "Evaluating expression:\n";
   expr->PrintWithEndl(*os);
   exprs.push(PushedExpr(expr));
}

void AlfVMTraceDebugger::ResultFromEval(const Value * value)
{
   if (!expr_eval_enabled)
      return;
   *os << "Result:\n" << *value << endl << DecrIndent;
   exprs.pop();
}

void AlfVMTraceDebugger::EvalOperand()
{
   /*
   Eval:
   { add 32 ... }
       Eval:
       ...
       Result:
       ...
   +
       
   
   */
   if (!expr_eval_enabled)
      return;
   const COpNumExprTuple * op_expr = &dynamic_cast<const COpNumExprTuple &>(*exprs.top().expr);
   switch (exprs.top().operand_index)
   {
   case 0:
      switch (op_expr->GetOperator())
      {
      case COpNumExprTuple::OP_TYPE_NEG:
         *os << "-\n";
         break;
      default:
         break;
      }
      break;
   case 1:
      switch (op_expr->GetOperator())
      {
      case COpNumExprTuple::OP_TYPE_ADD:
         *os << "+\n";
         break;
      default:
         break;
      }
      break;
   case 2:
      switch (op_expr->GetOperator())
      {
      case COpNumExprTuple::OP_TYPE_ADD:
         *os << "+ (carry)\n";
         break;
      default:
         break;
      }
      break;
   }
   ++exprs.top().operand_index;
}

string AlfVMTraceDebugger::NodeTypeToStmtName(CGenericNode::TYPE node_type)
{
   switch (node_type) 
   {
   case CGenericNode::TYPE_NULL_STMT_TUPLE:
      return "null";
      break;
   case CGenericNode::TYPE_STORE_STMT_TUPLE:
      return "store";
      break;
   case CGenericNode::TYPE_JUMP_STMT_TUPLE:
      return "jump";
      break;
   case CGenericNode::TYPE_SWITCH_STMT_TUPLE:
      return "switch";
      break;
   case CGenericNode::TYPE_CALL_STMT_TUPLE:
      return "call";
      break;
   case CGenericNode::TYPE_RETURN_STMT_TUPLE:
      return "return";
      break;
   case CGenericNode::TYPE_FREE_STMT_TUPLE:
      return "free";
      break;
   default:
      return "(unknown)";
      break;
   }
}
