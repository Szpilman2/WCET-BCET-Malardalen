#include "globals.h"
#include "program_state/value/ValueDomain.h"
#include "program_state/Endianness.h"

using namespace std;

// Some global junk needed to resolve external references
unique_ptr<ValueDomain> domain;
bool g_ignore_stores_to_int_addr = false;
bool g_use_alternative_narrowing=false;
bool g_do_widening_stepwise=false;
bool g_use_zero_maxiter_fix=true;
Endianness g_endianness = Endianness::Little();
bool g_ft_continue=false;
bool g_ft_warn=false;
string g_output_annotation_specification_file_name;
bool g_merged_outp_annots;
bool g_removed_alf_label=false;
bool g_removed_BB=false;
bool g_removed__bb=false;
bool g_unmangled_colons=false;
