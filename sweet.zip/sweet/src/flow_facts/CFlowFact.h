// $Id $

#ifndef CFLOWFACT_H_
#define CFLOWFACT_H_

#include <iostream>
#include <vector>
#include "CIndexRangeList.h"
#include "CFFCollector.h"
#include "CConstraint.h"


class CScope;

class CFlowFact
{
public:
   typedef enum {
     UHSS, // Normal upper header bounds in scope context 
     LHSS, // Lower header bounds in scope context.
     UHSF, // Upper loop header bounds in function context.
     LHSF, // Lower header bounds in function context.
     UHSP, // Upper header bounds in program context.
     LHSP, // Lower header bounds in program context.

     UHPF, // Upper bounds for header node pairs in function-context.
     LHPF, // Lower bounds for header node pairs in function-context.
     UHPP, // Upper bounds for header node pairs in program-context.
     LHPP, // Lower bounds for header node pairs in program-context.

     UNSS, // Upper bounds for nodes in scope context.
     LNSS, // Lower bounds for nodes in scope context.
     UNSF, // Upper bounds for nodes in function context.
     LNSF, // Lower bounds for nodes in function context.
     UNSP, // Upper bounds for nodes in program context.
     LNSP, // Lower bounds for nodes in program context.
     INSE, // Infeasible nodes (i.e. nodes never taken) for individual iterations of scope.
     INSA, // Infeasible nodes (i.e. nodes never taken) for all iterations of scope.

     UNPS, // Upper bounds for node pairs in scope-context.
     LNPS, // Lower bounds for node pairs in scope-context.
     UNPF, // Upper bounds for node pairs in function-context.
     LNPF, // Lower bounds for node pairs in function-context.
     UNPP, // Upper bounds for node pairs in program-context.
     LNPP, // Lower bounds for node pairs in program-context.
     INPA, // Infeasible node pairs (i.e. excluding ones) for all iterations of scope.
     INPA2, // Node pairs that must be taken together for each iteration of loop. 
     INNA, // Infeasible node paths for all iterations of scope.

     UESS, // Upper bounds for edges in scope-context.
     LESS, // Lower bounds for edges in scope-context.
     UESF, // Upper bounds for edges in function context.
     LESF, // Lower bounds for edges in function context.
     UESP, // Upper bounds for edges in program context.
     LESP, // Lower bounds for edges in program context.
     UCSF, // Upper bounds for call edges in function context.
     LCSF, // Lower bounds for call edges in function context.
     UCSP, // Upper bounds for call edges in program context.
     LCSP, // Lower bounds for call edges in program context.
     UBNS, // Upper bounds for sum of loop body begin edges in scope-context.
     LBNS, // Lower bounds for sum of loop body begin edges in scope-context.

     IEPA, // Infeasible paths of edges for all iterations of scope
     FIX,  // Fix, corresponds to having a maximum iteration = 0"; break;
     UNDEF // Undefined
   } t_flowfacttype;
   CFlowFact(const CFlowFact &theother);
   CFlowFact(const CScope *);
   CFlowFact(const CScope *, const t_flowfacttype &, const CFFCollector &, const CConstraint &);
   // CFlowFact(const CScope *, const t_flowfacttype &, const CIndexRangeList &, const CFFCollector &, const CConstraint &);
   virtual ~CFlowFact(void);

   void RangeList(const CIndexRangeList &);
   // CConstraint MergeConstraints(CFlowFact *ff) const;

   // Returns the components of a flow fact
   // (the flow fact name is the same as for the enclosing Scope)
   t_flowfacttype Type(void) const;
   // const CIndexRangeList *IndexRangeList(void) const;
   const CFFCollector *Collector(void) const;
   const CConstraint *Constraint(void) const;

   bool operator == (const CFlowFact &) const;
   bool operator <  (const CFlowFact &) const;
   friend std::ostream & operator << (std::ostream &o, const CFlowFact &ff);

private:
   const CScope *_s;
   t_flowfacttype _type;
   CIndexRangeList _context;
   CFFCollector _collector;
   CConstraint _constraint;
   void Copy(const CFlowFact &theother);
   const CFlowFact & operator = (const CFlowFact &);
};

// For printing the flow fact type
std::ostream & operator << (std::ostream &o, const CFlowFact::t_flowfacttype &ff_type);

#endif
