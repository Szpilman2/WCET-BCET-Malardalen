// $Id $

#ifndef RAPITA_INTERMEDIATE_H_
#define RAPITA_INTERMEDIATE_H_

#include <vector>
#include <map>
#include <set>
#include <string>
#include <utility>

#include "tools/CSourceLoader.h"
#include "graphs/cfg/CFlowGraph.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "flow_facts/CContextSensitiveValidAtEntryOfFlowFact.h"
#include "flow_facts/FlowFactToRapita.h"

// -------------------------------------------------------
// Class that collects information from a a number of generated 
// context-sensitive valid-at-entry-of flow facts and produces
// aiS flow facts. Will optionally translate used ALF labels 
// to C source code labels in generated Rapita FFs.
// -------------------------------------------------------
class RapitaIntermediate
{
public:

  // To crxeate and delete a rapita intermediate
  RapitaIntermediate(const std::vector<CFlowGraph*> * flow_graphs, CSourceLoader *source_loader, 
                     bool ffs_based_on_traces = false);
  ~RapitaIntermediate();

  // ---------------------------------
  // Loop bounds
  // ---------------------------------

  // Add information to generate local loop bounds on Rapita format.
  // Format: #pragma RPT <alf_label> loop_max_iter(<count>) ; 
  // Should be generated using ffg=lhss (lower bound will be ignored)
  // or ffg=uhss and zero context-sensitivity (-f csl=0). Both bounds
  // will be converted to an upper bound on the number of times the
  // *loop body* can be executed for each entry of loop.
  void AddLocalLoopHeaderMaxCount(CFlowGraphNode * loop_header, int count);
  void AddLocalLoopBodyMaxCount(CFlowGraphNode * loop_header, int count);
  void AddLocalLoopHeaderMinCount(CFlowGraphNode * loop_header, int count);
  void AddLocalLoopBodyMinCount(CFlowGraphNode * loop_header, int count);

  // ---------------------------------
  // Infeasible nodes
  // ---------------------------------

  // Add information about infeasible/dead code on Rapita format.
  // Format: #pragma RPT <alf_label> ignore_path ; 
  // Generated using ffg=insa and zero context-sensitivity. Could
  // also be derived using ffg=lnss,unss,lnsf,unsf,lnsp,unsp when upper exec
  // bound is = 0 and zero context-sensitivity.
  void AddInfeasibleNode(CFlowGraphNode * node);

  // ---------------------------------
  // Scope local flow information
  // ---------------------------------

  // Add information to generate upper local node bounds on Rapita format.
  // Format: #pragma RPT <alf_label> wfreq(<count>) ; 
  // Should be generated using ffg=lnss (lower bounds will be ignored)
  // or ffg=unss and zero context-sensitivity (-f csl=0).
  void AddLocalNodeMaxCount(CFlowGraphNode * node, int count);

  // Add information about local exclusive nodes.
  // Format: #pragma RPT lwp_one_or_none_of (<alf_label1>, <alf_label2>) ;
  // Should be generated using ffg=inpa and zero context-sensitivity when 
  // upper bound of n1 + n2 is <= 1
  void AddLocalNodesOneOrNoneOf(CFlowGraphNode * node1, CFlowGraphNode * node2);

  // Add information about nodes taken locally at least once.
  // Format: #pragma RPT lwp_at_least_one_of (<alf_label1>) ;
  // Should be generated using ffg=lnss and zero context-sensitivity when
  // lower bound is >= 1.
  void AddLocalNodeAtLeastOneOf(CFlowGraphNode * node);

  // Add information about node pairs taken locally at least once.
  // Format: #pragma RPT lwp_at_least_one_of (<alf_label1>, <alf_label2>) ;
  // Should be generated using ffg=lnps and zero context-sensitivity when
  // lower bound of pairs is >= 1.
  void AddLocalNodesAtLeastOneOf(CFlowGraphNode * node1, CFlowGraphNode * node2);

  // Add information on nodes that must be taken togeher, or not at all, during
  // each iteration of a scope. This is made by assigning both nodes the
  // same tag (we create a new tag just for this ff).
  // Format: #pragma RPT lwp_one_or_none_of(<new_tag>); 
  // Generated using ffg=inpa and no merging.
  void AddLocalNodesMustBeTakenTogether(CFlowGraphNode * node1, CFlowGraphNode * node2);

  // ---------------------------------
  // Global flow information
  // ---------------------------------

  // Add information about nodes taken globally at least once.
  // Format: #pragma RPT wp_at_least_one_of (<alf_label1>) ;
  // Should be generated using ffg=lnsp and zero context-sensitivity when
  // lower bound is >= 1.
  void AddGlobalNodeAtLeastOneOf(CFlowGraphNode * node);

  // Add information on on global exclusive nodes.
  // Format: #pragma RPT wp_one_or_none_of (<alf_label1>, <alf_label2>); 
  // Should be generated using ffg=lnpp (only upper bound is used) or
  // unpp and zero context-sensitivity.  Generated when the loop pair
  // may be taken at most one time together, i.e. n1 + n2 <= 1.
  void AddGlobalNodesOneOrNoneOf(CFlowGraphNode * node1, CFlowGraphNode * node2);

  // ---------------------------------
  // Function calls 
  // ---------------------------------

  // Add information about called functions from a node
  // Format: #pragma RPT <alf_label> call_to ( <dummy_var>, <func_label1>, <func_label2>, ...) ;
  // Should be generated using ffg=lcsf,lcsp and zero context-sensitivity.
  // All edges having an upper exec count may be called from the call-site.
  // All functions should be given a tag equal to or similar to its function name.
  void AddFuncCallFromCallSite(CFlowGraphNode * call_site, CFlowGraphNode * called_node);

  // ---------------------------------
  // Generate output
  // ---------------------------------

  // To print the generated flow facts. If sl == NULL then that given
  // alf labels will be used in the Rapita ff printouts. Otherwise the
  // alf_labels will be translated to C source labels and
  // printed. Returns the number of flow facts generated.
  int PrintAsRapitaFlowFacts(std::ostream & out_stream, CSourceLoader * sl=NULL);

  // If the node belongs to a basic block whose start node is the
  // return-to node after a function call, then it is not a valid node
  // to refer to.  Otherwise it is.
  bool IsValidRapitaPathNode(CFlowGraphNode * node);

protected:

  // ---------------------------------
  // Help functions
  // ---------------------------------

  // Help function for adding a node to a set
  void AddNodeToSet(CFlowGraphNode * node, std::set<CFlowGraphNode *> & node_set);

  // Help function for assigning a node a max count in a given map
  // data structure.
  void AddMaxCountForNodeToMap(CFlowGraphNode * node, int count, std::map<CFlowGraphNode *, int> & node_to_max_count);
  void AddMinCountForNodeToMap(CFlowGraphNode * node, int count, std::map<CFlowGraphNode *, int> & node_to_min_count);

  // Help function for adding a node pair to a set
  void AddNodePairToSet(CFlowGraphNode * node1, CFlowGraphNode * node2, 
                        std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> > & node_pair_set);

  // To get a tag without $ signs
  std::string PrettifyTagName(std::string name);

  // ---------------------------------
  // Internal data structures
  // ---------------------------------

  // To keep track of local loop header max and min count
  std::map<CFlowGraphNode *, int> _local_loop_header_max_count;
  std::map<CFlowGraphNode *, int> _local_loop_header_min_count;

  // To keep track of local loop body max and min count
  std::map<CFlowGraphNode *, int> _local_loop_body_max_count;
  std::map<CFlowGraphNode *, int> _local_loop_body_min_count;

  // To keep track of infeasible nodes
  std::set<CFlowGraphNode *> _infeasible_nodes;

  // To keep track of local node max count
  std::map<CFlowGraphNode *, int> _local_node_max_count;

  // To keep track of local exclusive nodes
  std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> > _local_nodes_one_or_none_of;
  
  // To keep track of local node taken at least once
  std::set<CFlowGraphNode *> _local_node_at_least_one_of;
  
  // To keep track of local nodes taken at least once 
  std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> > _local_nodes_at_least_one_of;

  // To keep track of local nodes that must be taken together
  std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> > _local_nodes_must_be_taken_together;
  
  // To keep track of global nodes taken globally at least once
   std::set<CFlowGraphNode *> _global_node_at_least_one_of;
  
   // To keep track of global exclusive nodes
  std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> > _global_nodes_one_or_none_of;

  // To keep track of possible function calls from a call site
  std::map<CFlowGraphNode *, std::set<CFlowGraphNode *> *> _call_site_to_called_funcs;

  // To keep track of the alf labels and functions referenced
  std::set<CFlowGraphNode *> _nodes_referred_to;

  // To keep track of if we should generate flow facts or flow hypothesis
  bool _ffs_based_on_traces;

  // Needed for generating rapita indexes for loops, calls and nodes
  const std::vector<CFlowGraph*> * _flow_graphs;
  CSourceLoader * _source_loader;

  // A set holding the valid rapita nodes 
  std::set<CFlowGraphNode *> _valid_rapita_nodes;

  // A set holding temporary c_source labels to be removed
  std::set<CAlfLabelSource *> _temp_c_sources;

  // ---------------------------------
  // Help functions
  // ---------------------------------

  // Help functions to create a mapping between loop index, call-site index and bb node index 
  // to a alf label starting a basic block
  void CreateFuncLoopIndexPairToCFGNodeMap(const std::vector<CFlowGraph*> &flow_graphs, 
                                           CSourceLoader *source_loader, 
                                           std::map<std::pair<CGenericFunction *, unsigned int>,CFlowGraphNode *> * rapita_func_and_loop_index_pair_map_to_cfg_node);
  void CreateFuncCallIndexPairToCFGNodeMap(const std::vector<CFlowGraph*> &flow_graphs, 
                                           CSourceLoader *source_loader, 
                                           std::map<std::pair<CGenericFunction *, unsigned int>,CFlowGraphNode *> * rapita_func_and_call_index_pair_map_to_cfg_node,
                                           std::ostream & out_stream,
                                           bool collect_only_bb_start_nodes=true);
  void CreateFuncNodeIndexPairToCFGNodeMap(const std::vector<CFlowGraph*> &flow_graphs, 
                                           CSourceLoader *source_loader, 
                                           std::map<std::pair<CGenericFunction *, unsigned int>,CFlowGraphNode *> * rapita_func_and_node_index_pair_map_to_cfg_node,
                                           std::ostream & out_stream,
                                           bool collect_only_bb_start_nodes=true);

  // To derive the CFG nodes that are valid rapita path nodes
  void DeriveValidRapitaPathNodes(const std::vector<CFlowGraph*> * flow_graphs, 
                                  std::set<CFlowGraphNode *> * valid_rapita_nodes);

  // To get the sopurce info to be associated to a certain cfg node. If the node itself
  // does not have the source info we check the onther nodes in its basic block.
  const CAlfLabelSource * GetCSourceOfNode(CFlowGraphNode * node, CSourceLoader * sl);

  // To get the rapita name to use for a give alf label from a mapping.
  std::string GetRapitaNameFromMap(std::string alf_label, std::map<std::string, std::string> * alf_label_to_rapita_name_map);
  bool HasRapitaNameInMap(std::string alf_label, std::map<std::string, std::string> * alf_label_to_rapita_name_map);

};


// Help function for traversing a set of generated context-sensitive
// valid-at-entry-of ffs and creating a number of Rapita ffs.
void
UpdateRapitaIntermediateWithContextSensitiveValidAtEntryOfFlowFacts(const std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs, 
                                                                    RapitaIntermediate * ir);

#endif

