// $Id $

#include "CLocator.h"
#include "graphs/scopes/CScope.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "globals.h"

using namespace std;

CBBLocator::~CBBLocator(void)
{
}

CBBLocator::CBBLocator(void)
{
   _scope = NULL;
   _node = NULL;
}

CBBLocator::CBBLocator(CFlowGraphNode *node)
{
   _scope = NULL;
   _node = node;
}

CBBLocator::CBBLocator(CScope *scope, CFlowGraphNode *node)
{
   _scope = scope;
   _node = node;
}

const CScope *CBBLocator::GetScope(void) const
{
   return _scope;
}

const CFlowGraphNode *CBBLocator::GetNode(void) const
{
   return _node;
}

string CBBLocator::tostring(void) const
{
   string name = _node->Name();
   if (_scope) {
      return _scope->Name() + "." + name;
   } else {
      return name;
   }
}

// ostream & operator << (ostream &o, const CBBLocator &loc)
// {
//    o << loc._scope->Name() << '.' << loc._node->Name();
//    return o;
// }

CNodeLocator::CNodeLocator(t_loctype t)
{
        _type = t;
}

t_loctype CNodeLocator::GetType(void) const
{
   return _type;
}

CNodeLocator::~CNodeLocator(void)
{
}

CNodeLocatorBB::~CNodeLocatorBB(void)
{
}

CNodeLocatorBB::CNodeLocatorBB(CBBLocator loc):CNodeLocator(LOC_BB)
{
        _loc = loc;
}

const CBBLocator *CNodeLocatorBB::GetBBLocator(void) const
{
   return &_loc;
}

string CNodeLocatorBB::tostring(void) const
{
   return _loc.tostring();
}

CNodeLocatorId::~CNodeLocatorId(void)
{
   _node = NULL;
}

CNodeLocatorId::CNodeLocatorId(CFlowGraphNode *node):CNodeLocator(LOC_ID)
{
        _node = node;
}

const CFlowGraphNode *CNodeLocatorId::GetNode(void) const
{
   return _node;
}

string CNodeLocatorId::tostring(void) const
{
   return _node->Name();
}

CNodeLocatorEntry::~CNodeLocatorEntry(void)
{
}

CNodeLocatorEntry::CNodeLocatorEntry(CFlowGraphNode *node):CNodeLocator(LOC_ENTRY)
{
        _node = node;
}

const CFlowGraphNode *CNodeLocatorEntry::GetNode(void) const
{
   return _node;
}

string CNodeLocatorEntry::tostring(void) const
{
   return _node->Name() + ".entry";
}

CEdgeLocator::~CEdgeLocator(void)
{
}

CEdgeLocator::CEdgeLocator(void)
{
   _from = NULL;
   _to = NULL;
}

CEdgeLocator::CEdgeLocator(CNodeLocator *from, CNodeLocator *to)
{
   _from = from;
   _to = to;
}

const CNodeLocator *CEdgeLocator::From(void) const
{
   return _from;
}

const CNodeLocator *CEdgeLocator::To(void) const
{
   return _to;
}

string CEdgeLocator::tostring(void) const
{
   string from_node = _from->tostring();
   string to_node = _to->tostring();
   return from_node + " -> " + to_node;
}
