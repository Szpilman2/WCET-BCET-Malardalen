// $Id $

#ifndef CFFCOLLECTOR_H_
#define CFFCOLLECTOR_H_

#include <iostream>

class CIndexRange;



typedef enum {FOR_EACH, TOTAL} t_range_type;

class CFFCollector
{
public:
   CFFCollector(void);
   CFFCollector(const t_range_type t, CIndexRange *range=NULL);
   CFFCollector(const CFFCollector &theother);
   ~CFFCollector(void);
   bool operator == (const CFFCollector &theother) const;
   const CFFCollector & operator = (const CFFCollector &theother);
   
   /* Changes to a new range of the colloector, the previous one is deleted */
   void Range(CIndexRange *range);
   void RangeType(t_range_type t, CIndexRange *range);
   
   /* Returns a pointer to the current range of the colloector */
   const CIndexRange *Range(void) const;
   
   /* Returns the range type of the colloector */
   t_range_type RangeType(void) const;
   
   // To copy the collector
   CFFCollector * Copy() const;
   
   friend std::ostream & operator << (std::ostream &o, const CFFCollector &cc);

private:
   void Copy(const CFFCollector &theother);
   CIndexRange *_range;
   t_range_type _range_type;
};

#endif
