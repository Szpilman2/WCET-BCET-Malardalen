// $Id $

#ifndef CEXPRESSION_H_
#define CEXPRESSION_H_

#include <iostream>
#include "CLocator.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/ecfg/CECFGNode.h"

typedef enum {ETYPE_BINOP, ETYPE_UNOP, ETYPE_INT, ETYPE_CFG_NODE, ETYPE_CFG_EDGE, ETYPE_ECFG_NODE, ETYPE_ECFG_EDGE } t_etype;
typedef enum {BINOP_MUL, BINOP_DIV, BINOP_ADD, BINOP_SUB} t_binop;
typedef enum {UNOP_NOT, UNOP_MINUS} t_unop;

// -------------------------------------------------------
// CExpression -
// - Expression in constraints. Can be constants, unary or binary expressions, 
//   expression referring to cfg node or edge or ecfg node or edge.
// - General class to inherit from
// -------------------------------------------------------
class CExpression
{
public:
  CExpression(void);
  virtual ~CExpression(void);
  CExpression(t_etype t);
  CExpression(const CExpression &);
  virtual CExpression *NewExpression(void) = 0;
  virtual std::string tostring(void) const = 0;
  t_etype Type(void) const;
  virtual bool operator==(const CExpression &theother) const = 0;
  virtual CExpression & operator = (const CExpression &) = 0;
protected:
  t_etype Type(t_etype t);
private:
  t_etype _type;
};

// -------------------------------------------------------
// CExpressionBin -
// - Binary expression on the format: expr1 op expr2
// -------------------------------------------------------
class CExpressionBin :public CExpression
{
public:
  CExpressionBin(CExpression *l, t_binop op, CExpression *r);
  CExpressionBin(const CExpressionBin &);
  virtual ~CExpressionBin(void);

  // Returns the operator type of this expression
  t_binop GetOperator(void) const;

  // Returns the left sub expression of this expression
  CExpression *GetLeftExpression(void) const;

  // Returns the right sub expression of this expression
  CExpression *GetRightExpression(void) const;

  CExpression *NewExpression(void);
  bool operator==(const CExpression &theother) const;
  CExpression & operator = (const CExpression &);
  std::string tostring(void) const;
private:
  t_binop _op;
  CExpression *_left, *_right;
};

// -------------------------------------------------------
// CExpressionUn -
// - Unary expression on the format: op expr
// -------------------------------------------------------
class CExpressionUn :public CExpression
{
public:
  CExpressionUn(t_unop op, CExpression *exp);
  CExpressionUn(const CExpressionUn &);
  virtual ~CExpressionUn(void);

  // Returns the operator type of this expression
  t_unop GetOperator(void) const;

  // Returns the left sub expression of this expression
  const CExpression *GetExpression(void) const;

  CExpression *NewExpression(void);
  bool operator==(const CExpression &theother) const;
  CExpression & operator = (const CExpression &);
  std::string tostring(void) const;
private:
  t_unop _op;
  CExpression *_exp;
};

// -------------------------------------------------------
// CExpressionInt -
// - Expression referring to a singed integer constant 
// -------------------------------------------------------
class CExpressionInt :public CExpression
{
public:
  CExpressionInt(int val);
  virtual ~CExpressionInt(void);

  // Returns the integer value of this expression
  int Value(void) const;

  CExpression *NewExpression(void);
  bool operator==(const CExpression &theother) const;
  CExpression & operator = (const CExpression &);
  std::string tostring(void) const;
private:
  int _val;
};

// -------------------------------------------------------
// CExpressionFlowGraphNode -
// - Expression referring to a flow graph node
// - Used by context sensitive flow facts  
// - Used sometimes by scope graph flow facts
// -------------------------------------------------------
class CExpressionFlowGraphNode : public CExpression
{
public:
  CExpressionFlowGraphNode(CFlowGraphNode * node);
  virtual ~CExpressionFlowGraphNode();
  
  // To get the node
  const CFlowGraphNode * Node() const { return _node; };

  CExpression* NewExpression(void);
  bool operator==(const CExpression &theother) const;
  CExpression & operator = (const CExpression &);
  std::string tostring(void) const;
private:
  CFlowGraphNode * _node;
};

// -------------------------------------------------------
// CExpressionFlowGraphEdge -
// - Expression referring to a flow graph edge
// - Used mostly by context sensitive flow facts 
// - Used sometimes by scope graph flow facts
// -------------------------------------------------------
class CExpressionFlowGraphEdge : public CExpression
{
public:
  CExpressionFlowGraphEdge(CFlowGraphNode * from_node, CFlowGraphNode * to_node);
  virtual ~CExpressionFlowGraphEdge();
  
    // To get the from and to node
  CFlowGraphNode * FromNode() const { return _from_node; };
  CFlowGraphNode * ToNode() const { return _to_node; };

  CExpression* NewExpression(void);
  bool operator==(const CExpression &theother) const;
  CExpression & operator = (const CExpression &);
  std::string tostring(void) const;
private:
  CFlowGraphNode * _from_node;
  CFlowGraphNode * _to_node;
};


// -------------------------------------------------------
// CExpressionECFGNode -
// - Expression referring to an ecfg node 
// - Used by scope graph flow facts 
// -------------------------------------------------------
class CExpressionECFGNode : public CExpression
{
public:
  CExpressionECFGNode(CECFGNode * node);
  virtual ~CExpressionECFGNode();
  
  // To get the node
  const CECFGNode * Node() const { return _node; };

  // Get the id-string of this expression
  std::string Id(void) const;

  CExpression* NewExpression(void);
  bool operator==(const CExpression &theother) const;
  CExpression & operator = (const CExpression &);
  std::string tostring(void) const;
private:
  CECFGNode * _node;
};

// -------------------------------------------------------
// CExpressionECFGEdge -
// - Expression referring to a flow graph edge 
// - Used by scope graph flow facts 
// -------------------------------------------------------
class CExpressionECFGEdge : public CExpression
{
public:
  CExpressionECFGEdge(CECFGNode * from_node, CECFGNode * to_node);
  virtual ~CExpressionECFGEdge();
  
    // To get the from and to node
  const CECFGNode * FromNode() const { return _from_node; };
  const CECFGNode * ToNode() const { return _to_node; };

  CExpression* NewExpression(void);
  bool operator==(const CExpression &theother) const;
  CExpression & operator = (const CExpression &);
  std::string tostring(void) const;
private:
  CECFGNode * _from_node;
  CECFGNode * _to_node;
};

#endif
