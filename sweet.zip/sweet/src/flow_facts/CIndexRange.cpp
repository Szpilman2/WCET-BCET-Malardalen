// $Id $
#include "CIndexRange.h"
#include <cassert>
#include <iostream>

using namespace std;

CIndexRange::CIndexRange (void)
{
        _is_bottom = true;
}

CIndexRange::CIndexRange(int lb, int ub)
{
        _is_bottom = false;
        _lb = lb;
        _ub = ub;
}

CIndexRange::~CIndexRange(void)
{
}

int CIndexRange::IsBottom(void) const
{
        return _is_bottom;
}

int CIndexRange::LowerBound(void) const
{
        assert (_is_bottom == false);
        return _lb;
}

void CIndexRange::ExtendRange(int value)
{
        if (_is_bottom == true) {
           _lb = value;
           _ub = value;
           _is_bottom = false;
        } else {
     if (value < _lb) _lb = value;
     else if (value > _ub) _ub = value;
   }
}

int CIndexRange::LowerBound(int lb) 
{
        assert (_is_bottom == false);
        return _lb = lb;
}

int CIndexRange::UpperBound(void) const
{
        assert (_is_bottom == false);
        return _ub;
}

int CIndexRange::UpperBound(int ub)
{
        assert (_is_bottom == false);
        return _ub = ub;
}

bool CIndexRange::operator < (const CIndexRange &theother) const
{
        assert (_is_bottom == false);
   if (_ub == theother._ub)
      return _lb < theother._lb;
   return _ub < theother._ub;
}

bool CIndexRange::operator == (const CIndexRange &theother) const
{
        assert (_is_bottom == false);
   return _ub == theother._ub && _lb == theother._lb;
}

ostream & operator << (ostream &o, const CIndexRange &r)
{
        if (r._is_bottom == true) {
                o << "bottom";
        } else {
          // if (r._lb == r._ub)
          // o << r._lb;
          // else
          o << r._lb << ".." << r._ub;
   }
        return o;
}

