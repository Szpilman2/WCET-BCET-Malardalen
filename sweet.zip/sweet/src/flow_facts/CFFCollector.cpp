// $Id $
#include "CFFCollector.h"
#include "CIndexRange.h"
#include <cassert>

using namespace std;

CFFCollector::CFFCollector() :
   _range (NULL),
   _range_type(TOTAL)
{
}

CFFCollector::CFFCollector(t_range_type t, CIndexRange *range) :
   _range (range),
   _range_type(t)
{
}

CFFCollector::~CFFCollector(void)
{
   if (_range)
      delete _range;
}

void CFFCollector::Copy(const CFFCollector &theother)
{
   if (theother._range) {
      _range = new CIndexRange();
      *_range = *theother._range;
   } else
      _range = NULL;
   _range_type = theother._range_type;
}

CFFCollector::CFFCollector(const CFFCollector &theother)
{
   Copy(theother);
}

bool CFFCollector::operator == (const CFFCollector &theother) const
{
   bool equal_ranges;
   if (_range == NULL) {
      if (theother._range != NULL)
         return false;
      equal_ranges = true;
   } else if (theother._range == NULL)
      return false;
   else
      equal_ranges = *_range == *theother._range;
   return _range_type == theother._range_type && equal_ranges;
}

const CFFCollector & CFFCollector::operator = (const CFFCollector &theother)
{
   Copy(theother);
   return *this;
}

void CFFCollector::Range(CIndexRange *range)
{
   delete _range;
   _range = range;
}

void CFFCollector::RangeType(t_range_type t, CIndexRange *range)
{
   delete _range;
   _range = range;
   _range_type = t;
}

const CIndexRange *CFFCollector::Range(void) const
{
   return _range;
}

t_range_type CFFCollector::RangeType(void) const
{
   return _range_type;
}

ostream & operator << (ostream &o, const CFFCollector &cc)
{
   if (cc._range_type == FOR_EACH) {
      o << "<";
      if (cc._range)
         o << *cc._range;
      o << ">";
   } else if (cc._range_type == TOTAL) {
      o << "[";
      if (cc._range)
         o << *cc._range;
      o << "]";
   } else
      ;
        return o;
}

