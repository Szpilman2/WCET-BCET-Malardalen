// $Id $

#ifndef CCONSTRAINT_H_
#define CCONSTRAINT_H_

#include <iostream>

class CExpression;
typedef enum {RELOP_LT, RELOP_LTEQ, RELOP_GT, RELOP_GTEQ, RELOP_EQ, RELOP_NEQ} t_relop;

class CConstraint
{
private:
   CExpression *_left;
   t_relop _relop;
   CExpression *_right;
   void Copy(const CConstraint &theother);
public:
   CConstraint(void);
   CConstraint(CExpression *l, t_relop op, CExpression *r);
   CConstraint(const CConstraint &);
   virtual ~CConstraint(void);

   // Returns the relation operator type of this constraint
   t_relop GetOperator(void);

   // Returns the left expression of this constraint
   CExpression *GetLeftExpression(void);

   // Returns the right expression of this constraint
   CExpression *GetRightExpression(void);

   // Merges two constarints
   // CConstraint MergeConstraints(const CConstraint *) const;
   bool operator == (const CConstraint &theother) const;
   const CConstraint & operator = (const CConstraint &theother);
   bool operator<(const CConstraint &theother) const;
   void Print(std::ostream *o) const;
   friend std::ostream & operator << (std::ostream &o, const CConstraint &c)
   { c.Print(&o); return o; }

   // To copy a constraint
   CConstraint* Copy() const;
};

#endif
