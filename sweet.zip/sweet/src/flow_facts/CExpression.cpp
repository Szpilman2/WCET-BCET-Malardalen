// $Id $
#include "CExpression.h"
#include "graphs/scopes/CScope.h"
#include <cassert>
#include <sstream>

using namespace std;

// -------------------------------------------------------
// CExpression
// -------------------------------------------------------

CExpression::CExpression(t_etype t)
{
        _type = t;
}

CExpression::CExpression(const CExpression &theother)
{
        _type = theother._type;
}

CExpression::~CExpression(void)
{
}

t_etype CExpression::Type(t_etype t)
{
        return _type = t;
}

t_etype CExpression::Type(void) const
{
        return _type;
}


// -------------------------------------------------------
// CExpressionBin
// -------------------------------------------------------

// Binary expression:
CExpressionBin::CExpressionBin(CExpression *l, t_binop op, CExpression *r):CExpression(ETYPE_BINOP)
{
        _left = l;
        _right = r;
        _op = op;
}

CExpressionBin::CExpressionBin(const CExpressionBin &theother) : CExpression(theother)
{
        _right = theother._right->NewExpression();
        _op = theother._op;
        _left = theother._left->NewExpression();
}

CExpressionBin::~CExpressionBin(void)
{
        delete _left;
        delete _right;
}

t_binop CExpressionBin::GetOperator(void) const
{
   return _op;
}

CExpression *CExpressionBin::GetLeftExpression(void) const
{
   return _left;
}

CExpression *CExpressionBin::GetRightExpression(void) const
{
   return _right;
}

CExpression *CExpressionBin::NewExpression(void)
{
   CExpressionBin *e = new CExpressionBin(_left->NewExpression(), _op, _right->NewExpression());
   return e;

}

CExpression & CExpressionBin::operator = (const CExpression &right_hand)
{
   if (&right_hand != this) {
      CExpressionBin *r = (CExpressionBin *)&right_hand;
      Type(r->Type());
      _right = r->_right->NewExpression();
      _op = r->_op;
      _left = r->_left->NewExpression();
   }
   return *this;
}

bool CExpressionBin::operator==(const CExpression &theother) const
{
   if (theother.Type() != ETYPE_BINOP)
      return false;
   CExpressionBin *other = (CExpressionBin*)&theother;
   if((GetOperator() == other->GetOperator()) &&
      (GetLeftExpression() == other->GetLeftExpression()) &&
      (GetRightExpression() == other->GetRightExpression()))
     return true;
   else
     return false;
}

string CExpressionBin::tostring(void) const
{
   string s;
   s = /*"(" + */_left->tostring();
   switch (_op) {
/*
   case BINOP_MUL:
      s += " * ";
      break;
   case BINOP_DIV:
      s += " / ";
      break;
*/
   case BINOP_ADD:
      s += " + ";
      break;
/*
   case BINOP_SUB:
      s += " - ";
      break;
*/
   default:
      assert(0);
      break;
   }
   s += _right->tostring()/* + ")"*/;
   return s;
}

// -------------------------------------------------------
// CExpressionUn
// -------------------------------------------------------

// Unary expression:
CExpressionUn::CExpressionUn(t_unop op, CExpression *exp):CExpression(ETYPE_UNOP)
{
   _op = op;
   _exp = exp;
}

CExpressionUn::CExpressionUn(const CExpressionUn &theother) : CExpression(theother)
{
   _op = theother._op;
   _exp = theother._exp->NewExpression();
}

CExpressionUn::~CExpressionUn(void)
{
   delete _exp;
}

t_unop CExpressionUn::GetOperator(void) const
{
   return _op;
}

const CExpression *CExpressionUn::GetExpression(void) const
{
   return _exp;
}

CExpression *CExpressionUn::NewExpression(void)
{
   CExpressionUn *e = new CExpressionUn(_op, _exp->NewExpression());
   return e;
}

CExpression & CExpressionUn::operator = (const CExpression &right_hand)
{
   if (&right_hand != this) {
      CExpressionUn *r = (CExpressionUn *)&right_hand;
      Type(r->Type());
      _op = r->_op;
      _exp = r->_exp->NewExpression();
   }
   return *this;
}

bool CExpressionUn::operator==(const CExpression &theother) const
{
   if (theother.Type() != ETYPE_UNOP)
      return false;
   CExpressionUn *other = (CExpressionUn*)&theother;
   if((GetOperator() == other->GetOperator()) &&
      (GetExpression() == other->GetExpression()))
     return true;
   else
     return false;
}



string CExpressionUn::tostring(void) const
{
   string s;
   switch (_op) {
   case UNOP_NOT:
      s = "!";
      break;
   case UNOP_MINUS:
      s = "-";
      break;
   default:
      assert(0);
      break;
   }
   s += _exp->tostring();
        return s;
}

// -------------------------------------------------------
// CExpressionInt
// -------------------------------------------------------

// Expression int (base case):
CExpressionInt::CExpressionInt(int val):CExpression(ETYPE_INT)
{
   _val = val;
}

CExpressionInt::~CExpressionInt(void)
{
}

CExpression *CExpressionInt::NewExpression(void)
{
   CExpressionInt *e = new CExpressionInt(_val);
   return e;
}

int CExpressionInt::Value(void) const
{
   return _val;
}

bool CExpressionInt::operator==(const CExpression &theother) const
{
   if(theother.Type() != Type()) 
      return false;
   else {
      CExpressionInt *r = (CExpressionInt *)&theother;
      return r->Value() == Value();
   }
}

CExpression & CExpressionInt::operator = (const CExpression &right_hand)
{
   CExpressionInt *r = (CExpressionInt *)&right_hand;
   Type(r->Type());
   _val = r->_val;
   return *this;
}

string CExpressionInt::tostring(void) const
{
   stringstream ss;
   ss << _val;
   return ss.str();
}

// -------------------------------------------------------
// CExpressionFlowGraphNode
// -------------------------------------------------------

CExpressionFlowGraphNode::
CExpressionFlowGraphNode(CFlowGraphNode * node)
  : CExpression(ETYPE_CFG_NODE), _node(node) 
{
  // Do nothing
}

CExpressionFlowGraphNode::
~CExpressionFlowGraphNode(void)
{
  // Do nothing
}

CExpression *
CExpressionFlowGraphNode::
NewExpression(void)
{
  return new CExpressionFlowGraphNode(_node);
}

bool 
CExpressionFlowGraphNode::operator==(const CExpression &theother) const
{
   if(theother.Type() != Type()) 
      return false;
   else {
      CExpressionFlowGraphNode *r = (CExpressionFlowGraphNode *)&theother;
      return r->Node() == Node();
   }
}

CExpression & CExpressionFlowGraphNode::operator = (const CExpression &other)
{
   CExpressionFlowGraphNode *r = (CExpressionFlowGraphNode *)&other;
   Type(r->Type());
   _node = r->_node;
   return *this;
}

std::string  
CExpressionFlowGraphNode::tostring(void) const
{
   return _node->Stmt()->TryGetSourceString();
}

// -------------------------------------------------------
// CExpressionFlowGraphEdge
// -------------------------------------------------------

CExpressionFlowGraphEdge::
CExpressionFlowGraphEdge(CFlowGraphNode * from_node, CFlowGraphNode * to_node)
  : CExpression(ETYPE_CFG_EDGE), _from_node(from_node), _to_node(to_node)
{
  // Do nothing
}

CExpressionFlowGraphEdge::
~CExpressionFlowGraphEdge(void)
{
  // Do nothing
}

CExpression *
CExpressionFlowGraphEdge::
NewExpression(void)
{
   return new CExpressionFlowGraphEdge(_from_node, _to_node);
}

bool 
CExpressionFlowGraphEdge::operator==(const CExpression &theother) const
{
   if(theother.Type() != Type()) 
      return false;
   else {
      CExpressionFlowGraphEdge *r = (CExpressionFlowGraphEdge *)&theother;
      return (r->FromNode() == FromNode()) && (r->ToNode() == ToNode());
   }
}

CExpression & CExpressionFlowGraphEdge::operator = (const CExpression &other)
{
   CExpressionFlowGraphEdge *r = (CExpressionFlowGraphEdge *)&other;
   Type(r->Type());
   _from_node = r->_from_node;
   _to_node = r->_to_node;
   return *this;
}

std::string  
CExpressionFlowGraphEdge::tostring(void) const
{
   return _from_node->Stmt()->TryGetSourceString() + "->"
      + _to_node->Stmt()->TryGetSourceString();
}

// -------------------------------------------------------
// CExpressionECFGNode
// -------------------------------------------------------

CExpressionECFGNode::
CExpressionECFGNode(CECFGNode * node)
  : CExpression(ETYPE_ECFG_NODE), _node(node) 
{
  // Do nothing
}

CExpressionECFGNode::
~CExpressionECFGNode(void)
{
  // Do nothing
}

CExpression *
CExpressionECFGNode::
NewExpression(void)
{
   return new CExpressionECFGNode(_node);
}

bool 
CExpressionECFGNode::operator==(const CExpression &theother) const
{
   if(theother.Type() != Type()) 
      return false;
   else {
      CExpressionECFGNode *r = (CExpressionECFGNode *)&theother;
      return r->Node() == Node();
   }
}

CExpression & CExpressionECFGNode::operator = (const CExpression &other)
{
   CExpressionECFGNode *r = (CExpressionECFGNode *)&other;
   Type(r->Type());
   _node = r->_node;
   return *this;
}

std::string  
CExpressionECFGNode::tostring(void) const
{
   return _node->Scope()->Name() + "."
      + _node->GetFlowGraphNode()->Stmt()->TryGetSourceString();
}


// -------------------------------------------------------
// CExpressionECFGEdge
// -------------------------------------------------------

CExpressionECFGEdge::
CExpressionECFGEdge(CECFGNode * from_node, CECFGNode * to_node)
  : CExpression(ETYPE_ECFG_EDGE), _from_node(from_node), _to_node(to_node)
{
  // Do nothing
}

CExpressionECFGEdge::
~CExpressionECFGEdge(void)
{
  // Do nothing
}

CExpression *
CExpressionECFGEdge::
NewExpression(void)
{
  return new CExpressionECFGEdge(_from_node, _to_node);
}

bool 
CExpressionECFGEdge::operator==(const CExpression &theother) const
{
  if(theother.Type() != Type()) return false;
  else {
    CExpressionECFGEdge *r = (CExpressionECFGEdge *)&theother;
    return (r->FromNode() == FromNode()) && (r->ToNode() == ToNode());
  }
}

CExpression & CExpressionECFGEdge::operator = (const CExpression &other)
{
  CExpressionECFGEdge *r = (CExpressionECFGEdge *)&other;
  Type(r->Type());
  _from_node = r->_from_node;
  _to_node = r->_to_node;
  return *this;
}

std::string  
CExpressionECFGEdge::tostring(void) const
{
  return _from_node->Scope()->Name() + "."
     + _from_node->GetFlowGraphNode()->Stmt()->TryGetSourceString() + "->" 
     + _to_node->Scope()->Name() + "."
     + _to_node->GetFlowGraphNode()->Stmt()->TryGetSourceString();
}
