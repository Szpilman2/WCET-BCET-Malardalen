#include "flow_facts/AisIntermediate.h"
#include "program/CGenericStmt.h"
#include "program/alf/AStmt.h"
#include "program/alf/CLabelTuple.h"
#include "program/CGenericFunction.h"
#include "program/CGenericStmt.h"
#include "program/alf/CGenericNode.h"
#include "program/alf/CCallStmtTuple.h"
#include "flow_facts/CExpression.h"
#include "flow_facts/CConstraint.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/cfg/CFlowGraph.h"
#include "graphs/components/CComponent.h"
#include <cassert>
#include <algorithm>
#include <sstream>

using namespace std;

AisIntermediate::
AisIntermediate(std::string root_func_name, bool ffs_based_on_traces)
  : _root_func_name(root_func_name), _ffs_based_on_traces(ffs_based_on_traces)
{
  // Do nothing
}

AisIntermediate::
~AisIntermediate()
{
  // Delete all function call sets
  for(std::map<CFlowGraphNode *, std::set<CGenericFunction *> *>::iterator c2fs = _call_site_to_called_funcs.begin();
      c2fs != _call_site_to_called_funcs.end(); ++c2fs) {
    delete (*c2fs).second;
  }
}

void
AisIntermediate::
AddLoopHeaderLocalMinCount(CFlowGraphNode * loop_header, int count)
{
  int new_count = count;
  if(_loop_to_loop_header_local_min_count.find(loop_header) != _loop_to_loop_header_local_min_count.end()) {
    int old_count = _loop_to_loop_header_local_min_count[loop_header];
    if(old_count > count)
      new_count = old_count;
  }
  _loop_to_loop_header_local_min_count[loop_header] = new_count;
  // Remember the alf label used
  _referred_nodes.insert(loop_header);
  _referred_alf_labels.insert(loop_header->Name());
}


void
AisIntermediate::
AddLoopHeaderLocalMaxCount(CFlowGraphNode * loop_header, int count)
{
  int new_count = count;
  if(_loop_to_loop_header_local_max_count.find(loop_header) != _loop_to_loop_header_local_max_count.end()) {
    int old_count = _loop_to_loop_header_local_max_count[loop_header];
    if(old_count < count)
      new_count = old_count;
  }
  _loop_to_loop_header_local_max_count[loop_header] = new_count;
  // Remember the alf label used
  _referred_nodes.insert(loop_header);
  _referred_alf_labels.insert(loop_header->Name());
}

void
AisIntermediate::
AddLoopBodyLocalMinCount(CFlowGraphNode * loop_header, int count)
{
  int new_count = count;
  if(_loop_to_loop_body_local_min_count.find(loop_header) != _loop_to_loop_body_local_min_count.end()) {
    int old_count = _loop_to_loop_body_local_min_count[loop_header];
    if(old_count > count)
      new_count = old_count;
  }
  _loop_to_loop_body_local_min_count[loop_header] = new_count;
  // Remember the alf label used
  _referred_nodes.insert(loop_header);
  _referred_alf_labels.insert(loop_header->Name());
}


void
AisIntermediate::
AddLoopBodyLocalMaxCount(CFlowGraphNode * loop_header, int count)
{
  int new_count = count;
  if(_loop_to_loop_body_local_max_count.find(loop_header) != _loop_to_loop_body_local_max_count.end()) {
    int old_count = _loop_to_loop_body_local_max_count[loop_header];
    if(old_count < count)
      new_count = old_count;
  }
  _loop_to_loop_body_local_max_count[loop_header] = new_count;
  // Remember the alf label used
  _referred_nodes.insert(loop_header);
  _referred_alf_labels.insert(loop_header->Name());
}


void 
AisIntermediate::
AddNodeSumMinCount(std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of, std::vector<CFlowGraphNode *> nodes_to_sum, int count)
{
  // Remember the func and alf labels used 
  if(valid_at_entry_of.second)
    _referred_alf_labels.insert(valid_at_entry_of.second->Name());
  _referred_funcs.insert(valid_at_entry_of.first);
  for(std::vector<CFlowGraphNode *>::iterator node = nodes_to_sum.begin(); node != nodes_to_sum.end(); node++) {
    _referred_nodes.insert(*node);
    _referred_alf_labels.insert((*node)->Name());
  }

  // Store the mapping
  int new_count = count;
  sort(nodes_to_sum.begin(),nodes_to_sum.end());
  std::pair<std::pair<CGenericFunction *, CGenericStmt *>, std::vector<CFlowGraphNode *> > vns = make_pair(valid_at_entry_of, nodes_to_sum);
  if(_vns_to_min_count.find(vns) != _vns_to_min_count.end()) {
    int old_count = _vns_to_min_count[vns];
    // We use the smallest upper bound
    if(old_count < new_count)
      new_count = old_count;
  }
  _vns_to_min_count[vns] = new_count;
}



void 
AisIntermediate::
AddNodeSumMaxCount(std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of, std::vector<CFlowGraphNode *> nodes_to_sum, int count)
{
  // Remember the func and alf labels used 
  if(valid_at_entry_of.second)
    _referred_alf_labels.insert(valid_at_entry_of.second->Name());
  _referred_funcs.insert(valid_at_entry_of.first);
  for(std::vector<CFlowGraphNode *>::iterator node = nodes_to_sum.begin(); node != nodes_to_sum.end(); node++) {
    _referred_nodes.insert(*node);
    _referred_alf_labels.insert((*node)->Name());
  }

  // Store the mapping
  int new_count = count;
  sort(nodes_to_sum.begin(),nodes_to_sum.end());
  std::pair<std::pair<CGenericFunction *, CGenericStmt *>, std::vector<CFlowGraphNode *> > vns = make_pair(valid_at_entry_of, nodes_to_sum);
  if(_vns_to_max_count.find(vns) != _vns_to_max_count.end()) {
    int old_count = _vns_to_max_count[vns];
    // We use the smallest upper bound
    if(old_count > new_count)
      new_count = old_count;
  }
  _vns_to_max_count[vns] = new_count;
}

// Add information about called functions from a node
void
AisIntermediate::
AddFuncCallFromCallSite(CFlowGraphNode * call_site, CGenericFunction * called_func)
{
  // Create a set for the call site if needed
  if(_call_site_to_called_funcs.find(call_site) == _call_site_to_called_funcs.end())
    _call_site_to_called_funcs[call_site] = new std::set<CGenericFunction *>;
  // Add the called node to the set
  _call_site_to_called_funcs[call_site]->insert(called_func);
  
  // Remember the alf labels used
  _referred_nodes.insert(call_site);
  _referred_nodes.insert(call_site->GetBeginNodeOfNodesBasicBlock());
  _referred_alf_labels.insert(call_site->Name());
  _referred_alf_labels.insert(call_site->GetBeginNodeOfNodesBasicBlock()->Name());
  _referred_funcs.insert(called_func);
}

void 
AisIntermediate::
AddEqualTo(CFlowGraphNode * node1, CFlowGraphNode * node2)
{
  AddNodePairToSet(node1, node2, _equal_to_nodes);
}

void 
AisIntermediate::
AddNodePairToSet(CFlowGraphNode * node1, CFlowGraphNode * node2, 
                 std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> > & node_pair_set)
{
  // To avoid unneccessary copies we order the nodes before we insert
  // them into the set
  CFlowGraphNode * n1 = NULL;
  CFlowGraphNode * n2 = NULL;
  if(node1 < node2) {
    n1 = node1; 
    n2 = node2;
  }
  else {
    n1 = node2;
    n2 = node1;
  }
  node_pair_set.insert(std::make_pair(n1,n2));

  // Remember the alf label used
  _referred_nodes.insert(node1);
  _referred_nodes.insert(node2);
}


std::string
AisIntermediate::
GetCSourceNameFromLabel(CSourceLoader * sl, std::string alf_label)
{
  if(sl != NULL) 
    return sl->GetCSourceNameFromLabel(alf_label, "_");
  else
    return alf_label;
}

// 
// Info from Henrik Theiling on how to create aiS loop bounds:
// 
// The translation of the minimum and maximum you specify depends on
// whether you mark it with 'start' or 'end' or nothing.  Internally, aiT
// needs the bound on the loop header, while a user usually counts the
// iterations of the loop body.  The two are identical for do{}while()
// loops, but different for while(){} loops, where the header bound is
// one larger (because the header is the first block of the condition,
// not the first block in the loop body).  So if you specify nothing, aiT
// will assume that you don't know whether it's a while(){} or a
// do{}while() loop. For the three cases, the numbers are adjusted as
// follows ([a..b] is the user's loop bound, counting body iterations):
//
//    User's Annotation                  Internal Bound
//    min a max b                 =>     [a..b+1]
//    min a max b begin           =>     [a+1..b+1]
//    min a max b end             =>     [a..b]
    
int
AisIntermediate::
PrintAsAisFlowFacts(std::ostream & out_stream, CSourceLoader * sl)
{
   stringstream temp_stream;

  int nr_of_ais_ffs = 0;
  
  // ---------------------------------
  // Print ais labels
  // ---------------------------------
  std::string flow_info = "flow facts";
  if(_ffs_based_on_traces) 
    flow_info = "flow hypothesis";

  if(sl) {
    temp_stream << "# AIS " << flow_info << " generated using mapping file" << endl << endl;

    // Make ais labels for all ALF labels
    temp_stream << "# Label specifications" << endl;
    for(std::set<CFlowGraphNode *>::iterator node = _referred_nodes.begin();
        node != _referred_nodes.end(); ++node) {
      // Get the corresponding C source code label if such exists
      std::string alf_label = (*node)->Name();
      const CAlfLabelSource * alf_label_src = sl->GetSourceOfLabel(alf_label);
      if(alf_label_src) {
        // Print a comment including all needed information
        temp_stream << "# Label: " <<  GetCSourceNameFromLabel(sl, alf_label) 
                   << " refers to file: " << CSourceLoader::PrettifyFileName(alf_label_src->GetFileName()) 
                   << " function: " << CSourceLoader::PrettifyFuncName((*node)->FlowGraph()->Function()->Name()) 
                   << " line: " << alf_label_src->GetLineNumber() 
                   << " column: " << alf_label_src->GetColumnNumber()
                   << " and alf_label: " << alf_label << endl;
        // Print the annotation
        temp_stream << "LABEL FILE \"" << CSourceLoader::PrettifyFileName(alf_label_src->GetFileName()) << "\" LINE " 
                   << alf_label_src->GetLineNumber() << " = \"" << GetCSourceNameFromLabel(sl, alf_label) << "\" ; " << endl; 
      }
    }
    temp_stream << endl;
  } 
  else {
    temp_stream << "# AIS " << flow_info << " generated without mapping file" << endl << endl;
  }

  // ---------------------------------
  // Print loop bounds
  // ---------------------------------
  {
    bool first_loop_bound = true;

    // We could either generate local loop bound by loop header count
    // flow facts.
    if(_loop_to_loop_header_local_max_count.size() > 0) {

      // Get loop bounds from loop header lower and upper bounds
      for(std::map<CFlowGraphNode *, int>::iterator l2c = _loop_to_loop_header_local_max_count.begin();
          l2c != _loop_to_loop_header_local_max_count.end(); l2c++) {
        // Extract the label and the count
        CFlowGraphNode * node = (*l2c).first;
        std::string alf_label = (*l2c).first->Name();
        int max_count = (*l2c).second;

        // Check if there is a corresponding min count
        bool has_min_count = false;
        int min_count = 0;
        if(_loop_to_loop_header_local_min_count.find(node) != _loop_to_loop_header_local_min_count.end()) {
          min_count = _loop_to_loop_header_local_min_count[node];
          has_min_count = true;
        }
        
        // Print the loop bound to file
        if(sl == NULL || sl->GetSourceOfLabel(alf_label)) {
          if(first_loop_bound) {
            temp_stream << "# Loop bounds" << endl;
            first_loop_bound = false;
          }
          // Print using just the ALF labels. 
          temp_stream << "LOOP \"" << GetCSourceNameFromLabel(sl, alf_label) << "\"";
          // Check the type of loop the flow graph node is header in
          CFlowGraph * fg = node->FlowGraph();
          bool is_while_do_loop = fg->NodeHasExitEdgeToNonSubordinateComponent(node);

          // If the loop is a while-do-loop (for-loop) we should withdraw one count from the
          // min and max iteration bound to get the body bound.
          if(is_while_do_loop && (max_count-1) > 0) {
            if(has_min_count && (min_count-1) > 0) temp_stream << " MIN " << min_count-1;
            temp_stream << " MAX " << max_count-1;
            temp_stream << " BEGIN ";
          }
          // A do-while loop, ie. header bound = body bound. 
          else {
            if(has_min_count) temp_stream << " MIN " << min_count;
            temp_stream << " MAX " << max_count;
            temp_stream << " END ";
          }          

          // End the loop annotation
          temp_stream << ";" << endl;
          
          // Remember that we have created a flow fact
          nr_of_ais_ffs++;
        }
      } // end for
    } // end if 
    
    // Alternatively we could generate the loop bounds by counting
    // the loop body beging edges.
    else if(_loop_to_loop_body_local_max_count.size() > 0) {

      // Get loop bounds from loop body lower and upper bounds
      for(std::map<CFlowGraphNode *, int>::iterator l2c = _loop_to_loop_body_local_max_count.begin();
          l2c != _loop_to_loop_body_local_max_count.end(); l2c++) {
        // Extract the label and the count
        CFlowGraphNode * node = (*l2c).first;
        std::string alf_label = (*l2c).first->Name();
        int max_count = (*l2c).second;

        // Check if there is a corresponding min count
        bool has_min_count = false;
        int min_count = 0;
        if(_loop_to_loop_body_local_min_count.find(node) != _loop_to_loop_body_local_min_count.end()) {
          min_count = _loop_to_loop_body_local_min_count[node];
          has_min_count = true;
        }

        // Print the loop bound to file
        if(sl == NULL || sl->GetSourceOfLabel(alf_label)) {
          if(first_loop_bound) {
            temp_stream << "# Loop bounds" << endl;
            first_loop_bound = false;
          }
          // Print using just the ALF labels. We print the actual counts since
          // we have derived bounds on the loop boudy executions 
          temp_stream << "LOOP \"" << GetCSourceNameFromLabel(sl, alf_label) << "\"";

          // Check the type of loop the flow graph node is header in
          CFlowGraph * fg = node->FlowGraph();
          bool is_while_do_loop = fg->NodeHasExitEdgeToNonSubordinateComponent(node);

          // if it is a while-do loop (for-loop) we should withdraw one more from min and max 
          if(is_while_do_loop && (max_count-1) > 0) {
            if(has_min_count && (min_count-1) > 0) temp_stream << " MIN " << min_count-1;
            temp_stream << " MAX " << max_count-1;
            temp_stream << " BEGIN ";
          }
          // if it is a do-while loop all loop bounds xshoud be printed as is  
          else {
            if(has_min_count && min_count > 0) temp_stream << " MIN " << min_count;
            temp_stream << " MAX " << max_count;
            temp_stream << " END ";
          }          
          // End the loop annotation
          temp_stream << ";" << endl;
          
          // Remember that we have created a flow fact
          nr_of_ais_ffs++;
        }
      } // end for
    } // end if 

    if(first_loop_bound == false) temp_stream << endl;
  }

  // To make printout at first flow fact something special 
  bool first_flow_fact = true;

  // ---------------------------------
  // Print min node count bounds
  // ---------------------------------
  {
    for(std::map<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, std::vector<CFlowGraphNode *> >, int>::iterator vns2c = _vns_to_min_count.begin();
        vns2c != _vns_to_min_count.end(); ++vns2c){
      // Extract the label and the count
      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of = (*vns2c).first.first;
      std::vector<CFlowGraphNode *> alf_labels = (*vns2c).first.second;
      int min_count = (*vns2c).second;
      if(min_count == 0) continue;
 
      // Check if we should print using labels or not 
      bool has_C_labels = true;
      if(sl == NULL) has_C_labels = false;
      // If the valid_at_entry_of refers to a loop, we should check if
      // the header node exists on source map
      else if((valid_at_entry_of.second != NULL) && 
              !sl->GetSourceOfLabel(valid_at_entry_of.second->Name())) has_C_labels = false;
      else {
        for(std::vector<CFlowGraphNode *>::iterator alf_label = alf_labels.begin();
            alf_label != alf_labels.end(); alf_label++) {
          if(!sl->GetSourceOfLabelIfFirstInCLine((*alf_label)->Name())) {
            has_C_labels = false;
            break;
          }
        }
      }
      
      // Print the min flow fact to file
      if(sl == NULL || has_C_labels) {
        if(first_flow_fact) {
          temp_stream << "# Flow constraints" << endl;
          first_flow_fact = false;
        }
        
        // Print as C level code ais annots
        temp_stream << "FLOW SUM ";
        for(std::vector<CFlowGraphNode *>::iterator alf_label = alf_labels.begin();
            alf_label != alf_labels.end(); /* Intentionally empty */ ) {
          temp_stream << "(\"" << GetCSourceNameFromLabel(sl, (*alf_label)->Name()) << "\")";
          alf_label++;
          if(alf_label != alf_labels.end())
            temp_stream << " + ";  
        }    
        temp_stream << " >= ";
        temp_stream << min_count;        
        // If the valid_at_entry_of refers to a function (i.e. not a loop) and the function is different
        // from the root node and we have min count larger than zero, then we should print some additional info.
        if((valid_at_entry_of.second == NULL) && 
           (_root_func_name != valid_at_entry_of.first->Name()) && 
           min_count != 0) {
          temp_stream << "(\"" << CSourceLoader::PrettifyFuncName(valid_at_entry_of.first->Name()) << "\")";
        }
        temp_stream << " ;" << endl;      
        
        // Remember that we have created a flow fact
        nr_of_ais_ffs++;
      }
    }
  }

  // ---------------------------------
  // Print max node count bounds
  // ---------------------------------
  {
    for(std::map<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, std::vector<CFlowGraphNode *> >, int>::iterator vns2c = _vns_to_max_count.begin();
      vns2c != _vns_to_max_count.end(); ++vns2c){
      // Extract the label and the count
      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of = (*vns2c).first.first;
      std::vector<CFlowGraphNode *> alf_labels = (*vns2c).first.second;
      int max_count = (*vns2c).second;

      // Check if we should print using labels or not 
      bool has_C_labels = true;
      if(sl == NULL) has_C_labels = false;
      // If the valid_at_entry_of refers to a loop, we should check if
      // the header node exists on source map
      else if((valid_at_entry_of.second != NULL) && 
              !sl->GetSourceOfLabel(valid_at_entry_of.second->Name())) has_C_labels = false;
      else {
        for(std::vector<CFlowGraphNode *>::iterator alf_label = alf_labels.begin();
            alf_label != alf_labels.end(); alf_label++) {
          if(!sl->GetSourceOfLabelIfFirstInCLine((*alf_label)->Name())) {
            has_C_labels = false;
            break;
          }
        }
      }
      
      // Print the max flow fact to file
      if(sl == NULL || has_C_labels) {
        if(first_flow_fact) {
          temp_stream << "# Flow constraints" << endl;
          first_flow_fact = false;
        }
        // Print as C level code ais annots
        temp_stream << "FLOW SUM ";
        for(std::vector<CFlowGraphNode *>::iterator alf_label = alf_labels.begin();
            alf_label != alf_labels.end(); /* Intentionally empty*/ ) {
          temp_stream << "(\"" << GetCSourceNameFromLabel(sl, (*alf_label)->Name()) << "\")";
          alf_label++;
          if(alf_label != alf_labels.end())
           temp_stream << " + ";  
        }    
        temp_stream << " <= ";        
        temp_stream << max_count;
        if((valid_at_entry_of.second == NULL) && 
           (_root_func_name != valid_at_entry_of.first->Name()) && 
           max_count != 0) {
          temp_stream << "(\"" << CSourceLoader::PrettifyFuncName(valid_at_entry_of.first->Name()) << "\")";
        }
        temp_stream << " ;" << endl;      
        
        // Remember that we have created a flow fact
        nr_of_ais_ffs++;
      }
    }
  }

  // ---------------------------------
  // Print equal to nodes 
  // ---------------------------------
  {
    for(std::set<std::pair<CFlowGraphNode *, CFlowGraphNode * > >::iterator np = _equal_to_nodes.begin();
        np != _equal_to_nodes.end(); ++np) {
      // Extract the node labels
      CFlowGraphNode * node1 = (*np).first;
      std::string alf_label1 = node1->Name();
      CFlowGraphNode * node2 = (*np).second;
      std::string alf_label2 = node2->Name();
      
      // Check if we should print using labels or not 
      bool has_C_labels = true;
      if(sl == NULL) 
        has_C_labels = false;
      else if(!sl->GetSourceOfLabelIfFirstInCLine(alf_label1) ||
              !sl->GetSourceOfLabelIfFirstInCLine(alf_label2))
        has_C_labels = false;

      // Print the max flow fact to file
      if(sl == NULL || has_C_labels) {
        if(first_flow_fact) {
          temp_stream << "# Flow constraints" << endl;
          first_flow_fact = false;
        }
        // Print as C level code ais annots
        temp_stream << "FLOW SUM ";
        temp_stream << "(\"" << GetCSourceNameFromLabel(sl, alf_label1) << "\") == ";
        temp_stream << "(\"" << GetCSourceNameFromLabel(sl, alf_label2) << "\") ;" << endl;
        // Remember that we have created a flow fact
        nr_of_ais_ffs++;
      }
    }
  }

  // ---------------------------------
  // Print possible function calls 
  // ---------------------------------
  {
    bool first_func_call = true;
    for(std::map<CFlowGraphNode *, std::set<CGenericFunction *> *>::iterator cs2fs = _call_site_to_called_funcs.begin();
        cs2fs != _call_site_to_called_funcs.end(); ++cs2fs) {
      CFlowGraphNode * call_node = (*cs2fs).first;
      { 
        // It might be the case that it has no stmt, since we might be running from a CFG
        if(call_node->Stmt()) {
          alf::CCallStmtTuple * call_stmt = dynamic_cast<alf::CCallStmtTuple *>(call_node->Stmt());
          // If it is a normal function call, i.e. no func pointers are
          // used, no call info should be generated
          if(call_stmt != NULL && 
             call_stmt->GetLabelExpr()->IsType(alf::CGenericNode::TYPE_LABEL_TUPLE))
            continue;
        }
      }

      // Else, we should try to generate func pointer call info
      std::string alf_label = call_node->GetBeginNodeOfNodesBasicBlock()->Name();
      std::set<CGenericFunction *> * called_funcs = (*cs2fs).second;
      
      // Print the ais calls flow fact
      if(sl == NULL || sl->GetSourceOfLabelIfFirstInCLine(alf_label)) {
        if(first_func_call) {
          temp_stream << endl << "# Function calls" << endl;
          first_func_call = false;
        }        
        temp_stream << "INSTRUCTION \"" << GetCSourceNameFromLabel(sl, alf_label) << "\" CALLS ";
        for(std::set<CGenericFunction *>::iterator func = called_funcs->begin();
            func != called_funcs->end(); ++func) {
          std::string called_func_name = (*func)->Name();
          temp_stream << "\"" << CSourceLoader::PrettifyFuncName(called_func_name) << "\" ";
        }
        temp_stream << "; " << endl;

        // Remember that we have created a flow fact
        nr_of_ais_ffs++;

      } // end if
    } // end 
  }

  if(first_flow_fact == false) temp_stream << endl;

  // If we generated some flow facts we should write the result to file, otherwise not
  if(nr_of_ais_ffs > 0) {
    out_stream << temp_stream.str();
  }

  // Return the number of flow facts created 
  return nr_of_ais_ffs;
}

// Help function for converting lower and upper node bounds flow facts
// to aiS flow facts
void
UpdateAisIntermediateWithContextSensitiveValidAtEntryOfFlowFacts(const std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs, 
                                                                 AisIntermediate * ais)
{
  // Go through all flow facts
  for(std::vector<CContextSensitiveValidAtEntryOfFlowFact *>::const_iterator ff = ffs->begin();
      ff != ffs->end(); ++ff) {

    // To avoind unneccessary processing
    if(!(*ff)->IsZeroContextSensitive()) continue;

    CFlowFact::t_flowfacttype type = (*ff)->Type();

    // ---------------------------------
    // Check if we have a local min or max loop header bound
    // ---------------------------------
    if(((type == CFlowFact::LHSS) || (type == CFlowFact::UHSS)) && (*ff)->IsValidAtEntryOfLoop()) {
      CGenericStmt * valid_at_entry_of_stmt = (*ff)->ValidAtEntryOf()->second;
      std::string valid_at_entry_of = valid_at_entry_of_stmt->Name();
      CConstraint * constr = (*ff)->Constraint();
      assert(constr->GetLeftExpression());
      assert(constr->GetLeftExpression()->Type() == ETYPE_CFG_NODE);
      CExpressionFlowGraphNode *lhs = dynamic_cast<CExpressionFlowGraphNode*>(constr->GetLeftExpression());
      // std::string bb = GetAlfLabelFromExprId(lhs->Node()->Name());
      CFlowGraphNode * bb = const_cast<CFlowGraphNode *>(lhs->Node());
      assert(bb->Name() == valid_at_entry_of);
      assert(lhs); 
      CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
      int count = rhs->Value();
      assert(rhs);
      t_relop relop = constr->GetOperator();
      if(relop == RELOP_LTEQ) {
        // We have #BB <= count, i.e. an upper loop bound
        ais->AddLoopHeaderLocalMaxCount(bb, count);
      }
      else if(relop == RELOP_GTEQ) {
        // We have #BB >= count, i.e. a lower loop bound
        ais->AddLoopHeaderLocalMinCount(bb, count);
      }
    }

    // ---------------------------------
    // Check if we have a lower or upper loop begin edge bound
    // ---------------------------------
    else if(((type == CFlowFact::LBNS) || (type == CFlowFact::UBNS)) && (*ff)->IsValidAtEntryOfLoop()) {
      // Derive the loop header node by first deriving the from node and 
      CConstraint * constr = (*ff)->Constraint();
      CExpression * expr = constr->GetLeftExpression();
      while(expr->Type() == ETYPE_BINOP) {
        expr = (dynamic_cast<CExpressionBin *>(expr))->GetLeftExpression();
      }
      assert(expr->Type() == ETYPE_CFG_EDGE);
      CExpressionFlowGraphEdge *edge_expr = dynamic_cast<CExpressionFlowGraphEdge*>(expr);
      CFlowGraphNode * from_node = edge_expr->FromNode();
      CFlowGraphNode * header = from_node->GetBeginNodeOfNodesBasicBlock();
      // Get the count from the right expression
      CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
      int count = rhs->Value();
      assert(rhs);
      t_relop relop = constr->GetOperator();
      if(relop == RELOP_LTEQ) {
        // We have #BB <= count, i.e. an upper loop body bound
        ais->AddLoopBodyLocalMaxCount(header, count);
      }
      else if(relop == RELOP_GTEQ) {
        // We have #BB >= count, i.e. a lower loop body bound
        ais->AddLoopBodyLocalMinCount(header, count);
      }
    }

    // ---------------------------------
    // Check if we have a lower or upper node bound
    // ---------------------------------
    else if(((type == CFlowFact::LHSF) || (type == CFlowFact::LHSP) || 
             (type == CFlowFact::LNSF) || (type == CFlowFact::LNSP) ||
             (type == CFlowFact::UHSF) || (type == CFlowFact::UHSP) || 
             (type == CFlowFact::UNSF) || (type == CFlowFact::UNSP) ||
             // (type == CFlowFact::UNSS) || (type == CFlowFact::LNSS) ||
             // (type == CFlowFact::UHSS) || (type == CFlowFact::LHSS) ||
             (type == CFlowFact::INSA))) {
      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of = 
        std::make_pair((*ff)->ValidAtEntryOf()->first, (*ff)->ValidAtEntryOf()->second);
      CConstraint * constr = (*ff)->Constraint();
      assert(constr->GetLeftExpression());
      assert(constr->GetLeftExpression()->Type() == ETYPE_CFG_NODE);
      CExpressionFlowGraphNode *lhs = dynamic_cast<CExpressionFlowGraphNode*>(constr->GetLeftExpression());
      std::vector<CFlowGraphNode *> node_vec;
      node_vec.push_back(const_cast<CFlowGraphNode *>(lhs->Node()));
      assert(lhs); 
      CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
      int count = rhs->Value();
      assert(rhs);
      t_relop relop = constr->GetOperator();
      if(relop == RELOP_LTEQ) {
        // We have #BB <= count, i.e. an upper bound
        ais->AddNodeSumMaxCount(valid_at_entry_of, node_vec, count);
      }
      else if(relop == RELOP_GTEQ) {
        // We have #BB >= count, i.e. a lower bound
        ais->AddNodeSumMinCount(valid_at_entry_of, node_vec, count);
      }
      else if(relop == RELOP_EQ && count == 0 && type == CFlowFact::INSA) {
        // We have a <> : #BB = 0 flow fact
        ais->AddNodeSumMaxCount(valid_at_entry_of, node_vec, count);
        ais->AddNodeSumMinCount(valid_at_entry_of, node_vec, count);
      }
      else if(relop == RELOP_EQ && type != CFlowFact::INSA) {
        // We have a [] : #BB = count flow fact
        ais->AddNodeSumMaxCount(valid_at_entry_of, node_vec, count);
        ais->AddNodeSumMinCount(valid_at_entry_of, node_vec, count);
      }
    }

    // ---------------------------------
    // Check if we have a lower or upper node pair bound
    // ---------------------------------
    else if(((type == CFlowFact::LNPF) || (type == CFlowFact::LNPP) ||
             (type == CFlowFact::UNPF) || (type == CFlowFact::UNPP) ||
             (type == CFlowFact::LHPF) || (type == CFlowFact::LHPP) ||
             (type == CFlowFact::UHPF) || (type == CFlowFact::UHPP))) {
      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of = 
        std::make_pair((*ff)->ValidAtEntryOf()->first, (*ff)->ValidAtEntryOf()->second);
      CConstraint * constr = (*ff)->Constraint();
      CExpressionBin *lhs = dynamic_cast<CExpressionBin*>(constr->GetLeftExpression());
      std::vector<CFlowGraphNode *> node_vec;
      GetNodesInExprIntoVector(lhs, &node_vec);
      CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
      int count = rhs->Value();
      assert(rhs);
      t_relop relop = constr->GetOperator();
      if(relop == RELOP_LTEQ) {
        // We have #BB + #BB <= count, i.e. an upper bound
        ais->AddNodeSumMaxCount(valid_at_entry_of, node_vec, count);
      }
      else if(relop == RELOP_GTEQ) {
        // We have #BB + #BB >= count, i.e. a lower bound
        ais->AddNodeSumMinCount(valid_at_entry_of, node_vec, count);
      } 
      else if(relop == RELOP_EQ) {
        // We have #BB + #BB == count, i.e. both a lower and an upper bound
        ais->AddNodeSumMinCount(valid_at_entry_of, node_vec, count);
        ais->AddNodeSumMaxCount(valid_at_entry_of, node_vec, count);
      }
    }
    // ---------------------------------
    // Check if we have a lower or upper node path bound
    // ---------------------------------
    else if(type == CFlowFact::INNA) {
      std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of = 
        std::make_pair((*ff)->ValidAtEntryOf()->first, (*ff)->ValidAtEntryOf()->second);
      CConstraint * constr = (*ff)->Constraint();
      CExpressionBin *lhs = dynamic_cast<CExpressionBin*>(constr->GetLeftExpression());
      std::vector<CFlowGraphNode *> node_vec;
      GetNodesInExprIntoVector(lhs, &node_vec);
      CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
      int count = rhs->Value();
      assert(rhs);
      t_relop relop = constr->GetOperator();
      if(relop == RELOP_LTEQ) {
        // We have #BB + #BB + .. + #BB <= count, i.e. an upper bound
        ais->AddNodeSumMaxCount(valid_at_entry_of, node_vec, count);
      }
      else if(relop == RELOP_GTEQ) {
        // We have #BB + #BB + .. + #BB >= count, i.e. a lower bound
        ais->AddNodeSumMinCount(valid_at_entry_of, node_vec, count);
      } 
      else if(relop == RELOP_EQ) {
        // We have #BB + #BB + .. + #BB == count, i.e. both a lower and upper bound
        ais->AddNodeSumMinCount(valid_at_entry_of, node_vec, count);
        ais->AddNodeSumMaxCount(valid_at_entry_of, node_vec, count);
      }
    }
    // ---------------------------------
    // Check if we have two nodes that always are taken the same amount of times 
    // ---------------------------------
    else if(type == CFlowFact::INPA2) {
      CConstraint * constr = (*ff)->Constraint();
      assert(constr->GetLeftExpression()->Type() == ETYPE_CFG_NODE);
      assert(constr->GetRightExpression()->Type() == ETYPE_CFG_NODE);
      CExpressionFlowGraphNode *lhs = dynamic_cast<CExpressionFlowGraphNode*>(constr->GetLeftExpression());
      CExpressionFlowGraphNode *rhs = dynamic_cast<CExpressionFlowGraphNode*>(constr->GetRightExpression());
      assert(constr->GetOperator() == RELOP_EQ);
      ais->AddEqualTo(const_cast<CFlowGraphNode *>(lhs->Node()), const_cast<CFlowGraphNode *>(rhs->Node())); 
    }

    // ---------------------------------
    // Check if we have information on call edges
    // ---------------------------------
    else if(type == CFlowFact::UCSF || type == CFlowFact::UCSP) {
      // Derive the from and to nodes in the call edge
      CConstraint * constr = (*ff)->Constraint();
      assert(constr->GetLeftExpression());
      assert(constr->GetLeftExpression()->Type() == ETYPE_CFG_EDGE);
      CExpressionFlowGraphEdge *lhs = dynamic_cast<CExpressionFlowGraphEdge*>(constr->GetLeftExpression());
      CFlowGraphNode * call_site = lhs->FromNode();
      CGenericFunction * called_func = lhs->ToNode()->FlowGraph()->Function();
      // Derive the count and the operation
      CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
      assert(rhs);
      int count = rhs->Value();
      t_relop relop = constr->GetOperator();
      if(relop == RELOP_LTEQ && count > 0) {
        // We have #BB->BB >= count, i.e. an upper call-edge count larger than zero
        ais->AddFuncCallFromCallSite(call_site, called_func);
      }   
    }

    else {
    // skip remaining ffs
    }

  } // end for all ffs

}

// To convert an expr id to a alf label, i.e. we remove the # in the
// beginning of the id.
std::string
GetAlfLabelFromExprId(std::string expr_id)
{
  // Remove the # in the beginning of the string
  if(expr_id[0] == '#')
    return expr_id.substr(1);
  else
    return expr_id;
}

       
// Help function to get all alf label names in a larger expression in a vector
void
GetNodesInExprIntoVector(const CExpression * expr, std::vector<CFlowGraphNode *> * vec)
{
  switch(expr->Type()) {
  case ETYPE_CFG_NODE: {
    // We found an expr holding a label, store in the vector
    const CExpressionFlowGraphNode *id_expr = dynamic_cast<const CExpressionFlowGraphNode*>(expr);
    vec->push_back(const_cast<CFlowGraphNode *>(id_expr->Node()));
    break;
  }
  case ETYPE_BINOP: {
    // We found a expr1 + expr2 expression, go thuough subparts recursively
    const CExpressionBin *bin_expr = dynamic_cast<const CExpressionBin*>(expr);
    assert(bin_expr->GetOperator() == BINOP_ADD);
    const CExpression *lhs = dynamic_cast<const CExpression*>(bin_expr->GetLeftExpression());
    const CExpression *rhs = dynamic_cast<const CExpression*>(bin_expr->GetRightExpression());
      // Do a recursive call on both sub exprs 
    GetNodesInExprIntoVector(lhs, vec);
    GetNodesInExprIntoVector(rhs, vec);
    break;
    }
  default: {
    // we should not be able to get here
    assert(0);
  }
  }
  // Return, the vector has been updated
  return;
}    


