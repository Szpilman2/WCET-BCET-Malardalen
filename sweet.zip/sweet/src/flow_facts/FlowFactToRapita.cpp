#include "FlowFactToRapita.h"
#include "CFlowFact.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/cfg/CFlowGraph.h"
// #include "graphs/components/CComponent.h"
// #include "graphs/components/CComponentTree.h"
#include "CExpression.h"
#include "tools/CSourceLoader.h"
#include "tools/CAlfLabelSource.h"
#include "CIndexRange.h"
#include "CContextSensitiveValidAtEntryOfFlowFact.h"
#include "program/CGenericFunction.h"
#include <algorithm>
#include <cassert>

using namespace std;

typedef class CAlfLabelSource CodePoint;

static int GetBound(CContextSensitiveValidAtEntryOfFlowFact *ff);

/// ////////////////////////////////////////////////////////////////////////////
/// \class RapitaLoop
///     Represents one loop
/// ////////////////////////////////////////////////////////////////////////////

void
RapitaLoop::
Print(string (*Unmangle)(string), ostream &o)
{
   o << "#pragma RPT [" << src->GetFileName() << ":" << Unmangle(function->Name());
   o << "@L" << sequence_number << "] loop_max_iter(" << upper_bound << ");" << endl;
}

void
RapitaLoop::
AssignBound(int ub)
{
   upper_bound += ub;
}

/// Computes the first available source code point in the body of a loop (excluding nested loops).
/// \return The code point with the smallest line number or NULL if no source information was
///   available for the concerned piece of code
/// \param loop A pointer to the component (e.g. representing a loop) to investigate
/// \param source_loader A lookup table for node names ("labels") to line numbers.
const CodePoint *
RapitaLoop::
FirstCodePoint(CComponent<CFlowGraphNode> *loop, CSourceLoader *source_loader) const
{
   const CodePoint *so_far_smallest = NULL;
   for (CComponent<CFlowGraphNode>::subnode_iterator node_it=loop->SubNodeBegin(); node_it!=loop->SubNodeEnd(); ++node_it) {
      CFlowGraphNode *cfg_node = *node_it;
      const CodePoint *new_candidate = source_loader->GetSourceOfLabel(cfg_node->Name());
      if (new_candidate) {
         if (so_far_smallest) {
            if (new_candidate->GetLineNumber() < so_far_smallest->GetLineNumber()) {
               so_far_smallest = new_candidate;
            }
         } else {
            so_far_smallest = new_candidate;
         }
      }
   }
   return so_far_smallest;
}

unsigned 
RapitaLoop::
GetSourceLine() const 
{ 
  if (src) 
    return src->GetLineNumber(); 
  else 
    return 0; 
}


/// ////////////////////////////////////////////////////////////////////////////
/// \class SortedRapitaLoops
///     Represents a set of loops sorted based on their occurrance in the source code.
/// ////////////////////////////////////////////////////////////////////////////
class SortedRapitaLoops
{
public:
   SortedRapitaLoops() :
      loops(vector<RapitaLoop*>()),
      src(NULL) { }

   /// Add a loop to this sorted set at the end.
   /// \param loop The loop to add.
   /// \pre There exists no other loops between this set and the one to add.
   /// \pre This set of loop is sorted.
   /// \pre There exists no other loops between the first and last of this set than those included in the set.
   /// \post This set is extended by one loop and the precondition is maintained.
   void Add(RapitaLoop *loop) { loops.push_back(loop); src = loop->GetCodePoint(); }

   /// Concatenates another set of sorted loops to this sorted set of loops.
   /// \param loops The loops to concatenate.
   /// \pre There exists no other loops between the two sets.
   /// \pre The following holds for both sets: \n
   ///      - The set of loops is sorted \n
   ///      - There exists no other loops between the first and last of the set than those included in the set.\n
   /// \post The precondition is maintained
   void Merge(SortedRapitaLoops other_loops) { loops.insert(loops.end(), other_loops.loops.begin(), other_loops.loops.end()); }

   // Returns various data concerning this sorted loop set
   unsigned GetSourceLine() const { if (src) return src->GetLineNumber(); else return 0; }
   const vector <RapitaLoop*> &GetLoopList() const { return loops; }
   const CodePoint *GetCodePoint() const { return src; }

private:
   vector <RapitaLoop*> loops;
   const CodePoint *src;
};


/// ////////////////////////////////////////////////////////////////////////////
/// RapitaLoops - Represents a set of loops where each loop is associated with a label
/// ////////////////////////////////////////////////////////////////////////////
void
RapitaLoops::
AssignBoundsToLoops(map<const CFlowGraphNode*, vector<CContextSensitiveValidAtEntryOfFlowFact *> > &rffs)
{
   for (map<const CFlowGraphNode*, vector<CContextSensitiveValidAtEntryOfFlowFact *> >::iterator hit=rffs.begin();
        hit!=rffs.end(); ++hit)
   {
      const CFlowGraphNode *header_node = hit->first;
      vector<CContextSensitiveValidAtEntryOfFlowFact *> &header_facts = hit->second;
      map <string, RapitaLoop*>::iterator loop_it = label_to_loop.find(header_node->Name());
      if (loop_it != label_to_loop.end())
      {
         RapitaLoop *loop = loop_it->second;
         for(unsigned i=0; i<header_facts.size(); ++i)
         {
            CContextSensitiveValidAtEntryOfFlowFact *ff=header_facts[i];
            loop->AssignBound(GetBound(ff));
         }
      }
   }
}

// void
// RapitaLoops::
// GetAlfLabelToLoopIndex(std::map<std::string, unsigned int> * alf_label_to_loop_index)
// {
//   for(map <string, Loop*>::iterator loop_it = label_to_loop.begin();
//       loop_it != label_to_loop.end(): ++loop_it) {
//     (*alf_label_to_loop_index)[(*loop_it).first] = (*loop_it).second->GetSequenceNumber();
//   }
// }

void
RapitaLoops::
AddLoops(SortedRapitaLoops &loops)
{
   const vector<RapitaLoop*> &loop_list = loops.GetLoopList();
   // Note that the first element in the list is not a loop, the origin of this is the
   // root of the component tree, which is always representing a function
   for (unsigned i=1; i<loop_list.size(); ++i)
   {
      RapitaLoop *loop = loop_list[i];
      label_to_loop[loop->GetComponent()->Head()->Name()] = loop;
   }
}

void
RapitaLoops::
Print(string (*Unmangle)(string), ostream &o)
{
   for (map <string, RapitaLoop*>::iterator loop_it=label_to_loop.begin(); loop_it!=label_to_loop.end(); ++loop_it)
   {
      RapitaLoop *loop = loop_it->second;
      loop->Print(Unmangle, o);
   }
}

const RapitaLoop *
RapitaLoops::
GetRapitaLoopOfAlfLabel(std::string alf_label)
{
  std::map<std::string, RapitaLoop*>::iterator l2rl = label_to_loop.find(alf_label);
  if(l2rl == label_to_loop.end())
    return NULL;
  else
    return (*l2rl).second;
}

/// ////////////////////////////////////////////////////////////////////////////
/// Help functions
/// ////////////////////////////////////////////////////////////////////////////

/// Flatterns a loop tree into a sorted list. The loops will be sorted in the textual order
/// they appear in the C-souce code. If the order of a sequence of siblings somewhere in
/// the tree can not be determined, then they are omitted from the flatternd list, and
/// their parent will hold the number of dropped loops.\n
/// Note that if \a root is in the first level of recursion is the root of a component
/// tree, then it represents a function rather than a loop, nevertheless it will be
/// included in the list.
/// \param root The root of the loop tree to process.
/// \param source_loader A table where to lookup the line numbers of the node "labels" (names).
/// \param loops A list of sorted loops. A loop enclosing one or more kids are considered
///   being before its enclosed loops. A sequence of loops (enclosed in a "component" (loop)) one loop
///   is before another if its smallest line number is smaller than the smallest of the other.
///   However, if, in a sequence of several loops, there is one kid that entirely lacks line numbers,
///   then we have no complete information about the ordering between them, so we have to drop
///   them all.
static void
CreateSortedRapitaLoops(CComponent<CFlowGraphNode> *root, CSourceLoader *source_loader, 
                        SortedRapitaLoops &loops)
{
   RapitaLoop *current_loop;
   current_loop = new RapitaLoop(root, source_loader);
   loops.Add(current_loop); // We are before all kids

   if (root->KidsSize() > 0)
   {
      // Collect the kids in an ordered set
      map <unsigned, SortedRapitaLoops> sorted_sub_loops;
      for (CComponent <CFlowGraphNode>::kid_iterator kid_it=root->KidBegin(); kid_it!=root->KidEnd(); ++kid_it)
      {
         SortedRapitaLoops sub_loops;
         CreateSortedRapitaLoops(kid_it->node, source_loader, sub_loops);
         sorted_sub_loops[sub_loops.GetSourceLine()] = sub_loops;
      }

      {
         // In case the current loop lacks references to the source we may be able to
         // relate it to its siblings in the tree (higher up in the recursion) if we
         // just let it inherit a proper reference from one its descendants. So if
         // that is the case we try to find such a reference here.
         if (current_loop && current_loop->GetSourceLine() == 0)
         {
            map <unsigned, SortedRapitaLoops>::iterator it = sorted_sub_loops.begin();
            unsigned source_line = it->first;
            if (source_line == 0)
            {
               it++;
               if (it != sorted_sub_loops.end())
                  source_line = it->first;
            }
            if (source_line != 0)
            {
               current_loop->AssignCodePoint(it->second.GetCodePoint());
            }
         }
      }

      {
         // Merge each flatterned sub loop tree into the main list This is not
         // always feasible: if at least one of several sub loops entirely
         // lacks source information then we can not relate them to each other
         map <unsigned, SortedRapitaLoops>::iterator it = sorted_sub_loops.begin();
         unsigned first_line_number = it->first;
         SortedRapitaLoops sub_loops = it->second;
         if (first_line_number == 0)
         {
            // Then there were no known code points in this sub loop tree (line numbers are always > 0)
            if (root->KidsSize() == 1) // Special case: we can relate this single sub loop to the current one
               loops.Merge(sub_loops);
            else // We have to drop all the sub loops
               current_loop->AssignNrOfDroppedSubLoops(root->NumberOfDescendants());
         }
         else
         {
            // Normal case, we merge them all.
            do
            {
               loops.Merge(it->second);
               ++it;
            } while(it != sorted_sub_loops.end());
         }
      }
   }
}

static void
AssignSequenceNumbersToLoops(SortedRapitaLoops &loops)
{
   const vector <RapitaLoop*> &loop_list = loops.GetLoopList();
   unsigned sequence_number = 1;
   for (unsigned i=1; i<loop_list.size(); ++i)
   {
      RapitaLoop *loop = loop_list[i];
      loop->AssignSequenceNumber(sequence_number);
      ++sequence_number;
      sequence_number += loop->GetNrOfDroppedSubLoops();
   }
}

static void
AssignFunctions(SortedRapitaLoops &loops, CGenericFunction *function)
{
   const vector <RapitaLoop*> &loop_list = loops.GetLoopList();
   for (unsigned i=0; i<loop_list.size(); ++i)
   {
      RapitaLoop *loop = loop_list[i];
      loop->AssignFunction(function);
   }
}

/// Computes the upper bound of a flow fact
/// \pre The operator of the fact is either of <, <= or ==
static int
GetBound(CContextSensitiveValidAtEntryOfFlowFact *ff)
{
   CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(ff->Constraint()->GetRightExpression());
   assert(rhs);
   int count = rhs->Value();
   t_relop relop = ff->Constraint()->GetOperator();
   switch (relop)
   {
      case RELOP_LT:
         count--;
      break;
      case RELOP_LTEQ:
      break;
      case RELOP_GT:
      case RELOP_GTEQ:
      case RELOP_NEQ:
         // These will never occur.
      break;
      case RELOP_EQ:
      break;
   }
   return count;
}

static void
ExtractRapitaFacts(vector<CContextSensitiveValidAtEntryOfFlowFact *> &ffs, 
                   map<const CFlowGraphNode*, vector<CContextSensitiveValidAtEntryOfFlowFact *> > &rffs)
{
   for(unsigned i=0; i<ffs.size(); ++i)
   {
      CContextSensitiveValidAtEntryOfFlowFact *ff=ffs[i];
      if (ff->Type() == CFlowFact::UBNS)
      {
         if (ff->IsValidAtEntryOfFunction())
         {
            CExpressionFlowGraphEdge *lhs = dynamic_cast<CExpressionFlowGraphEdge*>(ff->Constraint()->GetLeftExpression());
            assert(lhs);
            const CFlowGraphNode *header_node = lhs->FromNode();
            if (header_node->Name()[0] != '*') 
               rffs[header_node].push_back(ff);
         }
      }
   }
}

void
CollectRapitaLoops(const vector<CFlowGraph*> &flow_graphs,
                   CSourceLoader *source_loader, RapitaLoops &rapita_loops,
                   vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs)
{
   {
      // For each function:
      //  - Flattern its loop tree in a way that the loops is put in the same order as they appear in the source
      //  - Assign sequence numbers and functions to the loops
      //  - Insert the loops into the mapping from its header nodes.
      for (unsigned i=0; i<flow_graphs.size(); ++i) {
         CFlowGraph *flow_graph = flow_graphs[i];
         CComponentTree <CFlowGraphNode> *component_tree = flow_graph->ComponentTree();
         SortedRapitaLoops loops;
         CreateSortedRapitaLoops(component_tree->TreeRoot(), source_loader, loops);
         AssignSequenceNumbersToLoops(loops);
         AssignFunctions(loops, flow_graph->Function());
         rapita_loops.AddLoops(loops);
      }
   }

   {

     if(ffs != NULL) {
       // Extract the facts that are relevant for rapita, and then assign them to the loops
       map<const CFlowGraphNode*, vector<CContextSensitiveValidAtEntryOfFlowFact *> > rffs;
       ExtractRapitaFacts(*ffs, rffs);
       rapita_loops.AssignBoundsToLoops(rffs);
     }
   }
}



        
               

// Traverse all CFGs in file. For each CFG we extract all the CFG nodes.
// We sort the CFG nodes based on (1) their C source line number (2) their C column number. 
// This is most easily done by using a key index in a map consisting of pair<LineNumber,ColumnNumber>
// We can thenm just traverse the map in order to assign an index to the corresponding alf label.
// The result becomes a map from alf_label to an index. map<string,unsigned int> 
// _call_stmt_label_to_index and _bb_label_to_index.
// The source loader keeps mapping from alf_label to structure (CAlfLabelSource) 
// holding line number, column number and file. 
 
        
