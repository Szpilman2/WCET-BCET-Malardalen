// $Id $

#ifndef AIS_INTERMEDIATE_H_INLUDED
#define AIS_INTERMEDIATE_H_INLUDED

#include <vector>
#include <map>
#include <set>
#include <string>
#include <utility>

#include "tools/CSourceLoader.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "flow_facts/CContextSensitiveValidAtEntryOfFlowFact.h"

// -------------------------------------------------------
// Class that collects information from a a number of generated 
// context-sensitive valid-at-entry-of flow facts and produces
// aiS flow facts. Will optionally translate used ALF labels 
// to C source code labels in generated Ais FFs.
// -------------------------------------------------------
class AisIntermediate
{
public:

  // No arguments to create and delete
  AisIntermediate(std::string root_func_name, bool ffs_based_on_traces=false);
  ~AisIntermediate();

 // Enum holding the type of loop bounds that can be generated
  typedef enum { BEGIN, END, UNKNOWN } t_loop_bound;

  // Add information to generate local loop bounds on aiS format. 
  // Format: LOOP <pgm_point> <begin/end/unknown> MIN i MAX j
  // Should be generated using ffg=lhss and zero context-sensitivity (-c l=0)
  void AddLoopHeaderLocalMinCount(CFlowGraphNode * loop_header, int count);
  // Should be generated using ffg=lhss or ffg=uhss and zero
  // context-sensitivity (-c l=0)
  void AddLoopHeaderLocalMaxCount(CFlowGraphNode * loop_header, int count);

  // Add information to generate local loop bounds on aiS format. 
  // Format: LOOP <pgm_point> <begin/end/unknown> MIN i MAX j
  // Should be generated using ffg=lhss and zero context-sensitivity (-c l=0)
  void AddLoopBodyLocalMinCount(CFlowGraphNode * loop_header, int count);
  // Should be generated using ffg=lhss or ffg=uhss and zero
  // context-sensitivity (-c l=0)
  void AddLoopBodyLocalMaxCount(CFlowGraphNode * loop_header, int count);

  // Add information to generate lower node bounds on aiS format.
  // Comes from:  : valid_at_entry_of : #BB1 + #BB2 + ... + #BBN <= count 
  // Format: FLOW SUM count ("valid_at_entry_of") >= ("node1") + ... +  ("nodeN")
  void AddNodeSumMinCount(std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of, std::vector<CFlowGraphNode *> nodes_to_sum, int min_count);
  // Add information to generate upper node bounds on aiS format.
  // Comes from:  : valid_at_entry_of : #BB1 + #BB2 + ... + #BBN >= count 
  // Format: FLOW SUM count ("valid_at_entry_of") <= ("node1") + ... +  ("nodeN")
  void AddNodeSumMaxCount(std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of, std::vector<CFlowGraphNode *> nodes_to_sum, int max_count);

  // Add information to generate lower node bounds on aiS format.
  // Comes from:  : <> : #BB1 == #BB2  
  // Format: FLOW SUM ("node1") == ("nodeN")
  void AddEqualTo(CFlowGraphNode * node1, CFlowGraphNode * node2);

  // Add information about called functions from a node
  // Format: INSTRUCTION <alf_label> CALLS "<func_name1>" "<func_name2>" ;
  // Should be generated using ffg=lcsf,lcsp and zero context-sensitivity.
  // All edges having an upper exec count may be called from the call-site.
  void AddFuncCallFromCallSite(CFlowGraphNode * call_site, CGenericFunction * called_func);

  // To print the generated flow facts. If sl == NULL then that given
  // alf labels will be used in the aiS ff printouts. Otherwise the
  // alf_labels will be translated to C source labels and
  // printed. Returns the number of flow facts generated.
  int PrintAsAisFlowFacts(std::ostream & out_stream, CSourceLoader * sl=NULL);

protected:

  // Help function to make pair of nodes. To make sure that nodes
  // always come in the sdameo order in the resulting pair
  // std::pair<std::string, std::string> MakeNodePair(std::string node1, std::string node2);

  // Help function to get c source name of label. If sl == NULL, alf_label will be returned.
  std::string GetCSourceNameFromLabel(CSourceLoader * sl, std::string alf_label);

  // To keep track of min and max header node local counts. The loop
  // is represented by the header node. The count is a local lower and
  // upper bound on the number of times the loop header can be taken
  std::map<CFlowGraphNode *, int> _loop_to_loop_header_local_min_count; 
  std::map<CFlowGraphNode *, int> _loop_to_loop_header_local_max_count;

  // To keep track of min and max loop body local counts. The loop is
  // represented by the header node. The count is a local lower and
  // upper bound on the number of times the loop body can be taken.
  std::map<CFlowGraphNode *, int> _loop_to_loop_body_local_min_count; 
  std::map<CFlowGraphNode *, int> _loop_to_loop_body_local_max_count; 

  // A mapping between <valid_at_entry, node_vector> and min and max counts
  std::map<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, std::vector<CFlowGraphNode *> >, int> _vns_to_min_count; 
  std::map<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, std::vector<CFlowGraphNode *> >, int> _vns_to_max_count; 

  // To keep track of nodes that are taken the same amount of times
  void AddNodePairToSet(CFlowGraphNode * node1, CFlowGraphNode * node2, 
                        std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> > & node_pair_set);
  std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> > _equal_to_nodes;

  // To keep track of the alf labels and functions referenced
  std::set<CFlowGraphNode *> _referred_nodes;
  std::set<CGenericFunction *> _referred_funcs;
  std::set<std::string> _referred_alf_labels;

  // Too keep track of root func name
  std::string _root_func_name;

  // To keep track on if ffs are based on traces
  bool _ffs_based_on_traces;

  // To keep track of possible function calls from a call site
  std::map<CFlowGraphNode *, std::set<CGenericFunction *> *> _call_site_to_called_funcs;
};



// Help function for traversing a set of generated context-sensitive
// valid-at-entry-of ffs and creating a number of aiS ffs.
void
UpdateAisIntermediateWithContextSensitiveValidAtEntryOfFlowFacts(const std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs, 
                                                                 AisIntermediate * ais_ir); 

// To get all alf label names in a larger summation expression in a vector.
// I.e. if the expression is a tree holding #BB1 + #BB2 + .. + #BBN we get 
// a <BB1, BB2, ..., BBN> vector.
void GetNodesInExprIntoVector(const CExpression * expr, std::vector<CFlowGraphNode *> * node_vec);

// Help function to convert an expr id to a alf label, i.e. we remove
// the # in the beginning of the id.
std::string 
GetAlfLabelFromExprId(std::string expr_id);

#endif


