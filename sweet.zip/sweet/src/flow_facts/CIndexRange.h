// $Id $

#ifndef CRANGE_H_
#define CRANGE_H_

#include <iostream>



class CIndexRange
{
private:
   bool _is_bottom;
   int _lb, _ub;
   
public:
   CIndexRange (void);
   CIndexRange (int lb, int ub);
   ~CIndexRange (void);

   int IsBottom() const;

   // Sets the values of the ranges
   int LowerBound(int lb);
   int UpperBound(int ub);

   // Extends the range so value is included
   void ExtendRange(int value);

   // Returns the values of the ranges
   int LowerBound(void) const;
   int UpperBound(void) const;

   bool operator < (const CIndexRange &theother) const;
   bool operator == (const CIndexRange &theother) const;
   friend std::ostream & operator << (std::ostream &o, const CIndexRange &r);
};

#endif
