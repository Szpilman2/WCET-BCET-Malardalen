#include "CContextSensitiveValidAtEntryOfFlowFact.h"
#include "program/CGenericFunction.h"
#include "program/CGenericStmt.h"
#include "CExpression.h"
#include "tools/RangeIterator.h"
#include <cassert>

using namespace std;

// -------------------------------------------------------
// -------------------------------------------------------
// CContextSensitiveValidAtEntryOfFlowFact
// -------------------------------------------------------
// -------------------------------------------------------

CContextSensitiveValidAtEntryOfFlowFact::
CContextSensitiveValidAtEntryOfFlowFact(std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > call_string,
                                        std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of, 
                                        CFFCollector * ffcollector, CConstraint * constraint,
                                        CFlowFact::t_flowfacttype ff_type)
  : _call_string(call_string), _valid_at_entry_of(valid_at_entry_of), _ffcollector(ffcollector), 
    _constraint(constraint), _ff_type(ff_type)
{
  // Do nothing
}

CContextSensitiveValidAtEntryOfFlowFact::
~CContextSensitiveValidAtEntryOfFlowFact()
{
  delete _ffcollector;
  delete _constraint;
}


// Function to check if a ff is fully context-senstive. That is, if
// last element in call-string is equal to the first element in
// valid_at_entry_of, or if call-string is empty and cg_root_func
// is equal to first element in valid_at_entry_of.
bool
CContextSensitiveValidAtEntryOfFlowFact::
IsFullyContextSensitive(CGenericFunction * cg_root_func) const
{
  // Check if call-string is empty and cg_root_func is equal to first
  // element in valid_at_entry_of.
  if(_call_string.empty()) {
    if(_valid_at_entry_of.first == cg_root_func)
      return true;
    else
      return false;
  }
  else {
    // Check if last element in call-string is equal to the first
    // element in valid_at_entry_of
    if(_call_string.back().second == _valid_at_entry_of.first)
      return true;
    else
      return false;
  }
}

// Function to check if the flow fact is not context-sensitive at all.
// That is true if the call string is empty.
bool
CContextSensitiveValidAtEntryOfFlowFact::
IsZeroContextSensitive() const
{
  return _call_string.empty();
}

bool
CContextSensitiveValidAtEntryOfFlowFact::
IsValidAtEntryOfLoop() const
{
  return _valid_at_entry_of.second != NULL;
}

bool
CContextSensitiveValidAtEntryOfFlowFact::
IsValidAtEntryOfFunction() const
{
  return _valid_at_entry_of.second == NULL;
}


// void
// CContextSensitiveValidAtEntryOfFlowFact::
// ConvertToAndPrintAisFlowFact(std::ostream *o, CSourceLoader * sl)  
// {
//   // For flow facts of type lhss or uhss we can generate loop bounds.
//   // Also, the ff must be valid for each entry of a loop and has no 
//   // call string. 
//   if((_ff_type == CFlowFact::LHSS || _ff_type == CFlowFact::UHSS) &&
//      IsValidAtEntryOfLoop() && IsZeroContextSensitive()) 
//     {
//       // Get the label of the loop stmt
//       CGenericStmt * stmt = _valid_at_entry_of.second;
//       assert(stmt);
//       AStmt * astmt = dynamic_cast<AStmt *>(stmt);
//       CLabelTupel * label = astmt->GetLabel();
//       std::string bbid = label->AsBasicBlockId();

//       // Get the corresponding source code stuff
      

//       *o << "LOOP "

 

void
CContextSensitiveValidAtEntryOfFlowFact::
Print(std::ostream *o) 
{
   // Print the call string as call_site, call_site, ..., call_site, called_func 
   for (RangeIterator<const CallStringType> cs2f(_call_string); cs2f; ++cs2f) {
      *o << "((" << (*cs2f).first.first->Name() << ", "
         << (*cs2f).first.second->TryGetSourceString() << "), "
         << (*cs2f).second->Name() << ") ";
   }
   // Print a separator
   *o << ": ";
   // Print the valid at entry of
   if(_valid_at_entry_of.second) {
      // If loop scope, i.e. func and header node
      *o << "(" << _valid_at_entry_of.first->Name() << ", "
         << _valid_at_entry_of.second->TryGetSourceString() << ')';
   } else {
      // Just a function name
      *o << _valid_at_entry_of.first->Name();
   }
   // Print a separator
   *o << " : ";
   // Print the collector
   *o << *_ffcollector;
   // Print a separator
   *o << " : ";
   // Print the constraint
   *o << *_constraint;
   // Print a ff separator
   *o << " ;  ";
   // Print the type comment
   *o << _ff_type;
}
  
std::ostream & operator << (std::ostream &o, CContextSensitiveValidAtEntryOfFlowFact &ff)
{
  ff.Print(&o);
  return o;
}

  
