// $Id $
#include "CFlowFact.h"
#include "CConstraint.h"
#include "graphs/scopes/CScope.h"

using namespace std;

CFlowFact::CFlowFact(const CScope *s) : _s(s)
{
}

CFlowFact::CFlowFact(const CScope *s, const t_flowfacttype &t, const CFFCollector &collector, const CConstraint &constraint)
{
   _s = s;
   _type = t;
   _collector = collector;
   _constraint = constraint;
}

void CFlowFact::Copy(const CFlowFact &theother)
{
   _s = theother._s;
   _type = theother._type;
   _context = theother._context;
   _collector = theother._collector;
   _constraint = theother._constraint;
}

CFlowFact::~CFlowFact(void)
{
}

CFlowFact::CFlowFact(const CFlowFact &theother)
{
   Copy(theother);
}

CFlowFact::t_flowfacttype CFlowFact::Type(void) const
{
   return _type;
}

const CFFCollector *CFlowFact::Collector(void) const
{
   return &_collector;
}

const CConstraint *CFlowFact::Constraint(void) const
{
   return &_constraint;
}

bool CFlowFact::operator == (const CFlowFact &theother) const
{
   return _context == theother._context &&
          _collector == theother._collector && _constraint == theother._constraint;
}

bool CFlowFact::operator<(const CFlowFact &theother) const
{
   if (_s == theother. _s) //&& (_type == theother._type))
      if (_context == theother._context)
         return _constraint < theother._constraint;
      return _context < theother._context;
   return _s < theother. _s;
}

ostream & operator << (ostream &o, const CFlowFact &ff)
{
  o << ff._s->Name();
  o << " : ";
  o << ff._collector;
  o << " : ";
  o << ff._constraint << ";";
  o << ff._type;
   return o;
}


ostream & operator << (ostream &o, const CFlowFact::t_flowfacttype &ff_type)
{
  switch (ff_type) {

  // Headers
  case CFlowFact::UHSS: o << " %% uhss - Upper header bounds in scope context."; break; 
  case CFlowFact::LHSS: o << " %% lhss - Lower header bounds in scope context."; break; 
  case CFlowFact::UHSF: o << " %% uhsf - Upper header bounds in function context."; break;
  case CFlowFact::LHSF: o << " %% lhsf - Lower header bounds in function context."; break;
  case CFlowFact::UHSP: o << " %% uhsp - Upper header bounds in program context."; break; 
  case CFlowFact::LHSP: o << " %% lhsp - Lower header bounds in program context."; break; 

  // Header pairs
  case CFlowFact::UHPF: o << " %% uhpf - Upper bounds for header node pairs in function-context."; break; 
  case CFlowFact::LHPF: o << " %% lhpf - Lower bounds for header node pairs in function-context."; break; 
  case CFlowFact::UHPP: o << " %% uhpp - Upper bounds for header node pairs in program-context."; break; 
  case CFlowFact::LHPP: o << " %% lhpp - Lower bounds for header node pairs in program-context."; break; 

  // Nodes
  case CFlowFact::UNSS: o << " %% unss - Upper bounds for nodes in scope context."; break; 
  case CFlowFact::LNSS: o << " %% lnss - Lower bounds for nodes in scope context."; break; 
  case CFlowFact::UNSF: o << " %% unsf - Upper bounds for nodes in function context."; break; 
  case CFlowFact::LNSF: o << " %% lnsf - Lower bounds for nodes in function context."; break; 
  case CFlowFact::UNSP: o << " %% unsp - Upper bounds for nodes in program context."; break; 
  case CFlowFact::LNSP: o << " %% lnsp - Lower bounds for nodes in program context."; break; 
  case CFlowFact::INSE: o << " %% inse - Infeasible nodes (i.e. nodes never taken) for individual iterations of scope."; break; 
  case CFlowFact::INSA: o << " %% insa - Infeasible nodes (i.e. nodes never taken) for all iterations of scope."; break; 

  // Node pairs
  case CFlowFact::UNPS: o << " %% unps - Upper bounds for node pairs in scope-context."; break; 
  case CFlowFact::LNPS: o << " %% lnps - Lower bounds for node pairs in scope-context."; break; 
  case CFlowFact::UNPF: o << " %% unpf - Upper bounds for node pairs in function-context."; break; 
  case CFlowFact::LNPF: o << " %% lnpf - Lower bounds for node pairs in function-context."; break; 
  case CFlowFact::UNPP: o << " %% unpp - Upper bounds for node pairs in program-context."; break; 
  case CFlowFact::LNPP: o << " %% lnpp - Lower bounds for node pairs in program-context."; break; 
  case CFlowFact::INPA: o << " %% inpa - Infeasible node pairs (i.e. excluding ones) for all iterations of scope."; break; 
  case CFlowFact::INPA2: o << " %% inpa - Node pairs that must be taken together (either both are taken or none) for all iterations of scope."; break; 
  case CFlowFact::INNA: o << " %% inna - Infeasible node paths for all iterations of scope."; break; 

  case CFlowFact::UESS: o << " %% uess - Upper bounds for edges in scope-context."; break; 
  case CFlowFact::LESS: o << " %% less - Lower bounds for edges in scope-context."; break; 
  case CFlowFact::UESF: o << " %% uesf - Upper bounds for edges in function context."; break; 
  case CFlowFact::LESF: o << " %% lesf - Lower bounds for edges in function context."; break; 
  case CFlowFact::UESP: o << " %% uesp - Upper bounds for edges in program context."; break; 
  case CFlowFact::LESP: o << " %% lesp - Lower bounds for edges in program context."; break; 
  case CFlowFact::UCSF: o << " %% ucsf - Upper bounds for call edges in function context."; break; 
  case CFlowFact::LCSF: o << " %% lcsf - Lower bounds for call edges in function context."; break; 
  case CFlowFact::UCSP: o << " %% ucsp - Upper bounds for call edges in program context."; break; 
  case CFlowFact::LCSP: o << " %% lcsp - Lower bounds for call edges in program context."; break;
  case CFlowFact::UBNS: o << " %% ubss - Upper bounds for sum of loop body begin edges in scope-context."; break; 
  case CFlowFact::LBNS: o << " %% lbss - Lower bounds for sum of loop body begin edges in scope-context."; break;    
  
    // Not to be used
  case CFlowFact::IEPA: o << " %% iepa - Infeasible paths of edges for all iterations of scope."; break;
  case CFlowFact::FIX:  o << " %% Fix, corresponds to having a maximum iteration = 0"; break;  
  case CFlowFact::UNDEF: break;
     }
   return o;
}
