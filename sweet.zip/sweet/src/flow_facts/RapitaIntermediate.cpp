#include "flow_facts/RapitaIntermediate.h"
#include "program/CGenericStmt.h"
#include "program/CGenericFunction.h"
#include "program/alf/CGenericNode.h"
#include "program/alf/CCallStmtTuple.h"
#include "program/alf/AStmt.h"
#include "program/alf/AExpr.h"
#include "flow_facts/CExpression.h"
#include "flow_facts/CConstraint.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/cfg/CFlowGraph.h"
#include "graphs/components/CComponent.h"
#include "graphs/tools/Dominance.h"
#include "tools/CTextBlock.h"
#include <cassert>
#include <algorithm>
#include <iostream>
#include <sstream>

using namespace std;

RapitaIntermediate::
RapitaIntermediate(const std::vector<CFlowGraph*> * flow_graphs, CSourceLoader *source_loader, bool ffs_based_on_traces)
{
  _flow_graphs = flow_graphs;
  _source_loader = source_loader;
  _ffs_based_on_traces = ffs_based_on_traces;
  DeriveValidRapitaPathNodes(flow_graphs, &_valid_rapita_nodes);
}

RapitaIntermediate::
~RapitaIntermediate()
{
  // Delete all function call sets
  for(std::map<CFlowGraphNode *, std::set<CFlowGraphNode *> *>::iterator c2fs = _call_site_to_called_funcs.begin();
      c2fs != _call_site_to_called_funcs.end(); ++c2fs) {
    delete (*c2fs).second;
  }
  // Delete all temporary created c_source objects
  for(std::set<CAlfLabelSource *>::iterator als = _temp_c_sources.begin();
      als != _temp_c_sources.end(); ++als) {
    delete *als;
  }
}

// Add information about infeasible/dead code on Rapita format.
void 
RapitaIntermediate::
AddInfeasibleNode(CFlowGraphNode * node)
{
  // Call help function
  AddNodeToSet(node, _infeasible_nodes);
}

// Add information to generate upper local node bounds on Rapita format.
void 
RapitaIntermediate::
AddLocalNodeMaxCount(CFlowGraphNode * node, int count)
{
  // Call help function
  AddMaxCountForNodeToMap(node, count, _local_node_max_count);
}

// Add information about local exclusive nodes.
void
RapitaIntermediate::
AddLocalNodesOneOrNoneOf(CFlowGraphNode * node1, CFlowGraphNode * node2)
{
  AddNodePairToSet(node1, node2, _local_nodes_one_or_none_of);
}

// Add information to generate upper local loop header bounds on Rapita format.
void 
RapitaIntermediate::
AddLocalLoopHeaderMaxCount(CFlowGraphNode * node, int count)
{
  // Call help function
  AddMaxCountForNodeToMap(node, count, _local_loop_header_max_count);
}

// Add information to generate lower local loop header bounds on Rapita format.
void 
RapitaIntermediate::
AddLocalLoopHeaderMinCount(CFlowGraphNode * node, int count)
{
  // Call help function
  AddMinCountForNodeToMap(node, count, _local_loop_header_min_count);
}

// Add information to generate upper local loop header bounds on Rapita format.
void 
RapitaIntermediate::
AddLocalLoopBodyMaxCount(CFlowGraphNode * node, int count)
{
  // Call help function
  AddMaxCountForNodeToMap(node, count, _local_loop_body_max_count);
}

// Add information to generate lower local loop header bounds on Rapita format.
void 
RapitaIntermediate::
AddLocalLoopBodyMinCount(CFlowGraphNode * node, int count)
{
  // Call help function
  AddMinCountForNodeToMap(node, count, _local_loop_body_min_count);
}

// Add information about node taken locally at least once 
void 
RapitaIntermediate::
AddLocalNodeAtLeastOneOf(CFlowGraphNode * node)
{
  // Call help function
  AddNodeToSet(node, _local_node_at_least_one_of);
}

// Add information about node taken locally at least once 
void 
RapitaIntermediate::
AddLocalNodesAtLeastOneOf(CFlowGraphNode * node1, CFlowGraphNode * node2)
{
  // Call help function
  AddNodePairToSet(node1, node2, _local_nodes_at_least_one_of);
}

// Add information on nodes that must be taken togeher, or not at all,
// during each iteration of a scope.
void
RapitaIntermediate::
AddLocalNodesMustBeTakenTogether(CFlowGraphNode * node1, CFlowGraphNode * node2)
{
  // Call help function
  AddNodePairToSet(node1, node2, _local_nodes_must_be_taken_together);
} 

// Add information about nodes taken globally at least once.
void
RapitaIntermediate::
AddGlobalNodeAtLeastOneOf(CFlowGraphNode * node)
{
  // Call help function
  AddNodeToSet(node, _global_node_at_least_one_of);
}

// Add information about local exclusive nodes.
void
RapitaIntermediate::
AddGlobalNodesOneOrNoneOf(CFlowGraphNode * node1, CFlowGraphNode * node2)
{
  AddNodePairToSet(node1, node2, _global_nodes_one_or_none_of);
}

// Add information about called functions from a node
void
RapitaIntermediate::
AddFuncCallFromCallSite(CFlowGraphNode * call_site, CFlowGraphNode * called_node)
{
  // Create a set for the call site if needed
  if(_call_site_to_called_funcs.find(call_site) == _call_site_to_called_funcs.end())
    _call_site_to_called_funcs[call_site] = new std::set<CFlowGraphNode *>;
  // Add the called node to the set
  _call_site_to_called_funcs[call_site]->insert(called_node);

  // Remember the alf labels used
  _nodes_referred_to.insert(call_site);
  _nodes_referred_to.insert(call_site->GetBeginNodeOfNodesBasicBlock());
  _nodes_referred_to.insert(called_node);

}

// Help function for keeping track of max count derived for a certain node.
// Assumes that all counts are safe, i.e. will always chose the lowest count.
void 
RapitaIntermediate::
AddMaxCountForNodeToMap(CFlowGraphNode * node, int count, std::map<CFlowGraphNode *, int> & node_to_max_count)
{
  int new_count = count;
  
  if(node_to_max_count.find(node) != node_to_max_count.end()) {
    int old_count = node_to_max_count[node];
    if(old_count < count)
      new_count = old_count;
  }
  node_to_max_count[node] = new_count;

  // Remember the alf label used
  _nodes_referred_to.insert(node);
}

// Help function for keeping track of min count derived for a certain node.
// Assumes that all counts are safe, i.e. will always chose the largest count.
void 
RapitaIntermediate::
AddMinCountForNodeToMap(CFlowGraphNode * node, int count, std::map<CFlowGraphNode *, int> & node_to_min_count)
{
  int new_count = count;
  
  if(node_to_min_count.find(node) != node_to_min_count.end()) {
    int old_count = node_to_min_count[node];
    if(old_count > count)
      new_count = old_count;
  }
  node_to_min_count[node] = new_count;

  // Remember the alf label used
  _nodes_referred_to.insert(node);
}

// Help function for adding a node to a set
void 
RapitaIntermediate::
AddNodeToSet(CFlowGraphNode * node, std::set<CFlowGraphNode *> & node_set)
{
  // Add the node
  node_set.insert(node);

  // Remember the alf label used
  _nodes_referred_to.insert(node);
}


// Help function for adding a node pair to a set
void 
RapitaIntermediate::
AddNodePairToSet(CFlowGraphNode * node1, CFlowGraphNode * node2, 
                 std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> > & node_pair_set)
{
  // To avoid unneccessary copies we order the nodes before we insert
  // them into the set
  CFlowGraphNode * n1 = NULL;
  CFlowGraphNode * n2 = NULL;
  if(node1 < node2) {
    n1 = node1; 
    n2 = node2;
  }
  else {
    n1 = node2;
    n2 = node1;
  }
  node_pair_set.insert(std::make_pair(n1,n2));

  // Remember the alf label used
  _nodes_referred_to.insert(node1);
  _nodes_referred_to.insert(node2);
}

// To replace all $'s occuring in tag name with '_'
std::string
RapitaIntermediate::
PrettifyTagName(std::string name)
{
  // Search and repace all '$' with '_' or until we reach end of name
  for (unsigned i=0; i<name.length(); ++i) {
    if(name[i] == '$') {
      name[i] = '_';
    }
  }

  // Return the resulting 
  return name;
}


// If the node belongs to a basic block whose start node is the
// return-to node after a function call, then it is not a valid node
// to refer to.  Otherwise it is.
bool 
RapitaIntermediate::
IsValidRapitaPathNode(CFlowGraphNode * node)
{
  return _valid_rapita_nodes.find(node) != _valid_rapita_nodes.end();
}  

void
RapitaIntermediate::
DeriveValidRapitaPathNodes(const std::vector<CFlowGraph*> * flow_graphs, 
                           std::set<CFlowGraphNode *> * valid_rapita_nodes)
{
  assert(flow_graphs);
  assert(valid_rapita_nodes);

  // Loop through all flow graphs
  for (unsigned i=0; i<flow_graphs->size(); ++i) {
    CFlowGraph *flow_graph = (*flow_graphs)[i];
    assert(flow_graph);

    // Calculate immidiate pre and post dominance relation for the nodes in the graph
    CDominance<CFlowGraphNode,CFlowGraphEdgeAnnot> dom_algo;
    std::map<CFlowGraphNode *, CFlowGraphNode *> idom;
    std::string id_s = "idom error"; 
    dom_algo.CalculateIdom(flow_graph, &idom, id_s);
    std::map<CFlowGraphNode *, CFlowGraphNode *> ipdom;
    std::string ipd_s = "ipdom error"; 
    dom_algo.CalculateIPdom(flow_graph, &ipdom, ipd_s);
    
    // Loop through all flow graph nodes
    for(CFlowGraph::node_iterator node = flow_graph->NodesBegin(); 
        node != flow_graph->NodesEnd(); ++node) {

      // The node must be a begin node of a basic block 
      if(!(*node)->IsBeginOfBasicBlock()) {
        continue;
      }

      // A function start node is ok as a rapita path node
      if((*node) == flow_graph->GetEntry() || (*node)->PredSize() == 0) {
        valid_rapita_nodes->insert(*node);
        continue;
      }
      // If the node is a basic block that follows a call node it is
      // not a valid rapita path node
      if(((*node)->PredSize() == 1) && (*((*node)->PredBegin()))->Stmt()->Type() == CGenericStmt::GS_CALL) {
        continue;
      }

      // If the current node post-dominates another node, and this
      // node also pre-dominates this node, then the current node can
      // not be a rapita path node
      CFlowGraphNode * pre_dom_node = idom[*node];
      if(pre_dom_node) {
        CFlowGraphNode * post_dom_node = ipdom[pre_dom_node];
        if(post_dom_node && post_dom_node == *node) {
          continue;
        }
      }

      // Else, the node is a valid rapita node, insert it into the set to be returned
      valid_rapita_nodes->insert(*node);
    }
  }
}
      


int
RapitaIntermediate::
PrintAsRapitaFlowFacts(std::ostream & out_stream, CSourceLoader * sl)
{
  stringstream temp_stream;

  bool has_source_loader = (sl != NULL);

  // ---------------------------------
  // Print initial stuff in file
  // ---------------------------------
  std::string flow_info;
  if(_ffs_based_on_traces) 
    flow_info = "flow hypotheses";
  else
    flow_info = "flow facts";
  
  if(sl) 
    temp_stream << "// RAPITA " << flow_info << " generated using mapping file" << endl << endl;
  else 
    temp_stream << "// RAPITA " << flow_info << " generated without mapping file" << endl << endl;

  int nr_of_rapita_ffs = 0;

  // ---------------------------------
  // Derive needed maps
  // ---------------------------------
  std::map<std::pair<CGenericFunction *, unsigned int>, CFlowGraphNode *> rapita_func_and_loop_index_pair_map_to_cfg_node;
  CreateFuncLoopIndexPairToCFGNodeMap(*_flow_graphs, _source_loader, &rapita_func_and_loop_index_pair_map_to_cfg_node);
  std::map<std::pair<CGenericFunction *, unsigned int>, CFlowGraphNode *> rapita_func_and_call_index_pair_map_to_cfg_node;
  CreateFuncCallIndexPairToCFGNodeMap(*_flow_graphs, _source_loader, &rapita_func_and_call_index_pair_map_to_cfg_node, temp_stream);
  std::map<std::pair<CGenericFunction *, unsigned int>, CFlowGraphNode *> rapita_func_and_node_index_pair_map_to_cfg_node;
  CreateFuncNodeIndexPairToCFGNodeMap(*_flow_graphs, _source_loader, &rapita_func_and_node_index_pair_map_to_cfg_node, temp_stream);

  // Mappings needed to print correct loop names etc
  std::map<std::string, std::string> alf_label_to_rapita_loop;
  std::map<std::string, std::string> alf_label_to_rapita_call_site;
  std::map<std::string, std::string> alf_label_to_rapita_path;
  std::map<std::string, std::string> alf_label_to_rapita_path_tag;
  
  // ---------------------------------
  // Print rapita labels
  // ---------------------------------
  if(has_source_loader) {

      { // Make rapita loop labels for all ALF labels
        bool first_loop_spec = true;
        // Go through all mappings inbetween <func, loop index> pairs and correspinding alf labels. 
        // For each alf label that is used by a flow fact we generate a tag.
        for(std::map<std::pair<CGenericFunction *, unsigned int>, CFlowGraphNode *>::iterator fi2n = rapita_func_and_loop_index_pair_map_to_cfg_node.begin();
            fi2n != rapita_func_and_loop_index_pair_map_to_cfg_node.end(); ++fi2n) {
          // Only generate tag info if the loop node is part of a flow fact
          CFlowGraphNode * node = (*fi2n).second;
          if(_nodes_referred_to.find(node) == _nodes_referred_to.end()) continue;
          // Print extra info
          if(first_loop_spec) {
            temp_stream << "// Loop specifications" << endl;
            first_loop_spec = false;
          }
          // Extract func name and loop index info 
          std::pair<CGenericFunction *, unsigned int> fi = (*fi2n).first;
          std::string func_name = CSourceLoader::PrettifyFuncName(fi.first->Name());
          unsigned int loop_index = fi.second;
          // Extract the first node with valid alf label in the node's
          // basic block. The node should have a corresponding c_source.
          const CAlfLabelSource * c_source_info = GetCSourceOfNode(node, sl);
          if(c_source_info) {
            std::string alf_label = node->Name();
            // Print additional C source info 
            std::stringstream s;
            s << func_name << "@L" << loop_index; 
            std::string rapita_loop = s.str();
            temp_stream << "// " << rapita_loop << " refers to file: " 
                       << CSourceLoader::PrettifyFileName(c_source_info->GetFileName()) << " line: " 
                       << c_source_info->GetLineNumber() << " column: " << c_source_info->GetColumnNumber() << " and alf_label: " << alf_label << endl;
            // Remember the connection
            alf_label_to_rapita_loop[alf_label] = rapita_loop;
          }
        }
        if(!first_loop_spec) temp_stream << endl;
      }
      
      { // Make rapita call labels for all ALF labels
        bool first_call_spec = true;

        // Go through all mappings inbetween <func, call index> pairs and corresponding alf labels. 
        // For each alf label that is used by a flow fact we generate a tag.
        for(std::map<std::pair<CGenericFunction *, unsigned int>, CFlowGraphNode *>::iterator fi2n = rapita_func_and_call_index_pair_map_to_cfg_node.begin();
            fi2n != rapita_func_and_call_index_pair_map_to_cfg_node.end(); ++fi2n) {
          // Only generate tag info if the loop node is part of a flow fact
          CFlowGraphNode * node = (*fi2n).second;
          // if(_nodes_referred_to.find(node) == _nodes_referred_to.end()) continue;
          // Print extra info
          if(first_call_spec) {
            temp_stream << "// Call site specifications" << endl;
            first_call_spec = false;
          }

          // Extract func name and loop index info 
          std::pair<CGenericFunction *, unsigned int> fi = (*fi2n).first;
          std::string func_name = CSourceLoader::PrettifyFuncName(fi.first->Name());
          unsigned int call_index = fi.second;
          // Extract the first node with valid alf label in the node's
          // basic block. The node should have a corresponding c_source.
          const CAlfLabelSource * c_source_info = GetCSourceOfNode(node, sl);
          if(c_source_info) {
            std::string alf_label = node->Name();
            // Print additional C source info
            std::stringstream s;
            s << func_name << "@C" << call_index;
            std::string rapita_call_site = s.str();
            temp_stream << "// " << rapita_call_site << " refers to file: " 
                       << CSourceLoader::PrettifyFileName(c_source_info->GetFileName()) << " line: " 
                       << c_source_info->GetLineNumber() << " column: " << c_source_info->GetColumnNumber() << " and alf_label: " << alf_label << endl;
            // Remember the connection
            alf_label_to_rapita_call_site[alf_label] = rapita_call_site;
          }
        }
        if(!first_call_spec) temp_stream << endl;
      }

      { // Make rapita tag labels for all ALF node labels
        bool first_node_spec = true;
        std::vector<std::string> alf_labels;
        // Go through all mappings inbetween <func, call index> pairs and correspinding alf labels. 
        // For each alf label that is used by a flow fact we generate a tag.
        for(std::map<std::pair<CGenericFunction *, unsigned int>, CFlowGraphNode *>::iterator fi2n  = rapita_func_and_node_index_pair_map_to_cfg_node.begin();
            fi2n  != rapita_func_and_node_index_pair_map_to_cfg_node.end(); ++fi2n ) {
          // Only generate tag info if the loop node is part of a flow fact
          CFlowGraphNode * node = (*fi2n).second;
          if(_nodes_referred_to.find(node) == _nodes_referred_to.end()) continue;
          // Print extra info
          if(first_node_spec) {
            temp_stream << "// Global path specifications" << endl;
            first_node_spec = false;
          }
          // Extract func name and loop index info 
          std::pair<CGenericFunction *, unsigned int> fi = (*fi2n).first;
          std::string func_name = CSourceLoader::PrettifyFuncName(fi.first->Name());
          unsigned int node_index = fi.second;
          // Extract the first node with valid alf label in the node's
          // basic block. The node should have a corresponding c_source.
          const CAlfLabelSource * c_source_info = GetCSourceOfNode(node, sl);
          if(c_source_info) {
            std::string alf_label = node->Name();
            // Print additional C source info 
            std::stringstream s;
            s << func_name << "@P" << node_index;
            std::string rapita_path = s.str();
            temp_stream << "// " << rapita_path << " refers to file: " 
                       << CSourceLoader::PrettifyFileName(c_source_info->GetFileName()) << " line: " 
                       << c_source_info->GetLineNumber() << " column: " << c_source_info->GetColumnNumber() << " and alf_label: " << alf_label << endl;
            // Remember the connection
            alf_label_to_rapita_path[alf_label] = rapita_path;
            // We also create a local tag
            std::stringstream t;
            t << func_name << "_pt" << node_index;
            std::string rapita_path_tag = t.str();
            alf_label_to_rapita_path_tag[alf_label] = rapita_path_tag;
            // Remember the alf label
            alf_labels.push_back(alf_label);
          }
        }
        if(!first_node_spec) temp_stream << endl;

        // Print all the alf_labels again, using local path info
        if(!first_node_spec) {
          temp_stream << "// Local path tag specifications" << endl;
          for(std::vector<std::string>::iterator alf_label = alf_labels.begin(); 
              alf_label != alf_labels.end(); ++alf_label) {
            std::string rapita_path = alf_label_to_rapita_path[*alf_label];
            std::string rapita_path_tag = alf_label_to_rapita_path_tag[*alf_label];
            temp_stream << "#pragma RPT [" << rapita_path << "] path_tag (" << rapita_path_tag << ") ; " << endl;
          }
          temp_stream << endl;
        }
      }
  }
  
  // ---------------------------------
  // Print min and max loop bounds
  // ---------------------------------
  {
    bool first_loop_bound = true;

    // We could either generate local loop bound by loop header count
    // flow facts.
    if(_local_loop_header_max_count.size() > 0) {

      // Get loop bounds from loop header lower and upper bounds
      for(std::map<CFlowGraphNode *, int>::iterator l2c = _local_loop_header_max_count.begin();
          l2c != _local_loop_header_max_count.end(); l2c++) {
        // Extract the label and the count
        CFlowGraphNode * node = (*l2c).first;
        std::string alf_tag = node->Name();
        int max_count = (*l2c).second;

        // Print the loop bound to file
        if(!has_source_loader || HasRapitaNameInMap(alf_tag, &alf_label_to_rapita_loop)) {
          if(first_loop_bound) {
            temp_stream << "// Loop body bounds" << endl;
            first_loop_bound = false;
          }
          // We print with -1 on max node count for while-do-loops
          // since the Rapita loop iter counts refer to loop body
          // iterations.
          std::string rapita_loop = GetRapitaNameFromMap(alf_tag, &alf_label_to_rapita_loop);
          temp_stream << "#pragma RPT [" << rapita_loop << "] loop_max_iter(";
          // Check the type of loop the flow graph node is header in
          CFlowGraph * fg = node->FlowGraph();
          bool is_while_do_loop = fg->NodeHasExitEdgeToNonSubordinateComponent(node);
          // Print the max bound 
          if(is_while_do_loop) 
            temp_stream << max_count-1;
          else
            temp_stream << max_count;
          temp_stream << ") ; " << endl;

          // Remember that we have created a flow fact
          nr_of_rapita_ffs++;

          // Check if we also have a min count for the same loop       
          std::map<CFlowGraphNode *, int>::iterator lc = _local_loop_header_min_count.find(node);
          if(lc != _local_loop_header_min_count.end()) {
            int min_count = (*lc).second;
            std::string rapita_loop = GetRapitaNameFromMap(alf_tag, &alf_label_to_rapita_loop);
            temp_stream << "// ** pragma RPT [" << rapita_loop << "] loop_min_iter(";
            // Check the type of loop the flow graph node is header in
            CFlowGraph * fg = node->FlowGraph();
            bool is_while_do_loop = fg->NodeHasExitEdgeToNonSubordinateComponent(node);
            // Print the max bound 
            if(is_while_do_loop) 
              temp_stream << min_count-1;
            else
              temp_stream << min_count;
            temp_stream << ") ; " << endl;
            
            // Remember that we have created a flow fact
            nr_of_rapita_ffs++;
          }

        } // end if
      } // end for
    } // end if 
    
    // Alternatively we could generate the loop bounds by counting
    // the loop body beging edges.
    else if(_local_loop_body_max_count.size() > 0) {

      // Get loop bounds from loop body lower and upper bounds
      for(std::map<CFlowGraphNode *, int>::iterator l2c = _local_loop_body_max_count.begin();
          l2c != _local_loop_body_max_count.end(); l2c++) {
        // Extract the label and the count
        CFlowGraphNode * node = (*l2c).first;
        std::string alf_tag = node->Name();
        int max_count = (*l2c).second;

        // Print the loop bound to file
        if(!has_source_loader || HasRapitaNameInMap(alf_tag, &alf_label_to_rapita_loop)) {
          if(first_loop_bound) {
            temp_stream << "// Loop bounds" << endl;
            first_loop_bound = false;
          }

          // We print the actual counts since we have derived bounds
          // on the loop body executions
          std::string rapita_loop = GetRapitaNameFromMap(alf_tag, &alf_label_to_rapita_loop);
          temp_stream << "#pragma RPT [" << rapita_loop << "] loop_max_iter(" << max_count << ") ; " << endl;
          
          // Remember that we have created a flow fact
          nr_of_rapita_ffs++;

          // Check if we also have a min count for the same loop       
          std::map<CFlowGraphNode *, int>::iterator lc = _local_loop_body_min_count.find(node);
          if(lc != _local_loop_body_min_count.end()) {
            int min_count = (*lc).second;
            std::string rapita_loop = GetRapitaNameFromMap(alf_tag, &alf_label_to_rapita_loop);
            temp_stream << "// ** pragma RPT [" << rapita_loop << "] loop_min_iter(" << min_count << ") ; " << endl;
            
            // Remember that we have created a flow fact
            nr_of_rapita_ffs++;
          }
        } // end if
      } // end for
    } // end if 
    
    if(first_loop_bound == false) temp_stream << endl;
  }

  // ---------------------------------
  // Print local nodes max count 
  // ---------------------------------
  {
    bool first_local_node_max_count = true;
    for(std::map<CFlowGraphNode *, int>::iterator n2c = _local_node_max_count.begin();
        n2c != _local_node_max_count.end(); n2c++) {    

      // Extract the label and the count
      CFlowGraphNode * node = (*n2c).first;
      std::string alf_tag = node->Name();
      int max_count = (*n2c).second;
      
      // Print the loop bound to file
      if(!has_source_loader || HasRapitaNameInMap(alf_tag, &alf_label_to_rapita_path_tag)) {
        if(first_local_node_max_count) {
            temp_stream << "// Local worst-case frequency in loops" << endl;
            first_local_node_max_count = false;
        }
        
        std::string rapita_path_tag = GetRapitaNameFromMap(alf_tag, &alf_label_to_rapita_path_tag);
        temp_stream << "#pragma RPT [\"" << rapita_path_tag << "\"] wfreq(" << max_count << ") ; " << endl;
        
        // Remember that we have created a flow fact
        nr_of_rapita_ffs++;

      } // end if
    } // end for

    if(first_local_node_max_count == false) temp_stream << endl;
  }

  // ---------------------------------
  // Print local exclusive node pairs
  // ---------------------------------
  {
    bool first_local_nodes_one_or_none_of = true;
    for(std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> >::iterator np = _local_nodes_one_or_none_of.begin();
        np != _local_nodes_one_or_none_of.end(); ++np) {

      // Extract the alf labels of the nodes
      CFlowGraphNode * node1 = (*np).first;
      std::string alf_tag1 = node1->Name();
      CFlowGraphNode * node2 = (*np).second;
      std::string alf_tag2 = node2->Name();

      // Print the loop bound to file
      if(!has_source_loader || 
         (HasRapitaNameInMap(alf_tag1, &alf_label_to_rapita_path_tag) && 
          HasRapitaNameInMap(alf_tag2, &alf_label_to_rapita_path_tag))) {
        if(first_local_nodes_one_or_none_of) {
            temp_stream << "// Local mutually exclusive paths" << endl;
            first_local_nodes_one_or_none_of = false;
        }

        // Print using just the ALF labels. 
        std::string rapita_path_tag1 = GetRapitaNameFromMap(alf_tag1, &alf_label_to_rapita_path_tag);
        std::string rapita_path_tag2 = GetRapitaNameFromMap(alf_tag2, &alf_label_to_rapita_path_tag);
        temp_stream << "#pragma RPT lwp_one_or_none_of (\"" 
                   << rapita_path_tag1 << "\", \"" << rapita_path_tag2 << "\") ;" << endl;
        
        // Remember that we have created a flow fact
        nr_of_rapita_ffs++;
        
      } // end if
    } // end for

    if(first_local_nodes_one_or_none_of == false) temp_stream << endl;
  }

  // ---------------------------------
  // Print local nodes taken at least once
  // ---------------------------------
  {
     bool first_local_node_at_least_one_of = true;
     for(std::set<CFlowGraphNode *>::iterator node = _local_node_at_least_one_of.begin();
        node != _local_node_at_least_one_of.end(); ++node) {
      
      // Extract the alf label 
      std::string alf_tag = (*node)->Name();

      // Print the infeasible node to file
      if(!has_source_loader || HasRapitaNameInMap(alf_tag, &alf_label_to_rapita_path_tag)) {
        if(first_local_node_at_least_one_of) {
          temp_stream << "// Local node at least one of" << endl;
          first_local_node_at_least_one_of = false;
        }

        std::string rapita_path_tag = GetRapitaNameFromMap(alf_tag, &alf_label_to_rapita_path_tag);
        temp_stream << "#pragma RPT lwp_at_least_one_of (\"" << rapita_path_tag << "\") ;" << endl;

        // Remember that we have created a flow fact
        nr_of_rapita_ffs++;

      } // end if
    } // end for

     if(first_local_node_at_least_one_of == false) temp_stream << endl;
  }

  // ---------------------------------
  // Print local node pairs at least one of
  // ---------------------------------
  {
    bool first_local_nodes_at_least_one_of = true;
    int i = 1;
    for(std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> >::iterator np = _local_nodes_at_least_one_of.begin();
        np != _local_nodes_at_least_one_of.end(); ++np, ++i) {

      // Extract the alf labels of the nodes
      CFlowGraphNode * node1 = (*np).first;
      std::string alf_tag1 = node1->Name();
      CFlowGraphNode * node2 = (*np).second;
      std::string alf_tag2 = node2->Name();

      // Print the flow annotations to file
      if(!has_source_loader ||
         (HasRapitaNameInMap(alf_tag1, &alf_label_to_rapita_path_tag) && HasRapitaNameInMap(alf_tag2, &alf_label_to_rapita_path_tag))) {
        if(first_local_nodes_at_least_one_of) {
            temp_stream << "// Local nodes at least one of" << endl;
            first_local_nodes_at_least_one_of = false;
        }
        
        // Print using just the ALF labels. 
        std::string rapita_path_tag1 = GetRapitaNameFromMap(alf_tag1, &alf_label_to_rapita_path_tag);
        std::string rapita_path_tag2 = GetRapitaNameFromMap(alf_tag2, &alf_label_to_rapita_path_tag);
        temp_stream << "#pragma RPT lwp_at_least_one_of (\"" << rapita_path_tag1 << "\",\"" 
                   << rapita_path_tag2 << "\") ;" << endl;

        // Remember that we have created a flow fact
        nr_of_rapita_ffs++;

      } // end if
    } // end for

    if(first_local_nodes_at_least_one_of == false) temp_stream << endl;
  }


  // ---------------------------------
  // Print local node pairs that must be taken together 
  // ---------------------------------
  {
    bool first_local_nodes_must_be_taken_together = true;
    int i = 1;
    for(std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> >::iterator np = _local_nodes_must_be_taken_together.begin();
        np != _local_nodes_must_be_taken_together.end(); ++np, ++i) {

      // Extract the alf labels of the nodes
      CFlowGraphNode * node1 = (*np).first;
      std::string alf_tag1 = node1->Name();
      CFlowGraphNode * node2 = (*np).second;
      std::string alf_tag2 = node2->Name();

      // Print the flow annotations to file
      if(!has_source_loader || 
         (HasRapitaNameInMap(alf_tag1, &alf_label_to_rapita_path_tag) && HasRapitaNameInMap(alf_tag2, &alf_label_to_rapita_path_tag))) {
        if(first_local_nodes_must_be_taken_together) {
            temp_stream << "// Local nodes that must be taken together" << endl;
            first_local_nodes_must_be_taken_together = false;
        }
        
        // Create a unique path marker  
        std::stringstream s;
        s << i;
        std::string taken_together_path_tag = "taken_together_" + s.str();
        
        // Create annotation so that both nodes refer to same path 
        std::string rapita_path_tag1 = GetRapitaNameFromMap(alf_tag1, &alf_label_to_rapita_path_tag);
        std::string rapita_path_tag2 = GetRapitaNameFromMap(alf_tag2, &alf_label_to_rapita_path_tag);
        temp_stream << "#pragma RPT [\"" << rapita_path_tag1 << "\"] path_tag(" << taken_together_path_tag << ") ; " << endl;
        temp_stream << "#pragma RPT [\"" << rapita_path_tag2 << "\"] path_tag(" << taken_together_path_tag << ") ; " << endl;

        // Remember that we have created a flow fact
        nr_of_rapita_ffs++;

      } // end if
    } // end for

    if(first_local_nodes_must_be_taken_together == false) temp_stream << endl;
  }

  // ---------------------------------
  // Print infeasible nodes 
  // ---------------------------------
  {
    bool first_infeasible_node = true;
    for(std::set<CFlowGraphNode *>::iterator node = _infeasible_nodes.begin();
        node != _infeasible_nodes.end(); ++node) {
      
      // Extract the alf label 
      std::string alf_tag = (*node)->Name();

      // Print the infeasible node to file
      if(!has_source_loader || HasRapitaNameInMap(alf_tag, &alf_label_to_rapita_path)) {
        if(first_infeasible_node) {
          temp_stream << "// Global infeasible nodes" << endl;
          first_infeasible_node = false;
        }

        std::string rapita_path = GetRapitaNameFromMap(alf_tag, &alf_label_to_rapita_path);
        temp_stream << "#pragma RPT [" << rapita_path << "] ignore_path ;" << endl;

        // Remember that we have created a flow fact
        nr_of_rapita_ffs++;

      } // end if
    } // end for

    if(first_infeasible_node == false) temp_stream << endl;
  }

  // ---------------------------------
  // Print nodes taken globally at least once
  // ---------------------------------
  {
     bool first_global_node_at_least_one_of = true;
     for(std::set<CFlowGraphNode *>::iterator node = _global_node_at_least_one_of.begin();
        node != _global_node_at_least_one_of.end(); ++node) {
      
      // Extract the alf label 
      std::string alf_tag = (*node)->Name();

      // Print the infeasible node to file
      if(!has_source_loader || HasRapitaNameInMap(alf_tag, &alf_label_to_rapita_path_tag)) {
        if(first_global_node_at_least_one_of) {
          temp_stream << "// Global node at least one of" << endl;
          first_global_node_at_least_one_of = false;
        }

        std::string rapita_path = GetRapitaNameFromMap(alf_tag, &alf_label_to_rapita_path);
        temp_stream << "#pragma RPT wp_at_least_one_of (" << rapita_path << ") ;" << endl;

        // Remember that we have created a flow fact
        nr_of_rapita_ffs++;

      } // end if
    } // end for

    if(first_global_node_at_least_one_of == false) temp_stream << endl;
  }

  // ---------------------------------
  // Print global exclusive node pairs
  // ---------------------------------
  {
    bool first_global_nodes_one_or_none_of = true;
    for(std::set<std::pair<CFlowGraphNode *, CFlowGraphNode *> >::iterator np = _global_nodes_one_or_none_of.begin();
        np != _global_nodes_one_or_none_of.end(); ++np) {

      // Extract the alf labels of the nodes
      CFlowGraphNode * node1 = (*np).first;
      std::string alf_tag1 = node1->Name();
      CFlowGraphNode * node2 = (*np).second;
      std::string alf_tag2 = node2->Name();

      // Print the loop bound to file
      if(!has_source_loader || 
         (HasRapitaNameInMap(alf_tag1, &alf_label_to_rapita_path_tag) && HasRapitaNameInMap(alf_tag2, &alf_label_to_rapita_path_tag))) {
        if(first_global_nodes_one_or_none_of) {
            temp_stream << "// Global mutually exclusive paths" << endl;
            first_global_nodes_one_or_none_of = false;
        }

        // Print using just the ALF labels. 
        std::string rapita_path1 = GetRapitaNameFromMap(alf_tag1, &alf_label_to_rapita_path);
        std::string rapita_path2 = GetRapitaNameFromMap(alf_tag2, &alf_label_to_rapita_path);
        temp_stream << "#pragma RPT wp_one_or_none_of (" 
                   << rapita_path1 << ", " << rapita_path2 << ") ;" << endl;
        
        // Remember that we have created a flow fact
        nr_of_rapita_ffs++;
        
      } // end if
    } // end for

    if(first_global_nodes_one_or_none_of == false) temp_stream << endl;
  }

  // ---------------------------------
  // Print possible function calls 
  // ---------------------------------
  {
    bool first_func_call = true;
    for(std::map<CFlowGraphNode *, std::set<CFlowGraphNode *> *>::iterator cs2fs = _call_site_to_called_funcs.begin();
        cs2fs != _call_site_to_called_funcs.end(); ++cs2fs) {
      CFlowGraphNode * call_node = (*cs2fs).first;
      { 
        // It might be the case that it has no stmt, since we might be running from a CFG
        if(call_node->Stmt()) {
          alf::CCallStmtTuple * call_stmt = dynamic_cast<alf::CCallStmtTuple *>(call_node->Stmt());
          // If it is a normal function call, i.e. no func pointers are
          // used, no call info should be generated
          if(call_stmt != NULL && 
             call_stmt->GetLabelExpr()->IsType(alf::CGenericNode::TYPE_LABEL_TUPLE))
            continue;
        }
      }

      // Else, generate fun pointer call info
      std::string alf_tag = call_node->GetBeginNodeOfNodesBasicBlock()->Name();
      std::set<CFlowGraphNode *> * called_nodes = (*cs2fs).second;
      
      // Print the func calls to file
      if(!has_source_loader || HasRapitaNameInMap(alf_tag, &alf_label_to_rapita_call_site)) {
        if(first_func_call) {
            temp_stream << "// Function calls" << endl;
            first_func_call = false;
        }
        
        std::string rapita_call_site = GetRapitaNameFromMap(alf_tag, &alf_label_to_rapita_call_site);
        temp_stream << "#pragma RPT [" << rapita_call_site << "] call_to (";
        for(std::set<CFlowGraphNode *>::iterator node = called_nodes->begin();
            node != called_nodes->end(); /*intentionally empty */) {
          std::string func_name = (*node)->FlowGraph()->Function()->Name();
          temp_stream << "" << CSourceLoader::PrettifyFuncName(func_name) << "";
          ++node;
          if(node != called_nodes->end()) temp_stream << ", ";
        }
        temp_stream << ") ; " << endl;

        // Remember that we have created a flow fact
        nr_of_rapita_ffs++;
      } // end if
    } // end 
    if(first_func_call== false) temp_stream << endl;
  }

  // If we generated some flow facts we should write the result to file, otherwise not
  if(nr_of_rapita_ffs > 0) {
    out_stream << temp_stream.str();
  }

  // Return the number of flow facts created 
  return nr_of_rapita_ffs;
}

// -------------------------------------------------------
// Help function to get the rapita name that are associated 
// with a given alf label. If no such name exists the alf label is returned.
// -------------------------------------------------------
std::string
RapitaIntermediate::
GetRapitaNameFromMap(std::string alf_label, std::map<std::string, std::string> * alf_label_to_rapita_name_map)
{
  std::map<std::string, std::string>::iterator it = alf_label_to_rapita_name_map->find(alf_label);
  if(it == alf_label_to_rapita_name_map->end())
    return alf_label;
  else
    return (*it).second;
}

// To check if teh given label has an entry in the map
bool
RapitaIntermediate::
HasRapitaNameInMap(std::string alf_label, std::map<std::string, std::string> * alf_label_to_rapita_name_map)
{
  std::map<std::string, std::string>::iterator it = alf_label_to_rapita_name_map->find(alf_label);
  if(it != alf_label_to_rapita_name_map->end())
    return true;
  else
    return false;
}



// -------------------------------------------------------
// Help function to create a mapping between the alf_label of a loop
// header node and a func and the call node index
// -------------------------------------------------------
void
RapitaIntermediate::
CreateFuncLoopIndexPairToCFGNodeMap(const std::vector<CFlowGraph*> &flow_graphs, 
                                    CSourceLoader *source_loader, 
                                    std::map<std::pair<CGenericFunction *, unsigned int>, CFlowGraphNode *> * rapita_func_and_loop_index_pair_map_to_cfg_node)
{
  // To avoid unneccessary work
  if(!source_loader) return;

  // Create a temporary holder for the loops
  RapitaLoops rapita_loops;
  // Call the function that extracts the loops
  CollectRapitaLoops(flow_graphs, source_loader, rapita_loops);

  // Get the alf label to loop mapping and loop through its items
  const std::map<std::string, RapitaLoop*> * label_to_loop = rapita_loops.GetLabelToRapitaLoopMap();
  for(std::map<std::string, RapitaLoop*>::const_iterator l2l = label_to_loop->begin();
      l2l != label_to_loop->end(); ++l2l) {
    // Extract the interesting stuff
    CFlowGraphNode * header_node = const_cast<CComponent<CFlowGraphNode> *>((*l2l).second->GetComponent())->Head();
    assert(header_node->IsHeader());
    assert(header_node->IsBeginOfBasicBlock());
    CGenericFunction * func = const_cast<CGenericFunction *>((*l2l).second->Function());
    unsigned int index = (*l2l).second->GetSequenceNumber();
    // Update map to be returned
    (*rapita_func_and_loop_index_pair_map_to_cfg_node)[std::make_pair(func, index)] = header_node;
  }
}
     
// -------------------------------------------------------
// Help function to create a mapping inbetween alf labels of call
// nodes and a func and the call node index.
// -------------------------------------------------------
void
RapitaIntermediate::
CreateFuncCallIndexPairToCFGNodeMap(const std::vector<CFlowGraph*> &flow_graphs, 
                                    CSourceLoader *source_loader, 
                                    std::map<std::pair<CGenericFunction *, unsigned int>, CFlowGraphNode *> * rapita_func_and_call_index_pair_map_to_cfg_node,
                                    std::ostream & out_stream,
                                    bool collect_only_bb_start_nodes)
{
  // To avoid unneccessary work
  if(!source_loader) return;

  bool wrote_error_message = false;

  // Loop through all flow graphs
  for (unsigned i=0; i<flow_graphs.size(); ++i) {
    CFlowGraph *flow_graph = flow_graphs[i];

    // Create a mapping inbetween source code locations and control-flow graph nodes
    std::map<std::pair<unsigned int, unsigned int>, CFlowGraphNode *> line_and_column_to_cfg_node;
    bool found_c_sources = true;

    // Loop through all nodes in the flow graph. For each node we
    // check if its is a call node. If so, we try to extract the
    // corresponding c_source info using its alf_label. If no valid
    // c_source was found we try to extract it from the nodes found
    // above and below in the basic block that the call node belongs
    // to. Info in the found c_source is used to update the mapping. 
    for(CFlowGraph::node_iterator node = flow_graph->NodesBegin(); 
        node != flow_graph->NodesEnd(); ++node) {
      
      // We only extract this for start nodes of basic blocks
      if(!(*node)->IsBeginOfBasicBlock() && collect_only_bb_start_nodes) continue;
      // Get the end node of the basic block
      CFlowGraphNode * end_node = (*node)->GetEndNodeOfNodesBasicBlock();
      // Check if it is a call node
      if(end_node->Stmt()->Type() == CGenericStmt::GS_CALL) {
        // Get the alf label and C source info of the node
        const CAlfLabelSource * c_source = source_loader->GetSourceOfLabel((*node)->Name());
        if(!c_source) {
          // Search from begin node of basic block to end node of
          // basic block for a valid c_source
          CFlowGraphNode * walker_node = (*node)->GetBeginNodeOfNodesBasicBlock();
          while(!walker_node->IsEndOfBasicBlock() && !c_source) {
            walker_node = walker_node->SuccBegin()->node;
            c_source = source_loader->GetSourceOfLabel(walker_node->Name());
          }          
        }
      
        if(c_source) {
          // If we have got a valid c_source we should extract its C
          // line and column number
          unsigned int line_number = c_source->GetLineNumber();
          unsigned int column_number = c_source->GetColumnNumber();
          // Update the mapping
          line_and_column_to_cfg_node[std::make_pair(line_number, column_number)] = (*node);
        }
        else {
          cout << "Warning: No Rapita call-site flow facts generated for function " 
               << CSourceLoader::PrettifyFuncName((*node)->FlowGraph()->Function()->Name()) 
               << " due to missing call-site info in map file. Consider: -m c" << endl;
          out_stream << "// NOTE! No Rapita call-site flow facts generated for function " 
                     << CSourceLoader::PrettifyFuncName((*node)->FlowGraph()->Function()->Name()) 
                     << " due to missing call-site info in map file. " << endl;
          found_c_sources = false;
          wrote_error_message = true;
          break;
        }
      }
    }

    if(found_c_sources) {
      // Go through mapping and assign func and call node index pairs to
      // the alf labels. We use the fact that traversing the map becomes
      // a sorted walk through the code...
      unsigned int j=1;
      for(std::map<std::pair<unsigned int, unsigned int>, CFlowGraphNode *>::iterator lc2n = line_and_column_to_cfg_node.begin();
          lc2n != line_and_column_to_cfg_node.end(); ++lc2n, ++j) {
        CFlowGraphNode * node = (*lc2n).second;
        CGenericFunction * func = node->FlowGraph()->Function();
        (*rapita_func_and_call_index_pair_map_to_cfg_node)[std::make_pair(func, j)] = node;
      }
    }
  }
  
  if(wrote_error_message)
    out_stream << endl;
}

// -------------------------------------------------------
// Help function to create a mapping inbetween alf labels of cfg
// nodes and a func and the node index.
// -------------------------------------------------------
void
RapitaIntermediate::
CreateFuncNodeIndexPairToCFGNodeMap(const std::vector<CFlowGraph*> &flow_graphs, 
                                    CSourceLoader *source_loader, 
                                    std::map<std::pair<CGenericFunction *, unsigned int>, CFlowGraphNode *> * rapita_func_and_node_index_pair_map_to_cfg_node,
                                    std::ostream & out_stream,
                                    bool collect_only_bb_start_nodes)
{
  // To avoid unneccessary work
  if(!source_loader) return;

  bool wrote_error_message = false;

  // Loop through all flow graphs
  for (unsigned i=0; i<flow_graphs.size(); ++i) {
    CFlowGraph *flow_graph = flow_graphs[i];

    // Create a mapping inbetween source code locations and control-flow graph nodes
    std::map<std::pair<unsigned int, unsigned int>, CFlowGraphNode *> line_and_column_to_cfg_node;
    bool found_c_sources = true;

    // Loop through all nodes in the flow graph. If the node is valid
    // we try to extract the corresponding c_source info using its
    // alf_label. If no valid c_source was found we should not be using 
    // any mapping for this particular flow graph.
    for(CFlowGraph::node_iterator node = flow_graph->NodesBegin(); 
        node != flow_graph->NodesEnd(); ++node) {

      // Only include nodes which are ok as rapita node reference
      if(!IsValidRapitaPathNode(*node)) continue;

      // Else, try to derive the right c_source for the node
      const CAlfLabelSource * c_source = GetCSourceOfNode(*node, source_loader);
      
      if(c_source) {
        // If we have got a valid c_source we should extract its C
        // line and column number
        unsigned int line_number = c_source->GetLineNumber();
        unsigned int column_number = c_source->GetColumnNumber();
        // Update the mapping
        line_and_column_to_cfg_node[std::make_pair(line_number, column_number)] = (*node);
      }
      else {
          cout << "Warning: No Rapita path flow facts generated for function " 
               << CSourceLoader::PrettifyFuncName((*node)->FlowGraph()->Function()->Name()) 
               << " due to missing path node info in map file. Consider: -m c" << endl;
          out_stream << "// NOTE! No Rapita path flow facts generated for function " 
                     << CSourceLoader::PrettifyFuncName((*node)->FlowGraph()->Function()->Name()) 
                     << " due to missing path node info in map file. " << endl;
        found_c_sources = false;
        wrote_error_message = true;
        break;
      }
    }

    if(found_c_sources) {
      // Go through mapping and assign func and node index pairs to
      // the alf labels. We use the fact that traversing the map becomes
      // a sorted walk through the code...
      unsigned int j=1;
      for(std::map<std::pair<unsigned int, unsigned int>, CFlowGraphNode *>::iterator lc2n = line_and_column_to_cfg_node.begin();
          lc2n != line_and_column_to_cfg_node.end(); ++lc2n, ++j) {
        CFlowGraphNode * node = (*lc2n).second;
        CGenericFunction * func = node->FlowGraph()->Function();
        (*rapita_func_and_node_index_pair_map_to_cfg_node)[std::make_pair(func, j)] = node;
      }
    }
  }

  if(wrote_error_message)
    out_stream << endl;
}



const CAlfLabelSource * 
RapitaIntermediate::
GetCSourceOfNode(CFlowGraphNode * node, CSourceLoader * sl) 
{
  // If we have no source code loader we cannot relate the node to the
  // source code
  if(!sl) return NULL;

  // First we try to get c source info using the label of the node
  const CAlfLabelSource * src = NULL;
  src = sl->GetSourceOfLabel(node->Name());
  if(src) return src;

  // If no src was not found, try the header node of the basic block 
  CFlowGraphNode * walker_node = node->GetBeginNodeOfNodesBasicBlock();
  src = sl->GetSourceOfLabel(walker_node->Name());
  if(src) return src;

  // Else, try the remaining nodes in the bb
  while(!walker_node->IsEndOfBasicBlock()) {
    walker_node = walker_node->SuccBegin()->node;
    src = sl->GetSourceOfLabel(walker_node->Name());
    if(src) return src;
  }

  // Special case. We have a node that starts a function but which
  // does not have a corresponding c_source, e.g. due to a while()
  // direct after the function start. Then we use the while node 
  // as the c_source.
  if(node->FlowGraph()->GetEntry() == node->GetBeginNodeOfNodesBasicBlock()) {
    CFlowGraphNode * end_node = node->GetEndNodeOfNodesBasicBlock();
    if(end_node->SuccSize() == 1) {
      CFlowGraphNode * succ_node = end_node->SuccBegin()->node;
      if(succ_node->PredSize() > 1) {
        // Call the function recursively
        src = GetCSourceOfNode(succ_node, sl);
      }
    }
    if(src) return src;
  }

  // Special case 2 (due to Satire generated ALF code missing a
  // label): We have a node which is a jump node which does not have a
  // c_source and it follows a switch statement which has an alf
  // label. Then we give the node a c_source which is directly after
  // the switch statements c_source.
  /** if((node->IsBeginOfBasicBlock()) &&
     (node->Stmt()->Type() == CGenericStmt::GS_JUMP) &&
     (node->PredSize() == 1) && 
     ((*node->PredBegin())->Stmt()->Type() == CGenericStmt::GS_COND)) {
    const CAlfLabelSource * pred_src = GetCSourceOfNode((*node->PredBegin()), sl);
    if(pred_src) {
      // Create a temporary c_source, to be returned and to be removed when the 
      // RapitaIntermediate objetc is removed.
      CAlfLabelSource * temp_src = 
        new CAlfLabelSource("** patched alf label source **", pred_src->GetFileName(), 
                            pred_src->GetLineNumber(), pred_src->GetColumnNumber()+1);
      _temp_c_sources.insert(temp_src);
      src = temp_src;
      return src;
    }
  }
  **/

  // Else, no source was found
  return NULL;
}

// Help function for converting lower and upper node bounds flow facts
// to aiS flow facts
void
UpdateRapitaIntermediateWithContextSensitiveValidAtEntryOfFlowFacts(const std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs, 
                                                                    RapitaIntermediate * ri) 
{
  // Go through all flow facts
  for(std::vector<CContextSensitiveValidAtEntryOfFlowFact *>::const_iterator ff = ffs->begin();
      ff != ffs->end(); ++ff) {

    // To avoid unneccessary processing
    if(!(*ff)->IsZeroContextSensitive()) continue;

    CFlowFact::t_flowfacttype type = (*ff)->Type();

    // ---------------------------------
    // Check if we have a local min or max loop header bound
    // ---------------------------------
    if(((type == CFlowFact::LHSS) || (type == CFlowFact::UHSS)) && (*ff)->IsValidAtEntryOfLoop()) {
      CConstraint * constr = (*ff)->Constraint();
      assert(constr->GetLeftExpression());
      assert(constr->GetLeftExpression()->Type() == ETYPE_CFG_NODE);
      CExpressionFlowGraphNode *lhs = dynamic_cast<CExpressionFlowGraphNode*>(constr->GetLeftExpression());
      CFlowGraphNode * header = const_cast<CFlowGraphNode *>(lhs->Node());
      assert(lhs); 
      CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
      int count = rhs->Value();
      assert(rhs);
      t_relop relop = constr->GetOperator();
      if(relop == RELOP_LTEQ) {
        // We have #BB <= count, i.e. an upper loop bound
        ri->AddLocalLoopHeaderMaxCount(header, count);
      }
      else if(relop == RELOP_GTEQ) {
        // We have #BB >= count, i.e. an lower loop bound
        ri->AddLocalLoopHeaderMinCount(header, count);
      }
    }

    // ---------------------------------
    // Check if we have a lower or upper loop begin edge bound
    // ---------------------------------
    else if(((type == CFlowFact::LBNS) || (type == CFlowFact::UBNS)) && (*ff)->IsValidAtEntryOfLoop()) {
      // Derive the loop header node 
      CConstraint * constr = (*ff)->Constraint();
      CExpression * expr = constr->GetLeftExpression();
      while(expr->Type() == ETYPE_BINOP) {
        expr = (dynamic_cast<CExpressionBin *>(expr))->GetLeftExpression();
      }
      assert(expr->Type() == ETYPE_CFG_EDGE);
      CExpressionFlowGraphEdge *edge_expr = dynamic_cast<CExpressionFlowGraphEdge*>(expr);
      CFlowGraphNode * from_node = edge_expr->FromNode();
      CFlowGraphNode * header = from_node->GetBeginNodeOfNodesBasicBlock();
      // Get the count from the right expression
      CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
      int count = rhs->Value();
      assert(rhs);
      t_relop relop = constr->GetOperator();
      if(relop == RELOP_LTEQ) {
        // We have #BB <= count, i.e. an upper loop body bound
        ri->AddLocalLoopBodyMaxCount(header, count);
      }
      else if(relop == RELOP_GTEQ) {
        // We have #BB >= count, i.e. an lower loop body bound
        ri->AddLocalLoopBodyMinCount(header, count);
      }
    }

    // ---------------------------------
    // Check if we have a local upper node bound or a local lower bound 
    // ---------------------------------
    else if(((type == CFlowFact::UNSS) || (type == CFlowFact::LNSS)) && (*ff)->IsValidAtEntryOfLoop()) {
      // Derive the node
      CConstraint * constr = (*ff)->Constraint();
      assert(constr->GetLeftExpression());
      assert(constr->GetLeftExpression()->Type() == ETYPE_CFG_NODE);
      CExpressionFlowGraphNode *lhs = dynamic_cast<CExpressionFlowGraphNode*>(constr->GetLeftExpression());
      CFlowGraphNode * node = const_cast<CFlowGraphNode *>(lhs->Node());
      // We only generate ffs for non-header nodes
      if(!node->IsHeader() && ri->IsValidRapitaPathNode(node)) {
        // Derive the count and the operation
        assert(lhs); 
        CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
        assert(rhs);
        int count = rhs->Value();
        t_relop relop = constr->GetOperator();
        if(relop == RELOP_LTEQ) {
          // Check if we have an infeasible node
          if(count == 0) ri->AddInfeasibleNode(node);
          // We have #BB <= count, i.e. an upper node count
          ri->AddLocalNodeMaxCount(node, count);
        }
        if(relop == RELOP_GTEQ && count > 0) {
          // We have #BB >= count, i.e. a lower node count
          ri->AddLocalNodeAtLeastOneOf(node);
        }
      }
    }

    // ---------------------------------
    // Check if we have function or program global infeasible nodes 
    // ---------------------------------
    else if((type == CFlowFact::UNSF) || (type == CFlowFact::UNSP)) {
      // Derive the node
      CConstraint * constr = (*ff)->Constraint();
      assert(constr->GetLeftExpression());
      assert(constr->GetLeftExpression()->Type() == ETYPE_CFG_NODE);
      CExpressionFlowGraphNode *lhs = dynamic_cast<CExpressionFlowGraphNode*>(constr->GetLeftExpression());
      CFlowGraphNode * node = const_cast<CFlowGraphNode *>(lhs->Node());
      if(ri->IsValidRapitaPathNode(node)) {
        // Derive the count and the operation
        assert(lhs); 
        CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
        assert(rhs);
        int count = rhs->Value();
        t_relop relop = constr->GetOperator();
        if(relop == RELOP_LTEQ && count == 0) {
          // We have #BB = 0, i.e. an infeasibel node
          ri->AddInfeasibleNode(node);
        }
      }
    } 

    // ---------------------------------
    // Check if we have local infeasible node 
    // ---------------------------------
    else if(type == CFlowFact::INSA) {
      // Derive the node
      CConstraint * constr = (*ff)->Constraint();
      assert(constr->GetLeftExpression());
      assert(constr->GetLeftExpression()->Type() == ETYPE_CFG_NODE);
      CExpressionFlowGraphNode *lhs = dynamic_cast<CExpressionFlowGraphNode*>(constr->GetLeftExpression());
      CFlowGraphNode * node = const_cast<CFlowGraphNode *>(lhs->Node());
      if(ri->IsValidRapitaPathNode(node)) {
        // Derive the count and the operation
        assert(lhs); 
        CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
        assert(rhs);
        int count = rhs->Value();
        t_relop relop = constr->GetOperator();
        if(relop == RELOP_EQ && count == 0) {
          // We have #BB = 0, i.e. an infeasibel node
          ri->AddInfeasibleNode(node);
        }
      }
    } 

    // ---------------------------------
    // Check if we have a local infeasible node pair
    // ---------------------------------
    else if(type == CFlowFact::INPA) {
      // Derive the pair of nodes
      CConstraint * constr = (*ff)->Constraint();
      CExpressionBin *lhs = dynamic_cast<CExpressionBin*>(constr->GetLeftExpression());
      assert(lhs->GetLeftExpression());
      assert(lhs->GetRightExpression());
      CExpressionFlowGraphNode * expr1 = dynamic_cast<CExpressionFlowGraphNode *>(lhs->GetLeftExpression());
      CExpressionFlowGraphNode * expr2 = dynamic_cast<CExpressionFlowGraphNode *>(lhs->GetRightExpression());
      assert(lhs->GetLeftExpression()->Type() == ETYPE_CFG_NODE);
      assert(lhs->GetRightExpression()->Type() == ETYPE_CFG_NODE);
      CFlowGraphNode * node1 = const_cast<CFlowGraphNode *>(expr1->Node());
      CFlowGraphNode * node2 = const_cast<CFlowGraphNode *>(expr2->Node());
      assert(node1);
      assert(node2);
      if(ri->IsValidRapitaPathNode(node1) && ri->IsValidRapitaPathNode(node2)) {
        // Create a rapita flow fact
        ri->AddLocalNodesOneOrNoneOf(node1, node2);
      }
    }

    // ---------------------------------
    // Check if we have that a node pair that must be taken at least once. 
    // *** Removed since Rapita FFs are valid for each iteration, while SWEET LNPS FFs
    // are valid for the whole execution of the scope *** 
    // ---------------------------------
    // else if(type == CFlowFact::LNPS && (*ff)->IsZeroContextSensitive()) {
    //       // Derive the pair of nodes
    //       CConstraint * constr = (*ff)->Constraint();
    //       CExpressionBin *lhs = dynamic_cast<CExpressionBin*>(constr->GetLeftExpression());
    //       assert(lhs->GetLeftExpression());
    //       assert(lhs->GetRightExpression());
    //       CExpressionFlowGraphNode * expr1 = dynamic_cast<CExpressionFlowGraphNode *>(lhs->GetLeftExpression());
    //       CExpressionFlowGraphNode * expr2 = dynamic_cast<CExpressionFlowGraphNode *>(lhs->GetRightExpression());
    //       assert(lhs->GetLeftExpression()->Type() == ETYPE_CFG_NODE);
    //       assert(lhs->GetRightExpression()->Type() == ETYPE_CFG_NODE);
    //       CFlowGraphNode * node1 = const_cast<CFlowGraphNode *>(expr1->Node());
    //       CFlowGraphNode * node2 = const_cast<CFlowGraphNode *>(expr2->Node());
    //       assert(node1);
    //       assert(node2);
    //       // Get the operator and the count
    //       CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
    //       assert(rhs);
    //       int count = rhs->Value();
    //       t_relop relop = constr->GetOperator();
    //       if(relop == RELOP_GTEQ && count > 0) {
    //         // We have #BB >= count, i.e. a lower node pair count
    //         ri->AddLocalNodesAtLeastOneOf(node1, node2);
    //       }
    //     }

    // ---------------------------------
    // Check if we have that a node pair that locally must be taken together
    // ---------------------------------
    else if(type == CFlowFact::INPA2) {
      // Derive the nodes
      CConstraint * constr = (*ff)->Constraint();
      assert(constr->GetLeftExpression());
      assert(constr->GetRightExpression());
      CExpressionFlowGraphNode *lhs = dynamic_cast<CExpressionFlowGraphNode *>(constr->GetLeftExpression());
      CExpressionFlowGraphNode *rhs = dynamic_cast<CExpressionFlowGraphNode *>(constr->GetRightExpression());
      CFlowGraphNode * node1 = const_cast<CFlowGraphNode *>(lhs->Node());
      CFlowGraphNode * node2 = const_cast<CFlowGraphNode *>(rhs->Node());
       // Check the operator
      t_relop relop = constr->GetOperator();
      if(relop == RELOP_EQ && ri->IsValidRapitaPathNode(node1) && ri->IsValidRapitaPathNode(node2)) {
        // We have <> : #BB1 == #BB2, two nodes that each iteration
        // must be executed the same way
        ri->AddLocalNodesMustBeTakenTogether(node1, node2);
      }
    }

    // ---------------------------------
    // Check if we have nodes that must be taken globally at least once
    // ---------------------------------
    else if(type == CFlowFact::LNSP) {
      CConstraint * constr = (*ff)->Constraint();
      assert(constr->GetLeftExpression());
      CExpressionFlowGraphNode *lhs = dynamic_cast<CExpressionFlowGraphNode*>(constr->GetLeftExpression());
      CFlowGraphNode * node = const_cast<CFlowGraphNode *>(lhs->Node());
      CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
      int count = rhs->Value();
      t_relop relop = constr->GetOperator();
      if(relop == RELOP_GTEQ && count > 0 && ri->IsValidRapitaPathNode(node)) {
        // We have #BB >= count, i.e. a lower node count
        ri->AddGlobalNodeAtLeastOneOf(node);
      }   
    }

    // ---------------------------------
    // Check if we have global exclusive nodes 
    // ---------------------------------
    else if(type == CFlowFact::LNPP || type == CFlowFact::UNPP) {
      // Derive the pair of nodes
      CConstraint * constr = (*ff)->Constraint();
      assert(constr->GetLeftExpression());
      assert(constr->GetLeftExpression()->Type() == ETYPE_BINOP);
      CExpressionBin *lhs = dynamic_cast<CExpressionBin*>(constr->GetLeftExpression());
      assert(lhs->GetLeftExpression());
      assert(lhs->GetRightExpression());
      CExpressionFlowGraphNode * expr1 = dynamic_cast<CExpressionFlowGraphNode *>(lhs->GetLeftExpression());
      CExpressionFlowGraphNode * expr2 = dynamic_cast<CExpressionFlowGraphNode *>(lhs->GetRightExpression());
      assert(lhs->GetLeftExpression()->Type() == ETYPE_CFG_NODE);
      assert(lhs->GetRightExpression()->Type() == ETYPE_CFG_NODE);
      CFlowGraphNode * node1 = const_cast<CFlowGraphNode *>(expr1->Node());
      CFlowGraphNode * node2 = const_cast<CFlowGraphNode *>(expr2->Node());
      assert(node1);
      assert(node2);
      // Get the operator and the count
      CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
      assert(rhs);
      int count = rhs->Value();
      t_relop relop = constr->GetOperator();
      if(relop == RELOP_LTEQ && count == 1 && 
         ri->IsValidRapitaPathNode(node1) && ri->IsValidRapitaPathNode(node2)) {
        // We have #BB1 + #BB2 <= 1, i.e. a lower bound on the node pair 
        ri->AddGlobalNodesOneOrNoneOf(node1, node2);
      }
    }
   
    // ---------------------------------
    // Check if we have information on call edges
    // ---------------------------------
    else if(type == CFlowFact::UCSF || type == CFlowFact::UCSP) {
      // Derive the from and to nodes in the call edge
      CConstraint * constr = (*ff)->Constraint();
      assert(constr->GetLeftExpression());
      assert(constr->GetLeftExpression()->Type() == ETYPE_CFG_EDGE);
      CExpressionFlowGraphEdge *lhs = dynamic_cast<CExpressionFlowGraphEdge*>(constr->GetLeftExpression());
      CFlowGraphNode * from_node = lhs->FromNode();
      CFlowGraphNode * to_node = lhs->ToNode();
      // Derive the count and the operation
      CExpressionInt *rhs = dynamic_cast<CExpressionInt*>(constr->GetRightExpression());
      assert(rhs);
      int count = rhs->Value();
      t_relop relop = constr->GetOperator();
      if(relop == RELOP_LTEQ && count > 0) {
        // We have #BB->BB >= count, i.e. an upper call-edge count larger than zero
        ri->AddFuncCallFromCallSite(from_node, to_node);
      }   
    }

    else {
      // skip remaining ffs
    }
    
  } // end for all ffs

}

