// $Id $
#include "CIndexRangeList.h"
#include <iostream>

using namespace std;

CIndexRangeList::CIndexRangeList(void)
{
}

CIndexRangeList::~CIndexRangeList(void)
{
}

void CIndexRangeList::AddRange(int lb, int ub)
{
   _rlist.push_front(CIndexRange(lb, ub));
}

void CIndexRangeList::Copy(const CIndexRangeList &theother)
{
   _rlist = theother._rlist;
}

CIndexRangeList::CIndexRangeList(const CIndexRangeList  &theother)
{
   Copy(theother);
}

int CIndexRangeList::RemoveRange(int nr, int lb, int ub)
{
        list <CIndexRange>::iterator it;
   int i;

        if (lb > ub)
                return false;
        for (it = _rlist.begin(), i = 0; it != _rlist.end(); it++, i++) {
      if (i==nr) {
         _rlist.erase(it);
         return true;
      }
   }
        return false;
}

int CIndexRangeList::UpdateRange(int nr, int lb, int ub)
{
        list <CIndexRange>::iterator it;
   int i;

        if (lb > ub)
                return false;
        for (it = _rlist.begin(), i = 0; it != _rlist.end(); it++, i++) {
      if (i==nr) {
         it->LowerBound(lb);
         it->UpperBound(ub);
         return true;
      }
   }
        return false;
}

bool  CIndexRangeList::operator < (const CIndexRangeList &theother) const
{
   return _rlist < theother._rlist;
}

bool  CIndexRangeList::operator ==(const CIndexRangeList &theother) const
{
   return _rlist == theother._rlist;
}

ostream & operator << (ostream &o, const CIndexRangeList &rl)
{
        list <CIndexRange>::const_iterator it;
        for (it = rl._rlist.begin(); it != rl._rlist.end();  ) {
                o << *it;
                if (++it != rl._rlist.end())
                        o << ", ";
        }
        if (rl._rlist.size() > 0)
                o << " : ";
        return o;
}
