// $Id $

#ifndef CLOCATOR_H_
#define CLOCATOR_H_

#include <iostream>
#include <string>


typedef enum {LOC_ID, LOC_BB, LOC_ENTRY} t_loctype;
class CScope;
class CFlowGraphNode;

class CBBLocator
{
private:
  CScope *_scope;
  CFlowGraphNode *_node;
public:
  virtual ~CBBLocator(void);
  CBBLocator(void);
  CBBLocator(CFlowGraphNode *);
  CBBLocator(CScope *, CFlowGraphNode *);

  // Get the scope refered by this locator
  const CScope *GetScope(void) const;

  // Get the flow-graph node refered by this locator
  const CFlowGraphNode *GetNode(void) const;

  std::string tostring(void) const;
  friend std::ostream & operator << (std::ostream &o, const CBBLocator &loc);
};

class CNodeLocator
{
private:
  t_loctype _type;
public:
  virtual ~CNodeLocator(void);
  CNodeLocator(t_loctype);
  t_loctype GetType(void) const;
  virtual std::string tostring(void) const = 0;
};

class CNodeLocatorBB:public CNodeLocator
{
private:
  CBBLocator _loc;
public:
  virtual ~CNodeLocatorBB(void);
  CNodeLocatorBB(CBBLocator loc);

  // Returns the sub-locator of this locator node
  const CBBLocator *GetBBLocator(void) const;

  std::string tostring(void) const;
};

class CNodeLocatorId:public CNodeLocator
{
private:
  CFlowGraphNode *_node;
public:
  virtual ~CNodeLocatorId(void);
  CNodeLocatorId(CFlowGraphNode *);

  // Returns the flow-graph node of this id-locator
  const CFlowGraphNode *GetNode(void) const;

  std::string tostring(void) const;
};

class CNodeLocatorEntry:public CNodeLocator
{
private:
  CFlowGraphNode *_node;
public:
  virtual ~CNodeLocatorEntry(void);

  // Returns the flow-graph node of this entry-locator
  const CFlowGraphNode *GetNode(void) const;

  CNodeLocatorEntry(CFlowGraphNode *);
  std::string tostring(void) const;
};

class CEdgeLocator
{
private:
  CNodeLocator *_from, *_to;
public:
  virtual ~CEdgeLocator(void);
  CEdgeLocator(void);

  // Return edges of this locator:
  const CNodeLocator *From(void) const;
  const CNodeLocator *To(void) const;

  CEdgeLocator(CNodeLocator *from, CNodeLocator *to);
  std::string tostring(void) const;
};

#endif
