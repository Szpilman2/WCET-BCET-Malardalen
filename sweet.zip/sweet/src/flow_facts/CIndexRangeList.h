// $Id $

#ifndef CRANGELIST_H_
#define CRANGELIST_H_

#include <list>
#include <iostream>
#include "CIndexRange.h"



class CIndexRangeList
{
protected:
        std::list<CIndexRange> _rlist;
   void Copy(const CIndexRangeList  &theother);
public:
   typedef std::list<CIndexRange>::iterator iterator;

   CIndexRangeList (const CIndexRangeList  &theother);
   CIndexRangeList (void);
   virtual ~CIndexRangeList (void);

   // Iterates over the ranges
   inline iterator begin(void) {return _rlist.begin();}
   inline iterator end(void) {return _rlist.end();}

   /* Adds a range to the range list. The last on inserted is the one to be printed first */
   void AddRange(int lb, int ub);

   /* Removes a range at index, where 0 is the first one inserted */
   int RemoveRange(int nr, int lb, int ub);

   /* Updates a range at index, where 0 is the first one inserted */
   int UpdateRange(int nr, int lb, int ub);

   bool  operator < (const CIndexRangeList &) const;
   bool  operator ==(const CIndexRangeList &) const;
   friend std::ostream & operator << (std::ostream &o, const CIndexRangeList &rl);
};

#endif
