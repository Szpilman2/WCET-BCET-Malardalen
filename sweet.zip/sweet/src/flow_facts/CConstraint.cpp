// $Id $
#include "CConstraint.h"
#include "CExpression.h"
#include <cassert>

using namespace std;

void CConstraint::Copy(const CConstraint &theother)
{
        _right = theother._right->NewExpression();
        _relop = theother._relop;
        _left = theother._left->NewExpression();
}

CConstraint::CConstraint(void)
{
        _left = _right = NULL;
        _relop = RELOP_EQ;
}

CConstraint::CConstraint(CExpression *l, t_relop op, CExpression *r)
{
        _left = l;
        _relop = op;
        _right = r;
}

CExpression *CConstraint::GetLeftExpression(void)
{
   return _left;
}

CExpression *CConstraint::GetRightExpression(void)
{
   return _right;
}

t_relop CConstraint::GetOperator(void)
{
   return _relop;
}

CConstraint::CConstraint(const CConstraint &theother)
{
   Copy(theother);
}

CConstraint::~CConstraint(void)
{
   delete _left;
   delete _right;
}

// CConstraint CConstraint::MergeConstraints(const CConstraint *other) const
// {
//    if (other->_right->Type() == ETYPE_INT && _right->Type() == ETYPE_INT && _relop == other->_relop) {
//       CExpressionInt *this_right = (CExpressionInt*)_right, *other_right = (CExpressionInt*)other->_right;
//       switch (_relop) {
//          case RELOP_LTEQ:
//             if (other_right->Value() > this_right->Value())
//                return CConstraint(new CExpressionId(((CExpressionId*)_left)->Id()), _relop, new CExpressionInt(other_right->Value()));
//             else
//                return CConstraint(new CExpressionId(((CExpressionId*)_left)->Id()), _relop, new CExpressionInt(this_right->Value()));
//          case RELOP_GTEQ:
//             if (other_right->Value() < this_right->Value())
//                return CConstraint(new CExpressionId(((CExpressionId*)_left)->Id()), _relop, new CExpressionInt(other_right->Value()));
//             else
//                return CConstraint(new CExpressionId(((CExpressionId*)_left)->Id()), _relop, new CExpressionInt(this_right->Value()));
//          case RELOP_LT: cerr << "RELOP_LT not used" << endl; assert(0);
//          case RELOP_GT: cerr << "RELOP_GT not used" << endl; assert(0);
//          case RELOP_EQ:
//             assert(other_right->Value() == this_right->Value());
//                return CConstraint(new CExpressionId(((CExpressionId*)_left)->Id()), _relop, new CExpressionInt(other_right->Value()));
//          case RELOP_NEQ: cerr << "RELOP_NEQ not used" << endl; assert(0);
//       }
//    } else {
//       if (_relop == RELOP_EQ && _relop == other->_relop) {
//          // Handle recursive EQ specially
//          assert (((CExpressionId*)other->_left)->Id() == ((CExpressionId*)_left)->Id());
//          assert (((CExpressionId*)other->_right)->Id() == ((CExpressionId*)_right)->Id());
//          return CConstraint(new CExpressionId(((CExpressionId*)_left)->Id()), _relop, new CExpressionId(((CExpressionId*)_right)->Id()));
//       } else {
//          cerr << "Internal error" << endl;
//          assert(0);
//       }
//    }
//    return CConstraint();
// }

bool CConstraint::operator<(const CConstraint &theother) const
{
   if (_right == theother._right)
      if (_left == theother._left)
         return _relop < theother._relop;
      return _left < theother._left;
   return _right < theother._right;
}

bool CConstraint::operator == (const CConstraint &theother) const
{
   return *_right == *theother._right && *_left == *theother._left && _relop == theother._relop;
}

const CConstraint & CConstraint::operator = (const CConstraint &theother)
{
   Copy(theother);
   return *this;
}

void CConstraint::Print(std::ostream *o) const {
   (*o) << _left->tostring();
   switch (_relop) {
   case RELOP_LT:
      (*o) << " < ";
      break;
   case RELOP_LTEQ:
      (*o) << " <= ";
      break;
   case RELOP_GT:
      (*o) << " > ";
      break;
   case RELOP_GTEQ:
      (*o) << " >= ";
      break;
   case RELOP_EQ:
      (*o) << " = ";
      break;
   case RELOP_NEQ:
      (*o) << " != ";
      break;
   }
   (*o) << _right->tostring();
}

