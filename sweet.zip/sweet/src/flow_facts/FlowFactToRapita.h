#ifndef FLOW_FACT_TO_RAPITA_H_INLUDED
#define FLOW_FACT_TO_RAPITA_H_INLUDED

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <utility>

class CSourceLoader;
class SortedRapitaLoops;
class RapitaLoop;
class CContextSensitiveValidAtEntryOfFlowFact;
class CFlowGraph;
class CFlowGraphNode;
class CSourceLoader;
class CFlowGraphNode;
class CGenericFunction;

#include "graphs/components/CComponent.h"
#include "graphs/components/CComponentTree.h"

/// ////////////////////////////////////////////////////////////////////////////
/// \class RapitaLoops
///     Represents a set of loops where each loop is associated with a label
/// ////////////////////////////////////////////////////////////////////////////
class RapitaLoops
{
public:
   /// Prints the flow facts of this set of Rapita Loop bounds on the Rapita format
   /// specifying loops by loop numbers in the source code
   void Print(std::string (*Unmangle)(std::string), std::ostream &o);

   /// Adds all loops to this Rapita loop bounds.
   void AddLoops(SortedRapitaLoops &loops);

   /// Assign Bounds to all loops in this Rapita loop bound with the flow facts found in rffs.
   void AssignBoundsToLoops(std::map<const CFlowGraphNode*, std::vector<CContextSensitiveValidAtEntryOfFlowFact *> > &rffs);

   /// To get the rapita loop that is associated to a certain alf label
   const RapitaLoop * GetRapitaLoopOfAlfLabel(std::string alf_label); 

   // To get the internal mapping
  const std::map<std::string, RapitaLoop*> * GetLabelToRapitaLoopMap() const { return &label_to_loop; }

private:
   std::map <std::string, RapitaLoop*> label_to_loop;
};

typedef class CAlfLabelSource CodePoint;

/// ////////////////////////////////////////////////////////////////////////////
/// \class RapitaLoop
///     Represents one loop
/// ////////////////////////////////////////////////////////////////////////////
class RapitaLoop
{
public:
   /// Constructs a loop. Keeps a reference to the component.
   RapitaLoop(CComponent<CFlowGraphNode> *component, CSourceLoader *source_loader) :
     component(component),
     sequence_number(0),
     upper_bound(0),
     function(NULL),
     nr_of_dropped_sub_loops(0),
     src(FirstCodePoint(component, source_loader)) {}
  
  // Print the loop bound of this loop using the rapita annotation format
  void Print(std::string (*Unmangle)(std::string), std::ostream &o);
  
  // Assigns various data to this loop
  void AssignCodePoint(const CodePoint *code_point) { src = code_point; }
  void AssignNrOfDroppedSubLoops(unsigned n) { nr_of_dropped_sub_loops = n; }
  void AssignSequenceNumber(unsigned number) { sequence_number = number; }
  void AssignFunction(CGenericFunction *func) { function = func; }
  void AssignBound(int ub);
  
  // Returns various data concerning this loop
  unsigned GetSourceLine() const;
  const CComponent<CFlowGraphNode> *GetComponent() const { return component; }
  const CodePoint *GetCodePoint() const { return src; }
  unsigned GetNrOfDroppedSubLoops() const { return nr_of_dropped_sub_loops; }
  unsigned GetSequenceNumber() const { return sequence_number; }
  const CGenericFunction * Function() const { return function; }
  
private:
  const CodePoint *FirstCodePoint(CComponent<CFlowGraphNode> *loop, CSourceLoader *source_loader) const;
  CComponent<CFlowGraphNode> *component;
  unsigned sequence_number;
  int upper_bound;
  CGenericFunction *function;
  unsigned nr_of_dropped_sub_loops;
  const CodePoint *src;
};

// To create Rapita loops and their flow facts. If the last argument is
// NULL, no flow facts will be generated.
void
CollectRapitaLoops(const std::vector<CFlowGraph*> &flow_graphs,
                   CSourceLoader *source_loader, RapitaLoops &rapita_loops,
                   std::vector<CContextSensitiveValidAtEntryOfFlowFact *> * ffs = NULL);

#endif

