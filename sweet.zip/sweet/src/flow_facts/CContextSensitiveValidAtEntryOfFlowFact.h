/* -*-c++-*- */

//----------------------------------------------------------------------
//
//  THIS FILE:
//
// ----------------------------------------------------------------------
//
//  $Id: $
//
// ----------------------------------------------------------------------

#ifndef CCONTEXTSENSITIVEVALIDATENTRYOFFLOWFACT_H_
#define CCONTEXTSENSITIVEVALIDATENTRYOFFLOWFACT_H_

// Standard includes
#include <iostream>
#include <fstream>
#include <vector>
#include <map>

#include "CFlowFact.h"

class CFFCollector;
class CConstraint;
class CGenericStmt;
class CGenericFunction;

// -------------------------------------------------------
// CContextSensitiveValidAtEntryOfFlowFact -
// Class representing so called "context-sensitive valid-at-entry-of 
// flow facts". Each generated flow fact has the following format:
//
// CALL_STRING : VALID_AT_ENTRY_OF : SUM_OR_ITER : CONSTRAINT
//
// - CALL_STRING is a list of function calls that must have been made for
//   the flow fact to hold. The calls start with the program start function.
//   The call string is represented as a list of 
//   <<calling_func, calling_stmt>, called_func> tuples.
//
// - VALID_AT_ENTRY_OF is a function or a loop in a function. The flow
//   fact should hold each time the given function or loop is entered.
//   It provides a way to give flow information in a local or global
//   context. The valid_at_entry_of is represented as a <func, stmt> tuple. 
//   If stmt == NULL then it refers to a function, otherwise a loop header.
//
// - FOREACH_OR_TOTAL is <>, <i..j> (foreach type) or [] (total type). 
//   -- Foreach <> are associated to iterations of loops, and specifies
//      that the flow fact should be valid for each individual iteration
//      of the loop specified in VALID_AT_ENTRY_OF.
//   -- Foreach <i..j> specifies that that flow fact should hold for each 
//      individual iteration starting at the i:th iteration of the loop and 
//      ending at the j:th iteration of the loop given in VALID_AT_ENTRY_OF. 
//   -- Total [] can be associated both to a function or a loop, and 
//      specifies that the flow fact should be valid for all entity executions 
//      within the function or loop given in VALID_AT_ENTRY_OF. 
//
// - CONSTRAINT is a linear constraint relating the execution of program
//    entities, such as nodes, (e.g., #BB0) or edges, (e.g., #BB0->BB1) in the
//    program CFGs to integer constants. It is only possible to refer to 
//    code entities reachable from the VALID_AT_ENTRY_OF loop or function, 
//    without leaving the given loop or function. 
// -------------------------------------------------------
class CContextSensitiveValidAtEntryOfFlowFact 
{
public:
   typedef std::vector<std::pair<std::pair<CGenericFunction *, CGenericStmt *>, CGenericFunction *> > CallStringType;

   // ---------------------------------
   // Fo creating and deleting the flow fact
   // ---------------------------------

   // For creating the flow fact
   CContextSensitiveValidAtEntryOfFlowFact(CallStringType call_string,
                                           std::pair<CGenericFunction *, CGenericStmt *> valid_at_entry_of, 
                                           CFFCollector * collector, CConstraint * constraint,
                                           CFlowFact::t_flowfacttype ff_type);

   // For deleting the flow fact
   ~CContextSensitiveValidAtEntryOfFlowFact();

   // ---------------------------------
   // To get access to the internal parts of the ff
   // ---------------------------------

   // The call string is represented as a list of <<calling_func,calling_stmt>, called_func>
   const CallStringType * CallString() const { return &_call_string; }
   // The valid_at_entry_of is represented as a <func, stmt> tuple.
   // If stmt == NULL then it refers to a function, otherwise a loop header.
   const std::pair<CGenericFunction *, CGenericStmt *> * ValidAtEntryOf() const { return &_valid_at_entry_of; }
   // The ffcollector is either [], <> or <i..j>
   const CFFCollector * FFCollector() const { return _ffcollector; }
   // The constraint is a linear constraint relating the execution of program
   // entities, such as nodes, (e.g., #BB0) or edges, (e.g., #BB0->BB1) in the
   // program CFGs to integer constants.
   CConstraint * Constraint() { return _constraint; }
   // The type of flow fact, giuves what flow fact generating algorithm
   // that have been used to generate the ff. When printing the ff an
   // extra informative comment about this is printed.
   CFlowFact::t_flowfacttype Type() const { return _ff_type; }

   // To get if the flow fact is fully context sensitive.
   bool IsFullyContextSensitive(CGenericFunction * cg_root_func) const;
   // To get if the flow fact is not context sensitive at all.
   bool IsZeroContextSensitive() const;
   // To get of the valid at entry of refers to a loop or a function.
   bool IsValidAtEntryOfLoop() const;
   bool IsValidAtEntryOfFunction() const;

  // ---------------------------------
  // For printing the flow fact
  // ---------------------------------

  void Print(std::ostream *o=&std::cout);
  friend std::ostream & operator << (std::ostream &o, CContextSensitiveValidAtEntryOfFlowFact &ff);

protected:

  // ---------------------------------
  // Internals
  // ---------------------------------

  // List of <<calling_func, calling_site>, called_func> tuples
   CallStringType _call_string; 
  // Point from which the fact should be valid. If stmt is func entry
  // node, then the fact is valid for each entry of func. If stmt is loop 
  // header node, then the fact is valid for each entry of loop.
  std::pair<CGenericFunction *, CGenericStmt *> _valid_at_entry_of;
  // Collector can be foreach <>, <i..j> or total [], [i..j]
  CFFCollector * _ffcollector;
  // The linear constraint 
  CConstraint * _constraint;
  // The type of the flow fact
  CFlowFact::t_flowfacttype _ff_type;
};


#endif
