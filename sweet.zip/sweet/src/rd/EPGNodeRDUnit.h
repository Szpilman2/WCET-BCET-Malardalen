#ifndef EPGNODERDUNIT_H_
#define EPGNODERDUNIT_H_

#include "rd/RDUnit.h"
#include "alf_slicing/ALFExtendedProgramGraphNode.h"
#include <iostream>
#include <fstream>

// -------------------------------------------------------
// RDUnits which include an ALF Extended Program Graph Node. Inherits
// most functionality from RDUnit class.
// 5-----
class EPGNodeRDUnit : public RDUnit
{
public:

  // The key is an index uniquely identifying the rd unit. If a
  // variable is given The RDUnit is making a definition. If the
  // variable set to be a kill it will also kill all previous
  // definitions of the variable reaching the given RD unit.
  EPGNodeRDUnit(ALFExtendedProgramGraphNode * epg_node, unsigned int key);
  EPGNodeRDUnit(ALFExtendedProgramGraphNode * epg_node, unsigned int key, unsigned int var, bool is_kill=false);
  ~EPGNodeRDUnit() {};

  // To get the included node
  ALFExtendedProgramGraphNode * GetEPGNode();
  
  // To print and draw the rd unit
  void Print(std::ostream & s = std::cout) const;
  void Draw(std::ostream & s = std::cout) const;
    
protected:

  // Internal pointer to a EPG node
  ALFExtendedProgramGraphNode * _epg_node;
};


#endif
