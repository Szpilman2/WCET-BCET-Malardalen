#ifndef REACHINGDEFINITIONSANSLYSIS_H_
#define REACHINGDEFINITIONSANSLYSIS_H_

#include "dfa/DataFlowAnalysis.h"
#include "ae/CBitVector.h"
#include "rd/RDUnit.h"

#include <set>
#include <vector>
#include <iostream>

// -------------------------------------------------------
// Reachingdefinitionsanslysis - General class for doing reaching
// definitions (RD) analysis. Inherits a lof of functionality from the
// DataFlowAnalysis template, including methods to do the fic point
// analysis. To be inherited from when doing RD analysis for a certain
// language.

// The RD analysis is useful when we want to derfive what definitions
// of a variable that MAY reach a certain program point. It is a MAY
// analysis, meaning that if the variable MAY be defined at a certain
// program point p1 and the definition MAY not be overwritten before
// another program point p2, then the analysis will report that p1's
// definition is included in p2's reaching definitions.
// 
// The analysis make use of the class RDUnit. Each program construct,
// such as a statement, which may define a variable is then associated
// with a RD unit. The RDUnit holds the index of the variable it may
// define. Each RDUnit can at most hold one variable definition. If a
// program construct may do several defines (e.g using dereferencing
// pointers) several RD units may be associated with one program
// construct. This allow us to differ between how far different
// defines made by the same program construct may reach. 

// Each RDUnit is given a unique index (an unsigned int). The analysis
// state is a bit vector (CBitVector) with one bit (0 or 1) per
// RDUnit. If a RDUnit j has a input state (bit vector) with the i:th
// bit set to 1 a definition made at RDUnit i may reach j. There may
// exist RD units with no definitions. If a variable value is surely
// overwritten by a definition, the RD Unit is a killing unit,
// basically removing all definitions of the same variable that may
// reach the unit.

// Illustrating example:        
//
// Stms and RD Units                       States 
// -----------------------------           --------------------------------
// stmt0 --- RDUnit0 - def var72           before: <000000> after: <000001>
//       |-- RDUnit1 - def var35           before: <000001> after: <000011>
// stmt1 --- RDUnit2                       before: <000011> after: <000011>
// stmt2 --- RDUnit3 - def var72 - iskill  before: <000011> after: <001010> 
//       |-- RDUnit4 - def var6            before: <001010> after: <011010>
// stmt3 --- RDUnit0 - def var72           before: <011010> after: <111010> 
//
// If a RDUnit has bit 0 set, e.g.  <000001> it means that the
// definition made at RDUnit0 may reach this RDUnit.
//
// -------------------------------------------------------
class ReachingDefinitionsAnalysis : public DataFlowAnalysis<RDUnit, CBitVector>
{
public:
  
  // To create and delete the RD analysis. The sets are owned by the
  // caller while rd_units and the the bit vector states are owned by
  // the RD analysis.
  ReachingDefinitionsAnalysis(const std::set<std::pair<RDUnit *, CBitVector * > > * rd_units_to_input_state,
                              const std::set<std::pair<RDUnit *, CBitVector * > > * rd_units_to_output_state,
                              const std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units);
  
  // Will kill all RD units and the bit vectors
  virtual ~ReachingDefinitionsAnalysis();

  // To get all the RDUnits with definitions which MAY reach a given RDUnit.
  void GetDefinitionsReachingRDUnit(const RDUnit * rd_unit, std::vector<RDUnit *> * def_rd_units)
  { GetDefinitionsReachingRDUnitInputState(rd_unit, def_rd_units); }

  // To get all the RDUnits which MAY define the given variable and
  // whose definitions MAY reach the given RDUnit
  void GetDefinitionsOfVarReachingRDUnit(const RDUnit * rd_unit, unsigned int var, std::vector<RDUnit *> * def_rd_units)
  { GetDefinitionsOfVarReachingRDUnitInputState(rd_unit, var, def_rd_units); }

  // To get all RDUnits that MAY define a given variable
  const std::set<RDUnit *> * GetRDUnitsDefiningVar(unsigned int var);
  void GetRDUnitsDefiningVar(unsigned int var, std::vector<RDUnit *> * def_rd_units);

  // Virtual function to get the type of the analysis
  virtual std::string AnalysisName(void) const { return "ReachingDefinitionsAnalysis"; };

protected:  

  // ---------------------------------
  // Useful functions 
  // ---------------------------------
  
  // To get all the RDUnits whose definitions reach the input and
  // output state of a given RDUnit.
  void GetDefinitionsReachingRDUnitInputState(const RDUnit * rd_unit, std::vector<RDUnit *> * def_rd_units);
  void GetDefinitionsReachingRDUnitOutputState(const RDUnit * rd_unit, std::vector<RDUnit *> * def_rd_units);

  // To get all the RDUnits whose definitions of a given variable
  // reach the input and output state of a given RDUnit.
  void GetDefinitionsOfVarReachingRDUnitInputState(const RDUnit * rd_unit, unsigned int var, std::vector<RDUnit *> * def_rd_units);
  void GetDefinitionsOfVarReachingRDUnitOutputState(const RDUnit * rd_unit, unsigned int var, std::vector<RDUnit *> * def_rd_units);

  // Help function to get the rd_units corresponding to bits in the state
  void GetRDUnitsFromBitVector(const CBitVector * state, std::vector<RDUnit *> * def_rd_units);

  // Help function to get the rd_units corresponding to bits in the
  // state which are also defining the given var
  void GetRDUnitsDefiningVarFromBitVector(const CBitVector * state, unsigned int var, std::vector<RDUnit *> * def_rd_units);

  // To get the input and output state vector with the indexes of the
  // rd_unit which have definitions that may reach the given
  // rd_unit. Mostly for debugging purposes.
  const CBitVector * GetInputState(RDUnit * rd_unit);
  const CBitVector * GetOutputState(RDUnit * rd_unit);

  // ---------------------------------
  // Help functions for which code bodies must be provided 
  // ---------------------------------

  // To perform out_state[n] = transfer(in_state[n]). 
  CBitVector * Transfer(const CBitVector * in_state, RDUnit * rd_unit);

  // To perform in_state[n] = join_{p in predecessor(n)}(out_state[p]).
  // Will merge several out states into an in_state. 
  CBitVector * Join(const std::set<CBitVector *> * out_states);

  // Help function to decide if two states are equal
  bool AreEqual(const CBitVector *state1, const CBitVector *state2);

  // Help function to delete a state
  void Delete(CBitVector *state);

  // Help functions to print a state and a stmt 
  void PrintState(const CBitVector *state, std::ostream & s = std::cout) const;
  void PrintNode(const RDUnit * rd_unit, std::ostream & s = std::cout) const;
  
  // Help functions to draw a state and a stmt 
  void DrawState(const CBitVector *state, std::ostream & s = std::cout) const;
  void DrawNode(const RDUnit * rd_unit, std::ostream & s = std::cout) const;

private:

  // -------------------------------------------------------
  // Functions that must be provided, but are not used.
  // -------------------------------------------------------
  void Transfer(const CBitVector * in_state, RDUnit * rd_unit, 
                std::map<RDUnit *, CBitVector *> *rd_unit_to_out_state_map) { };
  CBitVector * Widen(const CBitVector *state_prev_iter, const CBitVector *state_current_iter) {return NULL;};
  CBitVector * Narrow(const CBitVector *state_prev_iter, const CBitVector *state_current_iter) {return NULL;};

protected:

  // -------------------------------------------------------
  // Data structures needed for this particular RD analysis 
  // -------------------------------------------------------
  
  // A mapping from RD unit key to rd_unit (for fast lookup from BitVector)
  std::vector<RDUnit *> _key_to_rd_unit;

  // A mapping from variable to defining RD units
  std::vector<std::set<RDUnit *> *> _var_to_defining_rd_units;
    
  // Holds largest possible variable index
  unsigned int _max_var;

  // Holds largest possible rd_unit index
  unsigned int _max_key;

};

#endif

