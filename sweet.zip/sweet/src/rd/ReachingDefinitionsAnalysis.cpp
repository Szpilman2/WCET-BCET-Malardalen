#include "rd/ReachingDefinitionsAnalysis.h"
#include "dfa/DataFlowAnalysis.inl"

// To create a reaching definition analysis 
ReachingDefinitionsAnalysis::
ReachingDefinitionsAnalysis(const std::set<std::pair<RDUnit *, CBitVector * > > * rd_unit_to_input_state,
                            const std::set<std::pair<RDUnit *, CBitVector * > > * rd_unit_to_output_state,
                            const std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units)	
  : DataFlowAnalysis<RDUnit, CBitVector>(rd_unit_to_input_state, rd_unit_to_output_state, rd_unit_to_succ_rd_units)
{
  // ---------------------------------
  // Update needed data structures
  // ---------------------------------

  // initialize local state vars
  _max_var = 0;
  _max_key = 0;
  
  // Extract largest keys and variable indexes 
  bool first_key = true;
  for(std::set<RDUnit *>::iterator rd_unit = _nodes.begin(); rd_unit != _nodes.end(); ++rd_unit) {    
    // Update key to rd_unit vector
    unsigned int key = (*rd_unit)->GetKey();
    if(key > _max_key || first_key) 
      { _max_key = key; first_key = false; }
    // Update var to defining rd_units map
    if((*rd_unit)->HasVar()) {
      unsigned int var = (*rd_unit)->GetVar();
      if(var > _max_var) _max_var = var;
    }
  }

  // Initialize vector with empty RD unit sets
  for(unsigned int var = 0; var <= _max_var; var++) {
    _var_to_defining_rd_units.push_back(new std::set<RDUnit *>);
  }

  // Make sure the vector is large enough to contain all rd units
  _key_to_rd_unit.resize(_max_key+1);

  // Update vectors with appropriate values 
  for(std::set<RDUnit *>::iterator rd_unit = _nodes.begin(); rd_unit != _nodes.end(); ++rd_unit) {    
    // Update key to rd_unit vector
    unsigned int key = (*rd_unit)->GetKey();
    _key_to_rd_unit[key] = (*rd_unit);
    // Update var to defining rd_units map
    if((*rd_unit)->HasVar()) {
      unsigned int var = (*rd_unit)->GetVar();
      _var_to_defining_rd_units[var]->insert(*rd_unit);
    }
  }
}

  

// To delete a reaching definitions analysis
ReachingDefinitionsAnalysis::
~ReachingDefinitionsAnalysis() 
{
  // All bit vector states will be deleted by the parent class
  
  // Delete all sets of rd units associated with vars
  for(unsigned int var = 0; var <= _max_var; var++) {
    delete _var_to_defining_rd_units[var];
  }

  // Delete all rd_units
  for(std::set<RDUnit *>::iterator rd_unit = _nodes.begin(); rd_unit != _nodes.end(); ++rd_unit) {  
    delete *rd_unit;
  }
}


// To get all RDUnits that MAY define a given variable
const std::set<RDUnit *> *
ReachingDefinitionsAnalysis::
GetRDUnitsDefiningVar(unsigned int var)
{
  return _var_to_defining_rd_units[var];
}

void 
ReachingDefinitionsAnalysis::
GetRDUnitsDefiningVar(unsigned int var, std::vector<RDUnit *> * def_rd_units)
{
  // Extract the set of rd_unit pointers and copy all pointers to
  // argument vector
  std::set<RDUnit *> * rd_units =  _var_to_defining_rd_units[var];
  for(std::set<RDUnit *>::iterator rd_unit = rd_units->begin();
      rd_unit != rd_units->end(); rd_unit++) {
    def_rd_units->push_back(*rd_unit);
  }
}

void
ReachingDefinitionsAnalysis::
GetDefinitionsReachingRDUnitInputState(const RDUnit * rd_unit, std::vector<RDUnit *> * def_rd_units)
{
  // Get the input vector of the rd_unit
  const CBitVector * in_state = GetInputState(const_cast<RDUnit *>(rd_unit));
  // Derive the corresponding rd_units
  GetRDUnitsFromBitVector(in_state, def_rd_units);
}

void
ReachingDefinitionsAnalysis::
GetDefinitionsReachingRDUnitOutputState(const RDUnit * rd_unit, std::vector<RDUnit *> * def_rd_units)
{
  // Get the output vector of the rd_unit
  const CBitVector * in_state = GetOutputState(const_cast<RDUnit *>(rd_unit));
  // Derive the corresponding rd_units
  GetRDUnitsFromBitVector(in_state, def_rd_units);
}

void
ReachingDefinitionsAnalysis::
GetDefinitionsOfVarReachingRDUnitInputState(const RDUnit * rd_unit, unsigned int var, std::vector<RDUnit *> * def_rd_units)
{
  // Get the input vector of the rd_unit
  const CBitVector * in_state = GetInputState(const_cast<RDUnit *>(rd_unit));
  // Derive the corresponding rd_units
  GetRDUnitsDefiningVarFromBitVector(in_state, var, def_rd_units);
}

void
ReachingDefinitionsAnalysis::
GetDefinitionsOfVarReachingRDUnitOutputState(const RDUnit * rd_unit, unsigned int var, std::vector<RDUnit *> * def_rd_units)
{
  // Get the output vector of the rd_unit
  const CBitVector * in_state = GetOutputState(const_cast<RDUnit *>(rd_unit));
  // Derive the corresponding rd_units
  GetRDUnitsDefiningVarFromBitVector(in_state, var, def_rd_units);
}

void
ReachingDefinitionsAnalysis::
GetRDUnitsFromBitVector(const CBitVector * state, std::vector<RDUnit *> * def_rd_units)
{
  // Go through all elements in the bitvector
  unsigned int nr_of_bits = state->SizeInBits();
  for(unsigned int i = 0; i < nr_of_bits; i++) {
    // If the vector has the index of the rd_unit, then we add the
    // corresponcing rd_unit to the vector to return
    if(state->ElementExists(i)) {
      RDUnit * rd_unit = _key_to_rd_unit[i];
      def_rd_units->push_back(rd_unit);
    }
  }
}    

void
ReachingDefinitionsAnalysis::
GetRDUnitsDefiningVarFromBitVector(const CBitVector * state, unsigned int var, std::vector<RDUnit *> * def_rd_units)
{
  // Go through all elements in the bitvector
  unsigned int nr_of_bits = state->SizeInBits();
  for(unsigned int i = 0; i < nr_of_bits; i++) {
    // If the vector has the index of the rd_unit and it defines the
    // given var, then we add the rd_unit to the vector to return
    if(state->ElementExists(i)) {
      RDUnit * rd_unit = _key_to_rd_unit[i];
      if(rd_unit->HasVar() && rd_unit->GetVar() == var) {
	def_rd_units->push_back(rd_unit);
      }
    }
  }
}

const CBitVector *
ReachingDefinitionsAnalysis::
GetInputState(RDUnit * rd_unit)
{
  return InState(rd_unit);
}


const CBitVector *
ReachingDefinitionsAnalysis::
GetOutputState(RDUnit * rd_unit)
{
  return OutState(rd_unit);
}


// Join of output states is an OR of the bit vectors. 
CBitVector * 
ReachingDefinitionsAnalysis::
Join(const std::set<CBitVector *> * out_states) 
{
  CBitVector * join_vector = (*(out_states->begin()))->Copy();
  if(out_states->size() == 1) { 
    // Return a copy of the input bit vector 
    return join_vector;
  }
  else {
    // Return a bitwise or:ed bit vector
    std::set<CBitVector *>::const_iterator os = out_states->begin();
    for(os++; os != out_states->end(); ++os)
      (*join_vector) += (*os);
    return join_vector;
  }
}

// The transfer function makes the kills and the defines according to 
// the given rd unit. out_state = Transfer(in_state)
CBitVector * 
ReachingDefinitionsAnalysis::
Transfer(const CBitVector * in_state, RDUnit * rd_unit)
{
  // Create a new state to return
  CBitVector * out_state = in_state->Copy();

  // If the unit is a gen unit 
  if(rd_unit->HasVar()) {
    // Get the associated key
    unsigned int key = rd_unit->GetKey();
    
    // If the unit is a kill unit we should first kill all defines with
    // the same variable that in the state.
    if (rd_unit->IsKill()) {
      
      // Get the variable the unit defines
      unsigned int var = rd_unit->GetVar();
      
      // Get all the units that define this variable
      const std::set<RDUnit *> * def_rd_units = _var_to_defining_rd_units[var];
      // Loop through all of them and remove their keys from the out state
      for(std::set<RDUnit *>::const_iterator drdu = def_rd_units->begin(); 
	  drdu != def_rd_units->end(); drdu++) {
         out_state->RemoveElement((*drdu)->GetKey());
      }
    }
    
    // Finally, add the new definition to the out state
    out_state->AddElement(key);
  }

  // Return the updated state
  return out_state;
}

// To check if two states (i.e. bit-vectors) are equal
bool 
ReachingDefinitionsAnalysis::
AreEqual(const CBitVector *state1, const CBitVector *state2)
{
  return state1->IsEqual(state2);
}

// To delete a state (i.e. a bit-vector) 
void 
ReachingDefinitionsAnalysis::
Delete(CBitVector *state)
{
  delete state;
}

// To print a state 
void 
ReachingDefinitionsAnalysis::
PrintState(const CBitVector *state, std::ostream & s) const
{
  state->PrintBinary(&s);
}

// To print a node
void 
ReachingDefinitionsAnalysis::
PrintNode(const RDUnit * rd_unit, std::ostream & s) const
{
  rd_unit->Print(s);
}

void 
ReachingDefinitionsAnalysis::
DrawState(const CBitVector *state, std::ostream & s) const
{
  state->PrintBinary(&s);
}

void 
ReachingDefinitionsAnalysis::
DrawNode(const RDUnit * rd_unit, std::ostream & s) const
{
  rd_unit->Draw(s);
}

