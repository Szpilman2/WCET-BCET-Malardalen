#include "rd/ALFReachingDefinitionsAnalysisBuilder.h"
// #include "program/alf/CInitTuple.h"
// #include "program/alf/CRefTuple.h"
// #include "program/alf/CIntNumValTuple.h"
// #include "program/alf/ANumVal.h"
// #include "program/alf/CNumber.h"
// #include "program/alf/CExprList.h"
// #include "program/alf/COpNumExprTuple.h"
// #include "program/alf/CAddrTuple.h"
// #include "program/alf/CFRefTuple.h"
// #include "program/alf/CCompAddrTuple.h"
// #include "program/alf/CLoadExprTuple.h"
// #include "symtab/CSymTabEntry.h"
// #include "symtab/CSymTabBase.h"
// #include "symtab/CSymTabIdentifier.h"
// #include "ptranal/CSteensgaardPA.h"
// #include "program/alf/CAlfTreeFilter.h"
// #include "tools/StrStream.h"

// -------------------------------------------------------
// To create and delete the builder class
// -------------------------------------------------------

// To create the RD analysis builder class
ALFReachingDefinitionsAnalysisBuilder::
ALFReachingDefinitionsAnalysisBuilder()
{
  // Most stuff made in generate function
}

// To delete the RD analysis builder class
ALFReachingDefinitionsAnalysisBuilder::
~ALFReachingDefinitionsAnalysisBuilder()
{
  // Nothing is owned by the class
}

// -------------------------------------------------------
// To build an ALFReachingDefinitionsAnalysis object from an ALF extended program 
// control flow graph. 
// -------------------------------------------------------
ALFReachingDefinitionsAnalysis *
ALFReachingDefinitionsAnalysisBuilder::
Build(ALFExtendedProgramControlFlowGraph * epcfg, ALFDefsAndUsesAnalysis * du)
{
  assert(epcfg);
  assert(du);

  // To keep track of number of rd units created
  _rd_unit_key = 0;

  // Create rd units from the graph. Create connection from
  // EPFG nodes to a vector of rd units.
  std::set<std::pair<RDUnit *, RDUnit *> > rd_unit_to_succ_rd_units;
  std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *> * node_to_rd_units =
    new std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *>;
  CreateRDUnitsFromEPCFG(epcfg, du, node_to_rd_units, &rd_unit_to_succ_rd_units);

  // Create input and output states for rd units
  std::set<std::pair<RDUnit *, CBitVector *> > rd_unit_to_input_state;
  std::set<std::pair<RDUnit *, CBitVector *> > rd_unit_to_output_state;
  CreateStatesForRDUnits(&rd_unit_to_input_state, &rd_unit_to_output_state);

  // Create and return the RD analysis object. Gives away the created mapping to the RD analysis.
  return new ALFReachingDefinitionsAnalysis(&rd_unit_to_input_state, &rd_unit_to_output_state, 
  					    &rd_unit_to_succ_rd_units, node_to_rd_units);  
}

// -------------------------------------------------------
// To create and connecting a set of rd units according to 
// the things accessible from a call graph 
// -------------------------------------------------------
void 
ALFReachingDefinitionsAnalysisBuilder::
CreateRDUnitsFromEPCFG(ALFExtendedProgramControlFlowGraph * epcfg, ALFDefsAndUsesAnalysis * du,
		       std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *> * node_to_rd_units,
		       std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units)
{
  // Create rd units for all EPCFG nodes. 
  CreateRDUnitsForEPCFGNodes(epcfg, du, node_to_rd_units);

  // Create connections between RD units according to the vector
  // associated with each epcfg node
  ConnectRDUnitsInVectors(node_to_rd_units, rd_unit_to_succ_rd_units);

  // Create connections between RD units according to the pred,succ pairs in
  // the epcfg graphs
  ConnectRDUnitsAccordingToEPCFGEdges(epcfg, node_to_rd_units, rd_unit_to_succ_rd_units);
}

void 
ALFReachingDefinitionsAnalysisBuilder::
CreateRDUnitsForEPCFGNodes(ALFExtendedProgramControlFlowGraph * epcfg, ALFDefsAndUsesAnalysis * du,
			   std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *> * node_to_rd_units)
{
  // Loop through all the nodes in the epcfg 
  for(ALFExtendedProgramControlFlowGraph::node_iterator epg_node = epcfg->NodesBegin(); 
      epg_node != epcfg->NodesEnd(); ++epg_node) {
    // A vector for created rd units 
    std::vector<RDUnit *> * rd_units = new std::vector<RDUnit *>;
  
    // Create the rd units
    CreateRDUnitsForEPGNode(*epg_node, du, rd_units);

    // Update maps with vectors
    (*node_to_rd_units)[*epg_node] = rd_units;
  }
}

// -------------------------------------------------------
// To create rd units for a CFG node. Will also create rd units
// annots, global decls and inits, local decls, function arguments,
// etc. Each created rd unit will be stored in the vector of rd units.
// -------------------------------------------------------
void 
ALFReachingDefinitionsAnalysisBuilder::
CreateRDUnitsForEPGNode(ALFExtendedProgramGraphNode * epg_node, ALFDefsAndUsesAnalysis * du, 
			std::vector<RDUnit *> * rd_units)
{
  // To hold variable defines possible generated and/or killed by du unit
  std::set<unsigned int> gen_defs;
  std::set<unsigned int> kill_defs;

  // Use the def and use analysis to get generating kills and defines of the rd unit 
  du->GetGenAndKillDefsOfEPGNode(epg_node, &gen_defs, &kill_defs);	
 
  if(gen_defs.size() + kill_defs.size() == 0) {
    // If no defines we create an non-generating RD unit
    RDUnit * rd_unit = CreateNonGeneratingEPGNodeRDUnit(epg_node);
    rd_units->push_back(rd_unit);
  }
  else {
    // Create rd units according to the kills and defines

    // Loop through the generating vars to create corresponding RD units 
    for(std::set<unsigned int>::iterator d = gen_defs.begin(); d != gen_defs.end(); ++d) {
      RDUnit * rd_unit = CreateGeneratingEPGNodeRDUnit(epg_node, *d);
      rd_units->push_back(rd_unit);
    }
  
    // Loop through the killing vars to create corresponding RD units 
    for(std::set<unsigned int>::iterator d = kill_defs.begin(); d != kill_defs.end(); ++d) {
      RDUnit * rd_unit = CreateKillingEPGNodeRDUnit(epg_node, *d);
      rd_units->push_back(rd_unit);
    }
  }
}

// -------------------------------------------------------
// Help functions for connecting all pred,succ pairs in a list
// -------------------------------------------------------
void
ALFReachingDefinitionsAnalysisBuilder::
ConnectRDUnitsInVectors(std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *> * node_to_rd_units,
			std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units)
{
  // Loop through all mappings 
  for(std::map<ALFExtendedProgramGraphNode *, vector<RDUnit *> *>::iterator n2u = node_to_rd_units->begin();
      n2u != node_to_rd_units->end(); ++n2u) {
    std::vector<RDUnit *> * rd_units = (*n2u).second;
    ConnectRDUnitsInVector(rd_units, rd_unit_to_succ_rd_units);
  }
}

// Create connections between RD units according to the vector
// associated with each epg node. 
void
ALFReachingDefinitionsAnalysisBuilder::
ConnectRDUnitsInVector(std::vector<RDUnit *> * rd_units, 
		       std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units)
{
  for(std::vector<RDUnit *>::const_iterator rd_unit = rd_units->begin();
      rd_unit != rd_units->end(); ++rd_unit) {
    std::vector<RDUnit *>::const_iterator next_rd_unit = rd_unit;
    ++next_rd_unit;
    if(next_rd_unit != rd_units->end()) {
      rd_unit_to_succ_rd_units->insert(std::make_pair(*rd_unit, *next_rd_unit));
    }
  }
}   

// -------------------------------------------------------
// Create connections between RD units according to the pred,succ pairs in
// the epcfg graph
// -------------------------------------------------------
void
ALFReachingDefinitionsAnalysisBuilder::
ConnectRDUnitsAccordingToEPCFGEdges(ALFExtendedProgramControlFlowGraph * epcfg, 
				    std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *> * node_to_rd_units, 
				    std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units)
{
  // Get the edges of the epcfg
  ALFExtendedProgramControlFlowGraph::T_edge_list edges;
  epcfg->Edges(&edges);

  // Loop through all edges 
  for(ALFExtendedProgramControlFlowGraph::T_edge_list_iterator e = edges.begin(); e != edges.end(); ++e ) {

    // Get the edge data 
    ALFExtendedProgramGraphNode * from_node = (*e).from;
    ALFExtendedProgramGraphNode * to_node = (*e).to;

    // Get the rd_units of the from and to nodes
    std::vector<RDUnit *> * from_rd_units = (*node_to_rd_units)[from_node];
    std::vector<RDUnit *> * to_rd_units = (*node_to_rd_units)[to_node];
    assert(from_rd_units->size() > 0);
    assert(to_rd_units->size() > 0);

    // Connect last rd_unit of the from node with the first rd_unit of the to node 
    RDUnit * last_from_rd_unit = *(from_rd_units->rbegin());
    RDUnit * first_to_rd_unit = *(to_rd_units->begin());
    rd_unit_to_succ_rd_units->insert(std::make_pair(last_from_rd_unit, first_to_rd_unit));
  }
}

// -------------------------------------------------------
// To create input and output states for all rd units
// -------------------------------------------------------
void
ALFReachingDefinitionsAnalysisBuilder::
CreateStatesForRDUnits(std::set<std::pair<RDUnit *, CBitVector *> > * rd_unit_to_input_state,
		       std::set<std::pair<RDUnit *, CBitVector *> > * rd_unit_to_output_state)
{
  for(std::vector<RDUnit *>::iterator rd_unit = _rd_units.begin();
      rd_unit != _rd_units.end(); ++rd_unit) {
    (*rd_unit_to_input_state).insert(std::make_pair(*rd_unit, new CBitVector(_rd_unit_key+1)));
    (*rd_unit_to_output_state).insert(std::make_pair(*rd_unit, new CBitVector(_rd_unit_key+1)));
  }
}

// -------------------------------------------------------
// Help functions for creating EPGNodeRDUnits 
// -------------------------------------------------------

// To create a RD unit which do not result in any variable definitions
RDUnit *
ALFReachingDefinitionsAnalysisBuilder::
CreateNonGeneratingEPGNodeRDUnit(ALFExtendedProgramGraphNode * epg_node)
{
  EPGNodeRDUnit * rd_unit = new EPGNodeRDUnit(epg_node,_rd_unit_key);
  _rd_unit_key++;
  _rd_units.push_back(rd_unit);
  return rd_unit;
}

// To create a RD unit which may generate definition of var. It is
// however not sure that it will kill previous definitions.
RDUnit *
ALFReachingDefinitionsAnalysisBuilder::
CreateGeneratingEPGNodeRDUnit(ALFExtendedProgramGraphNode * epg_node, unsigned int var)
{
  EPGNodeRDUnit * rd_unit = new EPGNodeRDUnit(epg_node, _rd_unit_key, var);
  _rd_unit_key++;
  _rd_units.push_back(rd_unit);
  return rd_unit;
}

// To create a RD unit which is guaranteed to kill previous
// definitions of var.
RDUnit *
ALFReachingDefinitionsAnalysisBuilder::
CreateKillingEPGNodeRDUnit(ALFExtendedProgramGraphNode * epg_node, unsigned int var)
{
  EPGNodeRDUnit * rd_unit = new EPGNodeRDUnit(epg_node, _rd_unit_key, var, true);
  _rd_unit_key++;
  _rd_units.push_back(rd_unit);
  return rd_unit;
}

// *******************************************************
// *******************************************************
// *******************************************************
// *******************************************************
// *******************************************************
// *******************************************************
// *******************************************************
// *******************************************************
// *******************************************************
// *******************************************************

// // -------------------------------------------------------
// // To build an ALFReachingDefinitionsAnalysis object from a call graph
// // -------------------------------------------------------
// ALFReachingDefinitionsAnalysis *
// ALFReachingDefinitionsAnalysisBuilder::
// Build(CCallGraph * cg,  CALFAbsAnnotStorage * annots, alf::CAlfTuple * alf_ast, 
//       CSteensgaardPA * pa, CSymTabBase * symtab)
// {
//   // To keep track of number of rd units created
//   _rd_unit_key = 0;

//   // Extract the global declarations and initializations from the ALF ast
//   CDeclList * global_decls = alf_ast->GetDecls();
//   CInitList * global_inits = alf_ast->GetInits();

//   // Get the volatile vars annotations and initializations
//   std::set<unsigned int> volatile_vars;
//   if(annots != NULL) ExtractVolatileVarsFromAnnots(annots, &volatile_vars);
//   if(global_inits != NULL) ExtractVolatileVarsFromInits(global_inits, &volatile_vars);  

//   // Make sure that we do not have any when called abs annots 
//   if(annots != NULL && HasWhenCalledAnnotsForCFGsInCG(annots, cg))
//     assert("When called annots not supported by RD analysis" == 0);
  
//   // Create rd units from the graph. Create connection from
//   // nodes to a vector of rd units.
//   std::set<std::pair<RDUnit *, RDUnit *> > rd_unit_to_succ_rd_units;
//   std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> node_to_rd_units;
//   CreateRDUnitsFromCallGraph(cg, annots, global_decls, global_inits, &volatile_vars, 
// 			     pa, symtab, &node_to_rd_units, &rd_unit_to_succ_rd_units);

//   // Create input and output states for rd units
//   std::set<std::pair<RDUnit *, CBitVector *> > rd_unit_to_input_state;
//   std::set<std::pair<RDUnit *, CBitVector *> > rd_unit_to_output_state;
//   CreateStatesForRDUnits(&rd_unit_to_input_state, &rd_unit_to_output_state);

//   // Partition RD units on their content
//   std::map<alf::AStmt *, std::vector<ALFRDUnit *> *> * stmt_to_rd_units =
//     new std::map<alf::AStmt *, std::vector<ALFRDUnit *> *>;
//   std::map<CALFAbsAnnot *, std::vector<ALFRDUnit *> *> * annot_to_rd_units =
//     new std::map<CALFAbsAnnot *, std::vector<ALFRDUnit *> *>;
//   std::map<alf::CAllocTuple *, std::vector<ALFRDUnit *> *> * alloc_to_rd_units =
//     new std::map<alf::CAllocTuple *, std::vector<ALFRDUnit *> *>;
//   std::map<alf::CInitTuple *, std::vector<ALFRDUnit *> *> * init_to_rd_units =
//     new std::map<alf::CInitTuple *, std::vector<ALFRDUnit *> *>;
//   PartitionRDUnits(&node_to_rd_units, stmt_to_rd_units, annot_to_rd_units,
// 		   alloc_to_rd_units, init_to_rd_units);

//   // Delete temporary vectors in node to rd units map
//   for(std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *>::iterator n2v = node_to_rd_units.begin();
//       n2v != node_to_rd_units.end(); ++n2v) {
//     delete (*n2v).second;
//   }

//   // Create and return the RD analysis object. Gives away the created mappings to the RD analysis.
//   return new ALFReachingDefinitionsAnalysis(&rd_unit_to_input_state, &rd_unit_to_output_state, 
// 					    &rd_unit_to_succ_rd_units, stmt_to_rd_units, annot_to_rd_units,
// 					    alloc_to_rd_units, init_to_rd_units);
// }


// // ---------------------------------------
// // Help function for extracting the variables occurriding in volatile
// // vars from a set of annotations
// // -------------------------------------------------------
// void
// ALFReachingDefinitionsAnalysisBuilder::
// ExtractVolatileVarsFromAnnots(CALFAbsAnnotStorage * annots, std::set<unsigned int> * volatile_vars)
// {
//   if(!annots || !annots->HasVolatileAbsAnnots()) {
//     // Skip processing if no volatle annots are present
//     return;
//   }
//   else {
//     // Get all the variables defined in all the volatile abs annots
//     std::list<CALFAbsAnnot *> * vol_abs_annot_list = annots->GetVolatileAbsAnnots();
//     for(std::list<CALFAbsAnnot *>::iterator vol_abs_annot = vol_abs_annot_list->begin();
// 	vol_abs_annot != vol_abs_annot_list->end(); ++vol_abs_annot) {
//       // Since we can not convert a set of signed ints to a set of unsigned ints
//       std::set<int> defs;
//       (*vol_abs_annot)->GetDefs(&defs);
//       for(std::set<int>::iterator def = defs.begin(); def != defs.end(); ++def) {
// 	volatile_vars->insert(*def);
//       }
//     }
//   }
// }

// // -------------------------------------------------------
// // Help function for extracting the variables occurriding in volatile
// // vars from a set of initializations
// // -------------------------------------------------------
// void
// ALFReachingDefinitionsAnalysisBuilder::
// ExtractVolatileVarsFromInits(CInitList * inits, std::set<unsigned int> * volatile_vars)
// {
//   if(!inits || inits->ElementCount() == 0) {
//     // Skip processing if no volatle annots are present
//     return;
//   }
//   else {
//     // Get all the variables defined in all the volatile inits
//     for(CInitList::list_iterator init = inits->Iterator(); init != inits->InvalidIterator(); ++init) {
//       // Check if it is a volatile initialization
//       if((*init)->GetInitOption() == CInitTuple::VOLATILE) {
// 	// Get the key of the frame written to
// 	unsigned int lhs_key = (*init)->GetRef()->GetKey();
// 	// Add the key to the volatile vars set. 
// 	volatile_vars->insert(lhs_key);
//       }
//     }
//   }
// }

// // -------------------------------------------------------
// // To create and connecting a set of rd units according to 
// // the things accessible from a call graph 
// // -------------------------------------------------------
// void 
// ALFReachingDefinitionsAnalysisBuilder::
// CreateRDUnitsFromCallGraph(CCallGraph * cg, 
// 			   CALFAbsAnnotStorage * annots, CDeclList * global_decls, CInitList * global_inits, 
// 			   std::set<unsigned int> * volatile_vars, CSteensgaardPA * pa, CSymTabBase * symtab, 
// 			   std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> * node_to_rd_units,
// 			   std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units)
// {
//   // Create rd units for all CFG nodes. This includes rd units for
//   // annots and global decls and inits.  Each created rd unit will be
//   // associated with a cfg node.
//   CreateRDUnitsForCFGNodes(cg, annots, global_decls, global_inits, 
// 			   volatile_vars, pa, symtab, node_to_rd_units);

//   // Create connections between RD units according to the vector
//   // associated with each cfg node
//   ConnectRDUnitsInVectors(node_to_rd_units, rd_unit_to_succ_rd_units);

//   // Create connections between RD units according to the pred,succ pairs in
//   // the cfg graphs and the call-func and result->call pairs in the cg
//   ConnectRDUnitsAccordingToCGAndCFGEdges(cg, node_to_rd_units, rd_unit_to_succ_rd_units);
// }


// // -------------------------------------------------------
// // To create rd units from CFG nodes. This includes rd units for
// // annots, global decls and inits, local decls, function arguments,
// // etc. Each created rd unit will be associated with a node.
// // -------------------------------------------------------
// void 
// ALFReachingDefinitionsAnalysisBuilder::
// CreateRDUnitsForCFGNodes(CCallGraph * cg, 
// 			 CALFAbsAnnotStorage * annots, CDeclList * global_decls, CInitList * global_inits, 
// 			 std::set<unsigned int> * volatile_vars, CSteensgaardPA * pa, CSymTabBase * symtab, 
// 			 std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> * node_to_rd_units)
// {
//   // Get the program entry start node
//   CFlowGraphNode * prog_entry_node = cg->Root()->FlowGraph()->GetEntry();
//   // Loop through all the cfgs in the cg
//   for(CCallGraph::node_iterator cg_node = cg->NodesBegin(); cg_node != cg->NodesEnd(); ++cg_node) {
//     // Get the corresponding flow graph
//     CFlowGraph * cfg = (*cg_node)->FlowGraph();
//     // Get the cfg start node
//     CFlowGraphNode * func_entry_node = cfg->GetEntry();
//     // Loop through all the cfg nodes
//     for(CFlowGraph::node_iterator cfg_node = cfg->NodesBegin(); cfg_node != cfg->NodesEnd(); ++cfg_node) {
//       // Create a vector of rd units to be associated with the cfg node
//       std::vector<ALFRDUnit *> * rd_units = new std::vector<ALFRDUnit *>;
//       // Create the rd units
//       CreateRDUnitsForCFGNode(*cfg_node, cg, prog_entry_node, func_entry_node, 
// 			      annots, global_decls, global_inits, 
// 			      volatile_vars, pa, symtab,
// 			      rd_units);
//       // Update maps with vectors
//       (*node_to_rd_units)[*cfg_node] = rd_units;
//     }
//   }
// }


// // -------------------------------------------------------
// // To create rd units for a CFG node. Will also create rd units
// // annots, global decls and inits, local decls, function arguments,
// // etc. Each created rd unit will be stored in the vector of rd units.
// // -------------------------------------------------------
// void 
// ALFReachingDefinitionsAnalysisBuilder::
// CreateRDUnitsForCFGNode(CFlowGraphNode * cfg_node, CCallGraph * cg, CFlowGraphNode * prog_entry_node, CFlowGraphNode * func_entry_node,
// 			CALFAbsAnnotStorage * annots, CDeclList * global_decls, CInitList * global_inits, 
// 			std::set<unsigned int> * volatile_vars, CSteensgaardPA * pa, CSymTabBase * symtab, 
// 			std::vector<ALFRDUnit *> * rd_units)
// {
//   // ---------------------------------
//   // Handle program entry nodes 
//   // ---------------------------------
//   if(prog_entry_node == cfg_node) {

//     { // Create RD units for global declarations
//       if(global_decls != NULL && global_decls->ElementCount() > 0) { 
// 	for(CDeclList::list_iterator decl = global_decls->Iterator(); decl != global_decls->InvalidIterator(); ++decl) {
// 	  CreateRDUnitsForDecl(*decl, ALFRDUnit::GLOBAL_DECL, rd_units);
// 	}
//       }
//     }

//     { // Create RD units for initializations
//       if(global_inits != NULL && global_inits->ElementCount() > 0) { 
// 	for(CInitList::list_iterator init = global_inits->Iterator(); init != global_inits->InvalidIterator(); ++init) {
// 	  CreateRDUnitsForInit(*init, symtab, volatile_vars, ALFRDUnit::GLOBAL_INIT, rd_units);
// 	}
//       }
//     }

//     { // Create RD units for prog entry annot
//       if(annots != NULL && annots->HasProgEntryALFAbsAnnot()) {
// 	CALFAbsAnnot * annot = annots->GetProgEntryALFAbsAnnot(); 
// 	CreateRDUnitsForAnnot(annot, symtab, ALFRDUnit::PROG_ENTRY_ANNOT, rd_units);
//       }
//     }
//   }

//   // ---------------------------------
//   // Handle function entry nodes 
//   // ---------------------------------
//   if(func_entry_node == cfg_node) {

//     { // Create RD units for function argument and local declarations
//       alf::CFuncTuple * func = dynamic_cast<alf::CFuncTuple*>(cfg_node->FlowGraph()->Function());
//       assert(func);
//       CreateRDUnitsForFuncArgs(func, rd_units);
//       CreateRDUnitsForFuncDecls(func, rd_units);
//     }

//     { // Create RD units according to func entry annots
//       CFlowGraph * cfg = cfg_node->FlowGraph();
//       if(annots != NULL && annots->HasFuncEntryALFAbsAnnot(cfg)) {
// 	CALFAbsAnnot * annot = annots->GetFuncEntryALFAbsAnnot(cfg); 
// 	CreateRDUnitsForAnnot(annot, symtab, ALFRDUnit::FUNC_ENTRY_ANNOT, rd_units);
//       }
//     }
//   }

//   // ---------------------------------
//   // Handle the cfg node
//   // ---------------------------------
//   {
//     { // Create RD units for node entry annots
//       if(annots != NULL && annots->HasNodeEntryALFAbsAnnot(cfg_node)) {
// 	list<CALFAbsAnnot *> * anns = annots->GetNodeEntryALFAbsAnnot(cfg_node);
// 	for(list<CALFAbsAnnot *>::iterator ann = anns->begin(); ann != anns->end(); ++ann) {
// 	  CreateRDUnitsForAnnot(*ann, symtab, ALFRDUnit::NODE_ENTRY_ANNOT, rd_units);
// 	}
//       }
//     }

//     { // Create RD units for the statement in the CFG node
//       alf::AStmt * astmt = dynamic_cast<alf::AStmt *>(cfg_node->Stmt());
//       assert(astmt);
//       CreateRDUnitsForStmt(astmt, cfg_node, cg, pa, symtab, volatile_vars, rd_units);
//     }

//     { // Create RD units for node exit annots
//       if(annots != NULL && annots->HasNodeExitALFAbsAnnot(cfg_node)) {
// 	list<CALFAbsAnnot *> * anns = annots->GetNodeExitALFAbsAnnot(cfg_node);
// 	for(list<CALFAbsAnnot *>::iterator ann = anns->begin(); ann != anns->end(); ++ann) {
// 	  CreateRDUnitsForAnnot(*ann, symtab, ALFRDUnit::NODE_EXIT_ANNOT, rd_units);
// 	}
//       }
//     }
//   }

//   // Make sure that we have got some units
//   assert(rd_units->size() > 0);
// }


// // -------------------------------------------------------
// // Help functions for connecting all pred,succ pairs in a list
// // -------------------------------------------------------
// void
// ALFReachingDefinitionsAnalysisBuilder::
// ConnectRDUnitsInVectors(std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> * node_to_rd_units,
// 			std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units)
// {
//   // Loop through all mappings 
//   for(std::map<CFlowGraphNode *, vector<ALFRDUnit *> *>::iterator n2u = node_to_rd_units->begin();
//       n2u != node_to_rd_units->end(); ++n2u) {
//     std::vector<ALFRDUnit *> * rd_units = (*n2u).second;
//     ConnectRDUnitsInVector(rd_units, rd_unit_to_succ_rd_units);
//   }
// }

// // Create connections between RD units according to the vector
// // associated with each cfg node. Special treatment of call->func rd units.
// void
// ALFReachingDefinitionsAnalysisBuilder::
// ConnectRDUnitsInVector(std::vector<ALFRDUnit *> * rd_units, 
// 		       std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units)
// {
//   for(std::vector<ALFRDUnit *>::const_iterator rd_unit = rd_units->begin();
//       rd_unit != rd_units->end(); ++rd_unit) {
//     std::vector<ALFRDUnit *>::const_iterator next_rd_unit = rd_unit;
//     ++next_rd_unit;
//     if(next_rd_unit != rd_units->end()) {
//       // We skip making pairs to nodes succeeding rd units originating
//       // from call statements. This is because this node should be
//       // going to the rd unit corresponding to the called function.
//       ALFRDUnit * alf_rd_unit = dynamic_cast<ALFRDUnit *>(*rd_unit);
//       if(alf_rd_unit->GetType() != ALFRDUnit::CALL_STMT_CALL) {
// 	rd_unit_to_succ_rd_units->insert(std::make_pair(*rd_unit, *next_rd_unit));
//       }
//     }
//   }
// }   

// // -------------------------------------------------------
// // Create connections between RD units according to the pred,succ pairs in
// // the cfg graphs and the call-func and result->call pairs in the cg
// // -------------------------------------------------------
// void
// ALFReachingDefinitionsAnalysisBuilder::
// ConnectRDUnitsAccordingToCGAndCFGEdges(CCallGraph * cg, 
// 				       std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> * node_to_rd_units, 
// 				       std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units)
// {
//   // Connect RD units according to edges in the call graph
//   ConnectRDUnitsAccordingToCGEdges(cg, node_to_rd_units, rd_unit_to_succ_rd_units);

//   // Connect RD units according to edges in the cfgs
//   for(CCallGraph::node_iterator cg_node = cg->NodesBegin(); cg_node != cg->NodesEnd(); ++cg_node) {
//     CFlowGraph * cfg = (*cg_node)->FlowGraph();
//     ConnectRDUnitsAccordingToCFGEdges(cfg, node_to_rd_units, rd_unit_to_succ_rd_units);
//   }
// }

// // Connect rd units according to the edges in the call graph
// void 
// ALFReachingDefinitionsAnalysisBuilder::
// ConnectRDUnitsAccordingToCGEdges(CCallGraph * cg, 
// 				 std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> * node_to_rd_units, 
// 				 std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units)
// {
//   // Get and iterate through all edges in the call graph 
//   CCallGraph::T_edge_list cg_edges;
//   cg->Edges(&cg_edges);
//   for(CCallGraph::T_edge_list_iterator e = cg_edges.begin(); e != cg_edges.end(); ++e) {

//     // Get the edge data 
//     // CCallGraphNode * call_node = (*e).from;
//     CCallGraphNode * enter_node = (*e).to;
//     CCallGraphEdgeAnnot * edge_annot = (*e).edge_annot;

//     // Get the flow graph of the enter node
//     CFlowGraph * enter_cfg = enter_node->FlowGraph();

//     // Get the flow graph node the call goes call
//     CFlowGraphNode * call_cfg_node = edge_annot->CallSite();

//     // Get the rd units of the call node
//     std::vector<ALFRDUnit *> * call_rd_units = (*node_to_rd_units)[call_cfg_node];
    
//     { // Connect the rd units according to the func call edge (call->enter)

//       // Get the flow graph node the call goes to
//       CFlowGraphNode * enter_cfg_node = enter_cfg->GetEntry();
      
//       // Get the rd units of the enter node 
//       std::vector<ALFRDUnit *> * enter_rd_units = (*node_to_rd_units)[enter_cfg_node];
      
//       // Connect the rd unit node of call type correspnding to the caller node with 
//       // the first rd node in the vector correspnding to the entre node
//       ALFRDUnit * call_rd_unit = NULL;
//       for(std::vector<ALFRDUnit *>::iterator c = call_rd_units->begin(); 
// 	  c != call_rd_units->end(); ++c) {
// 	ALFRDUnit * alf_rd_unit = dynamic_cast<ALFRDUnit *>(*c);
// 	if(alf_rd_unit->GetType() == ALFRDUnit::CALL_STMT_CALL) {
// 	  call_rd_unit = (*c);
// 	  break;
// 	}
//       }
//       assert(call_rd_unit);
//       ALFRDUnit * enter_rd_unit = *(enter_rd_units->begin());
//       rd_unit_to_succ_rd_units->insert(std::make_pair(call_rd_unit, enter_rd_unit));
//     }      

//     { // Connect rd units according to func call return edges (return->result)

//       // Get all the return nodes of the flow graph of the called function
//       std::vector<CFlowGraphNode *> return_cfg_nodes;
//       enter_cfg->ExitNodes(&return_cfg_nodes);
      
//       // Get the rd units of result type from calling cfg node rd units
//       ALFRDUnit * result_rd_unit = NULL;
//       for(std::vector<ALFRDUnit *>::iterator c = call_rd_units->begin(); 
// 	  c != call_rd_units->end(); ++c) {
// 	ALFRDUnit * alf_rd_unit = dynamic_cast<ALFRDUnit *>(*c);
// 	if(alf_rd_unit->GetType() == ALFRDUnit::CALL_STMT_RESULT) {
// 	  result_rd_unit = (*c);
// 	  break;
// 	}
//       }
//       assert(result_rd_unit);

//       // Connect the last rd unit of all the exit nodes with the result rd unit
//       for(std::vector<CFlowGraphNode *>::iterator return_cfg_node = return_cfg_nodes.begin();
// 	  return_cfg_node != return_cfg_nodes.end(); ++return_cfg_node) {
      
// 	std::vector<ALFRDUnit *> * return_rd_units = (*node_to_rd_units)[*return_cfg_node];
// 	ALFRDUnit * return_rd_unit = *(return_rd_units->rbegin());
// 	ALFRDUnit * alf_return_rd_unit = dynamic_cast<ALFRDUnit *>(return_rd_unit);
// 	assert(alf_return_rd_unit->GetType() == ALFRDUnit::RETURN_STMT);
	
// 	rd_unit_to_succ_rd_units->insert(std::make_pair(return_rd_unit, result_rd_unit));
//       }
//     }
//   }
// }

// // Connect rd units according to edges in the cfg
// void 
// ALFReachingDefinitionsAnalysisBuilder::
// ConnectRDUnitsAccordingToCFGEdges(CFlowGraph * cfg, 
// 				  std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> * node_to_rd_units, 
// 				  std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units)
// {
//   // Get the edges of the cfg
//   CFlowGraph::T_edge_list edges;
//   cfg->Edges(&edges);

//   // Loop through all edges 
//   for(CFlowGraph::T_edge_list_iterator e = edges.begin(); e != edges.end(); ++e ) {

//     // Get the edge data 
//     CFlowGraphNode * from_node = (*e).from;
//     CFlowGraphNode * to_node = (*e).to;
//     CFlowGraphEdgeAnnot * edge_annot = (*e).edge_annot;

//     // If the edge is a false edge we should not generate any
//     // connection for it (this is handled when we generate
//     // connections for call edges)
//     if(!edge_annot->IsFalseEdge()) {
      
//       // The edge is a normal edge

//       // Get the rd_units of the from and to nodes
//       std::vector<ALFRDUnit *> * from_rd_units = (*node_to_rd_units)[from_node];
//       std::vector<ALFRDUnit *> * to_rd_units = (*node_to_rd_units)[to_node];
//       assert(from_rd_units->size() > 0);
//       assert(to_rd_units->size() > 0);

//       // Connect last rd_unit of the from node with the first rd_unit of the to node 
//       ALFRDUnit * last_from_rd_unit = *(from_rd_units->rbegin());
//       ALFRDUnit * first_to_rd_unit = *(to_rd_units->begin());

//       rd_unit_to_succ_rd_units->insert(std::make_pair(last_from_rd_unit, first_to_rd_unit));
//     }
//   }
// }

// // -------------------------------------------------------
// // CreateRDUnitsForInit -
// // To create rd_units for an init
// // -------------------------------------------------------
// void
// ALFReachingDefinitionsAnalysisBuilder::
// CreateRDUnitsForInit(CInitTuple * init, CSymTabBase * symtab, std::set<unsigned int> * volatile_vars, 
// 		     ALFRDUnit::TYPE type, std::vector<ALFRDUnit *> * rd_units)
// {
//   // Get the key of the frame written to
//   unsigned int lhs_key = init->GetRef()->GetKey();

//   // ************************* 
//   // We should be able to generate killing units from initializations.
//   // However, it requires that we can extract the size of a value or 
//   // a constant. The latter is unfortunately not that easy, and therefore 
//   // all inits are set as gens for the moment... Since we do not know the
//   // size of the written value we cannot easily tell if the whole frame
//   // is overwritten and thus the initialization must be set to a gen. This
//   // should be safe since if an init should be kept after slicing its 
//   // corresponding declaration should also be kept.
//   // *************************

//   // Create a generating RD unit and add it last to the vector 
//   ALFRDUnit * rd_unit = CreateGeneratingALFRDUnit(init, lhs_key, type);
//   rd_units->push_back(rd_unit);
// }

// // If the offset of the written value not is zero or if the size of
// // the data area written to is larger than the size of the value then
// // the def is not a kill.
// // Variabel to keep track on if the assignment is a kill
// //  bool is_kill = true;
// //   // Check that the ref offset starts at zero 
// //   int offset = init->GetRef()->GetOffset()->GetNumber()->GetValueAsInt();
// //   if(offset > 0) {
// //     is_kill = false;
// //   }
// //   else {
// //     // Check that the size of the data area written to is equal 
// //     // to the size of the value 
    
// //     // Get the size of the frame the key refers to
// //     Size lhs_size = GetSizeOfFrameByKey(lhs_key, symtab);

// //     // Check that the size is not too big
// //     if(lhs_size.IsInfinity()) {
// //       is_kill = false;
// //     }
// //     else {
// //       // Check that the value written has the same size as the data
// //       // area written to
// //       const AVal * val = init->GetVal();
// //       Size rhs_size = GetSizeOfValue(val);
// //       if(lhs_size > rhs_size) {
// // 	is_kill = false;
// //       }
// //       // If the variable is a volatile variable it can not be killed
// //       else if(volatile_vars->find(lhs_key) != volatile_vars->end()) {
// // 	is_kill = false;
// //       }
// //     }
// //   }

// //   // Create the RD unit and return it 
// //   ALFRDUnit * rd_unit = NULL;
// //   if(is_kill)
// //     rd_unit = CreateKillingALFRDUnit(lhs_key);
// //   else
// //     rd_unit = CreateGeneratingALFRDUnit(lhs_key);
// //   return rd_unit;
// // }


// // -------------------------------------------------------
// // CreateRDUnitsForAnnot -
// // To create rd_units for ALF abstract annotations
// // -------------------------------------------------------
// void
// ALFReachingDefinitionsAnalysisBuilder ::
// CreateRDUnitsForAnnot(CALFAbsAnnot * annot, CSymTabBase * symtab, 
// 		      ALFRDUnit::TYPE type, std::vector<ALFRDUnit *> * rd_units)
// {
//   // Get all the var := values assignments made in the abstract assignment 
//   const list<pair<CALFAbsAnnotVar *, CALFAbsAnnotVal *> > * var_vals_list = annot->VarValsList();

//   // Sets to keep track of if assignmenst are generating and maybe also killing a 
//   // previous variable definition variables. If the whole frame is overwritten 
//   // the abstract value, then the aqssignment is killing, otherwise not. 
//   std::set<unsigned int> generating;
//   std::set<unsigned int> killing;
  
//   // If the same variable is updated in several assignments in the
//   // same annot we might have the case that the assignments together
//   // overwrites the whole variable and the absann is therefore a kill
//   // of this particular variable. If however, there exists a part of
//   // the var which is not covered by the assignment, then the absann
//   // is a gen but not a kill of this particular variable.

//   // To keep track of the variable assignments made. We summarize all
//   // the sizes covered. If the sum is equal to the size of the frame
//   // then the whole frame is covered (a kill) otherwise not (a gen).
//   std::map<unsigned int, Size> var_key_to_bits_covered;

//   // Loop through the parallel assignments in the abstract annotation updating map 
//   for(list<pair<CALFAbsAnnotVar *, CALFAbsAnnotVal *> >::const_iterator var_vals = var_vals_list->begin();
//       var_vals != var_vals_list->end(); ++var_vals)
//     {
//       CALFAbsAnnotVar * var = (*var_vals).first;
//       // Get the key of the updated variable
//       const CSymTabEntry * var_entry = symtab->Lookup(var->FRefId());
//       unsigned int var_key = var_entry->GetIdentifier()->GetKey(); 

//       // If the update is a GLB or LUB the assignment can not be killing
//       if(annot->IsUpdateType(CALFAbsAnnot::GLB) || 
// 	 annot->IsUpdateType(CALFAbsAnnot::LUB)) {
// 	generating.insert(var_key);
//       }
//       else {
// 	// It is an ASSIGN update, it can be killing!

// 	// If the var assignment not has a size then it write over the whole frame
// 	// and is therefore a kill
// 	if(!var->HasSizeInBits()) {	  
// 	  killing.insert(var_key);
// 	}
// 	// If the var assignment has a infinite then the whole frame is updated
// 	else if(var->SizeInBits().IsInfinity()) {
// 	  killing.insert(var_key);
// 	}
// 	else {
// 	  // We have one or more assignments of the given variable.
// 	  // Calculate the size of the parts of the frame covered.
// 	  if(var_key_to_bits_covered.find(var_key) == var_key_to_bits_covered.end()) {
// 	    var_key_to_bits_covered[var_key] = Size(0);
// 	  }
// 	  var_key_to_bits_covered[var_key] += var->SizeInBits() * Size(var->Repeat());
// 	}
//       }
//     }

//   // Go through all list of size of var assignments and categorize the
//   // assignment as a kill or a define
//   for(std::map<unsigned int, Size>::iterator vk2bc = var_key_to_bits_covered.begin();
//       vk2bc != var_key_to_bits_covered.end(); ++vk2bc) {
//     // Get the variable defined and the size of bits covered in teh corresponding frame
//     unsigned int var_key = (*vk2bc).first;
//     Size bits_covered = (*vk2bc).second;
//     // Get the size of the frame that the var_key corresponds to 
//     Size frame_size = GetSizeOfFrameByKey(var_key, symtab);
//     // If they are equal it is a kill, otherwise not
//     if(bits_covered == frame_size) {
//       killing.insert(var_key);
//     }
//     else {
//       generating.insert(var_key);
//     }
//   }

//   // Loop through the generating vars to create corresponding RD units 
//   for(std::set<unsigned int>::iterator key = generating.begin(); key != generating.end(); ++key) {
//     ALFRDUnit * rd_unit = CreateGeneratingALFRDUnit(annot, *key, type);
//     rd_units->push_back(rd_unit);
//   }
  
//   // Loop through the killing vars to create corresponding RD units 
//   for(std::set<unsigned int>::iterator key = killing.begin(); key != killing.end(); ++key) {
//     ALFRDUnit * rd_unit = CreateKillingALFRDUnit(annot, *key, type);
//     rd_units->push_back(rd_unit);
//   }
// }

// // -------------------------------------------------------
// // Help function for creating rd_units for the function arguments
// // -------------------------------------------------------
// void
// ALFReachingDefinitionsAnalysisBuilder ::
// CreateRDUnitsForFuncArgs(alf::CFuncTuple * func, std::vector<ALFRDUnit *> * rd_units)
// {
//   // For all formal arguments to the function we create a killing rd_unit
//   const CArgDeclList * form_args = func->GetArgs();
//   for(CArgDeclList::const_list_iterator farg = form_args->ConstIterator(); farg != form_args->InvalidIterator(); ++farg) {
//     unsigned int key = (*farg)->GetKey();
//     ALFRDUnit * rd_unit = CreateKillingALFRDUnit(*farg, key, ALFRDUnit::FUNC_ARG);
//     rd_units->push_back(rd_unit);
//   }
// }

// // -------------------------------------------------------
// // Help function for creating rd_units for declarations in function 
// // -------------------------------------------------------
// void
// ALFReachingDefinitionsAnalysisBuilder ::
// CreateRDUnitsForFuncDecls(alf::CFuncTuple * func, std::vector<ALFRDUnit *> * rd_units)
// {
//   // For all local declarations in the function we create a killing rd
//   // unit. We also check that no local inits are made (we asserts if so).

//   // Extract and loop through all the scope statements in the function
//   vector<CGenericStmt *> scope_stmts;
//   scope_stmts.push_back((CScopeTuple *) func->GetScope());
//   func->GetStmtsInFunctionScopeAndSubordinateScopes(&scope_stmts, CGenericNode::TYPE_SCOPE_TUPLE);
//   for (vector<CGenericStmt *>::const_iterator sc = scope_stmts.begin(); sc != scope_stmts.end(); ++sc) {
//     const CScopeTuple * scope_tuple = dynamic_cast<const CScopeTuple *>(*sc);
//     assert(scope_tuple != 0);
//     // Create a killing rd unit for each scope local declaration made
//     const alf::CDeclList * decls = scope_tuple->GetDecls();
//     for(CDeclList::const_list_iterator decl = decls->ConstIterator(); decl != decls->InvalidIterator(); ++decl) {
//       CreateRDUnitsForDecl(*decl, ALFRDUnit::FUNC_DECL, rd_units);
//     }

//     // Extra check to make sure that no inits are made (should have been caught in static check)
//     const alf::CInitList * inits = scope_tuple->GetInits();
//     assert(inits->ElementCount() == 0);
//   }
// } 

// // -------------------------------------------------------
// // Help function for creating rd_units for list of declarations 
// // -------------------------------------------------------
// void
// ALFReachingDefinitionsAnalysisBuilder::
// CreateRDUnitsForDecl(alf::CAllocTuple * decl, ALFRDUnit::TYPE type, std::vector<ALFRDUnit *> * rd_units)
// {
//   // A declaration is always a killing definition
//   unsigned int key = decl->GetKey();
//   ALFRDUnit * rd_unit = CreateKillingALFRDUnit(decl, key, type);
//   rd_units->push_back(rd_unit);
// }

// // -------------------------------------------------------
// // Help function for creating RD units from the argument statement 
// // -------------------------------------------------------
// void
// ALFReachingDefinitionsAnalysisBuilder ::
// CreateRDUnitsForStmt(alf::AStmt * stmt, CFlowGraphNode * cfg_node, CCallGraph * cg, 
// 		     CSteensgaardPA * pa, CSymTabBase * symtab, std::set<unsigned int> * volatile_vars, 
// 		     std::vector<ALFRDUnit *> * rd_units)
// {
//   // Check what type of statement we have and call the corresponding
//   // create RD units function
//   switch(stmt->GetNodeType()) {
//     // Null, jump and switch statements do not generate any defines
//     case CGenericNode::TYPE_NULL_STMT_TUPLE:
//       {
// 	// Create a non generating rd unit and add it last to the list to return 
// 	rd_units->push_back(CreateNonGeneratingALFRDUnit(stmt, ALFRDUnit::NULL_STMT));
// 	break;
//       }
//     case CGenericNode::TYPE_JUMP_STMT_TUPLE:
//       {
// 	// Create a non generating rd unit and add it last to the list to return 
// 	rd_units->push_back(CreateNonGeneratingALFRDUnit(stmt, ALFRDUnit::JUMP_STMT));
// 	break;
//       }
//     case CGenericNode::TYPE_SWITCH_STMT_TUPLE:
//       {
// 	// Create a non generating rd unit and add it last to the list to return 
// 	rd_units->push_back(CreateNonGeneratingALFRDUnit(stmt, ALFRDUnit::SWITCH_STMT));
// 	break;
//       }
//     case CGenericNode::TYPE_STORE_STMT_TUPLE:
//       {
// 	// Store statement can make many defines  
//          CStoreStmtTuple *store_stmt = static_cast<CStoreStmtTuple *>(stmt);
//          CreateRDUnitsForStoreStmt(store_stmt, pa, symtab, volatile_vars, rd_units);
//          break;
//       }
//     case CGenericNode::TYPE_CALL_STMT_TUPLE:
//       {
// 	// Call statements can make many defines  
// 	CCallStmtTuple *call_stmt = static_cast<CCallStmtTuple *>(stmt);
// 	CreateRDUnitsForCallStmt(call_stmt, cfg_node, cg, pa, symtab, volatile_vars, rd_units);
// 	break;
//       }
//     case CGenericNode::TYPE_RETURN_STMT_TUPLE:
//       {
// 	// Return statements can't make defines   
// 	CReturnStmtTuple *return_stmt = static_cast<CReturnStmtTuple *>(stmt);
// 	CreateRDUnitsForReturnStmt(return_stmt, volatile_vars, rd_units);
// 	break;
//       }
//     // Free and other type of statements are not supported yet 
//     case CGenericNode::TYPE_FREE_STMT_TUPLE:
//     default: {
//       assert("ALF RD analysis - unsupported statement" == 0);
//       break;
//     }
//   } // end switch
// }


// // -------------------------------------------------------
// // A store statement in ALF may consist of several parallel
// // assignments. Each such parallel assignment may only kill when
// // there is a single variable in the lhs and the operation is
// // performed on the entire data object. If the same variable is
// // assigned in several of the parallel assignments it is enough that
// // one of the assignments is a killing assignment for a killing RD
// // unit should be created for the variable. 
// // -------------------------------------------------------
// void
// ALFReachingDefinitionsAnalysisBuilder ::
// CreateRDUnitsForStoreStmt(CStoreStmtTuple * stmt, CSteensgaardPA * pa, CSymTabBase * symtab, 
// 			  std::set<unsigned int> * volatile_vars, std::vector<ALFRDUnit *> * rd_units)
// {
//   // Get the list of addresses where the values should be stored
//   const CExprList* store_addr_exprs = stmt->GetAddrExprs();

//   // Get the list of expressions generating values to be stored 
//   const CExprList* value_exprs = stmt->GetExprs();

//   // Sets to keep track of variables for which it should be created
//   // generating and killing RD units. A variable first classified as
//   // generating can later be classified as killing if there exist at
//   // least assignment which surely defines this variable.
//   std::set<unsigned int> generating;
//   std::set<unsigned int> killing;

//   // Loop through the expressions of store addresses and values 
//   alf::CExprList::const_list_iterator store_addr_expr = store_addr_exprs->ConstIterator();
//   alf::CExprList::const_list_iterator value_expr = value_exprs->ConstIterator();
//   for( ; store_addr_expr != store_addr_exprs->InvalidIterator() && value_expr != value_exprs->InvalidIterator();
//        ++store_addr_expr, ++value_expr) { 
//     // Get the variables potentially updated on the lhs of this particular parallel store
//     std::set<unsigned int> updated_vars;
//     GetUpdatedVarsOfLhsAddrExpr(*store_addr_expr, pa, &updated_vars);
//     assert(updated_vars.size() >= 1);
    
//     // If more than one variable may be updated then it can not be a killing define 
//     if(updated_vars.size() == 1) {
      
//       // Get the key of the updated variable
//       unsigned int lhs_key = *(updated_vars.begin());
      
//       // If the variable already has been set as a killing 
//       if(killing.find(lhs_key) != killing.end()) {
// 	continue;
//       }
      
//       // If the variable is present in the volatile_vars set it can
//       // not be a kill
//       if(volatile_vars->find(lhs_key) != volatile_vars->end()) {
// 	generating.insert(lhs_key);
// 	continue;
//       }
      
//       // Get the size of the frame the key refers to
//       Size lhs_size = GetSizeOfFrameByKey(lhs_key, symtab);
//       // Get the size of the value stored
//       Size rhs_size = GetSizeOfValueExpr(*value_expr);
      
//       // Check if the sizes are equal. Since we are not allowed to
//       // write outside frames, we assume if the sizes are equal, that
//       // the whole frame will be overwritten.
//       if(lhs_size == rhs_size) { 
// 	killing.insert(lhs_key);
// 	// Remove previous generating assignment of var if any 
// 	std::set<unsigned int>::iterator gen = generating.find(lhs_key);
// 	if(gen != generating.end()) {
// 	  generating.erase(gen);
// 	}
//       }
//       else {
// 	// We have a generating assignment
// 	generating.insert(lhs_key);
//       }
//     }
//     else {
//       // More than one variable means that no variable is killing.
//       // All variables should therefore be added to the generating set.
//       for(std::set<unsigned int>::iterator v = updated_vars.begin();
// 	  v != updated_vars.end(); ++v) {
// 	// If the variable already is present in the killing set we
// 	// should not add it to the generating set.
// 	if(killing.find(*v) == killing.end()) {
// 	  generating.insert(*v);
// 	}
//       }
//     }
//   }

//   // Make sure that we generate some rd units for the statement
//   assert(killing.size() + generating.size() > 0);

//   // Loop through the generating vars to create corresponding RD units 
//   for(std::set<unsigned int>::iterator key = generating.begin(); key != generating.end(); ++key) {
//     ALFRDUnit * rd_unit = CreateGeneratingALFRDUnit(stmt, *key, ALFRDUnit::STORE_STMT);
//     rd_units->push_back(rd_unit);
//   }

//   // Loop through the killing vars to create corresponding RD units 
//   for(std::set<unsigned int>::iterator key = killing.begin(); key != killing.end(); ++key) {
//     ALFRDUnit * rd_unit = CreateKillingALFRDUnit(stmt, *key, ALFRDUnit::STORE_STMT);
//     rd_units->push_back(rd_unit);
//   }
// }

// void
// ALFReachingDefinitionsAnalysisBuilder ::
// CreateRDUnitsForCallStmt(CCallStmtTuple *call_stmt, CFlowGraphNode * cfg_node, CCallGraph * cg, 
// 			 CSteensgaardPA * pa, CSymTabBase * symtab, std::set<unsigned int> * volatile_vars, 
// 			 std::vector<ALFRDUnit *> * rd_units)
// {
//   // Create a non generating RD unit for the actual call. This is
//   // because we are only overwriting the parameter passing area. To be
//   // able to overwrite something using these parameters we must pass
//   // pointers to the function. Assignment using dereferenced pointers
//   // are handled in normal store statements by the pointer analysis.
//   rd_units->push_back(CreateNonGeneratingALFRDUnit(call_stmt, ALFRDUnit::CALL_STMT_CALL));
  
//   // The result parameters must however be treated as assignments
//   // since they may overwrite local (and global) variables to the
//   // calling function.
//   const alf::CExprList * result_addr_exprs = call_stmt->GetAddrExprs();

//   if(result_addr_exprs->ElementCount() == 0) {
//     // No result addresses. Create a non-generating RD unit as a place holder.
//     rd_units->push_back(CreateNonGeneratingALFRDUnit(call_stmt, ALFRDUnit::CALL_STMT_RESULT));
//     return;
//   }

//   else {

//     // Else, we have one or more result addresses for which we should
//     // create killing or generating RD units. We have the case that we
//     // might return different amount of values than what is handled on
//     // the result side of the call statement. We also have that
//     // different return statements may return different amount of
//     // values potentially with different sizes. We assume that all
//     // value sizes are be smaller than the sizes of the frames at
//     // which the result value might be stored. Finally, the result
//     // address may go to several frames (if we use pointers to access
//     // the address).

//     // Create a vector holding which result addresses that should be
//     // killing or generating. By default all are killing. 
//     // **************** Tried to use enums to do this but did not 
//     // get it to work.... *****************
//     unsigned int KILL = 0;
//     unsigned int GEN = 1;
//     std::vector<unsigned int> kill_or_gen;
//     unsigned int nr_of_result_addresses = result_addr_exprs->ElementCount();
//     kill_or_gen.resize(nr_of_result_addresses, KILL);

//     // Create a vector holding the sizes of the frames accessed by
//     // result addreses. 
//     std::vector<Size> res_frame_sizes;

//     { // Update the res_frame_size vector. If more than one frame may
//       // be written to then we set the result as generating.

//       unsigned int i = 0;
//       for(alf::CExprList::const_list_iterator result_addr_expr = result_addr_exprs->ConstIterator();
// 	  result_addr_expr != result_addr_exprs->InvalidIterator(); ++result_addr_expr, ++i) {
	
// 	// Get the variables potentially updated on the lhs of this result 
// 	std::set<unsigned int> updated_vars;
// 	GetUpdatedVarsOfLhsAddrExpr(*result_addr_expr, pa, &updated_vars);
// 	assert(updated_vars.size() >= 1);
	
// 	// If there are more than one variable updated all by the result
// 	// statement then it must be a gen (instead of a kill).
// 	if(updated_vars.size() > 1) {
// 	  kill_or_gen[i] = GEN;
// 	}
	
// 	// Get the size of the frame written to. Only one size is
// 	// needed, since if there are more than one frame written to we
// 	// have already set the result operation as a gen (see above).
// 	unsigned int frame_id = *(updated_vars.begin());
// 	Size frame_size = GetSizeOfFrameByKey(frame_id, symtab);
// 	res_frame_sizes.push_back(frame_size);

// 	// If the variable is present in the volatile_vars set it can
// 	// not be a kill
// 	if(volatile_vars->find(frame_id) != volatile_vars->end()) {
// 	  kill_or_gen[i] = GEN;
// 	}
//       }
//     }

//     { // Update kill_or_gen according to the sizes of the return
//       // values in the return statements of teh functions called from
//       // the call statement. A result can only be a kill if all return
//       // value sizes are the same as the frame written to by the
//       // result statement.

//       // Get the call graph node of the function in which the statement occurs
//       CCallGraphNode * cg_node = cg->FindNodeOfFunction(cfg_node->FlowGraph()->Function());
      
//       // Extract the cfgs that can be called from the given call site
//       std::set<CFlowGraph *> called_cfgs;
//       for(CCallGraphNode::succ_iterator it = cg_node->SuccBegin(); 
// 	  it != cg_node->SuccEnd(); ++it) {
// 	CFlowGraphNode * call_site = (*it).edge_annot->CallSite();
// 	if(call_site == cfg_node) {
// 	  CFlowGraph * called_cfg = (*it).node->FlowGraph();
// 	  called_cfgs.insert(called_cfg);
// 	}
//       }
      
//       // Loop through all the return statements of the cfgs that can be called. 
//       // A result can only be a kill if all return value sizes are the same 
//       // as the frame written to by the result statement.
//       for(std::set<CFlowGraph *>::iterator called_cfg = called_cfgs.begin();
// 	  called_cfg != called_cfgs.end(); ++called_cfg) {
// 	CFuncTuple * called_func_tuple = dynamic_cast<CFuncTuple *>((*called_cfg)->Function());
// 	CAlfTreeFilter filter = CAlfTreeFilter(called_func_tuple);
// 	CAlfTreeFilter::NodeList return_stmts = filter.GetNodesOfType(CGenericNode::TYPE_RETURN_STMT_TUPLE);
// 	for(CAlfTreeFilter::NodeList::iterator grs = return_stmts.begin(); 
// 	    grs != return_stmts.end(); ++grs) {
// 	  const CReturnStmtTuple * return_stmt = dynamic_cast<const CReturnStmtTuple *>(*grs);

// 	  // Check if the number of return values are different from the number of result values
// 	  const CExprList * return_values = return_stmt->GetExprs();
// 	  unsigned int nr_of_return_values = return_values->ElementCount();
// 	  if(nr_of_return_values < nr_of_result_addresses) {
// 	    // *********** ADD ERROR MESSAGE *************
// 	  }
// 	  if(nr_of_return_values > nr_of_result_addresses) {
// 	    // *********** ADD WARNING MESSAGE *************
// 	  }

// 	  // Loop through all return values, and check if the corresponding result op should 
// 	  // be classified as a gen
// 	  unsigned int i = 0;
// 	  for(CExprList::const_list_iterator return_value = return_values->ConstIterator();
// 	      return_value != return_values->InvalidIterator(); ++return_value, ++i) {
// 	    // To avoid unneccessary work
// 	    if(kill_or_gen[i] == KILL) {
// 	      // Get the size of the value stored
// 	      Size value_size = GetSizeOfValueExpr(*return_value);
// 	      // Get the corresponding size of the return address
// 	      Size res_frame_size = res_frame_sizes[i];
// 	      // We are not allowed to write outside the frame
// 	      assert(value_size <= res_frame_size);
// 	      // If the sizes are not of equal then it is a gen
// 	      if(value_size != res_frame_size) {
// 		kill_or_gen[i] = GEN;	     
// 	      }
// 	    }
// 	  }
// 	}
//       }
//     }
  
//     { // Create RD units according to kill_or_gen vector

//       unsigned int i = 0;
//       for(alf::CExprList::const_list_iterator result_addr_expr = result_addr_exprs->ConstIterator();
// 	  result_addr_expr != result_addr_exprs->InvalidIterator(); ++result_addr_expr, ++i) {
	
// 	// *********************************
// 	// Get the variables potentially updated by result. Maybe a
// 	// bit unneccessary since we already done this above.
// 	// I.e. updated_vars should maybe be cached?  
// 	// *********************************
// 	std::set<unsigned int> updated_vars;
// 	GetUpdatedVarsOfLhsAddrExpr(*result_addr_expr, pa, &updated_vars);
// 	assert(updated_vars.size() >= 1);
    
// 	// Loop through the generating vars to create corresponding RD units 
// 	for(std::set<unsigned int>::iterator key = updated_vars.begin(); key != updated_vars.end(); ++key) {
// 	  if(kill_or_gen[i] == GEN) {
// 	    rd_units->push_back(CreateGeneratingALFRDUnit(call_stmt, *key, ALFRDUnit::CALL_STMT_RESULT));
// 	  }
// 	  else {
// 	    assert(updated_vars.size() == 1);
// 	    rd_units->push_back(CreateKillingALFRDUnit(call_stmt, *key, ALFRDUnit::CALL_STMT_RESULT));
// 	  }
// 	}
//       }
//     }
//   }
// }



// void
// ALFReachingDefinitionsAnalysisBuilder ::
// CreateRDUnitsForReturnStmt(CReturnStmtTuple *return_stmt, std::set<unsigned int> * volatile_vars, 
// 			   std::vector<ALFRDUnit *> * rd_units)
// {
//   // We only assign parameter passing variables here, and therefore no
//   // definitions are made. We therefore only need to create a
//   // non-generating RD unit.
//   rd_units->push_back(CreateNonGeneratingALFRDUnit(return_stmt, ALFRDUnit::RETURN_STMT));
// }

// // -------------------------------------------------------
// // GetUpdatedVarsOfLhsAddrExprOfStore -
// // Function that given a lhs ADDR_EXPR in a store statement returns the
// // variables possibly updated. We say possibly since the analysis rely 
// // on the pointer analysis, and the pointer analysis is over approximative.
// //
// // The following are the valid BNF rules for lhs ADDR_EXPR in store statements.
// //
// // STMT -> 
// // | { store ADDR_EXPR+ with EXPR+ }
// //
// // ADDR_EXPR -> 
// // | { addr SIZE_IN_BITS FREF NUM_EXPR }              // CAddrTuple TYPE_ADDR_EXPR_TUPLE 
// // | { addr SIZE_IN_BITS FREF_EXPR NUM_EXPR }         // CCompAddrTuple TYPE_COMPADDR_EXPR_TUPLE 
// // | { load SIZE_IN_BITS ADDR_EXPR }                  // CLoadExprTuple TYPE_LOAD_EXPR_TUPLE
// // | { add SIZE_IN_BITS ADDR_EXPR NUM_EXPR NUM_EXPR } // COpNumExprTuple TYPE_OP_EXPR_TUPLE && GetOperator()==OP_TYPE_ADD   
// // | { add SIZE_IN_BITS NUM_EXPR ADDR_EXPR NUM_EXPR } // COpNumExprTuple TYPE_OP_EXPR_TUPLE && GetOperator()==OP_TYPE_ADD 
// // | { sub SIZE_IN_BITS ADDR_EXPR NUM_EXPR NUM_EXPR } // COpNumExprTuple TYPE_OP_EXPR_TUPLE && GetOperator()==OP_TYPE_SUB
// // | { undefined SIZE_IN_BITS }                       // CUndefinedExprTuple TYPE_UNDEFINED_EXPR_TUPLE
// //
// // -------------------------------------------------------
// void 
// ALFReachingDefinitionsAnalysisBuilder::
// GetUpdatedVarsOfLhsAddrExpr(alf::AExpr *expr, CSteensgaardPA *pa, std::set<unsigned int> *updated_vars)
// {
//   // Check that we have got a valid lhs address expression
//   bool valid_lhs_expr = false;
//   if(expr->IsType(alf::CGenericNode::TYPE_ADDR_EXPR_TUPLE) || 
//      expr->IsType(alf::CGenericNode::TYPE_COMPADDR_EXPR_TUPLE) ||
//      expr->IsType(alf::CGenericNode::TYPE_LOAD_EXPR_TUPLE) || 
//      expr->IsType(alf::CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE))
//     valid_lhs_expr = true;
//   else if(expr->IsType(alf::CGenericNode::TYPE_OP_EXPR_TUPLE)) {
//     COpNumExprTuple * op_num_expr = dynamic_cast<alf::COpNumExprTuple *>(expr);
//     if(((op_num_expr->GetOperator() == alf::COpNumExprTuple::OP_TYPE_ADD) ||
// 	(op_num_expr->GetOperator() == alf::COpNumExprTuple::OP_TYPE_SUB)) && 
//        op_num_expr->GetNumExprs()->ElementCount() == 3) {
//       valid_lhs_expr = true;
//     }
//   }
  
//   // Make sure that we have got a valid lhs expression
//   assert(valid_lhs_expr);
  
//   // Call the real function which derives the updated variables
//   GetUpdatedVarsOfExpr(expr, pa, updated_vars);
// }

// // Help function for deriving which variables that may be updated in a
// // lhs ADDR_EXPR. Extracted so that it can be called recursively.
// void 
// ALFReachingDefinitionsAnalysisBuilder::
// GetUpdatedVarsOfExpr(const AExpr *expr, CSteensgaardPA * pa, std::set<unsigned int> *updated_vars)
// {
//   // Check the type of the expression and act accordingly
//   switch(expr->GetNodeType()) {
//   case CGenericNode::TYPE_ADDR_EXPR_TUPLE:
//     {
//       // Get the fref and insert its key into the set
//       const alf::CAddrTuple *cast_expr = dynamic_cast<const alf::CAddrTuple *>(expr);
//       const alf::CFRefTuple *fref = cast_expr->GetFref();
//       unsigned int key = fref->GetKey();
//       updated_vars->insert(key);
//       break;
//     }
//   case CGenericNode::TYPE_COMPADDR_EXPR_TUPLE:
//     {
//       // Get the expression that should evaluate to a fref and call
//       // the function recursively
//       const alf::CCompAddrTuple *cast_expr = dynamic_cast<const alf::CCompAddrTuple *>(expr);
//       const alf::AExpr * fref_expr = cast_expr->GetFRefExpr();
//       GetUpdatedVarsOfExpr(fref_expr, pa, updated_vars);
//       break;
//     }
//    case CGenericNode::TYPE_LOAD_EXPR_TUPLE: 
//      {
//        // Here we do not return the variables of the subexpression,
//        // but rather the points-to-set of these. Note that we need not
//        // bother which variables are pointers, non-pointers will
//        // result zero sized points-to-set.
//        const alf::CLoadExprTuple *cast_expr = dynamic_cast<const alf::CLoadExprTuple *>(expr);
//        const AExpr * addr_expr = cast_expr->GetAddrExpr();
//        std::set<unsigned int> vars_to_deref;
//        GetUpdatedVarsOfExpr(addr_expr, pa, &vars_to_deref);
//        for(std::set<unsigned int>::const_iterator v = vars_to_deref.begin();
// 	   v != vars_to_deref.end(); ++v) {
// 	 if(pa->HasPointsToVars(*v)) {
// 	   // Add the dereferenced variables to the argument set
// 	   pa->GetPointsToVars(*v, updated_vars);
// 	 }
//        }
//        break;
//      }
//   case CGenericNode::TYPE_OP_EXPR_TUPLE:
//     {
//       // Here we just have to collect all updated variables in the sub-expressions.
//       // This is made by callign the funbction recursively.
//       const alf::COpNumExprTuple *cast_expr = dynamic_cast<const alf::COpNumExprTuple *>(expr);
//       const alf::CExprList* exprs = cast_expr->GetNumExprs();
//       for(CExprList::const_list_iterator e = exprs->ConstIterator();
// 	  e != exprs->InvalidIterator(); ++e) {
// 	GetUpdatedVarsOfExpr(*e, pa, updated_vars);
//       }
//       break;
//     }
//   case CGenericNode::TYPE_FREF_TUPLE:
//     {
//       // Get the key of the fref tuple and insert it into the set
//       const alf::CFRefTuple *cast_expr = dynamic_cast<const alf::CFRefTuple *>(expr);
//       unsigned int key = cast_expr->GetKey();
//       updated_vars->insert(key);
//       break;
//     }
//   case CGenericNode::TYPE_INTVAL_TUPLE:
//   case CGenericNode::TYPE_FLOATVAL_TUPLE:
//   case CGenericNode::TYPE_LREF_TUPLE:
//   case CGenericNode::TYPE_LABEL_TUPLE:
//   case CGenericNode::TYPE_COMPLABEL_EXPR_TUPLE:
//   case CGenericNode::TYPE_DYNALLOC_EXPR_TUPLE:
//     {
//       // No variables here, just return
//       break;
//     }
//   case CGenericNode::TYPE_UNDEFINED_EXPR_TUPLE:
//     {
//       // This is problematic. We do not know what variables that will be updated.
//       assert("undefined value can't be handled in RD analysis" == 0);
//       break;
//     } 
//   default:
//     {
//       assert("This type of expression should not occur on lhs side of store" == 0);
//       break;
//     }
//   } // end switch
// }

// // Use the symbol table to get the size in bits of a frame referred to
// Size 
// ALFReachingDefinitionsAnalysisBuilder ::
// GetSizeOfFrameByKey(unsigned int key, CSymTabBase * symtab) 
// {
//   // Get the symbol table entry and identifier corresponding to the key
//   const CSymTabEntry * entry = symtab->Lookup(key); 
//   const CSymTabIdentifier * id = entry->GetIdentifier(); 

//   // Check if the identifier is an alloc tuple 
//   const CAllocTuple * alloc = dynamic_cast<const CAllocTuple *>(id); 
//   if(alloc != NULL) {
//     return alloc->GetFrameSize()->GetSizeInBits();
//   }
  
//   // Check if the identrier is a fref tuple
//   const CFRefTuple * fref = dynamic_cast<const CFRefTuple *>(id);
//   if(fref != NULL) {
//     return fref->GetSize()->GetSizeInBits();
//   }

//   // Check if the identrier is a lref tuple
//   // const CLRefTuple * lref = dynamic_cast<const CLRefTuple *>(id);
//   //   if(lref != NULL) {
//   //     return lref->GetSize()->GetSizeInBits();
//   //   }

//   // Check if the identrier is a ref 
//   // const CRefTuple * ref = dynamic_cast<const CRefTuple *>(id);
//   //   if(ref != NULL) {
//   //     return ...
//   //   }

//   // ADD MORE!!!! 

//   assert("Not possible to get the size of the sym tab identifier with given key" == 0);
//   return NULL;
// }


// // To get the size of an expression evaluating to a value
// Size 
// ALFReachingDefinitionsAnalysisBuilder::
// GetSizeOfValueExpr(const AExpr * expr) 
// {
//   // We use the functionality provided by AExpr
//   return expr->GetSizeOfEvaluatedExpr();
// }


// // Returns true if any of the cfgs in the cfg set has an when called annot
// bool
// ALFReachingDefinitionsAnalysisBuilder::
// HasWhenCalledAnnotsForCFGsInCG(CALFAbsAnnotStorage * annots, CCallGraph * cg)
// {
//   // Loop through all the cfgs in the cg
//   for(CCallGraph::node_iterator cg_node = cg->NodesBegin(); cg_node != cg->NodesEnd(); ++cg_node) {

//     // Get the corresponding flow graph
//     CFlowGraph * cfg = (*cg_node)->FlowGraph();

//     // Check if we have a when called annot for this cfg
//     if(annots->HasWhenCalledAlfAbsAnnots(cfg))
//       return true;
//   }
//   // No annot found on the given cfgs
//   return false;
// }

// // To create input and output states for all rd units
// void
// ALFReachingDefinitionsAnalysisBuilder::
// CreateStatesForRDUnits(std::set<std::pair<RDUnit *, CBitVector *> > * rd_unit_to_input_state,
// 		       std::set<std::pair<RDUnit *, CBitVector *> > * rd_unit_to_output_state)
// {
//   for(std::vector<ALFRDUnit *>::iterator rd_unit = _rd_units.begin();
//       rd_unit != _rd_units.end(); ++rd_unit) {
//     (*rd_unit_to_input_state).insert(std::make_pair(*rd_unit, new CBitVector(_rd_unit_key+1)));
//     (*rd_unit_to_output_state).insert(std::make_pair(*rd_unit, new CBitVector(_rd_unit_key+1)));
//   }
// }

// // -------------------------------------------------------
// // Partition RD units of nodes based on their content
// // -------------------------------------------------------
// void
// ALFReachingDefinitionsAnalysisBuilder::
// PartitionRDUnits(std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> * node_to_rd_units,
// 		 std::map<alf::AStmt *, std::vector<ALFRDUnit *> *> * stmt_to_rd_units,
// 		 std::map<CALFAbsAnnot *, std::vector<ALFRDUnit *> *> * annot_to_rd_units,
// 		 std::map<alf::CAllocTuple *, std::vector<ALFRDUnit *> *> * alloc_to_rd_units,
// 		 std::map<alf::CInitTuple *, std::vector<ALFRDUnit *> *> * init_to_rd_units)
// {
//   // Go through all mappings
//   for(std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *>::iterator n2v = node_to_rd_units->begin();
//       n2v != node_to_rd_units->end(); ++n2v) { 
//     // Go through all rd units
//     std::vector<ALFRDUnit *> * rd_units = (*n2v).second;
//     for(std::vector<ALFRDUnit *>::iterator rd_unit = rd_units->begin();
// 	rd_unit != rd_units->end(); rd_unit++) {
//       // Get their origin and add the set to return
//       ALFRDUnit * alf_rd_unit = (*rd_unit);
//       switch (alf_rd_unit->GetBaseType()) {
//       case ALFRDUnit::STMT: 
// 	{
// 	  // Add the rd unit to vector for the stmt
// 	  alf::AStmt * stmt = alf_rd_unit->GetCreatedFromAsStmt();
// 	  if(stmt_to_rd_units->find(stmt) == stmt_to_rd_units->end())
// 	    (*stmt_to_rd_units)[stmt] = new std::vector<ALFRDUnit *>;
// 	  (*stmt_to_rd_units)[stmt]->push_back(*rd_unit);
// 	  break;
// 	}
//       case ALFRDUnit::ANNOT: 
// 	{
// 	// Add the rd unit to vector for the annot
// 	CALFAbsAnnot * annot = alf_rd_unit->GetCreatedFromAsAnnot();
// 	if(annot_to_rd_units->find(annot) == annot_to_rd_units->end())
// 	  (*annot_to_rd_units)[annot] = new std::vector<ALFRDUnit *>;
// 	(*annot_to_rd_units)[annot]->push_back(*rd_unit);
// 	break;
//       }
//     case ALFRDUnit::ALLOC:
//       {
// 	// Add the rd unit to vector for the annot
// 	alf::CAllocTuple * alloc = alf_rd_unit->GetCreatedFromAsAlloc();
// 	if(alloc_to_rd_units->find(alloc) == alloc_to_rd_units->end())
// 	  (*alloc_to_rd_units)[alloc] = new std::vector<ALFRDUnit *>;
// 	(*alloc_to_rd_units)[alloc]->push_back(*rd_unit);
// 	break;
//       }
//     case ALFRDUnit::INIT:
//       {
// 	// Add the rd unit to vector for the annot
// 	alf::CInitTuple * init = alf_rd_unit->GetCreatedFromAsInit();
// 	if(init_to_rd_units->find(init) == init_to_rd_units->end())
// 	  (*init_to_rd_units)[init] = new std::vector<ALFRDUnit *>;
// 	(*init_to_rd_units)[init]->push_back(*rd_unit);
// 	break;
//       }
//       }
//     }
//   }
// }


// // -------------------------------------------------------
// // Help functions for creating ALFRDUnits with annots
// // -------------------------------------------------------

// // To create a RD unit which do not result in any variable definitions
// ALFRDUnit *
// ALFReachingDefinitionsAnalysisBuilder::
// CreateNonGeneratingALFRDUnit(CALFAbsAnnot * annot, ALFRDUnit::TYPE type)
// {
//   ALFRDUnit * rd_unit = new ALFRDUnit(annot, type, _rd_unit_key);
//   _rd_unit_key++;
//   _rd_units.push_back(rd_unit);
//   return rd_unit;
// }

// // To create a RD unit which may generate definition of var. It is
// // however not sure that it will kill previous definitions.
// ALFRDUnit *
// ALFReachingDefinitionsAnalysisBuilder::
// CreateGeneratingALFRDUnit(CALFAbsAnnot * annot, unsigned int var, ALFRDUnit::TYPE type)
// {
//   ALFRDUnit * rd_unit = new ALFRDUnit(annot, type, _rd_unit_key, var);
//   _rd_unit_key++;
//   _rd_units.push_back(rd_unit);
//   return rd_unit;
// }

// // To create a RD unit which is guaranteed to kill previous
// // definitions of var.
// ALFRDUnit *
// ALFReachingDefinitionsAnalysisBuilder::
// CreateKillingALFRDUnit(CALFAbsAnnot * annot, unsigned int var, ALFRDUnit::TYPE type)
// {
//   ALFRDUnit * rd_unit = new ALFRDUnit(annot, type, _rd_unit_key, var, true);
//   _rd_unit_key++;
//   _rd_units.push_back(rd_unit);
//   return rd_unit;
// }

// // -------------------------------------------------------
// // Help functions for creating ALFRDUnits with allocs
// // -------------------------------------------------------

// // To create a RD unit which do not result in any variable definitions
// ALFRDUnit *
// ALFReachingDefinitionsAnalysisBuilder::
// CreateNonGeneratingALFRDUnit(alf::CAllocTuple * alloc, ALFRDUnit::TYPE type)
// {
//   ALFRDUnit * rd_unit = new ALFRDUnit(alloc, type, _rd_unit_key);
//   _rd_unit_key++;
//   _rd_units.push_back(rd_unit);
//   return rd_unit;
// }

// // To create a RD unit which may generate definition of var. It is
// // however not sure that it will kill previous definitions.
// ALFRDUnit *
// ALFReachingDefinitionsAnalysisBuilder::
// CreateGeneratingALFRDUnit(alf::CAllocTuple * alloc, unsigned int var, ALFRDUnit::TYPE type)
// {
//   ALFRDUnit * rd_unit = new ALFRDUnit(alloc, type, _rd_unit_key, var);
//   _rd_unit_key++;
//   _rd_units.push_back(rd_unit);
//   return rd_unit;
// }

// // To create a RD unit which is guaranteed to kill previous
// // definitions of var.
// ALFRDUnit *
// ALFReachingDefinitionsAnalysisBuilder::
// CreateKillingALFRDUnit(alf::CAllocTuple * alloc, unsigned int var, ALFRDUnit::TYPE type)
// {
//   ALFRDUnit * rd_unit = new ALFRDUnit(alloc, type, _rd_unit_key, var, true);
//   _rd_unit_key++;
//   _rd_units.push_back(rd_unit);
//   return rd_unit;
// }

// // -------------------------------------------------------
// // Help functions for creating ALFRDUnits with init
// // -------------------------------------------------------

// // To create a RD unit which do not result in any variable definitions
// ALFRDUnit *
// ALFReachingDefinitionsAnalysisBuilder::
// CreateNonGeneratingALFRDUnit(alf::CInitTuple * init, ALFRDUnit::TYPE type)
// {
//   ALFRDUnit * rd_unit = new ALFRDUnit(init, type, _rd_unit_key);
//   _rd_unit_key++;
//   _rd_units.push_back(rd_unit);
//   return rd_unit;
// }

// // To create a RD unit which may generate definition of var. It is
// // however not sure that it will kill previous definitions.
// ALFRDUnit *
// ALFReachingDefinitionsAnalysisBuilder::
// CreateGeneratingALFRDUnit(alf::CInitTuple * init, unsigned int var, ALFRDUnit::TYPE type)
// {
//   ALFRDUnit * rd_unit = new ALFRDUnit(init, type, _rd_unit_key, var);
//   _rd_unit_key++;
//   _rd_units.push_back(rd_unit);
//   return rd_unit;
// }

// // To create a RD unit which is guaranteed to kill previous
// // definitions of var.
// ALFRDUnit *
// ALFReachingDefinitionsAnalysisBuilder::
// CreateKillingALFRDUnit(alf::CInitTuple * init, unsigned int var, ALFRDUnit::TYPE type)
// {
//   ALFRDUnit * rd_unit = new ALFRDUnit(init, type, _rd_unit_key, var, true);
//   _rd_unit_key++;
//   _rd_units.push_back(rd_unit);
//   return rd_unit;
// }

// // -------------------------------------------------------
// // Help functions for creating ALFRDUnits with stmt
// // -------------------------------------------------------

// // To create a RD unit which do not result in any variable definitions
// ALFRDUnit *
// ALFReachingDefinitionsAnalysisBuilder::
// CreateNonGeneratingALFRDUnit(alf::AStmt * stmt, ALFRDUnit::TYPE type)
// {
//   ALFRDUnit * rd_unit = new ALFRDUnit(stmt, type, _rd_unit_key);
//   _rd_unit_key++;
//   _rd_units.push_back(rd_unit);
//   return rd_unit;
// }

// // To create a RD unit which may generate definition of var. It is
// // however not sure that it will kill previous definitions.
// ALFRDUnit *
// ALFReachingDefinitionsAnalysisBuilder::
// CreateGeneratingALFRDUnit(alf::AStmt * stmt, unsigned int var, ALFRDUnit::TYPE type)
// {
//   ALFRDUnit * rd_unit = new ALFRDUnit(stmt, type, _rd_unit_key, var);
//   _rd_unit_key++;
//   _rd_units.push_back(rd_unit);
//   return rd_unit;
// }

// // To create a RD unit which is guaranteed to kill previous
// // definitions of var.
// ALFRDUnit *
// ALFReachingDefinitionsAnalysisBuilder::
// CreateKillingALFRDUnit(alf::AStmt * stmt, unsigned int var, ALFRDUnit::TYPE type)
// {
//   ALFRDUnit * rd_unit = new ALFRDUnit(stmt, type, _rd_unit_key, var, true);
//   _rd_unit_key++;
//   _rd_units.push_back(rd_unit);
//   return rd_unit;
// }

