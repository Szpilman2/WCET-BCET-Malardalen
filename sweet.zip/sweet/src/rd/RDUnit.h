#ifndef RDUNIT_H_
#define RDUNIT_H_

#include <assert.h>
#include "graphs/tools/CNode.h"
#include <iostream>
#include <fstream>

// -------------------------------------------------------
// RDUnit - General class used by a reaching definition (RD)
// analysis. 
// -------------------------------------------------------
class RDUnit
{
public:
	      
  // ---------------------------------
  // To create and delete the unit. 
  // ---------------------------------
  
  // The key is an index uniquely identifying the rd unit. If a
  // variable is given The RDUnit is making a definition. If the
  // variable set to be a kill it will also kill all previous
  // definitions of the variable reaching the given RD unit.

  // If the rd unit does not originate from something
  RDUnit(unsigned int key);
  RDUnit(unsigned int key, unsigned int var, bool is_kill=false);

  // To delete the RDUnit
  virtual ~RDUnit();

  // ---------------------------------
  // Attribute access functions
  // ---------------------------------
  // The index used for the unit in the bit vector
  inline unsigned int GetKey() const { return _key; }

  // If the RD defines a variable
  inline bool HasVar() const { return _has_var; }

  // The index of the variable that the rd_unit generates. 
  inline unsigned int GetVar() const { assert(_has_var); return _var; } 

  // If the RD unit kills all definitions of the variable that reach
  // the RDUnit. I.e. it is guaranteed that the variable will be
  // completely overwritten by the statement/code construct
  // corresponding to the RD unit.
  inline bool IsKill() const { return _is_kill; }

  // To print and draw the node. Might be overwritten by subclasses.
  virtual void Print(std::ostream & s = std::cout) const;
  virtual void Draw(std::ostream & s = std::cout) const;

protected:

  // Internal variables
  unsigned int _key;
  bool _has_var;
  unsigned int _var;
  bool _is_kill; 

};


// // -------------------------------------------------------
// // RDUnitWithContent - RDUnit with a content. Templatified to allow
// // different type of RDUnits to be easily created. Inherits most 
// // functionality from the RDUnit base class.
// // -------------------------------------------------------
// template <typename Content>
// class RDUnitWithContent : public RDUnit
// {
// public:

//   // To create and delete the templatified RDUnit
//   RDUnitWithContent(Content * content, TYPE type, unsigned int key);
//   RDUnitWithContent(Content * content, TYPE type, unsigned int key, unsigned int var, bool is_kill=false);
//   virtual ~RDUnitWithContent();

//   // To get the templified content
//   const Content * GetContent();

// protected:

//   Content * _content;
// };
  
// template <typename Content>
// RDUnitWithContent<Content>::
// RDUnitWithContent(Content * content, unsigned int key)
// : RDUnit(key), _content(content)
// {
//   // Do nothing
// }

// template <typename Content>
// RDUnitWithContent<Content>::
// RDUnitWithContent(Content * content, unsigned int key, unsigned int var, bool is_kill)
// : RDUnit(key, var, is_kill), _content(content)
// {
//   Do nothing
// // }

// template <typename Content>
// RDUnitWithContent<Content>::
// ~RDUnitWithContent()
// {
//   // Do nothing
// }

// template <typename Content>
// const Content *
// RDUnitWithContent<Content>::
// GetContent() 
// {
//   return _content;
// }

#endif 


