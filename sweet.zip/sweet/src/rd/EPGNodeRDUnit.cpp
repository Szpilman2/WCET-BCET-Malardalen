#include "EPGNodeRDUnit.h"

// To create a non definining RD units with a special EPFG node 
EPGNodeRDUnit::
EPGNodeRDUnit(ALFExtendedProgramGraphNode * epg_node, unsigned int key) 
  : RDUnit(key), _epg_node(epg_node)
{

}

// To create a definining RD units with a special EPFG node 
EPGNodeRDUnit::
EPGNodeRDUnit(ALFExtendedProgramGraphNode * epg_node, unsigned int key, unsigned int var, bool is_kill)
  : RDUnit(key, var, is_kill), _epg_node(epg_node)
{

}
// To get the EPFG node 
ALFExtendedProgramGraphNode * 
EPGNodeRDUnit::
GetEPGNode()
{
  return _epg_node;
}

// To print the RD unit
void 
EPGNodeRDUnit::
Print(std::ostream & s) const
{
  RDUnit::Print(s);
  _epg_node->Print(s);
}

// To draw the RD unit
void 
EPGNodeRDUnit::
Draw(std::ostream & s) const
{
  RDUnit::Draw(s);
  _epg_node->Draw(s);
}
