#ifndef ALFREACHINGDEFINITIONSANALYSIS_H_
#define ALFREACHINGDEFINITIONSANALYSIS_H_

#include "rd/ReachingDefinitionsAnalysis.h"
#include "rd/RDUnit.h"
#include "alf_slicing/ALFExtendedProgramGraphNode.h"
#include "absann/CALFAbsAnnot.h"
#include "program/alf/CInitList.h"
#include "program/alf/AStmt.h"
#include "program/alf/CAllocTuple.h"
#include "program/alf/CInitTuple.h"
#include "program/alf/AExpr.h"
#include "program/alf/AVal.h"
#include "program/alf/CCallStmtTuple.h"
#include "program/alf/CReturnStmtTuple.h"
#include "program/alf/CSize.h"
#include "program/alf/CStoreStmtTuple.h"
#include "program_state/Size.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/ecfg/CECFGNode.h"

#include <set>
#include <vector>
#include <list>

using namespace alf;

// Classhierarchy:
// ---------------
//
// -- DataFlowAnalysis<ALFRDUnit, CBitVector>
//    |-- ReachingDefinitionsAnalysis
//        |-- ALFReachingDefinitionsAnalysis


// -------------------------------------------------------
// Class for doing RD analysis. Inherits most functionality.
// Steps:
// 1. First create the RD analysis object, using RD Analysis builder. 
// 2. Then call Run() to do the actual analysis.
// 3. Get def results for stmts
// -------------------------------------------------------
class ALFReachingDefinitionsAnalysis : public ReachingDefinitionsAnalysis
{
public:

  // ---------------------------------
  // Create and delete functions
  // ---------------------------------

  // For doing RD analysis over RD units.
  ALFReachingDefinitionsAnalysis(const std::set<std::pair<RDUnit *, CBitVector * > > * rd_units_to_input_state,
				 const std::set<std::pair<RDUnit *, CBitVector * > > * rd_units_to_output_state,
				 const std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units,
				 std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *> * node_to_rd_units);

  // Virtual, to make sure that deletes go to parent class 
  virtual ~ALFReachingDefinitionsAnalysis();

  // Function to get the type of the analysis
  std::string AnalysisName(void) const { return "ALFRDAnalysis"; };

  // ---------------------------------
  // Functions useful for getting the things that defines variables which
  // may reach certain epg node. 
  // ---------------------------------

  // To get all variable definitions that may reach a certain epg node 
  void GetDefsThatMayReachEPGNode(ALFExtendedProgramGraphNode * epg_node, 
				  std::set<ALFExtendedProgramGraphNode *> * defining_epg_nodes);

  // To get all definitions that may reach a certain epg node and which
  // may also define the given variable.
  void GetDefsOfVarThatMayReachEPGNode(ALFExtendedProgramGraphNode * epg_node, unsigned int var, 
				       std::set<ALFExtendedProgramGraphNode *> * defining_epg_nodes);

  // To get all possible EPG node definitions of a given variable.
  void GetDefsOfVar(unsigned int var, std::set<ALFExtendedProgramGraphNode *> * defining_epg_nodes);

  // ---------------------------------
  // Functions useful for getting the things that defines variables which
  // may reach certain statement. 
  // ---------------------------------

  // To get all variable definitions that may reach a certain stmt.
  void GetDefsThatMayReachStmt(alf::AStmt * stmt, 
			       std::set<alf::AStmt *> *defining_stmts, 
			       std::set<CALFAbsAnnot *> *defining_annots, 
			       std::set<CAllocTuple *> *defining_allocs,
			       std::set<CInitTuple *> *defining_inits);   
  
  // To get all definitions that may reach a certain stmt and which
  // may also define the given variable.
  void GetDefsOfVarThatMayReachStmt(alf::AStmt * stmt, unsigned int var, 
				    std::set<alf::AStmt *> *defining_stmts, 
				    std::set<CALFAbsAnnot *> *defining_annots,
				    std::set<alf::CAllocTuple *> *defining_allocs,
				    std::set<alf::CInitTuple *> *defining_inits);   				  
  
  // To get all possible definitions of a given variable.
  void GetDefsOfVar(unsigned int var, 
		    std::set<alf::AStmt *> *defining_stmts, 
		    std::set<CALFAbsAnnot *> *defining_annots, 
		    std::set<CAllocTuple *> *defining_allocs,
		    std::set<CInitTuple *> *defining_inits);   	

protected:
   
   // Help function for getting the first rd unit for a statement
   RDUnit * GetRDUnitForStmt(alf::AStmt * stmt);

   // Help function for getting the first rd unit for an epg node 
   RDUnit * GetRDUnitForEPGNode(ALFExtendedProgramGraphNode * epg_node);

  // Help function which goes through all rd units in vector 
  // and returns the thing the rd unit was created from.
  void PartitionRDUnitsOnTypes(std::vector<RDUnit *> * rd_units,
			       std::set<alf::AStmt*> *defining_stmts,
			       std::set<CALFAbsAnnot *> *defining_annots,
			       std::set<alf::CAllocTuple *> *defining_allocs,
			       std::set<alf::CInitTuple *> *defining_inits);
    
  // Help function for getting what epg nodes that correspond to a set
  // of rd units
  void ExtractEPGNodesFromRDUnits(std::vector<RDUnit *> * rd_units, 
				  std::set<ALFExtendedProgramGraphNode *> * epg_nodes);

  // ---------------------------------
  // Help data structures. 
  // ---------------------------------

  // Mapping for fast retrieval of the node that belongs to a certain
  // stmt, alloc, annot or init.
  std::map<AStmt *, ALFExtendedProgramGraphNode *> _stmt_to_epg_node;

  // Connection between ALFExtendedProgramGraphNode's and rd units. The RDUnits are 
  // EPGNodeRDUnits, containing a pointer to the EPGNode they originate from. The 
  // EPGNode contains a pointer to the ALF data structure they originate from.
  std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *> * _epg_node_to_rd_units;

};

#endif



