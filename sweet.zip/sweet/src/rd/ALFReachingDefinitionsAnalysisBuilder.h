#ifndef ALFREACHINGDEFINITIONSANALYSISBUILDER_H_
#define ALFREACHINGDEFINITIONSANALYSISBUILDER_H_

#include "rd/ReachingDefinitionsAnalysis.h"
#include "rd/ALFReachingDefinitionsAnalysis.h"
#include "rd/RDUnit.h"
#include "rd/EPGNodeRDUnit.h"
#include "alf_slicing/ALFExtendedProgramControlFlowGraph.h"
#include "alf_slicing/ALFExtendedProgramGraphNode.h"
#include "dfa/ALFDefsAndUsesAnalysis.h"

#include <set>
#include <vector>
#include <list>

using namespace alf;

// Classhierarchy:
// ---------------
//
// -- DataFlowAnalysis<ALFRDUnit, CBitVector>
//    |-- ReachingDefinitionsAnalysis
//        |-- ALFReachingDefinitionsAnalysis

class 
ALFReachingDefinitionsAnalysisBuilder
{
public:
  // ---------------------------------
  // To create and delete the builder class
  // ---------------------------------
  ALFReachingDefinitionsAnalysisBuilder();
  virtual ~ALFReachingDefinitionsAnalysisBuilder();
  
  // ---------------------------------
  // To create a RD analysis object
  // ---------------------------------
  ALFReachingDefinitionsAnalysis * Build(ALFExtendedProgramControlFlowGraph * epcfg, ALFDefsAndUsesAnalysis * du);

protected:

  void CreateRDUnitsFromEPCFG(ALFExtendedProgramControlFlowGraph * epcfg, ALFDefsAndUsesAnalysis * du,
			      std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *> * node_to_rd_units,
			      std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units);

  void CreateRDUnitsForEPCFGNodes(ALFExtendedProgramControlFlowGraph * epcfg, ALFDefsAndUsesAnalysis * du,
				  std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *> * node_to_rd_units);

  void CreateRDUnitsForEPGNode(ALFExtendedProgramGraphNode * epg_node, ALFDefsAndUsesAnalysis * du, 
			       std::vector<RDUnit *> * rd_units);

  void ConnectRDUnitsInVectors(std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *> * node_to_rd_units,
			       std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units);
  void ConnectRDUnitsInVector(std::vector<RDUnit *> * rd_units, 
			      std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units);

  void ConnectRDUnitsAccordingToEPCFGEdges(ALFExtendedProgramControlFlowGraph * epcfg, 
					   std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *> * node_to_rd_units, 
					   std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units);

  void CreateStatesForRDUnits(std::set<std::pair<RDUnit *, CBitVector *> > * rd_unit_to_input_state,
			      std::set<std::pair<RDUnit *, CBitVector *> > * rd_unit_to_output_state);
  
  RDUnit * CreateNonGeneratingEPGNodeRDUnit(ALFExtendedProgramGraphNode * epg_node);
  RDUnit * CreateGeneratingEPGNodeRDUnit(ALFExtendedProgramGraphNode * epg_node, unsigned int var);
  RDUnit * CreateKillingEPGNodeRDUnit(ALFExtendedProgramGraphNode * epg_node, unsigned int var);
  
  // A variable keeping track on the number of rd units created. Also 
  // used to assign each created rd_unit a unique index.
  unsigned int _rd_unit_key;

   // A vector keeping track of created rd units. Quick access using key to find 
   // a certain unit.
  std::vector<RDUnit *> _rd_units;
};

// *******************************************************
// *******************************************************
// *******************************************************
// *******************************************************
// *******************************************************
// *******************************************************
// *******************************************************
// *******************************************************
// *******************************************************
// *******************************************************


//   // ALFReachingDefinitionsAnalysis * Build(CCallGraph * cg, CALFAbsAnnotStorage * annots, 
//   // 					 alf::CAlfTuple * alf_ast, CSteensgaardPA * pa, CSymTabBase * symtab);

// protected:

//   // ---------------------------------
//   // Help functions for building the RD analysis 
//   // ---------------------------------
  
//   // To extract the variables occurriding in volatiles from a set of annotations
//   void ExtractVolatileVarsFromAnnots(CALFAbsAnnotStorage * annots, std::set<unsigned int> * volatile_vars);

//   // To extract the variables occurriding in volatiles from a set of initializations
//   void ExtractVolatileVarsFromInits(CInitList * inits, std::set<unsigned int> * volatile_vars);

//   // To create and connecting a set of rd units according to the things accessible from the call graph
//   void CreateRDUnitsFromCallGraph(CCallGraph * cg, 
// 				  CALFAbsAnnotStorage * annots, CDeclList * global_decls, CInitList * global_inits, 
// 				  std::set<unsigned int> * volatile_vars, CSteensgaardPA * pa, CSymTabBase * symtab, 
// 				  std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> * node_to_rd_units,
// 				  std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units);

//   // To create rd units from CFG nodes. This includes rd units for
//   // annots, global decls and inits, local decls, function arguments,
//   // etc. Each created rd unit will be associated with a node.
//   void CreateRDUnitsForCFGNodes(CCallGraph * cg, 
// 				CALFAbsAnnotStorage * annots, CDeclList * global_decls, CInitList * global_inits, 
// 				std::set<unsigned int> * volatile_vars, CSteensgaardPA * pa, CSymTabBase * symtab, 
// 				std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> * node_to_rd_units);

//   // To create rd units for a CFG node. Will also create rd units
//   // annots, global decls and inits, local decls, function arguments,
//   // etc. Each created rd unit will be stored in the vector of rd units.
//   void CreateRDUnitsForCFGNode(CFlowGraphNode * cfg_node, CCallGraph * cg, CFlowGraphNode * prog_entry_node, CFlowGraphNode * func_entry_node,
// 			       CALFAbsAnnotStorage * annots, CDeclList * global_decls, CInitList * global_inits, 
// 			       std::set<unsigned int> * volatile_vars, CSteensgaardPA * pa, CSymTabBase * symtab, 
// 			       std::vector<ALFRDUnit *> * rd_units);

//   // Create connections between RD units according to the vector
//   // associated with each cfg node. Special treatment of call->func rd units.
//   void ConnectRDUnitsInVectors(std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> * node_to_rd_units,
// 			       std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units);
//   void ConnectRDUnitsInVector(std::vector<ALFRDUnit *> * rd_units, 
// 			      std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units);

//   // Create connections between RD units according to the pred,succ pairs in
//   // the cfg graphs and the call-func and result->call pairs in the cg
//   void ConnectRDUnitsAccordingToCGAndCFGEdges(CCallGraph * cg, 
// 					      std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> * node_to_rd_units, 
// 					      std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units);
//   void ConnectRDUnitsAccordingToCGEdges(CCallGraph * cg, 
// 					std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> * node_to_rd_units, 
// 					std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units);
//   void ConnectRDUnitsAccordingToCFGEdges(CFlowGraph * cfg, 
// 					 std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> * node_to_rd_units, 
// 					 std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units );
    							     
//   // Create RD units according to global initialization
//   void CreateRDUnitsForInit(CInitTuple * init, CSymTabBase * symtab, std::set<unsigned int> * volatile_vars, 
// 			   ALFRDUnit::TYPE type, std::vector<ALFRDUnit *> * rd_units);

//   // Create RD units according to annotation
//   void CreateRDUnitsForAnnot(CALFAbsAnnot * annot, CSymTabBase * symtab, 
// 			     ALFRDUnit::TYPE type, std::vector<ALFRDUnit *> * rd_units);

//   // Help function for creating rd_units for the function arguments and declarations
//   void CreateRDUnitsForFuncArgs(alf::CFuncTuple * func, std::vector<ALFRDUnit *> * rd_units);

//   // Help function for creating rd_units for declarations in function 
//   void CreateRDUnitsForFuncDecls(alf::CFuncTuple * func, std::vector<ALFRDUnit *> * rd_units);    

//   // Help function to create rd units for decls 
//   void CreateRDUnitsForDecl(alf::CAllocTuple * decl, ALFRDUnit::TYPE type, std::vector<ALFRDUnit *> * rd_units);

//   // Help functions for creating RD units from the argument statement 
//   void CreateRDUnitsForStmt(alf::AStmt * stmt, CFlowGraphNode * cfg_node, CCallGraph * cg, 
// 			    CSteensgaardPA * pa, CSymTabBase * symtab, 
// 			    std::set<unsigned int> * volatile_vars, std::vector<ALFRDUnit *> * rd_units);
//   void CreateRDUnitsForStoreStmt(CStoreStmtTuple * stmt, CSteensgaardPA * pa, CSymTabBase * symtab, 
// 				 std::set<unsigned int> * volatile_vars, std::vector<ALFRDUnit *> * rd_units);
//   void CreateRDUnitsForCallStmt(CCallStmtTuple *call_stmt, CFlowGraphNode * cfg_node, CCallGraph * cg, 
// 				CSteensgaardPA * pa, CSymTabBase * symtab, std::set<unsigned int> * volatile_vars, 
// 				std::vector<ALFRDUnit *> * rd_units);
//   void CreateRDUnitsForReturnStmt(CReturnStmtTuple *return_stmt, std::set<unsigned int> * volatile_vars, 
// 				  std::vector<ALFRDUnit *> * rd_units);

//   // Help function to get the variables possibly updated in expr. The
//   // expr can be a lhs expr of a store statement or the result expr of
//   // a call statement.
//   void GetUpdatedVarsOfLhsAddrExpr(alf::AExpr *expr, CSteensgaardPA * pa, std::set<unsigned int> *updated_vars);
//   void GetUpdatedVarsOfExpr(const alf::AExpr *expr, CSteensgaardPA * pa, std::set<unsigned int> *updated_vars);

//   // Use the symbol table to get the size in bits of a frame referred to
//   Size GetSizeOfFrameByKey(unsigned int key, CSymTabBase * symtab);
//   // To get the size of an expression evaluating to a value
//   Size GetSizeOfValueExpr(const alf::AExpr * expr);

//   // Check to make sure that we do not have any when called annots. 
//   // ********** Should be supported in the future
//   bool HasWhenCalledAnnotsForCFGsInCG(CALFAbsAnnotStorage * annots, CCallGraph * cg);

//   // To create input and output states for all rd units
//   void CreateStatesForRDUnits(std::set<std::pair<RDUnit *, CBitVector *> > * rd_unit_to_input_state,
// 			      std::set<std::pair<RDUnit *, CBitVector *> > * rd_unit_to_output_state);

//   // To be moved elsewhere
//   void GetDefinedVarsOfExpr(const alf::AExpr *expr, CSteensgaardPA * pa, std::set<unsigned int> *defined_vars);

//   // Partition RD units of nodes based on their content
//   void PartitionRDUnits(std::map<CFlowGraphNode *, std::vector<ALFRDUnit *> *> * node_to_rd_units,
// 			std::map<alf::AStmt *, std::vector<ALFRDUnit *> *> * stmt_to_rd_units,
// 			std::map<CALFAbsAnnot *, std::vector<ALFRDUnit *> *> * annot_to_rd_units,
// 			std::map<alf::CAllocTuple *, std::vector<ALFRDUnit *> *> * alloc_to_rd_units,
// 			std::map<alf::CInitTuple *, std::vector<ALFRDUnit *> *> * init_to_rd_units);

//   // ---------------------------------
//   // Help functions and data structures for creatign RD units
//   // ---------------------------------

//   // To create a RD unit which holds a pointer to an annot
//   ALFRDUnit * CreateNonGeneratingALFRDUnit(CALFAbsAnnot * annot, ALFRDUnit::TYPE type);
//   ALFRDUnit * CreateGeneratingALFRDUnit(CALFAbsAnnot * annot, unsigned int var, ALFRDUnit::TYPE type);
//   ALFRDUnit * CreateKillingALFRDUnit(CALFAbsAnnot * annot, unsigned int var, ALFRDUnit::TYPE type);

//   // To create a RD unit which holds a pointer to an alloc
//   ALFRDUnit * CreateNonGeneratingALFRDUnit(alf::CAllocTuple * alloc, ALFRDUnit::TYPE type);
//   ALFRDUnit * CreateGeneratingALFRDUnit(alf::CAllocTuple * alloc, unsigned int var, ALFRDUnit::TYPE type);
//   ALFRDUnit * CreateKillingALFRDUnit(alf::CAllocTuple * alloc, unsigned int var, ALFRDUnit::TYPE type);

//   // To create a RD unit which holds a pointer to an init
//   ALFRDUnit * CreateNonGeneratingALFRDUnit(alf::CInitTuple * init, ALFRDUnit::TYPE type);
//   ALFRDUnit * CreateGeneratingALFRDUnit(alf::CInitTuple * init, unsigned int var, ALFRDUnit::TYPE type);
//   ALFRDUnit * CreateKillingALFRDUnit(alf::CInitTuple * init, unsigned int var, ALFRDUnit::TYPE type);
  
//   // To create a RD unit which holds a pointer to a stmt
//   ALFRDUnit * CreateNonGeneratingALFRDUnit(alf::AStmt * stmt, ALFRDUnit::TYPE type);
//   ALFRDUnit * CreateGeneratingALFRDUnit(alf::AStmt * stmt, unsigned int var, ALFRDUnit::TYPE type);
//   ALFRDUnit * CreateKillingALFRDUnit(alf::AStmt * stmt, unsigned int var, ALFRDUnit::TYPE type);
  
//   // A variable keeping track on the number of rd units created. Also 
//   // used to assign each created rd_unit a unique index.
//   unsigned int _rd_unit_key;

//   // A vector keeping track of created rd units. Quick access using key to find 
//   // a certain unit.
//   std::vector<ALFRDUnit *> _rd_units;
// };

#endif



