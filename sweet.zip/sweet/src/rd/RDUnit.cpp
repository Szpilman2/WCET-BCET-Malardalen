#include "rd/RDUnit.h"

// -------------------------------------------------------
// RDUnit
// -------------------------------------------------------

// To create a RD Unit defining no variable 
RDUnit::
RDUnit(unsigned int key)
  : _key(key), _has_var(false), _var(0), _is_kill(false)
{
  // Do nothing, all initializations are already made
}

// To create a RD Unit defining a variable and maybe also killing all
// previous definitions of the variable
RDUnit::
RDUnit(unsigned int key, unsigned int var, bool is_kill)
  : _key(key), _has_var(true), _var(var), _is_kill(is_kill)
{
  // Do nothing, all initializations are already made
}

RDUnit::
~RDUnit()
{
  // Do nothing
}


// To print the RDUnit
void
RDUnit::
Print(std::ostream & s) const 
{
  s << _key;
  if(_has_var) {
    s << " var: " << _var;
    if(_is_kill) 
      s << " is_kill";
    else
      s << " is_gen";
  }
}

// To draw the RDUnit
void
RDUnit::
Draw(std::ostream & s) const 
{
  Print(s);
}
