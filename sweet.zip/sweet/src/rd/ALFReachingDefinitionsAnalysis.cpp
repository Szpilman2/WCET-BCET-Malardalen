#include "rd/ALFReachingDefinitionsAnalysis.h"
#include "rd/EPGNodeRDUnit.h"
#include "program/alf/CInitTuple.h"
#include "program/alf/CRefTuple.h"
#include "program/alf/CIntNumValTuple.h"
#include "program/alf/ANumVal.h"
#include "program/alf/CNumber.h"
#include "program/alf/CExprList.h"
#include "program/alf/COpNumExprTuple.h"
#include "program/alf/CAddrTuple.h"
#include "program/alf/CFRefTuple.h"
#include "program/alf/CCompAddrTuple.h"
#include "program/alf/CLoadExprTuple.h"
#include "dfa/DataFlowAnalysis.inl"
 
// ---------------------------------
// To create the RD analysis class 
// ---------------------------------  
ALFReachingDefinitionsAnalysis::
ALFReachingDefinitionsAnalysis(const std::set<std::pair<RDUnit *, CBitVector * > > * rd_units_to_input_state,
			       const std::set<std::pair<RDUnit *, CBitVector * > > * rd_units_to_output_state,
			       const std::set<std::pair<RDUnit *, RDUnit *> > * rd_unit_to_succ_rd_units,
			       std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *> * epg_node_to_rd_units)
  : ReachingDefinitionsAnalysis(rd_units_to_input_state, rd_units_to_output_state, rd_unit_to_succ_rd_units),
    _epg_node_to_rd_units(epg_node_to_rd_units)
{
  // Go through all nodes and rd units vectors and add connection
  for(std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *>::iterator n2rs = epg_node_to_rd_units->begin();
      n2rs != epg_node_to_rd_units->end(); ++n2rs) {	
     // If the node was a statement we should add a connection to the
     // statement to epg node map. However, we skip result statements
     // (which refer to call statements) since we want to refer to the
     // calling epg node and not the resulting epg node.
     ALFExtendedProgramGraphNode * node = (*n2rs).first;
     if(node->GetBaseType() == ALFExtendedProgramGraphNode::STMT &&
	node->GetType() != ALFExtendedProgramGraphNode::RESULT_STMT) {
       ALFExtendedProgramGraphNodeStmt * stmt_node = dynamic_cast<ALFExtendedProgramGraphNodeStmt *>(node);
       alf::AStmt * stmt = stmt_node->GetStmt();
       _stmt_to_epg_node[stmt] = node;
     }
   }
}

// ---------------------------------
// To delete the RD analysis class 
// ---------------------------------
ALFReachingDefinitionsAnalysis::
~ALFReachingDefinitionsAnalysis()
{
  // Bit vector states and RD units are deleted in parent class. EPG
  // nodes are not owned by this class.
  
  // Delete mapping between epg nodes and rd units
  for(std::map<ALFExtendedProgramGraphNode *, std::vector<RDUnit *> *>::iterator a2rs = _epg_node_to_rd_units->begin();
      a2rs != _epg_node_to_rd_units->end(); ++a2rs) {
    delete (*a2rs).second;
  }
  // Delete the mapping
  delete _epg_node_to_rd_units;
}

// ---------------------------------
// To get all definitions that may reach a certain epg node
// ---------------------------------
void 
ALFReachingDefinitionsAnalysis::
GetDefsThatMayReachEPGNode(ALFExtendedProgramGraphNode * epg_node, 
			   std::set<ALFExtendedProgramGraphNode *> * defining_epg_nodes)
{
  // Make sure that we have run the RD analysis
  assert(HasMadeRun());

  // Get the rd unit for the epg node 
  RDUnit * rd_unit = GetRDUnitForEPGNode(epg_node);

  // Extract all definitions which reach the given rd_unit
  std::vector<RDUnit *> def_rd_units;
  GetDefinitionsReachingRDUnit(rd_unit, &def_rd_units);

  // Extract the epg nodes from the rd units
  ExtractEPGNodesFromRDUnits(&def_rd_units, defining_epg_nodes);
}


// ---------------------------------
// To get all definitions of var that may reach a certain stmt
// ---------------------------------
void
ALFReachingDefinitionsAnalysis::
GetDefsOfVarThatMayReachEPGNode(ALFExtendedProgramGraphNode * epg_node, unsigned int var, 
				std::set<ALFExtendedProgramGraphNode *> * defining_epg_nodes)
{
  // Make sure that we have run the RD analysis
  assert(HasMadeRun());

  // Get the rd unit for the stmt 
  RDUnit * rd_unit = GetRDUnitForEPGNode(epg_node);

  // Extract all definitions for the given rd_unit
  std::vector<RDUnit *> def_rd_units;
  GetDefinitionsOfVarReachingRDUnit(rd_unit, var, &def_rd_units);

  // Extract the epg nodes from the rd units
  ExtractEPGNodesFromRDUnits(&def_rd_units, defining_epg_nodes);
}

// ---------------------------------
// To get all possible definitions of a given variable.
// ---------------------------------
void 
ALFReachingDefinitionsAnalysis::
GetDefsOfVar(unsigned int var, 
	     std::set<ALFExtendedProgramGraphNode *> * defining_epg_nodes)

{
  // Make sure that we have run the RD analysis
  assert(HasMadeRun());

  // Extract all definitions of var for the given rd_unit
  std::vector<RDUnit *> def_rd_units;
  GetRDUnitsDefiningVar(var, &def_rd_units);
  
  // Extract the epg nodes from the rd units
  ExtractEPGNodesFromRDUnits(&def_rd_units, defining_epg_nodes);
}

// ---------------------------------
// To get all definitions that may reach a certain stmt
// ---------------------------------
void
ALFReachingDefinitionsAnalysis::
GetDefsThatMayReachStmt(alf::AStmt * stmt,
			std::set<alf::AStmt*> *defining_stmts, 
			std::set<CALFAbsAnnot *> *defining_annots, 
			std::set<CAllocTuple *> *defining_allocs,
			std::set<CInitTuple *> *defining_inits)
{
  // Make sure that we have run the RD analysis
  assert(HasMadeRun());

  // Get the rd unit for the stmt 
  RDUnit * rd_unit = GetRDUnitForStmt(stmt);

  // Extract all definitions which reach the given rd_unit
  std::vector<RDUnit *> def_rd_units;
  GetDefinitionsReachingRDUnit(rd_unit, &def_rd_units);

  // Partition the rd units on what they was created from
  PartitionRDUnitsOnTypes(&def_rd_units, defining_stmts, defining_annots, defining_allocs, defining_inits);
}		 

// ---------------------------------
// To get all definitions of var that may reach a certain stmt
// ---------------------------------
void
ALFReachingDefinitionsAnalysis::
GetDefsOfVarThatMayReachStmt(alf::AStmt * stmt, unsigned int var, 
			     std::set<alf::AStmt*> *defining_stmts, 
			     std::set<CALFAbsAnnot *> *defining_annots, 
			     std::set<CAllocTuple *> *defining_allocs,
			     std::set<CInitTuple *> *defining_inits)
{
  // Make sure that we have run the RD analysis
  assert(HasMadeRun());

  // Get the rd unit for the stmt 
  RDUnit * rd_unit = GetRDUnitForStmt(stmt);

  // Extract all definitions for the given rd_unit
  std::vector<RDUnit *> def_rd_units;
  GetDefinitionsOfVarReachingRDUnit(rd_unit, var, &def_rd_units);

  // Partition the rd units on what they was created from
  PartitionRDUnitsOnTypes(&def_rd_units, defining_stmts, defining_annots, defining_allocs, defining_inits);
}

// ---------------------------------
// To get all possible definitions of a given variable.
// ---------------------------------
void 
ALFReachingDefinitionsAnalysis::
GetDefsOfVar(unsigned int var, 
	     std::set<alf::AStmt*> *defining_stmts, 
	     std::set<CALFAbsAnnot *> *defining_annots, 
	     std::set<CAllocTuple *> *defining_allocs,
	     std::set<CInitTuple *> *defining_inits)
{
  // Make sure that we have run the RD analysis
  assert(HasMadeRun());

  // Extract all definitions of var for the given rd_unit
  std::vector<RDUnit *> def_rd_units;
  GetRDUnitsDefiningVar(var, &def_rd_units);

   // Partition the rd units on what they was created from
  PartitionRDUnitsOnTypes(&def_rd_units, defining_stmts, defining_annots, defining_allocs, defining_inits);
}

// -------------------------------------------------------
// To get the first RDUnit of a statement
// -------------------------------------------------------
RDUnit *
ALFReachingDefinitionsAnalysis::
GetRDUnitForStmt(alf::AStmt * stmt)
{
  // Get the epg node for the statement
  ALFExtendedProgramGraphNode * epg_node = _stmt_to_epg_node[stmt];
  assert(epg_node);

  // Get the rd units for the epg node
  std::vector<RDUnit *> * rd_units = (*_epg_node_to_rd_units)[epg_node];
  assert(rd_units);
  assert(rd_units->size() > 0);

  // Return the first element in the list
  return *(rd_units->begin());
}

// -------------------------------------------------------
// To get the first RDUnit of an EPG node
// -------------------------------------------------------
RDUnit *
ALFReachingDefinitionsAnalysis::
GetRDUnitForEPGNode(ALFExtendedProgramGraphNode * epg_node)
{
  // Get the rd units for the epg node
  std::vector<RDUnit *> * rd_units = (*_epg_node_to_rd_units)[epg_node];
  assert(rd_units);
  assert(rd_units->size() > 0);

  // Return the first element in the list
  return *(rd_units->begin());
} 

// -------------------------------------------------------
// Help function which goes through all rd units in vector 
// and returns the thing the rd unit was created from.
// -------------------------------------------------------
void
ALFReachingDefinitionsAnalysis::
PartitionRDUnitsOnTypes(std::vector<RDUnit *> * rd_units,
			std::set<alf::AStmt*> *defining_stmts, 
			std::set<CALFAbsAnnot *> *defining_annots, 
			std::set<CAllocTuple *> *defining_allocs,
			std::set<CInitTuple *> *defining_inits)
{
  // Go through all rd units and extract the node they originate from
  for(std::vector<RDUnit *>::iterator rd_unit = rd_units->begin();
      rd_unit != rd_units->end(); ++rd_unit) {

    // Get the epg node of the rd unit
    EPGNodeRDUnit * epg_node_rd_unit = dynamic_cast<EPGNodeRDUnit *>(*rd_unit);
    ALFExtendedProgramGraphNode * epg_node = epg_node_rd_unit->GetEPGNode();

    // Get their origin and add the set to return
    switch (epg_node->GetBaseType()) {
    case ALFExtendedProgramGraphNode::VIRTUAL:
    case ALFExtendedProgramGraphNode::ASSIGN: {
         break;
    }
    case ALFExtendedProgramGraphNode::STMT: 
      {
	ALFExtendedProgramGraphNodeStmt * stmt_node = dynamic_cast<ALFExtendedProgramGraphNodeStmt *>(epg_node);
	alf::AStmt * stmt = stmt_node->GetStmt();
	defining_stmts->insert(stmt);
	break;
      }
    case ALFExtendedProgramGraphNode::ANNOT: 
      {
	ALFExtendedProgramGraphNodeAnnot * annot_node = dynamic_cast<ALFExtendedProgramGraphNodeAnnot *>(epg_node);
	CALFAbsAnnot * annot = annot_node->GetAnnot();
	defining_annots->insert(annot);
	break;
      }
    case ALFExtendedProgramGraphNode::ALLOC:
      {
	ALFExtendedProgramGraphNodeAlloc * alloc_node = dynamic_cast<ALFExtendedProgramGraphNodeAlloc *>(epg_node);
	alf::CAllocTuple * alloc = alloc_node->GetAlloc();
	defining_allocs->insert(alloc);
	break;
      }
    case ALFExtendedProgramGraphNode::INIT:
      {
	ALFExtendedProgramGraphNodeGlobalInit * init_node = dynamic_cast<ALFExtendedProgramGraphNodeGlobalInit *>(epg_node);
	alf::CInitTuple * init = init_node->GetInit();
	defining_inits->insert(init);
	break;
      }
    }
  }
}

// -------------------------------------------------------
// Help function which goes through all rd units in vector 
// and returns the epg node the rd unit was created from.
// -------------------------------------------------------
void 
ALFReachingDefinitionsAnalysis::
ExtractEPGNodesFromRDUnits(std::vector<RDUnit *> * rd_units, 
			   std::set<ALFExtendedProgramGraphNode *> * epg_nodes)
{
  // Go through all rd units and extract the node they originate from
  for(std::vector<RDUnit *>::iterator rd_unit = rd_units->begin();
      rd_unit != rd_units->end(); ++rd_unit) {
    EPGNodeRDUnit * epg_node_rd_unit = dynamic_cast<EPGNodeRDUnit *>(*rd_unit);
    ALFExtendedProgramGraphNode * epg_node = epg_node_rd_unit->GetEPGNode();
    epg_nodes->insert(epg_node);
  }
}


