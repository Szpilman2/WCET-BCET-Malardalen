// $Id $

#ifndef GLOBALS_H_
#define GLOBALS_H_

#include <string>
#include <memory>

// Forward declare some classes
class ValueDomain;
class Endianness;

// Domain
extern std::unique_ptr<ValueDomain> domain;

// Global variables
extern bool g_ignore_stores_to_int_addr;
extern bool g_do_widening_stepwise;
extern bool g_use_alternative_narrowing;
extern bool g_use_zero_maxiter_fix;
extern Endianness g_endianness;
extern bool g_ft_continue;
extern bool g_ft_warn;
extern std::string g_output_annotation_specification_file_name;
extern bool g_merged_outp_annots;
extern bool g_removed_alf_label;
extern bool g_removed_BB;
extern bool g_removed__bb;
extern bool g_unmangled_colons;

#endif


