/* $Id: $ */

#include "cmd/AvailableOptions.h"
#include "cmd/CInputOptions.h"
#include "cmd/COptionGroups.h"
#include "cmd/CCommand.h"
#include "cmd/CCommands.h"
#include "cmd/CSession.h"
#include "cmd/version.h"
#include "tools/MSVCMemDebug.h"
#include <cstdio>
#include <stdexcept>
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ciso646>

using namespace std;
using namespace cmd;

/** This is the SWEET program: First check out what the user wants us to do.
   Once we know (and the user did not try to fool us) then do it. It is as
   simple as it can be! */
int main(int nr_of_args, char **args)
{
#ifdef MSVCMEMDEBUG_ENABLED
   _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif

   int return_value = 0;
   unique_ptr <COptionGroups> available_options = AvailableOptions();
   CSession session;
   CCommands commands;
   cout << "SWEET version " << SWEET_VERSION << " (" << SWEET_DATE << ')' << endl;
   try {
      CInputOptions input_options(nr_of_args, args);
      available_options->MatchInput(input_options, commands);
      session.SetCommands(&commands);
      session.ValidateCommands();

      try { 
         session.DispatchCommands();
      }
      catch (exception &e) {
         cerr << "Program aborted: " << e.what() << endl;
         return_value = 1;
      }
   }
   catch (runtime_error &e) {
      const COption *help_option = available_options->FindOption(COption::HELP);
      cerr << e.what() << endl;
      cerr << "Try \"" << *args << " --" << help_option->GetLongName() << "\""<< endl;
      return_value = 1;
   }

   return return_value;
}

