/********************************************************
* dominance.h
* Definitions for dominance.cpp
* $Id: dominance.h 1065 2009-09-28 08:05:47Z csg01 $
*********************************************************/

// Code for calculating immediated dominators from a rooted graph (e.g. a CFG)

#ifndef DOMINANCE_H_INCLUDED
#define DOMINANCE_H_INCLUDED

#include "graphs/tools/CGraph.h"
#include <map>
#include <set>
#include <list>
#include <string>
#include <stdexcept>
#include <iostream>

using namespace std;

class Empty
{
public:
   Empty *Copy() { return NULL; }
};

template <typename T_Node, typename T_Sub_Edgedata=Empty>
class CDominance
{
public:

   // Calculates immediate dominators in a graph using Tarjan/Lengauer
   // graph - The flow graph to calculate the dominance relation for
   // idom - The resulting immediate dominance-mapping. The immediate dominator of a node n is given by idom[n].
   // location - Text for error case
   void CalculateIdom(CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<T_Node *, T_Node * > *idom, std::string const& location);

   // Calculates immediate post dominators in a graph. Maybe not the most efficient solution,
   // since we create a reversed graph which we run the CalculateIdom code upon.
   // graph - The flow graph to calculate the dominance relation for
   // ipdom - The resulting immediate post dominance-mapping. The immediate post dominator of a node n is given by ipdom[n].
   // location - Text for error case
   void CalculateIPdom(CGraph <T_Node, T_Sub_Edgedata> const* graph,
                       std::map<T_Node *, T_Node * > *ipdom, std::string const& location);

   // Calculates a post dominator tree for a graph. After the call, the set of nodes immediately post-dominated by a
   // node n is given by rev_ipdom[n], and start_nodes holds those nodes which have no post dominators.
   // Only if the graph has more than one exit node will start_nodes.size() > 1.
   void CalculateIPdomRev(CGraph <T_Node, T_Sub_Edgedata> const* graph,
                          std::map<T_Node *, std::set<T_Node * > > & rev_ipdom,
                          std::string const& location, std::set<T_Node *> & start_nodes); 

   // Calculates the total dominance relation, i.e. there is an edge from every node to its dominators.
   // graph - The flow graph to calculate the dominance relation for
   // dom - The resulting dominance relation. dom[n1->Id()*graph->NrOfNodes() + n2->Id()] is true if n2 dominates n1
   // Uses the immediate dominator relation to build the total dominance relation.
   void CalculateDominance(CGraph <T_Node, T_Sub_Edgedata> *graph, std::vector<char> *dom);
   // This is a version that also returns the immediate relation as a side effect.
   void CalculateDominance(CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<T_Node*, T_Node*> *idom, std::vector<char> *dom);
   // These versions omit the edges n = dom(n), since that is an often not desired relation.
   void CalculateDominanceMinimal(CGraph <T_Node, T_Sub_Edgedata> *graph, std::vector<char> *dom);
   void CalculateDominanceMinimal(CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<T_Node*, T_Node*> *idom, std::vector<char> *dom);

   // Calculates the total post dominance relation, i.e. there is an edge from every node to its post dominators.
   // graph - The flow graph to calculate the post dominance relation for
   // dom - The resulting post dominance relation. dom[n1->Id()*graph->NrOfNodes() + n2->Id()] is true if n2 dominates n1
   // Uses the immediate post dominator relation to build the total post dominance relation.
   void CalculatePostDominance(CGraph <T_Node, T_Sub_Edgedata> *graph, std::vector<char> *pdom);
  // This is a version that also returns the immediate relation as a side effect.
   void CalculatePostDominance(CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<T_Node*, T_Node*> *ipdom, std::vector<char> *pdom);
   // These versions omit the edges n = pdom(n), since that is an often not desired relation.
   void CalculatePostDominanceMinimal(CGraph <T_Node, T_Sub_Edgedata> *graph, std::vector<char> *pdom);
   void CalculatePostDominanceMinimal(CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<T_Node*, T_Node*> *ipdom, std::vector<char> *pdom);

   // Calculates dominance frontier for a graph. The dominance frontier of a node n is the set all nodes, y, 
   // such that b dominates a predecessor of y but does not strictly dominate y. The dominance frontier
   // is used in the control-dependency graph (CDG) derivation, which is used in the program slicing.
   void CalculateDominanceFrontier(CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<T_Node*, std::set<T_Node*> *> *df);
  // To get the reversed dominance frontier
   void CalculateDominanceFrontierRev(CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<T_Node*, std::set<T_Node*> *> *df);

  // Calculate a control dependency mapping, based on reversed dominance frontier. The input graph must have 
  // a unique entry node a unique exit node and an edge between the entry and exit node. If not, the analysis 
  // will terminate with an error. 
  void CalculateControlDependency(CGraph <T_Node, T_Sub_Edgedata> *org_graph, 
				  std::map<T_Node*, std::set<T_Node*> *> *cd);
  // Alternative representation. Here the nodes are identified by the
  // Id() in the graph. If input graph does not have a unique entry
  // node we might generate such a node index. Returned bool is true
  // if the entry node was found in org graph, otherwise false;
  bool CalculateControlDependency(CGraph <T_Node, T_Sub_Edgedata> *org_graph, 
				  std::map<unsigned int, std::set<unsigned int> *> *cd, 
				  unsigned int *entry_node_id);

  // A third alternative. The graph is now represented as a set of
  // nodes and a set of edges. The nodes are represented as unsigned
  // ints. Their numbers must be from 0...number_of_nodes-1, and
  // number_of_nodes must be exactly as many unique node numbers there
  // are in the set of pairs. If the input graph does not have a
  // unique entry node we might generate such a node index. Returned
  // bool is true if the entry node was found in org graph, otherwise
  // false. Should maybe be moved outside the templatification?
  bool CalculateControlDependency(unsigned int number_of_nodes, 
				  const std::set<std::pair<unsigned int, unsigned int> > * edges,
				  std::map<unsigned int, std::set<unsigned int> *> *cd, 
				  unsigned int *entry_node_id);
  
  // When the input graph does not fulfil the requirement of the cdg algorithm. We will however
  // Not modify the original graph. Instead we create a graph from the original graph, performs
  // the analysis on this graph, and then maps back the result to the original graph.
  void CreateWrapperGraphAndCalculateControlDependency(CGraph <T_Node, T_Sub_Edgedata> *org_graph, std::map<T_Node*, std::set<T_Node*> *> *cd);
  // The actual control dependency analysis. Done when no checking is
  // needed for the graph.
  void CalculateControlDependency2(CGraph <T_Node, T_Sub_Edgedata> *org_graph, std::map<T_Node*, std::set<T_Node*> *> *cd);


protected:

  // Help function
  void CalculateIPdom(CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<T_Node *, T_Node * > *ipdom, std::map<T_Node *, std::set<T_Node * > > *rev_ipdom, std::string location);
 
private:
   int n;
   std::map<T_Node *, int> semi;
   std::map<T_Node *, T_Node *> parent;
   std::map<T_Node *, T_Node *> label;
   std::map<T_Node *, T_Node *> ancestor;

   inline void LINK(T_Node * from, T_Node * to) { ancestor[to]=from; }

   inline void COMPRESS(T_Node *v)
   {
      if(ancestor[ancestor[v]] != NULL) {
         COMPRESS(ancestor[v]);
         if(semi[label[ancestor[v]]] < semi[label[v]]) {
            label[v]=label[ancestor[v]];
         }
         ancestor[v]=ancestor[ancestor[v]];
      }
   }

   void DFS2(T_Node *v, std::map<int, T_Node *, std::less<int> >  *vertex, bool reset);
   void DFS(T_Node *v, CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<int, T_Node *, std::less<int> >  *vertex, std::string location);
   T_Node *EVAL(T_Node *v);
};

template <typename T_Node, typename T_Sub_Edgedata>
T_Node *CDominance<T_Node, T_Sub_Edgedata>::EVAL(T_Node *v)
{
   if(ancestor[v] == NULL) {
      return v;
   } else {
      COMPRESS(v);
      return label[v];
   }
}

template <typename T_Node, typename T_Sub_Edgedata>
void CDominance<T_Node, T_Sub_Edgedata>::DFS2(T_Node *v, 
                                              std::map<int, T_Node *, std::less<int> >  *vertex, 
                                              bool reset)
{
  if(reset) {
    label.clear();
    semi.clear();
    parent.clear();
    ancestor.clear();
  }

  n++;
  semi[v]=n;                      // Store number of current node
  (*vertex)[n]=v;                 // Create mapping from number => node
  label[v]=v;                     // All labels are loopback to start with...
                                  // Loop through all ancestors

  assert(v);
  for(typename T_Node::succ_iterator to=v->SuccBegin(); to != v->SuccEnd(); ++to) {
    if(semi[to->node] == 0) {    // If not already visited
      parent[to->node] = v;     // Set parentinformation for ancestor
      DFS2(to->node, vertex, false); // Search in depth first manner
    }
  }
}

template <typename T_Node, typename T_Sub_Edgedata>
void CDominance<T_Node, T_Sub_Edgedata>::CalculateDominanceMinimal(CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<T_Node *, T_Node * > *idom,
                                                                   std::vector<char> *dom)
{
   CalculateIdom(graph, idom, "");
   int n_nodes = graph->NrOfNodes();
   dom->resize(n_nodes * n_nodes);

   typename std::map<T_Node *, T_Node * >::const_iterator n1;
   for (n1 = idom->begin(); n1 != idom->end(); n1++) {
      for (T_Node *n2 = n1->second; (*idom)[n2]; n2 = (*idom)[n2]) {
         (*dom)[n1->first->Id() * n_nodes + (*idom)[n2]->Id()] = 1;
      }
   }
}

template <typename T_Node, typename T_Sub_Edgedata>
void CDominance<T_Node, T_Sub_Edgedata>::CalculateDominanceMinimal(CGraph <T_Node, T_Sub_Edgedata> *graph, std::vector<char> *dom)
{
   std::map<T_Node *, T_Node * > idom;
   CalculateDominanceMinimal(graph, &idom, dom);
}

template <typename T_Node, typename T_Sub_Edgedata>
void CDominance<T_Node, T_Sub_Edgedata>::CalculateDominance(CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<T_Node *, T_Node * > *idom,
                                                            std::vector<char> *dom)
{
   CalculateDominanceMinimal(graph, idom, dom);
   int n_nodes = graph->NrOfNodes();

   /* A node also dominates itself. */
   for (int i=0; i<n_nodes; i++) {
      (*dom)[i*n_nodes + i] = 1;
   }
}

template <typename T_Node, typename T_Sub_Edgedata>
void CDominance<T_Node, T_Sub_Edgedata>::CalculateDominance(CGraph <T_Node, T_Sub_Edgedata> *graph, std::vector<char> *dom)
{
   std::map<T_Node *, T_Node * > idom;
   CalculateDominance(graph, &idom, dom);
}

// Code for calculating immediate dominator
template <typename T_Node, typename T_Sub_Edgedata>
void CDominance<T_Node, T_Sub_Edgedata>::CalculateIdom(CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<T_Node *, T_Node * > *dom,
                                                       std::string const& location)
{
   T_Node *w;
   typedef std::multimap<T_Node * , T_Node * > t_bucket;
   t_bucket bucket;

   // This algorithm requires a distinct entry node. In case the graph contains more
   // than one entry node then we have to patch it with a dummy node connecting the different
   // entry nodes in order to make it work. We need to remove this node when finished.
   T_Node *new_entry_node = NULL;
   std::list<T_Node*> entry_nodes;
   graph->GetEntryNodes(&entry_nodes);
   bool lacks_distinct_entry_node = entry_nodes.size() > 1;
   if (lacks_distinct_entry_node) {
      // Make the new node as a copy of an arbitrary node.
      T_Node *root = graph->Root();
      assert(root);
      new_entry_node = root->Copy();
      graph->AddNode(new_entry_node);
      for (typename std::list<T_Node*>::iterator node_it=entry_nodes.begin(); node_it!=entry_nodes.end(); ++node_it) {
         T_Node *entry_node = *node_it;
         graph->AddEdge(new_entry_node, entry_node);
      }
      graph->FindRoot();
   }

   // This algorithm requires a distinct exit node. In case the graph contains more
   // than one then we have to patch it with a dummy node connecting the different
   // exit nodes in order to make it work. We need to remove this node when finihsed.
   T_Node *new_exit_node = NULL;
   std::list<T_Node*> exit_nodes;
   graph->GetExitNodes(&exit_nodes);
   bool lacks_distinct_exit_node = exit_nodes.size() > 1;
   if (lacks_distinct_exit_node) {
      // Make the new node as a copy of an arbitrary node.
      T_Node *root = graph->Root();
      assert(root);
      new_exit_node = root->Copy();
      graph->AddNode(new_exit_node);
      for (typename std::list<T_Node*>::iterator node_it=exit_nodes.begin(); node_it!=exit_nodes.end(); ++node_it) {
         T_Node *return_node = *node_it;
         graph->AddEdge(return_node, new_exit_node);
      }
      graph->FindExit();
   }

   // Get the root
   T_Node *root = graph->Root();
   assert(root);

   // Do a depth first search of the graph
   std::map<int, T_Node *, std::less<int> >  vertex;
   DFS(root, graph, &vertex, location);

   // STEP2
   for(unsigned i=graph->NrOfNodes(); i>1; i--)
   {
      // STEP2.1
      w=vertex[i];
      assert(w!=NULL);
      for(typename T_Node::pred_iterator i_node=w->PredBegin(); i_node != w->PredEnd(); ++i_node) {
         T_Node *u=EVAL(*i_node);
         if(semi[u] < semi[w]) {
            semi[w]=semi[u];
         }
      }
      //         bucket.insert( t_bucket::value_type( vertex[semi[w]], w));
      bucket.insert(std::pair<T_Node*, T_Node*>(vertex[semi[w]], w));
      LINK(parent[w], w);

      // STEP2.2
      for(typename t_bucket::iterator v_it=bucket.lower_bound(parent[w]); v_it != bucket.upper_bound(parent[w]); v_it++) {
         if(v_it->first==parent[w]) {
            T_Node *v=v_it->second;
            T_Node *u=EVAL(v);

            if(semi[u] < semi[v]) {
               (*dom)[v]=u;
            } else {
               (*dom)[v]=parent[w];
            }
         }
      }
      bucket.erase(parent[w]);
   }

   // STEP 3
   for(unsigned i=2; i<=graph->NrOfNodes(); i++) {
      w=vertex[i];
      if ((*dom)[w]!=vertex[semi[w]]) {
         (*dom)[w]=(*dom)[(*dom)[w]];
      }
   }
   (*dom)[root]=NULL;

   // Remove the extra entry node if such node has been added
   if (lacks_distinct_entry_node) {
      // Get rid of the extra inserted node
      std::map<T_Node *, T_Node * > dom_copy;
      graph->RemoveNode(new_entry_node);
      delete new_entry_node;
      graph->FindRoot();

      // Filter out all references to that node.
      for (typename std::map<T_Node *, T_Node * >::iterator it=dom->begin(); it!=dom->end(); ++it) {
         if (it->first == new_entry_node || it->second == new_entry_node) {
            ; // drop it
         } else {
            dom_copy[it->first] = it->second;
         }
      }
      *dom = dom_copy;
   }

   // Remove the extra exit node if such node has been added
   if (lacks_distinct_exit_node) {
      // Get rid of the extra inserted node
      std::map<T_Node *, T_Node * > dom_copy;
      graph->RemoveNode(new_exit_node);
      delete new_exit_node;
      graph->FindExit();

      // Filter out all references to that node.
      for (typename std::map<T_Node *, T_Node * >::iterator it=dom->begin(); it!=dom->end(); ++it) {
         if (it->first == new_exit_node || it->second == new_exit_node) {
            ; // drop it
         } else {
            dom_copy[it->first] = it->second;
         }
      }
      *dom = dom_copy;
   }

   // Compress graph if needed
   if(lacks_distinct_entry_node || lacks_distinct_exit_node)
     graph->CompressGraph();
}

// -------------------------------------------------------
// Code for calculating immediate post dominator. Uses
// code for calculating immediate dominator on a reversed
// idgraph.
// -------------------------------------------------------

// We want nodes holding just an id
class CIdNode : public CNode<CIdNode, Empty>
{
public:
  CIdNode(void) {};
  CIdNode *Copy() { return new CIdNode(); }
  virtual ~CIdNode(void) {};
};

// Code for calculating immediate post dominator
template <typename T_Node, typename T_Sub_Edgedata>
void CDominance<T_Node, T_Sub_Edgedata>::
CalculateIPdom(CGraph <T_Node, T_Sub_Edgedata> const* org_graph,
               std::map<T_Node *, T_Node *> *ipdom,
               std::string const& location)
{
  // A reversed graph holding id nodes
  CGraph <CIdNode, Empty> rev_id_graph;

  // Loop through all original nodes and create corresponding id nodes
  unsigned nr_of_nodes = org_graph->NrOfNodes();
  for(unsigned i = 0; i < nr_of_nodes; i++)
    {
      // Create a new id node
      CIdNode * id_node = new CIdNode();
      rev_id_graph.AddNode(id_node);
      // Make sure that the newly created node has got the right id
      assert(id_node->Id() == i);
    }

  // Loop through all the nodes again and for each edge we create a
  // reversed edge
  for(unsigned i = 0; i < nr_of_nodes; i++)
    {
      // Get the node in the graph and its id
      T_Node * node = org_graph->NodeAt(i);
      assert(node);
      int node_id = node->Id();

      // Get the corresponding node in the reversed graph
      CIdNode * id_node = rev_id_graph.NodeAt(node_id);

      // Loop through all successors of the original graph
      for(typename T_Node::succ_iterator succ = node->SuccBegin();
          succ != node->SuccEnd(); succ++)
        {
          // Get the id of the succ
          assert((*succ).node);
          int succ_id = (*succ).node->Id();

          // Get the corresponding node in the reversed graph
          CIdNode * succ_id_node = rev_id_graph.NodeAt(succ_id);

          // Create the reversed edge
          rev_id_graph.AddEdge(succ_id_node, id_node);
        }
    }

  // Calculate IDom on the reversed id graph
  std::map<CIdNode *, CIdNode *, std::less<CIdNode *> > id_ipdom;
  CDominance<CIdNode> dominance;
  dominance.CalculateIdom(&rev_id_graph, &id_ipdom, location);

  // Update the resulting ipdom map with the obtained result
  for(unsigned i = 0; i < nr_of_nodes; i++)
    {
      // Get the node in the graph and its id
      T_Node * node = org_graph->NodeAt(i);
      int node_id = node->Id();

      // Get the corresponding CIdNode
      CIdNode * id_node = rev_id_graph.NodeAt(node_id);

      // Get the corresponding immediate post dominator
      CIdNode * ipdom_id_node = id_ipdom[id_node];

      // Get the corresponding orginal node (if any)
      T_Node * ipdom_node = NULL;
      if(ipdom_id_node)
        {
          int id = ipdom_id_node->Id();
          ipdom_node = org_graph->NodeAt(id);
        }

      // Update the resulting ipdom map
      (*ipdom)[node] = ipdom_node;
  }

   for(unsigned i = 0; i < nr_of_nodes; ++i)
      delete rev_id_graph.NodeAt(i);
}

// Code for calculating immediate post dominator.
template <typename T_Node, typename T_Sub_Edgedata>
void CDominance<T_Node, T_Sub_Edgedata>::
CalculateIPdomRev(CGraph <T_Node, T_Sub_Edgedata> const* org_graph,
                  std::map<T_Node *, std::set<T_Node *> > & ipdom_rev,
                  std::string const& location,
                  std::set<T_Node *> & start_nodes)
{
  // Loop through all nodes, creating a corresponding node set for
  // each node
  int i = 0;
  int nr_of_nodes = org_graph->NrOfNodes();
  for(i = 0; i < nr_of_nodes; i++)
    {
      // Get the node in the graph by its index
      T_Node * node = org_graph->NodeAt(i);
      assert(node);
      // Assign an empty node set to the node in the map
      ipdom_rev[node].clear();
    }

  // Call help function
  std::map<T_Node *, T_Node *, std::less<T_Node *> > ipdom;
  CDominance<T_Node,T_Sub_Edgedata> dominance;
  dominance.CalculateIPdom(org_graph, &ipdom, location);

  // Loop through created ipdom map, creating reverse mapping
  typename std::map<T_Node *, T_Node *>::iterator ipd;
  for(ipd = ipdom.begin(); ipd != ipdom.end(); ipd++)
    {
      // Add the node to the ipdom set
      T_Node * node = (*ipd).first;
      T_Node * ipdominator = (*ipd).second;
      // Only assign if we have a ipdominator for the node
      if(ipdominator)
        ipdom_rev[ipdominator].insert(node);
      else
        start_nodes.insert(node);
    }
}

// template <typename T_Node, typename T_Sub_Edgedata>
// void CDominance<T_Node, T_Sub_Edgedata>::
// CalculateIPdomRevUsingMustBeTakenDataFlowAnalysis(CGraph <T_Node, T_Sub_Edgedata> const* org_graph,
//                                                   std::map<T_Node *, std::set<T_Node *> > & ipdom_rev,
//                                                   T_Node ** start_node)
// {
//   // Create a mappings needed by taken before data flow analysis
//   std::set<std::pair<T_Node *, CBitVectorWithBot *> > node_to_input_state;
//   std::set<std::pair<T_Node *, CBitVectorWithBot *> > node_to_output_state;
//   std::set<std::pair<T_Node *, T_Node *> > node_to_succ_node;
//   std::map<T_Node *, unsigned int> node_to_index;
//   std::set<T_Node *> start_nodes;
//   std::vector<CBitVector *> post_dominate;
//   std::vector<CBitVector *> immidiate_post_dominate;

//   // Loop through all nodes in the input graph update the mappings
//   unsigned nr_of_nodes = org_graph->NrOfNodes();
//   for(unsigned i = 0; i < nr_of_nodes; i++) {
//     T_Node * node = org_graph->NodeAt(i);
//     node_to_input_state.insert(std::make_pair(node, new CBitVectorWithBot(nr_of_nodes)));
//     node_to_output_state.insert(std::make_pair(node, new CBitVectorWithBot(nr_of_nodes)));
//     rev_node_to_input_state[node] = new CBitVector(nr_of_nodes);
//     node_to_index[node] = i;
//     // We reverse the graph,
//     if(node->SuccSize() == 0) {
//       // Nodes with node successors becomes start nodes
//       start_nodes.insert(node);
//     }
//     else {
//       // We set all successors of a node to being a predecessor of the
//       // node in the DFA
//       for(typename T_Node::succ_iterator succ = node->SuccBegin();
//           succ != node->SuccEnd(); succ++) {
//         node_to_succ_node[*succ] = node;
//       }
//     }
//   }

//   // Do the must be taken before data flow analysis
//   MustBeTakenBeforeDataFlowAnalysis<T_Node> dfa(&node_to_input_state, &node_to_output_state, &node_to_succ_node, &node_to_index);
//   std::list<FIXPOINT_PASS> run_list;
//   run_list.push_back(NORMAL);
//   dfa->Run(NODE_ORDERING, &run_list, FORWARD, &start_nodes);

//   // Create a reversed node to input state map. A node i will
//   // have a node j in its vector if i post-dominates j.
//   for(unsigned i = 0; i < nr_of_nodes; i++) {
//     T_Node * node = org_graph->NodeAt(i);
//     CBitVectorWithBot * input_state = dfa->GetInputState(node);
//     for(unsigned j = 0; j < nr_of_nodes; j++) {
//       if(input_state->ElementExists(j)) {
//         post_dominate[j]->AddElement(i);
//       }
//     }
//   }

//   // Create an immidiate post dominator relation. A node i will
//   // have a node j in its vector if i immidiate post-dominates j.
//   for(unsigned i = 0; i < nr_of_nodes; i++) {


// Runs a Depth First Search on CFG g, starting from v
// and numbers the nodes accordingly
template <typename T_Node, typename T_Sub_Edgedata>
void CDominance<T_Node, T_Sub_Edgedata>::DFS(T_Node *v, CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<int, T_Node *, std::less< int > >  *vertex, std::string location)
{
  assert(v);
  n = 0;
  DFS2(v, vertex, true);

  std::set<int> ids_in_vertex;
  for (typename std::map<int, T_Node *, std::less< int > >::const_iterator vit=vertex->begin(); vit!=vertex->end(); vit++)
      ids_in_vertex.insert(vit->second->Id());

  for (typename CGraph<T_Node, T_Sub_Edgedata>::node_iterator it=graph->NodesBegin(); it!=graph->NodesEnd(); it++)
  {
     if (ids_in_vertex.find((*it)->Id()) == ids_in_vertex.end())
        std::cerr << "WARNING! A loop without exit edge has been detected in " << location << ". This code is not analyzable\n";
  }
}

// Code for calculating post domininace. Derived using immediate post-dominance relation. 
template <typename T_Node, typename T_Sub_Edgedata>
void CDominance<T_Node, T_Sub_Edgedata>::CalculatePostDominanceMinimal(CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<T_Node *, T_Node * > *ipdom,
                                                                       std::vector<char> *pdom)
{
   CalculateIPdom(graph, ipdom, "");
   int n_nodes = graph->NrOfNodes();
   pdom->resize(n_nodes * n_nodes);

   typename std::map<T_Node *, T_Node * >::const_iterator n1;
   for (n1 = ipdom->begin(); n1 != ipdom->end(); n1++) {
      for (T_Node *n2 = n1->second; (*ipdom)[n2]; n2 = (*ipdom)[n2]) {
         (*pdom)[n1->first->Id() * n_nodes + (*ipdom)[n2]->Id()] = 1;
      }
   }
}

template <typename T_Node, typename T_Sub_Edgedata>
void CDominance<T_Node, T_Sub_Edgedata>::CalculatePostDominanceMinimal(CGraph <T_Node, T_Sub_Edgedata> *graph, std::vector<char> *pdom)
{
   std::map<T_Node *, T_Node * > ipdom;
   CalculatePostDominanceMinimal(graph, &ipdom, pdom);
}

template <typename T_Node, typename T_Sub_Edgedata>
void CDominance<T_Node, T_Sub_Edgedata>::CalculatePostDominance(CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<T_Node *, T_Node * > *ipdom,
                                                                std::vector<char> *pdom)
{
   CalculatePostDominanceMinimal(graph, ipdom, pdom);
   int n_nodes = graph->NrOfNodes();

   /* A node also dominates itself. */
   for (int i=0; i<n_nodes; i++) {
      (*pdom)[i*n_nodes + i] = 1;
   }
}

template <typename T_Node, typename T_Sub_Edgedata>
void CDominance<T_Node, T_Sub_Edgedata>::CalculatePostDominance(CGraph <T_Node, T_Sub_Edgedata> *graph, std::vector<char> *pdom)
{
   std::map<T_Node *, T_Node * > ipdom;
   CalculatePostDominance(graph, &ipdom, pdom);
}

// Code for calculating the dominace frontier. 
// The dominance frontier is calculated using the algorithm in 
// A Simple, Fast Dominance Algorithm, Keith D. Cooper, Timothy J. Harvey, and Ken Kennedy
// SOFTWARE-PRACTICE AND EXPERIENCE, Softw. Pract. Exper. 2001; 4:1-10
// The following is their desription of the algorithm:
// First, we identify each join point, j - any node with more than one
// incoming edge is a join point. We then examine each predecessor, p,
// of j and walk up the dominator tree starting at p. We stop the walk
// when we reach j's immediate dominator - j is in the dominance
// frontier of each of the nodes in the walk, except for j's immediate
// dominator. Intuitively, all of the rest of j's dominators are
// shared by j's predecessors as well. Since they dominate j, they
// will not have j in their dominance frontiers.

template <typename T_Node, typename T_Sub_Edgedata>
void 
CDominance<T_Node, T_Sub_Edgedata>::
CalculateDominanceFrontier(CGraph <T_Node, T_Sub_Edgedata> *graph, std::map<T_Node*, std::set<T_Node*> *> *df)
{
  // Calculate immidiate dominator tree
  std::map<T_Node *, T_Node * > idom;
  CalculateIdom(graph, &idom, "Error in CalculateDominateFrontier");

  // Add empty df sets for all nodes in the graph 
  for(typename CGraph<T_Node, T_Sub_Edgedata>::node_iterator b=graph->NodesBegin(); 
       b!=graph->NodesEnd(); b++) {
    (*df)[*b] = new std::set<T_Node *>;
  } 

  // The algorithm as extracted from the paper. 
  // for all nodes b in graph do
  for(typename CGraph<T_Node, T_Sub_Edgedata>::node_iterator b=graph->NodesBegin(); 
      b!=graph->NodesEnd(); b++) {
    // if the number of predecessors of b >= 2
    if((*b)->PredSize() >= 2) {
      // for all predecessors p of b do 
      for(typename T_Node::pred_iterator p=(*b)->PredBegin(); p != (*b)->PredEnd(); ++p) {
	// Walk upwards in the dominator tree
	T_Node * runner = (*p);
	T_Node * idom_b = idom[*b];
	// while runner != idom[b] do 
	while(runner != idom_b) {
	  // add b to runners dominance frontier set
	  ((*df)[runner])->insert(*b);
	  // Go one step upwards in the dominator tree.  
	  runner = idom[runner];
	  }
      }
    }
  }

  // The result is in the df
  return;
}

template <typename T_Node, typename T_Sub_Edgedata>
void 
CDominance<T_Node, T_Sub_Edgedata>::
CalculateDominanceFrontierRev(CGraph <T_Node, T_Sub_Edgedata> *org_graph, std::map<T_Node*, std::set<T_Node*> *> *rev_df)
{
  // Add empty df sets for all nodes in the graph 
  for(typename CGraph<T_Node, T_Sub_Edgedata>::node_iterator b=org_graph->NodesBegin(); 
      b!=org_graph->NodesEnd(); b++) 
    {
      (*rev_df)[*b] = new std::set<T_Node *>;
    } 

  // We create a reversed graph and works on this one instead

  // A reversed graph holding id nodes
  CGraph <CIdNode, Empty> rev_id_graph;

  // Loop through all original nodes and create corresponding id
  // nodes. Also create empty nodes for resulting df mapping.
  unsigned nr_of_nodes = org_graph->NrOfNodes();
  for(unsigned i = 0; i < nr_of_nodes; i++)
    {
      // Create a new id node
      CIdNode * id_node = new CIdNode();
      rev_id_graph.AddNode(id_node);
      // Make sure that the newly created node has got the right id
      assert(id_node->Id() == i);
    }

  // Loop through all the nodes again and for each edge we create a
  // reversed edge
  for(unsigned i = 0; i < nr_of_nodes; i++)
    {
      // Get the node in the graph and its id
      T_Node * node = org_graph->NodeAt(i);
      assert(node);
      int node_id = node->Id();

      // Get the corresponding node in the reversed graph
      CIdNode * id_node = rev_id_graph.NodeAt(node_id);

      // Loop through all successors of the original graph
      for(typename T_Node::succ_iterator succ = node->SuccBegin();
          succ != node->SuccEnd(); succ++)
        {
          // Get the id of the succ
          assert((*succ).node);
          int succ_id = (*succ).node->Id();

          // Get the corresponding node in the reversed graph
          CIdNode * succ_id_node = rev_id_graph.NodeAt(succ_id);

          // Create the reversed edge
          rev_id_graph.AddEdge(succ_id_node, id_node);
        }
    }

  // Calculate dominance frontier on the reversed id graph. Note that
  // the dominance algorithm must have same template nodes and edges
  // as argument graph
  std::map<CIdNode *, std::set<CIdNode *> *> rev_id_df;
  CDominance<CIdNode, Empty> dominance;
  dominance.CalculateDominanceFrontier(&rev_id_graph, &rev_id_df);

  // Update the resulting dominance frontier map with the rev_id_df map 
  for(unsigned i = 0; i < nr_of_nodes; i++)
    {
      // Get the node in the graph and its id
      T_Node * node = org_graph->NodeAt(i);
      int node_id = node->Id();

      // Get the corresponding id_node 
      CIdNode * id_node = rev_id_graph.NodeAt(node_id);

      // Get the corresponding set of id nodes from df
      std::set<CIdNode *> * id_node_set = rev_id_df[id_node];
      for(typename std::set<CIdNode *>::iterator id_n = id_node_set->begin();
	  id_n != id_node_set->end(); ++id_n) {
	
	// Get the corresponding orginal node 
	int id = (*id_n)->Id();
	T_Node * n = org_graph->NodeAt(id);
	assert(node);

	// Update the resulting rev_df map
	((*rev_df)[node])->insert(n);
      }
    }

  // Delete temporary nodes
  for(unsigned i = 0; i < nr_of_nodes; ++i)
    delete rev_id_graph.NodeAt(i);

  // Delete temporary sets 
  for(std::map<CIdNode *, std::set<CIdNode *> *>::iterator n2s = rev_id_df.begin();
      n2s != rev_id_df.end(); ++n2s) {
    delete (*n2s).second;
  }
}

// We derive a CDG using the algorithm specified in 
// Efficiently Computing Static Single Assignment Form and the Control Dependence Graph
// Ron Cytron, Jeanne Ferrante, Barry K. Rosen, Mark N. Wegman, F. Kenneth Zadeck
// ACM Transactions on Programming Languages and Systems (TOPLAS) TOPLAS 
// Volume 13 Issue 4, Oct. 1991 

// build RCFG
// build dominator tree for RCFG
// derive dominance frontier mapping RDF for RCFG
// for each node X do CD(X) = {} 
// for each node Y do
//   for each X in RDF(Y) do
//     CD(X) = CD(X) U { Y }
//   end
// end

template <typename T_Node, typename T_Sub_Edgedata>
void 
CDominance<T_Node, T_Sub_Edgedata>::
CalculateControlDependency(CGraph <T_Node, T_Sub_Edgedata> *org_graph, std::map<T_Node*, std::set<T_Node*> *> *cd)
{
  // Check if we have a single entry node, a single exit node and if there
  // is a edge from entry to exit. This is a requirement of the algorithm.
  assert(org_graph->FindRoot() && org_graph->FindExit());
  assert(org_graph->Root()->IsSucc(org_graph->Exit())); 

  // The graph is ok, call the real function
  CalculateControlDependency2(org_graph, cd);
}

template <typename T_Node, typename T_Sub_Edgedata>
void 
CDominance<T_Node, T_Sub_Edgedata>::
CalculateControlDependency2(CGraph <T_Node, T_Sub_Edgedata> *org_graph, std::map<T_Node*, std::set<T_Node*> *> *cd)
{
  // Derive the reverse dominance frontier mapping
  std::map<T_Node *, std::set<T_Node *> *> rdf;
  CalculateDominanceFrontierRev(org_graph, &rdf);

  // Add empty cd sets fo all nodes in the graph 
  for(typename CGraph<T_Node, T_Sub_Edgedata>::node_iterator x=org_graph->NodesBegin(); 
      x!=org_graph->NodesEnd(); x++) {
    (*cd)[*x] = new std::set<T_Node *>;
  }   

  // Loop through all nodes in the graph
  for(typename CGraph<T_Node, T_Sub_Edgedata>::node_iterator y=org_graph->NodesBegin(); 
      y!=org_graph->NodesEnd(); y++) {
    // Get the set of nodes in the rdf(y)    
    std::set<T_Node *> * rdf_nodes = rdf[*y];
    // For each node x in rdf(y) do
    for(typename std::set<T_Node *>::iterator x = rdf_nodes->begin(); x != rdf_nodes->end(); ++x) {
      // cd(x) = cd(x) U { y }
      ((*cd)[*x])->insert(*y);
    }
  }

  // Delete extra sets in reverse dominance frontier mapping
  for(typename std::map<T_Node *, std::set<T_Node *> *>::iterator n2ns = rdf.begin();
      n2ns != rdf.end(); ++n2ns) {
    delete (*n2ns).second;
  }
}

// When we want to return the control depenency graph as a mapping from node
// index to the nodes that are control dependant on this node.
template <typename T_Node, typename T_Sub_Edgedata>
bool
CDominance<T_Node, T_Sub_Edgedata>::
CalculateControlDependency(CGraph <T_Node, T_Sub_Edgedata> *org_graph, 
			   std::map<unsigned int, std::set<unsigned int> *> *cd,
			   unsigned int *entry_node_id)
{
  // We create a id node graph with nodes only holding node id:s
  CGraph<CIdNode, Empty> id_graph;

  // Loop through all org nodes and create corresponding id nodes.
  unsigned nr_of_nodes = org_graph->NrOfNodes();
  for(unsigned i = 0; i < nr_of_nodes; i++) {
      // Create a new id node
      CIdNode * id_node = new CIdNode();
      id_graph.AddNode(id_node);
      // Make sure that the newly created node has got the right id
      assert(id_node->Id() == i);
    }

  // To hold entry and exit node.
  CIdNode * entry_id_node = NULL; 
  CIdNode * exit_id_node = NULL;

  // To hold if new entry and exit nodes has been created
  bool new_entry_id_node_created = false;
  bool new_exit_id_node_created = false;

  // Check if we need to create a new entry id node
  bool unique_entry_node = org_graph->FindRoot();
  if(unique_entry_node) {
    // Org node ok, set corresponding id node as entry
    T_Node * entry_node = org_graph->Root();
    entry_id_node = id_graph.NodeAt(entry_node->Id());
  }
  else {
    // Org node not ok,  create new id node
    entry_id_node = new CIdNode();
    id_graph.AddNode(entry_id_node);
    new_entry_id_node_created = true;
  }

  // Create new exit node 
  exit_id_node = new CIdNode();
  id_graph.AddNode(exit_id_node);
  new_exit_id_node_created = true;

  // Loop through all the nodes again and for each org edge we create
  // an edge in the new id node graph
  for(unsigned i = 0; i < nr_of_nodes; i++) {
    // Get the node in the graph and its id
    T_Node * node = org_graph->NodeAt(i);
    assert(node);
    int node_id = node->Id();
    // Get the corresponding node in the graph
    CIdNode * id_node = id_graph.NodeAt(node_id);
    // Loop through all successors of the original graph
    for(typename T_Node::succ_iterator succ = node->SuccBegin();
	succ != node->SuccEnd(); succ++) {
      // Get the id of the succ
      assert((*succ).node);
      int succ_id = (*succ).node->Id();
      // Get the corresponding node in the graph
      CIdNode * succ_id_node = id_graph.NodeAt(succ_id);
      // Create the edge
      id_graph.AddEdge(id_node, succ_id_node);
    }
  }

  // If needed, add edges from entry id node to org entry nodes 
  if(new_entry_id_node_created) {
    std::list<T_Node*> org_entry_nodes;
    org_graph->GetEntryNodes(&org_entry_nodes);
    for(typename std::list<T_Node*>::iterator oen = org_entry_nodes.begin();
	oen != org_entry_nodes.end(); ++oen) {
      // Get node id and the corresponding id node
      int id = (*oen)->Id();
      CIdNode * id_node = id_graph.NodeAt(id);
      // Add edge from id_node to start id_node in id graph
      id_graph.AddEdge(entry_id_node, id_node);
    }
  }

  // If needed, add edges from exit id node to id nodes corresponding to org exit nodes 
  if(new_exit_id_node_created) {
    std::list<T_Node*> org_exit_nodes;
    org_graph->GetExitNodes(&org_exit_nodes);
    for(typename std::list<T_Node*>::iterator oen = org_exit_nodes.begin();
	oen != org_exit_nodes.end(); ++oen) {
      // Get node id and the corresponding id node
      int id = (*oen)->Id();
      CIdNode * id_node = id_graph.NodeAt(id);
      // Add edge from exit id_node to identified id_node 
      id_graph.AddEdge(id_node, exit_id_node);
    }
  }

  // If needed, add edge from start node to exit node
  if(!entry_id_node->IsSucc(exit_id_node)) {
    id_graph.AddEdge(entry_id_node, exit_id_node);
  }    

  // Calculate the control dependency on the new id graph. This returns 
  // a mapping between id_nodes and their control dependant nodes
  std::map<CIdNode*, std::set<CIdNode*> *> id_cd;
  CDominance<CIdNode, Empty> dominance;
  dominance.CalculateControlDependency2(&id_graph, &id_cd);

  // Go through the derived control dependencies and update argument
  // map accordingly
  for(typename std::map<CIdNode*, std::set<CIdNode*> *>::iterator id_n2ns = id_cd.begin();
      id_n2ns != id_cd.end(); ++id_n2ns) {
	
    // Get the mapping between id nodes <and their control dependant id nodes
    CIdNode* id_node = (*id_n2ns).first;    
    unsigned id = (*id_n2ns).first->Id();

    // Skip exit node
    if(new_exit_id_node_created && id_node == exit_id_node)
      continue;

    // Create an empty set for the ids
    std::set<unsigned int> * cds = new std::set<unsigned int>;

    std::set<CIdNode*> * id_nodes = (*id_n2ns).second;
    for(typename std::set<CIdNode *>::iterator n = id_nodes->begin();
        n != id_nodes->end(); ++n) {
      // Skip the exit node
      if(new_exit_id_node_created && (*n) == exit_id_node)
	continue;
      // Add the id to the resulting set
      cds->insert((*n)->Id());
    }
    
    // Add the created set to the resulting map
    (*cd)[id] = cds;      
  }

  // Delete temporary sets 
  for(typename std::map<CIdNode*, std::set<CIdNode*> *>::iterator id_n2ns = id_cd.begin();
      id_n2ns != id_cd.end(); ++id_n2ns) {
    delete (*id_n2ns).second;
  }
  
  // Mapping has been updated, return entry node id and if we created
  // a new entry node or not
  (*entry_node_id) = entry_id_node->Id();
  return new_entry_id_node_created;
}


// When the nodes in the input graph is represented as numbers, and
// edges as pairs of numbers. The resulting control dependency graph
// is represnted as a mapping from node index to the nodes that are
// control dependant on this node.
template <typename T_Node, typename T_Sub_Edgedata>
bool
CDominance<T_Node, T_Sub_Edgedata>::
CalculateControlDependency(unsigned int nr_of_nodes, const std::set<std::pair<unsigned int, unsigned int> > * edges,
			   std::map<unsigned int, std::set<unsigned int> *> *cd,
			   unsigned int *entry_node_id)
{
  // We create a id node graph with nodes only holding node id:s
  CGraph<CIdNode, Empty> id_graph;

  // Loop through all org nodes and create corresponding id nodes.
  for(unsigned i = 0; i < nr_of_nodes; i++) {
      // Create a new id node 
      CIdNode * id_node = new CIdNode();
      id_graph.AddNode(id_node);
      // Make sure that the newly created node has got the right id
      assert(id_node->Id() == i);
    }  

  // Loop through all edge pairs and create a corresponding edge 
  for(typename std::set<std::pair<unsigned int, unsigned int> >::const_iterator e = edges->begin();
      e != edges->end(); ++e) {
    // Get the id of the edges
    unsigned int from_node = (*e).first;
    unsigned int to_node = (*e).second;
    assert(from_node < nr_of_nodes && to_node < nr_of_nodes);

    // Get the corresponding nodes from the id_node graph
    CIdNode * from_id_node = id_graph.NodeAt(from_node);
    CIdNode * to_id_node = id_graph.NodeAt(to_node);
    
    // Create the edge
    id_graph.AddEdge(from_id_node, to_id_node);
  }

  // To hold entry and exit node.
  CIdNode * entry_id_node = NULL; 
  CIdNode * exit_id_node = NULL;
  
  // To hold if new entry and exit nodes has been created
  bool new_entry_id_node_created = false;
  bool new_exit_id_node_created = false;
  
  // To hold original entry and exit nodes (before adding our own)
  std::list<CIdNode *> org_entry_id_nodes;
  std::list<CIdNode *> org_exit_id_nodes;

  // Check if we should create an extra entry node
  bool unique_entry_id_node = id_graph.FindRoot();
  if(unique_entry_id_node) {
    // Set corresponding id node as entry
    entry_id_node = id_graph.Root();
  }
  else {
    // Org node not ok,  create new id node
    id_graph.GetEntryNodes(&org_entry_id_nodes);
    entry_id_node = new CIdNode();
    id_graph.AddNode(entry_id_node);
    new_entry_id_node_created = true;
  }

  // Create new exit node 
  id_graph.GetExitNodes(&org_exit_id_nodes);
  exit_id_node = new CIdNode();
  id_graph.AddNode(exit_id_node);
  new_exit_id_node_created = true;  

  // If needed, add edges from entry id node to orginal entry nodes 
  if(new_entry_id_node_created) {
    for(typename std::list<CIdNode *>::iterator oen = org_entry_id_nodes.begin();
	oen != org_entry_id_nodes.end(); ++oen) {
      // Add edge from entry id_node to original entry node
      id_graph.AddEdge(entry_id_node, (*oen));
    }
  }

  // If needed, add edges from exit id node to id nodes corresponding to org exit nodes 
  if(new_exit_id_node_created) {
    for(typename std::list<CIdNode *>::iterator oen = org_exit_id_nodes.begin();
	oen != org_exit_id_nodes.end(); ++oen) {
      // Add edge from exit id_node to identified id_node 
      id_graph.AddEdge((*oen), exit_id_node);
    }
  }

  // If needed, add edge from start node to exit node
  if(!entry_id_node->IsSucc(exit_id_node)) {
    id_graph.AddEdge(entry_id_node, exit_id_node);
  }    

  // Calculate the control dependency on the new id graph. This returns 
  // a mapping between id_nodes and their control dependant nodes
  std::map<CIdNode*, std::set<CIdNode*> *> id_cd;
  CDominance<CIdNode, Empty> dominance;
  dominance.CalculateControlDependency2(&id_graph, &id_cd);

  // Go through the derived control dependencies and update argument
  // map accordingly
  for(typename std::map<CIdNode*, std::set<CIdNode*> *>::iterator id_n2ns = id_cd.begin();
      id_n2ns != id_cd.end(); ++id_n2ns) {
	
    // Get the mapping between id nodes <and their control dependant id nodes
    CIdNode* id_node = (*id_n2ns).first;    
    unsigned id = (*id_n2ns).first->Id();

    // Skip exit node
    if(new_exit_id_node_created && id_node == exit_id_node)
      continue;

    // Create an empty set for the ids
    std::set<unsigned int> * cds = new std::set<unsigned int>;

    // Add teh connections to the resulting map
    std::set<CIdNode*> * id_nodes = (*id_n2ns).second;
    for(typename std::set<CIdNode *>::iterator n = id_nodes->begin();
        n != id_nodes->end(); ++n) {
      // Skip the exit node
      if(new_exit_id_node_created && (*n) == exit_id_node)
	continue;
      // Add the id to the resulting set
      cds->insert((*n)->Id());
    }
    
    // Add the created set to the resulting map
    (*cd)[id] = cds;      
  }

  // Delete temporary sets 
  for(typename std::map<CIdNode*, std::set<CIdNode*> *>::iterator id_n2ns = id_cd.begin();
      id_n2ns != id_cd.end(); ++id_n2ns) {
    delete (*id_n2ns).second;
  }
  
  // Mapping has been updated, return entry node id and if we created
  // a new entry node or not
  (*entry_node_id) = entry_id_node->Id();
  return new_entry_id_node_created;
} 

#endif
