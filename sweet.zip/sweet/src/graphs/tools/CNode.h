// $Id: CNode.h 7974 2018-11-23 13:53:26Z lkg02 $

#ifndef CNODE_H_
#define CNODE_H_

#include <list>
#include <stddef.h>

class UnusedAnnot
{
public:
   UnusedAnnot *Copy() { return NULL; }
};

// This is a node template, special designed to be useful as a node in
// instances of the corresponding CGraph-template (or in classed
// inherited from CGraph).
// It is not extremely general, but sort of optimised for sparse
// graphs.  The node assume an adjacent-list representation of the
// graph. Edges are outedges from the node (there is an additional set
// of edges in opposite direction, that allows for backward
// traversal).
// There is a list representation of edges, making it possible to
// maintain a multigraph. However all methods that assign a value to
// and edge takes an parameter that controls whether or not it should
// be used in a multigraph or not. If not multigraph, then adding a
// new edge when there is already an edge, will skipp adding the new
// one.
// The pred-pointers are assumed to be present (and correct) all the
// time - the responsibility to maintain them is on the graph.
template <typename T_Node, typename T_Edge_annot=UnusedAnnot>
class CNode
{
public:
   struct successor_type
   {
      successor_type(T_Node * node, T_Edge_annot * annot)
         : node(node), edge_annot(annot) {}
      T_Node *node; 
      T_Edge_annot *edge_annot;
   };
   typedef std::list<successor_type> successor_list;
   typedef std::list<T_Node*> predecessor_list;
   typedef typename successor_list::iterator succ_iterator;
   typedef typename successor_list::const_iterator const_succ_iterator;
   typedef typename predecessor_list::iterator pred_iterator;
   typedef typename predecessor_list::const_iterator const_pred_iterator;

   CNode() { _id = 0; }
   virtual ~CNode();
   CNode(const CNode &theother) { (void)theother; _succs.clear(); _preds.clear(); }

   // Iterator functions for out-edges
   // The returned value is a tuple of pointers <node, edge_annot>, named `node' and `edgedata' respectively. Thus the access in
   // a loop goes something like: it->node->SuccSize() or it->edge_annot->Blah()
   // Constant time.
   succ_iterator SuccBegin(void) { return _succs.begin();}
   const_succ_iterator SuccBegin(void) const { return _succs.begin();}
   succ_iterator SuccEnd(void) { return _succs.end();}
   const_succ_iterator SuccEnd(void) const { return _succs.end();}

   // Iterator functions for predecessors. These are not edges (however, for each in-edge there is a corresponding predecessor,
   // and each predecessor represents an in-edge, the actual in-edge data object, if any, can be obtained via the predecessor),
   // it might just be convenient to know the predecessor.
   // Constant time.
   pred_iterator PredBegin(void) { return _preds.begin();}
   const_pred_iterator PredBegin(void) const { return _preds.begin();}
   pred_iterator PredEnd(void) { return _preds.end();}
   const_pred_iterator PredEnd(void) const { return _preds.end();}

   // Sizes...
   // Constant time.
   inline unsigned PredSize(void) const {return (unsigned)_preds.size();}
   inline unsigned SuccSize(void) const {return (unsigned)_succs.size();}

   // Returns true if other is successor to this
   // Runs in O(N), where N is the number of out-edges from the node `from'
   bool IsSucc(const T_Node *other);

   /// Checks for the existence of a ceratin edge out from this node.
   /// \param other The destination node of the edge to check for
   /// \param edge_annot A pointer to a location updated with
   ///      the edge annotation in case present.
   /// \return True if the edge is present
   /// Runs in O(N), where N is the number of out-edges from the node `from'
   bool EdgeTo(T_Node *other, T_Edge_annot **edge_annot=NULL);

   // Add edge with and without edge_annot, respectively. The return value is true in case there is an edge to `succ_node',
   // else false. In case allow_multi_edges is true it runs in constant time else O(nr-of-successors).
   bool AddEdge(T_Node *succ_node, T_Edge_annot *edge_annot, bool allow_multi_edges);
   bool AddEdge(T_Node *succ_node, bool allow_multi_edges) { return AddEdge(succ_node, NULL, allow_multi_edges); }

   // Remove an edge. We will maintain the predecessors. The return value is the edge_annot object. The
   // return value will be 0 either if there is no edge data or if there is no edge to `succ_node'.
   // Runs in O(N+M) where N is number of outedges in this node, and M is number of in-edges in `succ_node'.
   T_Edge_annot *RemoveEdge(T_Node *succ_node);

   /// Redirects an out-edge of this node to a new destination.
   /// \param current_succ The current successor node whose ingoing edge from this node will be re-directed.
   /// \param new_succ The new target of the edge.
   /// \param allow_multi_edges Tells if the graph should be maintain with multiple edges or not.
   /// \return If an edge was removed due to \a allow_multi_edges being false the annotation of the
   /// former edge from this node to \a new_succ will be returned, else NULL is returned.
   /// \post If \a allow_multi_edges is false there are at most one edge to \a new_succ.
   /// \n
   /// If `current' is not a successor to this node then nothing will be done, and 0 will be returned.
   /// O(N+M) where N is number of outedges from this node, and M is number of in-edges into `current'.
   T_Edge_annot *RedirectOutEdge(T_Node *current_succ, T_Node *new_succ, bool allow_multi_edges);

   /// Similar to the \a RedirectInEdge, but redirects an in-edge to this node rather than an out-edge
   /// \n
   /// O(N+M) where N is number of inedges to this node, and M is number of out-edges from `current'.
   T_Edge_annot *RedirectInEdge(T_Node *current, T_Node *new_pred, bool allow_multi_edges);

   // Returns the number of edges to the potential successor `succ'.
   // Runs in O(nr-of-successors)
   unsigned EdgeCount(T_Node *succ);

   // To get the edge between current node and the predecessor.
   T_Edge_annot *EdgedataOfPred(T_Node *pred);

   // This id is a key to be used by the graph, we don't bother it's
   // use, just provide it.
   // Constant time.
   inline unsigned Id(void) const {return _id;}
   inline void SetId(unsigned id) {_id = id;}

   // Removes the outpointers to other nodes from this node (which implies the succ and pred pointers)
   // Does not consider the corresponding pointers into this node (i.e. it does not really clear edges
   // only pointers)
   // Runs in O(1)
   void ClearOutPointers(void) { _succs.clear(); _preds.clear(); }

private:
   successor_list _succs;
   predecessor_list _preds;
   unsigned _id;

   // Add and remove predecessor node, respectively.
   void LinkPred(T_Node *pred);
   void UnlinkPred(T_Node *pred);
};

#endif
