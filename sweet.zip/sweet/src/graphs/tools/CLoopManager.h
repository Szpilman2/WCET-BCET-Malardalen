// $Id: CLoopManager.h 4745 2012-12-20 14:05:39Z lkg02 $

#ifndef CLOOP_MANAGER_H_
#define CLOOP_MANAGER_H_

#include "graphs/components/CSuperNode.h"
#include "graphs/components/CComponent.h"
#include "graphs/components/CComponentTree.h"
#include "graphs/tools/CGraph.h"

template <typename T_Sub_Graph, typename T_Sub_Node, typename T_Sub_Edgedata=int>

/** \class CLoopManager. Manages two related analyzes concerning loops: Makes irreducible loops reducible and
   builds a loop tree from a reducible loop.
*/
class CLoopManager
{
public:
   /** This is the "node splitting algorithm", well known since a number of decades, please consult basic litterature for
      details.
      Basically it performs two things: 1) detects if a graph is reducible or not, and in case not 2) it will perform node
      copying in order to obtain a reducible graph.
      The actual graph is only affected when node splitting occur i.e. when we have detected that the graph is irreducible.
      \return True if we needed to make node splitting, else false.
      NOTE(1)! The nodes of `graph' need to have a method `Duplicate' that returns a pointer to a copy of itself.
      NOTE(2)! When splitting is made the edge annotations will be just copied, meaning that if these are pointers to
      dynamically allocated memory, after the splitting there will be more than one pointer to the same allocated memory.
      The caller has to be take care of this.
      \param graph The graph to analyze and eventually perform transformations on.
      \pre \a graph has a unique entry node.
      \post \a graph is reducible, and possibly has multiple exit nodes.
   */
   bool NodeSplitting(T_Sub_Graph *graph);

   /** This function will identify all loops in the code of a flow graph and arrange them in a tree hierarchy, where innermost
      loops are represented by leaf nodes and the outermost loops are repeseented by nodes at level 1 in the tree. The root
      node in the tree represents the flow graph itself.
      Each node in the tree contains a set of (pointers to) flow graph nodes that are the nodes that are part of the loop that
      it represents, excluding the nodes of inner loops. The root component's flow graph nodes are those that do not belong to
      any loop.
      \param graph The graph to analyze
      \param belong A pointer to a map that maps flow graph nodes to components.
      \pre \a graph has a unique entry node, a unique exit node and is reducible.
      \post \a belong is updated with a mapping from every flow graph node to the component it "belongs to".
      \return A pointer to a component tree. The memory of the tree is the caller responsible for. If any flow graph node
         is freed then then this tree should no longer be used.
   */
   CComponentTree <T_Sub_Node> *CreateSccTree(CGraph <T_Sub_Node, T_Sub_Edgedata> *graph, std::map<T_Sub_Node*, CComponent <T_Sub_Node>*> *belong);
private:
   // Functions used by node splitting:
   void Init(CGraph <CSuperNode <T_Sub_Node> >  &split_graph, T_Sub_Graph *graph, T_Sub_Node *node);
   void T1(CGraph <CSuperNode <T_Sub_Node> >  *split_graph);
   bool T2(CGraph <CSuperNode <T_Sub_Node> > *split_graph);
   void T3(CGraph <CSuperNode <T_Sub_Node> >  *split_graph, T_Sub_Graph *graph);
   void MakeNodeCopy(CGraph <CSuperNode <T_Sub_Node> > *split_graph, T_Sub_Graph *graph, CSuperNode <T_Sub_Node> *node_to_split,
                     CSuperNode <T_Sub_Node> *copy, CSuperNode <T_Sub_Node> *pred);

   // Functions used when creating a scc-tree:
   bool FindBackedgesByDFS(T_Sub_Node *node, std::vector<int> *state, std::list<T_Sub_Node*> *headers, std::vector<std::list<T_Sub_Node*> > *backedges);
   void RemoveDuplicateHeaders(std::list<T_Sub_Node*> *headers);
   void FindBackedges(CGraph <T_Sub_Node, T_Sub_Edgedata> *graph, std::list<T_Sub_Node*> *headers, std::vector<std::list<T_Sub_Node*> > *backedges);
   void insert(T_Sub_Node *m, std::vector<T_Sub_Node*> *loop, std::list<T_Sub_Node*> *stack_list);
   void FindLoop(T_Sub_Node *n, T_Sub_Node *d, std::vector<T_Sub_Node*> *loop);
   void FindLoops(CGraph <T_Sub_Node, T_Sub_Edgedata> *graph, std::list<T_Sub_Node*> *headers, std::vector<std::list<T_Sub_Node*> > *backedges,
                  std::vector<std::vector<T_Sub_Node*> > *loops);
   void InsertComponentInTree(CComponent <T_Sub_Node> *component, CComponent <T_Sub_Node> *current_root,
                              CComponentTree <T_Sub_Node> *component_tree);
   void ArrangeLoopHierarchy(CGraph <T_Sub_Node, T_Sub_Edgedata> *graph, std::list<T_Sub_Node*> *headers, std::vector<std::list<T_Sub_Node*> > *backedges,
                             std::vector<std::vector<T_Sub_Node*> > *loops, CComponentTree <T_Sub_Node> *component_tree);
   void RemoveNodesOfSubLoop(CComponent <T_Sub_Node> *component, CComponent <T_Sub_Node> *other);
   void RemoveNodesOfSubLoops(CComponent <T_Sub_Node> *component);
   void CreateNodeToLoopMapping(CComponent <T_Sub_Node> *root, std::map<T_Sub_Node*, CComponent <T_Sub_Node>*> *node_to_component);
};

#endif
