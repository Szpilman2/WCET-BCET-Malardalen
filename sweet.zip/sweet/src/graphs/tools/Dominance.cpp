#include "Dominance.h"
#include "graphs/tools/CGraph.inl"
#include "graphs/tools/CNode.inl"

template class CGraph<CIdNode, Empty>;
template class CNode<CIdNode, Empty>;
