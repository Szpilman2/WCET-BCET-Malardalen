// $Id: CTree.h 1056 2009-09-25 07:46:34Z lkg02 $

#ifndef CTREE_H_
#define CTREE_H_

#include "CGraph.h"

template <typename T_Tree_Node>
class CTree  : private CGraph <T_Tree_Node>
{
public:
   typedef typename CGraph <T_Tree_Node>::node_iterator tree_node_iterator;

   // Adds the kid `kid' as the kid of the parent `parent'. Does also insert a sub-tree properly
   inline void AddKid(T_Tree_Node *parent, T_Tree_Node *kid)
   {
      AddNodesOfTree(kid);
      CGraph <T_Tree_Node>::AddEdge(parent, kid);
   }

   void AddNodesOfTree(T_Tree_Node *node)
   {
      CGraph <T_Tree_Node>::AddNode(node);
      for (typename CTreeNode<T_Tree_Node>::kid_iterator kid=node->KidBegin(); kid!=node->KidEnd(); kid++) {
         AddNodesOfTree(kid->node);
         CGraph <T_Tree_Node>::AddEdge(node, kid->node);
      }
   }

   // Get all nodes in the tree except the root node
   inline void AllKidsInTree(std::list<T_Tree_Node *> * kids)
   {
     CGraph <T_Tree_Node>::FindRoot();
     T_Tree_Node * root = CGraph <T_Tree_Node>::Root();
     // typename CTreeNode<T_Tree_Node>::kid_iterator kid;
     tree_node_iterator tn; 
     for(tn = TreeNodesBegin(); tn != TreeNodesEnd(); tn++) 
       {
         if(root != (*tn))
           kids->push_back(*tn);
         // NodesOfSubtree(kid->node, kids);
       }
   }

   // Get all nodes in the tree including the root node
   inline void AllNodesInTree(std::list<T_Tree_Node *> * nodes)
   {
     // typename CTreeNode<T_Tree_Node>::kid_iterator kid;
     tree_node_iterator tn; 
     for(tn = TreeNodesBegin(); tn != TreeNodesEnd(); tn++) 
       {
         nodes->push_back(*tn);
         // NodesOfSubtree(kid->node, kids);
       }
   }

   // Removes the subtree rooted at `subtree' from this tree. The subtree will however still exist, but is diconnected from this tree.
   inline void RemoveSubtree(T_Tree_Node *subtree)
   {
      if (subtree->Parent()) {
         RemoveEdge(subtree->Parent(), subtree);
      }
      std::list<T_Tree_Node *> nodes;
      CTree <T_Tree_Node> new_tree;
      NodesOfSubtree(subtree, &nodes);
      CutSubgraph(&new_tree, &nodes);
      CGraph <T_Tree_Node>::FindRoot();
      CGraph <T_Tree_Node>::CompressGraph();
   }

   // Moves the subtree rooted at `subtree' from its current location to be the kid of `newparent'.
   inline void MoveSubtree(T_Tree_Node *subtree, T_Tree_Node *newparent)
   {
      if (subtree->Parent()) {
         CGraph <T_Tree_Node>::RemoveEdge(subtree->Parent(), subtree);
         CGraph <T_Tree_Node>::FindRoot();
      }
      CGraph <T_Tree_Node>::AddEdge(newparent, subtree);
   }

   // Iterates over all nodes in the tree
   inline tree_node_iterator TreeNodesBegin(void) { return CGraph <T_Tree_Node>::NodesBegin(); }
   inline tree_node_iterator TreeNodesEnd(void) { return CGraph <T_Tree_Node>::NodesEnd(); }

   // Adds the tree node `root' to this tree. It is assumed that this is an empty tree
   inline void AddRoot(T_Tree_Node *root)
   {
      CGraph <T_Tree_Node>::AddNode(root);
      CGraph <T_Tree_Node>::FindRoot();
   }

   // Replaces the node `current' with `newnode' in this tree. `current' will be the kid to `newnode'.
   inline void Replace(T_Tree_Node *current, T_Tree_Node *newnode)
   {
      T_Tree_Node *parent = current->Parent();
      if (parent) {
         AddKid(parent, newnode);
         parent->RedirectOutEdge(current, newnode, false);
      } else {
         assert(current == CGraph <T_Tree_Node>::Root());
         T_Tree_Node subtree;
         RemoveSubtree(&subtree);
         AddRoot();
      }
      AddKid(newnode, current);
   }

   // Returns the root of this tree
   inline T_Tree_Node *TreeRoot(void) { return CGraph <T_Tree_Node>::Root(); }

private:
   void NodesOfSubtree(T_Tree_Node *subtree, std::list<T_Tree_Node *> *nodes)
   {
      nodes->push_back(subtree);
      for (typename CTreeNode<T_Tree_Node>::kid_iterator kid=subtree->KidBegin(); kid!=subtree->KidEnd(); kid++) {
         NodesOfSubtree(kid->node, nodes);
      }
   }
};

#endif
