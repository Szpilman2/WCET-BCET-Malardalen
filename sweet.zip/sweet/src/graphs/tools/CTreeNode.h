// $Id: CTreeNode.h 1461 2009-12-02 13:02:08Z csg01 $

#ifndef CTREE_NODE_H_
#define CTREE_NODE_H_

#include "CNode.h"

template <typename T_Tree_Node>
class CTreeNode  : public CNode <T_Tree_Node>
{
public:
   typedef typename CNode<T_Tree_Node>::succ_iterator kid_iterator;

   inline T_Tree_Node *Parent()
   {
      parent_iterator par = CNode <T_Tree_Node>::PredBegin();
      if (par==CNode <T_Tree_Node>::PredEnd()) {
         return NULL;
      } else {
         return *par;
      }
   }

   bool IsAncestor(T_Tree_Node *other)
   {
      parent_iterator par = CNode <T_Tree_Node>::PredBegin();
      if (par==CNode <T_Tree_Node>::PredEnd()) {
         return false;
      } else if (*par == other) {
         return true;
      } else {
         return (*par)->IsAncestor(other);
      }
   }

   T_Tree_Node *Root()
   {
      if (CNode <T_Tree_Node>::NrOfPreds() == 0) {
         return this;
      } else {
         return (*CNode <T_Tree_Node>::PredBegin())->Root();
      }
   }

   int NumberOfDescendants()
   {
      int n = KidsSize();
/*      kid_iterator kit_it;
      for (kit_it = KidBegin(); kit_it != KidEnd(); ++kid_it)
         n += NumberOfDescendants();*/
      return n;
   }

   inline kid_iterator KidBegin() { return  CNode <T_Tree_Node>::SuccBegin(); }
   inline kid_iterator KidEnd() { return CNode <T_Tree_Node>::SuccEnd(); }
   inline int KidsSize() { return CNode <T_Tree_Node>::SuccSize(); }
private:
   typedef typename CNode<T_Tree_Node>::pred_iterator parent_iterator;
};

#endif
