// $Id: CGraph.h 7974 2018-11-23 13:53:26Z lkg02 $

#ifndef CGRAPH_H_
#define CGRAPH_H_

#include <list>
#include <vector>
#include <set>
#include <map>
#include <iostream>
#include <algorithm>
#include <cassert>
#include "CNode.h"


/* This is a directed and rooted graph class. It is also connected, however this property is not maitained at any point. E.g.
   in the meantime between inserting nodes and edges between them the graph is obviously not connected. Also when removing
   an edge the graph may be diconnected until nodes have been removed.
   The nodes of instances of the template has to provide the following functions:
   unsigned Id();
   void SetId(int);
   pred_iterator PredBegin();
   pred_iterator PredEnd();
   succ_iterator SuccBegin();
   succ_iterator SuccEnd();
   unsigned SuccSize();
   unsigned PredSize();
   This is fulfilled by the class CNode. SetId will be called when nodes are added, and when the graph is compressed. The integer
   is a key used by the graph to find the node, so it must not be altered by any other then the graph.

   The inserted nodes are not destroyed by the destructor of the template, so if you want the nodes to be owned by the
   instanciated graph class then that class has to deal with the destruction.

   The nodes of the graph can always be iterated by the use of the iterator functions or using indexing+NodeAt
   About removing nodes: Removing nodes will leave "holes" in the set of nodes. I.e. you may get NULL pointer
   rather than pointer to nodes when iterating after removal. The reason why the node set is not automatically compressed
   is you may probably want the Id() as well as iterators and NrOfNodes() to be consistent during the whole iteration (in
   case you make the removal in an iteration). The price you have to pay for this is to take the resposnisbility either for
   calling `CompressGraph()' when finished a "removal iteration" or to always check for NULL-pointers.
   Also making sub-graphs introduces "holes" in the node-set (see `InsertSubGraph()'). Subgraphs can not be compressed.
*/

template <typename T_Node, typename T_Edge_annot=UnusedAnnot>
class CGraph
{
public:
   typedef std::vector<T_Node*> node_vector;
   typedef typename node_vector::iterator node_iterator;
   typedef struct { T_Node *from; T_Node *to; T_Edge_annot *edge_annot;} T_edge;
   typedef std::list<T_edge> T_edge_list;
   typedef typename T_edge_list::iterator T_edge_list_iterator;

   CGraph();
   virtual ~CGraph();

   // Adds the node `node' to the graph. Constant time (+ time for memory allocation).
   // Id() can later be used to get the index from the node, which in turn can be used for fast random access.
   inline void AddNode(T_Node *node)
   {
      _nodes.push_back(node);
      node->SetId((unsigned)_nodes.size() - 1);
   }

   // Inserts all the node pointers and the edges in the graph `other' to this graph. An edge will be added from `source_node' to
   // the root of `other' in case `source_node' is not NULL. Note that the nodes as well as the edges will belong to both graphs
   // after the insertion, so ` other' will be a subgraph to this (where the predecessor to the root node of the other will be
   // located outside the graph if `source_node' is non-zero). If you don't want this, then use `TakeNodes' instead.
   // A consequence of the common nodes is that before deleting the other graph you have to call Clear(). Also you are no longer
   // allowed to `CompressGraph()' the other graph, since it must contain holes to make the `Id()' consistent. Furthermore you should
   // be prepared that the first node is no longer at index 0.
   // use Clear().
   // O(N) where N is number of nodes in `other' (+ memory allocation time)
   void InsertSubGraph(const CGraph <T_Node, T_Edge_annot> *other, T_Node *source_node=NULL);

   // Moves the content of the graph `other' to to this. Semantically equivalent to
   // InsertSubGraph(other); other.Clear();
   // O(N) where N is number of nodes in `other' (+ memory allocation time)
   void TakeNodes(CGraph <T_Node, T_Edge_annot> *other, T_Node *source_node=NULL);

   // Returns true if `second' is a descendant to `first' in this graph. A node is not descendant to itself.
   // NOTE! This algorithm requires that this graph is a DAG!
   // O(N) where N is number of nodes in this graph
   bool IsDescendant(T_Node *first, T_Node *second);

   // Removes all nodes and edges of this graph.
   // Runs in constant time.
   void Clear(void) { _nodes.clear(); _root = NULL; _exit = NULL; }

   // Cut out all the nodes in `nodes', as well as the edges "internal" to that set of nodes, and adds them
   // to the graph `new_graph'.
   // Annotations from the removed edges (i.e. edge possibly connecting the cut out subgraph to the
   // remaining nodes in this graph) will be added to list `removed_edges'.
   // Note that since nodes are removed from the graph there might be "holes" in the set of nodes, so you
   // may want to call `CompressGraph' after the cut.
   // Runs in O(N) where N is the number of nodes in `nodes' (+ memory allocation time)
   void CutSubgraph(CGraph <T_Node, T_Edge_annot> *new_graph, std::list<T_Node*> *nodes, std::list <T_Edge_annot*> *removed_edges=NULL);

   // Copies all the nodes in `nodes', as well as the edges "internal" to that set of nodes, and adds them to the graph `new_graph'.
   // The nodes are required to have a Copy() method. NOTE that copying the edges means copying of the pointers in case the
   // edges are annotated with pointers!
   // Runs in O(N) where N is the number of nodes in `nodes' (+ memory allocation time)
   void CopySubgraph(CGraph <T_Node, T_Edge_annot> *new_graph, std::list<T_Node*> *nodes);

   // Returns a pointer to a new copy of this graph. The nodes are required to have a Copy() method that returns a pointer
   // to a copy of the node.
   // The edge annotations are required to be pointers to some class that have a method Copy() that returns a copy of the edge
   // annotation.
   // Runs in O(N) where N is the number of nodes in `nodes' (+ memory allocation time)
   CGraph <T_Node, T_Edge_annot> *Copy();

   // The nodes in the set `nodes' as well as all out edges from these, will be duplicated and inserted into this graph.
   // The edges from any node in `pred' to any node in `nodes' will also be added.
   // The return value is a pointer to a set of pointers to the copied nodes (memory belongs to the caller).
   // The nodes are required to have a Copy() method.
   // Runs in O(N) (+ memory allocation time). Here N is the total number of out edges from `nodes'.
   std::set<T_Node*> *DuplicateGraphPartition(std::set<T_Node*> *nodes, std::set<T_Node*> *pred_nodes);

   /// Creates a graph that is isomorphic to a subgraph of this graph
   /// \param nodes Specifies the source subgraph
   /// \return A pointer to the new graph.
   /// The nodes are required to have a Copy() method.
   /// Runs in O(N*M) (+ memory allocation time). Here N is the number of nodes in `nodes' and M is
   /// the total number of out edges from all nodes in `nodes'.
   CGraph<T_Node, T_Edge_annot> *CreateGraphFromNodes(std::list<T_Node*> *nodes);

   // Removes the node `node' from the graph, preserving the in-edges of a node with a single successor. All in-edges to `node'
   // will be redirected to the successors of `node'. If there are no successors the in-edges will be removed.
   // If `node' is the root, then there will be no root after return.
   // O(MAX(N,M)) where M=nr_preds(node)^2 and N=SUM(nr_succs(pred[i])) for all predecessors, pred, of `node'
   void RemoveNodeAndRedirectInEdgesToSuccessor(T_Node *node, std::list <T_Edge_annot*> *removed_edges=NULL, bool compress=false);

   // Removes the node `node' from the graph, preserving the out-edges of a node with a single predecessor. All out-edges from `node'
   // will be redirected to the predecessors of `node'. If there are no predecessors the out-edges will be removed.
   // If `node' is the root, then there will be no root after return.
   // O(MAX(N,M)) where M=nr_succs(node)^2 and N=SUM(nr_preds(succ[i])) for all succsessors, succ, of `node'
   void RemoveNodeAndRedirectOutEdgesToPredecessor(T_Node *node, std::list <T_Edge_annot*> *removed_edges=NULL, bool compress=false);

   // Collapses or "merges" the nodes of the edge src->dest into one node, which is `src'.
   // After the call, all in-edges to `dest' will go all the successors  of dest, and
   // all edges out from dest will start in src.
   // There will be no edges out from or in to `dest', but `dest' will still be in the Graph.
   // If src and dest are the same node, the edge will be removed
   // The root will be adjusted if needed.
   // O(MAX(N,M,P,Q)) where
   //    M=nr_succs(to)^2 and
   //    N=nr_preds(to)^2 and
   //    P=SUM(nr_preds(succ[i])) for all succsessors, succ[i], of `to' and
   //    Q=SUM(nr_succs(pred[i])) for all predecessors, pred[i], of `to'
   // Assuming a flowgraph with at most two successors (NIC) the average will be max 2*2=4 iterations.
   void Collapse(T_Node *src, T_Node *dest, std::list <T_Edge_annot*> *removed_edges);

   // Removes the node `node' from the graph. All edges concerning 
   // `node' will be removed. If `node' is the root, then there will be no root after return.
   // O(N*N) where N is MAX(npreds, nsuccs, succs[i](preds), preds[i](succs))
   // Note: If you want to remove several nodes, please call RemoveNodes instead, or remove each
   // of them using the below and then call CompressGraph().
   void RemoveNode(T_Node *node, std::list <T_Edge_annot*> *removed_edges=NULL, bool compress=false);

   // Removes a set of nodes, using `RemoveNode' and compresses the graph after all nodes have been removed.
   // Runs in O(N*M) where N is number of nodes and M is the complexity of `RemoveNode'
   void RemoveNodes(std::set<T_Node*> *nodes, std::list <T_Edge_annot*> *removed_edges=NULL, bool compress=false);

   // Removes the edge from `from' to node `to', the edge_annot will be returned (or 0 if there exists no such edge).
   // Runs in O(N+M) where N is number of outedges in this node, and M is number of in-edges in `succ_node'.
   T_Edge_annot *RemoveEdge(T_Node *from, T_Node *to);

   // Compresses the graph to save unused memory (might be good after removal).
   // Runs in O(nr-of-nodes)
   void CompressGraph(void);

   /// Adds pointers to all nodes that are part of the connected component of this graph that contains \a node.
   /// Runs in O(N) where N is nr of nodes in the component
   void FindComponent(T_Node *node, std::list<T_Node*> *component);

   /// Identifies all components of this graph.
   /// \param components A list of node lists. The nodes of each connected component in this graph are
   ///   collected into a list and that list is added to \a components.
   /// The memory of the lists are owned by the caller.
   /// Runs in O(N) where N is nr of nodes in the graph.
   void FindComponents(std::list<std::list<T_Node*> *> *components);

   /// Adds pointers to all nodes that are reachable from \a node.
   /// Runs in O(N) where N is nr of nodes in the component.
   void FindFlowComponent(T_Node *node, std::list<T_Node*> *component);

   // Searches the graph for a single root (i.e. a node with no in-edges), and set it.
   // The return value is true if a single root were found else false and an arbitrary node is choosen (if there
   // exists multiple candidates among these).
   // Runs in O(nr-of-nodes)
   bool FindRoot(void);

   // Searches the graph for a single exit node (i.e. a node with no out-edges), and set it.
   // The return value is true if a single exit node were found else false and an arbitrary node is choosen (if there
   // exists multiple candidates among these).
   // Runs in O(nr-of-nodes)
   bool FindExit(void);

   // Returns the root of the graph as preset by FindRoot.
   // Constant time.
   inline T_Node *Root(void)
   {
      // Check if FindRoot has been called
     if (!_root && !_rootless)
       FindRoot();
     return _root;
   }

   // Returns a std::list of entry nodes of a non-flow graph
   // Runs in O(nr-of-nodes)
   void GetEntryNodes(std::list<T_Node*> *entry_nodes);

   // Returns a std::list of exit nodes of a non-flow graph
   // Runs in O(nr-of-nodes)
   void GetExitNodes(std::list<T_Node*> *exit_nodes);

   // Returns the exit node of the graph as preset by FindExit.
   // Constant time.
   inline T_Node *Exit(void) 
   { 
     // Check if FindExit has been called
     if (!_exit && !_exitless)
       FindExit();
     return _exit;
   }

   // This fucntion returns true if the graph is connected, else false.
   // Runs in O(nr-of-nodes)
   bool IsConnected(void);

   // This function inserts all edges of this graph into `edge_list'.
   // If edge_annot are pointer in the current template usage, then the data pointed to belongs to the graph
   // Runs in O(nr-of-edges) (+ time for memory allocation).
   void Edges(T_edge_list *edge_list);

   // Returns the number of nodes in this graph. Calls Edges function and has therefore same complexity.
   unsigned NrOfEdges();
 
   /// Collects all in edges to \a node
   /// \pre \a node is a node in this graph
   /// \param node The node to collect in edges for
   /// \param edge_list A pointer to a std::list. Each in edge of \a node will be added to this std::list.
   void GetInEdges(T_Node *node, T_edge_list *edge_list);

   /// Adds a directed edge to the graph, starting in `from' ending in `to'.
   /// Constant time (+ time for memory allocation).
   /// @return true if an edge was added, false otherwise
   bool AddEdge(T_Node *from, T_Node *to);
   bool AddEdge(unsigned from, unsigned to) { return AddEdge(_nodes.at(from), _nodes.at(to)); }

   /// Adds a directed edge to the graph, starting in `from' ending in `to' assigning edge data to the edge.
   /// Constant time (+ time for memory allocation).
   /// @return true if an edge was added, false otherwise
   bool AddEdge(T_Node *from, T_Node *to, T_Edge_annot *edge_annot);
   bool AddEdge(unsigned from, unsigned to, T_Edge_annot *edge_annot) { return AddEdge(_nodes.at(from), _nodes.at(to), edge_annot); }

   // Returns an iterator to the first node.
   // Constant time.
   inline node_iterator NodesBegin() { return _nodes.begin(); }

   // Returns the end iterator of the nodes.
   // Constant time.
   inline node_iterator NodesEnd() { return _nodes.end(); }

   // Returns an application data object if the index is within
   // range. If the index referes to removed nodes in the graph
   // (i.e. removed nodes without compressing) then it will return
   // NULL.  Constant time.
   inline T_Node *NodeAt(unsigned i) const { if(_nodes.size() <= i) { return NULL; } else { return _nodes.at(i); } }

   // Returns the number of nodes in this graph.
   // Constant time.
   inline unsigned NrOfNodes(void) const {return (unsigned)_nodes.size();}

   /// Checks for the existence of a certain edge in this graph.
   /// \param from The source node of the edge to check for
   /// \param to The destination node of the edge to check for
   /// \param edge_annot A pointer to a location updated with
   ///      the edge annotation in case present.
   /// \return True if the edge is present
   /// Runs in O(N), where N is the number of out-edges from the node `from'
   inline bool Edge(T_Node *from, T_Node *to, T_Edge_annot **edge_annot=NULL) const { return from->EdgeTo(to, edge_annot); }

   // Like the above, but returns an edge data structure containing a
   // pointer to the edge annotation or NULL if there is no edge or if
   // there is no annotation
   inline bool Edge(T_Node *from, T_Node *to, T_edge *edge) const {
      edge->from = from;
      edge->to = to;
      return from->EdgeTo(to, &edge->edge_annot);
   }

   // Returns true if the node `node' exists within this graph.
   // Constant time.
   inline bool HasNode(T_Node *node) const
   {
      if (node->Id() > _nodes.size())
         return false;
      return _nodes.at(node->Id()) == node;
   }

   // Prints a textual representation of the graph using the internal node enumeration.
   void PrintWithNodeNumbers(std::ostream &o = std::cout);

   // The nodes of each SCC:s will be collected into a std::list, one for each SCC. These std::lists will be inserted into the
   // std::list pointed to by `sccs' .
   // The nodes that do not belong to any SCC will be stored into the std::list pointed to by `other_nodes'.
   // O(N), where N=nr-of-nodes.
   void Sccs(std::list<std::list<T_Node*> > *sccs, std::vector<bool> *other_nodes);

  // To get all nodes in the graph that are backwards (through
  // predecessor edges) or forward (through successor edges) reachable
  // from a given set of start nodes. The start node(s) will be
  // included in the returned set. 
  void ForwardReachableNodes(T_Node * start_node, std::set<T_Node *> * reachable_nodes); 
  void ForwardReachableNodes(std::set<T_Node *> * start_nodes, std::set<T_Node *> * reachable_nodes);
  void ForwardReachableNodesAndEdges(T_Node * start_node, std::set<T_Node *> * reachable_nodes, 
				     std::set<T_Edge_annot*> * edges=NULL);
  void ForwardReachableNodesAndEdges(std::set<T_Node *> * start_nodes, std::set<T_Node *> * reachable_nodes, 
				     std::set<T_Edge_annot*> * edges=NULL);
  void BackwardReachableNodes(T_Node * start_node, std::set<T_Node *> * reachable_nodes);  
  void BackwardReachableNodes(std::set<T_Node *> * start_nodes, std::set<T_Node *> * reachable_nodes);
  void BackwardReachableNodesAndEdges(T_Node * start_node, std::set<T_Node *> * reachable_nodes,
				     std::set<T_Edge_annot*> * edges=NULL);
  void BackwardReachableNodesAndEdges(std::set<T_Node *> * start_nodes, std::set<T_Node *> * reachable_nodes,
				      std::set<T_Edge_annot*> * edges=NULL);

protected:
   // Flag indicating if multi-edges are supported or not, default not.
   bool _multi_graph;

   // Removes a node from the set of nodes but does not touch edges related to that node
   // NOTE! Overloading this function requires calling it back
   virtual void ResetNode__(int id);

private:

   CGraph(const CGraph &);
   CGraph & operator = (const CGraph &);

   // Needed to make subgraphs cosnistent
//     node_iterator _NodesBegin(void);

typedef enum {VISITING=1, FINISHED=2} t_state;

   // The nodes
   std::vector<T_Node*> _nodes;

   // The root of the graph.
   T_Node *_root;
   bool _rootless; // set by FindRoot.

   // The exit node of the graph.
   T_Node *_exit;
   bool _exitless; // set by FindExit.

   // Indicates if this graph is a subgraph of another.
   bool _is_subgraph;

   // Just perform a depth-first search. `done' must have room for NrOfNodes booleans, and they must be inited to false. If all nodes
   // of this graph are reached starting with `node', then all elements of `done' will be true, else at least one is false.
   // Runs in O(nr-of-nodes)
   void dfs(T_Node *node, std::vector<bool> *done, std::vector<T_Node *> *visited);

   // Finds all nodes that is connected in the same component as `node' and that is not present in `done'. The nodes
   // pushed into the cmoponent std::list will be indicated as done.
   void FindComponent(T_Node *node, std::list<T_Node*> *component, std::vector<bool> *done);

   // Finds all nodes that is descendants to `node' and that is not present in `done'. The nodes
   // pushed into the cmoponent std::list will be indicated as done.
   void FindFlowComponent(T_Node *node, std::list<T_Node*> *component, std::vector<bool> *done);

   // Standard dfs algorthm
   void dfs(std::vector<int> *discovered, std::vector<std::pair<int, int> > *finished, std::vector<int> *pi);
   void dfs_visit(int u, int *time, std::vector<bool> *done, std::vector<int> *discovered, std::vector<std::pair <int, int> > *finished, std::vector<int> *pi);

   // Helper functions to the SCCs algorithm
   bool dfs_visit_rev(int u, std::vector<int> *done, std::list<T_Node*> *scc);
   void dfs_rev(std::vector<std::pair <int,int> > *finished, std::list<std::list<T_Node*> >*sccs, std::vector<bool> *other_nodes);

   // Helper functions for idom calculation
  // void idom_dfs(T_Node *v, std::map<int, T_Node *, std::less< int > >  *vertex);
  // void idom_dfs2(T_Node *v, std::map<int, T_Node *, std::less< int > >  *vertex, bool reset);
  // T_Node * idom_eval(T_Node *v);
  // void idom_compress(T_Node *v);
  // void idom_link(T_Node * from, T_Node * to);

};

#endif
