// $Id: CFlowGraphNode.cpp 2545 2010-10-18 12:46:10Z ael01 $

#include "CFlowGraphNode.h"
#include "CFlowGraph.h"
#include "program/CGenericFunction.h"
#include "../tools/CNode.inl"
#include "../../program/alf/AStmt.h"
#include <cassert>

using namespace std;

template class CNode<CFlowGraphNode, CFlowGraphEdgeAnnot>;

void
CFlowGraphNode::
PrintAsDot(ostream &o)
{
   CGenericStmt* stmt = Stmt();

   o << Id() <<
      " [label=<<TABLE BORDER=\"0\" CELLBORDER=\"0\" CELLSPACING=\"0\">" <<
      "<TR><TD VALIGN=\"BOTTOM\" CELLPADDING=\"0\">" <<
      "<FONT POINT-SIZE=\"32\" FACE=\"verdana\">" <<
      Id() <<
      "</FONT></TD></TR>" <<
      "<TR><TD ALIGN=\"LEFT\" BALIGN=\"LEFT\" CELLPADDING=\"0\">" <<
      "<FONT POINT-SIZE=\"2\" FACE=\"verdana\">";
   stmt->PrintAsDot(o);
   o << "</FONT></TD></TR></TABLE>>];" << endl;
}

CFlowGraphNode::~CFlowGraphNode()
{

}

CFlowGraphNode *
CFlowGraphNode::
Copy()
{
   CFlowGraphNode *new_node = new CFlowGraphNode(_stmt, _flow_graph);
   new_node->_is_header = _is_header;
   // new_node->_annot_number_to_succs = _annot_number_to_succs;

   return new_node;
}

std::string CFlowGraphNode::Name() const { 
   return _stmt->Name(); 
}

std::string CFlowGraphNode::PrettifiedName() const { 
   std::string s = _stmt->PrettifiedName();
   return s;
}   

unsigned CFlowGraphNode::Key() const { 
   return _stmt->Key();
}

void CFlowGraphNode::GetSuccessorsGoingToNode(const CFlowGraphNode * node, vector<successor_type> & successors)
{
   for (succ_iterator s = SuccBegin(); s != SuccEnd(); ++s)
      if (s->node == node)
         successors.push_back(*s);
}

// void CFlowGraphNode::AddAnnotNumberToSuccessor(unsigned int number, const CFlowGraphNode * node, const CFlowGraphEdgeAnnot * edge_annot)
// {
//    // TODO: Here we have a potential problem: there can be more than one edge that is identified by (node, edge_annot).
//    // For the nonce we solve this by letting the number be added to all of them.

//    int nr_added = 0;
//    for (succ_iterator s = SuccBegin(); s != SuccEnd(); ++s)
//    {
//       if (s->node == node && s->edge_annot == edge_annot)
//       {
//          if (_annot_number_to_succs.size() <= number)
//          {
//             _annot_number_to_succs.resize(number + 1);
//          }
//          _annot_number_to_succs[number].push_back(*s);
//          ++nr_added;
//       }
//    }
//    assert(nr_added > 0 || "Trying to add number to non-existing successor" == NULL);
// }

void CFlowGraphNode::AddAnnotNumberToSuccessor(unsigned int number, const CFlowGraphNode * node, CFlowGraphEdgeAnnot * edge_annot)
{	
  edge_annot->AddAnnotNumber(number);
}

// void CFlowGraphNode::GetAnnotNumbersOfOutgoingEdge(const CFlowGraphNode * target_node, const CFlowGraphEdgeAnnot * edge_annot,
//                                                    vector<unsigned int> & edge_annot_numbers) const
// {
//    // Iterate over all labels
//    for (unsigned int l = 0; l < _annot_number_to_succs.size(); ++l)
//    {
//       // Iterate over all successor that are annotated with that annotation number
//       for (vector<successor_type>::const_iterator s = _annot_number_to_succs[l].begin(); s < _annot_number_to_succs[l].end(); ++s)
//       {
//          // If the successor matches the one specified by (target_node, edge_annot), add the annotation number to edge_annot_numbers
//          if (s->node == target_node && s->edge_annot == edge_annot)
//          {
//             edge_annot_numbers.push_back(l);
//          }
//       }
//    }
// }

void 
CFlowGraphNode::
GetSuccessorsWithAnnotNumber(unsigned int number, std::vector<successor_type> * succ_types) const 
{
  for (const_succ_iterator s = SuccBegin(); s != SuccEnd(); ++s)
   {
     if (s->edge_annot->HasAnnotNumber(number)) {
       successor_type st(s->node, s->edge_annot);
       succ_types->push_back(st);
     }
   }
}

void CFlowGraphNode::GetAnnotNumbersOfOutgoingEdge(const CFlowGraphNode * target_node, const CFlowGraphEdgeAnnot * edge_annot,
                                                   vector<unsigned int> & edge_annot_numbers) const
{
  // The edge annot hold all annot numbers
  edge_annot->GetAnnotNumbers(&edge_annot_numbers);
}

void
CFlowGraphNode::PrintDetailed(std::ostream &o)
{
  assert(FlowGraph());
  assert(FlowGraph()->Function());
  o << "<" << FlowGraph()->Function()->Name() << "," << PrettifiedName() << "," << Id() << ">";
}


// void 
// CFlowGraphNode::PrintAnnotNumberToSuccs(std::ostream &o)
// {
//    // Iterate over all labels
//    for (unsigned int l = 0; l < _annot_number_to_succs.size(); ++l)
//    {
//      o << "[" << l << "]: ";
//      // Iterate over all successor that are annotated with that annotation number
//      for (vector<successor_type>::const_iterator s = _annot_number_to_succs[l].begin(); s < _annot_number_to_succs[l].end(); ++s)
//        {
// 	 CFlowGraphNode * target_node = s->node;
// 	 CFlowGraphEdgeAnnot * edge_annot = s->edge_annot;
// 	 assert(target_node);
// 	 assert(edge_annot);
// 	 target_node->PrintDetailedName(o);
// 	 o << " ";
// 	 edge_annot->PrintDetailed(o);
// 	 o << " ";
//       }
//    }
// }

void 
CFlowGraphNode::PrintEdgesDetailed(std::ostream &o)
{
  for (succ_iterator s = SuccBegin(); s != SuccEnd(); ++s)
    {
      CFlowGraphNode * target_node = s->node;
      CFlowGraphEdgeAnnot * edge_annot = s->edge_annot;
      PrintDetailed(o);
      o << " -> ";
      target_node->PrintDetailed(o);
      o << " ";
      edge_annot->PrintDetailed(o);
      o << "\n";
    }
}

bool 
CFlowGraphNode ::
IsBeginOfBasicBlock(void) 
{
   // If not one predecessor it must be a start of a basic block
   if(PredSize() != 1)
      return true;

   // If predecessor has more than one sucessor it must be a start of a
   // basic block
   CFlowGraphNode::pred_iterator pred_it = PredBegin();
   CFlowGraphNode *pred = *pred_it;
   if(pred->SuccSize() > 1)
      return true;
   else if(pred->SuccSize() == 1) {
      // Special case: this is the first node of a function that is also
      // a loop header 
      CFlowGraphEdgeAnnot *edge_annot;
      pred->EdgeTo(this, &edge_annot);
      if (edge_annot->IsBackedge())
         return true;
   }

   // If predecessor is a call node, we should start a new basic block
   if(pred->Stmt()->Type() == CGenericStmt::GS_CALL)
      return true;

   // Else, it must be a non-start node
   return false;
}


bool 
CFlowGraphNode ::
IsEndOfBasicBlock(void) 
{
   // If more than one successor it must be an end of a basic block
   if(SuccSize() != 1)
      return true;

   // If successor is begin of basic block, then we must be an end of
   // the basic block
   CFlowGraphNode::succ_iterator succ_it = SuccBegin();
   CFlowGraphNode * succ = (*succ_it).node;
   if(succ->IsBeginOfBasicBlock())
     return true;

   // // If successor has more than one predecessor it must be an end of a
   //    // basic block
   //    CFlowGraphNode::succ_iterator succ_it = SuccBegin();
   //    if(succ_it->node->PredSize() > 1)
   //       return true;
   //    else if(succ_it->node->PredSize() == 1) {
   //       // Special case: the successor is the first node of a function that is also
   //       // a loop header 
   //       if (succ_it->edge_annot->IsBackedge())
   //          return true;
   //    }

   // If we are a call node, we should end a basic block
   if(Stmt()->Type() == CGenericStmt::GS_CALL)
      return true;

   // If we are a return node, we should end a basic block
   if(Stmt()->Type() == CGenericStmt::GS_RETURN)
      return true;

   // Else, it must be a non end node
   return false;
}

CFlowGraphNode *
CFlowGraphNode ::
GetBeginNodeOfNodesBasicBlock(void) 
{
  CFlowGraphNode * walker = this;
  while(!walker->IsBeginOfBasicBlock())
    {
      assert(walker->PredSize() == 1);
      walker = *(walker->PredBegin());
    }
  return walker;
}

CFlowGraphNode *
CFlowGraphNode ::
GetEndNodeOfNodesBasicBlock(void) 
{
  CFlowGraphNode * walker = this;
  while(!walker->IsEndOfBasicBlock())
    {
      assert(walker->SuccSize() == 1);
      walker = (*(walker->SuccBegin())).node;
    }
  return walker;
}

// Alternative printing function
std::ostream &operator << (std::ostream &o, CFlowGraphNode &e)
{
  o << e.Name();
  return o;
}
