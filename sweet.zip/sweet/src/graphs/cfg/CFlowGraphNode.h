// $Id: CFlowGraphNode.h 2545 2010-10-18 12:46:10Z ael01 $

#ifndef CFLOW_GRAPH_NODE_H_
#define CFLOW_GRAPH_NODE_H_

#include "graphs/tools/CNode.h"
#include "program/CGenericStmt.h"
#include "CFlowGraphEdgeAnnot.h"
#include <string>
#include <vector>

class CScopeName;
class CAnnots;
class CStmt;
class CFlowGraph;
class CEdge;

/** \class CFlowGraphNode
   Defines a flow graph node. The flow graph node represents a single statement.
*/
class CFlowGraphNode : public CNode<CFlowGraphNode, CFlowGraphEdgeAnnot>
{
public:
   /** Constructs a new flowgraph node representing a statement.
      \param stmt A pointer to a statement that this node represents. The memory of the statement object
         is NOT owned by this node. The pointer will be stored in this flow graph node so after releasing
         the memory of the statement object this flow graph node should not be used any more.
      \param flow_graph A pointer to the flow graph of this node.
   */
   CFlowGraphNode(CGenericStmt *stmt, CFlowGraph *flow_graph): _stmt(stmt), _flow_graph(flow_graph), _is_header(false) { }

   /** Frees all memory owned by this node.
   */
   virtual ~CFlowGraphNode();

   /** \return A pointer to a new flow graph node that is a duplicate of this. A deep copy will be
      performed with all objects owned by this node.
   */
   CFlowGraphNode *Copy();

   /** \return A pointer to the flowgraph of this node.
   */
   inline CFlowGraph *FlowGraph() const {return _flow_graph;}

   /** \return The name of the node, i.e. the label of the statement. This shold be unique in
      the entire program.
   */
   std::string Name() const; 

   /** \return The prettified name of the node, i.e. a label suitable for printout i eg. dot-files.
    */
   std::string PrettifiedName() const;
   
   /** \return The unique key of the label of the statement.
    */
   unsigned Key() const;
   
   /** \return A pointer to the statement that this node represents in the flow graph.
      We are not the owner of the returned objects memory, and if it is destroyed then
      this node is no longer valid.
   */
   inline CGenericStmt *Stmt() const { return _stmt; }

   /** Fill in @a successors with all the successors to this node that targeted at node @a node */
   void GetSuccessorsGoingToNode(const CFlowGraphNode * node, std::vector<successor_type> & successors);

   /** Add annotation number @a number to the successor that identified by (@a node, @a edge_annot) */
   // void AddAnnotNumberToSuccessor(unsigned int number, const CFlowGraphNode * node, const CFlowGraphEdgeAnnot * edge_annot);
   void AddAnnotNumberToSuccessor(unsigned int number, const CFlowGraphNode * node, CFlowGraphEdgeAnnot * edge_annot);

   /** Get access to a list of successors that are annotated with @a number */
   // const std::vector<successor_type> * GetSuccessorsWithAnnotNumber(unsigned int number) const {return &_annot_number_to_succs[number];}
   void GetSuccessorsWithAnnotNumber(unsigned int number, std::vector<successor_type> * succ_types) const;

   /** Fill in @a edge_annot_numbers with the annotation numbers associated with the successor (@a target_node, @a edge) */
   void GetAnnotNumbersOfOutgoingEdge(const CFlowGraphNode * target_node, const CFlowGraphEdgeAnnot * edge_annot, std::vector<unsigned int> & edge_annot_numbers) const;

   /** \return true if this node is the first node of a basic block.
   */
   bool IsBeginOfBasicBlock(void);

   /** \return true if this node is the last node of a basic block.
   */
   bool IsEndOfBasicBlock(void);

   /** \return the node that is the start node of the basic block that the
       node belong to. It could be the node itself or some other node.
   */
   CFlowGraphNode * GetBeginNodeOfNodesBasicBlock(void);

   /** \return the node that is the end node of the basic block that the
       node belong to. It could be the node itself or some other node.
   */
   CFlowGraphNode * GetEndNodeOfNodesBasicBlock(void);

   /** \return true if this node is the target of a back edge, a so called header.
   */
   bool IsHeader(void) const { return _is_header; }

   /** Tells this node that it is the target of a back edge, a so called header.
   */
   void SetHeader()      { _is_header = true; }

   /** Prints this node as a node in a dot file.
   */
   void PrintAsDot(std::ostream &o = std::cout);

   /** Detailed prints. The second function will print edges annots.
    */
   void PrintDetailed(std::ostream &o = std::cout);
   void PrintEdgesDetailed(std::ostream &o = std::cout);

private:
   /** A pointer to the statement that this node represents.
   */
   CGenericStmt *_stmt;

   /** A pointer to the flowgraph where this node exists.
   */
   CFlowGraph *_flow_graph;

   bool _is_header;

   /// A mapping from an annotation number to a collection of successor
   /// nodes (that are present in CNode::succs) that are annotated with
   /// that number
   /// - A successor can be mapped from more than one annotation number.
   /// - Each annotation can be mapped to more than one successor
   /// std::vector<std::vector<successor_type> > _annot_number_to_succs;
   // EBBE: Removed 20101018 since can not handle copyies will since
   // it contain pointers to nodes. Functionality Moved to CFlowGraphEdgeAnnot.

   // Prevent from using
   CFlowGraphNode(const CFlowGraphNode &theother);
};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CFlowGraphNode &e);

#endif
