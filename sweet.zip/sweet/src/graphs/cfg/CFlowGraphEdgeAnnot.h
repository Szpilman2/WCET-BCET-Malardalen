// $Id: CFlowGraphEdgeAnnot.h 5125 2013-04-07 22:13:58Z lkg02 $

#ifndef CFLOW_GRAPH_EDGE_H
#define CFLOW_GRAPH_EDGE_H

#include <iostream>
#include <vector>
#include <set>

/** \class CFlowGraphEdgeAnnot
   Defines a flow graph edge. The flow graph edge represents one possible execution flow from one statement to another.
*/
class CFlowGraphEdgeAnnot
{
public:
   /** Constructs one annotation of a flow graph edge
   */
   CFlowGraphEdgeAnnot(int label=0) : _label(label), _is_backedge(false), _is_false_edge(false) { }

   /** Frees all memory owned by this node.
   */
   ~CFlowGraphEdgeAnnot() { }

   /** \return A pointer to a new flow graph edge that is a duplicate of this. A deep copy will be
      performed with all objects owned by this node.
   */
   CFlowGraphEdgeAnnot *Copy();

   /** Marks this edge with the backedge property, i.e. indicates that the destination of this
      edge is the header node of a loop.
   */
   inline void SetBackedge() { _is_backedge = true; }

   /** \return The backedge property of this edge, i.e. true if the destination of this
      edge is the header node of a loop, else false.
   */
   inline bool IsBackedge()  { return _is_backedge; }

   /** Marks this edge with the false edge property, i.e. indicates that it does not represent a possible
      execution flow, i.e. it is the local edge out from a node representing a call statement.
   */
   inline void MarkAsFalseEdge() { _is_false_edge = true; }

   /** \return The "false edge property" of this edge, i.e. true if it does not represent a possible
      execution flow, i.e. it is the local edge out from a node representing a call statement.
   */
   inline bool IsFalseEdge() { return _is_false_edge; }

   /** \return A label of this edge.
   */
   inline int Label(void)        { return _label; }

   /** Print detailed info
    */
   void PrintDetailed(std::ostream &o = std::cout);

   /** Add an annot number to the edge 
    */
   void AddAnnotNumber(unsigned int annot_number);
   
   /** To check if the edge has the annot number */
   bool HasAnnotNumber(unsigned int annot_number);

   /** To get all annot numberd of the edge annot */
   void GetAnnotNumbers(std::vector<unsigned int> * annot_numbers) const;

private:
   CFlowGraphEdgeAnnot(int label, bool is_backedge, bool is_false_edge) : _label(label), _is_backedge(is_backedge), _is_false_edge(is_false_edge) { }
   int _label;
   bool _is_backedge;
   bool _is_false_edge;
   std::set<unsigned int> _annot_numbers;
};

#endif
