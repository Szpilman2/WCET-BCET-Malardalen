// $Id: CFlowGraphEdgeAnnot.cpp 5125 2013-04-07 22:13:58Z lkg02 $

#include "CFlowGraphEdgeAnnot.h"

CFlowGraphEdgeAnnot *
CFlowGraphEdgeAnnot::
Copy()
{
   CFlowGraphEdgeAnnot *new_annot = new CFlowGraphEdgeAnnot(_label, _is_backedge, _is_false_edge);
   for(std::set<unsigned int>::iterator an = _annot_numbers.begin();
      an != _annot_numbers.end(); ++an) {
     new_annot->AddAnnotNumber(*an);
   }
   return new_annot;
}

void
CFlowGraphEdgeAnnot::
PrintDetailed(std::ostream &o)
{
  o << "label: " << _label << " back_edge: " << _is_backedge << " false_edge: " << _is_false_edge;
  o << " annot_numbers: ";
  for(std::set<unsigned int>::iterator an = _annot_numbers.begin();
      an != _annot_numbers.end(); ++an) {
    o << (*an) << " ";
  }
}  

void 
CFlowGraphEdgeAnnot::
AddAnnotNumber(unsigned int annot_number) 
{ 
  _annot_numbers.insert(annot_number); 
}
  
bool
CFlowGraphEdgeAnnot::
HasAnnotNumber(unsigned int annot_number) 
{ 
  return _annot_numbers.find(annot_number) != _annot_numbers.end(); 
}

void
CFlowGraphEdgeAnnot::
GetAnnotNumbers(std::vector<unsigned int> * annot_numbers) const
{
  for(std::set<unsigned int>::const_iterator an = _annot_numbers.begin();
      an != _annot_numbers.end(); ++an) {
    annot_numbers->push_back(*an);
  }
}
