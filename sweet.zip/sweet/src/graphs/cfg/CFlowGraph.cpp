// $Id: CFlowGraph.cpp 7974 2018-11-23 13:53:26Z lkg02 $

#include "CFlowGraph.h"
#include "../tools/CGraph.inl"
#include "../tools/CNode.inl"
#include "program/CGenericFunction.h"
#include "graphs/tools/CLoopManager.inl"
#include "graphs/components/CComponent.h"
#include "graphs/components/CComponentTree.h"
#include "tools/CSourceLoader.h"
#include <sstream>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <list>

using namespace std;

template class CGraph <CFlowGraphNode, CFlowGraphEdgeAnnot>;

CFlowGraph::~CFlowGraph()
{
   if (_component_tree) {
      delete _component_tree;
   }
   for (unsigned i=0; i<NrOfNodes(); i++) {
      if (NodeAt(i)) {
         delete NodeAt(i);
      }
   }
}

CFlowGraph *
CFlowGraph::
Duplicate()
{
   CFlowGraph *cfg = new CFlowGraph(_function);

   map<CFlowGraphNode*,CFlowGraphNode*> node_map;
   for (unsigned i=0; i<NrOfNodes(); i++) {
      CFlowGraphNode *orig_node = NodeAt(i);
      CFlowGraphNode *node = orig_node->Copy();
      node_map[orig_node] = node;
   }

   T_edge_list edges;
   Edges(&edges);
   for (T_edge_list_iterator edge_it=edges.begin(); edge_it!=edges.end(); edge_it++) {
      CFlowGraphNode *from = node_map[edge_it->from];
      CFlowGraphNode *to = node_map[edge_it->to];
      AddEdge(from, to, edge_it->edge_annot);
   }

   return cfg;
}

void
CFlowGraph::
ResetNode__(int id)
{
   CGraph <CFlowGraphNode, CFlowGraphEdgeAnnot>::ResetNode__(id);
   if (NodeAt(id) == _entry_node) {
      _entry_node = NULL;
   }
}

// This is the grammar specifying the format of the loop part of the control flow graphs to be printed
//
// LOOPS =>
//   |
//   | { loops LOOP+ }
// LOOP => { LOOP_ID LNODES LEDGES LENTRIES LITERS LEXISTS LOOPS }
// LOOP_ID => string
// LNODES => { nodes BB_ID+ }
// LEDGES =>
//   |
//   | { edges LEDGE+ }
// LEDGE =>
//   | BB_ID->BB_ID
//   | BB_ID--BB_ID
// LENTRIES => { entries LEDGE+ }
// LITERS => { iters LEDGE+ }
// LEXITS =>
//   |
//   | { exits LEDGE+ }
void CFlowGraph::PrintLoopsAsPFF(ostream &o, CComponent<CFlowGraphNode> *root, T_edge_list *edge_list, string indent)
{
   if (root->KidsSize() > 0) {
      // LOOPS
      o << indent << "{loops " << endl;

      set <CFlowGraphNode *> *subnodes = root->SubNodes();

      // LOOP+
      for (CComponent<CFlowGraphNode>::kid_iterator scc_it=root->KidBegin(); scc_it!=root->KidEnd(); scc_it++) {
         CComponent<CFlowGraphNode> *loop = scc_it->node;

         // LOOP_ID
         string indent_level1 = indent + "   ";
         o << indent_level1 << "{" << loop->Head()->Name() << endl;

         // LNODES
         string indent_level2 = indent_level1 + "   ";
         o << indent_level2 << "   {nodes ";
         for (CComponent<CFlowGraphNode>::subnode_iterator bb_it=loop->SubNodeBegin(); bb_it!=loop->SubNodeEnd(); bb_it++) {
            o << (*bb_it)->Name() << " ";
         }
         o << "}" << endl;

         // LEDGES
         for(T_edge_list_iterator edge = edge_list->begin(); edge != edge_list->end(); edge++) {
            if (subnodes->count(edge->from) > 0) {
               // Only include edges with the source node in this loop-scope
               CGenericStmt *stmt = edge->from->Stmt();
               if (stmt->Type() == CGenericStmt::GS_CALL) {
                  // call->result is not an execution path
                  o << edge->from->Name() << "--" << edge->to->Name() << " ";
               } else {
                  // ...but other edges are
                  o << edge->from->Name() << "->" << edge->to->Name() << " ";
               }
            }
         }

         // LENTRIES
         o << indent_level2 << "{entries " << loop->Head()->Name() << "}" << endl;

         // LITERS
         o << indent_level2 << "{iters ";
         for (CComponent<CFlowGraphNode>::backedge_iterator be_it=loop->BackedgeBegin(); be_it!=loop->BackedgeEnd(); be_it++) {
            o << be_it->first->Name() << "->" << be_it->second->Name() << " ";
         }
         o << indent_level2 << "}" << endl;

         // LEXITS
         const list <CFlowGraphNode *> *exit_node_list = loop->ExitNodes(&_node_to_component);
         set <CFlowGraphNode *> exit_node_set;
         for (list <CFlowGraphNode *>::const_iterator node_it=exit_node_list->begin(); node_it!=exit_node_list->end(); node_it++) {
            exit_node_set.insert(*node_it);
         }
         o << indent_level2 << "{exits ";
         for(T_edge_list_iterator edge = edge_list->begin(); edge != edge_list->end(); edge++) {
            if (exit_node_set.count(edge->from) > 0) {
               // Only include edges with the source node in this loop-scope
               o << edge->from->Name() << "->" << edge->to->Name() << " ";
            }
         }
         o << indent_level2 << "}" << endl;

         // LOOPS
         PrintLoopsAsPFF(o, loop, edge_list, indent_level2);

         o << indent_level1 << "}" << endl; // Close loop
      }
      o << indent << "}" << endl; // Close loops
   }
}

unsigned int
CFlowGraph::
GetNrOfLoops() {
  
  // Get the components of the CFG
  CComponentTree <CFlowGraphNode> *ct = ComponentTree();
  std::list<CComponent<CFlowGraphNode> *> components;
  ct->AllNodesInTree(&components);

  // All components except the root is a loop
  return (unsigned)components.size() - 1;
}


// To get all components except the root component
void
CFlowGraph::
GetLoopingComponents(std::list<CComponent<CFlowGraphNode> *> * looping_components)
{
  ComponentTree()->AllKidsInTree(looping_components);
}

//
// CFG =>
//   | { cfg FUNC_ID FNODES FEDGES FSTART FEND LOOPS }
// FNODES => { nodes BB_ID+ }
// BB_ID => string
// FUNC_ID => string
// FEDGES =>
//   |
//   | { edges FEDGE+ }
// FEDGE =>
//   | BB_ID->BB_ID
//   | BB_ID--BB_ID
//   | BB_ID->exit
// FSTART => { start BB_ID+ }
// FEND => { end BB_ID+ }
void CFlowGraph::PrintAsPFF(ostream &o)
{
   // FUNC_ID
   o << "{cfg " << Function()->Name() << endl;

   CComponentTree <CFlowGraphNode> *ct = ComponentTree();
   CComponent<CFlowGraphNode> *root = ct->TreeRoot();

   // FNODES
   o << "{nodes ";
   for (CComponent<CFlowGraphNode>::subnode_iterator bb_it=root->SubNodeBegin(); bb_it!=root->SubNodeEnd(); bb_it++) {
      o << (*bb_it)->Name() << " ";
   }
   o << "}" << endl; // Close nodes

   // FEDGES
   o << "      {edges ";
   set <CFlowGraphNode *> *subnodes = root->SubNodes();
   T_edge_list edge_list;
   Edges(&edge_list);
   for(T_edge_list_iterator edge = edge_list.begin(); edge != edge_list.end(); edge++) {
      if (subnodes->count(edge->from) > 0) {
         // Only include edges with the source node in this scope
         CGenericStmt *stmt = edge->from->Stmt();
         if (stmt->Type() == CGenericStmt::GS_CALL) {
            o << edge->from->Name() << "--" << edge->to->Name() << " ";
         } else {
            o << edge->from->Name() << "->" << edge->to->Name() << " ";
         }
      }
   }
   o << "}" << endl; // Close edges

   // FSTART
   o << "      {start " << GetEntry()->Name() << "}" << endl;

   // FEND
   o << "      {end " << ExitNode()->Name() << "}" << endl;

   // LOOPS
   PrintLoopsAsPFF(o, root, &edge_list, "      ");

   o << "}" << endl; // Close cfg
}

void CFlowGraph::AddAnnotNumberToEdge(unsigned int label, CFlowGraphNode * from, CFlowGraphNode * to, CFlowGraphEdgeAnnot * edge_annot)
{
   assert(from);
   assert(to);
   from->AddAnnotNumberToSuccessor(label, to, edge_annot);
}

void CFlowGraph::AssignHeaders(CComponent<CFlowGraphNode> *component)
{
   CFlowGraphNode *bb = component->Head();
   bb->SetHeader();
   for (CComponent<CFlowGraphNode>::kid_iterator scc=component->KidBegin(); scc!=component->KidEnd(); scc++) {
      AssignHeaders(scc->node);
   }
}

void CFlowGraph::AssignBackedges(CComponent<CFlowGraphNode> *component)
{
   for (CComponent<CFlowGraphNode>::backedge_iterator be_it=component->BackedgeBegin(); be_it!=component->BackedgeEnd(); be_it++) {
      CFlowGraphNode *src_bb = be_it->first;
      CFlowGraphNode *dest_bb = be_it->second;
      for (CFlowGraphNode::succ_iterator succ_it=src_bb->SuccBegin(); succ_it!=src_bb->SuccEnd(); succ_it++) {
         if (succ_it->node == dest_bb) {
            succ_it->edge_annot->SetBackedge();
            break;
         }
      }
   }
   for (CComponent<CFlowGraphNode>::kid_iterator scc=component->KidBegin(); scc!=component->KidEnd(); scc++) {
      AssignBackedges(scc->node);
   }
}

void CFlowGraph::BuildSccs(void)
{
   CLoopManager <CFlowGraph, CFlowGraphNode, CFlowGraphEdgeAnnot> loop_manager;
   if (loop_manager.NodeSplitting(this)) {
      // If splitting was needed then there is a risk that there are multiple return nodes (due to the copying).
      // In our analyses we assume a single return node. So we have to check this, and in case there are more
      // than one, then we just remove all but one and re-direct the in-edges to the removed ones into the one
      // saved. This may seem like reverting what node slitting has done, and actually that is true to some extent ...
      // but we only revert the last node - and that can never be involved in loops.
      CFlowGraphNode *basic_block_to_keep = NULL;
      bool removed = false;
      for (int i=NrOfNodes()-1; i>=0; i--) {
         CFlowGraphNode *basic_block = NodeAt(i);
         if (basic_block->SuccSize() == 0) {
            assert(basic_block->Stmt()->Type() == CGenericStmt::GS_RETURN);
            if (basic_block_to_keep == NULL) {
               // We save the first one
               basic_block_to_keep = basic_block;
            } else {
               // But remove all other and redirect to the first one.
               // Just to make things as simple as possible: add a new edge (that will be removed in the next statement)
               // just to point out where to redirect the predecessors to the node to remove.
               AddEdge(basic_block, basic_block_to_keep);
               RemoveNodeAndRedirectInEdgesToSuccessor(basic_block);
               removed = true;
            }
         }
      }
      if (removed) {
         CompressGraph();
      }
   }
   if (_component_tree) {
      delete _component_tree;
      _node_to_component.clear();
   }
   _component_tree = loop_manager.CreateSccTree(this, &_node_to_component);
   AssignBackedges(_component_tree->TreeRoot());
   AssignHeaders(_component_tree->TreeRoot());
}

CComponentTree <CFlowGraphNode> *CFlowGraph::ComponentTree(void)
{
   if (_component_tree == NULL) {
     BuildSccs();
   }
   return _component_tree;
}

const list <CFlowGraphNode*> *CFlowGraph::ExitNodesOfComponent(CComponent <CFlowGraphNode> *component)
{
   ComponentTree(); // asserts there is a mapping
   return component->ExitNodes(&_node_to_component);
}

const CFlowGraph::T_edge_list *CFlowGraph::ExitEdgesOfComponent(CComponent <CFlowGraphNode> *component)
{
   ComponentTree(); // asserts there is a node-to-component mapping
   const list <CFlowGraphNode*> *exit_nodes = ExitNodesOfComponent(component);
   T_edge_list *exit_edges = new T_edge_list();
   for (list <CFlowGraphNode*>::const_iterator node_it=exit_nodes->begin(); node_it!=exit_nodes->end(); node_it++) {
      CFlowGraphNode *node = *node_it;
      CComponent <CFlowGraphNode> *component;
      component = _node_to_component[node];
      for (CFlowGraphNode::succ_iterator succ_it=node->SuccBegin(); succ_it!=node->SuccEnd(); succ_it++) {
         CFlowGraphNode *succ = succ_it->node;
         if (_node_to_component[succ] != component) {
            T_edge edge = {node, succ_it->node, succ_it->edge_annot};
            exit_edges->push_back(edge);
         }
      }
   }
   return exit_edges;
}

bool 
CFlowGraph::
BasicBlockOfNodeHasExitEdgeToNonSubordinateComponent(CFlowGraphNode * node)
{
  assert(node);
  // Get the last node in the basic block the node belongs to 
  CFlowGraphNode * end_node = node->GetEndNodeOfNodesBasicBlock();
  // Call the other function
  return NodeHasExitEdgeToNonSubordinateComponent(end_node);
}

bool 
CFlowGraph::
NodeHasExitEdgeToNonSubordinateComponent(CFlowGraphNode * node)
{
  assert(node);
  // Get the comp�onent of the node 
  CComponent<CFlowGraphNode> * comp = _node_to_component[node];
  // Loop through all successors of the end node in basic block 
  for (CFlowGraphNode::succ_iterator succ_it=node->SuccBegin(); succ_it!=node->SuccEnd(); succ_it++) {
    CFlowGraphNode *succ_node = succ_it->node;
    CComponent<CFlowGraphNode> * succ_comp = _node_to_component[succ_node];
    if((succ_comp != comp) && !(succ_comp->IsAncestor(comp))) {
      return true;
    }
  }
  return false;
}


CFlowGraphNode *CFlowGraph::ExitNode(void)
{
   for (int i=NrOfNodes()-1; i>=0; i--) {
      if (NodeAt(i)->SuccSize() == 0) {
         return NodeAt(i);
      }
   }
   return NULL;
}

void CFlowGraph::ExitNodes(std::vector<CFlowGraphNode *> * exit_nodes)
{
  for (int i=NrOfNodes()-1; i>=0; i--) {
    if (NodeAt(i)->SuccSize() == 0) {
       exit_nodes->push_back(NodeAt(i));
    }
  }
}

void CFlowGraph::ExitNodes(std::list<CFlowGraphNode *> * exit_nodes)
{
  for (int i=NrOfNodes()-1; i>=0; i--) {
    if (NodeAt(i)->SuccSize() == 0) {
       exit_nodes->push_back(NodeAt(i));
    }
  }
}

void 
CFlowGraph::
GetBasicBlocksAsNodeLists(std::vector< std::list<CFlowGraphNode *> *> *bbs)
{
  // Loop through all nodes
  for (CFlowGraph::node_iterator node_it = NodesBegin(); node_it != NodesEnd(); node_it++) {
    CFlowGraphNode *node = *node_it;
    // Check if we should start a new basic block
    if(node->IsBeginOfBasicBlock()) {
      // Create a new list and store the start node in the list
      std::list<CFlowGraphNode *> * node_list = new std::list<CFlowGraphNode *>;
      CFlowGraphNode *n = node;
      node_list->push_back(n);
      // Store all its successor nodes as long as they are just a single successor 
      // and the successor only has one predecessor
      while(!(n->IsEndOfBasicBlock())) {
         assert(n->SuccSize() == 1);
         // Get the next successor
         n = n->SuccBegin()->node;
         node_list->push_back(n);
      }
      // Store the resulting list in the vector to return
      bbs->push_back(node_list);
    }
  }
}

unsigned 
CFlowGraph::
GetNrOfBasicBlocks()
{
  unsigned nr_of_bbs = 0; 
   // Loop through all nodes
  for (CFlowGraph::node_iterator node_it = NodesBegin(); node_it != NodesEnd(); node_it++) {
    CFlowGraphNode *node = *node_it;
    // Check if we should start a new basic block
    if(node->IsBeginOfBasicBlock()) {
      nr_of_bbs++;
    }
  }
  return nr_of_bbs;
}

unsigned 
CFlowGraph::
GetNrOfEdgesInbetweenBasicBlocks()
{
  unsigned nr_of_edges = 0; 
   // Loop through all nodes
  for (CFlowGraph::node_iterator node_it = NodesBegin(); node_it != NodesEnd(); node_it++) {
    CFlowGraphNode *node = *node_it;
    // Check if the node ends the basic block
    if(node->IsEndOfBasicBlock()) {
      nr_of_edges += node->SuccSize();
    }
  }
  return nr_of_edges;
}

void CFlowGraph::PrintFlowGraphGraphically(FILE *f, bool draw_with_bb_number)
{
   fprintf(f, "digraph \"\" {\n");
   fprintf(f, "  size=\"11.4,7.8\";\n");
   fprintf(f, "  rankdir=TB;\n");
   fprintf(f, "  center=1;\n");
   fprintf(f, "  rotate=0;\n");
   fprintf(f, "   {\n");
   fprintf(f, "   node [shape=plaintext, fontsize=10];\n");
   time_t now;
   time(&now);
   string time = asctime(localtime(&now));
   time.resize(time.size()-1); // remove newline at end
   fprintf(f, "   \"Flow graph for %s\\n%s\"\n", Function()->PrettifiedName().c_str(), time.c_str());
   fprintf(f, "   }\n");
   fprintf(f, "    /* Nodes */\n");
   fprintf(f, "    node [width=0.01 fixedsize=true shape=circle fontsize=10]\n");
   for (node_iterator bb=NodesBegin(); bb!=NodesEnd(); bb++) {
      if (draw_with_bb_number) {
         fprintf(f, "    %d[label=%s]\n", (*bb)->Id(), (*bb)->Name().c_str());
      } else {
         fprintf(f, "    %d[label=%d]\n", (*bb)->Id(), (*bb)->Id());
      }
   }
   fprintf(f, "    /* Edges */\n");
   for (node_iterator bb=NodesBegin(); bb!=NodesEnd(); bb++) {
      fprintf(f, "    ");
      for (CFlowGraphNode::succ_iterator succ=(*bb)->SuccBegin(); succ!=(*bb)->SuccEnd(); succ++) {
         fprintf(f, "%d->%d ", (*bb)->Id(), succ->node->Id());
      }
      fprintf(f, "\n");
   }
   fprintf(f, "}\n");
}

void
CFlowGraph::
CollectNodesToKeep(CFlowGraphNode *node, set<CFlowGraphNode *> *nodes_to_keep)
{
   if (nodes_to_keep->find(node) == nodes_to_keep->end()) {
      nodes_to_keep->insert(node);
      for (CFlowGraphNode::succ_iterator succ=node->SuccBegin(); succ!=node->SuccEnd(); succ++) {
         CollectNodesToKeep(succ->node, nodes_to_keep);
      }
   }
}

void
CFlowGraph::
CutCodeSnippet(CFlowGraphNode *start_node, CFlowGraphNode *end_node)
{
   CFlowGraphNode *exit_node = ExitNode();
   assert(exit_node);

   set<CFlowGraphNode *> nodes_to_keep;
   nodes_to_keep.insert(end_node);
   CollectNodesToKeep(start_node, &nodes_to_keep);
   nodes_to_keep.insert(GetEntry());
   nodes_to_keep.insert(exit_node);

   // Now remove the nodes that are not in the snippet.
   unsigned nr_of_nodes = NrOfNodes();
   for (unsigned i=0; i<nr_of_nodes; i++) {
      if (nodes_to_keep.find(NodeAt(i)) == nodes_to_keep.end()) {
         RemoveNode(NodeAt(i));
      }
   }

   // Add edges from enter to start node, and from end node to return node, if they are not the same and not there
   if (GetEntry()->SuccSize() == 0) {
      AddEdge(GetEntry(), start_node);
   }
   if (exit_node->PredSize() == 0 && exit_node != end_node) {
      AddEdge(end_node, exit_node);
   }

   // There may be holes, we have to compress - always follow up with new enumeration
   CompressGraph();

   // Finally - build new scc:s
   BuildSccs();
}

void
CFlowGraph::
PrintAsDot(ostream &o, const CSourceLoader *source_loader)
{
   string function_name = Function()->PrettifiedName();
   o << "   "  << "subgraph \"" << function_name << "\" {" << endl;

   // Node specification. The node Id() need to be prefixed by the function
   // name to make them globally unique and not interfere with other cfgs
   // within the same digraph
   for (node_iterator it = NodesBegin(); it != NodesEnd(); it++) {
      CFlowGraphNode* node = *it;
      string label;
      if (source_loader) {
         label = source_loader->GetCLine(node->Name());
      } else {
         label = node->PrettifiedName();
      }
      stringstream node_key;
      node_key << function_name << node->Id() ;
      o << "   \""  << node_key.str() << "\"[label=\"" << label << "\",fontsize=10,width=0.01]" << endl;
   }
   // Generate the edge specification
   T_edge_list edges;
   Edges(&edges);
   for (T_edge_list_iterator edge_it=edges.begin(); edge_it!=edges.end(); ++edge_it) {
      stringstream src_node_key, dest_node_key;
      src_node_key << function_name << edge_it->from->Id();
      dest_node_key << function_name << edge_it->to->Id();
      o << "   \""  << src_node_key.str() << "\" -> \"" << dest_node_key.str() << "\"" << endl;
   }

   // Generate an entry edge (we don't have multiple in-edges in flow graphs) by creating an
   // invisible place holder for the source of it 
   string invisible_entry_node_key = function_name + "_entry"; // Uinque since other node keys are based on numbers
   stringstream entry_node_key;
   entry_node_key << function_name << GetEntry()->Id();
   o << "   \"" << invisible_entry_node_key << "\" [label=\"\",color=\"white\",height=\"0.01\",fontsize=10,width=0.01]" << endl;
   o << "   \""  << invisible_entry_node_key << "\" -> \"" << entry_node_key.str() << "\"" << endl;

   // Generate an exit edge the same way. Here we may have myltiple nodes.
   string invisible_exit_node_key = function_name + "_exit";
   o << "   \""  << invisible_exit_node_key << "\" [label=\"\",color=\"white\",fontsize=10,width=0.01]" << endl;
   list <CFlowGraphNode*> exit_nodes;
   GetExitNodes(&exit_nodes);
   for (list <CFlowGraphNode*>::const_iterator node_it=exit_nodes.begin(); node_it!=exit_nodes.end(); ++node_it) {
      stringstream exit_node_key;
      exit_node_key << function_name << (*node_it)->Id();
      o << "   \""  << exit_node_key.str() << "\" -> \"" << invisible_exit_node_key << "\"" << endl;
   }

   o << "}" << endl;
}

void
CFlowGraph::
PrintDetailed(ostream &o)
{
  string function_name = Function()->PrettifiedName();
  o << "begin CFG " << function_name << " " << endl;

  // Print nodes
  {
    o << "  nodes: " << endl;
    for (node_iterator it = NodesBegin(); it != NodesEnd(); it++) {
      CFlowGraphNode* node = *it;
      o << "    ";
      node->PrintDetailed(o);
    o << endl;
    }
    o << "    entry" << endl;
    o << "    exit" << endl;
  }

  // Print edges
  {
    o << "  edges: " << endl;
    for (node_iterator it = NodesBegin(); it != NodesEnd(); it++) {
      CFlowGraphNode* node = *it;
      o << "    ";
      node->PrintEdgesDetailed(o);
      o << endl;
    }
  }

  // Generate an entry edge 
  {
    o << "    entry -> ";
    GetEntry()->PrintDetailed(o);
    o << endl;
  }

  // Generate exit edges
  {
    // Here we may have multiple nodes.
    list <CFlowGraphNode*> exit_nodes;
    GetExitNodes(&exit_nodes);
    for (list <CFlowGraphNode*>::const_iterator node_it=exit_nodes.begin(); node_it!=exit_nodes.end(); ++node_it) {
      o << "    "; 
      (*node_it)->PrintDetailed(o);
      o << " -> " << "exit" << endl;
    }
  }
  
  o << "end CFG " << endl;
} 

int
CFlowGraph::
PrintToPdf(std::string file_path)
{
   stringstream ss_dot_file;
   ss_dot_file << file_path << ".dot";

   ofstream pdf_file;
   pdf_file.open(ss_dot_file.str().c_str());
   if (pdf_file.is_open())
   {
      PrintAsDot(pdf_file);
      pdf_file.close();

      stringstream ss_command;
      ss_command << "dot -Tpdf -o" << file_path << " " << ss_dot_file.str();
      return system(ss_command.str().c_str());
   }
   else
      return -1;
}

