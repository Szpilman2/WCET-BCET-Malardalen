// $Id: CFlowGraph.h 3709 2011-11-18 19:43:57Z lkg02 $

#ifndef CFLOW_GRAPH_H_
#define CFLOW_GRAPH_H_

#include "graphs/tools/CGraph.h"
#include "CFlowGraphNode.h"
#include "CFlowGraphEdgeAnnot.h"
#include <map>
#include <vector>
#include <cassert>
#include <cstdio>

class CGenericStmt;
class CGenericFunction;
class CSourceLoader;
template <typename CFlowGraphNode> class CComponent;
template <typename CFlowGraphNode> class CComponentTree;

/** \class CFlowGraph
   Defines a flow graph. The flow graph represents the possible execution flows in a single function.
   The nodes represents statements (one-to-one between statements and nodes). The edges represents
   possible execution flows local to the function. Every possible flow is represented by a single edge.
   Every edge represents a possible flow, except that edges out from nodes representing
   Call-statements. These are present to make sure that the graph is connected and for convenience reasons.
   The graph owns the memory of its nodes.
*/
class CFlowGraph : public CGraph <CFlowGraphNode, CFlowGraphEdgeAnnot>
{
public:
   /** Constructs a new empty flowgraph.
      \param function A pointer to the function whose code this flow graph will represent. The memory
         of the function object is NOT owned by this graph. The pointer will be stored in this flow graph
         so after releasing the memory of the function object this flow graph should not be used any more.
   */
   CFlowGraph(CGenericFunction *function) : _function(function), _entry_node(NULL), _component_tree(NULL) { }

   /** Frees all memory owned by this node, i.e. the nodes will deleted.
   */
   virtual ~CFlowGraph();

   /** \return A pointer to a new flow graph that is a duplicate of this. A deep copy will be
      performed with all objects owned by this node.
   */
   CFlowGraph *Duplicate();

   /** Plants a pointer to the entry node of the graph. The entry node can not be found by just
      inspecting the graph structure for an arbitrary programs. Thus it must be set from outside
      when more knowledge about the program is present.
      \pre \a node is a node of the graph. */
   void SetEntry(CFlowGraphNode *entry_node) { _entry_node = entry_node; }

   /** \return the pointer to the entry node.
      \pre The entry node has been set by SetEntry(). */
   inline CFlowGraphNode *GetEntry() const { assert(_entry_node); return _entry_node; }
   inline bool IsEntry(CFlowGraphNode * node) const { return _entry_node == node; }

   /** \return A pointer to the function whose code this flow graph is representing. The memory
         of the function object is NOT owned by this graph.
   */
   CGenericFunction *Function() const { return _function; }

   /** Print the flow graph to a text file using the PFF format (the flow graph part of it)
   */
   void PrintAsPFF(std::ostream &o);

   /** Add label @a label to the edge that goes from @a from to @a to, and is annotated with @a edge_annot */
   void AddAnnotNumberToEdge(unsigned int label, CFlowGraphNode * from, CFlowGraphNode * to, CFlowGraphEdgeAnnot * edge_annot);
   
   /** Add label @a label to the edge that goes from the node with id @a from to the node with id @a to and is annotated with @a edge_annot */
   void AddAnnotNumberToEdge(unsigned int label, int from, int to, CFlowGraphEdgeAnnot * edge_annot) {AddAnnotNumberToEdge(label, NodeAt(from), NodeAt(to), edge_annot);}

   /** \return A pointer to a component tree of the cfg. All subtrees except the root represents
      loops, and contain pointers to the call graph nodes that are involved in that loop but not
      in any other. The root contains pointers to the nodes that are not involved in any loop.
   */
   CComponentTree <CFlowGraphNode> *ComponentTree();
   unsigned GetNrOfLoops();

   // To get all components except the root compoinent
   void GetLoopingComponents(std::list<CComponent<CFlowGraphNode> *> * looping_components);

   /** \return The component of \a node, or NULL if \a node is is not in this flow graph.
   */
   CComponent <CFlowGraphNode> *ComponentOfNode(CFlowGraphNode *node) { return _node_to_component[node]; }

   /** \return All nodes in \a component that have out-edges that ends in some other component.
   */
   const std::list<CFlowGraphNode*> *ExitNodesOfComponent(CComponent <CFlowGraphNode> *component);

   /** \return All edges that starts in \a component and ends in some other component.
   */
   const T_edge_list *ExitEdgesOfComponent(CComponent <CFlowGraphNode> *component);

   // This function returns true if it is possible to leave the node
   // to a successor so that the successor's component not is the
   // node's component, nor that the node's component is an ancestor
   // of the successors component. In a CFG this corresponds to a
   // while-do loop.
   bool NodeHasExitEdgeToNonSubordinateComponent(CFlowGraphNode *node); 

   // Returns the flow graph node that has no successors or NULL if
   // there is none. If there are more than one then the first one is
   // returned.
   CFlowGraphNode *ExitNode();
   // To get all exit nodes of the flow graph in a vector
   void ExitNodes(std::vector<CFlowGraphNode *> *exit_nodes);
   void ExitNodes(std::list<CFlowGraphNode *> *exit_nodes);

   /** \return Updates the argument vector with list of flowgraph nodes. Each node list 
       corresponds to a basic block. The node list is ordered, ie. the first node 
       in each list is the header node of the basic block and the last is the end node.
       The lists (but not their content) should be deallocated by the caller.
   */
   void GetBasicBlocksAsNodeLists(std::vector< std::list<CFlowGraphNode *> *> *bbs);

   /** To get the number of basic blocks and edges between basic
       blocks in the CFG. O(nodes). */
   unsigned GetNrOfBasicBlocks();
   unsigned GetNrOfEdgesInbetweenBasicBlocks();

   /** Prints the current flow graph to a dot file.
   */
   void PrintFlowGraphGraphically(FILE *f, bool draw_with_bb_number);

   /** Cut away some code from this graph. The code that is preserved is that represented by nodes reachable
      from \a start_node but not bypassing \a end_node as well as the entry and exit nodes. If the entry or
      exit nodes are isolated they will be connected to \a start_node and \a end_node respectively.
      The eventually added edges lacks annotations.
      \param start_node A node where to start a forward search in this graph.
      \param end_node A node the forward search will stop at.
      \pre This flow graph has unique entry and exit nodes.
      \post This flow graph has the same unique entry and exit nodes, is connected and all nodes are
      reachable from the entry node. All nodes (except for the entry and exit nodes) that are not reached
      by the forward search are removed. Internal data of this graph that may depend on the removed nodes
      will be properly updated.
   */
   void CutCodeSnippet(CFlowGraphNode *start_node, CFlowGraphNode *end_node);

   /** \return A pointer to a list of nodes representing the statement \a stmt in this flow graph,
      or NULL if there is no node representating \a stmt. Usually the returned list contains a
      single element. Multiple nodes will occur only in case of irreducible loops (which forces
      some structuring algoritm to make some node copying).
   */
   // EBBE: Removed since it seems not to be maintained correctly
   // const std::vector<CFlowGraphNode*> *NodesOfStmt(CGenericStmt *stmt) { return &_stmt_to_node[stmt]; }

   /** Prints this flow graph to a dot file. This will be printed in a way assuming that this is the sole
      graph of the dot file.
      \param o The file (stream) to print to.
      \param source_loader An optional pointer to a C-code source loader that is capable to map
         statements labels to C-source code. If present the nodes of the graph will be annotated
         with corresponding C-source, else with the "PrettifiedName" of the node.
   */
   void PrintAsDot(std::ostream &o = std::cout, const CSourceLoader *source_loader=NULL);

   /** Prints this flow graph as a pdf file via the dot format and tool. This will be printed in a way
      assuming that this is the sole graph of the dot file.
      \param file_path The file name of the new file. The name will be presented as is to the file system
      (i.e. nothing checked and nothing appended to the beginning or end).
   */
   int PrintToPdf(std::string file_path);

   /* Detiled printout, including annts_to_succs in CFG nodes */
   void PrintDetailed(std::ostream &o = std::cout);

private:
   CFlowGraphNode *Root();

   CGenericFunction *_function;

   CFlowGraphNode *_entry_node;

   CComponentTree <CFlowGraphNode> *_component_tree;

   // A mapping from all nodes to its component (for nodes that are part of a loop)
   std::map<CFlowGraphNode*, CComponent <CFlowGraphNode>*> _node_to_component;

   // std::map<CGenericStmt*, std::vector<CFlowGraphNode*> > _stmt_to_node;

   CFlowGraphNode *NodeOfName(const std::string *name) const;
   CFlowGraphNode *NodeOfNumber(const int number) const;

   // This function returns true if it is possible to leave the basic
   // block to which the header belongs to a successor so that the
   // successor's component not is the header's component, nor that the
   // header's component is an ancestor of the successors
   // component. In a CFG this corresponds to a while-do loop.
   bool BasicBlockOfNodeHasExitEdgeToNonSubordinateComponent(CFlowGraphNode *node); 

   // Will de-compose the flow graph into sccs and a set of nodes that is not part of any scc
   void BuildSccs();

   // Intercepts the parent class' resetting of nodes
   void ResetNode__(int id);

   void AssignBackedges(CComponent<CFlowGraphNode> *component);
   void AssignHeaders(CComponent<CFlowGraphNode> *component);

   /* Helper function for RemoveEmptyNodes */
   void InsertEmptyIf(void);

   CFlowGraph & operator = (const CFlowGraph &);
   CFlowGraph(CFlowGraph &theother);

   // Helper function for PrintAsPFF
   void PrintLoopsAsPFF(std::ostream &o, CComponent<CFlowGraphNode> *root, T_edge_list *edge_list, std::string indent);

   // Helper function to CutCodeSnippet.
   void CollectNodesToKeep(CFlowGraphNode *node, std::set<CFlowGraphNode *> *nodes_to_keep);
};

#endif
