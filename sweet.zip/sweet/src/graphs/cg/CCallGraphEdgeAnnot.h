// $Id: CCallGraphEdgeAnnot.h 5125 2013-04-07 22:13:58Z lkg02 $

#ifndef CCALL_GRAPH_EDGE_H
#define CCALL_GRAPH_EDGE_H



class CFlowGraphNode;

/**
   \class CCallGraphEdgeAnnot
   A call graph edge is the annotation of an edge in a call graph. An annotated edge represents
   a possible inerprocedure flow from one call. This annotation contains the call site and
   information about if the call is "ambigous" or not.
*/
class CCallGraphEdgeAnnot
{
public:
   /** Constructs one call graph edge, which contains the annotations of an edge in the call graph.
      \param call_site A pointer to the flow graph node that represents the call statement that
         causes this edge in the call graph. The memory of the object is not owned by this edge
         annotation. If it is released then this edge annotation should not be used any more.
      \param ambigous_pointer_call A flag indicating that this is not the sole edge caused by the
         same call site. Multiple edges from a call graph node usually exists because there are
         multiple call sites.
         However, multiple destinations from the same call site may also occur, This is because
         the call is performed using function pointer and it was not possible for the pointer
         analysis to find a single function.
   */
   CCallGraphEdgeAnnot(CFlowGraphNode *call_site, bool ambigous_pointer_call=false) :
         _call_site(call_site),
         _ambigous_pointer_call(ambigous_pointer_call)
         { }

   CCallGraphEdgeAnnot *Copy()
         {
            CCallGraphEdgeAnnot *new_annot = new CCallGraphEdgeAnnot(_call_site, _ambigous_pointer_call);
            return new_annot;
         }

   /** Needed for the "impossible error"-case in template function for template class - and for the
      = operator. Should not be used when constructing the graph.
   */
   CCallGraphEdgeAnnot() { }

   /** Releases all memory owned by this edge as well as the memory of itself.
   */
   ~CCallGraphEdgeAnnot() { }

   /** Needed for the node splitting algorithm.
   */
   CCallGraphEdgeAnnot & operator = (const CCallGraphEdgeAnnot &theother)
   { _call_site = theother._call_site; _ambigous_pointer_call = theother._ambigous_pointer_call; return *this; }

      /** \return The value of the "ambigous pointer call" flag.
   */
   bool IsAmbigousPointerCall() { return _ambigous_pointer_call; }

   /** \return The cfg node of the statement performing the call.
   */
   CFlowGraphNode *CallSite() { return _call_site; }

private:
   CFlowGraphNode *_call_site;
   bool _ambigous_pointer_call;
};

#endif
