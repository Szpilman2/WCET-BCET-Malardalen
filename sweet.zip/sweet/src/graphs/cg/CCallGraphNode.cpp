#include "CCallGraphNode.h"
#include "../tools/CNode.inl"
#include "graphs/cfg/CFlowGraph.h"

template class CNode <CCallGraphNode, CCallGraphEdgeAnnot>;

CCallGraphNode::
~CCallGraphNode()
{
   delete _flow_graph;
}

CGenericFunction *
CCallGraphNode::
Function() const
{
   return FlowGraph()->Function();
}
