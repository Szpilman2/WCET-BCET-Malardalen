// $Id: CProgramElement.cpp 327 2009-05-06 08:55:06Z msl01 $
#include "CProgramElement.h"
#include "program/CGenericFunction.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/components/CComponent.h"

using namespace std;

string CProgramElement::Text() {
   if (_component == NULL) {
      // Then _component represents a function, implying this element also represents a function.
      return _function->PrettifiedName();
   } else {
      // Then we deal with a loop
      return "Loop, header = " + _component->Head()->Name();
   }
}
