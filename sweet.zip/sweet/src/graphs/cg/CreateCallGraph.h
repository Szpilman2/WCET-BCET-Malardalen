// $Id: CreateCallGraph.h 1377 2009-11-11 14:02:13Z csg01 $

#ifndef CREATE_CALL_GRAPH_H_INCLUDED
#define CREATE_CALL_GRAPH_H_INCLUDED

#include <vector>
#include <memory>


class CCallGraph;
class CFlowGraph;
class CSymTabBase;
class CSteensgaardPA;

/** Constructs a new call graph.
   \param flow_graphs A set of flow graphs.
   \param symtab A symbol table. Only functions will be looked up.
   \param pa A pointer analysis. Only function pointers will be used (in case
      function pointers occur in the program).
   Nodes in the flow graphs that contains statements of call type will be
   connected to call graphs with the the name of the called function(s).
   Each call graph node will contain a pointer to a flowgraph representing the
   possible execution flow of the function that the node represents. The flow graph
   nodes are considered the owners of the flow graphs.
   \return The new call graph.
*/
std::unique_ptr<CCallGraph> CreateCallGraph(std::vector<CFlowGraph*> & flow_graphs, const CSymTabBase *symtab,
      const CSteensgaardPA &pa);

#endif
