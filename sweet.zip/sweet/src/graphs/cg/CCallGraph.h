// $Id: CCallGraph.h 3710 2011-11-18 19:46:33Z lkg02 $

#ifndef CCALL_GRAPH_H
#define CCALL_GRAPH_H

/** \class CCallGraph
   A call graph is a graph where nodes represents functions and edges
   represents possible calls.
   The source node of an edge represents the function where the call statement resides (the caller).
   The destination node of an edge represents the function being called (the callee).
   The call takes place at a certain statement in the caller, a call statement.
   The edge is annotated with this statement.
   This call graph has the following properties:
   - The graph is connected
   - The graph is a multigraph
   - The graph has a "start node", i.e. a node from which there is a path to every other node in the graph.
      If more than one node fullfill this criteria then it is included in a nest of mutually recursive functions
      and the call graph will choose an arbitrary node among these to be the "start node".
   - If two nodes represent the same function.

   The interface provides the following:
   - A mapping from functions to a list of callgraphs where the function is
      present.
*/

#include "CCallGraphEdgeAnnot.h"
#include "CCallGraphNode.h"
#include "CProgramElement.h"
#include "graphs/tools/CGraph.h"
#include "graphs/components/CComponentTree.h"
#include <iostream>
#include <map>
#include <set>
#include <list>
#include <vector>
#include <ctime>
#include <cstdio>

class CFlowGraphNode;
class CGenericFunction;
 

class CCallGraph : public CGraph <CCallGraphNode, CCallGraphEdgeAnnot>
{
public:
   /** Constructs a new empty call graph.
   */
   CCallGraph();

   /** Releases all memory owned by this call graph as well as the memory of itself.
   */
   virtual ~CCallGraph();

   /**
      @return \a True if the function of \a node is a recursive function, else \a false
      @pre This graph has identified its recursive functions by a previous call to IdentifyRecursiveFunctions()
   */
   bool IsRecursive(CCallGraphNode *node);

   /**
      @return \a True if any function represented by a node in this call graph is recursive else \a false
   */
   bool ContainRecursiveFunctions();

   /** @return A set of pointers to recursive function(s) if the function of \a node is involved in recursion, else NULL.
      The returned memory is private for the call graph.
      @pre This graph has identified its recursive functions by a previous call to IdentifyRecursiveFunctions()
   */
   std::set<CCallGraphNode*> *RecursiveFunctionSet(CCallGraphNode *node);

   /** Searches the graph for recursive functions and collect them into sets, each consists of one (direct recursion) or
   more (mutual recursion) functions.
   If the cycles of mutual recursive functions the graph have in-edges from outside the cycle to more than one node,
   (compare irreducible loops in flow graphs) then subgraphs will be duplicated in order to eliminate such multiple
   entries (using "Node splitting").
   @return \a True if nodes were duplicated else \a false
   @post This graph will have a container with sets of callgraph nodes that make it suitable to later retieve information
   about recursive functions.
   */
   bool IdentifyRecursiveFunctions();

   /** @return A pointer to a node of this callgraph that represents \a function, or NULL if there is none
   */
   CCallGraphNode *FindNodeOfFunction(CGenericFunction *function);

   /** Simple printout routine.
   */
   void Print(std::ostream &o=std::cout);

   /** Print the call-graph to a dot file, labelling the nodes with function names.
   */
   void PrintGraphically(FILE *file, const std::string);

private:
   CComponentTree <CCallGraphNode> *_component_tree;
   std::map<CCallGraphNode *, CComponent <CCallGraphNode>*> _node_to_component;
};

#endif
