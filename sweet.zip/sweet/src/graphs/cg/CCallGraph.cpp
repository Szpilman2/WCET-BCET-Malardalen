// $Id: CCallGraph.cpp 2203 2010-05-28 11:13:36Z ael01 $

#include "CCallGraph.h"
#include "graphs/tools/CGraph.inl"
#include "graphs/tools/CNode.inl"
#include "graphs/cfg/CFlowGraph.h"
#include "program/CGenericFunction.h"
#include "graphs/tools/CLoopManager.inl"
#include "graphs/cfg/CFlowGraphNode.h"
#include <cstdio>
 
using namespace std;

template class CGraph <CCallGraphNode, CCallGraphEdgeAnnot>;

CCallGraph::
CCallGraph()
{
   CCallGraph::_multi_graph = true;
   _component_tree = NULL;
}

CCallGraph::
~CCallGraph()
{
   if (_component_tree) {
      delete _component_tree;
   }
   for (unsigned i=0; i<NrOfNodes(); i++) {
      if (NodeAt(i)) {
         delete NodeAt(i);
      }
   }
}

bool
CCallGraph::
IsRecursive(CCallGraphNode *node)
{
   return RecursiveFunctionSet(node) != NULL;
}

set <CCallGraphNode*> *
CCallGraph::
RecursiveFunctionSet(CCallGraphNode *node)
{
   if (_node_to_component.size() == 0) {
      IdentifyRecursiveFunctions();
   }
   map <CCallGraphNode*, CComponent <CCallGraphNode>*>::iterator component_it;
   component_it = _node_to_component.find(node);
   assert (component_it != _node_to_component.end());
   CComponent <CCallGraphNode> *component = component_it->second;
   if (component != _component_tree->TreeRoot()) {
      return component->SubNodes();
   }
   return NULL;
}

bool
CCallGraph::
IdentifyRecursiveFunctions()
{
   CLoopManager <CCallGraph, CCallGraphNode, CCallGraphEdgeAnnot> loop_manager;
   bool nodes_have_been_splitted = loop_manager.NodeSplitting((CCallGraph*)this);
   _component_tree = loop_manager.CreateSccTree((CCallGraph*)this, &_node_to_component);
   return nodes_have_been_splitted;
}

bool
CCallGraph::
ContainRecursiveFunctions()
{
   for (unsigned i=0; i<NrOfNodes(); ++i) {
      CCallGraphNode *node = NodeAt(i);
      if (IsRecursive(node)) {
         return true;
      }
   }
   return false;
}

CCallGraphNode *
CCallGraph::
FindNodeOfFunction(CGenericFunction *function)
{
   for (node_iterator node_it=NodesBegin(); node_it!=NodesEnd(); node_it++) {
      if ((*node_it)->Function() == function) {
         return *node_it;
      }
   }
   return NULL;
}

void
CCallGraph::
PrintGraphically(FILE *f, const string s)
{
   fprintf(f, "digraph \"\" {\n");
   fprintf(f, "  size=\"10,8\";\n");
   fprintf(f, "  rankdir=TB;\n");
   fprintf(f, "  center=1;\n");
   fprintf(f, "  rotate=0;\n");
   fprintf(f, "   {\n");
   fprintf(f, "   node [shape=plaintext,fontsize=10];\n");
   time_t now;
   time(&now);
   string time = asctime(localtime(&now));
   time.resize(time.size()-1); // remove newline at end
   fprintf(f, "   \"Call graph for %s\\n%s\"\n", s.c_str(), time.c_str());
   fprintf(f, "   }\n");
   for (unsigned i=0; i<NrOfNodes(); ++i) {
      CCallGraphNode *node = NodeAt(i);
      string func_name = node->Function()->PrettifiedName();
      unsigned size = node->FlowGraph()->NrOfNodes();
      fprintf(f, "   %d [label=\"%s\\n(size=%d)\",fontsize=7]\n", node->Id(), func_name.c_str(), size);
   }
   T_edge_list edge_list;
   Edges(&edge_list);
   for (T_edge_list::iterator edge_it=edge_list.begin(); edge_it!=edge_list.end(); ++edge_it) {
      fprintf(f, "   %d->%d\n", edge_it->from->Id(), edge_it->to->Id());
   }
   fprintf(f, "}\n");
}

// Simple printing
void
CCallGraph::
Print(ostream &o)
{
   for (node_iterator cgnode = NodesBegin(); cgnode != NodesEnd(); cgnode++) {
      // Print the name of the function
      CGenericFunction * func = (*cgnode)->Function();
      o << "  " << func->PrettifiedName() << endl;

      // Print all predecessors
      o << "     called by: ";
      for (CCallGraphNode::pred_iterator pred = (*cgnode)->PredBegin(); pred != (*cgnode)->PredEnd(); pred++) {
         // Print the name of the function
         CGenericFunction * pred_func = (*pred)->Function();
         o << pred_func->PrettifiedName() << " ";
      }
      o << endl;

      // Print all successors
      o << "     calls: ";
      for (CCallGraphNode::succ_iterator succ = (*cgnode)->SuccBegin(); succ != (*cgnode)->SuccEnd(); succ++) {
         // Print the name of the function
         CGenericFunction * succ_func = succ->node->Function();
         o << succ_func->PrettifiedName() << " ";
      }
      o << endl;
   }
}

