// $Id: CProgramElement.h 843 2009-07-30 16:11:14Z lkg02 $

#ifndef CPROGRAM_ELEMENT_H
#define CPROGRAM_ELEMENT_H

#include <string>

class CCallGraph;
class CGenericFunction;
class CFlowGraphNode;
template <typename CFlowGraphNode> class CComponent;

/** \class CProgramElement A class representing a program element. You can simply get out from it what you put into it.
*/
class CProgramElement {
public:
   /**
      Creates a new program element.
      \param tree_level is an integer intended to denote the tree level in the program of this element
      \param callgraph is a pointer to a call graph intended to be the call graph where this program element lives
      \param function is a pointer to a function intended to be the function where this program element lives
      \param component is a pointer to a component intended to be the component where this program element lives
   */
   CProgramElement(int tree_level, CCallGraph *callgraph, CGenericFunction *function, CComponent <CFlowGraphNode> *component) :
      _tree_level(tree_level), _callgraph(callgraph), _function(function), _component(component) { }

   /** Sets this element to be recursive.
   */
   void SetRecursive() { _recursive = true; }

   /** \return the recursive property of this element.
   */
   bool IsRecursive() { return _recursive; }

   /** \return a text reprsenting this element. In case this is a function it will be the function name, if it is
      a loop it will be the name of the header basic block.
   */
   std::string Text();

   /** \return a text like the Text() function, but indented according to the components tree level using
      \a spaces_per_level number of spaces as indentation depth for each level.
   */
   std::string IndentedText(int spaces_per_level) {
      return std::string(spaces_per_level*_tree_level, ' ') + Text();
   }

   /** \return the tree level of this element.
   */
   int TreeLevel() { return _tree_level; }

   /** \return a pointer to the call graph that this element lives in.
   */
   CCallGraph *CallGraph() { return _callgraph; }

   /** \return a pointer to the function that this element lives in.
   */
   CGenericFunction *Function() { return _function; }

   /** \return a pointer to the component that this element lives in.
   */
   CComponent <CFlowGraphNode> *Component() { return _component; }
private:
   int _tree_level;
   bool _recursive;
   CCallGraph *_callgraph;
   CGenericFunction *_function;
   CComponent <CFlowGraphNode> *_component;
};

#endif
