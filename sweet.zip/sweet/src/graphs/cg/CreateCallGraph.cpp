// $Id: CreateCallGraph.cpp 1468 2009-12-04 07:32:46Z csg01 $

#include "CreateCallGraph.h"
#include "CCallGraph.h"
#include "CCallGraphNode.h"
#include "graphs/cfg/CFlowGraph.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/cfg/CFlowGraph.h"
#include "graphs/scopes/CScopeGraph.h"
#include "graphs/ecfg/CECFG.h"
#include "program/alf/AStmt.h"
#include "graphs/components/CComponentTree.h"
#include <typeinfo>

using namespace alf;
using namespace std;

// Crates a mapping from functions to flowgraphs based on a list of flow graphs
static void
FunctionToFlowGraph(vector <CFlowGraph*> *flow_graphs, map <CGenericFunction*, CFlowGraph*> *function_to_flow_graph)
{
   for (vector <CFlowGraph*>::iterator cfg_it=flow_graphs->begin(); cfg_it!=flow_graphs->end(); cfg_it++) {
      CFlowGraph *flow_graph = *cfg_it;
      CGenericFunction *function = flow_graph->Function();
      (*function_to_flow_graph)[function] = flow_graph;
   }
}

// Collects all nodes of a flow graph that represents call statements
static void
CollectCallNodes(CFlowGraph *calling_flow_graph, vector <CFlowGraphNode*> *call_nodes)
{
   unsigned nr_of_nodes = calling_flow_graph->NrOfNodes();
   for (unsigned node_nr=0; node_nr<nr_of_nodes; node_nr++) {
      CFlowGraphNode *flow_graph_node = calling_flow_graph->NodeAt(node_nr);
      CGenericStmt *stmt = flow_graph_node->Stmt();
      if (stmt->Type() == CGenericStmt::GS_CALL) {
         call_nodes->push_back(flow_graph_node);
      }
   }
}

// Get the called functions from the statement of the call node
// For each called function:
//    Convert it to a flow graph and add it to a list
static void
AddCalles(list<CFlowGraph*> *callees, CFlowGraphNode *call_node, map <CGenericFunction*, CFlowGraph*> *function_to_flow_graph, const CSymTabBase *symtab, const CSteensgaardPA &pa)
{
   CGenericStmtCall *call_stmt = dynamic_cast<CGenericStmtCall*>(call_node->Stmt());
   assert(call_stmt);
   list <CGenericFunction*> function_list;
   call_stmt->CalledFunctions(&function_list, symtab, pa);
   for (list <CGenericFunction*>::iterator func_it=function_list.begin(); func_it!=function_list.end(); func_it++) {
      CGenericFunction *called_function = *func_it;
      CFlowGraph *called_flow_graph = (*function_to_flow_graph)[called_function];
      callees->push_back(called_flow_graph);
   }
}

// For each node i a list of calling nodes,
//    Select the element associated with it in the calls map
//    Add the calles to that element
static void
AssociateCallList(map <CFlowGraphNode*, list<CFlowGraph*> > *calls, vector <CFlowGraphNode*> *call_nodes,
                           map <CGenericFunction*, CFlowGraph*> *function_to_flow_graph, const CSymTabBase *symtab, const CSteensgaardPA &pa)
{
   for (vector <CFlowGraphNode*>::iterator node_it=call_nodes->begin(); node_it!=call_nodes->end(); node_it++) {
      CFlowGraphNode *call_node = *node_it;
      list<CFlowGraph*> *list_of_called_flow_graphs = &(*calls)[call_node];
      AddCalles(list_of_called_flow_graphs, call_node, function_to_flow_graph, symtab, pa);
   }
}

// Let CG_INPUT be a mapping <CFG, call-list>
// Foreach control flow graph, CFG,
//    Get a list, L, of function call nodes in CFG
//    Associate CFG to a call-list
static void
PrepareCallGraph(vector <CFlowGraph*> *flow_graphs, map <CFlowGraph*, map <CFlowGraphNode*, list <CFlowGraph*> > > *cg_input, const CSymTabBase *symtab, const CSteensgaardPA &pa)
{
   // Set up a mapping from functions to flowgraphs.
   map <CGenericFunction*, CFlowGraph*> function_to_flow_graph;
   FunctionToFlowGraph(flow_graphs, &function_to_flow_graph);

   // The just created mapping will be useful to set up a new mapping from functions to
   // a collection of calls in that function.
   for (vector <CFlowGraph*>::iterator cfg_it=flow_graphs->begin(); cfg_it!=flow_graphs->end(); cfg_it++) {
      CFlowGraph *calling_flow_graph = *cfg_it;
      vector <CFlowGraphNode*> call_nodes;
      CollectCallNodes(calling_flow_graph, &call_nodes);
      AssociateCallList(&(*cg_input)[calling_flow_graph], &call_nodes, &function_to_flow_graph, symtab, pa);
   }
}

static void
BuildCallGraph(CCallGraph *call_graph, map <CFlowGraph*, map <CFlowGraphNode*, list <CFlowGraph*> > > *cg_input)
{
   // Create an empty graph, and a mapping
   map <CFlowGraph*, CCallGraphNode*> flow_graph_to_call_graph_node;

   // Add the nodes
   // Wrap the CFGs into call graph nodes and add these to the call graph
   for (map <CFlowGraph*, map <CFlowGraphNode*, list <CFlowGraph*> > >::iterator it = cg_input->begin(); it != cg_input->end(); it++) {
      CFlowGraph *flow_graph = it->first;
      CCallGraphNode *call_graph_node = new CCallGraphNode(flow_graph);
      call_graph->AddNode(call_graph_node);
      // We will need this mapping in a while (when adding the edges)
      flow_graph_to_call_graph_node[flow_graph] = call_graph_node;
   }

   // Add the edges
   // Note that a single call may result in more than one edge if a function pointer is used
   for (map <CFlowGraph*, map <CFlowGraphNode*, list<CFlowGraph*> > >::iterator it=cg_input->begin(); it!=cg_input->end(); it++) {
      // Unpack the pair of the current element
      CFlowGraph *caller_function = it->first;
      map <CFlowGraphNode*, list<CFlowGraph*> > *calls = &it->second;

      // Retrieve the corresponding call graph node from the mapping
      CCallGraphNode *caller_node = flow_graph_to_call_graph_node[caller_function];

      // Add one edge for each call in this caller function
      for (map<CFlowGraphNode*, list<CFlowGraph*> >::iterator call_it=calls->begin(); call_it!=calls->end(); call_it++) {
         CFlowGraphNode *calling_stmt = call_it->first;
         list <CFlowGraph*> *callees = &call_it->second;
         // There may be more than one function in a single call due to function pointers and a pointer analysis
         // that approximates pointer values.
         for (list <CFlowGraph*>::iterator callee=callees->begin(); callee!=callees->end(); callee++) {
            CCallGraphNode *callee_node = flow_graph_to_call_graph_node[*callee];
            call_graph->AddEdge(caller_node, callee_node, new CCallGraphEdgeAnnot(calling_stmt, callees->size()>1));
         }
      }
   }
}

unique_ptr<CCallGraph>
CreateCallGraph(std::vector<CFlowGraph*> & flow_graphs, const CSymTabBase *symtab, const CSteensgaardPA &pa)
{
   // Build the call graph
   // First prepare by setting up a mapping representing the calls
   // Next translate the mapping to nodes and edges in the graph.
   map <CFlowGraph*, map <CFlowGraphNode*, list <CFlowGraph*> > > cg_input;
   PrepareCallGraph(&flow_graphs, &cg_input, symtab, pa);
   unique_ptr<CCallGraph> call_graph(new CCallGraph);
   BuildCallGraph(call_graph.get(), &cg_input);
   return call_graph;
}
