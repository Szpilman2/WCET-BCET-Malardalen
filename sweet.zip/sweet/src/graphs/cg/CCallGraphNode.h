// $Id: CCallGraphNode.h 1222 2009-10-17 20:41:00Z csg01 $

#ifndef CCALL_GRAPH_NODE_H
#define CCALL_GRAPH_NODE_H

#include "CCallGraphEdgeAnnot.h"
#include "graphs/tools/CNode.h"

class CGenericFunction;
class CFlowGraph;


class CGenericFunction;

/** @class CCallGraphNode
      A call graph node is a node that can be inserted into a call graph,
      and call graph edges can be attached to it. A call graph node represents a function.
*/
class CCallGraphNode : public CNode <CCallGraphNode, CCallGraphEdgeAnnot>
{
public:
   /** Creates a new call graph node.
      @param flow_graph A pointer to a flowgraph where nodes represents statements. The pointer
      will be stored in this call graph node and the memory pointed to will be
      own by this callgraph node.
   */
   CCallGraphNode(CFlowGraph *flow_graph) : _flow_graph(flow_graph) {}

   /** Releases all memory owned by this node as well as the memory of the node itself.
   */
   ~CCallGraphNode();

   /** @return A pointer to a new CCallGraphNode that is a copy of this node.
   */
   CCallGraphNode *Copy() const { return new CCallGraphNode(_flow_graph); }

   /** @return A pointer to a flowgraph based on statements preivously attached to
      this call graph node, or NULL if there is no such flow graph attached. */
   CFlowGraph *FlowGraph() const { return _flow_graph; }

   /** @return A pointer to the function that this call graph represents or NULL if
      there is no function attached. */
   CGenericFunction * Function() const;

   /** Required for the loop detection interface
   */
   void SetHeader()      { }
private:
   CFlowGraph *_flow_graph;
};

#endif
