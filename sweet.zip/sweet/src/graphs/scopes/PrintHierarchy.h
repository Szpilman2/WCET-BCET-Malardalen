// $Id: $

#ifndef PRINT_HIERARCHY_H_INCLUDED
#define PRINT_HIERARCHY_H_INCLUDED

#include <ostream>

class CScopeGraph;
class CScope;

using namespace std;

/** Generates dot format text representing the scope hierarchy
   \param o A stream open for drawing in text mode. This is where we output the generated dot format text.
   \param id A name identifying the graph. Used as label in the dot file.
   \param start_function The name of the function of this scope. Used as an extension to the
      label in the dot file.
   \param i The level number to start with.
   \param max_levels The maximum "levels" to draw in a scope tree rooted at this scope. "level"
      here means the maximum recursion level when recursing from this scope (i.e. the number of
      tree levels in a tree formed scope graph).
   */
void GenerateScopeTreeHierarchyAsDot(std::ostream &o, std::string id, CScopeGraph *scope_graph, 
                                     bool label_as_tool_tip=true, CScope *scope=NULL, unsigned levels_to_show=0xffffffff);

#endif
