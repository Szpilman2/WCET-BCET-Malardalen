// $Id: CDJEdge.h 327 2009-05-06 08:55:06Z msl01 $

#ifndef CDJEDGE_H_
#define CDJEDGE_H_

#include <iostream>

typedef enum {EDGE_D, EDGE_CJ, EDGE_BJ, EDGE_J} t_edge;

template <typename T_Sub_Node> class CDJNode;

template <typename T_Sub_Node>
class CDJEdge
{
private:
   CDJNode <T_Sub_Node> *_from;
   CDJNode <T_Sub_Node> *_to;
   t_edge _type;
   bool _isspback;
public:
   CDJEdge(CDJNode <T_Sub_Node> *from, CDJNode <T_Sub_Node> *to, t_edge type);
   CDJEdge(CDJNode <T_Sub_Node> *from, CDJNode <T_Sub_Node> *to, t_edge type, bool isspback);
   virtual ~CDJEdge(void);
   bool IsRealPath(void) const;

   // Redirect the head of this edge to some other node
   void Head(CDJNode <T_Sub_Node> *newhead) { _to = newhead; }

   // Redirect the tail of this edge to some other node
   void Tail(CDJNode <T_Sub_Node> *newtail) { _from = newtail; }

   // Return the head of the edge
   CDJNode <T_Sub_Node> *Head(void) const { return _to; }

   // Return the tail of the edge
   CDJNode <T_Sub_Node> *Tail(void) const { return _from; }

   // Return the type of the edge
   t_edge Type(void) const { return _type; }

   // Assign the type of the edge
   t_edge Type(t_edge type) { return _type = type; }

   // Returns true if this is a so called sp-backedge (spanning tree back-edge)
   bool IsSpBack(void) const { return _isspback; }

   // Just for logging: prints this edge as an arrow between two sets of sub-nodes (no new lines).
   bool Print(std::ostream &o) const;
};


template <typename T_Sub_Node>
CDJEdge<T_Sub_Node>::~CDJEdge(void)
{
   _from->RemoveOutgoingEdge(this);
   _to->RemoveIncomingEdge(this);
}

template <typename T_Sub_Node>
CDJEdge<T_Sub_Node>::CDJEdge(CDJNode <T_Sub_Node> *from, CDJNode <T_Sub_Node> *to, t_edge type, bool isspback)
{
   _from = from;
   _to = to;
   _type = type;
   _isspback = isspback;
}

template <typename T_Sub_Node>
CDJEdge<T_Sub_Node>::CDJEdge(CDJNode <T_Sub_Node> *from, CDJNode <T_Sub_Node> *to, t_edge type)
{
   _from = from;
   _to = to;
   _type = type;
   _isspback = false;
}

template <typename T_Sub_Node>
bool CDJEdge<T_Sub_Node>::IsRealPath(void) const
{
   const std::set<T_Sub_Node*> *fgnodes1, *fgnodes2;
   typename std::set<T_Sub_Node*>::iterator itf;
   typename T_Sub_Node::succ_iterator itt;

   fgnodes1 = _from->FGNodes();
   fgnodes2 = _to->FGNodes();
   for (itf = fgnodes1->begin(); itf != fgnodes1->end(); itf++)
      for (itt = (*itf)->SuccBegin(); itt != (*itf)->SuccEnd(); itt++)
         if (fgnodes2->find(itt->node) != fgnodes2->end())
            return true;
   return false;
}

template <typename T_Sub_Node>
bool CDJEdge<T_Sub_Node>::Print(std::ostream &o) const
{
   _from->PrintSubNodesAsSet(o);
   o << "->";
   _to->PrintSubNodesAsSet(o);
   return 0;
}

#endif
