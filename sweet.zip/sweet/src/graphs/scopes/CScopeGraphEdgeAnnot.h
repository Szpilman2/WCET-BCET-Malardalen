// $Id: CScopeGraphEdgeAnnot.h 1023 2009-09-18 20:51:52Z csg01 $

#ifndef CSCOPE_GRAPH_EDGE_ANNOT_H_
#define CSCOPE_GRAPH_EDGE_ANNOT_H_

#include <set>
#include <cassert>
#include <vector>

class CFlowGraphNode;

/** \class CScopeGraphEdgeAnnot
      An annotation on a scope graph edge. Hold information about the class of edge.
*/
class CScopeGraphEdgeAnnot
{
public:
   /** Constructs an annotation for an edge between scopes. Calles is the call node
      in case of an edge between different functions. */
   CScopeGraphEdgeAnnot(const CFlowGraphNode *caller=NULL) : caller(caller) {}

   /** Checks if this annotation's edge represents a function call
      \return True if it does. */
   bool RepresentsFunctionCall() const { return caller != NULL; }

   /** \return A pointer to a flow graph node containing a call to the function
      represented by the scope that is the destination of the edge of this
      annotation.
      \pre \a RepresentsFunctionCall() returns true. */
   const CFlowGraphNode *FlowGraphNodeOfFunctionCall() { return caller; }

   /** \return NULL This function should not be used!
   */
   CScopeGraphEdgeAnnot *Copy()
   {
      assert("This function should not be used!"==0);
      return NULL;
   }


private:
   const CFlowGraphNode *caller;
};

#endif
