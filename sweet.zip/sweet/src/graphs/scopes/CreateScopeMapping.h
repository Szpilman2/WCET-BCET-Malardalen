// $Id: CreateScopeMapping.h 327 2009-05-06 08:55:06Z msl01 $

#ifndef CREATESCOPEMAPPING_H_
#define CREATESCOPEMAPPING_H_

#include <map>

class CScopeGraph;
class CScope;

// Creates a mapping from the scopes in `from' to corresponding scopes in `to'. It is required that `from' has
// a subset of basic blocks of those in `to'.
void CreateScopeMapping(CScopeGraph *from, CScopeGraph *to, std::map<CScope*, CScope*> *from_to_map);

#endif
