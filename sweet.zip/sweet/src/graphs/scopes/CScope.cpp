// $Id: CScope.cpp 7975 2018-11-23 15:24:04Z lkg02 $

#include "program/CGenericStmt.h"
#include "CScope.h"
#include "../tools/CNode.inl"
#include "program/CGenericFunction.h"
#include "CScopeGraph.h"
#include "CreateScopes.h"
#include "flow_facts/CFlowFact.h"
#include "flow_facts/CConstraint.h"
#include "flow_facts/CExpression.h"
#include "flow_facts/CFFCollector.h"
#include "flow_facts/CLocator.h"
#include "flow_facts/CExpression.h"
#include "graphs/components/CComponent.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/cfg/CFlowGraph.h"
#include "graphs/ecfg/CECFG.h"
#include "graphs/ecfg/CECFGNode.h"
#include "graphs/cg/CCallGraphNode.h"
#include "globals.h"
#include "macros.h"
#include <cassert>
#include <ctime>
#include <ciso646>
#include <cstdio>
#include <limits.h>

using namespace std;

template class CNode <CScope, CScopeGraphEdgeAnnot>;

CScope *
CScope::
Copy()
{
  assert("This function should not be used!"==0);
  return NULL;
}

// Assign a pointer to each ecfg node (i.e. just an "up-pointer").
void
CScope::
AssignScopeToECFGNodes(CComponent<CFlowGraphNode> *component, CScope *scope, vector <CECFGNode*> *cfg_to_ecfg_map)
{
   
   for (CComponent<CFlowGraphNode>::subnode_iterator cfg_node=component->SubNodeBegin(); cfg_node!=component->SubNodeEnd(); cfg_node++) {
      CECFGNode *ecfg_node = (*cfg_to_ecfg_map)[(*cfg_node)->Id()];
      ecfg_node->SetScope(scope);
   }

}

void
CScope::
ExtendWithMututalRecursiveFunction(CComponent<CFlowGraphNode> *component, vector <CECFGNode*> *cfg_to_ecfg_map,
                                                CGenericFunction *function)
{
   
   _type = MUTUAL_RECURSIVE_FUNCTIONS;
   _name = _name + "_" + function->PrettifiedName();
   for (CComponent<CFlowGraphNode>::subnode_iterator cfg_node=component->SubNodeBegin(); cfg_node!=component->SubNodeEnd(); cfg_node++) {
      CECFGNode *ecfg_node = (*cfg_to_ecfg_map)[(*cfg_node)->Id()];
      AddECFGNode(ecfg_node);
   }

   AssignScopeToECFGNodes(component, this, cfg_to_ecfg_map);

}

// Common initialiser for the various constructors
void
CScope::
InitScope(t_scopetype type,
                       string name,
                       CComponent<CFlowGraphNode> *component,
                       CScopeGraph *scope_graph,
                       CCallGraphNode *call_graph_node,
                       CScope *enclosing_function_scope,
                       vector <CECFGNode*> *cfg_to_ecfg_map,
                       list <pair<CECFGNode*, CECFGNode*> > *pending_edges,
                       CECFGNode *calling_node)
{
   
   _type = type;
   _name = name;
   _component = component;
   _scope_graph = scope_graph;
   _call_graph_node = call_graph_node;
   _enclosing_function_scope = enclosing_function_scope;
   _pending_edges = pending_edges;
   _header = (*cfg_to_ecfg_map)[component->Head()->Id()];
   _iteration_count = INVALID_ITER_COUNT;
   _calling_node = calling_node;

   // Add stuff needed by the scope: header, backedges, internal nodes...
   for (CComponent<CFlowGraphNode>::subnode_iterator cfg_node=component->SubNodeBegin(); cfg_node!=component->SubNodeEnd(); cfg_node++) {
      CECFGNode *ecfg_node = (*cfg_to_ecfg_map)[(*cfg_node)->Id()];
      AddECFGNode(ecfg_node);
   }

   for (CComponent<CFlowGraphNode>::backedge_iterator back_edge=component->BackedgeBegin(); back_edge!=component->BackedgeEnd(); back_edge++) {
      CECFGNode *from = (*cfg_to_ecfg_map)[back_edge->first->Id()];
      CECFGNode *to = (*cfg_to_ecfg_map)[back_edge->second->Id()];
      AddBackedge(from, to);
   }

   AssignScopeToECFGNodes(component, this, cfg_to_ecfg_map);

}

// Constructor for a function scope
// The mysterious cfg_to_ecfg_map is a mapping from basic blocks to corresponding ecfg-nodes. It covers the entire scc-tree of
// the current function.
CScope::
CScope(CComponent<CFlowGraphNode> *component, CCallGraphNode *call_graph_node, vector <CECFGNode*> *cfg_to_ecfg_map,
               list <pair<CECFGNode*, CECFGNode*> > *pending_edges, CScope *parent, CECFGNode *calling_node,
               CScopeGraph *scope_graph) {
   
   CGenericFunction *function = call_graph_node->Function();

   // Generate a name
   string name;
   if (parent) {
      // We have to add a suffix to make it unique, in case there are more than one function called in the same scope.
      char buf[100];
      int unique_function_counter = scope_graph->UniqueCallNumber(call_graph_node);
      sprintf(buf, "%d", unique_function_counter);
      name = parent->Name() + "_" + function->PrettifiedName() + buf;
   } else {
      name = function->PrettifiedName();
   }
   InitScope(FUNCTION, name, component, scope_graph, call_graph_node, this, cfg_to_ecfg_map, pending_edges, calling_node);
   _entry_node = (*cfg_to_ecfg_map)[call_graph_node->FlowGraph()->GetEntry()->Id()];

}

// Constructor for a loop scope
CScope::
CScope(CComponent<CFlowGraphNode> *component, vector <CECFGNode*> *cfg_to_ecfg_map, CScope *parent, int number)
{
   
   // Assign a name that is the name of the parent and the number passed
   char buf[100];
   sprintf(buf, "_L%d", number);

   InitScope(LOOP, parent->Name() + buf, component, parent->ScopeGraph(), parent->CallGraphNode(), parent->FunctionScope(), cfg_to_ecfg_map,
             parent->_pending_edges);
   _entry_node = _header;

}

CScope::
CScope(CComponent<CFlowGraphNode> *component, CCallGraphNode *call_graph_node, CScopeGraph *scope_graph) :
  _type(FUNCTION),
  _component(component),
  _call_graph_node(call_graph_node),
  _scope_graph(scope_graph),
  _function(call_graph_node->Function()),
  _enclosing_function_scope(this),
  _pending_edges(NULL),
  _header(NULL),
  _entry_node(NULL),
  _iteration_count(INVALID_ITER_COUNT),
  _calling_node(NULL)
  //      _collector_ip(NULL)
{
    // Do nothing
}

CScope::
CScope(CComponent<CFlowGraphNode> *component, CScope *parent) :
  _type(LOOP),
  _component(component),
  _call_graph_node(parent->_call_graph_node),
  _scope_graph(parent->_scope_graph),
  _function(parent->_function),
  _enclosing_function_scope(parent->_enclosing_function_scope),
  _pending_edges(NULL),
  _header(NULL),
  _entry_node(NULL),
  _iteration_count(INVALID_ITER_COUNT),
  _calling_node(NULL)
  // _collector_ip(NULL)
{
  // Do nothing
}

void
CScope::
GetCallString(vector <const CECFGNode*> &call_string)
{
   CScope *current = this;
   while (current->ParentScope()) {
      if (current->_calling_node) {
         call_string.push_back(current->_calling_node);
      }
      current = current->ParentScope();
   }
}

unsigned
CScope::
GetGlobalLoopCount()
{
   unsigned n = Type() == LOOP;
   for (succ_iterator kid=SuccBegin(); kid != SuccEnd(); kid++) {
      n += kid->node->GetGlobalLoopCount();
   }
   return n;
}

unsigned
CScope::
GetGlobalMaxLoopNesting()
{
   unsigned x;
   unsigned n = 0;
   for (succ_iterator kid=SuccBegin(); kid != SuccEnd(); kid++) {
      x = kid->node->GetGlobalMaxLoopNesting();
      if (x > n) {
         n = x;
      }
   }
   n += Type() == LOOP;
   return n;
}

unsigned
CScope::
GetGlobalMaxNesting()
{
   unsigned x;
   unsigned n = 0;
   for (succ_iterator kid=SuccBegin(); kid != SuccEnd(); kid++) {
      x = kid->node->GetGlobalMaxNesting();
      if (x > n) {
         n = x;
      }
   }
   n++;
   return n;
}

void
CScope::
BackEdges(std::set<std::pair<CECFGNode *, CECFGNode *> > * back_edges)
{
  for (CScope::t_backedge_iterator be=BackedgeBegin(); be!=BackedgeEnd(); be++) {
    back_edges->insert(*be);
  }
}

void
CScope::
AddExitEdge(CECFGNode *from, CECFGNode *to)
{
   _exit_edges.push_back(std::pair<CECFGNode *, CECFGNode *> (from, to));
}

void
CScope::
AddBackedge(CECFGNode *from, CECFGNode *to)
{
   _back_edges.push_back(make_pair(from, to));
}

CGenericFunction *
CScope::
Function()
{
   return CallGraphNode()->Function();
}

// Will expand all "pending edges", i.e. all function calls and returns with the respective tree, this will be done down all leafs in the tree
void
CScope::
CompletelyExpandScopeTreesOfPendingEdges(CCallGraph *call_graph, const CSymTabBase *symtab, const CSteensgaardPA &pa) {

   
   for (list <pair<CECFGNode*,CECFGNode*> >::iterator pending_edge=_pending_edges->begin(); pending_edge!=_pending_edges->end(); pending_edge++) {

      CECFGNode *ecfg_calling_node = pending_edge->first;
      CECFGNode *ecfg_return_to_node = pending_edge->second;
      CFlowGraphNode *cfg_call_node = ecfg_calling_node->GetFlowGraphNode();

      CGenericStmtCall *call_stmt = dynamic_cast<CGenericStmtCall*>(cfg_call_node->Stmt());
      assert(call_stmt);
      list <CGenericFunction*> called_functions;
      call_stmt->CalledFunctions(&called_functions, symtab, pa);

      for (list <CGenericFunction*>::iterator func_it=called_functions.begin(); func_it!=called_functions.end(); func_it++) {

         CGenericFunction *called_function = *func_it;
         CreateScopes::ExpandContextSensitive(_scope_graph, call_graph, called_function, ecfg_calling_node, ecfg_return_to_node, symtab, pa);
      }
   }
   _pending_edges->clear();

}

CScope::
~CScope(void) {
   
   if (Type() != LOOP && _pending_edges) {
      delete _pending_edges;
   }
   // delete _collector_ip;

}

bool
CScope::
IsRoot(void) {
   
   bool is_root = this == ScopeGraph()->Root();

   return is_root;
}

int 
CScope::
IterationCount(void)
{
  return _iteration_count;
}

void
CScope::
SetIterationCount(int new_iteration_count)
{
  if(HasValidIterationCount()) {
    if(_iteration_count > new_iteration_count)
      _iteration_count = new_iteration_count;
  }
  else {
    _iteration_count = new_iteration_count;
  }
}

void
CScope::
AddFlowFact(CFlowFact &ff) {
   
   _flow_fact.insert(ff);

}

void
CScope::
RemoveFlowFact(CFlowFact &ff) {
   
   set<CFlowFact> ::iterator it;
   for (it=_flow_fact.begin(); it!=_flow_fact.end(); it++) {
      if (ff == *it) {
         _flow_fact.erase(it);
         break;
      }
   }

}

// void
// CScope::
// AddAndMergeFlowFact(CFlowFact &ff) {
//    
//    set<CFlowFact> ::iterator it;
//    for (it=_flow_fact.begin(); it!=_flow_fact.end(); it++) {
//       if (ff == *it) {
//          CConstraint c = it->MergeConstraints(&ff);
//          _flow_fact.insert(CFlowFact(this, ff.Type(), *ff.Collector(),  c));
//          _flow_fact.erase(it);
//          break;
//       }
//    }
//    _flow_fact.insert(ff);
// 
// }

// Returns true if 'other' is ancestor to the current scope
bool
CScope::
HasAncestor(CScope *other) {
   
   bool has_ancestor = false;
   if (other==this) {
      has_ancestor = true;
   } else if (PredSize() > 0) {
      for (pred_iterator pred=PredBegin(); pred!=PredEnd(); pred++) {
         if ((*pred)->HasAncestor(other)) {
            has_ancestor = true;
            break;
         }
      }
   }

   return has_ancestor;
}

// Returns true if current is an ancestor of argument scope
bool
CScope::
IsAncestorOf(CScope *arg)
{
  return arg->HasAncestor(this);
}

CScope *
CScope::
ParentScope(void)
{
   assert(PredSize() <= 1);
   CScope *parent = NULL;
   if (PredSize() == 1) {
      parent = *PredBegin();
   }
   return parent;
}

// Returns true if current is a (direct) parent of argument scope
bool
CScope::
IsParentOf(CScope *arg)
{
  return (arg->ParentScope() == this);
}

void
CScope::
ChildScopes(set<CScope *> * subscopes)
{
   succ_iterator it;   for(it = SuccBegin(); it != SuccEnd(); it++) {
      CScope * scope = it->node;
      subscopes->insert(scope);
   }
}

void
CScope::
DescendantScopes(set<CScope *> * scopes)
{
   // Go through all subscopes and add their siblings
   succ_iterator it;
   for (it = SuccBegin(); it != SuccEnd(); it++) {
      // Get the subscope
      CScope * subscope = it->node;
      // Insert the scope
      scopes->insert(subscope);
      // Call the function recursively to get the scopes one level down
      subscope->DescendantScopes(scopes);
   }
}

void
CScope::
DescendantScopesList(list<CScope *> * scopes)
{
   // Go through all subscopes and add their siblings
   succ_iterator it;
   for (it = SuccBegin(); it != SuccEnd(); it++) {
      // Get the subscope
      CScope * subscope = it->node;
      // Insert the scope
      scopes->push_back(subscope);
      // Call the function recursively to get the scopes one level down
      subscope->DescendantScopesList(scopes);
   }
}

CScope * 
CScope::
LoopNestRootScope(void)
{
  if(!IsLoopScope()) {
    return NULL;
  }
  else {
    // We are within a loop nest consisting of one or more scopes. Loop 
    // upwards until we reach a scope which is not a loop scope.
    CScope * walker = this;
    while(walker->ParentScope() && walker->ParentScope()->IsLoopScope()) {
      walker = walker->ParentScope();
    }
    return walker;
  }
}

bool
CScope::
IsLoopNestRootScope(void)
{
  return (this == LoopNestRootScope());
}

int
CScope::
LoopNestingLevel(void) {
   
   int level = 0;
   if (_type == LOOP) {
      CScope *parent = ParentScope();
      if (parent) {
         level = parent->LoopNestingLevel() + 1;
      } else {
         level = 1;
      }
   }

   return level;
}

int
CScope::
LoopNestingDistance(CScope *other) {
   
   int d1 = LoopNestingLevel();
   int d2 = other->LoopNestingLevel();
   int distance;
   if (HasAncestor(other) || other->HasAncestor(this)) {
      distance = d1 - d2;
   } else {
      distance = 0;
   }

   return distance;
}

int
CScope::
LoopLevelDifference(CScope *other) {
   
   int level_diff = LoopNestingLevel() - other->LoopNestingLevel();

   return level_diff;
}

// // Returns true if current is a loop, other is a subordinate loop scope of current and 
// // there are only loop scopes appearing inbetween the two scopes
// bool 
// CScope::
// IsSubordinateInScopesLoopNest(CScope *other)
// {
//   // Make sure that both scopes are loop scopes
//   if(!other->IsLoopScope()) return false;
//   if(!IsLoopScope()) return false;
//   // Make sure that current is an ancestor of other
//   if(!IsAncestorOf(other)) return false;
//   // Make sure that all intermediate scopes also are loop scopes
//   CScope * walker = other->ParentScope();
//   while(walker != this) {
//     if(!walker->IsLoopScope()) return false;
//     walker = walker->ParentScope();
//   }
//   // Ok, alles ok
//   return true;
// }
  
bool
CScope::
IsTopInScopesLoopNest(void)
{
  if(IsLoopScope() && (!ParentScope() || !(ParentScope()->IsLoopScope())))
    return true;
  else 
    return false;
}


CScope *
CScope::
GetTopScopeInScopesLoopNest(void)
{
  // Make sure that the current scope is in a loop nest
  if(!IsLoopScope()) return NULL;
  // Get the top scope in the loop nest
  CScope * walker = this;
  while(walker->ParentScope() && walker->ParentScope()->IsLoopScope()) {
    walker = walker->ParentScope();
  }
  return walker;
}


void
CScope::
Edges(set< pair<CECFGNode *, CECFGNode *> > *edges)
{
   
   for(CScope::ecfg_nodes_iterator node=ECFGNodesBegin(); node!=ECFGNodesEnd(); node++) {
      for(CECFGNode::succ_iterator succ=(*node)->SuccBegin(); succ!=(*node)->SuccEnd(); succ++) {
         edges->insert(make_pair(*node,succ->node));
      }
   }

}

// To get all exit edges in the scope in a set
void
CScope::
ExitEdges(set< pair<CECFGNode *, CECFGNode *> > *exit_edges)
{
   
   t_exitedge_iterator exit_edge;
   FORALL(exit_edge, _exit_edges) {
      exit_edges->insert(*exit_edge);
   }

}

// Get exit edges starting in current scope but not going to scopes
// for which the current is an ancestor.
void
CScope::
ExitEdgesToSurroundingScopes(set<pair<CECFGNode *, CECFGNode *> > * exit_edges_to_outer_scopes)
{
   
   // Loop through all exit edges
   t_exitedge_iterator exit_edge;
   FORALL(exit_edge, _exit_edges) {
      // Get the target scope of the exit edge
      CScope * target_scope = ((*exit_edge).second)->Scope();
      // Check if the target scope has _scope as an ancestor
      if (!(target_scope->HasAncestor(this)))
              // Nope, then the edge goes to an outer scope
                exit_edges_to_outer_scopes->insert(*exit_edge);
      }

}

// Get number of exit edges starting in current scope but not going to
// scopes for which the current is an ancestor.
int
CScope::
NrOfExitEdgesToSurroundingScopes(void)
{
   
   set<pair<CECFGNode *, CECFGNode *> > exit_edges_to_outer_scopes;
   ExitEdgesToSurroundingScopes(&exit_edges_to_outer_scopes);
   int size = (int)exit_edges_to_outer_scopes.size();

   return size;
}

//  // Get exit edges starting in current scope but not going to scopes
//  // for which the scope is an ancestor (exit edges to s are not included)
//  void CScope::ExitEdgesToSurroundingScopesWrtAnotherScope(set<pair<CECFGNode *, CECFGNode *> > *exit_edges_to_outer_scopes, CScope *s)
//  {
//     
//     // Loop through all exit edges
//     t_exitedge_iterator exit_edge;
//     FORALL(exit_edge, _exit_edges) {
//       // Get the target scope of the exit edge
//       CScope * target_scope = ((*exit_edge).second)->Scope();
//       // Check if the target scope has scope s as an ancestor
//       if (!(target_scope->HasAncestor(s)))
//         // Nope, then the edge goes to an outer scope
//         exit_edges_to_outer_scopes->insert(*exit_edge);
//     }
//  
//  }

// Get exit edges starting in current or subordinate scopes but not
// going to scopes for which the current is an ancestor
void
CScope::
ExitEdgesInclSubScopesToSurroundingScopes(set<pair<CECFGNode *, CECFGNode *> > * exit_edges)
{
   
   // Get all the subordiate scopes of the current scope including siblings
   set<CScope *> scopes;
   DescendantScopes(&scopes);

   // Add the current scope to the set
   scopes.insert(this);

   // Loop through all these scopes
   set<CScope *>::iterator scope;
   FORALL(scope, scopes) {
      // Get the exit edges of the current scope
      set<pair<CECFGNode *, CECFGNode *> > scope_exit_edges;
      (*scope)->ExitEdges(&scope_exit_edges);

      // Loop through all exit edges
      set<pair<CECFGNode *, CECFGNode *> >::iterator scope_exit_edge;
      FORALL(scope_exit_edge, scope_exit_edges) {
              // Get the target scope of the exit edge
              CScope * target_scope = ((*scope_exit_edge).second)->Scope();
              // Check if the target scope has this scope as an ancestor
              if(!(target_scope->HasAncestor(this))) {
                 // Nope, then the edge goes to an outer scope
                 exit_edges->insert(*scope_exit_edge);
              }
           }
   }

}

// Get number of exit edges starting in current or subordinate scopes
// but not going to scopes for which the current is an ancestor
int
CScope::
NrOfExitEdgesInclSubScopesToSurroundingScopes(void)
{
   
   set<pair<CECFGNode *, CECFGNode *> > exit_edges;
   ExitEdgesInclSubScopesToSurroundingScopes(&exit_edges);
   int size = (int)exit_edges.size();

   return size;
}

void
CScope::
ExitEdgesInclSubScopesToOtherSubScopesWrtAnotherScope(set<pair<CECFGNode *, CECFGNode *> > *exit_edges, CScope * s)
{
  

  // Get all the exit edges coming from current scope or sibling of current scope
  // which do not end in current or in sibling of current
  set<pair<CECFGNode *, CECFGNode *> > current_and_sibling_exit_edges;
  ExitEdgesInclSubScopesToSurroundingScopes(&current_and_sibling_exit_edges);

  // Loop through all these edges. Extract all those edges which do not end
  // in s but which have s as an ancestor
  set<pair<CECFGNode *, CECFGNode *> >::iterator current_and_sibling_exit_edge;
  FORALL(current_and_sibling_exit_edge, current_and_sibling_exit_edges)
    {
      // Get the target scope of the exit edge
      CScope * to_scope = ((*current_and_sibling_exit_edge).second)->Scope();

      // Do the check for an alternative subscope
      if((to_scope != s) && s->IsAncestorOf(to_scope))
        {
          // Yes, add the exit edge to the set to return
          exit_edges->insert(*current_and_sibling_exit_edge);
        }
    }

  // We are done, the set has been updated
  return;
}

// Given a subscope sub of the current scope (this) get the
// subscopes or sibling scopes reachable (directly or in several
// steps) through exitedges of the subscope or its sibling scopes
// (including sub and its sibling scopes).
void
CScope::
SubScopesToCurrentScopeReachableFromSubScope(set<CScope*> * reachable_subscopes,
                                                  CScope * sub)
{
  // Create a set of subscopes to test
  set<CScope *> subscopes_to_test;
  subscopes_to_test.insert(sub);

  // Create a set of subscopes that already have been tested
  set<CScope *> tested_subscopes;

  // Do while there are more subscopes to test
  set<CScope *>::iterator subscope;
  while(!(subscopes_to_test.empty()))
    {
      // Pop a subscope
      set<CScope *>::iterator subscope_it = subscopes_to_test.begin();
      CScope * subscope = *(subscope_it);
      subscopes_to_test.erase(subscope_it);

      // Add all the reachable siblings from subscope including subscope
      subscope->DescendantScopes(reachable_subscopes);
      reachable_subscopes->insert(subscope);

      // Get the exitedges going to other subscopes of current from sub
      set<pair<CECFGNode *, CECFGNode *> > exit_edges;
      subscope->ExitEdgesInclSubScopesToOtherSubScopesWrtAnotherScope(&exit_edges,
                                                                      this);

      // Go through the target scopes of the exit edges
      set<pair<CECFGNode *, CECFGNode *> >::iterator exit_edge;
      FORALL(exit_edge, exit_edges)
        {
          // Get the subscope that the edge goes to
          CScope * target_subscope = ((*exit_edge).second)->Scope();

          // Make sure that it is a direct subscope of current
          // (siblings are not allowed at the moment)
          assert(IsParentOf(target_subscope));

          // Check if the target_subscope is among the set of tested subscope
          if(tested_subscopes.find(target_subscope) == tested_subscopes.end())
            {
              // Nope, add it to the set of subscopes_to_test (since
              // we are using a set we do not need to check if it is
              // already added)
              subscopes_to_test.insert(target_subscope);
            }
        }

      // Remember that we have tested the subscope
      tested_subscopes.insert(subscope);
    }

  // Return (the set of reachable subscopes has been update)
  return;
}

// To get all the exit edges from a set of scopes which goes to current scope
void
CScope::
ExitEdgesToCurrentScope(set<pair<CECFGNode *, CECFGNode *> > *exit_edges_to_current,
                       set<CScope*> * scopes)
{
  // Loop through all the scopes
  set<CScope*>::iterator scope;
  FORALL(scope, (*scopes))
    {
      // Get all the exit edges of the scope
      set<pair<CECFGNode *, CECFGNode *> > exit_edges;
      (*scope)->ExitEdges(&exit_edges);

      // Loop through all exit edges
      set<pair<CECFGNode *, CECFGNode *> >::iterator exit_edge;
      FORALL(exit_edge, exit_edges)
        {
          // Get the scope that the edge goes to
          CScope * target_scope = ((*exit_edge).second)->Scope();

          // Check if this scope is the same as current scope
          if(target_scope == this)
            {
              // Yes, add the edge
              exit_edges_to_current->insert(*exit_edge);
            }
        }
    }
  // Return, the set of exit edges is updated
  return;
}

// To get all the exit edges from a set of scopes which goes to
// a surrounding scope of current scope
void CScope::
ExitEdgesToSurroundingScopes(set<pair<CECFGNode *, CECFGNode *> > *exit_edges_to_outer,
                             set<CScope*> * scopes)
{
  // Loop through all the scopes
  set<CScope*>::iterator scope;
  FORALL(scope, (*scopes))
    {
      // Get all the exit edges of the scope
      set<pair<CECFGNode *, CECFGNode *> > exit_edges;
      (*scope)->ExitEdges(&exit_edges);

      // Loop through all exit edges
      set<pair<CECFGNode *, CECFGNode *> >::iterator exit_edge;
      FORALL(exit_edge, exit_edges)
        {
          // Get the scope that the edge goes to
          CScope * target_scope = ((*exit_edge).second)->Scope();

          // If it is the current scope so skip the edge
          if(this == target_scope)
            continue;

          // If the current scope is an ancestor of the targert scope so skip it
          else if(IsAncestorOf(target_scope))
            continue;

          // Else, add the edge
          else
            exit_edges_to_outer->insert(*exit_edge);
        }
    }
  // The set of exit edges has been updated, return
  return;
}

// Get the exit edges starting in current scope and going to a
// subordinate scope (direct or sibling)
void
CScope::
ExitEdgesToSubScopes(set<pair<CECFGNode *, CECFGNode *> > * exit_edges_to_subscopes)
{
   
   // Loop through all exit edges of current scope
   t_exitedge_iterator exit_edge;
   FORALL(exit_edge, _exit_edges) {
      // Get the target scope of the exit edge
      CScope * target_scope = ((*exit_edge).second)->Scope();
      // Check if the target scope has _scope as an ancestor
      if(target_scope->HasAncestor(this)) {
        // Yes, then the edge goes to a subordinate scope
        exit_edges_to_subscopes->insert(*exit_edge);
      }
   }

}

// Get the number of exit edges starting in current scope and going to
// a subordinate scope (direct or sibling)
int
CScope::
NrOfExitEdgesToSubScopes(void)
{
   
   set<pair<CECFGNode *, CECFGNode *> > exit_edges;
   ExitEdgesToSubScopes(&exit_edges);
   int size = (int)exit_edges.size();

   return size;
}

// If this is not the root scope, then it is easy: we will find it by just scanning the exit edges to see which leads to
// the parent scope (or some scope in case of DAG), which is O(nr-of-top-level-loops*number-of-preds)
// In case of root we don't have any exit edges, so we ask the flow_graph for the return node.
// Then we need to scan the ECFG-nodes to find which points to the basic block...
CECFGNode *
CScope::
ReturnNode(void)
{
   
   CECFGNode *return_node = NULL;
   if (IsRoot()) {
      CFlowGraph *flow_graph = CallGraphNode()->FlowGraph();
      CFlowGraphNode *basic_block = flow_graph->ExitNode();
      for (ecfg_nodes_iterator node=ECFGNodesBegin(); node!=ECFGNodesEnd(); node++) {
         if ((*node)->GetFlowGraphNode() == basic_block) {
            return_node = *node;
            break;
         }
      }
   } else {
      for (t_exitedge_iterator it=ExitEdgesBegin(); it!=ExitEdgesEnd() && !return_node; it++) {
         for (pred_iterator pred=PredBegin(); pred!=PredEnd(); pred++) {
            if (it->second->Scope() == *pred) {
               return_node = it->first;
               break;
            }
         }
      }
   }

   return return_node;
}

CECFGNode *
CScope::
ResultNode(CECFGNode *call_node)
{
   
   CECFGNode *result_node = NULL;
   if (call_node->GetFlowGraphNode()->SuccBegin() != call_node->GetFlowGraphNode()->SuccEnd()) {
      result_node = ECFGNodeOfFlowGraphNode(call_node->GetFlowGraphNode()->SuccBegin()->node);
   }
   assert(result_node);

   return result_node;
}

void
CScope::
PrintTCD(ostream &o)
{
   
   for (ecfg_nodes_iterator node=ECFGNodesBegin(); node!=ECFGNodesEnd(); node++) {
      (*node)->PrintTCD(o);
   }
   for (succ_iterator kid=SuccBegin(); kid != SuccEnd(); kid++) {
      kid->node->PrintTCD(o);
   }

}

void
CScope::
Reachable(set <CScope *> *scopes)
{
   
   scopes->insert(this);
   for (CScope::succ_iterator subscope = SuccBegin(); subscope != SuccEnd(); subscope++) {
      subscope->node->Reachable(scopes);
   }

}

CECFGNode *
CScope::
ECFGNodeOfFlowGraphNode(CFlowGraphNode *basic_block) const
{
   
   CECFGNode *node = NULL;
   for (ecfg_nodes_iterator node_it=ECFGNodesBegin(); node_it!=ECFGNodesEnd(); node_it++) {
      if ((*node_it)->GetFlowGraphNode() == basic_block) {
         node = *node_it;
         break;
      }
   }

   return node;
}

//----------------------------------
// To get the nodes in the current scope
//---------------------------------
void
CScope::
NodesInScope(set<CECFGNode *> * nodes_to_consider)
{
  // Loop through all the nodes in the scope
  CScope::ecfg_nodes_iterator node;
  for(node=this->ECFGNodesBegin(); node!=this->ECFGNodesEnd(); node++)
    {
      // Add the node to the set
      nodes_to_consider->insert(*node);
    }
  // We are done the node set been updated
  return;
}

//----------------------------------
// To get the nodes in the current scope
//---------------------------------
void
CScope::
NodesInScopeExceptHeader(set<CECFGNode *> * nodes_to_consider)
{
  // Loop through all the nodes in the scope
  CScope::ecfg_nodes_iterator node;
  for(node=this->ECFGNodesBegin(); node!=this->ECFGNodesEnd(); node++)
    {
      // Skip count variable for the header node
      if(*node == this->Header()) continue;

      // Add the node to the set
      nodes_to_consider->insert(*node);
    }
  // We are done the node set been updated
  return;
}

//----------------------------------
// To get the nodes in the current scope and its subscopes
// Except the current header.
//---------------------------------
void
CScope::
NodesInScopeAndSubScopes(set<CECFGNode *> * nodes_to_consider)
{
  // Add all the nodes in the current scope (except the header)
  NodesInScope(nodes_to_consider);

  // Loop through all nodes in all subscopes
  CScope::succ_iterator succ;
  for(succ = this->SuccBegin(); succ != this->SuccEnd(); succ++)
    {
      CScope * subscope = succ->node;
      // Call the recursive function
      NodesInScopeAndSubScopes(nodes_to_consider, subscope);
    }
  // We are done the node set been updated
  return;
}

//----------------------------------
// To get the nodes in the current scope and its subscopes
// Except the current header.
//---------------------------------
void
CScope::
NodesInScopeExceptHeaderAndSubScopes(set<CECFGNode *> * nodes_to_consider)
{
  // Add all the nodes in the current scope (except the header)
  NodesInScopeExceptHeader(nodes_to_consider);

  // Loop through all nodes in all subscopes
  CScope::succ_iterator succ;
  for(succ = this->SuccBegin(); succ != this->SuccEnd(); succ++)
    {
      CScope * subscope = succ->node;
      // Call the recursive function
      NodesInScopeAndSubScopes(nodes_to_consider, subscope);
    }
  // We are done the node set been updated
  return;
}


//----------------------------------
// To get the nodes in the current scope and its subscopes
//---------------------------------
void
CScope::
NodesInScopeAndSubScopes(set<CECFGNode *> * nodes_to_consider, CScope * scope)
{
  // Loop through all the nodes in the scope
  CScope::ecfg_nodes_iterator node;
  for(node=scope->ECFGNodesBegin(); node!=scope->ECFGNodesEnd(); node++)
    {
      // Add the node to the set
      nodes_to_consider->insert(*node);
    }
  // Loop through all nodes in all subscopes
  CScope::succ_iterator succ;
  for(succ = scope->SuccBegin(); succ != scope->SuccEnd(); succ++)
    {
      CScope * subscope = succ->node;
      // Call the function recursively
      NodesInScopeAndSubScopes(nodes_to_consider, subscope);
    }
  // We are done the node set been updated
  return;
}

// ---------------------------------
// To get the nodes in the current scope and its direct looping subscopes
//---------------------------------
void
CScope::
NodesInScopeAndLoopSubScopes(set<CECFGNode *> * nodes_to_consider)
{
  // Add all the nodes in the current scope (except the header)
  NodesInScope(nodes_to_consider);

  // Loop through all nodes in all subscopes
  CScope::succ_iterator succ;
  for(succ = this->SuccBegin(); succ != this->SuccEnd(); succ++)
    {
      CScope * subscope = succ->node;

      // Call the function recursively if it is a loop scope
      if(subscope->Type() == CScope::LOOP)
        {
          // Call the recursive function
          NodesInScopeAndLoopSubScopes(nodes_to_consider, subscope);
        }
    }
  // We are done the node set has been updated
  return;
}


//----------------------------------
// To get the nodes in the current scope and its direct looping subscopes
//---------------------------------
void
CScope::
NodesInScopeExceptHeaderAndLoopSubScopes(set<CECFGNode *> * nodes_to_consider)
{
  // Add all the nodes in the current scope (except the header)
  NodesInScopeExceptHeader(nodes_to_consider);

  // Loop through all nodes in all subscopes
  CScope::succ_iterator succ;
  for(succ = this->SuccBegin(); succ != this->SuccEnd(); succ++)
    {
      CScope * subscope = succ->node;

      // Call the function recursively if it is a loop scope
      if(subscope->Type() == CScope::LOOP)
        {
          // Call the recursive function
          NodesInScopeAndLoopSubScopes(nodes_to_consider, subscope);
        }
    }
  // We are done the node set has been updated
  return;
}

void
CScope::
NodesInScopeAndLoopSubScopes(set<CECFGNode *> * nodes_to_consider, CScope * scope)
{
  // Loop through all the nodes in the scope
  CScope::ecfg_nodes_iterator node;
  for(node= scope->ECFGNodesBegin(); node!= scope->ECFGNodesEnd(); node++)
    {
      // Add the node to the set
      nodes_to_consider->insert(*node);
    }

  // Loop through all nodes in all subscopes
  CScope::succ_iterator succ;
  for(succ = scope->SuccBegin(); succ != scope->SuccEnd(); succ++)
    {
      // Get the subscope
      CScope * subscope = succ->node;

      // Call the function recursively if it is a loop scope
      if(subscope->Type() == CScope::LOOP)
        {
          NodesInScopeAndLoopSubScopes(nodes_to_consider, subscope);
        }
    }
  // We are done the node set has been updated
  return;
}

//----------------------------------
// To get the header node in the current scope
//---------------------------------
void
CScope::
HeaderNodeInScope(set<CECFGNode *> * nodes_to_consider)
{
  // Add the loop header node to the set
  nodes_to_consider->insert(this->Header());

  // We are done the node set been updated
  return;
}

//----------------------------------
// To get the loop header nodes in the current scope and its direct looping subscopes
//---------------------------------
void
CScope::
HeaderNodesInScopeAndLoopSubScopes(set<CECFGNode *> * nodes_to_consider)
{
  // Call the recursive function collecting all the headers of all the
  // looping subscopes (including this one)
  HeaderNodesInScopeAndLoopSubScopes(nodes_to_consider, this);
}

void
CScope::
HeaderNodesInScopeAndLoopSubScopes(set<CECFGNode *> * nodes_to_consider, CScope * scope)
{
  // Add the loop header node of the scope to the set
  nodes_to_consider->insert(scope->Header());

  // Loop through all nodes in all subscopes
  CScope::succ_iterator succ;
  for(succ = scope->SuccBegin(); succ != scope->SuccEnd(); succ++)
    {
      // Get the subscope
      CScope * subscope = succ->node;

      // Call the function recursively if it is a loop scope
      if(subscope->Type() == CScope::LOOP)
        {
          // Call the function recursively
          HeaderNodesInScopeAndLoopSubScopes(nodes_to_consider, subscope);
        }
    }
  // We are done the node set been updated
  return;
}

//----------------------------------
// To get the loop header nodes in the current scope and its subscopes
//---------------------------------
void
CScope::
HeaderNodesInScopeAndSubScopes(set<CECFGNode *> * nodes_to_consider)
{
  // Call the recursive function collecting all the headers of all the
  // looping subscopes (including this one)
  HeaderNodesInScopeAndSubScopes(nodes_to_consider, this);
}

void
CScope::
HeaderNodesInScopeAndSubScopes(set<CECFGNode *> * nodes_to_consider, CScope * scope)
{
  // Add the loop header node of the scope to the set
  nodes_to_consider->insert(scope->Header());

  // Loop through all nodes in all subscopes
  CScope::succ_iterator succ;
  for(succ = scope->SuccBegin(); succ != scope->SuccEnd(); succ++)
    {
      // Get the subscope
      CScope * subscope = succ->node;

      // Call the function recursively
      HeaderNodesInScopeAndSubScopes(nodes_to_consider, subscope);
    }
  // We are done the node set been updated
  return;
}


//----------------------------------
// To get the edges in the current scope
//---------------------------------
void
CScope::
EdgesInScope(set<pair<CECFGNode *, CECFGNode *> > * edges_to_consider)
{
  // Gete all the edges in the scope
  this->Edges(edges_to_consider);

  // We are done the edge set been updated
  return;
}

//----------------------------------
// To get the edges in the current scope and its subscopes
//---------------------------------
void
CScope::
EdgesInScopeAndSubScopes(set<pair<CECFGNode *, CECFGNode *> > * edges_to_consider)
{
  // Call the recursive function
  EdgesInScopeAndSubScopes(edges_to_consider, this);
}

void
CScope::
EdgesInScopeAndSubScopes(set<pair<CECFGNode *, CECFGNode *> > * edges_to_consider, CScope * scope)
{
  // Add all edges in the current scope
  scope->Edges(edges_to_consider);

  // Loop through all edges in all subscopes
  CScope::succ_iterator succ;
  for(succ = scope->SuccBegin(); succ != scope->SuccEnd(); succ++)
    {
      CScope * subscope = succ->node;
      // Call the function recursively
      EdgesInScopeAndSubScopes(edges_to_consider, subscope);
    }

  // We are done the edge set been updated
  return;
}

//----------------------------------
// To get the edges in the current scope and its direct looping subscopes
//---------------------------------
void
CScope::
EdgesInScopeAndLoopSubScopes(set<pair<CECFGNode *, CECFGNode *> > * edges_to_consider)
{
  // Call the recursice function
  EdgesInScopeAndLoopSubScopes(edges_to_consider, this);
}

void
CScope::
EdgesInScopeAndLoopSubScopes(set<pair<CECFGNode *, CECFGNode *> > * edges_to_consider, CScope * scope)
{
  // Add all edges in the current scope
  scope->Edges(edges_to_consider);

  // Loop through all edges in all subscopes
  CScope::succ_iterator succ;
  for(succ = scope->SuccBegin(); succ != scope->SuccEnd(); succ++)
    {
      // Get the subscope
      CScope * subscope = succ->node;

      // Call the function recursively if it is a loop scope
      if(subscope->Type() == CScope::LOOP)
        {
          EdgesInScopeAndLoopSubScopes(edges_to_consider, subscope);
        }
    }
  // We are done the edge set been updated
  return;
}

//----------------------------------
// To get the call edges in the current scope 
//---------------------------------
void
CScope::
CallEdges(std::set<pair<CECFGNode *, CECFGNode *> > * call_edges)
{
  for(CScope::t_exitedge_iterator exit_edge = ExitEdgesBegin(); exit_edge != ExitEdgesEnd(); ++exit_edge) {
    CECFGNode * to_node = (*exit_edge).second;
    // Check if the exit node goes to a function scope and if the node
    // is the header of this scope
    if((to_node->Scope()->IsFunctionScope() || to_node->Scope()->IsRecursiveFunctionScope() ||
        to_node->Scope()->IsMutualRecursiveFunctionsScope()) && 
       (to_node->Scope()->EntryNode() == to_node)) {
      call_edges->insert(*exit_edge);
    }
  }
}

//----------------------------------
// To get the call edges in the current scope and its direct looping subscopes
//---------------------------------
void
CScope::
CallEdgesInScopeAndLoopSubScopes(set<pair<CECFGNode *, CECFGNode *> > * edges_to_consider)
{
  // Call the recursice function
  CallEdgesInScopeAndLoopSubScopes(edges_to_consider, this);
}

void
CScope::
CallEdgesInScopeAndLoopSubScopes(set<pair<CECFGNode *, CECFGNode *> > * edges_to_consider, CScope * scope)
{
  // Add all call edges in the current scope
  scope->CallEdges(edges_to_consider);

  // Loop through all edges in all subscopes
  CScope::succ_iterator succ;
  for(succ = scope->SuccBegin(); succ != scope->SuccEnd(); succ++)
    {
      // Get the subscope
      CScope * subscope = succ->node;

      // Call the function recursively if it is a loop scope
      if(subscope->Type() == CScope::LOOP)
        {
          CallEdgesInScopeAndLoopSubScopes(edges_to_consider, subscope);
        }
    }
  // We are done the edge set been updated
  return;
}


//----------------------------------
// To get the call edges in the current scope and its subscopes
//---------------------------------
void
CScope::
CallEdgesInScopeAndSubScopes(set<pair<CECFGNode *, CECFGNode *> > * edges_to_consider)
{
  // Call the recursive function
  CallEdgesInScopeAndSubScopes(edges_to_consider, this);
}

void
CScope::  
CallEdgesInScopeAndSubScopes(set<pair<CECFGNode *, CECFGNode *> > * edges_to_consider, CScope * scope)
{
  // Add all exit edges in the current scope
  scope->CallEdges(edges_to_consider);

  // Loop through all edges in all subscopes
  CScope::succ_iterator succ;
  for(succ = scope->SuccBegin(); succ != scope->SuccEnd(); succ++)
    {
      CScope * subscope = succ->node;
      // Call the function recursively
      CallEdgesInScopeAndSubScopes(edges_to_consider, subscope);
    }

  // We are done the edge set been updated
  return;
}

//----------------------------------
// To get loop-body-begin-edge in the current scope 
//---------------------------------
void
CScope::
LoopBodyBeginEdgesInScope(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider, bool consider_edges_inbetween_basic_blocks)
{
  if(!IsLoopScope()) return;
  else {
    CECFGNode * header = Header();
    if(consider_edges_inbetween_basic_blocks) header = header->GetEndNodeOfNodesBasicBlockStretchingOverFalseEdges();
    for(CECFGNode::succ_iterator succ_node = header->SuccBegin(); succ_node != header->SuccEnd(); succ_node++) {
      CScope * succ_scope = succ_node->node->Scope();
      if ((succ_scope == this) || (IsAncestorOf(succ_scope))) {
        edges_to_consider->insert(std::make_pair(header,succ_node->node));
      }
    }
  }
}

//----------------------------------
// To get loop-body-begin-edge in the current scope and its direct looping subscopes
//---------------------------------
void
CScope::
LoopBodyBeginEdgesInScopeAndLoopSubScopes(std::set<std::pair<CECFGNode *, CECFGNode *> > * edges_to_consider, bool consider_edges_inbetween_basic_blocks)
{
  // Call the recursice function
  LoopBodyBeginEdgesInScopeAndLoopSubScopes(edges_to_consider, consider_edges_inbetween_basic_blocks, this);
}

void
CScope::
LoopBodyBeginEdgesInScopeAndLoopSubScopes(std::set<std::pair<CECFGNode *, CECFGNode *> > * edges_to_consider, bool consider_edges_inbetween_basic_blocks, CScope * scope)
{
  // Add all call edges in the current scope
  scope->LoopBodyBeginEdgesInScope(edges_to_consider, consider_edges_inbetween_basic_blocks);

  // Loop through all edges in all subscopes
  CScope::succ_iterator succ;
  for(succ = scope->SuccBegin(); succ != scope->SuccEnd(); succ++)
    {
      // Get the subscope
      CScope * subscope = succ->node;

      // Call the function recursively if it is a loop scope
      if(subscope->Type() == CScope::LOOP)
        {
          LoopBodyBeginEdgesInScopeAndLoopSubScopes(edges_to_consider, consider_edges_inbetween_basic_blocks, subscope);
        }
    }
  // We are done the edge set been updated
  return;
}
  
//----------------------------------
// To get the loop-body-begin-edges in the current scope and its subscopes
//---------------------------------
void
CScope::
LoopBodyBeginEdgesInScopeAndSubScopes(std::set<std::pair<CECFGNode *, CECFGNode *> > * edges_to_consider, bool consider_edges_inbetween_basic_blocks)
{
  // Call the recursive function
  LoopBodyBeginEdgesInScopeAndSubScopes(edges_to_consider, consider_edges_inbetween_basic_blocks, this);
}

void
CScope::  
LoopBodyBeginEdgesInScopeAndSubScopes(std::set<std::pair<CECFGNode *, CECFGNode *> > * edges_to_consider, bool consider_edges_inbetween_basic_blocks, CScope * scope)
{
  // Add all loop body begin edges in the current scope
  scope->LoopBodyBeginEdgesInScope(edges_to_consider, consider_edges_inbetween_basic_blocks);

  // Add all loop body begin edges in all subscopes
  CScope::succ_iterator succ;
  for(succ = scope->SuccBegin(); succ != scope->SuccEnd(); succ++)
    {
      CScope * subscope = succ->node;
      // Call the function recursively
      LoopBodyBeginEdgesInScopeAndSubScopes(edges_to_consider, consider_edges_inbetween_basic_blocks, subscope);
    }

  // We are done the edge set been updated
  return;
}

// 8<-----------------------------------------
CScope *CScope::NextScope(CFlowGraphNode *from, CFlowGraphNode *to)
{
   
   CScope *next_scope = NULL;
   CECFGNode *ecfg_node = ECFGNodeOfFlowGraphNode(from);
   assert(ecfg_node);
   for (CECFGNode::succ_iterator succ=ecfg_node->SuccBegin(); succ!=ecfg_node->SuccEnd(); succ++) {
      if (succ->node->GetFlowGraphNode() == to) {
         next_scope = succ->node->Scope();
         break;
      }
   }

   return next_scope;
}

bool CScope::IsHeader(CFlowGraphNode *basic_block)
{
   
   bool is_header;
   CECFGNode *ecfg_node = ECFGNodeOfFlowGraphNode(basic_block);
   if (ecfg_node == NULL)
      is_header = false;
   else
      is_header = IsHeader(ecfg_node);

   return is_header;
}

list <pair <CScope*, CFlowGraphNode*> > CScope::GetSuccessors(CFlowGraphNode *basic_block)
{
   
   CECFGNode *ecfg_node = ECFGNodeOfFlowGraphNode(basic_block);
   assert(ecfg_node);
   list <pair <CScope*, CFlowGraphNode*> > node_pairs;
   for (CECFGNode::succ_iterator succ=ecfg_node->SuccBegin(); succ!=ecfg_node->SuccEnd(); succ++) {
      node_pairs.push_back(make_pair(succ->node->Scope(), succ->node->GetFlowGraphNode()));
   }

   return node_pairs;
}

list <pair <CScope*, CFlowGraphNode*> > CScope::GetPredecessors(CFlowGraphNode *basic_block)
{
   
   CECFGNode *ecfg_node = ECFGNodeOfFlowGraphNode(basic_block);
   assert(ecfg_node);
   list <pair <CScope*, CFlowGraphNode*> > node_pairs;
   for (CECFGNode::pred_iterator pred=ecfg_node->PredBegin(); pred!=ecfg_node->PredEnd(); pred++) {
      node_pairs.push_back(make_pair((*pred)->Scope(), (*pred)->GetFlowGraphNode()));
   }

   return node_pairs;
}

CFlowGraphNode *CScope::HeaderNode(void)
{
   
   CFlowGraphNode *header = Header()->GetFlowGraphNode();

   return header;
}

void CScope::AllFlowGraphNodes(set<CFlowGraphNode *> *cfg_nodes)
{
   // Go through all ECFGs and collect their basic blocks
   CScope::ecfg_nodes_iterator ecfg_node;
   for(ecfg_node = ECFGNodesBegin();  ecfg_node != ECFGNodesEnd(); ecfg_node++) {
      cfg_nodes->insert((*ecfg_node)->GetFlowGraphNode());
   }
   return;
}

// 8<-----------------------------------------

void
CScope::
PrintGraphically(FILE *f, const string s, CScope * root_scope, const int max_levels, const bool reduced_scope_graph)
{
   
   fprintf(f, "digraph \"\" {\n");
   fprintf(f, "   size=\"11.4,7.8\";\n");
   fprintf(f, "   rankdir=TB;\n");
   fprintf(f, "   center=1;\n");
   fprintf(f, "   rotate=0;\n");
   fprintf(f, "   {\n");
   fprintf(f, "   node [shape=plaintext, fontsize=11];\n");
   time_t now;
   time(&now);
   string time = asctime(localtime(&now));
   time.resize(time.size()-1); // remove newline at end
   if (reduced_scope_graph) {
      fprintf(f, "   \"Reduced scope graph for %s\\n%s\\n\\n", s.c_str(), time.c_str());
      fprintf(f, "   Scopes with solid line = function scopes\\n");
      fprintf(f, "   Scopes with dotted line = loop scopes\\n");
      fprintf(f, "   Each node is a basic block\\n");
   }
   else {
      fprintf(f, "   \"Full scope graph for %s\\n%s\\n\\n", s.c_str(), time.c_str());
      fprintf(f, "   Each node is a statement\\n");
      fprintf(f, "   Green node = start statement of basic block\\n");
      fprintf(f, "   Dotted node = statement inside a basic block\\n");
      fprintf(f, "   Red node = end statement of basic block\\n");
      fprintf(f, "   Yellow node = start and end statement of basic block\\n");
   }
   fprintf(f, "   Blue node = header\\n");
   fprintf(f, "   Red edge = backedge (ring at arrow head)\\n");
   fprintf(f, "   Green edge = exit/entry edge\\n");
   fprintf(f, "   Blue edge = recursive call edge\\n");
   
   if (root_scope != this) {
      fprintf(f, "   Partial graph with root function = %s\\n", Function()->Name().c_str());
   }
   if (max_levels > 0 and max_levels != INT_MAX) {
      fprintf(f, "   Max. no. of levels = %d\n", max_levels);
      fprintf(f, "   Scopes with dashed line are marking called function scopes \\n");
   }
   
   ecfg_nodes_iterator nd=ECFGNodesBegin();
   CECFGNode *cur_node = *nd;
   string label = cur_node->GetFlowGraphNode()->PrettifiedName();

   if (label.find("alf_label_") == 0) g_removed_alf_label = true;
   if (label.find("BB") == 0) g_removed_BB = true;
   if (label.find("__bb__") != std::string::npos or label.find("__bb") != std::string::npos) g_removed__bb = true;

   if (g_removed_alf_label) fprintf(f, "\\n   In the node labels, replace '.' with \\n'alf_label_' \\nto get the label in the ALF file. \\n");
   if (g_removed_BB) fprintf(f, "\\n   In the node labels, replace '.' with \\n'BB' \\nto get the label in the ALF file. \\n");
   if (g_removed__bb) fprintf(f, "\\n   In the node labels, replace '.' with \\nfunction name + '::bb::' or '::bb' \\nto get the label in the ALF file. \\n");
   fprintf(f, "\"");
   fprintf(f, "   }\n");
   PrintGraphicallyRecursively(f, "   ", root_scope, max_levels, max_levels, reduced_scope_graph);
   PrintEntryedgeGraphically(f, "   ", root_scope, max_levels, max_levels);
   PrintExitedgesGraphically(f, "   ", root_scope, max_levels, max_levels, reduced_scope_graph);
   fprintf(f, "}\n");
}

/* Private function that output code that will force dot to draw:
   - A frame with a border representing this scope.
   - The nodes of this scope to be drawn inside the border.
   - The edges between these nodes.
   - The child scopes to be drawn inside the border.
*/
void
CScope::
PrintGraphicallyRecursively(FILE *f, string indent, CScope * root_scope, int max_levels, int level, bool reduced_scope_graph) {
      
   const char *scope_name = _name.c_str();
   string function_name = Function()->Name();
   
      // Bottom level (= 0) is handled in a special way
      // Scopes are only sketched and only entry/exit edges are drawn
      
   if (level == 0) {
      fprintf(f, "%ssubgraph \"cluster_%s\" {\n", indent.c_str(), scope_name);
      fprintf(f, "%s   label= \"scope: %s", indent.c_str(), scope_name);
      if (IsFunctionScope()) fprintf(f, "\\n function: %s\"", function_name.c_str());
      else fprintf(f, "\"");
      
      if (IsLoopScope()) fprintf(f, "\n%sgraph[style=dashed] \n", indent.c_str());
      if (IsFunctionScope()) fprintf(f, "\n%sgraph[style=dashed] \n", indent.c_str());
      fprintf(f, "%s   /* Nodes */\n", indent.c_str());
   
         // Print the entry node
      for (ecfg_nodes_iterator nd=ECFGNodesBegin(); nd!=ECFGNodesEnd(); nd++) {
         CECFGNode *cur_node = *nd;
         string label = cur_node->GetFlowGraphNode()->PrettifiedName();
         
         char cur_node_key_string [33];
         sprintf (cur_node_key_string, "%d", cur_node->GetFlowGraphNode()->Key());
         
         if (IsHeader(cur_node))
            fprintf(f, "%s   \"%s_%s\"[label=\"%s\"]  [style=invis]\n", indent.c_str(), scope_name, cur_node_key_string, label.c_str());
      }

         // Print all exit nodes
      for (t_exitedge_iterator edge_it=ExitEdgesBegin(); edge_it!=ExitEdgesEnd(); edge_it++) {
         CECFGNode *from_node = edge_it->first;
         char from_node_key_string [33];
         sprintf (from_node_key_string, "%d", from_node->GetFlowGraphNode()->Key());
         CECFGNode *to_node = edge_it->second;
         string label = from_node->GetFlowGraphNode()->PrettifiedName();
            if (to_node->Scope() == ParentScope())
               fprintf(f, "%s   \"%s_%s\"[label=\"%s\"]  [style=invis]\n", indent.c_str(), scope_name, from_node_key_string, label.c_str());
      }
      
         // Close the current dot-scope
      fprintf(f, "\n%s}\n", indent.c_str());
      return;
   }
   
   if (IsFunctionScope() and root_scope != this and level == max_levels) {
         // Top level
         // Start with creating the calling node and node to return to
         // They are not drawn for root scope
         
         // Print the calling node (outside the box)
      
      fprintf(f, "%s/* Calling node to %s*/\n", indent.c_str(), scope_name);

      for (ecfg_nodes_iterator nd=ECFGNodesBegin(); nd!=ECFGNodesEnd(); nd++) {
         CECFGNode *cur_node = *nd;
         CECFGNode *pred_node;
         
         bool is_adjacent_to_outer_scopes_node = false;
         
            // Check in edges
         for (CECFGNode::pred_iterator pred=cur_node->PredBegin(); pred!=cur_node->PredEnd(); pred++) {
            pred_node = *pred;
            if (pred_node->Scope() == ParentScope()) {
               is_adjacent_to_outer_scopes_node = true;
               break;
            }
         }
         
         if (is_adjacent_to_outer_scopes_node) {
               // Then "declare" the node (i.e. define it to exist but be invisible):
            char key [33];
            sprintf (key, "%d", pred_node->GetFlowGraphNode()->Key());
            fprintf(f, "%s   \"%s_%s\"[style=invis]\n", indent.c_str(), ParentScope()->Name().c_str(), key);
         }
      }

      fprintf(f, "%s/* Node to return to from %s*/\n", indent.c_str(), scope_name);

         // Print the node to return to (outside the box)
      for (ecfg_nodes_iterator nd=ECFGNodesBegin(); nd!=ECFGNodesEnd(); nd++) {
         CECFGNode *cur_node = *nd;
         CECFGNode *succ_node;
         
         bool is_adjacent_to_outer_scopes_node = false;

            // Check out edges
         for (CECFGNode::succ_iterator succ=cur_node->SuccBegin(); succ!=cur_node->SuccEnd(); succ++) {
            succ_node = succ->node;
            if (succ_node->Scope() == ParentScope()) {
               is_adjacent_to_outer_scopes_node = true;
               break;
            }
         }
         
         if (is_adjacent_to_outer_scopes_node) {
               // Then "declare" the node (i.e. define it to exist but be invisible):
            char key [33];
            sprintf (key, "%d", succ_node->GetFlowGraphNode()->Key());
            fprintf(f, "%s   \"%s_%s\"[style=invis]\n", indent.c_str(), succ_node->Scope()->Name().c_str(), key);
         }
      }
   }
   
      // Top/intermediate level.
      // Continue with opening a new scope in the dot file. That dot-scope will contain this
      // scope as well as its children.

   fprintf(f, "%ssubgraph \"cluster_%s\" {\n", indent.c_str(), scope_name);
   fprintf(f, "%s   label= \"scope: %s", indent.c_str(), scope_name);
   if (IsFunctionScope()) fprintf(f, "\\n function: %s\"", function_name.c_str());
   else fprintf(f, "\"");
   
   if (IsLoopScope()) fprintf(f, "\n%sgraph[style=dotted] \n", indent.c_str());
   if (IsFunctionScope()) fprintf(f, "\n%sgraph[style=line] \n", indent.c_str());
   fprintf(f, "%s   /* Nodes */\n", indent.c_str());
   
   fprintf(f, "%s   node [width=0.3 fixedsize=true shape=circle fontsize=10]\n", indent.c_str());
   fprintf(f, "%s   /* Nodes and edges */\n", indent.c_str());
      
      // "Declare" the nodes:
   for (ecfg_nodes_iterator nd=ECFGNodesBegin(); nd!=ECFGNodesEnd(); nd++) {
      CECFGNode *cur_node = *nd;
      string label = cur_node->GetFlowGraphNode()->PrettifiedName();
      
         // Put back :: into names if they were removed
      if (g_unmangled_colons)
         for (unsigned i=1; i<label.length()-1; ++i) {
            if (label[i] == '_' and label[i+1] == '_') {
               label[i] = ':';
               label[i+1] = ':';
            }
         }
         // Shorten statement labels.
         // Here we see different versions of ALF code (backward compatible)
      
      string prefix;
      prefix = "alf_label_";
      if (label.find(prefix) == 0) {
            // Just use the number - that makes them unique
         label = '.' + label.substr(prefix.length());
         g_removed_alf_label = true;
      }
      
      prefix = "BB";
      if (label.find(prefix) == 0) {
            // Just use the number - that makes them unique
         label = '.' + label.substr(prefix.length());
         g_removed_BB = true;
      }
      
         // Latest version of ALF code has prefix "f::bb::<something>nx" or "f::bbnx" where "f" is a function
         // Replace with ".<something>nx" or ".nx"
      
      prefix = "::bb::";
      if (label.find(prefix) != std::string::npos) {
            // Just use the number - that makes them unique
         label = '.' + label.substr(label.find(prefix)+6);
         g_removed__bb = true;
      }
      
      prefix = "::bb";
      if (label.find(prefix) != std::string::npos) {
            // Just use the number - that makes them unique
         label = '.' + label.substr(label.find(prefix)+4);
         g_removed__bb = true;
      }
      
      char cur_node_key_string [33];
      sprintf (cur_node_key_string, "%d", cur_node->GetFlowGraphNode()->Key());
      if (reduced_scope_graph) {
         if (cur_node->IsBeginOfBasicBlock() or IsHeader(cur_node)) {
            fprintf(f, "%s   \"%s_%s\"[label=\"%s\"]", indent.c_str(), scope_name, cur_node_key_string, label.c_str());
            if (IsHeader(cur_node)) {
               fprintf(f, " [color=\"lightblue\"]");
            }
            fprintf(f, "\n");
         }
      }
      else /* is not reduced_scope_graph */ {
         fprintf(f, "%s   \"%s_%s\"[label=\"%s\"]", indent.c_str(), scope_name, cur_node_key_string, label.c_str());
         if (IsHeader(cur_node)) {
            fprintf(f, " [color=\"lightblue\"]");
         } else {
            if (cur_node->IsBeginOfBasicBlock() and cur_node->IsEndOfBasicBlock()) {
               fprintf(f, " [color=\"orange\"]");
            } else {
               if (cur_node->IsBeginOfBasicBlock()) {
                  fprintf(f, " [color=\"green\"]");
               } else {
                  if (cur_node->IsEndOfBasicBlock()) {
                     fprintf(f, " [color=\"red\"]");
                  }
                  else fprintf(f, " [style=dotted]");
               }
            }
         }
         fprintf(f, "\n");
      }
   }
   
      // Generate the code that will draw the internal edges.
      // We skip the exit edges at this stage - we have to output them at the outermost level in the dot file.
   
   fprintf(f, "%s   /* Internal edges */\n", indent.c_str());
   
   for (ecfg_nodes_iterator nd=ECFGNodesBegin(); nd!=ECFGNodesEnd(); nd++) {
      CECFGNode *cur_node = *nd;
      if (reduced_scope_graph) {
         for (CECFGNode::succ_iterator succ=cur_node->SuccBegin(); succ!=cur_node->SuccEnd(); succ++) {
            if (succ->node->Scope() == this) {
               if (cur_node->IsEndOfBasicBlock()) {
                  CFlowGraphNode* block_begin_node = cur_node->GetFlowGraphNode()->GetBeginNodeOfNodesBasicBlock();
                  char block_begin_node_key_string [33];
                  sprintf (block_begin_node_key_string, "%d", block_begin_node->Key());
                  CECFGNode *succ_node = succ->node;
                  assert(succ_node->IsBeginOfBasicBlock());
                  char succ_node_key_string [33];
                  sprintf (succ_node_key_string, "%d", succ_node->GetFlowGraphNode()->Key());
                  fprintf(f, "%s   \"%s_%s\"->\"%s_%s\"", indent.c_str(), scope_name, block_begin_node_key_string,
                          scope_name, succ_node_key_string);
                     // Indicate edges type by color
                  if (succ->edge_annot) {
                     fprintf(f, " [color=\"%s\"", succ->edge_annot->Color().c_str());
                     if (succ->edge_annot->Color() == "red") {
                        fprintf(f, " arrowhead=normalodot");
                     }
                     fprintf(f, "]");
                  }
                  fprintf(f, "\n");
               }
            }
         }
      }
      else {
         for (CECFGNode::succ_iterator succ=cur_node->SuccBegin(); succ!=cur_node->SuccEnd(); succ++) {
            if (succ->node->Scope() == this) {
               CECFGNode *succ_node = succ->node;
               char cur_node_key_string [33];
               sprintf (cur_node_key_string, "%d", cur_node->GetFlowGraphNode()->Key());
               char succ_node_key_string [33];
               sprintf (succ_node_key_string, "%d", succ_node->GetFlowGraphNode()->Key());
               fprintf(f, "%s   \"%s_%s\"->\"%s_%s\" ", indent.c_str(), scope_name, cur_node_key_string,
                       scope_name, succ_node_key_string);
                  // Indicate edges type by color
               if (succ->edge_annot) {
                  fprintf(f, " [color=\"%s\"", succ->edge_annot->Color().c_str());
                  if (succ->edge_annot->Color() == "red") {
                     fprintf(f, " arrowhead=normalodot");
                  }
                  fprintf(f, "]");
               }
               fprintf(f, "\n");
            }
         }
      }
   }
      // Draw the child scopes within the same dot-scope
   
   if (level > 0)
      for (succ_iterator kid=SuccBegin(); kid != SuccEnd(); kid++) {
         if (kid->node->IsFunctionScope())
            kid->node->PrintGraphicallyRecursively(f, indent+"   ", root_scope, max_levels, level-1, reduced_scope_graph);
         else
            kid->node->PrintGraphicallyRecursively(f, indent+"   ", root_scope, max_levels, level, reduced_scope_graph);
      }
      // Close the current dot-scope
   fprintf(f, "%s}\n", indent.c_str());
}

/* Private function that output the entry edge (in dot format) to the function scope where the printout starts. 
 The edge is printed only if the function is not the root. */
void
CScope::
PrintEntryedgeGraphically(FILE *f, std::string indent, CScope * root_scope, int max_levels, int level) {
   
   if (IsFunctionScope() and root_scope != this and level == max_levels) {      
      string to_scope_name_string = Name();      
      fprintf(f, "%s/* Entry edge to %s*/\n", indent.c_str(), to_scope_name_string.c_str());

         // Get the calling node (outside the box)
      for (ecfg_nodes_iterator nd=ECFGNodesBegin(); nd!=ECFGNodesEnd(); nd++) {
         CECFGNode *cur_node = *nd;
         CECFGNode *pred_node;
         
         bool is_adjacent_to_outer_scopes_node = false;
         
            // Check in edges
         for (CECFGNode::pred_iterator pred=cur_node->PredBegin(); pred!=cur_node->PredEnd(); pred++) {
            pred_node = *pred;
            if (pred_node->Scope() == ParentScope()) {
               is_adjacent_to_outer_scopes_node = true;
               break;
            }
         }
         
         if (is_adjacent_to_outer_scopes_node) {
               // Then "declare" the node (i.e. define it to exist but be invisible):
            char from_key [33];
            sprintf (from_key, "%d", pred_node->GetFlowGraphNode()->Key());
            char to_key [33];
            sprintf (to_key, "%d", cur_node->GetFlowGraphNode()->Key());
            fprintf(f, "%s   \"%s_%s\"->\"%s_%s\" [color=\"green\"]\n", indent.c_str(), ParentScope()->Name().c_str(), from_key,
                    Name().c_str(), to_key);
         }
      }
   }
}

/* Private function that output the exit edges (in dot format) of the scope tree rooted at this scope
   without making difference between scoping in the dot file. */
void
CScope::
PrintExitedgesGraphically(FILE *f, string indent, CScope *root_scope, int max_levels, int level, bool reduced_scope_graph) {
   for (t_exitedge_iterator edge_it=ExitEdgesBegin(); edge_it!=ExitEdgesEnd(); edge_it++) {
      const char *from_scope_name = _name.c_str();
      fprintf(f, "%s/* Exit edge from %s*/\n", indent.c_str(), from_scope_name);
      CECFGNode *from_node = edge_it->first;
      assert(from_node->IsEndOfBasicBlock());
      CECFGNode *to_node = edge_it->second;
      char to_node_key_string [33];
      sprintf (to_node_key_string, "%d", to_node->GetFlowGraphNode()->Key());
      CScope *to_scope = to_node->Scope();
      string to_scope_name_string = to_scope->Name();
      const char *to_scope_name = to_scope_name_string.c_str();
      if (level == 0) {
            // Only draw exit edge to parent
         if (from_node->Scope() == ParentScope() or to_node->Scope() == ParentScope()) {
            char from_node_key_string [33];
            sprintf (from_node_key_string, "%d", from_node->GetFlowGraphNode()->Key());
            fprintf(f, "%s   \"%s_%s\"->\"%s_%s\" [color=\"green\"]\n", indent.c_str(), from_scope_name, from_node_key_string,
                    to_scope_name, to_node_key_string);
         }
      } else  {
         if (reduced_scope_graph) {
            char from_block_begin_node_key_string [33];
            CFlowGraphNode* from_block_begin_node = from_node->GetFlowGraphNode()->GetBeginNodeOfNodesBasicBlock();
            sprintf (from_block_begin_node_key_string, "%d", from_block_begin_node->Key());
            fprintf(f, "%s   \"%s_%s\"->\"%s_%s\" [color=\"green\"]\n", indent.c_str(), from_scope_name, from_block_begin_node_key_string,
                    to_scope_name, to_node_key_string);
         } else {
            char from_node_key_string [33];
            sprintf (from_node_key_string, "%d", from_node->GetFlowGraphNode()->Key());
            fprintf(f, "%s   \"%s_%s\"->\"%s_%s\" [color=\"green\"]\n", indent.c_str(), from_scope_name, from_node_key_string,
                    to_scope_name, to_node_key_string);
         }
      }
   }
   
      // Output edges of child scopes at the same "scope" (the outermost) in the dot-file.
   if (level > 0) {
      for (succ_iterator kid=SuccBegin(); kid != SuccEnd(); kid++) {
         if (kid->node->IsFunctionScope())
            kid->node->PrintExitedgesGraphically(f, indent+"   ", root_scope, max_levels, level-1, reduced_scope_graph);
         else
            kid->node->PrintExitedgesGraphically(f, indent+"   ", root_scope, max_levels, level, reduced_scope_graph);         
      }
   }
}

void
CScope::
PrintFlowFactFile(ostream &o)
{
   
   o << "scope " << Name() << ":" << endl;
   o << "%% -------------------------" << endl;
   o << "%%    Type = ";
   if (Type() == LOOP) {
      o << "Loop";
   } else if (Type()==FUNCTION) {
      o << "Function";
      if (IsRoot()) {
         o << " (root)";
      }
   } else if (Type()==RECURSIVE_FUNCTION) {
      o << "Function (recursive)";
   } else if (Type()==MUTUAL_RECURSIVE_FUNCTIONS) {
      o << "Function (set of mutually recursive)";
   }
   o << endl;
   o << "%%    Backedges:";
   for (CScope::t_backedge_iterator be=BackedgeBegin(); be!=BackedgeEnd(); be++) {
      string from_name = be->first->GetFlowGraphNode()->Name();
      o << "   [(" << from_name << "," << be->first->Scope()->Name() << ") -> "
         << be->second->GetFlowGraphNode()->Name() << "]";
   }
   o << endl;
   o << "%% -------------------------" << endl;

   // Special fix, instead of setting maxiter = 0 we set the number of
   // times the scope header can be taken = 0 and maxiter = 1. We only do
   // this for looping scopes.
   bool generate_zero_header_fact = false;

   //    if (_collector_ip && (_collector_ip->IterationCount() || !g_use_zero_maxiter_fix)) {
   if (HasValidIterationCount() || !g_use_zero_maxiter_fix) {
     o << "  maxiter " << IterationCount() << ';' << endl;
   }
   else {
     o << "  maxiter " << "1;" << endl;
     generate_zero_header_fact = true;
   }

   o << "  header";
   o << " " <<  Header()->GetFlowGraphNode()->Name() << ";" << endl;

   o << "  facts" << endl;
   for (set<CFlowFact>::const_iterator it1=_flow_fact.begin(); it1!=_flow_fact.end(); it1++) {
      o << "    " << *it1 << endl;
   }

   // If we should create an extra scope : [] : header = 0 fact
   if(generate_zero_header_fact) {
     CExpressionFlowGraphNode * header_expr = new CExpressionFlowGraphNode(Header()->GetFlowGraphNode());
     CExpressionInt * zero_expr = new CExpressionInt(0);
     CConstraint * constraint = new CConstraint(header_expr, RELOP_EQ, zero_expr);
     CFFCollector * collector = new CFFCollector(TOTAL);
     CFlowFact * fix_fact = new CFlowFact(this,  CFlowFact::FIX, *collector, *constraint);
     o << "    " << *fix_fact << endl;
     delete fix_fact;
     delete collector;
     delete constraint;
   }

   o << "  subordinates" << endl;
   for (succ_iterator kid=SuccBegin(); kid != SuccEnd(); kid++) {
      o << "    " << kid->node->Name() << ";" << endl;
   }

   o << "  basicblocks" << endl;
   for (ecfg_nodes_iterator node_it=ECFGNodesBegin(); node_it!=ECFGNodesEnd(); node_it++) {
      CECFGNode *ecfg_node = *node_it;
      CFlowGraphNode *basic_block = ecfg_node->GetFlowGraphNode();
      o << "    " << basic_block->Name() << ", [ ];" << endl;
   }

   o << "  internaledges" << endl;
   int edge_counter = 0;
   for (ecfg_nodes_iterator node_it=ECFGNodesBegin(); node_it!=ECFGNodesEnd(); node_it++) {
      CECFGNode *ecfg_node = *node_it;
      CFlowGraphNode *basic_block = ecfg_node->GetFlowGraphNode();
      string from_cfg_node_name = basic_block->Name();
      for (CECFGNode::succ_iterator succ_it=ecfg_node->SuccBegin(); succ_it!=ecfg_node->SuccEnd(); succ_it++) {
         CECFGNode *succ = succ_it->node;
         if (succ->Scope() == this) {
            CFlowGraphEdgeAnnot *flow_graph_edge = NULL;
            if (succ_it->edge_annot)
               flow_graph_edge = succ_it->edge_annot->FlowGraphEdge();
            if (flow_graph_edge == NULL || !flow_graph_edge->IsFalseEdge()) {
               o << "    ";
               o << from_cfg_node_name << " -> " << succ->GetFlowGraphNode()->Name() << ";" << endl;
               edge_counter++;
            }
         }
      }
   }

   if (edge_counter == 0) {
     o << " ;" << endl;
   }

   o << "  exitedges" << endl;
   for (t_exitedge_iterator it=ExitEdgesBegin(); it!=ExitEdgesEnd(); it++) {
      string from_cfg_node_name = it->first->GetFlowGraphNode()->Name();
      CECFG const* ecfg = ScopeGraph()->ECFG();
      CECFGEdgeAnnot *ecfg_edge=NULL;
      ecfg->Edge(it->first, it->second, &ecfg_edge);
      CFlowGraphEdgeAnnot *flow_graph_edge = NULL;
      if (ecfg_edge)
         flow_graph_edge = ecfg_edge->FlowGraphEdge();
      if (flow_graph_edge == NULL || !flow_graph_edge->IsFalseEdge()) {
         o << "    ";
         o << from_cfg_node_name << " -> " <<
            "(" << it->second->Scope()->Name() << ", " << it->second->GetFlowGraphNode()->Name() << ");" << endl;
      }
   }
   if (IsRoot()) {
      CFlowGraphNode *return_cfg_node = ReturnNode()->GetFlowGraphNode();
      string from_cfg_node_name = return_cfg_node->Name();
      o << "     " << from_cfg_node_name << " -> exit;" << endl;
   }
   o << "end scope\n" << endl;

}


// Special twist, we want to end the analysis at some special nodes. This
// means that we write the node -> exit edges especially.
void
CScope::
PrintFlowFactFileSpecialExit(ostream &o, set<string> * exit_cfg_node_names)
{
   
   assert(exit_cfg_node_names->size() > 0);

   o << "scope " << Name() << ":" << endl;
   o << "%% -------------------------" << endl;
   o << "%%    Type = ";
   if (Type() == LOOP) {
      o << "Loop";
   } else if (Type()==FUNCTION) {
      o << "Function";
      if (IsRoot()) {
         o << " (root)";
      }
   } else if (Type()==RECURSIVE_FUNCTION) {
      o << "Function (recursive)";
   } else if (Type()==MUTUAL_RECURSIVE_FUNCTIONS) {
      o << "Function (set of mutually recursive)";
   }
   o << endl;
   o << "%%    Backedges:";
   for (CScope::t_backedge_iterator be=BackedgeBegin(); be!=BackedgeEnd(); be++) {
      string from_cfg_node_name = be->first->GetFlowGraphNode()->Name();
      o << "   [(" << from_cfg_node_name << "," << be->first->Scope()->Name() << ") -> "
         << be->second->GetFlowGraphNode()->Name() << "]";
   }
   o << endl;
   o << "%% -------------------------" << endl;
   // Special fix, instead of setting maxiter = 0 we set the number of
   // times the scope header can be taken = 0 and maxiter = 1. We only do
   // this for looping scopes.
   bool generate_zero_header_fact = false;
   // if (_collector_ip && (_collector_ip->IterationCount() || !g_use_zero_maxiter_fix)) {
   if (HasValidIterationCount() || !g_use_zero_maxiter_fix) {
     o << "  maxiter " << IterationCount() << ';' << endl;
   }
   else {
     o << "  maxiter " << "1;" << endl;
     generate_zero_header_fact = true;
   }

   o << "  header";
   o << " " <<  Header()->GetFlowGraphNode()->Name() << ";" << endl;

   o << "  facts" << endl;
   for (set<CFlowFact>::const_iterator it1=_flow_fact.begin(); it1!=_flow_fact.end(); it1++) {
      o << "    " << *it1 << endl;
   }
   // If we should create an extra scope : [] : header = 0 fact
   if(generate_zero_header_fact) {
     CExpressionFlowGraphNode * header_expr = new CExpressionFlowGraphNode(Header()->GetFlowGraphNode());
     CExpressionInt * zero_expr = new CExpressionInt(0);
     CConstraint * constraint = new CConstraint(header_expr, RELOP_EQ, zero_expr);
     CFFCollector * collector = new CFFCollector(TOTAL);
     CFlowFact * fix_fact = new CFlowFact(this,  CFlowFact::FIX, *collector, *constraint);
     o << "    " << *fix_fact << endl;
     delete fix_fact;
     delete constraint;
     delete collector;
   }

   // We treat the normal exit edge especially
   if (IsRoot()) {
      CFlowGraphNode *return_cfg_node = ReturnNode()->GetFlowGraphNode();
      string cfg_node_name = return_cfg_node->Name();
      // Check if we should not end form the  node
      if(exit_cfg_node_names->find(cfg_node_name) == exit_cfg_node_names->end())
      {
         // Add an extra scope : [] : cfg_node_name->exit = 0; flow fact;
         // cfg_node_name = return_cfg_node->Name();
         CExpressionFlowGraphNode * return_expr = new CExpressionFlowGraphNode(return_cfg_node);
         CExpressionInt * int_expr = new CExpressionInt(0);
         CFFCollector * collector = new CFFCollector(TOTAL);
         CConstraint * constr = new CConstraint(return_expr, RELOP_EQ, int_expr);
         CFlowFact *ff = new CFlowFact(this, CFlowFact::UNDEF, *collector, *constr);
         o << "            " << *ff << endl;
         delete constr;
         delete collector;
         delete ff;
      }
   }


   o << "  subordinates" << endl;
   for (succ_iterator kid=SuccBegin(); kid != SuccEnd(); kid++) {
      o << "    " << kid->node->Name() << ";" << endl;
   }

   o << "  basicblocks" << endl;
   for (ecfg_nodes_iterator node_it=ECFGNodesBegin(); node_it!=ECFGNodesEnd(); node_it++) {
      o << "    " << (*node_it)->GetFlowGraphNode()->Name() << ", [ ];" << endl;
   }

   o << "  internaledges" << endl;
   int edge_counter = 0;
   for (ecfg_nodes_iterator node_it=ECFGNodesBegin(); node_it!=ECFGNodesEnd(); node_it++) {
      string from_cfg_node_name = (*node_it)->GetFlowGraphNode()->Name();
      for (CECFGNode::succ_iterator succ_it=(*node_it)->SuccBegin(); succ_it!=(*node_it)->SuccEnd(); succ_it++) {
         if (succ_it->node->Scope() == this) {
            CFlowGraphEdgeAnnot *flow_graph_edge = NULL;
            if (succ_it->edge_annot)
               flow_graph_edge = succ_it->edge_annot->FlowGraphEdge();
            if (flow_graph_edge == NULL || !flow_graph_edge->IsFalseEdge()) {
               o << "    ";
               o << from_cfg_node_name << " -> " << succ_it->node->GetFlowGraphNode()->Name() << ";" << endl;
               edge_counter++;
            }
         }
      }
   }

   if (edge_counter == 0) {
      o << " ;";
   }
   o << endl;

   o << "  exitedges" << endl;
   for (t_exitedge_iterator it=ExitEdgesBegin(); it!=ExitEdgesEnd(); it++) {
      string from_cfg_node_name = it->first->GetFlowGraphNode()->Name();
      CECFG const* ecfg = ScopeGraph()->ECFG();
      CECFGEdgeAnnot *ecfg_edge=NULL;
      ecfg->Edge(it->first, it->second, &ecfg_edge);
      CFlowGraphEdgeAnnot *flow_graph_edge = NULL;
      if (ecfg_edge)
         flow_graph_edge = ecfg_edge->FlowGraphEdge();
      if (flow_graph_edge == NULL || !flow_graph_edge->IsFalseEdge()) {
         o << "            ";
         o << from_cfg_node_name << " -> " <<
            "(" << it->second->Scope()->Name() << ", " << it->second->GetFlowGraphNode()->Name() << ");" << endl;
      }
   }

   // Loop through all the ECFGNodes in the scope
   for (ecfg_nodes_iterator node_it=ECFGNodesBegin(); node_it!=ECFGNodesEnd(); node_it++) {
     // Get the name of the basic block
     string cfg_node_name = (*node_it)->GetFlowGraphNode()->Name();
     // Check if the name exists among the set of exit cfg_node names
     if(exit_cfg_node_names->find(cfg_node_name) != exit_cfg_node_names->end())
       {
         cfg_node_name = (*node_it)->GetFlowGraphNode()->Name();
         // Generate an exit edge from this node
         o << "            " << cfg_node_name << " -> exit;" << endl;
       }
   }

   // We must use the return node of the root scope as exit node,
   // but use the argument node names instead.
   if (IsRoot()) {
      CFlowGraphNode *return_cfg_node = ReturnNode()->GetFlowGraphNode();
      string from_cfg_node_name = return_cfg_node->Name();
      o << "            " << from_cfg_node_name << " -> exit;" << endl;
   }


   o << "end scope\n" << endl;

}
