// $Id: CScope.h 7974 2018-11-23 13:53:26Z lkg02 $

#ifndef CSCOPE_H_
#define CSCOPE_H_

#include "flow_facts/CFlowFact.h"
#include "graphs/tools/CNode.h"
#include "CScopeGraphEdgeAnnot.h"

#include <iostream>
#include <map>
#include <list>
#include <set>
#include <vector>
#include <string>
#include <utility>
#include <cassert>
#include <stdio.h>

class CScopeGraph;
class CFlowGraphNode;
class CGenericStmt;
class CGenericFunction;
class CECFGNode;
class CAliasGraph;
class CCallGraph;
class CCallGraphNode;
class CCollectorIP;
class CSymTabBase;
class CSteensgaardPA;
class CCollectorIP;  // ******** To be removed *********
template <typename CFlowGraphNode> class CComponent;

#define INVALID_ITER_COUNT -1

class CScope : public CNode <CScope, CScopeGraphEdgeAnnot>
{
public:
   typedef enum {
      LOOP,                       // Loop
      FUNCTION,                   // Non-recursive function
      RECURSIVE_FUNCTION,         // Self-recursive function
      MUTUAL_RECURSIVE_FUNCTIONS  // Mutually recursive functions
   } t_scopetype;

   typedef std::list<std::pair<CECFGNode *, CECFGNode *> > t_backedges;
   typedef std::list<std::pair<CECFGNode *, CECFGNode *> > t_exitedges;
   typedef std::vector<CECFGNode *> t_ecfg_nodes;

   typedef t_backedges::iterator t_backedge_iterator;
   typedef t_exitedges::iterator t_exitedge_iterator;
   typedef t_ecfg_nodes::const_iterator ecfg_nodes_iterator;

   /** Constructs a new function scope
      \param component A pointer to the component in a CFG-component tree that represents tha function that this
         scope represents (i.e. the root node of that tree). The object pointed to is not owned by this scope.
      \param call_graph_node A pointer to the call graph node that represents tha function that this
         scope represents. The object pointed to is not owned by this scope.
      \param cfg_to_ecfg_map A pointer to a mapping from CFG nodes to ECFG nodes. The object pointed to is not
         owned by this scope.
      \param pending_edges A pointer to a list of ecfg edges whose targets are ecfg nodes not yet under any scope.
         The memory pointed to is owned by this scope.
      \param parent A pointer to the parent scope or NULL in case the \a scope_graph where this scope will
         be inserted is empty. The object pointed to is not owned by this scope.
     \param calling_node A pointer to the ECFG-node representing the call statement calling the function that
         this scope represents.
      \param scope_graph A pointer to the scope graph where this scope will be inserted. The object pointed to
         is not owned by this scope.
   */
   CScope(CComponent<CFlowGraphNode> *component, CCallGraphNode *call_graph_node, std::vector<CECFGNode*> *cfg_to_ecfg_map,
          std::list<std::pair<CECFGNode*, CECFGNode*> > *pending_edges, CScope *parent, CECFGNode *calling_node,
          CScopeGraph *scope_graph);

   /** Constructs a new loop scope
      \param component A pointer to the component in a CFG-component tree that represents tha function that this
         scope represents (i.e. the root node of that tree). The object pointed to is not owned by this scope.
      \param cfg_to_ecfg_map A pointer to a mapping from CFG nodes to ECFG nodes. The object pointed to is not
         owned by this scope.
      \param parent A pointer to the parent scope. The object pointed to is not owned by this scope.
      \param number A sequence number indicating the sibling number of this loop.
   */
   CScope(CComponent<CFlowGraphNode> *component, std::vector<CECFGNode*> *cfg_to_ecfg_map, CScope *parent, int number);

   /** Constructs a new loop scope
      \param component A pointer to the component in a CFG-component tree that represents tha function that this
         scope represents (i.e. the root node of that tree). The object pointed to is not owned by this scope.
      \param parent A pointer to the parent scope. The object pointed to is not owned by this scope.
   */
   CScope(CComponent<CFlowGraphNode> *component, CScope *parent);

   /** Constructs a new function scope
      \param component A pointer to the component in a CFG-component tree that represents tha function that this
         scope represents (i.e. the root node of that tree). The object pointed to is not owned by this scope.
      \param call_graph_node A pointer to the call graph node that represents the function that this
         scope represents. The object pointed to is not owned by this scope.
      \param scope_graph A pointer to the scope graph where this scope will be inserted. The object pointed to
         is not owned by this scope.
   */
   CScope(CComponent<CFlowGraphNode> *component, CCallGraphNode *call_graph_node, CScopeGraph *scope_graph);

   virtual ~CScope(void);

   /** \return NULL This function should not be used!
   */
   CScope *Copy();

   // Will expand all "pending edges", i.e. all function calls and returns, with the respective tree. This `expansion' will be done completely
   // down to all leafs in the scope tree
   void CompletelyExpandScopeTreesOfPendingEdges(CCallGraph *call_graph, const CSymTabBase *symtab, const CSteensgaardPA &pa);

   /** Extends a scope to be a mutual recursive functions scope, essentially adds the the set of internal
      ecfg nodes the flow graph nodes specified by `component' and translated by `bb_to_ecfg_map'.
   */
   void ExtendWithMututalRecursiveFunction(CComponent<CFlowGraphNode> *component, std::vector<CECFGNode*> *bb_to_ecfg_map,
                                           CGenericFunction *function);

   /** Assignes a name to this scope.
      \pre The name is unique within the scopes graph. */
   void SetName(std::string name) { _name = name; }

   /** Adds an exit edge from `from' to `to'
   */
   void AddExitEdge(CECFGNode *from, CECFGNode *to);

   /** Change the scope type to be a self recursive function
   */
   inline void SetSelfRecursive() { _type = RECURSIVE_FUNCTION; }

   /** \return A pointer to the scope graph that this scope belongs to.
   */
   inline CScopeGraph *ScopeGraph() { return _scope_graph; }

   /** \return A pointer to the header of the scope.
   */
   inline CECFGNode *Header() { return _header; }

   /** Sets a pointer to the header of the scope.
   */
   inline void SetHeader(CECFGNode *header) { _header = header; }

   /** \return A pointer to the entry node of the scope (this will be the
      same as the header in case of loop scope, only in case of
      function scope this may be some other node).
   */
   inline CECFGNode *EntryNode() { return _entry_node; }

   /** Sets a pointer to the entry node of the scope.
   */
   inline void SetEntryNode(CECFGNode *entry_node) { _entry_node = entry_node; }

   /** \return A pointer to the function that this scope represents if this scope is a function
      scope, else returns the same pointer as the enclosing function scope.
   */
   CGenericFunction *Function();

   /** \return A pointer to the call graph node representing the same function that this
      scope represents if this scope is a function scope, else returns the same pointer as
      the enclosing function scope.
   */
   CCallGraphNode *CallGraphNode() { return _call_graph_node; }

   /** \return A pointer to the component in the component tree of the flow graph that this scope represents.
   */
   inline CComponent<CFlowGraphNode> *Component() { return _component; }

   /** \return A pointer to the scope of the enclosing function scope or to this scope if this is a function scope.
   */
   inline CScope *FunctionScope(void) { return _enclosing_function_scope; }

   /** \return If this is the root scope in the scope graph then \a true is returned else \a false
   */
   bool IsRoot(void);

   /** \return The scope type
   */
   inline t_scopetype Type(void) { return _type; }

   /** Collect all call sites along the path down to the funtion represented by this scope.
      \param call_string Where the call sites (represented by will ECFG nodes) will be put.
         The first element is the call site of the caller of this function, and the last is
         the firs caller in the chain.
      \pre This is a context sensitive scope graph.
   */
   void GetCallString(std::vector <const CECFGNode*> &call_string);

   /** Counts the number of loop scopes reachable from this scope (including this scope in
      the count in case this is a loop scope).
      \return The count. */
   unsigned GetGlobalLoopCount();

   /** Counts the maximum loop nesting depth in the scopes reachable from this scope. Definition:
      a single loop has a nesting of 1. The count is performed at a global level meaning that
      a call to a function with a loop in the body of another loop gives a nesting of 2.
      Undefined result if recursive functions are included.
      \return The maximum nesting depth. */
   unsigned GetGlobalMaxLoopNesting();
   /** The same as above, but includes all type of scopes */
   unsigned GetGlobalMaxNesting();

   bool IsLoopScope() { return _type == LOOP; }
   bool IsFunctionScope() { return _type == FUNCTION; }
   bool IsRecursiveFunctionScope() { return _type == RECURSIVE_FUNCTION; }
   bool IsMutualRecursiveFunctionsScope() { return _type == MUTUAL_RECURSIVE_FUNCTIONS; }

   // Returns a pointer to a list of back-edges
   inline t_backedges *Backedges(void) {return &_back_edges; }
   void BackEdges(std::set<std::pair<CECFGNode *, CECFGNode *> > * back_edges);   

   // Returns a std::string with the name of the scope
   inline const std::string Name(void) const { return _name; }

   // Returns a std::string with the name of the scope to useinf flow facts
   // inline const std::string FFName(void) const { return "\"" + _name + "\""; }

   // Returns a pointer to the ecfg node of this scope that points to
   // the flow graph node that contains a return statement, in case this
   // is a function scope, else NULL.
   CECFGNode *ReturnNode(void);

   // Returns a pointer to the ecfg node of the flow graph node that is a
   // successor to the flow graph node pointed to by `call_node' in case
   // there exists such a successor in the cfg, else NULL. Note: there
   // is no check that `call_node' is a call node.
   CECFGNode *ResultNode(CECFGNode *call_node);

   // Returns a pointer to the node in the extended control flow graph
   // that points to a certain flow graph node, or NULL if the flow graph node
   // is not related to this scope.
   CECFGNode *ECFGNodeOfFlowGraphNode(CFlowGraphNode *flow_graph_node) const;

   /** \return \a true if 'other' is an ancestor to this of if other is this, else \a false
   */
   bool HasAncestor(CScope *other);

   /** \return If current scope is an ancestor of \a arg then \a true is returned else \a false
   */
   bool IsAncestorOf(CScope *arg);

   /** \return A pointer to the parent scope or NULL if this is the root scope.
      NOTE! This function is only meaningful in case of context sensitive scope graph
      (i.e. tree structure). In case of a DAG structure the result is undefined (use pred-iterator).
   */
   CScope *ParentScope();

   /** \return If current is a (direct) parent of \a arg then \a true is returned else \a false
   */
   bool IsParentOf(CScope *arg);

   /** Adds the child scopes of this scope to the set \a subscopes
   */
   void ChildScopes(std::set<CScope *> *subscopes);

   /** Adds the descendant scopes of this scope to the set \a subscopes
   */
   void DescendantScopes(std::set<CScope *> * subscopes);

   /** Adds the descendant scopes of this scope to the list \a subscopes
    */
   void DescendantScopesList(std::list<CScope *> * subscopes);
   
   /** \return If current scope is a loop scope then we will return the loop scope which is the root
       in the loop nest (i.e. this scope or some ancestor scope). If currrent scope not is a loop 
       scope then NULL will be returned. 
   */
   CScope * LoopNestRootScope(void);
   bool IsLoopNestRootScope(void);

   // To get and set the iteration count of the scope
   int IterationCount(void);
   // If the scope already has a valid iteration count, i.e. a count not eqaul to -1 
   // we will take the smallest of current and the new. Otherwise we will take the new.
   void SetIterationCount(int iteration_count);
   bool HasValidIterationCount(void) { return _iteration_count != INVALID_ITER_COUNT; }

   /// Add a flow fact to the set of flowfacts in this scope. Previous flow facts is disregarded
   /// \param flow_fact The flow fact to add
   void AddFlowFact(CFlowFact &flow_fact);

   /// Removes a flow fact from the set of flow facts in this scope if there is one equal to the
   /// the requested, else do nothing
   /// \param flow_fact a flowfact equal to the one to remove.
   void RemoveFlowFact(CFlowFact &flow_fact);

   /// Adds a flow fact into this scope if it can not be merged with some flowfact aleady there
   /// \param flow_fact The flow fact to add
   // void AddAndMergeFlowFact(CFlowFact &flow_fact);

   /// \return A pointer the set of flow facts in this scope
   inline std::set<CFlowFact> *GetFlowFacts() { return &_flow_fact; }

   /// Removes all flow facts previsously stored in this scope.
   void RemoveAllFlowFacts() { _flow_fact.clear(); }

   // Returns the difference in loop nesting levels of other compared
   // to this (i.e. only loop scopes are counted) in case
   // they are nested, else 0
   int LoopNestingDistance(CScope *other);

   // Returns the difference between this and other in loop nesting levels (only loops are counted)
   int LoopLevelDifference(CScope *other);

   // Returns true if current is a loop, other is a subordinate loop scope of current and 
   // there are only loop scopes appearing inbetween the two scopes
   bool IsSubordinateInLoopNest(CScope *other);

   // Returns true if current scope is a loop scope and it is the top
   // scope in the loop nesting. Otherwise false.
   bool IsTopInScopesLoopNest(void);

   // Given that the current scope is a loop scope, then this function
   // will return the top loop in the loop nest in which the scope occurs. 
   // If it is not a loop scope NULL will be returned.
   CScope * GetTopScopeInScopesLoopNest(void);

   // To get all edges in the scope in a set
   void Edges(std::set<std::pair<CECFGNode *, CECFGNode *> > * edges);

   // To get all call edges in the scope in a set. That is an exit
   // edges that goes to the header of a function scope that is not
   // the urrent scope.
   void CallEdges(std::set<std::pair<CECFGNode *, CECFGNode *> > * edges);

   // Get edges starting in current scope but not ending in current scope
   inline t_exitedge_iterator ExitEdgesBegin() { return _exit_edges.begin(); }
   inline t_exitedge_iterator ExitEdgesEnd() { return _exit_edges.end(); }
   inline int NrOfExitEdges() { return (int)_exit_edges.size(); }
   void ExitEdges(std::set<std::pair<CECFGNode *, CECFGNode *> > *);

   // Get exit edges starting in current scope but not going to scopes
   // for which the current is an ancestor.
   void ExitEdgesToSurroundingScopes(std::set<std::pair<CECFGNode *, CECFGNode *> > *);
   int NrOfExitEdgesToSurroundingScopes(void);

   // Get exit edges starting in current scope but not going to scopes
   // for which the scope is an ancestor (exit edges to s are not included).
   // void ExitEdgesToSurroundingScopesWrtAnotherScope(std::set<std::pair<CECFGNode *, CECFGNode *> > *, CScope *s);

   // Get exit edges starting in current or subordinate scopes but not
   // going to scopes for which the current is an ancestor
   void ExitEdgesInclSubScopesToSurroundingScopes(std::set<std::pair<CECFGNode *, CECFGNode *> > *);
   int NrOfExitEdgesInclSubScopesToSurroundingScopes(void);

   // Get exit edges starting in current scope or its sibling scopes
   // but not going to scopes for which the scope is an ancestor (exit
   // edges to s are not included).
   // void ExitEdgesInclSubScopesToSurroundingScopesWrtAnotherScope(std::set<std::pair<CECFGNode *, CECFGNode *> > *, CScope * s);

   // Get exit edges starting in current scope or its sibling scopes
   // which are going to *another* subscope or sibling scope of scope s.
   void ExitEdgesInclSubScopesToOtherSubScopesWrtAnotherScope(std::set<std::pair<CECFGNode *, CECFGNode *> > *exit_edges, CScope * s);

   // Given a subscope sub of the current scope (this) get the
   // subscopes or sibling scopes reachable (directly or in several
   // steps) through exitedges of the subscope or its sibling scopes
   // (including sub and its sibling scopes).
   void SubScopesToCurrentScopeReachableFromSubScope(std::set<CScope*> * subscopes,
                                                     CScope * sub);

   // To get all the exit edges from a set of scopes which goes to
   // current scope
   void ExitEdgesToCurrentScope(std::set<std::pair<CECFGNode *, CECFGNode *> > *exit_edges,
                                std::set<CScope*> * scopes);

   // To get all the exit edges from a set of scopes which goes to
   // a surrounding scope of current scope
   void ExitEdgesToSurroundingScopes(std::set<std::pair<CECFGNode *, CECFGNode *> > *exit_edges,
				     std::set<CScope*> * scopes);

   // Get the exit edges starting in current scope and going to a
   // subordinate scope (direct or sibling)
   void ExitEdgesToSubScopes(std::set<std::pair<CECFGNode *, CECFGNode *> > *);
   int NrOfExitEdgesToSubScopes(void);

   /* Returns true if the node is a header of the scope */
   bool IsHeader(CECFGNode *node) { return node == Header(); }

   // Iterates over the extended control flow graph nodes of this scope
   inline ecfg_nodes_iterator ECFGNodesBegin(void) const {return _ecfg_nodes.begin();}
   inline ecfg_nodes_iterator ECFGNodesEnd(void) const {return _ecfg_nodes.end();}

   /** Add one ECFG node to be in the collection of nodes in this scope. */
   void AddECFGNode(CECFGNode *node) { _ecfg_nodes.push_back(node); }

   inline unsigned ECFGNodesSize() const {return (unsigned)_ecfg_nodes.size();}

   inline t_backedge_iterator BackedgeBegin(void) {return _back_edges.begin();}
   inline t_backedge_iterator BackedgeEnd(void) {return _back_edges.end();}

   void AddBackedge(CECFGNode *from, CECFGNode *to);

   inline int BackedgesSize(void) {return (int)_back_edges.size();}

   /** Collects all scopes reachable from this scope. I.e. if the scope graph is fully context
      sensitive it will collect all scopes in the tree rooted at this scope.
      \param scopes A set of scopes to which all scopes reachable from this scope will be added.
   */
   void Reachable(std::set<CScope *> *scopes);

   // Prints the files with the analysis result
   void PrintFlowFactFile(std::ostream &o);

   // Special twist, we want to end the analysis at some special nodes.
   // Prints the files with the analysis result
   void PrintFlowFactFileSpecialExit(std::ostream &o, std::set<std::string> * exit_bb_names);

   /** Will generate dot format text representing the scope graph (scopes and nodes).
      \param file A file open for drawing in text mode where to output the generated dot text.
      \param id A name identifying the graph. Used as label in the dot file.
      \param max_levels The maximum "levels" to draw in a scope tree rooted at this scope. "level"
         here means the maximum recursion level when recursing from this scope (i.e. the number of
         tree levels in a tree formed scope graph).
      \param reduced_scope_graph If true the cfg-nodes drawn will represent basic blocks rather than
         statements.
   */
   void PrintGraphically(FILE *file, const std::string s, CScope * root_scope, const int max_levels, const bool reduced_scope_graph=false);

   void PrintTCD(std::ostream &o);
   
   // Help functions used by collectors. Returns the set of nodes
   // located in a the scope, the scope and subscopes or the scope and
   // all looping subscopes respectively. 
   void NodesInScope(std::set<CECFGNode *> * nodes_to_consider);
   void NodesInScopeAndSubScopes(std::set<CECFGNode *> * nodes_to_consider);
   void NodesInScopeAndLoopSubScopes(std::set<CECFGNode *> * nodes_to_consider);

   void NodesInScopeExceptHeader(std::set<CECFGNode *> * nodes_to_consider);
   void NodesInScopeExceptHeaderAndSubScopes(std::set<CECFGNode *> * nodes_to_consider);
   void NodesInScopeExceptHeaderAndLoopSubScopes(std::set<CECFGNode *> * nodes_to_consider);
   
   // The same as above but only returns the loop headers. 
   void HeaderNodeInScope(std::set<CECFGNode *> * nodes_to_consider);
   void HeaderNodesInScopeAndLoopSubScopes(std::set<CECFGNode *> * nodes_to_consider);
   void HeaderNodesInScopeAndSubScopes(std::set<CECFGNode *> * nodes_to_consider);

   // Help functions used by different subclasses. Returns the set of edges
   // located in a the scope, the scope and subscopes or the scope and all
   // looping subscopes respectively. Should be moved to the CScope code.
   void EdgesInScope(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider);
   void EdgesInScopeAndLoopSubScopes(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider);
   void EdgesInScopeAndSubScopes(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider);
   void CallEdgesInScopeAndLoopSubScopes(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider);
   void CallEdgesInScopeAndSubScopes(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider);

   // A loop-body-begin-edge is an edge that goes from a header node
   // in a loop scope to a node within the same scope or to a node in
   // a subscope. If consider_edges_inbetween_basic_blocks is true we will
   // instead use the last node in the header's basic block as the
   // header.
   void LoopBodyBeginEdgesInScope(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider, 
                                  bool consider_edges_inbetween_basic_blocks=false);
   void LoopBodyBeginEdgesInScopeAndLoopSubScopes(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider, 
                                                  bool consider_edges_inbetween_basic_blocks=false);
   void LoopBodyBeginEdgesInScopeAndSubScopes(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider, 
                                              bool consider_edges_inbetween_basic_blocks=false);

   // The node of the calling statement in case this is a function
   // scope in a context sensitive graph, else NULL.
   CECFGNode * CallingNode() { return _calling_node; }

   // 8<--------------------------------------------
   // Returns a pointer to the scope that will be entered if following the
   // edge from->to if 'from' referes to a node within this scope and from->to
   // is a legal path, else NULL.
   // If `to' is not an immediate successor to `from' in the the original (non-reduced) ECFG the
   // behaviour is undefined (SWEET may die).
   CScope *NextScope(CFlowGraphNode *from, CFlowGraphNode *to);

   // Returns true if the node is a header of the scope
   bool IsHeader(CFlowGraphNode *flow_graph_node);

   // Returns a pointer to the set of headers of the scope. Structured loop scopes will always have a single header,
   // function scopes will have its start node as header, only unstructured loops will have multiple headers.
   std::set<CFlowGraphNode*> _ns;
   std::set<CFlowGraphNode*> *HeaderNodes(void) { _ns.clear(); _ns.insert(HeaderNode()); return &_ns; }

   // Returns the single header node of this scope. In case of multiple headers the return
   // value will be a pointer to an arbitrary node
   CFlowGraphNode *HeaderNode(void);

   // Returns a list of successor nodes (including context) to the node nd in this scope.
   std::list<std::pair <CScope*, CFlowGraphNode*> > GetSuccessors(CFlowGraphNode *);
   std::list<std::pair <CScope*, CFlowGraphNode*> > GetPredecessors(CFlowGraphNode *);

   // To get all the flow graph nodes in a scope
   void AllFlowGraphNodes(std::set<CFlowGraphNode *> *bbs);

   // To get all the conditional flow graph nodes in a scope
   void AllCondFlowGraphNodes(std::set<CFlowGraphNode *> *cond_bbs);

   // To 

// 8<--------------------------------------------

   /** Plants a pointer to a CCollectorIP in this scope. The object is not owned by us and
      the pointer can later be retrieved or removed.
   */
   void SetCollectorIP(CCollectorIP *collector_ip) { assert(0); /* _collector_ip = collector_ip; */ }

   /** \return A pointer to a CCollectorIP if one has been assigned, else NULL.
   */
   CCollectorIP *CollectorIP() const { assert(0); return NULL; /* return _collector_ip; */ }

   /** Removes the CCollectorIP pointer from this scope.
   */
   void RemoveCollectorIP() { assert(0); /* _collector_ip = NULL; */ }

private:
   // Type of this scope
   t_scopetype _type;

   // Complete name of this scope
   std::string _name;

   // A pointer to the component of this scope
   CComponent<CFlowGraphNode> *_component;

   CCallGraphNode *_call_graph_node;

   // A pointer to the scope graph where this scope is a node
   CScopeGraph *_scope_graph;

   // A pointer to the function of this scope (in case of a loop scope this is a pointer to the function where the loop exists).
   // In case of a mutual recursive scope this is a pointer to the function called from outside the nest of recursive function that
   // are included in this scope.
   CGenericFunction *_function;

   // A pointer to the enclosing function scope (i.e. the scope of `function' in this context)
   CScope *_enclosing_function_scope;

   // A list of pending edges in the function. A "pending edge" is an edge from a node ending with a call statement to
   // the node with the corresponing result statement. These edges does not exist in the ecfg, but they should be present in the
   // scope graph file. They also points at where there are lacking edges to sub-function scopes at the time when this scope is
   // created (these edges can be expanded at arbitrary time). The function scope owns this data, the loop scopes points to it.
   std::list<std::pair<CECFGNode*, CECFGNode*> > *_pending_edges;

   // The extended flow graph nodes of this scope. Each ecfg node wraps one cfg node
   t_ecfg_nodes _ecfg_nodes;

   // The flow fact that belongs to this scope
   std::set<CFlowFact> _flow_fact;

   // The header node of this scope
   CECFGNode *_header;

   // The entry node of this scope
   CECFGNode *_entry_node;

   // The backedges (empty in case this is a function scope). These are all the edges whose tail start with a
   // node in `_ecfg_nodes' and the head ends in `_header'. This is information that is implicit given by `_ecfg_nodes'
   // and the edges in the graph, but we precalculate them since they might be frequently accessed
   t_backedges _back_edges;

   // All exit edges. These are all the edges whose tail start with a node in `_ecfg_nodes' but
   // the head isn't a node among those. This is information that is implicit given by `_ecfg_nodes' and the
   // edges in the graph, but we precalculate them since they might be frequently accessed
   // (changing E from "nr of edges in flow graph" to "nr of exit edges in flow graph" in O(E) )
   t_exitedges _exit_edges;

   // A pointer to some flow information
   // CCollectorIP *_collector_ip;
   int _iteration_count;

   // Help functions for deriving nodes and edges
   void NodesInScopeAndSubScopes(std::set<CECFGNode *> * nodes_to_consider, CScope * scope);
   void NodesInScopeAndLoopSubScopes(std::set<CECFGNode *> * nodes_to_consider, CScope * scope);
   void HeaderNodesInScopeAndLoopSubScopes(std::set<CECFGNode *> * nodes_to_consider, CScope * scope);
   void HeaderNodesInScopeAndSubScopes(std::set<CECFGNode *> * nodes_to_consider, CScope * scope);
   void EdgesInScopeAndLoopSubScopes(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider, CScope * scope);
   void EdgesInScopeAndSubScopes(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider, CScope * scope);
   void CallEdgesInScopeAndLoopSubScopes(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider, CScope * scope);
   void CallEdgesInScopeAndSubScopes(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider, CScope * scope);
  void LoopBodyBeginEdgesInScopeAndLoopSubScopes(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider, bool consider_edges_inbetween_basic_blocks, CScope * scope);
  void LoopBodyBeginEdgesInScopeAndSubScopes(std::set<std::pair<CECFGNode*, CECFGNode*> > * edges_to_consider, bool consider_edges_inbetween_basic_blocks, CScope * scope);

   // The node of the calling statement in case this is a function scope in a context sensitive graph, else NULL.
   CECFGNode *_calling_node;

   void PrintGraphicallyRecursively(FILE *f, std::string indent, CScope * root_scope,
                                    const int max_levels, int level, const bool reduced_scope_graph);
   void PrintEntryedgeGraphically(FILE *f, std::string indent, CScope * root_scope, int max_levels, int level);
   void PrintExitedgesGraphically(FILE *f, std::string indent, CScope * root_scope,
                                  int max_levels, int level, bool reduced_scope_graph);
   int LoopNestingLevel();
   void AssignScopeToECFGNodes(CComponent<CFlowGraphNode> *component, CScope *scope, std::vector<CECFGNode*> *bb_to_ecfg_map);
   void InitScope(t_scopetype type,
                       std::string name,
                       CComponent<CFlowGraphNode> *component,
                       CScopeGraph *scope_graph,
                       CCallGraphNode *call_graph_node,
                       CScope *enclosing_function_scope,
                       std::vector<CECFGNode*> *cfg_to_ecfg_map,
                       std::list<std::pair<CECFGNode*, CECFGNode*> > *pending_edges,
                       CECFGNode *calling_node=NULL);

   CScope(const CScope &theother);
   const CScope & operator = (const CScope &theother);
};

#endif
