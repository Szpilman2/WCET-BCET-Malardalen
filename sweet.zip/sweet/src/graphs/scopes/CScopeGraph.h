// $Id: CScopeGraph.h 2201 2010-05-28 09:56:29Z ael01 $

#ifndef CSCOPEGRAPH_H_
#define CSCOPEGRAPH_H_

#include "graphs/tools/CGraph.h"
#include "graphs/scopes/CScope.h"
#include <iostream>
#include <set>
#include <vector>
#include <map>

class CGenericFunction;
// class CScope;
class CECFG;
class CECFGNode;
class CGlobalValueCollector;
class CCallGraphNode;
class OutputSettings;
class CScopeGraphEdgeAnnot;

class CScopeGraph : public CGraph <CScope, CScopeGraphEdgeAnnot>
{
public:

   CScopeGraph(CECFG *ecfg=NULL);
   ~CScopeGraph();

   // Functions for convenient access to scopes (using functionality exported by CGraph)
   int inline unsigned NrOfScopes(void) const { return NrOfNodes(); }
   inline CScope * ScopeAt(unsigned i) const { return NodeAt(i); }
   typedef node_iterator scope_iterator;
   inline scope_iterator ScopesBegin() { return NodesBegin(); }
   inline scope_iterator ScopesEnd() { return NodesEnd(); }

   // To get all function scopes. Will not include recursive scopes. 
   void FunctionScopes(std::vector<CScope*> * scopes) const;
   unsigned NrOfFunctionScopes() const;
   // To get all loop scopes in the scope graph. 
   void LoopScopes(std::vector<CScope*> * scopes) const;
   unsigned NrOfLoopScopes() const;
   // Returns a pointer to a set of function scopes over the function `function'. This is 
   // becuase the same function may occur at several places in the same scope graph.
   const std::set<CScope *> *ScopesOfFunction(CGenericFunction *function) const ;
   // To get the root scope
   inline CScope * RootScope() { return Root(); }
   // Get all the leaf scopes. Returns the number of leaf scopes in
   // the vector.
   unsigned LeafScopes(std::vector<CScope*> * leaves) const;
   unsigned NrOfLeafScopes() const;

   // To get a pointer to the (possibly context sensitive) interprocedural "extended" flow
   // graph of this scope graph. The returned object does not belong to the caller.
   CECFG *ECFG() { return _ecfg; }
   CECFG const* ECFG() const { return _ecfg; }

   // Get all the ecfg nodes of the scope graph. 
   void ECFGNodes(std::set<CECFGNode*>* nodes);
   // To get all ecfg nodes in the scope graph that begin a basic block.
   void ECFGNodesThatBeginBasicBlocks(std::set<CECFGNode*>* nodes) const;
   // To get all ecfg nodes in the scope graph that end a basic block.
   void ECFGNodesThatEndBasicBlocks(std::set<CECFGNode*>* nodes) const;

   // Maintain the mapping that can be retrieved by the above `ScopesOfFunction'.
   void MapFunctionToScope(CScope *function_scope);

   /** \return A number that is unique for all calls with the same \a call_graph_node. */
   unsigned UniqueCallNumber(CCallGraphNode *call_graph_node);

   /** Prints the files with the analysis result */
   void PrintTCD(std::ostream &o);

   /** Prints the files with the analysis result */
   void PrintFlowFactFile(std::ostream &o);

   // Special twist, we want to end the analysis at some special nodes.
   // Prints the files with the analysis result
   void PrintFlowFactFileSpecialExit(std::ostream &o, std::set<std::string> * exit_bb_names);
   void PrintFlowFactFileSpecialExit(std::ostream &o, std::set<std::string> * exit_bb_names, std::string inital_text);


   void SetECFG(CECFG *ecfg) { _ecfg = ecfg; }

   // Checks if the scope graph includes recursive scopes
   bool HasRecursiveScopes() const;

private:
   std::vector<std::set<CScope *> *> _function_to_scope; // A mapping from functions to a set of scopes over the functions
   std::vector<unsigned> _function_id_to_unique_number; // A mapping from function ids to a unique number for each call to a function
   CECFG *_ecfg;
}; 


#endif
