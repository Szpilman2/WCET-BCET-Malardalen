// $Id: CreateScopes.cpp 5407 2013-06-16 14:52:16Z lkg02 $

#include "CreateScopes.h"
#include "CScopeGraph.h"
#include "CScope.h"
#include "program/CGenericFunction.h"
#include "program/CGenericStmt.h"
#include "graphs/cfg/CFlowGraph.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "graphs/components/CComponent.h"
#include "graphs/components/CComponentTree.h"
#include "graphs/ecfg/CECFG.h"
#include "graphs/ecfg/CECFGNode.h"
#include "graphs/cg/CCallGraph.h"
#include <cassert>
#include <vector>
#include <list>
#include <sstream>

using namespace std;

static void CreateLoopScope(CComponent<CFlowGraphNode> *scc, CScopeGraph *scope_graph, vector <CECFGNode*> *cfg_to_ecfg_map,
                            CScope *parent, int loopcounter);
static void ExpandLoopScopeTree(CComponent<CFlowGraphNode> *component, CScopeGraph *scope_graph,
                                vector <CECFGNode*> *cfg_to_ecfg_map, CScope *scope);
static void AddLoopExitEdges(CScope *scope);
static void ExtendScopeWithOtherFunctionsInThisRecursion(CScope *scope, CCallGraph *call_graph, CCallGraphNode *call_graph_node, list <pair<CECFGNode*, CECFGNode*> > *pending_edges, const CSymTabBase *symtab, const CSteensgaardPA &pa);

// Creates a loop scope tree.
static void CreateLoopScope(CComponent<CFlowGraphNode> *scc, CScopeGraph *scope_graph, vector <CECFGNode*> *cfg_to_ecfg_map,
                            CScope *parent, int loopcounter)
{
   
   CScope *scope = new CScope(scc, cfg_to_ecfg_map, parent, loopcounter);
   // ...and the scope graph:
   scope_graph->AddNode(scope);
   scope_graph->AddEdge(parent, scope);

   // (No more edges are needed in the ecfg due to a loop scope)

   ExpandLoopScopeTree(scc, scope_graph, cfg_to_ecfg_map, scope);

}

// Just spawns to the eventual loop-scope kids
static void ExpandLoopScopeTree(CComponent<CFlowGraphNode> *component, CScopeGraph *scope_graph,
                                vector <CECFGNode*> *cfg_to_ecfg_map, CScope *scope)
{
   
   int loopcounter = 1; // The loop-counter :-)
   for (CComponent<CFlowGraphNode>::kid_iterator scc=component->KidBegin(); scc!=component->KidEnd(); scc++) {
      CreateLoopScope(scc->node, scope_graph, cfg_to_ecfg_map, scope, loopcounter++);
   }

}

// The exit edges concerning loops can not be identified during the build process, since the target loop scope of an
// exit edge might not have been created when processing a certain loop. Therefore we have to run a separate pass
// over the sub tree consisting of a function root and all nested loops within that function, to find all
// loop-related exit-edges (into and out from loop scopes but not out from the function scope).
static void AddLoopExitEdges(CScope *scope)
{
   
   // Don't add exit edges from this function to some other function, only the loop-related exit edges should be added.
   // Exit edges to other functions starts at the basic block with the return statement.
   for (CScope::ecfg_nodes_iterator ecfg_node=scope->ECFGNodesBegin(); ecfg_node!=scope->ECFGNodesEnd(); ecfg_node++) {
      for (CECFGNode::succ_iterator succ=(*ecfg_node)->SuccBegin(); succ!=(*ecfg_node)->SuccEnd(); succ++) {
         if (succ->node->Scope() != scope) {
            // The scope of the destination ecfg-node is not this scope, then this must be an exit edge.
            // .. but we must avoid nodes representing the return statement..
            if ((*ecfg_node)->GetFlowGraphNode()->Stmt()->Type() != CGenericStmt::GS_RETURN) {
               scope->AddExitEdge(*ecfg_node, succ->node);
            }
         }
      }
   }
   for (CScope::succ_iterator succ=scope->SuccBegin(); succ!=scope->SuccEnd(); succ++) {
      if (succ->node->Type() == CScope::LOOP) {
         AddLoopExitEdges(succ->node);
      }
   }

}

// `scope' must be a recursive function scope and will be extended in all respects with any other function in the same
// scc of the call graph (in case of self recursion there will be none).
// All recursive edges of the set of functions involved in this recursion (also when self recursion) will be inserted
// in the ECFG.
static void ExtendScopeWithOtherFunctionsInThisRecursion(CScope *scope, CCallGraph *call_graph, CCallGraphNode *call_graph_node, list <pair<CECFGNode*, CECFGNode*> > *pending_edges, const CSymTabBase *symtab, const CSteensgaardPA &pa)
{
   
   set <CCallGraphNode *> *recursive_functions = call_graph->RecursiveFunctionSet(call_graph_node);
   CECFG *ecfg = scope->ScopeGraph()->ECFG();
   map <CGenericFunction*, pair<CECFGNode*, CECFGNode*> > function_entry_return;
   function_entry_return[scope->Function()] = make_pair(scope->EntryNode(), scope->ReturnNode());
   if (recursive_functions->size() > 1) {
      for (set <CCallGraphNode *>::iterator mutual_function_it=recursive_functions->begin();
           mutual_function_it!=recursive_functions->end(); mutual_function_it++) {
         if (*mutual_function_it != call_graph_node) {
            // Note that the component tree has to be accessed before the bb->ecfg map is created, since the component tree
            // is not created until accessed the first time.
            CComponent<CFlowGraphNode> *root = (*mutual_function_it)->FlowGraph()->ComponentTree()->TreeRoot();

            // Create the part of the ecfg corresponding to this called function's cfg
            vector <CECFGNode*> cfg_to_ecfg_map;
            CFlowGraph *flow_graph = (*mutual_function_it)->FlowGraph();
            ecfg->ExtendWithFlowgraph(flow_graph, &cfg_to_ecfg_map, pending_edges, symtab, pa);

            // Add data to existing scope instead of creating a new
            scope->ExtendWithMututalRecursiveFunction(root, &cfg_to_ecfg_map, (*mutual_function_it)->Function());

            // Add the loops
            ExpandLoopScopeTree(root, scope->ScopeGraph(), &cfg_to_ecfg_map, scope);
            AddLoopExitEdges(scope);

            // Prepare for adding the recursive calls within the recursive functions' scope
            function_entry_return[(*mutual_function_it)->Function()] = make_pair(cfg_to_ecfg_map[root->Head()->Id()],
                                                                cfg_to_ecfg_map[flow_graph->ExitNode()->Id()]);
         }
      }
   } else {
      scope->SetSelfRecursive();
   }
   // `pending_edges' conatins edges for all <call, result> in the recursive nest, but `function_entry_return' just
   // contains the functions in the recursive nest, so only edges from recursive calls (direct or indirect within
   // the nest of recursive functions) will be added.

   // Recursive pending_edges may also be exit edges in its scope. If so we have to add it as an exit edge here, it
   // won't be discovered anywhere else
   // Exit edges are those with a source in one scope and dest in another, i.e. in this case we are actually looking
   // for recursive calls within loops.
   for (list <pair<CECFGNode*, CECFGNode*> >::iterator edge=pending_edges->begin(); edge!=pending_edges->end(); edge++) {
      CFlowGraphNode *call_bb=edge->first->GetFlowGraphNode();
      CGenericStmtCall *call_stmt = dynamic_cast<CGenericStmtCall*>(call_bb->Stmt());
      assert(call_stmt);
      list <CGenericFunction*> called_functions;
      call_stmt->CalledFunctions(&called_functions, symtab, pa);
      for (list <CGenericFunction*>::iterator func=called_functions.begin(); func!=called_functions.end(); func++) {
         map <CGenericFunction*, pair<CECFGNode*, CECFGNode*> >::iterator it = function_entry_return.find(*func);
         if (it != function_entry_return.end()) {
            // Now add the edges in the extended control flow graph
            CECFGNode *callnode = edge->first;
            CECFGNode *entrynode = function_entry_return[*func].first;

            CECFGNode *returnnode = function_entry_return[*func].second;
            CECFGNode *resultnode = edge->second;

            if (callnode->Scope() != entrynode->Scope()) {
                  // The scope of return is always the same as of the entry, and the scope of the
               // result is always the same as of the call.
               callnode->Scope()->AddExitEdge(callnode, entrynode);
               returnnode->Scope()->AddExitEdge(returnnode, resultnode);
            }
         }
      }
   }

   ecfg->AddPendingRecursiveEdges(pending_edges, &function_entry_return, symtab, pa);

}

namespace CreateScopes {

// Creates a (sub-) scope tree for an entire function, but not more
CScope *AddFunctionWithLoops(CScopeGraph *scope_graph, CCallGraph *call_graph, CCallGraphNode *call_graph_node, CECFGNode *calling_node, CECFGNode *return_to_node, const CSymTabBase *symtab, const CSteensgaardPA &pa)
{
   

   CECFG *ecfg = scope_graph->ECFG();
   if (calling_node == NULL) {
      assert(scope_graph->NrOfNodes()==0);
   } else {
      assert(ecfg->NodeAt(calling_node->Id()) == calling_node);
   }

   // Just unpack some data. Note that the component tree has to be accessed before the bb->ecfg map is created,
   // since the component tree is not created until accessed the first time.
   CFlowGraph *called_fg = call_graph_node->FlowGraph();
   CComponent<CFlowGraphNode> *root = called_fg->ComponentTree()->TreeRoot();
   CScope *calling_scope = NULL;
   if (calling_node) {
      calling_scope = calling_node->Scope();
   }

   // Create the part of the ecfg corresponding to the called function's cfg
   vector <CECFGNode*> cfg_to_ecfg_map;
   list <pair<CECFGNode*, CECFGNode*> > *pending_edges = new list <pair<CECFGNode*, CECFGNode*> > (); // A gift to the scope
   ecfg->ExtendWithFlowgraph(called_fg, &cfg_to_ecfg_map, pending_edges, symtab, pa);

   // Create the scope
   CScope *scope = new CScope(root, call_graph_node, &cfg_to_ecfg_map, pending_edges, calling_scope, calling_node, scope_graph);
   scope_graph->MapFunctionToScope(scope);

   // Add the scope to the scope graph
   scope_graph->AddNode(scope);

   // Add all in-edges to this scope (if it is not the root)
   if (calling_node) {

      scope_graph->AddEdge(calling_scope, scope);

      // Add the exit edges in the scope concerning the call to this function
      CECFGNode *entry_node = scope->EntryNode();
      list <CFlowGraphNode*> exit_nodes;
      called_fg->GetExitNodes(&exit_nodes);

      calling_scope->AddExitEdge(calling_node, entry_node);
      for (list <CFlowGraphNode*>::iterator retnode_it=exit_nodes.begin(); retnode_it!=exit_nodes.end(); retnode_it++) {
         CECFGNode *return_node = cfg_to_ecfg_map[(*retnode_it)->Id()];
         scope->AddExitEdge(return_node, return_to_node);
      }
      // Add edges in the extended control flow graph
      ecfg->AddEdge(calling_node, entry_node);
      for (list <CFlowGraphNode*>::iterator retnode_it=exit_nodes.begin(); retnode_it!=exit_nodes.end(); retnode_it++) {
         CECFGNode *return_node = cfg_to_ecfg_map[(*retnode_it)->Id()];
         ecfg->AddEdge(return_node, return_to_node);
      }

   }

   // Add the sub-scopes with loops recursively, but no sub-scopes to functions
   ExpandLoopScopeTree(root, scope_graph, &cfg_to_ecfg_map, scope);
   AddLoopExitEdges(scope);

   if (call_graph->IsRecursive(call_graph_node)) {
      ExtendScopeWithOtherFunctionsInThisRecursion(scope, call_graph, call_graph_node, pending_edges, symtab, pa);
   }


   return scope;
}

// Create a scope tree whose root scope represents the function of `call_graph_node'
CScope *ContextSensitive(CScopeGraph *scope_graph, CCallGraph *call_graph, CCallGraphNode *call_graph_node, const CSymTabBase *symtab, const CSteensgaardPA &pa)
{
   
   assert(scope_graph->NrOfNodes()==0);

   CECFG *ecfg = scope_graph->ECFG();
   // Note that the component tree has to be accessed before the bb->ecfg map is created, since the component tree
   // is not created until accessed the first time.
   CComponent<CFlowGraphNode> *root = call_graph_node->FlowGraph()->ComponentTree()->TreeRoot();

   // Create the part of the ecfg corresponding to the called function's cfg
   vector <CECFGNode*> cfg_to_ecfg_map;
   list <pair<CECFGNode*, CECFGNode*> > *pending_edges = new list <pair<CECFGNode*, CECFGNode*> > (); // A gift to the scope
   ecfg->ExtendWithFlowgraph(call_graph_node->FlowGraph(), &cfg_to_ecfg_map, pending_edges, symtab, pa);

   CScope *scope = new CScope(root, call_graph_node, &cfg_to_ecfg_map, pending_edges, NULL, NULL, scope_graph);

   scope_graph->AddNode(scope);
   scope_graph->MapFunctionToScope(scope);
   scope_graph->FindRoot();

   // Add the sub-scopes with loops recursively, but no sub-scopes to functions
   ExpandLoopScopeTree(root, scope_graph, &cfg_to_ecfg_map, scope);
   AddLoopExitEdges(scope);
   if (call_graph->IsRecursive(call_graph_node)) {
      ExtendScopeWithOtherFunctionsInThisRecursion(scope, call_graph, call_graph_node, pending_edges, symtab, pa);
   }

   scope->CompletelyExpandScopeTreesOfPendingEdges(call_graph, symtab, pa);


   return scope;
}

CScope *
ExpandContextSensitive(CScopeGraph *scope_graph, CCallGraph *call_graph, CGenericFunction *called_function,
                       CECFGNode *calling_node, CECFGNode *return_to_node, const CSymTabBase *symtab,
                       const CSteensgaardPA &pa)
{
   
   CCallGraphNode *call_graph_node = call_graph->FindNodeOfFunction(called_function);

   CScope *scope = AddFunctionWithLoops(scope_graph, call_graph, call_graph_node, calling_node, return_to_node, symtab, pa);
   scope->CompletelyExpandScopeTreesOfPendingEdges(call_graph, symtab, pa);

   return scope;
}

/** Assigns names to loop a scope forest. Descendant scopes that are not loop
   scopes will be ignored. The name of a certain scope will be the
   concatenation of its parent's name and a sequence number, hence guranteed
   to be unique within any context where its parent's name is unique.
   \param parent The scope where the forest is rooted.
   \post All loop scopes reachable from \a parent via loop scopes have names.
*/
static
void
AssignNamesToLoopScopeForest(CScope *parent)
{
   unsigned sequence_number = 0;
   for (CScope::succ_iterator kid_it=parent->SuccBegin(); kid_it != parent->SuccEnd(); ++kid_it) {
      stringstream s;
      CScope *kid = kid_it->node;
      if (kid->Type() == CScope::LOOP) {
         ++sequence_number;
         s << parent->Name() << "_L" << sequence_number;
         kid->SetName(s.str());
         AssignNamesToLoopScopeForest(kid);
      }
   }
}

/** Assigns names to scopes.
   \param scopes A list of scopes to get names. The scopes in this list will
      get the name of its function. Descendants reachable only via loop scopes
      will be assigned unique names based on their parents current name.
*/
static
void
AssignContextInsensitiveScopesNames(vector <CScope*> &scopes)
{
   for (vector <CScope*>::iterator scope_it=scopes.begin(); scope_it!=scopes.end(); ++scope_it) {
      CScope *function_scope = *scope_it;
      CGenericFunction *function= function_scope->Function();
      function_scope->SetName(function->PrettifiedName());
      AssignNamesToLoopScopeForest(function_scope);
   }
}

/** Inserts a scope tree isomorphic to a certain component tree.
   \param scope_graph The scope graph where to insert the scope tree.
   \param component The component of a component tree.
   \param func_to_scope A mapping from functions to function scopes. Loop
      scopes will not appear in this mapping.
   \param component_to_scope A mapping from components in the component
      tree to the scopes.
   \return The root scope of the added scope tree.
   \post \a scope_graph will be extended with one connected component.
      The subgraph of this connected component is a tree.
      The root node in the tree represents the function of the corrsponding
      call graph node. All other nodes in the tree represents loops within
      the function represented by the root node. The tree expresses the loop
      nesting. */
static void
InsertLoopTree(CScopeGraph *scope_graph,
               CComponent <CFlowGraphNode> *component,
               map <CComponent <CFlowGraphNode> *, CScope*> &component_to_scope,
               CScope *scope)
{
   scope_graph->AddNode(scope);
   component_to_scope[component] = scope;
   for (CComponent <CFlowGraphNode>::kid_iterator kid=component->KidBegin();
        kid!=component->KidEnd(); ++kid) {
      CComponent <CFlowGraphNode> *kid_component = kid->node;
      CScope *kid_scope = new CScope(kid_component, scope);
      scope_graph->AddEdge(scope, kid_scope, new CScopeGraphEdgeAnnot());
      InsertLoopTree(scope_graph, kid_component, component_to_scope, kid_scope);
   }
}

/** Inserts the scope trees corresponding to the loops trees in the functions
   represented by the nodes in a call graph.
   \param scope_graph The scope graph where to insert the scope trees
   \param call_graph_nodes The call graph nodes to process.
   \param func_to_scope A mapping from functions to function scopes. Updated
      with all added function scopes.
      scopes will not appear in this mapping.
   \param component_to_scope A mapping from components in the component
      tree to the scopes, updated with all added scopes.
   \param scopes A list of scopes updated with all added function scopes.
   \post \a scope_graph will be extended with the same number of connected
      components as the number of nodes reachable from \a start_node, including
      \a start_node. The subgraph of each such connected component is a tree.
      The root node in these trees represents the function of the corrsponding
      call graph node. All other nodes in such trees represents loops within
      the function represented by the root node. The tree expresses the loop
      nesting. */
static void
InsertLoopTrees(CScopeGraph *scope_graph,
                set <CCallGraphNode*> &call_graph_nodes,
                map <CGenericFunction *,CScope*> &func_to_scope,
                map <CComponent <CFlowGraphNode> *, CScope*> &component_to_scope,
                vector <CScope*> &scopes)
{
   for (set <CCallGraphNode*>::const_iterator node_it=call_graph_nodes.begin();
        node_it!=call_graph_nodes.end(); ++node_it) {
      CCallGraphNode *current_node = *node_it;
      CComponentTree <CFlowGraphNode> *component_tree = current_node->FlowGraph()->ComponentTree();
      CComponent <CFlowGraphNode> *root = component_tree->TreeRoot();
      CScope *function_scope = new CScope(root, current_node, scope_graph);
      scopes.push_back(function_scope);
      func_to_scope[current_node->Function()] = function_scope;
      InsertLoopTree(scope_graph, root, component_to_scope, function_scope);
   }
}

/** Create a mapping from flow graph nodes to the scope they belongs to.
   The mapping includes all nodes in the control flow graphs  represented
   by all components in a map.
   \param component_to_scope A mapping from components to scopes.
   \param cfg_node_to_scope A mapping from control flow graph nodes to
      scopes.*/
static void
CreateFlowGraphNodeMapping(map <CComponent  <CFlowGraphNode> *, CScope*> &component_to_scope,
                          map <CFlowGraphNode*, CScope*> &cfg_node_to_scope)
{
   for (map <CComponent  <CFlowGraphNode> *, CScope*>::iterator it=component_to_scope.begin();
        it!=component_to_scope.end(); ++it) {
      CComponent  <CFlowGraphNode> *component = it->first;
      CScope *scope = it->second;
      for (CComponent  <CFlowGraphNode>::subnode_iterator cfg_node_it=component->SubNodeBegin();
           cfg_node_it!=component->SubNodeEnd(); ++cfg_node_it) {
         CFlowGraphNode * cfg_node = *cfg_node_it;
         cfg_node_to_scope[cfg_node] = scope;
      }
   }
}

/** Inserts edges in a scope graph representing a set of call graph edges
   which in turn represents function calls.
   \param scope_graph The scope graph where to insert the scope trees
   \param call_graph_edges The edges in the call graph for which a
      corresponding edge in the scope graph should be inserted.
   \param func_to_scope A mapping from functions to function scopes. Loop
      scopes will not appear in this mapping.
   \param cfg_node_to_scope A mapping from control flow graph nodes to
      scopes.
   \post \a scope_graph is extended with edges that connects the
      scope trees rooted at the functions that are present in \a func_to_scope.
      Each edge represents a function call. Its source is the scope in the
      scope tree where the call that it represents occur and the destination
      is the root scope in the scope tree representing the called function. */
static void
AddInterproceduralEdges(CScopeGraph *scope_graph,
                        vector <CCallGraph::T_edge> &call_graph_edges,
                        map <CGenericFunction *,CScope*> &func_to_scope,
                        map <CFlowGraphNode*, CScope*> &cfg_node_to_scope)
{
   for (unsigned i=0; i<call_graph_edges.size(); ++i) {
      CGenericFunction *called_function = call_graph_edges[i].to->Function();
      CScope *called_scope = func_to_scope[called_function];
      CFlowGraphNode *call_site = call_graph_edges[i].edge_annot->CallSite();
      CScope *calling_scope = cfg_node_to_scope[call_site];
      scope_graph->AddEdge(calling_scope, called_scope, new CScopeGraphEdgeAnnot(call_site));
   }
}

/** Collects all edges reachable from a certain node in a call graph.
   \param current_node The start node.
   \param call_graph_edges The vector where to insert the found edges.
   \param done A set to keep track on which nodes in the call graph that we
      have visisted. Any node found in this set will not be added as the
      source node of an edge, but edges in to it will. */
static void
CollectCallGraphEdges(CCallGraphNode *current_node, vector <CCallGraph::T_edge> &call_graph_edges, set <CCallGraphNode*> &done)
{
   if (done.find(current_node) == done.end()) {
      done.insert(current_node);
      for (CCallGraphNode::succ_iterator succ=current_node->SuccBegin();
           succ!=current_node->SuccEnd(); succ++) {
         CCallGraph::T_edge edge = {current_node, succ->node, succ->edge_annot};
         call_graph_edges.push_back(edge);
         CollectCallGraphEdges(succ->node, call_graph_edges, done);
      }
   }
}

void
ScopeDAG(CScopeGraph *scope_graph, CCallGraphNode *start_node)
{
   map <CGenericFunction *,CScope*> func_to_scope;
   map <CComponent  <CFlowGraphNode> *, CScope*> component_to_scope;
   map <CFlowGraphNode*, CScope*> cfg_node_to_scope;
   set <CCallGraphNode*> call_graph_nodes;
   vector <CCallGraph::T_edge> call_graph_edges;
   vector <CScope*> scopes;
   CollectCallGraphEdges(start_node, call_graph_edges, call_graph_nodes);
   InsertLoopTrees(scope_graph, call_graph_nodes, func_to_scope, component_to_scope, scopes);
   CreateFlowGraphNodeMapping(component_to_scope, cfg_node_to_scope);
   AddInterproceduralEdges(scope_graph, call_graph_edges, func_to_scope, cfg_node_to_scope);
   scope_graph->FindRoot();
   AssignContextInsensitiveScopesNames(scopes);
}

static
void
MapCFGNodeToContext(vector <vector<CECFGNode*> > &cfg_node_to_ecfg_node, CScope *scope,
                    CFlowGraphNode *cfg_node, CECFGNode *ecfg_node)
{
   if ((unsigned)scope->Id() >= cfg_node_to_ecfg_node.size()) {
      cfg_node_to_ecfg_node.resize(scope->Id() + 1);
   }
   if ((unsigned)cfg_node->Id() >= cfg_node_to_ecfg_node[scope->Id()].size()) {
      cfg_node_to_ecfg_node[scope->Id()].resize(cfg_node->Id() + 1);
   }
   cfg_node_to_ecfg_node[scope->Id()][cfg_node->Id()] = ecfg_node;
}

static
CECFGNode *
GetECFGNodeInContext(vector <vector<CECFGNode*> > &cfg_node_to_ecfg_node, const CScope *scope, const CFlowGraphNode *cfg_node)
{
   return cfg_node_to_ecfg_node[scope->Id()][cfg_node->Id()];
}


/** Set up a mapping from components to scopes. Components are actually not unique wrt scopes,
   but given some scope of the component's tree it has a unique scope in that context. That is
   what is set up here.
   */
static
void
CreateComponentToScopeMap(map <CScope*, map <CComponent  <CFlowGraphNode>*, CScope*> > &component_to_scope, CScopeGraph *scope_graph)
{
   for (unsigned i=0; i<(unsigned)scope_graph->NrOfNodes(); ++i) {
      CScope *scope = scope_graph->NodeAt(i);
      CComponent<CFlowGraphNode> *component = scope->Component();
      component_to_scope[scope->FunctionScope()][component] = scope;
   }
}

static
CScope *
GetScopeOfComponentWithinLoopTree(map <CScope*, map <CComponent  <CFlowGraphNode>*, CScope*> > &component_to_scope,
                                           CScope *scope, CComponent  <CFlowGraphNode> *component)
{
   return component_to_scope[scope->FunctionScope()][component];
}

/** Creates ecfg-nodes for a number of scopes. The nodes are added to the graph as well
   as to its scope.
   \param scopes The scopes to be generated ecfg nodes for.
   \param ecfg The graph where to insert the ecfg-nodes.
   \param cfg_node_to_ecfg_node A mapping from cfg nodes to its corrsponding ecfg node
      in a certain scope.
   \post All created ecfg nodes (that is one for each cfg-node in all of the scopes) are
      added to \a ecfg and to ist corresponding scope and the corresponding (cfg,scope)
      maps to it. */
static
void
AddECFGNodes(vector <CScope*> &scopes, CECFG *ecfg, vector <vector<CECFGNode*> > &cfg_node_to_ecfg_node)
{
   for (unsigned i=0; i<scopes.size(); ++i) {
      CScope *scope = scopes[i];
      CComponent<CFlowGraphNode> *component = scope->Component();
      for (CComponent  <CFlowGraphNode>::subnode_iterator cfg_node_it=component->SubNodeBegin();
           cfg_node_it!=component->SubNodeEnd(); ++cfg_node_it) {
         CFlowGraphNode * cfg_node = *cfg_node_it;
         CECFGNode *ecfg_node = new CECFGNode(cfg_node, scope);
         ecfg->AddNode(ecfg_node);
         MapCFGNodeToContext(cfg_node_to_ecfg_node, scope, cfg_node, ecfg_node);
         scope->AddECFGNode(ecfg_node);
      }
      scope->SetHeader(GetECFGNodeInContext(cfg_node_to_ecfg_node, scope, component->Head()));
      if (scope->Type() == CScope::LOOP) {
         scope->SetEntryNode(GetECFGNodeInContext(cfg_node_to_ecfg_node, scope, component->Head()));
      } else {
         // Function entries may not be the same as the header - pick it from the flow graph instead
         scope->SetEntryNode(GetECFGNodeInContext(cfg_node_to_ecfg_node, scope, scope->CallGraphNode()->FlowGraph()->GetEntry()));
      }
   }
}

/** Creates ecfg-edges for a number of scopes. The edges are added to the graph.
   Only edges representing the program flow local to function are considered
   (flow graph edges).
   \param scopes The scopes to be generated local ecfg edges for.
   \param ecfg The graph where to insert the ecfg edges.
   \param cfg_node_to_ecfg_node A mapping from cfg nodes to its corrsponding ecfg node
      in a certain scope.
   \param component_to_scope A mapping from components to its corresponding scope in the
      context of some other scope.
   \post All created ecfg edges are added to \a ecfg and all edges that are not internal
      to a scope are added to its corresponding source scope. */
static
void
AddECFGLocalEdges(vector <CScope*> &scopes, CECFG *ecfg, vector <vector<CECFGNode*> > &cfg_node_to_ecfg_node,
    map <CScope*, map <CComponent  <CFlowGraphNode>*, CScope*> > &component_to_scope)
{
   // Check out-edges from all cfg-nodes: they are either exit-edges (i.e. dest is in
   // another component/scope in the same component tree or they are internal to the
   // component/scope.
   // At this stage we only process edges within a function (i.e. edges between
   // sub-nodes in a component tree of a function.
   for (unsigned i=0; i<scopes.size(); ++i) {
      CScope *scope = scopes[i];
      CComponent<CFlowGraphNode> *component = scope->Component();
      CCallGraphNode *call_graph_node = scope->CallGraphNode();
      CFlowGraph *flow_graph = call_graph_node->FlowGraph();
      for (CComponent  <CFlowGraphNode>::subnode_iterator cfg_node_it=component->SubNodeBegin();
           cfg_node_it!=component->SubNodeEnd(); ++cfg_node_it) {
         CFlowGraphNode * cfg_node = *cfg_node_it;
         for (CFlowGraphNode::succ_iterator succ_it=cfg_node->SuccBegin(); succ_it!=cfg_node->SuccEnd(); ++succ_it) {
            CFlowGraphNode *succ_node = succ_it->node;
            CComponent<CFlowGraphNode> *succ_component = flow_graph->ComponentOfNode(succ_node);
            // Since we are in the same flow graph the succ component must be in the component tree
            // of the current scope
            CScope *dest_scope = GetScopeOfComponentWithinLoopTree(component_to_scope, scope, succ_component);
            CECFGNode *src_node = GetECFGNodeInContext(cfg_node_to_ecfg_node, scope, cfg_node);
            CECFGNode *dest_node = GetECFGNodeInContext(cfg_node_to_ecfg_node, dest_scope, succ_node);
            if (flow_graph->ComponentOfNode(succ_node) == component) {
               // Internal
            } else {
               // Exit edge: either into or out from a loop within the same function scope.
               scope->AddExitEdge(src_node, dest_node);
            }
            ecfg->AddEdge(src_node, dest_node, new CECFGEdgeAnnot(succ_it->edge_annot));
         }
      }
   }
}

/** Creates back-edges for a number of scopes. The edges are added to their corresponding
   scope graph.
   \param scopes The scopes to be generated back edges for.
   \param cfg_node_to_ecfg_node A mapping from cfg nodes to its corrsponding ecfg node
      in a certain scope.
   \post All created back edges are added to its corresponding source scope. */
static
void
AddScopeBackEdges(vector <CScope*> &scopes, vector <vector<CECFGNode*> > &cfg_node_to_ecfg_node)
{
   // Check out-edges from all cfg-nodes: they are either exit-edges (i.e. dest is in
   // another component/scope in the same component tree or they are internal to the
   // component/scope.
   // At this stage we only process edges within a function (i.e. edges between
   // sub-nodes in a component tree of a function.
   for (unsigned i=0; i<scopes.size(); ++i) {
      CScope *scope = scopes[i];
      CComponent<CFlowGraphNode> *component = scope->Component();
      for (CComponent<CFlowGraphNode>::backedge_iterator back_edge=component->BackedgeBegin();
           back_edge!=component->BackedgeEnd(); back_edge++) {
         CECFGNode *src_node = GetECFGNodeInContext(cfg_node_to_ecfg_node, scope, back_edge->first);
         CECFGNode *dest_node = GetECFGNodeInContext(cfg_node_to_ecfg_node, scope, back_edge->second);
         scope->AddBackedge(src_node, dest_node);
      }
   }
}

/** Creates ecfg-edges for a number of scopes. The edges are added to the graph.
   Only edges representing the interprocedural program flow are considered
   (call graph edges).
   \param scopes The scopes to be generated interprocedural ecfg edges for.
   \param ecfg The graph where to insert the ecfg edges.
   \param cfg_node_to_ecfg_node A mapping from cfg nodes to its corrsponding ecfg node
      in a certain scope.
   \post All created ecfg edges are added to \a ecfg and to its corresponding source scope. */
static
void
AddECFGInterproceduralEdges(vector <CScope*> &scopes, CECFG *ecfg, vector <vector<CECFGNode*> > &cfg_node_to_ecfg_node)
{
   for (unsigned i=0; i<scopes.size(); ++i) {
      CScope *scope = scopes[i];
      for (CScope::succ_iterator succ_it=scope->SuccBegin(); succ_it!=scope->SuccEnd(); ++succ_it) {
         CScopeGraphEdgeAnnot *annot = succ_it->edge_annot;
         if (annot->RepresentsFunctionCall()) {
            CScope *dest_scope = succ_it->node;
            const CFlowGraphNode *call_node = annot->FlowGraphNodeOfFunctionCall();
            CECFGNode *src_node = GetECFGNodeInContext(cfg_node_to_ecfg_node, scope, call_node);
            CComponent<CFlowGraphNode> *dest_component = dest_scope->Component();
            CFlowGraphNode *header_node = dest_component->Head();
            CECFGNode *dest_node = GetECFGNodeInContext(cfg_node_to_ecfg_node, dest_scope, header_node);
            scope->AddExitEdge(src_node, dest_node);
            ecfg->AddEdge(src_node, dest_node, new CECFGEdgeAnnot());
         }
      }
   }
}

CECFG *
ECFG(CScopeGraph *scope_graph)
{
   CECFG *ecfg = new CECFG(scope_graph);
   vector <vector<CECFGNode*> > cfg_node_to_ecfg_node;
   vector <CScope*> scopes;
   for (unsigned i=0; i<(unsigned)scope_graph->NrOfNodes(); ++i) {
      scopes.push_back(scope_graph->NodeAt(i));
   }

   map <CScope*, map <CComponent  <CFlowGraphNode>*, CScope*> > component_to_scope;
   CreateComponentToScopeMap(component_to_scope, scope_graph);

   AddECFGNodes(scopes, ecfg, cfg_node_to_ecfg_node);
   AddECFGLocalEdges(scopes, ecfg, cfg_node_to_ecfg_node, component_to_scope);
   AddScopeBackEdges(scopes, cfg_node_to_ecfg_node);
   AddECFGInterproceduralEdges(scopes, ecfg, cfg_node_to_ecfg_node);
   return ecfg;
}

CScopeGraph *ScopeDAG(CCallGraphNode *start_node)
{
   CScopeGraph *scope_graph = new CScopeGraph();
   ScopeDAG(scope_graph, start_node);
   CECFG *ecfg = ECFG(scope_graph);
   scope_graph->SetECFG(ecfg);
   return scope_graph;
}

}
