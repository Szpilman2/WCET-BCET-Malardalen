// $Id: CreateScopes.h 1080 2009-09-29 15:12:41Z csg01 $

#ifndef CREATE_SCOPES_H_
#define CREATE_SCOPES_H_

class CGenericFunction;
class CScopeGraph;
class CScope;
class CECFGNode;
class CCallGraph;
class CCallGraphNode;
class CSymTabBase;
class CSteensgaardPA;
class CECFG;

namespace CreateScopes {
/** Creates a scope tree as well as an ecfg graph over the function \a called_function. I.e. one scope for
   \a called_function and for each loop in \a called_function one additional scope - no scopes will be
   created for functions called by \a called_function. The scopes will form a tree following the loop
   structure in the \a called_function which will be the root in that tree. The tree will be inserted
   at the point indicated by \a calling_node when present.
   ecfg nodes and edges representing all code of the new scopes will be added to the ecfg of \a scope_graph.
   \pre \a scope_graph is empty or \a calling_node is a node whose statement is calling  \a called_function.
   \param scope_graph A graph where to insert the new scope tree.
   \param call_graph A call graph where to generate the scopes from.
   \param call_graph_node The call graph node of the function within \a call_graph that \a scope_graph spans.
   \param calling_node If present it is a node of the ecfg of \a scope_graph that has a call statement
      calling \a called_function.
   \param symtab A pointer to a symbol table of the ast we are working on
   \param pa A refrerence to a pointer analysis of the ast we are working on
   \post The returned tree is inserted into \a scope_graph and an edge is inserted from the scope of
      calling_node to the root of the new tree. The ecfg is extended with one node for each node in
      \a called_function and with edges according to the intra- and interprocedural flow (ref. ecfg).
   \return A pointer to the root node of the new scope tree.
*/
CScope *AddFunctionWithLoops(CScopeGraph *scope_graph, CCallGraph *call_graph, CCallGraphNode *call_graph_node, CECFGNode *calling_node, const CSymTabBase *symtab, const CSteensgaardPA &pa);

/** Creates a context sensitive scope graph starting at `function', i.e. the graph will have the form of a tree
   where `function' is the root. The graph is completely expanded, i.e. `function' and all code reachable from
   `function' will be included. ecfg nodes and edges representing all code of the new scopes will be added to
   the ecfg of \a scope_graph.
   \pre \a scope_graph is empty
   \param scope_graph A graph where to insert the new scopes.
   \param call_graph A call graph where to generate the scopes from. The root node in \a call_graph will be
      the root node in \a scope_graph.
   \param call_graph_node The call graph node of the function within \a call_graph that \a scope_graph spans.
   \param symtab A pointer to a symbol table of the ast we are working on
   \param pa A refrerence to a pointer analysis of the ast we are working on
   \return A pointer to the root node of the new scope tree.
*/
CScope *ContextSensitive(CScopeGraph *scope_graph, CCallGraph *call_graph, CCallGraphNode *call_graph_node, const CSymTabBase *symtab, const CSteensgaardPA &pa);

/** A non-empty scope graph will be extended with scopes representing the code that is reachable from
   \a calling_node. The new scope generation will be made in a context sensitive manner, i.e. they will form
   a tree and \a called_function will be the root in that tree.
   ecfg nodes and edges representing all code of the new scopes will be added to
   the ecfg of \a scope_graph.
   \param scope_graph A graph where to insert the new scopes.
   \param call_graph A call graph where to generate the scopes from.
   \param called_function A function within the call graph that \a scope_graph spans.
   \param calling_node A node of the ecfg of \a scope_graph that has a call statement that calls \a called_function
   \param return_to_node A node of the ecfg of \a scope_graph that has a return to statement that \a called_function
         should return to when execution is finished.
   \param symtab A pointer to a symbol table of the ast we are working on
   \param pa A refrerence to a pointer analysis of the ast we are working on
   \return A pointer to the root node of the new scope tree.
*/
CScope *ExpandContextSensitive(CScopeGraph *scope_graph, CCallGraph *call_graph, CGenericFunction *called_function, CECFGNode *calling_node, CECFGNode *return_to_node, const CSymTabBase *symtab, const CSteensgaardPA &pa);

/** Add scopes to a scope graph in a context-insensitive manner, functions will be
   represented by a single scope. Each function call is represented by a unique edge
   making the graph to a multigraph.
   \param scope_graph The scope graph where to add the new scopes.
   \param start_node The call graph node where to start scanning for code.
*/
void ScopeDAG(CScopeGraph *scope_graph, CCallGraphNode *start_node);

/** Add scopes to a new scope graph in a context-insensitive manner, functions will be
   represented by a single scope. Each function call is represented by a unique edge
   making the graph to a multigraph. A new ECFG will be created and inserted into the
   scope graph.
   \param start_node The call graph node where to start scanning for code.
   \return The new scope graph
*/
CScopeGraph *ScopeDAG(CCallGraphNode *start_node);

/** Creates a new ECFG spanning the sub nodes in a scope graph.
   \param scope_graph The scope graph whose cfg-nodes will be wrapped with
      ecfg-nodes.
   \return The new ECFG.
*/
CECFG *ECFG(CScopeGraph *scope_graph);


}

#endif
