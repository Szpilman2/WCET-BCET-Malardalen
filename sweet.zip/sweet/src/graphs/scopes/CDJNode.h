// $Id: CDJNode.h 327 2009-05-06 08:55:06Z msl01 $

#ifndef CDJNODE_H_
#define CDJNODE_H_

#include <set>
#include <list>
#include <map>
#include <iostream>
#include "CDJEdge.h"

typedef enum {COL_WHITE, COL_GRAY, COL_BLACK, COL_ROSE, COL_RED} t_color;
template <typename T_Sub_Node>
class CDJNode
{
private:
   std::set<T_Sub_Node*> _sub_nodes;
   // Both _in and _out maps theother node to the edge between this and theother
   std::map<CDJNode <T_Sub_Node>*, CDJEdge <T_Sub_Node>*> _out;
   std::map<CDJNode <T_Sub_Node>*, CDJEdge <T_Sub_Node>*> _in;
   CDJNode <T_Sub_Node> *_idom;
   std::set<CDJNode <T_Sub_Node>*> _dominators;
   int _level;
   int _id;
   bool _deprecated;
   t_color _col;
   void GiveUp(CDJNode <T_Sub_Node> *eater);
   void FindIrreducibleLoop(int level, std::set<CDJNode <T_Sub_Node>* >*, std::set<T_Sub_Node*> *fgloopnodes, std::list<CDJNode <T_Sub_Node> *  > *);
   bool RedirectOutEdge(CDJNode <T_Sub_Node> *current, CDJNode <T_Sub_Node> *newone);
   bool RedirectInEdge(CDJNode <T_Sub_Node> *current, CDJNode <T_Sub_Node> *newone);
public:
   CDJNode(T_Sub_Node*);
   ~CDJNode(void);
   void CatenateSuccessors(std::list<CDJNode <T_Sub_Node>*> *succ) const;
   void CatenateOutEdges(std::list<CDJEdge <T_Sub_Node>*> *edges) const;
   void PrintDJNode(void);
   std::ostream &Print(std::ostream &o);
   void Eat(CDJNode <T_Sub_Node> *);
   void EdgeIn(CDJEdge <T_Sub_Node> *e);
   void EdgeOut(CDJEdge <T_Sub_Node> *e);
   bool IsDestinationOfCJEdgeAndSpBackedge(void) const;
   bool IsDestinationOfBJEdge(void) const;

   void RemoveIncomingEdge(const CDJEdge<T_Sub_Node> *e) { _in.erase(e->Tail()); }
   void RemoveOutgoingEdge(const CDJEdge<T_Sub_Node> *e) { _out.erase(e->Head()); }
   int Id(void) const { return _id; }
   int Level(void) const { return _level; }
   const std::set<T_Sub_Node*> *FGNodes(void) const { return &_sub_nodes; }
   void InsertDominators(const std::set<CDJNode<T_Sub_Node>*> &dominators) { _dominators = dominators; _level = _dominators.size() - 1; }
   bool  operator<(const CDJNode<T_Sub_Node> &theother) const { return _level >= theother._level; }
   bool Done(void) { return _col != COL_WHITE; }


   /* Collect all sp backedges of the current node into 'bes' */
   void GetBackedgesSources(std::set<CDJNode <T_Sub_Node>* > *bes) const;

   /* If current node is below 'head' then add it to 'loopnodes' and recurse
   all predecessors */
   void CollectPredessors(const CDJNode <T_Sub_Node> *head, std::set<CDJNode <T_Sub_Node>*> *loopnodes);

   /* Marks the node as deprecated */
   void Deprecated(void) { _deprecated = true; }

   /* True if the node is deprecated */
   bool IsDeprecated(void) const { return _deprecated; }

   /* Recursively paints all nodes in the DJ-graph WHITE */
   void Clear(void);

   /* Recurses the sub graph that can be reached from the current node to
   identify a loop using the 5-color method */
   void FindIrreducibleLoop(int level, std::set<CDJNode <T_Sub_Node>*> *djnodes, std::set<T_Sub_Node*> *fgloopnodes);

   /* Checks the current node for all incoming edges. If the current node has
   at least one edge that originates from outside 'loop' it will put into
   'targets'. Also the fg-nodes actually fulfilling this edge will be put
   into 'fgnodes' */
   bool IsTargetOfInEdgesFromOutsideLoop(std::set<CDJNode <T_Sub_Node>*> *loop);

   /* Checks the current node for all incoming edges. All edges that originates
   from inside 'loop' will be collected into 'bes' */
   void SourceOfInEdgesFromInsideLoop(std::set<CDJNode <T_Sub_Node>*> *loop, std::set<std::pair<T_Sub_Node*, T_Sub_Node*> > *bes);

   // Just to be used for logging:
   void PrintSubNodesAsSet(std::ostream &) const; // Print the set of sub-nodes (no new line).
   void PrintEdges(std::ostream &, std::map<CDJNode <T_Sub_Node>*, CDJEdge <T_Sub_Node>*> *edges) const; // Print the specified list of all DJ-edges (no new line).
   void PrintDJNode(std::ostream &o) const; // Print the subnodes and all in- and out-DJedges (all on one line).
   void Print(std::ostream &o) const; // Print complete data about this DJ node (multiple lines).
};

template <typename T_Sub_Node>
CDJNode<T_Sub_Node>::~CDJNode(void)
{
   typename std::map<CDJNode<T_Sub_Node>*, CDJEdge<T_Sub_Node>*> ::iterator ite;
   for (ite = _in.begin(); ite != _in.end(); ite++) {
      delete ite->second;
   }
   for (ite = _out.begin(); ite != _out.end(); ite++) {
      delete ite->second;
   }
}

template <typename T_Sub_Node>
CDJNode<T_Sub_Node>::CDJNode(T_Sub_Node *nd)
{
   _sub_nodes.insert(nd);
   _deprecated = false;
   _idom = NULL;
   _id = nd->Id();
}

template <typename T_Sub_Node>
void CDJNode<T_Sub_Node>::CatenateSuccessors(std::list<CDJNode<T_Sub_Node>*> *succ) const
{
   typename std::map<CDJNode<T_Sub_Node>*, CDJEdge<T_Sub_Node>*>::const_iterator it;
   for (it = _out.begin(); it != _out.end(); it++) {
      if (it->first->_level > _level)
         succ->push_back(it->first);
   }
}

template <typename T_Sub_Node>
void CDJNode<T_Sub_Node>::CatenateOutEdges(std::list<CDJEdge<T_Sub_Node>*> *edges) const
{
   typename std::map<CDJNode<T_Sub_Node>*, CDJEdge<T_Sub_Node>*>::const_iterator it;
   for (it = _out.begin(); it != _out.end(); it++)
      edges->push_back(it->second);
}

template <typename T_Sub_Node>
bool CDJNode<T_Sub_Node>::RedirectOutEdge(CDJNode<T_Sub_Node> *current, CDJNode<T_Sub_Node> *newone)
{
   if (_out.find(current) == _out.end())
      return false; // already done
   CDJEdge<T_Sub_Node> *e = _out[current];
   _out.erase(current);
   if (_out.find(newone) == _out.end()) {
      _out[newone] = e;
      newone->_in[this] = e;
      e->Head(newone);
   } else
      delete e;
   return true;
}

template <typename T_Sub_Node>
bool CDJNode<T_Sub_Node>::RedirectInEdge(CDJNode<T_Sub_Node> *current, CDJNode<T_Sub_Node> *newone)
{
   if (_in.find(current) == _in.end())
      return false; // already done
   CDJEdge<T_Sub_Node> *e = _in[current];
   _in.erase(current);
   if (_in.find(newone) == _in.end()) {
      _in[newone] = e;
      newone->_out[this] = e;
      e->Tail(newone);
   } else {
      delete e;
   }
   return true;
}

template <typename T_Sub_Node>
void CDJNode<T_Sub_Node>::GiveUp(CDJNode<T_Sub_Node> *eater)
{
   typename std::map<CDJNode<T_Sub_Node>*, CDJEdge<T_Sub_Node>*> ::iterator ite;
   bool redirected;

   // Tell the owner of the tail that is a new head
   do {
      redirected = false;
      for (ite = _in.begin(); ite != _in.end(); ite++)  {
         if (ite->second->Head() != ite->second->Tail()) { // skip self loops
            redirected = ite->first->RedirectOutEdge(this, eater);
            if (redirected)
               break;
         }
      }
   } while (redirected);
   _in.clear();

   // ... the same procedure for out-edges
   do {
      redirected = false;
      for (ite = _out.begin(); ite != _out.end(); ite++) {
         if (ite->second->Head() != ite->second->Tail()) {
            redirected = ite->first->RedirectInEdge(this, eater);
            if (redirected)
               break;
         }
      }
   } while (redirected);
   _out.clear();
}

template <typename T_Sub_Node>
void CDJNode<T_Sub_Node>::Eat(CDJNode<T_Sub_Node> *theother)
{
   typename std::set<T_Sub_Node*> ::iterator it;
   typename std::map<CDJNode<T_Sub_Node>*, CDJEdge<T_Sub_Node>*> ::iterator ite;
   bool deleted;

   if (theother == this) {
      _in.erase(this);
      _out.erase(this);
   } else {
      for (it = theother->_sub_nodes.begin(); it != theother->_sub_nodes.end(); it++)
         _sub_nodes.insert(*it);
      theother->GiveUp(this);
      // Self loops may have occured
      do {
         deleted = false;
         for (ite = _in.begin(); ite != _in.end(); ite++) {
            if (ite->first == this) {
               delete ite->second;
               deleted = true;
               break;
            }
         }
      } while (deleted);
   }
}

/* Adds a new incoming edge. Classifis a J edge as CJ of BJ according dominance */
template <typename T_Sub_Node>
void CDJNode<T_Sub_Node>::EdgeIn(CDJEdge<T_Sub_Node> *e)
{
   _in[e->Tail()] = e;
   switch (e->Type()) {
   case EDGE_J:
      if (e->Tail() != _idom) {
         if (e->Tail()->_dominators.find(this) == e->Tail()->_dominators.end())
            e->Type(EDGE_CJ);
         else
            e->Type(EDGE_BJ);
      }
      break;
   case EDGE_D:
      _idom = e->Tail();
   default:;
   }
}

/* Adds a new outgoing edge. Classifis a J edge as CJ of BJ according dominance */
template <typename T_Sub_Node>
void CDJNode<T_Sub_Node>::EdgeOut(CDJEdge<T_Sub_Node> *e)
{
   _out[e->Head()] = e;
   switch (e->Type()) {
   case EDGE_J:
      if (e->Head()->_idom != this) {
         if (_dominators.find(e->Head()) == _dominators.end())
            e->Type(EDGE_CJ);
         else
            e->Type(EDGE_BJ);
      }
      break;
   default:;
   }
}

template <typename T_Sub_Node>
bool CDJNode<T_Sub_Node>::IsDestinationOfCJEdgeAndSpBackedge(void) const
{
   typename std::map<CDJNode<T_Sub_Node>*, CDJEdge<T_Sub_Node>*> ::const_iterator it;
   for (it = _in.begin(); it != _in.end(); it++)
      if (it->second->Type()==EDGE_CJ && it->second->IsSpBack())
         return true;
   return false;
}

template <typename T_Sub_Node>
bool CDJNode<T_Sub_Node>::IsDestinationOfBJEdge(void) const
{
   typename std::map<CDJNode<T_Sub_Node>*, CDJEdge<T_Sub_Node>*> ::const_iterator it;
   for (it = _in.begin(); it != _in.end(); it++)
      if (it->second->Type()==EDGE_BJ)
         return true;
   return false;
}

template <typename T_Sub_Node>
void CDJNode<T_Sub_Node>::GetBackedgesSources(std::set<CDJNode<T_Sub_Node>*> *bes) const
{
   typename std::map<CDJNode<T_Sub_Node>*, CDJEdge<T_Sub_Node>*> ::const_iterator it;
   for (it = _in.begin(); it != _in.end(); it++)
      if ((it->second->IsSpBack() && it->first->_level > _level) || it->first == this)
         bes->insert(it->first);
}

template <typename T_Sub_Node>
void CDJNode<T_Sub_Node>::CollectPredessors(const CDJNode<T_Sub_Node> *head, std::set<CDJNode<T_Sub_Node>*> *loopnodes)
{
   typename std::map<CDJNode<T_Sub_Node>*, CDJEdge<T_Sub_Node>*> ::const_iterator it;

   if (_level > head->_level && loopnodes->find(this) == loopnodes->end()) {
      loopnodes->insert(this);
      for (it = _in.begin(); it != _in.end(); it++) {
         it->first->CollectPredessors(head, loopnodes);
      }
   }
}

template <typename T_Sub_Node>
void CDJNode<T_Sub_Node>::Clear(void)
{
   typename std::map<CDJNode<T_Sub_Node>*, CDJEdge<T_Sub_Node>*> ::iterator it;

   _col = COL_WHITE;
   for (it = _out.begin(); it != _out.end(); it++)
      if (it->first->_level > _level)
         it->first->Clear();
}

template <typename T_Sub_Node>
void CDJNode <T_Sub_Node>::FindIrreducibleLoop(int level, std::set<CDJNode <T_Sub_Node>*> *djnodes, std::set<T_Sub_Node*> *fgloopnodes)
{
   std::list<CDJNode <T_Sub_Node>*> path;
   FindIrreducibleLoop(level, djnodes, fgloopnodes, &path);
}

template <typename T_Sub_Node>
void CDJNode <T_Sub_Node>::FindIrreducibleLoop(int level, std::set<CDJNode <T_Sub_Node>*> *djnodes, std::set<T_Sub_Node*> *fgloopnodes, std::list<CDJNode <T_Sub_Node>*> *path)
{
   typename std::list<CDJNode <T_Sub_Node>*> ::reverse_iterator sit;
   typename std::map<CDJNode <T_Sub_Node>*, CDJEdge<T_Sub_Node>*> ::iterator eit;
   if (_col == COL_BLACK || _level < level) {
      return;
   }
   if (_col == COL_WHITE) {
      _col = COL_GRAY;
      path->push_back(this);
      for (eit = _out.begin(); eit != _out.end(); eit++)
         eit->first->FindIrreducibleLoop(level, djnodes, fgloopnodes, path);
      if (_col == COL_ROSE) {
         _col = COL_RED;
      } else {
         _col = COL_BLACK;
      }
      path->pop_back();
   } else if (_col == COL_GRAY || _col == COL_ROSE) {
      for (sit = path->rbegin(); *sit != this && sit!=path->rend(); sit++) {
         if ((*sit)->_col == COL_GRAY) {
            (*sit)->_col = COL_ROSE;
         }
         djnodes->insert(*sit);
         for (typename std::set<T_Sub_Node*> ::iterator it = (*sit)->_sub_nodes.begin(); it != (*sit)->_sub_nodes.end(); it++) {
            fgloopnodes->insert(*it);
         }
      }
      for (typename std::set<T_Sub_Node*> ::iterator it = _sub_nodes.begin(); it != _sub_nodes.end(); it++) {
         fgloopnodes->insert(*it);
      }
      djnodes->insert(this);
      _col = COL_ROSE;
   } else { // Red
      for (sit = path->rbegin(); sit != path->rend(); sit++) {
         if ((*sit)->_col != COL_GRAY)
            break;
      }
      if (sit != path->rend()) {
         for (sit = path->rbegin(); sit != path->rend(); sit++) {
            if ((*sit)->_col == COL_GRAY)
               (*sit)->_col = COL_ROSE;
            else
               break;
            djnodes->insert(*sit);
            for (typename std::set<T_Sub_Node*> ::iterator it = (*sit)->_sub_nodes.begin(); it != (*sit)->_sub_nodes.end(); it++) {
               fgloopnodes->insert(*it);
            }
         }
      }
      _col = COL_ROSE;
   }
}

template <typename T_Sub_Node>
bool CDJNode<T_Sub_Node>::IsTargetOfInEdgesFromOutsideLoop(std::set<CDJNode <T_Sub_Node>*> *loop)
{
   typename std::map<CDJNode<T_Sub_Node>*, CDJEdge<T_Sub_Node>*> ::iterator eit;

   for (eit = _in.begin(); eit != _in.end(); eit++)
      if (loop->find(eit->first) == loop->end() && eit->second->IsRealPath())
         return true;
   return false;
}

template <typename T_Sub_Node>
void CDJNode<T_Sub_Node>::SourceOfInEdgesFromInsideLoop(std::set<CDJNode <T_Sub_Node>*> *loop, std::set<std::pair<T_Sub_Node*, T_Sub_Node*> > *bes)
{
   typename std::set<T_Sub_Node*> ::iterator nit;
   typename std::map<CDJNode<T_Sub_Node>*, CDJEdge<T_Sub_Node>*> ::iterator eit;
   typename T_Sub_Node::succ_iterator nit1;
   CDJNode <T_Sub_Node>* src;

   for (eit = _in.begin(); eit != _in.end(); eit++) {
      if (loop->find(eit->first) != loop->end()) {
         src = eit->first;
         for (nit = src->_sub_nodes.begin(); nit != src->_sub_nodes.end(); nit++) {
            for (nit1 = (*nit)->SuccBegin(); nit1 != (*nit)->SuccEnd(); nit1++) {
               if (_sub_nodes.find(nit1->node) != _sub_nodes.end()) {
                  bes->insert(make_pair(*nit, nit1->node));
               }
            }
         }
      }
   }
}

template <typename T_Sub_Node>
void CDJNode<T_Sub_Node>::PrintSubNodesAsSet(std::ostream &o) const
{
   o << "{";
   for (typename std::set<T_Sub_Node*> ::iterator it = _sub_nodes.begin(); it != _sub_nodes.end(); it++)
      o << (*it)->Id() << " ";
   o << "}";
}

template <typename T_Sub_Node>
void CDJNode<T_Sub_Node>::PrintEdges(std::ostream &o, std::map<CDJNode <T_Sub_Node>*, CDJEdge <T_Sub_Node>*> *edges) const
{
   for (typename std::map<CDJNode<T_Sub_Node>*, CDJEdge<T_Sub_Node>*> ::iterator edge=edges->begin(); edge!=edges->end(); edge++)
      o << edge->second->Tail()->Id() << "->" << edge->second->Head()->Id() << " ";
}

template <typename T_Sub_Node>
void CDJNode<T_Sub_Node>::PrintDJNode(std::ostream &o) const
{
   PrintSubNodesAsSet(o);
   o << " In edges: ";
   PrintEdges(o, &_in);
   o << " Out edges: ";
   PrintEdges(o, &_out);
   o << "\n";
}

template <typename T_Sub_Node>
void CDJNode<T_Sub_Node>::Print(std::ostream &o) const
{
   PrintDJNode(o);
   if (_idom)
      o << "\nIdom: " << _idom;
   o << "\nLevel: " << _level << std::endl;
}

#endif
