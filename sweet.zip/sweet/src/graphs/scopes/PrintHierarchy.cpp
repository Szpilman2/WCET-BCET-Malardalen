// $Id: $

#include <iostream>
#include <fstream>
#include <ctime>
#include "PrintHierarchy.h"
#include "CScope.h"
#include "CScopeGraph.h"

#define ONE_INDENT_LEVEL "   "

static void GenerateScopeTreeHierarchyEdgesAsDot(ostream &o, CScope *scope, unsigned levels_to_show)
{
   if (levels_to_show > 1) {
      for (CScope::succ_iterator kid=scope->SuccBegin(); kid != scope->SuccEnd(); ++kid) {
         o << ONE_INDENT_LEVEL << scope->Id() << " -> " << kid->node->Id() << endl;
         GenerateScopeTreeHierarchyEdgesAsDot(o, kid->node, levels_to_show-1);
      }
   }
}

static void GenerateScopeTreeHierarchyAsDot(ostream &o, string indent, CScope *scope, unsigned levels_to_show, bool label_as_tool_tip)
{
   if (levels_to_show > 0) {
      string display_attribute;
      if (label_as_tool_tip)
         display_attribute = "tooltip";
      else
         display_attribute = "label";
      o << indent << scope->Id() << " [" << display_attribute << "=\"" << scope->Name() << "\" shape=box" << endl;
      if (scope->IsLoopScope()) o << indent << " style=dotted";
      if (scope->IsFunctionScope()) o << indent << " style=line";
      o << indent << "]" << endl;
      for (CScope::succ_iterator kid=scope->SuccBegin(); kid != scope->SuccEnd(); ++kid) {
         GenerateScopeTreeHierarchyAsDot(o, indent + ONE_INDENT_LEVEL, kid->node, levels_to_show-1, label_as_tool_tip);
      }
   }
}

void GenerateScopeTreeHierarchyAsDot(ostream &o, string id, CScopeGraph *scope_graph, bool label_as_tool_tip, CScope *scope, 
                                     unsigned levels_to_show)
{
   // Decide the scope to start with
   bool start_at_root = false;
   if (scope == NULL) {
      scope = scope_graph->Root();
      start_at_root = true;
   }

   string indent = ONE_INDENT_LEVEL;

   // Generate the header stuff for the dot file
   o << "digraph \"\" {" << endl;

   // Generate the graph properties
   o << indent << "size=\"11.4,7.8\";" << endl;
   o << indent << "rankdir=TB;" << endl;
   o << indent << "center=1;" << endl;
   o << indent << "rotate=0;" << endl;

   // Generate the text identifying the graph
   o << indent << "{" << endl;
   o << indent << indent << "node [shape=plaintext, fontsize=12];" << endl;
   time_t now;
   time(&now);
   string time = asctime(localtime(&now));
   time.resize(time.size()-1); // remove newline at end
   o << indent << indent << "\"Scope hierarchy for\\n" << id << "\\n " << time;
   if (!start_at_root) {
      o << "\\nNOTE! Partial graph";
   }
   o << "\\n\\n";
   o << indent << indent << "Scopes with solid line = function scope\\n";
   o << indent << indent << "Scopes with dotted line = loop scope\\n\"" << endl;
   o << indent << "}" << endl;

   GenerateScopeTreeHierarchyAsDot(o, indent, scope, levels_to_show, label_as_tool_tip);
   GenerateScopeTreeHierarchyEdgesAsDot(o, scope, levels_to_show);
   o << "}" << endl;
}
