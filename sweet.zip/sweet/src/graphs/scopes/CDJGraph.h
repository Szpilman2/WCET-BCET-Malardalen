// $Id: CDJGraph.h 3943 2012-03-21 10:18:28Z lkg02 $

#ifndef CDJGRAPH_H_
#define CDJGRAPH_H_

#include <set>
#include <map>
#include <list>
#include "CDJNode.h"
#include "graphs/components/CComponent.h"
#include "graphs/components/CComponentTree.h"
#include "graphs/tools/Dominance.h"
#include <cstdio>

template <typename T_Sub_Node, typename T_Sub_Edgedata=int>
class CDJGraph
{
private:
   typedef enum {WHITE, GRAY, BLACK} t_color;
   typedef std::map<T_Sub_Node*, std::pair<t_color, std::list<T_Sub_Node *> > > t_node_map;
   std::list<CDJNode <T_Sub_Node>*> _nodes;
   CDJNode <T_Sub_Node> *_root;
   int _print_counter;
   bool SpTree(T_Sub_Node *nd, t_node_map *ndmap, std::map<T_Sub_Node*, T_Sub_Node*>*);
   void CollapseIrreducibleLoop(int level, std::map<T_Sub_Node*, CComponent<T_Sub_Node>*> *belong, std::map<T_Sub_Node*, CComponent<T_Sub_Node>*> *topscc,
                                CComponentTree <T_Sub_Node> *tree);
   void CollapseReducibleLoop(CDJNode <T_Sub_Node> *nd, std::map<T_Sub_Node*, CComponent<T_Sub_Node>*> *belong,
                              std::map<T_Sub_Node*, CComponent<T_Sub_Node>*> *topscc, CComponentTree <T_Sub_Node> *tree);
   void Sort(void);
   void PrintDot(void);

   void CreateDJGraph(CGraph <T_Sub_Node, T_Sub_Edgedata> *graph);
   CDJGraph(CDJGraph &djgraph);
   CDJGraph & operator = (const CDJGraph &);
public:
   CDJGraph(void);
   virtual ~CDJGraph(void);

   /* PartitionGraphIntoLoops creates a list of components (strongly connected components) identified using the DJ-graph algorithm. While doing this
      the nodes of the DJ-graph will be collapsed. The parameter 'belong' is a mapping from (all) nodes of the rooted graph to the components which
      contains it.
      Each components is a tree where any loop nested in another is a decendant to that. Hence the list contains the sequence of the outermost loops
      of the graph.  */
   CComponentTree <T_Sub_Node> *PartitionGraphIntoLoops(CGraph <T_Sub_Node, T_Sub_Edgedata> *graph, std::map<T_Sub_Node*, CComponent<T_Sub_Node>*> *belong);

   // A print functio, just for logging.
   bool PrintDot(std::string filename);
};

template <typename T_Sub_Node, typename T_Sub_Edgedata>
CDJGraph<T_Sub_Node, T_Sub_Edgedata>::~CDJGraph(void)
{
   typename std::list<CDJNode<T_Sub_Node>*> ::iterator it;
   for (it=_nodes.begin(); it!=_nodes.end(); it++)
      delete *it;
}

template <typename T_Sub_Node, typename T_Sub_Edgedata>
CDJGraph<T_Sub_Node, T_Sub_Edgedata>::CDJGraph(void)
{
   _print_counter = 0;
}

/* Visit all nodes in a top down manner. Paint the node gray when entering
   and paint it black when leaving. If entering a gray node this indicates a
   back edge (save that edge). If entering a black node there is nothing to
   do, and if entering a white we have to explore it.
   Note: The tree is never built - we only need the backedges. */
template <typename T_Sub_Node, typename T_Sub_Edgedata>
bool CDJGraph<T_Sub_Node, T_Sub_Edgedata>::SpTree(T_Sub_Node *nd, t_node_map *ndmap, std::map<T_Sub_Node*, T_Sub_Node*> *bes)
{
   typename std::list<T_Sub_Node*>::const_iterator it;

   if ((*ndmap)[nd].first == BLACK)
      return false;
   else if ((*ndmap)[nd].first == GRAY)
      return true;
   (*ndmap)[nd].first = GRAY;
   for (it = (*ndmap)[nd].second.begin(); it != (*ndmap)[nd].second.end(); it++)
      if (SpTree(*it, ndmap, bes))
         (*bes)[nd] = *it;
   (*ndmap)[nd].first = BLACK;
   return false;
}

template <typename T_Sub_Node, typename T_Sub_Edgedata>
void CDJGraph<T_Sub_Node, T_Sub_Edgedata>::CollapseIrreducibleLoop(int level, std::map<T_Sub_Node*,
                                                                   CComponent<T_Sub_Node>*> *belong, std::map<T_Sub_Node*, CComponent<T_Sub_Node>*> *topscc,
                                                                   CComponentTree <T_Sub_Node> *tree)
{
   typename std::list<CDJNode<T_Sub_Node>*> ::iterator lit;
   typename std::set<CDJNode<T_Sub_Node>*> ::iterator it;
   CDJNode<T_Sub_Node> *djnode;
   typename std::set<T_Sub_Node*> ::iterator nit;
   typename std::set<std::pair<T_Sub_Node*, T_Sub_Node*> > ::iterator bit;
   std::list<CDJNode<T_Sub_Node>*> nodes;
   CComponent<T_Sub_Node> *component;

   _root->Clear();/* Paint it white */
   for (lit = _nodes.begin(); lit != _nodes.end(); lit++) {
      if ((*lit)->Level() == level && !(*lit)->Done()) {
         std::set<CDJNode<T_Sub_Node>*> loopnddj;
         std::set<std::pair<T_Sub_Node*, T_Sub_Node*> > bes;
         std::set<T_Sub_Node*> loopndfg;
         (*lit)->FindIrreducibleLoop(level, &loopnddj, &loopndfg);
         if (!loopnddj.empty()) {
            component = new CComponent<T_Sub_Node>(false);
            for (it = loopnddj.begin(); it != loopnddj.end(); it++)
               if ((*it)->IsTargetOfInEdgesFromOutsideLoop(&loopnddj))
                  (*it)->SourceOfInEdgesFromInsideLoop(&loopnddj, &bes);
            tree->AddKid(tree->TreeRoot(), component);
            // Just a temporary to rememer not to insert kid more than once...
            std::set<CComponent <T_Sub_Node> *> done;
            for (nit = loopndfg.begin(); nit != loopndfg.end(); nit++) {
               if (belong->find(*nit) == belong->end()) {
                  (*belong)[*nit] = component;
                  component->AddSubNode(*nit);
               } else if (done.find((*topscc)[*nit]) == done.end()) {
                  // The node does already belong to an component (below in the tree), replace that node with the current if not there
                  tree->RemoveSubtree((*topscc)[*nit]);
                  tree->AddKid(component, (*topscc)[*nit]);
                  done.insert((*topscc)[*nit]); // ..and remember that we have done it
               }
               (*topscc)[*nit] = component; // save the topmost occurance
            }
            for (bit = bes.begin(); bit != bes.end(); bit++) {
               component->AddBackedge(bit->first, bit->second);
               component->AddHead(bit->second);
            }
             /* Collapse */
            it = loopnddj.begin();
            djnode = *it;
            for (it++; it != loopnddj.end(); it++) {
               djnode->Eat(*it);
               (*it)->Deprecated();
            }
         }
      }
   }
   /* Cleanup from depecated nodes */
   for (lit = _nodes.begin(); lit != _nodes.end(); lit++)
      if (!(*lit)->IsDeprecated())
         nodes.push_back(*lit);
   _nodes = nodes;
}

/* Collapses a reducible loop:
  for all back edges do
     collect predessors
  for all predessors do
     incorporate them into the header
  save the resulting fg-node set
  remove the nodes from the DJ-graph*/
template <typename T_Sub_Node, typename T_Sub_Edgedata>
void CDJGraph<T_Sub_Node, T_Sub_Edgedata>::CollapseReducibleLoop(CDJNode<T_Sub_Node> *djnode, std::map<T_Sub_Node*, CComponent<T_Sub_Node>*> *belong,
                                                                 std::map<T_Sub_Node*, CComponent<T_Sub_Node>*> *topscc,  CComponentTree <T_Sub_Node> *tree)
{
   typename std::set<T_Sub_Node*> ::iterator nit, hdrit;
   typename T_Sub_Node::succ_iterator nit2;
   typename std::set<CDJNode<T_Sub_Node>*> ::iterator it;
   std::list<CDJNode<T_Sub_Node>*> nodes;
   typename std::list<CDJNode<T_Sub_Node>*> ::iterator lit;
   std::set<CDJNode<T_Sub_Node>*> bes;
   std::set<CDJNode<T_Sub_Node>*> loopnodes;
   CComponent<T_Sub_Node> *component;

   component = new CComponent<T_Sub_Node>(true);
   djnode->GetBackedgesSources(&bes);
   for (it = bes.begin(); it != bes.end(); it++)
      (*it)->CollectPredessors(djnode, &loopnodes);

   /* Here identification is ready, we also have to collapse the nodes of
   the loop and, it may sound crazy, the following piece of code is just to
   transform to a more suitable representation... */
   for (hdrit = djnode->FGNodes()->begin(); hdrit != djnode->FGNodes()->end(); hdrit++) {
      for (it = bes.begin(); it != bes.end(); it++) {
         for (nit = (*it)->FGNodes()->begin(); nit != (*it)->FGNodes()->end(); nit++) {
            for (nit2 = ((T_Sub_Node*)*nit)->SuccBegin(); nit2 != ((T_Sub_Node*)*nit)->SuccEnd(); nit2++) {
               if (nit2->node == *hdrit) {
                  component->AddBackedge(*nit, *hdrit);
                  component->AddHead(*hdrit);
                  break;
               }
            }
         }
      }
   }

   /* Collapse */
   if (loopnodes.size() == 0)  // Self iteration
      djnode->Eat(djnode);
   for (it = loopnodes.begin(); it != loopnodes.end(); it++) {
      djnode->Eat(*it);
      (*it)->Deprecated();
   }

   /* Copy all cfg-nodes from the DJ-node that comes out from the collapsed loop to the component. Note that, due to the bottom-up manner of this
      analysis, any cfg-node may already belong to some other (previously collapsed) inner loop. We detect this by checking the `topscc'
      map, which contains the so far most recent (the "top" one) access to this node. In case it is already "used" in some subordinated loop,
      then this must be the one most closely to the current one, so we will add a reference to that component as the kid of this loop rather than
      adding the cfg-node. We also must update the map in case there are further references higher up (i.e. enclosing loops). */

   // First we assume that the current component is at the top level (i.e. immediately below the virtual root.
   tree->AddKid(tree->TreeRoot(), component);
   // Just a temporary to rememer not to insert kid more than once...
   std::set<CComponent <T_Sub_Node> *> done;
   for (nit = djnode->FGNodes()->begin(); nit != djnode->FGNodes()->end(); nit++) {
      if (belong->find(*nit) == belong->end()) {
         (*belong)[*nit] = component;
         component->AddSubNode(*nit);
      } else if (done.find((*topscc)[*nit]) == done.end()) {
         // The node does already belong to an component (below in the tree), replace that node with the current if not there
         tree->RemoveSubtree((*topscc)[*nit]);
         tree->AddKid(component, (*topscc)[*nit]);
         done.insert((*topscc)[*nit]); // ..and remember that we have done it
      }
      (*topscc)[*nit] = component; // save the topmost occurance
   }

   /* Cleanup from depecated nodes */
   for (lit = _nodes.begin(); lit != _nodes.end(); lit++) {
      if (!(*lit)->IsDeprecated()) {
         nodes.push_back(*lit);
      } else {
         delete *lit;
      }
   }
   _nodes = nodes;
}

template <typename T_Sub_Node, typename T_Sub_Edgedata>
void CDJGraph<T_Sub_Node, T_Sub_Edgedata>::Sort(void)
{
   std::list<CDJNode<T_Sub_Node>*> nodes;
   typename std::list<CDJNode<T_Sub_Node>*> ::const_iterator it;
   int level = 0;

   for (it = _nodes.begin(); it != _nodes.end(); it++)
      if ((*it)->Level() > level)
         level = (*it)->Level();
   for (; level >= 0; level--)
      for (it = _nodes.begin(); it != _nodes.end(); it++)
         if ((*it)->Level() == level)
            nodes.push_back(*it);
   _nodes = nodes;
}

template <typename T_Sub_Node, typename T_Sub_Edgedata>
CComponentTree <T_Sub_Node> *CDJGraph<T_Sub_Node, T_Sub_Edgedata>::PartitionGraphIntoLoops(CGraph <T_Sub_Node, T_Sub_Edgedata> *graph,
                                                                                           std::map<T_Sub_Node*, CComponent<T_Sub_Node>*> *belong)
{
   int level;
   typename std::list<CDJNode <T_Sub_Node>*> ::const_iterator it;
   // The topscc is a mapping from any node to the scc as high as possible (as high as known so far) in the tree of sccs
   std::map<T_Sub_Node*, CComponent<T_Sub_Node>*> topscc;
   bool irreducible;
   CComponentTree <T_Sub_Node> *tree;

   CreateDJGraph(graph);
   tree = new CComponentTree <T_Sub_Node> ();
   CComponent<T_Sub_Node> *component = new CComponent<T_Sub_Node>(true);
   tree->AddRoot(component);

   Sort();

   // Initiallay we assume that all sub-nodes belongs to the virtual top-component
   for (it = _nodes.begin(); it != _nodes.end(); it++) {
      component->AddSubNode(*(*it)->FGNodes()->begin()); // There is only one subnode in each at this stage
   }

   it = _nodes.begin();
   if (it == _nodes.end())
      return tree;
   level = (*it)->Level();
   irreducible = false;

   do {
      if ((*it)->IsDestinationOfCJEdgeAndSpBackedge())
         irreducible = true;
      if ((*it)->IsDestinationOfBJEdge()) {
         CDJNode <T_Sub_Node> *tmp = *it;
         CollapseReducibleLoop(*it, belong, &topscc, tree);
         for (it = _nodes.begin(); it != _nodes.end() && *it != tmp; it++)
            ;
      }
      it++;
      if (it == _nodes.end() || level != (*it)->Level()) {
         if (irreducible) {
            CDJNode <T_Sub_Node> *curnode = NULL;
            if (it != _nodes.end())
               curnode = *it;
            irreducible = false;
            CollapseIrreducibleLoop(level, belong, &topscc, tree);
            for (it = _nodes.begin(); it != _nodes.end() && *it != curnode; it++)
               ;
         }
         if (it != _nodes.end())
            level = (*it)->Level();
      }
   } while (it != _nodes.end());

   // Remove all nodes that belongs to some loop from the total (initial) set of subnodes.
   for (typename std::map<T_Sub_Node*, CComponent<T_Sub_Node>*> ::iterator bit = belong->begin(); bit != belong->end(); bit++) {
      component->RemoveSubNode(bit->first);
   }

   return tree;
}

/* This function will build the actual DJ-graph, which uses both the spanning tree and the dominator relation. The DJ-graph is
   useful to identify (possibly nested and unstructured) loops in a rooted graph, and, to my knowledge, nothing more. */
template <typename T_Sub_Node, typename T_Sub_Edgedata>
void CDJGraph<T_Sub_Node, T_Sub_Edgedata>::CreateDJGraph(CGraph <T_Sub_Node, T_Sub_Edgedata> *graph)
{
   typename std::map<T_Sub_Node *, T_Sub_Node * >::const_iterator it;
   std::map<T_Sub_Node*, CDJNode <T_Sub_Node>*> flow2DJ;
   typename std::list<CDJNode <T_Sub_Node> *> :: iterator it2;
   CDJNode <T_Sub_Node> *djnode;
   std::map<T_Sub_Node *, T_Sub_Node * > idom;
   T_Sub_Node *root = graph->Root();

   CDominance <T_Sub_Node, T_Sub_Edgedata> dominance;
   dominance.CalculateIdom(graph, &idom, " <call graph> ");

   // Create dominator tree
   // ----------------------
   /* Create the nodes of the tree (at this stage just wrappers to flow graph nodes) */
   for (typename CGraph<T_Sub_Node, T_Sub_Edgedata>::node_iterator itn=graph->NodesBegin(); itn!=graph->NodesEnd(); itn++) {
      djnode = new CDJNode<T_Sub_Node>(*itn);
      _nodes.push_back(djnode);
      flow2DJ[*itn] = djnode;
      if (*itn==root)
         _root = djnode;
   }

   /* Add the D-edges */
   for (it = idom.begin(); it != idom.end(); it++) {
      if (it->first != root && it->first != NULL) {
         CDJEdge <T_Sub_Node>*e = new CDJEdge<T_Sub_Node>(flow2DJ[idom[it->first]], flow2DJ[it->first], EDGE_D);
         flow2DJ[it->first]->EdgeIn(e);
         flow2DJ[idom[it->first]]->EdgeOut(e);
      }
   }

   /* Add the dominator relation */
   for (it2 = _nodes.begin(); it2 != _nodes.end(); it2++) {
      std::set<CDJNode <T_Sub_Node>*> doms;
      T_Sub_Node *nd;
      for (nd = *(*it2)->FGNodes()->begin(); nd!=root; nd = idom[nd])
         doms.insert(flow2DJ[nd]);
      doms.insert(_root);
      (*it2)->InsertDominators(doms);
   }

   /* Compute the sp-back-edges: create a spanning tree to the flowgraph
   and collect backedges during the traversal */

   /* A node map is an image of the flow graph with nodes extended with a "visited
   flag" (color). First initialize to white */
   t_node_map ndmap;
   std::map<T_Sub_Node*, T_Sub_Node*> bes;
   for (typename CGraph<T_Sub_Node, T_Sub_Edgedata>::node_iterator itn=graph->NodesBegin(); itn!=graph->NodesEnd(); itn++) {
      ndmap[*itn] = make_pair(WHITE, std::list<T_Sub_Node*>());
      for (typename T_Sub_Node::succ_iterator succ=(*itn)->SuccBegin(); succ!=(*itn)->SuccEnd(); succ++)
         ndmap[*itn].second.push_back(succ->node);
   }

   /* Create spanning tree to get the sp back edges */
   SpTree(root, &ndmap, &bes);

   // Create the DJ-graph from the dominator tree
   // -------------------------------------------

   /* Add the join edeges; at this stage all DJ-nodes contain exactely one flow
   graph node. The nodes has to classify the edge types to BJ or CJ themselves */
   T_Sub_Node *fgnode;
   for (it2 = _nodes.begin(); it2 != _nodes.end(); it2++) {
      fgnode = *(*it2)->FGNodes()->begin();
      typename std::map<T_Sub_Node *, T_Sub_Node *> :: const_iterator spbe = bes.find(fgnode);
      for (typename T_Sub_Node::succ_iterator succ = fgnode->SuccBegin(); succ != fgnode->SuccEnd(); succ++) {
         CDJEdge <T_Sub_Node> *e;
         if (spbe != bes.end() && spbe->second == succ->node)
            e = new CDJEdge<T_Sub_Node>(*it2, flow2DJ[succ->node], EDGE_J, 1);
         else
            e = new CDJEdge<T_Sub_Node>(*it2, flow2DJ[succ->node], EDGE_J);
         (*it2)->EdgeOut(e);
         flow2DJ[succ->node]->EdgeIn(e);
      }
   }
}

template <typename T_Sub_Node, typename T_Sub_Edgedata>
bool CDJGraph<T_Sub_Node, T_Sub_Edgedata>::PrintDot(std::string filename)
{
   std::list<CDJEdge<T_Sub_Node>*> edges;
   typename std::list<CDJEdge<T_Sub_Node>*>::iterator e;
   std::list<CDJNode<T_Sub_Node>*> cur, succ;
   typename std::list<CDJNode<T_Sub_Node>*>::iterator djnodeit;
   typename std::set<T_Sub_Node*>::const_iterator it;
   const std::set<T_Sub_Node*> *nodes;
   int i = 0;
   FILE *f;

   f = fopen(filename.c_str(), "wt");
   if (f==NULL)
      return false;
   fprintf(f, "digraph \"\" {\n");
   fprintf(f, "  size=\"11.4,7.8\";\n");
   fprintf(f, "  rankdir=TB;\n");
   fprintf(f, "  center=1;\n");
   fprintf(f, "  rotate=0;\n");
   cur.push_back(_root);
   while (cur.size() > 0) {
      fprintf(f, "  subgraph cluster_%d {\n", i++);
      fprintf(f, "    node [width=0.27 fixedsize=true shape=circle fontsize=10]\n");
      for (djnodeit = cur.begin(); djnodeit != cur.end(); djnodeit++) {
         fprintf(f, "    %d\n", (*djnodeit)->Id());
         nodes = (*djnodeit)->FGNodes();
         if (nodes->size() > 1) {
            fprintf(f, "[label=\"");
            for (it=nodes->begin(); it!=nodes->end(); it++)
               if (it==nodes->begin())
                  fprintf(f, "%d", (*it)->Id());
               else
                  fprintf(f, ",%d", (*it)->Id());

            fprintf(f, "\"]");
         }
      }
      fprintf(f, "  }\n");
      succ.clear();
      for (djnodeit = cur.begin(); djnodeit != cur.end(); djnodeit++) {
         (*djnodeit)->CatenateSuccessors(&succ);
         (*djnodeit)->CatenateOutEdges(&edges);
      }
      cur = succ;
   }
   fprintf(f, "   // Edeges:\n");
   for (e=edges.begin(); e != edges.end(); e++) {
      fprintf(f, "  %d->%d", (*e)->Tail()->Id(), (*e)->Head()->Id());
      if ((*e)->Head()->Level() < (*e)->Tail()->Level()) // up-edge
         fprintf(f, "  [constraint=false]");
      else
         fprintf(f, "\n");
   }
   fprintf(f, "}\n");
   fclose(f);
   return true;
}

#endif
