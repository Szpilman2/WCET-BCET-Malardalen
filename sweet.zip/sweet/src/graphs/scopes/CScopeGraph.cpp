// $Id: CScopeGraph.cpp 7974 2018-11-23 13:53:26Z lkg02 $

#include "CScopeGraph.h"
#include "CScope.h"
#include "../tools/CGraph.inl"
#include "../tools/CNode.inl"
#include "graphs/cg/CCallGraphNode.h"
#include "graphs/ecfg/CECFG.h"
#include "graphs/ecfg/CECFGNode.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include "program/CGenericFunction.h"
#include "cmd/CCommand.h"
#include <cstring>
#include <cassert>
#include <fstream>

using namespace std;

template class CGraph <CScope, CScopeGraphEdgeAnnot>;

CScopeGraph::CScopeGraph(CECFG *ecfg)
: _ecfg(ecfg)
{
   if (_ecfg)
      _ecfg->SetScopeGraph(this);
}

CScopeGraph::~CScopeGraph(void)
{
   
   delete _ecfg;
   for(unsigned i=0; i<NrOfNodes(); i++) {
      CScope *scope = NodeAt(i);
      delete scope;
   }
   for (unsigned i=0; i < _function_to_scope.size(); i++) {
      if (_function_to_scope[i]) {
         delete _function_to_scope[i];
      }
   }

}

const set <CScope *> *CScopeGraph::ScopesOfFunction(CGenericFunction *function) const
{
   
   const set <CScope *> *scopes = _function_to_scope[function->Key()];

   return scopes;
}

void CScopeGraph::FunctionScopes(vector<CScope*> * scopes) const
{
   
   for(unsigned i=0; i<NrOfNodes(); i++) {
      CScope *scope = NodeAt(i);
      if(scope->IsFunctionScope())
         scopes->push_back(scope);
   }

}

unsigned CScopeGraph::NrOfFunctionScopes() const
{
  vector<CScope *> scopes;
  FunctionScopes(&scopes);
  return (unsigned)scopes.size();
}

void CScopeGraph::LoopScopes(vector<CScope*> * scopes) const
{
   
   for(unsigned i=0; i<NrOfNodes(); i++) {
      CScope *scope = NodeAt(i);
      if(scope->IsLoopScope())
         scopes->push_back(scope);
   }

}

unsigned CScopeGraph::NrOfLoopScopes() const
{
  vector<CScope *> scopes;
  LoopScopes(&scopes);
  return (unsigned)scopes.size();
}


void CScopeGraph::ECFGNodes(set<CECFGNode*> * nodes)
{
   
   for(unsigned i=0; i<NrOfNodes(); i++) {
      CScope *scope = NodeAt(i);
      for(CScope::ecfg_nodes_iterator node=scope->ECFGNodesBegin(); node!=scope->ECFGNodesEnd(); node++) {
         nodes->insert(*node);
      }
   }

}

void CScopeGraph::ECFGNodesThatBeginBasicBlocks(set<CECFGNode*> * nodes) const
{
   
   for(unsigned i=0; i<NrOfNodes(); i++) {
      CScope *scope = NodeAt(i);
      for(CScope::ecfg_nodes_iterator node=scope->ECFGNodesBegin(); node!=scope->ECFGNodesEnd(); node++) {
        if((*node)->IsBeginOfBasicBlock())
          nodes->insert(*node);
      }
   }

}

void CScopeGraph::ECFGNodesThatEndBasicBlocks(set<CECFGNode*> * nodes) const
{
   
   for(unsigned i=0; i<NrOfNodes(); i++) {
      CScope *scope = NodeAt(i);
      for(CScope::ecfg_nodes_iterator node=scope->ECFGNodesBegin(); node!=scope->ECFGNodesEnd(); node++) {
        if((*node)->IsEndOfBasicBlock())
          nodes->insert(*node);
      }
   }

}
 

void CScopeGraph::MapFunctionToScope(CScope *function_scope)
{
   
   assert(function_scope->Type() == CScope::FUNCTION);

   unsigned i = function_scope->Function()->Key();
   if (i >= _function_to_scope.size()) {
      _function_to_scope.resize(i+1);
   }
   if (_function_to_scope[i] == NULL) {
      _function_to_scope[i] = new set <CScope*> ();
   }
   _function_to_scope[i]->insert(function_scope);

}

unsigned CScopeGraph::UniqueCallNumber(CCallGraphNode *call_graph_node)
{
   unsigned id = call_graph_node->Id();
   if (id >= _function_id_to_unique_number.size()) {
      _function_id_to_unique_number.resize(id+1);
   }
   return ++_function_id_to_unique_number[id];
}

void CScopeGraph::PrintTCD(ostream &o)
{
   
   for (node_iterator scope=NodesBegin(); scope!=NodesEnd(); scope++) {
      (*scope)->PrintTCD(o);
   }

}

unsigned CScopeGraph::LeafScopes(vector<CScope*> * leaves) const
{
   
   unsigned nr_of_leaf_scopes = 0;
   for(unsigned i=0; i<NrOfNodes(); i++) {
      CScope *scope = NodeAt(i);
      if(scope->SuccSize() == 0) {
         leaves->push_back(scope);
         nr_of_leaf_scopes++;
      }
   }

   return nr_of_leaf_scopes;
}

unsigned CScopeGraph::NrOfLeafScopes() const
{
  vector<CScope *> scopes;
  LeafScopes(&scopes);
  return (unsigned)scopes.size();
}


bool CScopeGraph::HasRecursiveScopes() const
{
  bool has_recursive_scope = false;
  for(unsigned i=0; i<NrOfNodes(); i++) {
    CScope *scope = NodeAt(i);
    if(scope->IsRecursiveFunctionScope() || scope->IsMutualRecursiveFunctionsScope()) {
      has_recursive_scope = true;
      break;
    }
  }
  return has_recursive_scope;
}



void CScopeGraph::PrintFlowFactFile(ostream &o)
{
   
   o << "scopegraph" << endl << endl;
   for (node_iterator scope=NodesBegin(); scope!=NodesEnd(); scope++) {
      (*scope)->PrintFlowFactFile(o);
   }
   o << "end scopegraph" << endl;

}

void CScopeGraph::PrintFlowFactFileSpecialExit(ostream &o, set<string> * exit_bb_names)
{
   
   o << "scopegraph" << endl << endl;
   for (node_iterator scope=NodesBegin(); scope!=NodesEnd(); scope++) {
      (*scope)->PrintFlowFactFileSpecialExit(o, exit_bb_names);
   }
   o << "end scopegraph" << endl;

}

void CScopeGraph::PrintFlowFactFileSpecialExit(ostream &o, set<string> * exit_bb_names, string initial_text)
{
   
   o << "scopegraph" << endl;
   o << "%% -------------------------" << endl;
   o << "%% " << initial_text << endl;
   o << "%% -------------------------" << endl << endl;
   for (node_iterator scope=NodesBegin(); scope!=NodesEnd(); scope++) {
      (*scope)->PrintFlowFactFileSpecialExit(o, exit_bb_names);
   }
   o << "end scopegraph" << endl;

}
