// $Id: CreateScopeMapping.cpp 5402 2013-06-15 21:33:51Z lkg02 $

#include "CreateScopeMapping.h"
#include "CScopeGraph.h"
#include "CScope.h"
#include "graphs/ecfg/CECFGNode.h"
#include <map>
#include <cassert>

using namespace std;

void CreateScopeMapping(CScopeGraph *from, CScopeGraph *to, map <CScope*, CScope*> *from_to_map)
{
   return;
   for (CScopeGraph::node_iterator it=from->NodesBegin(); it!=from->NodesEnd(); it++) {
      CScope *dest = to->NodeAt((*it)->Id());
      assert(dest);
      for (CScope::ecfg_nodes_iterator from_node=dest->ECFGNodesBegin(); from_node!=dest->ECFGNodesEnd(); from_node++) {
      }
      (*from_to_map)[*it] = dest;
   }
}
