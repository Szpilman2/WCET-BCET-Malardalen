// $Id: CECFGNode.h 2545 2010-10-18 12:46:10Z ael01 $

#ifndef CCECFGNODE_H_
#define CCECFGNODE_H_

#include "CECFGEdgeAnnot.h"
#include "graphs/tools/CNode.h"
#include <vector>
#include <cassert>

class CFlowGraphNode;
class CScope;

/** \class 
   Defines a node in an extended flow graph. The ECFG node represents one or more control flow
   nodes (which in turn represent a single statement).
*/
class CECFGNode : public CNode <CECFGNode, CECFGEdgeAnnot> 
{
public:

  // To create and destory an ecfg node
  CECFGNode(CFlowGraphNode *flow_graph_node=NULL, CScope *scope=NULL);
  virtual ~CECFGNode(void) {}

   /** \return NULL This function should not be used!
   */
   CECFGNode *Copy();

   /** Adds a flow graph node at the end of a list of flow graph nodes that this ECFG node represents.
      \param flow_graph_node A pointer to a flow graph node to add. The memory of the node is not owned by
         this ECFG node.
   */
   void AddFlowGraphNode(CFlowGraphNode *flow_graph_node) { _flow_graph_nodes.push_back(flow_graph_node); }

   /** \return The flow graph node that this ECFG node represents.
       \pre This ECFG node has exactly one CFG node.
   */
   CFlowGraphNode *GetFlowGraphNode() { return *_flow_graph_nodes.begin(); }
   const CFlowGraphNode *GetFlowGraphNode() const { return *_flow_graph_nodes.begin(); }

   /** \return A pointer to a list of flow graph nodes that this ECFG node represents. The order
      of the nodes in the list is the same order as they were added using AddFlowGraphNode. The memory
      of the nodes in the list does NOT belong to this ECFG node. The memory of the list does NOT
      belong to the caller.
   */
   /* const std::vector<CFlowGraphNode*> *FlowGraphNodes() const { return &_flow_graph_nodes; } */
   // int GetHighestAnnotNumber() const;
   unsigned int GetHighestAnnotNumber() const;

   /** Add label @a label to the successor identified by (@a node, @a edge_annot) */
   // void AddAnnotNumberToSuccessor(unsigned int label, const CECFGNode * node, const CECFGEdgeAnnot * edge_annot);
  void AddAnnotNumberToSuccessor(unsigned int label, const CECFGNode * node, CECFGEdgeAnnot * edge_annot);

   /** Get access to a list of successors that are annotated with @a label */
   // const std::vector<successor_type> * GetSuccessorsWithAnnotNumber(unsigned int number) const {return &_annot_number_to_succs[number];}
   void GetSuccessorsWithAnnotNumber(unsigned int number, std::vector<successor_type> * succ_types) const;

   /** To get and set the node that is the call-node proceeding a return-to-node, i.e. this 
       node is the return-to-node. Returns NULL if no such node has been set or if current node
       not is a return-to-node. */
   bool HasFalseEdgePredecessor() const { return _false_edge_predecessor != NULL; }
   CECFGNode * GetFalseEdgePredecessor() const { return _false_edge_predecessor; }
   void SetFalseEdgePredecessor(CECFGNode *false_edge_predecessor) { _false_edge_predecessor = false_edge_predecessor; }

   /** To get and set the node that is the return-to-node succeeding a call-node, i.e. this 
       node is the call-node. Returns NULL if no such node has been set or if current node
       not is a call-node. */
   bool HasFalseEdgeSuccessor() const { return _false_edge_successor != NULL; }
   CECFGNode * GetFalseEdgeSuccessor() const { return _false_edge_successor; }
   void SetFalseEdgeSuccessor(CECFGNode *false_edge_successor) { _false_edge_successor = false_edge_successor; }

   inline void SetScope(CScope *scope) { _scope = scope; }
   inline CScope *Scope() const { return _scope; }

   /** Get a single successor ECFGNode. Will assert if less than one or more than one successor */
   CECFGNode * GetSuccessor(void);

   /** To check if the ECFG node is the start or end of a basic block **/
   bool IsBeginOfBasicBlock(void);
   bool IsEndOfBasicBlock(void);

   /** To get the first and last node in the node's basic block **/
   CECFGNode * GetBeginNodeOfNodesBasicBlock(void);
   CECFGNode * GetEndNodeOfNodesBasicBlock(void);
   // If we should continue over call-node to return-to edges.
   CECFGNode * GetEndNodeOfNodesBasicBlockStretchingOverFalseEdges(void);

   // To print the node. The printed node name should also be suitable for dot drawings
   void Print(std::ostream &o=std::cout) const;

   // To get an unique id of the node suitable for dot drawings
   // void DrawId(std::ostream &o=std::cout) const;

   /** \return The number of statements in the input code that this node represents.
   */
   unsigned NrOfStatements();

   /** Prints dummy TCD instructions (nop) for the code that this node represents
   */
   void PrintTCD(std::ostream &o);

private:
   std::vector<CFlowGraphNode*> _flow_graph_nodes;
   CScope *_scope;
   CECFGNode *_false_edge_predecessor;
   CECFGNode *_false_edge_successor;

   // A mapping from labels (unsigned ints) to a collection of
   // successors with that label. Each successor can have several
   // labels.
   // std::vector<std::vector<successor_type> > _annot_number_to_succs;
   // EBBE: Removed 20101018 since can not handle copyies will since
   // it contain pointers to nodes. Functionality Moved to CECFGEdgeAnnot.

   // to be removed
   int PrintErrorMessageAndReturnZero(std::ostream &o = std::cerr) const;

};

// Alternative printing function
std::ostream &operator << (std::ostream &o, CECFGNode &n);

#endif
