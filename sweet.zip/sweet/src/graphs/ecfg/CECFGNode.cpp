//  $Id: CECFGNode.cpp 2545 2010-10-18 12:46:10Z ael01 $

#include "CECFGNode.h"
#include "../tools/CNode.inl"
#include "graphs/scopes/CScope.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include <iomanip>
#include <assert.h>

using namespace std;

template class CNode <CECFGNode, CECFGEdgeAnnot>;


CECFGNode::
CECFGNode(CFlowGraphNode *flow_graph_node, CScope *scope)
 : _scope(scope), _false_edge_predecessor(NULL), _false_edge_successor(NULL)
{
  if (flow_graph_node)
    _flow_graph_nodes.push_back(flow_graph_node);
}

CECFGNode *
CECFGNode::
Copy()
{
  assert("This function should not be used!"==0);
  return NULL;
}


// /** Add label @a label to the successor identified by (@a node, @a edge_annot) */
// void CECFGNode::AddAnnotNumberToSuccessor(unsigned int label, const CECFGNode * node, const CECFGEdgeAnnot * edge_annot)
// {
//    // TODO: Here we have a potential problem: there can be more than one edge that is identified by (node, edge_annot).
//    // For the nonce we solve this by letting the label be added to all of them.

//    int nr_added = 0;
//    for (succ_iterator s = SuccBegin(); s != SuccEnd(); ++s)
//    {
//       if (s->node == node && s->edge_annot == edge_annot)
//       {
//          if (_annot_number_to_succs.size() <= label)
//          {
//             _annot_number_to_succs.resize(label + 1);
//          }
//          _annot_number_to_succs[label].push_back(*s);
//          ++nr_added;
//       }
//    }
//    assert(nr_added > 0 || "Trying to add label to non-existing successor" == NULL);

// }


unsigned int
CECFGNode::
GetHighestAnnotNumber() const
{
  unsigned int highest_annot_number = 0;
  bool annot_number_found = false;
  for (const_succ_iterator s = SuccBegin(); s != SuccEnd(); ++s)
    {
      if (s->edge_annot->HasAnyAnnotNumber()) {
	annot_number_found = true;
	unsigned int an = s->edge_annot->GetHighestAnnotNumber();
	if(an > highest_annot_number)  {
	  highest_annot_number = an;
	}
      }
    }
  assert(annot_number_found);
  return highest_annot_number;
}

/** Add label @a label to the successor identified by (@a node, @a edge_annot) */
void CECFGNode::AddAnnotNumberToSuccessor(unsigned int label, const CECFGNode * node, CECFGEdgeAnnot * edge_annot)
{
  edge_annot->AddAnnotNumber(label);
}


void 
CECFGNode::
GetSuccessorsWithAnnotNumber(unsigned int number, std::vector<successor_type> * succ_types) const 
{
  for (const_succ_iterator s = SuccBegin(); s != SuccEnd(); ++s)
   {
     if (s->edge_annot->HasAnnotNumber(number)) {
       successor_type st(s->node, s->edge_annot);
       succ_types->push_back(st);
     }
   }
}


CECFGNode * 
CECFGNode::
GetSuccessor(void)
{
  assert(SuccSize() == 1);
  succ_iterator s = const_cast<CECFGNode *>(this)->SuccBegin();
  return s->node;
}

bool 
CECFGNode::
IsBeginOfBasicBlock(void)
{
  return GetFlowGraphNode()->IsBeginOfBasicBlock();
}

bool 
CECFGNode::
IsEndOfBasicBlock(void)
{
  return GetFlowGraphNode()->IsEndOfBasicBlock();
}

CECFGNode *
CECFGNode ::
GetBeginNodeOfNodesBasicBlock(void) 
{
  CECFGNode * walker = this;
  while(!walker->IsBeginOfBasicBlock())
    {
      assert(walker->PredSize() == 1);
      walker = *(walker->PredBegin());
    }
  return walker;
}

CECFGNode *
CECFGNode ::
GetEndNodeOfNodesBasicBlock(void) 
{
  CECFGNode * walker = this;
  while(!walker->IsEndOfBasicBlock())
    {
      assert(walker->SuccSize() == 1);
      walker = (*(walker->SuccBegin())).node;
    }
  return walker;
}

CECFGNode *
CECFGNode ::
GetEndNodeOfNodesBasicBlockStretchingOverFalseEdges(void) 
{
  CECFGNode * walker = this;
  while(!walker->IsEndOfBasicBlock())
    {
      assert(walker->SuccSize() == 1);
      walker = (*(walker->SuccBegin())).node;
      if(walker->HasFalseEdgeSuccessor()) {
        walker = walker->GetFalseEdgeSuccessor();
      }
    }
  return walker;
}


void
CECFGNode::
Print(ostream &o) const
{
  o << Scope()->Name() << "_" << GetFlowGraphNode()->Name();
}

unsigned
CECFGNode::
NrOfStatements()
{
   return 1;
}

void
CECFGNode::
PrintTCD(ostream &o)
{
   unsigned instr_size = 2, i;

   CFlowGraphNode *flow_graph_node = GetFlowGraphNode();
   o << "begin block " << flow_graph_node->Name() << ":\n";
   o << "  pred ;\n";
   o << "  succ ;\n";
   o << "  code\n";
   for (i=0; i < NrOfStatements(); i++) {
      o << setw(8) << " :" << instr_size << " : Nop;\n";
   }
   o << "  end code\n";
   o << "end block\n\n";
}

// Not needed since print function do the same
// void
// CECFGNode::
// DrawId(std::ostream & s) const
// {
//   s << Scope()->Name() << "_" << GetFlowGraphNode()->Name();
// }


// Alternative printing function
ostream &operator << (ostream &o, CECFGNode &n)
{
   n.Print(o);
   return o;
}


int 
CECFGNode::
PrintErrorMessageAndReturnZero(std::ostream &o) const
{
  o << "CECFGNode::GetHighestAnnotNumber() ERROR: _annot_number_to_succs is empty for node ";
  Print(o);
  o << std::endl;
  return 0; 
}
