// $Id: CECFGEdgeAnnot.cpp 5125 2013-04-07 22:13:58Z lkg02 $

#include "CECFGEdgeAnnot.h"
#include <sstream>
#include <assert.h>

using namespace std;

CECFGEdgeAnnot *
CECFGEdgeAnnot::
Copy()
{
   CECFGEdgeAnnot *new_annot = new CECFGEdgeAnnot(_cfg_edge);
   for(std::set<unsigned int>::iterator an = _annot_numbers.begin();
      an != _annot_numbers.end(); ++an) {
     new_annot->AddAnnotNumber(*an);
   }
   return new_annot;
}

string
CECFGEdgeAnnot::
Annotation()
{
   ostringstream s;
   if (_cfg_edge->IsBackedge()) {
      s << "B";
   }
   s << _cfg_edge->Label();
   return s.str();
}

CFlowGraphEdgeAnnot *
CECFGEdgeAnnot::
FlowGraphEdge()
{
   return _cfg_edge;
}

string
CECFGEdgeAnnot::
Color()
{
   if (_cfg_edge && _cfg_edge->IsBackedge())
      return "red";
   else
      return "black";
}

void 
CECFGEdgeAnnot::
AddAnnotNumber(unsigned int annot_number) 
{ 
  _annot_numbers.insert(annot_number); 
}
  
bool
CECFGEdgeAnnot::
HasAnnotNumber(unsigned int annot_number) const
{ 
  return _annot_numbers.find(annot_number) != _annot_numbers.end(); 
}

bool
CECFGEdgeAnnot::
HasAnyAnnotNumber() const
{ 
  return _annot_numbers.size() > 0; 
}


void
CECFGEdgeAnnot::
GetAnnotNumbers(std::vector<unsigned int> * annot_numbers) const
{
  for(std::set<unsigned int>::const_iterator an = _annot_numbers.begin();
      an != _annot_numbers.end(); ++an) {
    annot_numbers->push_back(*an);
  }
}

unsigned int
CECFGEdgeAnnot::
GetHighestAnnotNumber() const
{
  assert(HasAnyAnnotNumber());
  bool first_item = true;
  unsigned int highest_annot_number = 0;
  for(std::set<unsigned int>::const_iterator an = _annot_numbers.begin();
      an != _annot_numbers.end(); ++an) {
    if(first_item) {
      highest_annot_number = (*an);
      first_item = false;
    }
    else {
      if((*an) > highest_annot_number) 
	highest_annot_number = (*an);
    }
  }
  return highest_annot_number;
}


////////////////////////////////////////////////////////
// recursive:
////////////////////////////////////////////////////////

CECFGEdgeRecursiveCall *
CECFGEdgeRecursiveCall::
Copy()
{
   CECFGEdgeRecursiveCall *new_annot = new CECFGEdgeRecursiveCall(_return, _result);
   for(std::set<unsigned int>::iterator an = _annot_numbers.begin();
      an != _annot_numbers.end(); ++an) {
     new_annot->AddAnnotNumber(*an);
   }
   return new_annot;
}

string
CECFGEdgeRecursiveCall::
Color()
{
   return "blue";
}

string
CECFGEdgeRecursiveCall::
Annotation()
{
   ostringstream s;
   if (_cfg_edge)
      s << "RC" << _cfg_edge->Label();
   return s.str();
}

