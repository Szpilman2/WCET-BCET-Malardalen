// $Id: CECFGEdgeAnnot.h 5125 2013-04-07 22:13:58Z lkg02 $

#ifndef CECFG_EDGE_H_
#define CECFG_EDGE_H_

#include <iostream>
#include <vector>
#include <set>

#include "graphs/cfg/CFlowGraphEdgeAnnot.h"

class CECFGNode;
class CFlowGraphEdgeAnnot;

/** \class CECFGEdgeAnnot
   Defines an edge in an extended flow graph, ECFG. The ECFG edge represents one possible interprocedural execution flow
   from one ECFG node to another.
*/
class CECFGEdgeAnnot
{
public:
   /** Constructs one edge annotation, that simply connects the flow graph's edge that this
      extended flow graph's edge represents.
      \param cfg_edge A pointer to the edge annotation in the flow graph that this edge represents.
         If \a cfg_edge is omitted or NULL this edge does not represent any edge in the flowgraph.
   */
   CECFGEdgeAnnot(CFlowGraphEdgeAnnot *cfg_edge=NULL) : _cfg_edge(cfg_edge) { }

   virtual ~CECFGEdgeAnnot() {}

   CECFGEdgeAnnot *Copy();

   /** \return A pointer to the edge that this extended flow graph's edge is representing, or NULL
      if it does not represent any flow graph edge.
   */
   CFlowGraphEdgeAnnot *FlowGraphEdge();

   /** \return A very brief annotation that indicates the type of edge concatenated with the
      annotation label of the corresponding flow graph edge.
      'RR' - a recursive return edge
      'B' - a backedge
   */
   virtual std::string Annotation();

   /** \return A string telling a color value that can be used for e.g. annotations.
      red - a backedge
      black - for other cases
   */
   virtual std::string Color();

   /** Extract information from corresponding CFG edge annot */
   inline bool IsBackEdge() const { return _cfg_edge->IsBackedge(); }
   inline bool IsFalseEdge() const { return _cfg_edge->IsFalseEdge(); }

   /** \return \a true if this edge is an out-edge from a node representing a call statement
      calling an undefined function. I.e. the target is a node corresponding to the successor
      node in the CFG.
   */
   bool EdgeFromCallToUndefinedFunction() { return edge_from_call_to_undefined_function; }
   void SetEdgeFromCallToUndefinedFunction() { edge_from_call_to_undefined_function = true; }

    /** Add an annot number to the edge 
    */
   void AddAnnotNumber(unsigned int annot_number);
   
   /** To check if the edge has the annot number */
   bool HasAnnotNumber(unsigned int annot_number) const;
   bool HasAnyAnnotNumber() const;

   /** To get all annot numbers of the edge annot */
   void GetAnnotNumbers(std::vector<unsigned int> * annot_numbers) const;

   /** To get the highest annot number of the edge annot. Asserts if
       it has no annot number (check using HasAnyAnnotNumber)*/
   unsigned int GetHighestAnnotNumber() const;

protected:
   CFlowGraphEdgeAnnot *_cfg_edge;
   bool edge_from_call_to_undefined_function;
   std::set<unsigned int> _annot_numbers;
};

class CECFGEdgeRecursiveCall : public CECFGEdgeAnnot
{
public:
   CECFGEdgeRecursiveCall(CECFGNode *return_, CECFGNode *result) : CECFGEdgeAnnot(), _return(return_), _result(result) {}
   CECFGNode *ReturnNode() { return _return; }
   CECFGNode *ResultNode() { return _result; }

   CECFGEdgeRecursiveCall *Copy();

   /** \return A string telling a color value that can be used for e.g. annotations.
      blue - because this is a recursive edge
   */
   std::string Color();

   /** \return A very brief annotation that indicates the type of edge concatenated with the
      annotation label of the corresponding flow graph edge.
      'RC' - Because this is a recursive call edge
   */
   std::string Annotation();
private:
   CECFGNode *_return;
   CECFGNode *_result;
};

#endif
