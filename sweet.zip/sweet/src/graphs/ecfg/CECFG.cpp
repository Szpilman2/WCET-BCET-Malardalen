// $Id: CECFG.cpp 5407 2013-06-16 14:52:16Z lkg02 $

#include "CECFG.h"
#include "../tools/CGraph.inl"
#include "program/CGenericFunction.h"
#include "graphs/cfg/CFlowGraph.h"
#include "graphs/cfg/CFlowGraphNode.h"
#include <cassert>

using namespace std;

template class CGraph<CECFGNode, CECFGEdgeAnnot>;

CECFG::
~CECFG(void)
{
   
   for(unsigned i=0; i<NrOfNodes(); i++) {
      delete NodeAt(i);
   }

}

void
CECFG::
AddPendingRecursiveEdges(list <pair<CECFGNode*,CECFGNode*> > *pending_edges,
                         map <CGenericFunction*, pair<CECFGNode*,CECFGNode*> >*function_entry_return, const CSymTabBase *symtab, const CSteensgaardPA &pa)
{
   
   for (list <pair<CECFGNode*, CECFGNode*> >::iterator edge_it=pending_edges->begin(); edge_it!=pending_edges->end(); ) {
      CFlowGraphNode *cfg_call_node = edge_it->first->GetFlowGraphNode();
      CGenericStmtCall *call_stmt = dynamic_cast<CGenericStmtCall*>(cfg_call_node->Stmt());
      assert(call_stmt);
      list <CGenericFunction*> called_functions;
      call_stmt->CalledFunctions(&called_functions, symtab, pa);
      bool handled = false;
      // There may be multiple functions called due to pointer analysis approximations.
      for (list <CGenericFunction*>::iterator func_it=called_functions.begin(); func_it!=called_functions.end(); func_it++) {
         CGenericFunction *function = *func_it;
         map <CGenericFunction*, pair<CECFGNode*, CECFGNode*> >::iterator it = function_entry_return->find(function);
         if (it != function_entry_return->end()) {
            // We obtain the call and result nodes from the current list element
            CECFGNode *call_node = edge_it->first;
            CECFGNode *result_node = edge_it->second;

            // We obtain the entry and return node of the called function from the map
            CECFGNode *entry_node = (*function_entry_return)[function].first;
            CECFGNode *return_node = (*function_entry_return)[function].second;


            // The call edge annotation need to be a little more expressive.
            // Note that none of these edges has a corresponding edge in the flow graph..
            CECFGEdgeAnnot *recursive_call_edge = new CECFGEdgeRecursiveCall(result_node, return_node);
            CECFGEdgeAnnot *recursive_return_edge = new CECFGEdgeAnnot();

            AddEdge(call_node, entry_node, recursive_call_edge);
            AddEdge(return_node, result_node, recursive_return_edge);
            handled = true;
         }
      }
      if (handled) {
         edge_it = pending_edges->erase(edge_it);
      } else {
         edge_it++;
      }
   }

}

// Basically just adds all nodes and edges in `flowgraph' to this
// ecfg. However there is an exception: the call->result edges are not
// added to this ecfg since they don't represent an actual control
// flow (in an interprocedural perspective). Instead such edges are
// added to the list of pending edges `pending_edges'.
void
CECFG::
ExtendWithFlowgraph(CFlowGraph *flowgraph, std::vector<CECFGNode*> *bb_to_ecfg_map, 
		    std::list<std::pair<CECFGNode*, CECFGNode*> > *pending_edges, 
		    const CSymTabBase *symtab, const CSteensgaardPA &pa)
{
   

   // flowgraph->PrintDetailed();

   // For each node in the cfg, add a node in the ecfg. Maintain a mapping <cfg_node, ecfg_node>
   // that will be useful when handling the edges.
   // Nodes in graphs has id:s that is the same as their position (NodeAt) and these number are consecutive
   bb_to_ecfg_map->resize(flowgraph->NrOfNodes());
   for (unsigned cfg_node_id=0; cfg_node_id<flowgraph->NrOfNodes(); cfg_node_id++) {
      CECFGNode *ecfg_node = new CECFGNode();
      ecfg_node->AddFlowGraphNode(flowgraph->NodeAt(cfg_node_id));
      AddNode(ecfg_node);
      (*bb_to_ecfg_map)[cfg_node_id] = ecfg_node;
   }

   // flowgraph->PrintDetailed();

   CFlowGraph::T_edge_list edge_list;
   flowgraph->Edges(&edge_list);
   for (CFlowGraph::T_edge_list_iterator edge_it=edge_list.begin(); edge_it!=edge_list.end(); edge_it++) {
      CFlowGraphNode *from_node = edge_it->from;
      CFlowGraphNode *to_node = edge_it->to;
      CFlowGraphEdgeAnnot *cfg_edge_annot = edge_it->edge_annot;
      CGenericStmt *from_stmt = from_node->Stmt();

      // Use the mapping to find the ecfg-nodes
      CECFGNode *ecfg_from_node = (*bb_to_ecfg_map)[from_node->Id()];
      CECFGNode *ecfg_to_node = (*bb_to_ecfg_map)[to_node->Id()];

      bool handle_as_call = false;
      if (from_stmt->Type() == CGenericStmt::GS_CALL) {
         CGenericStmtCall *call_stmt = dynamic_cast<CGenericStmtCall*>(from_stmt);
         assert(call_stmt);
         list <CGenericFunction*> called_functions;
         call_stmt->CalledFunctions(&called_functions, symtab, pa);
         if (called_functions.size() > 0) {
           handle_as_call = true;
         }
      }

      // Ebbe: 20100425. Before these two function calls where located in the if part below...
      // Now a false-edges is set up independant on if the function call is a valid one or not. 

      // Annotate the call-node with the return to node
      ecfg_from_node->SetFalseEdgeSuccessor(ecfg_to_node);
      // Also annotate the return-to-node with the call-stmt-node to be able to
      // get the necessary information from it.
      ecfg_to_node->SetFalseEdgePredecessor(ecfg_from_node);
      
      if (handle_as_call) {
         // This is an edge from call to result. In general, that is not a valid execution path, instead
         // we will later add interprocedure edges to and from the appropriate function(s). Save a pair
         // of nodes to be used to hook in these edges later.
         pending_edges->push_back(make_pair(ecfg_from_node, ecfg_to_node));
      } else {
         // Just add a corresponding edge within the ecfg.
         CECFGEdgeAnnot *ecfg_edge_annot = new CECFGEdgeAnnot(cfg_edge_annot);
         ecfg_edge_annot->SetEdgeFromCallToUndefinedFunction();

         AddEdge(ecfg_from_node, ecfg_to_node, ecfg_edge_annot);
         // Find out what labels the CFG edge has
         vector<unsigned int> edge_labels;
         from_node->GetAnnotNumbersOfOutgoingEdge(to_node, cfg_edge_annot, edge_labels);
         for (vector<unsigned int>::iterator l = edge_labels.begin(); l != edge_labels.end(); ++l)
            AddAnnotNumberToEdge(*l, ecfg_from_node, ecfg_to_node, ecfg_edge_annot);
      }
   }


}


void CECFG::AddAnnotNumberToEdge(unsigned int label, CECFGNode * from, CECFGNode * to, CECFGEdgeAnnot * edge_annot)
{
   assert(from);
   assert(to);
   from->AddAnnotNumberToSuccessor(label, to, edge_annot);
}

void
CECFG::
PrintWithFlowGraphNodeNames(ostream *o)
{
   
   for (node_iterator node_it=NodesBegin(); node_it!=NodesEnd(); node_it++) {
      CECFGNode *ecfg_node = *node_it;
      CFlowGraphNode *cfg_node = ecfg_node->GetFlowGraphNode();
      if (ecfg_node->SuccSize() == 0) {
         *o << "   " << cfg_node->Id() << " -> ";
      } else {
         for (CECFGNode::succ_iterator succ=ecfg_node->SuccBegin(); succ!=ecfg_node->SuccEnd(); succ++) {
            *o << "   " << cfg_node->Id() << " -> " << succ->node->GetFlowGraphNode()->Id();
         }
      }
      *o << endl;
   }

}
