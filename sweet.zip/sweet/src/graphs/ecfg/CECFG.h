// $Id: CECFG.h 2545 2010-10-18 12:46:10Z ael01 $

#ifndef CECFG_H_
#define CECFG_H_

#include "graphs/tools/CGraph.h"
#include "CECFGNode.h"
#include "CECFGEdgeAnnot.h"
#include <map>
#include <iostream>
#include <list>
#include <set>

class CProgram;
class CScopeGraph;
class CFlowGraph;
class CGenericFunction;
class CSymTabBase;
class CSteensgaardPA;

/** \class CECFG The Extended Control Flow Graph is an interprocedural flow graph. Each node of this ECFG graph
      can represent more than one node in the flow graph (typically a basic block). This particular ECFG may be
      built context sensitive, so that if the same function called at more than one site get its nodes repeated
      for each new site. However the repeated nodes are not identical: a special scope pointer in the nodes will
      identify the context.
*/
class CECFG : public CGraph<CECFGNode, CECFGEdgeAnnot>
{
public:

   CECFG(CScopeGraph *scope_graph=NULL) : _scope_graph(scope_graph) { }

   virtual ~CECFG(void);

   void SetScopeGraph(CScopeGraph *scope_graph) { _scope_graph = scope_graph; }
   const CScopeGraph * GetScopeGraph() const { return _scope_graph; }

   // Adds a sub-graph corresponding to the cfg `cfg' to this ecfg
   void AddFlowgraph(CFlowGraph *flowgraph);

   /** Adds intraprocedure call edges.
      \param pending_edges A list of pairs of ecfg-nodes <n1, n2> where n1 points to a flow graph node that is a
         call node and n2 points to one that is a return-to node. This pair represents an edge in the flow graph,
         since in the flow graph there is an edge between such two nodes, despite that there are no program flow
         between such nodes. In the extended control flow graph such edges are however not present but instead the
         interprocedure flow is represented by "call->enter" and "return->result" edges.
      \param function_entry_return A mapping function to <entry, return>, where entry and return are nodes of the
         function.
      \param symtab A pointer to a symbol table for the current ast.
      \param pa A pointer analysis of the current ast.
         This function will add "call->enter" and "return->result" edges for all nodes in \a pending_edges whose
         call have a matching function in \a function_entry_return. Those edges in \a pending_edges that are
         matching (and thus inserted a pair of edges into the extended flow graph) are removed from \a pending_edges.
         The added edges are assigned the property "recursive-call" and "recursive-return" respectively.
   */
   void AddPendingRecursiveEdges(std::list<std::pair<CECFGNode*, CECFGNode*> > *pending_edges,
                        std::map<CGenericFunction*, std::pair<CECFGNode*, CECFGNode*> > *function_entry_return, const CSymTabBase *symtab, const CSteensgaardPA &pa);

   // Extends this Extended Control Flow Graph with a subgraph corresponding to the passed flowgraph.
   // All nodes and edges in `flowgraph' will get their counterpart in `ecfg'. To make a meaning as an 
   // Extended flowgraph edges into and outfrom this isolated sub-graph needs to be added.
   // Will add the new nodes to the vector pointed to by `bb_to_ecfg_map' in a way that they can be 
   // access using the nodeid of the flow graph nodes, hence can serve as fast-access mapping.
   // During the traversal it will ignore all edges in the flowgraph from a call to a result node 
   // (no corresponding edge will be added to this ecfg). The corresponding nodes will be added in 
   // `pending_edges' for later convenient retrieval.
   void ExtendWithFlowgraph(CFlowGraph *flowgraph, std::vector<CECFGNode*> *bb_to_ecfg_map,
                            std::list<std::pair<CECFGNode*, CECFGNode*> > *pending_edges,
                            const CSymTabBase *symtab, const CSteensgaardPA &pa);

   /** Add label @a label to the edge that goes from @a from to @a to */
   void AddAnnotNumberToEdge(unsigned int label, CECFGNode * from, CECFGNode * to, CECFGEdgeAnnot * edge_annot);
   
   /** Add label @a label to the edge that goes from the node with id @a from to the node with id @a to */
   void AddAnnotNumberToEdge(unsigned int label, int from, int to, CECFGEdgeAnnot * edge_annot) {AddAnnotNumberToEdge(label, NodeAt(from), NodeAt(to), edge_annot);}

   // Print the graph as text
   void PrintWithFlowGraphNodeNames(std::ostream *o);
   void PrintWithFlowGraphNodeNames(void) { PrintWithFlowGraphNodeNames(&std::cout); }

private:
   CScopeGraph *_scope_graph;
};

#endif
