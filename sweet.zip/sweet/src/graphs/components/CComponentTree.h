// $Id: CComponentTree.h 327 2009-05-06 08:55:06Z msl01 $

#ifndef CCOMPONENT_TREE_H_
#define CCOMPONENT_TREE_H_

#include "graphs/components/CComponent.h"
#include "graphs/tools/CTree.h"

// This is the abstract tree class for a component tree. A "component" is a possibly strongly connected component.
template <typename T_Sub_Node>
class CComponentTree : public CTree <CComponent <T_Sub_Node> >
{
private:
public:

   virtual ~CComponentTree(void)
   {
      for (typename CTree <CComponent <T_Sub_Node> >::tree_node_iterator tree_node=CTree <CComponent <T_Sub_Node> >::TreeNodesBegin();
           tree_node!=CTree <CComponent <T_Sub_Node> >::TreeNodesEnd(); tree_node++) {
         delete *tree_node;
      }
   }

   // Just for logging.
   void Print(void) { Print(std::cout); }
   void Print(std::ostream &o) { CTree <CComponent <T_Sub_Node> >::TreeRoot()->Print(o, ""); }
};

#endif
