// $Id: CComponent.h 3853 2012-02-28 06:36:07Z jgn01 $

#ifndef CCOMPONENT_H_
#define CCOMPONENT_H_

#include "graphs/tools/CTreeNode.h"
#include <set>
#include <list>
#include <map>

/* This class defines a component which is a possibly strongly
   connected component, or to be more specific, a loop. In general, a
   loop can be defined by the statements in the loop that does not
   belong to any inner loop, and a forest of sequential inner loops.
   At the top level of a CFG we have the similar: a number of
   statements belonging to the cfg but not to any of the loops in the
   cfg, and all sequential loops of the cfg (at the outermost level of
   loop nesting).  Hence we represent also the top level of the cfg as
   a "component", however the set of headers and the set of back edges
   will be empty for the top level component.  There is also an
   indication if the scc is reducible (the top level scc is of course
   always).

   This class is however, not restricted to analyze CFG:s only, it can
   handle any class, we just used CFG:s to explain the meaning. A
   summary: Basically a hierarchy of scc:s, however at the top level
   it may not be a scc, but some ohter structure similar to a scc.

   In a CFG the `T_Sub_Node' is typically a basic block class.  */

template <typename T_Sub_Node>
class CComponent : public CTreeNode <CComponent<T_Sub_Node> >
{
private:
   std::set<T_Sub_Node *> _subnodes;
   std::list<T_Sub_Node *> _headers;
   std::set<std::pair<T_Sub_Node *, T_Sub_Node*> > _backedges;
   bool _reducible;
   std::list<T_Sub_Node *> *_exit_nodes;
public:
   typedef typename std::list<T_Sub_Node*>::iterator head_iterator;
   typedef typename std::set<T_Sub_Node*>::iterator subnode_iterator;
   typedef typename std::set<std::pair<T_Sub_Node *, T_Sub_Node*> >::iterator backedge_iterator;
   typedef typename CTreeNode <CComponent <T_Sub_Node> >::kid_iterator kid_iterator;

   inline CComponent(bool reducible) { _reducible = reducible; _exit_nodes = 0; }
   virtual ~CComponent() { if (_exit_nodes) delete _exit_nodes; }

   inline T_Sub_Node *Head(void) const { return *_headers.begin(); }
   inline bool IsHead(T_Sub_Node *node) { assert(_headers.size() == 1); return node == *_headers.begin(); }
   inline head_iterator HeadBegin(void) { return _headers.begin(); }
   inline head_iterator HeadEnd(void) { return _headers.end(); }
   inline backedge_iterator BackedgeBegin(void) { return _backedges.begin(); }
   inline backedge_iterator BackedgeEnd(void) { return _backedges.end(); }
   inline subnode_iterator SubNodeBegin(void) { return _subnodes.begin(); }
   inline subnode_iterator SubNodeEnd(void) { return _subnodes.end(); }

   inline bool IsSubNode(T_Sub_Node *node) { return _subnodes.find(node) != _subnodes.end(); }
   inline bool IsBackedge(T_Sub_Node *from, T_Sub_Node *to) { return _backedges.find(make_pair(from, to)) != _backedges.end(); }

   inline std::set<T_Sub_Node *> *SubNodes(void) { return &_subnodes; }
   inline bool IsReducible(void) const { return _reducible; }

   // The subnodes are just unrelated objects during the algorithm. The are however 
   // used initially to build the structure of dj-nodes.
   inline void AddSubNode(T_Sub_Node *nd) { _subnodes.insert(nd); }
   inline void RemoveSubNode(T_Sub_Node *nd) { _subnodes.erase(nd); }

   // This function returns a pointer to a list of nodes that are exit nodes to this component. 
   // For the root component of a component tree `nodes' will contain the exit node.
   // The memory pointed to by the returned pointer belongs to this component.
   // The result will be cached.
   // O(N) where N is the total number of edges starting in the nodes of this component
   const std::list<T_Sub_Node *> *ExitNodes(std::map<T_Sub_Node*, CComponent <T_Sub_Node>*> *node_to_component);

    inline void AddBackedge(T_Sub_Node *from, T_Sub_Node *to) { _backedges.insert(std::make_pair(from, to)); }
   inline void AddHead(T_Sub_Node *node) { _headers.remove(node); _headers.push_back(node); }
   inline void RemoveHead(T_Sub_Node *node) { _headers.remove(node); }

   // Just for logging. Prints a block of details about each scc in the scc-tree rooted at this. Indented properly.
   void Print(void) { Print(std::cout, ""); }
   void Print(std::ostream &o) { Print(o, ""); }
   void Print(std::ostream &o, std::string tabbing);
};

//  We find exit edges by following successors in the CFG, and if the successor is not in the same loop (i.e. component)
//  then it is an exit edge.
template <typename T_Sub_Node>
const std::list<T_Sub_Node *> *CComponent<T_Sub_Node>::ExitNodes(std::map<T_Sub_Node*, CComponent <T_Sub_Node>*> *node_to_component)
{
   if (!_exit_nodes) {
      _exit_nodes = new std::list<T_Sub_Node *>();
      for (subnode_iterator node_it=SubNodeBegin(); node_it!=SubNodeEnd(); node_it++) {
         T_Sub_Node *node = *node_it;
         CComponent <T_Sub_Node> *component;
         component = (*node_to_component)[node];
         for (typename T_Sub_Node::succ_iterator succ_it=node->SuccBegin(); succ_it!=node->SuccEnd(); succ_it++) {
            T_Sub_Node *succ = succ_it->node;
            if ((*node_to_component)[succ] != component) {
               _exit_nodes->push_back(node);
               break;
            }
         }
      }
   }
   return _exit_nodes;
}

template <typename T_Sub_Node>
void CComponent<T_Sub_Node>::Print(std::ostream &o, std::string tabbing)
{
   o << "\n" << tabbing << "Graph nodes:";
   for (subnode_iterator it = _subnodes.begin(); it != _subnodes.end(); it++) {
      o << (*it)->Id() << " ";
   }

   o << "\n" << tabbing << "Header nodes:";
   for (head_iterator it=HeadBegin(); it!=HeadEnd(); it++) {
      o << (*it)->Id() << " " << "("<<(*it)<<")";
   }

   o << "\n" << tabbing << "Back edges:";
   for (backedge_iterator it = _backedges.begin(); it != _backedges.end(); it++) {
      o << it->first->Id() << "->" << it->second->Id() << " ";
   }

   o << "\n" << tabbing << "Nr of subordinated sccs:" << CTreeNode <CComponent<T_Sub_Node> >::KidsSize() << std::endl;
   for (kid_iterator kid = CTreeNode <CComponent<T_Sub_Node> >::KidBegin(); kid != CTreeNode <CComponent<T_Sub_Node> >::KidEnd(); kid++) {
      kid->node->Print(o, tabbing+"  ");
   }
}


#endif
