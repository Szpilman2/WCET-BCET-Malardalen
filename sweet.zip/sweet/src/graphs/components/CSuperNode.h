// $Id: CSuperNode.h 327 2009-05-06 08:55:06Z msl01 $

#ifndef CSUPERNODE_H_
#define CSUPERNODE_H_

/* This defines a class of nodes that is intended to wrap some sub-node type. It is intended for
   the NODE_SPLITTING algorithm, but might be useful also for other algorithms that needs to wrap
   some other node type, and mergeing the content when collapsing nodes. */

#include "graphs/tools/CNode.h"
#include <set>



template <typename T_Sub_Node>
class CSuperNode : public CNode < CSuperNode <T_Sub_Node> >
{
private:
   std::set<T_Sub_Node *> _sub_nodes;
public:
   // Adds a sub node to the list of subnodes
   void AddSubNode(T_Sub_Node *node) { _sub_nodes.insert(node); }

   // Returns the set of sub-nodes
   std::set<T_Sub_Node *> *SubNodes(void) { return &_sub_nodes; }

   // Will merge the contents (i.e. the sub-nodes) into this
   void EatContents(CSuperNode *theother)
   {
      for (typename std::set<T_Sub_Node *>::iterator  sub_node=theother->_sub_nodes.begin();  sub_node!=theother->_sub_nodes.end();  sub_node++) {
         _sub_nodes.insert(*sub_node);
      }
      theother->_sub_nodes.clear();
   }
};

#endif
